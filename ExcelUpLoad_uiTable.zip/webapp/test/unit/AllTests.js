sap.ui.define([
	"excelupload/ExcelUpLoad_uiTable/test/unit/controller/mainview.controller"
], function () {
	"use strict";
});