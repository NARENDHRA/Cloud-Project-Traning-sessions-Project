/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"excelupload/ExcelUpLoad_uiTable/test/integration/AllJourneys"
	], function () {
		QUnit.start();
	});
});