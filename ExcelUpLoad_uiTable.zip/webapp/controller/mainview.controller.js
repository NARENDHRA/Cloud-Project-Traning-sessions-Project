sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("excelupload.ExcelUpLoad_uiTable.controller.mainview", {
		onInit: function () {
			this.getOwnerComponent().getModel().setDefaultBindingMode("TwoWay");
		},
		onChangetrigger: function (evt) {
			var oFileUpId = this.byId("fileUpload"),
				domRef = oFileUpId.getFocusDomRef(),
				file = domRef.files[0];
			oFileUpId.clear();
			this._importxlxsfile(file);
		},
		_importxlxsfile: function (file) {
			if (file && window.FileReader) {
				var reader = new FileReader();
				var that = this;
				reader.onload = function (evt) {
					var data = evt.target.result;
					//var xlsx = XLSX.read(data, {type: 'binary'});
					var CHUNK_SIZE = 0x8000; // arbitrary number here, not too small, not too big
					var index = 0;
					var array = new Uint8Array(data);
					var length = array.length;
					var arr = '';
					var slice1;
					while (index < length) {
						slice1 = array.subarray(index, Math.min(index + CHUNK_SIZE, length)); // `Math.min` is not really necessary here I think
						arr += String.fromCharCode.apply(null, slice1);
						index += CHUNK_SIZE;
					}
					try {
						var xlsx = XLSX.read(btoa(arr), {
							type: 'base64'
						});
					} catch (err) {
						sap.m.MessageBox.show(err.message, {
							title: "Error",
							styleClass: "sapUiSizeCompact messageBox",
							icon: sap.m.MessageBox.Icon.ERROR,
							actions: [sap.m.MessageBox.Action.OK]
						});
						that.getView().byId("fileUpload").setValue("");
						return false;
					}

					var result = xlsx.Strings;
					result = {};
					var sheet = xlsx.SheetNames[0];
					// xlsx.Sheets[xlsx.SheetNames[0]]['!ref'] = "A1:F10";
					xlsx.SheetNames.forEach(function (sheetName) {
						var rObjArr = XLSX.utils
							.sheet_to_row_object_array(xlsx.Sheets[sheetName]);
						if (rObjArr.length > 0) {
							result[sheetName] = rObjArr;
						}
					});
					var sheetData = result[sheet];
					if (sheetData === undefined) {
						sap.m.MessageBox.show("Invalid Excel\nUse Excel template to upload", {
							title: "Error",
							styleClass: "sapUiSizeCompact messageBox",
							icon: sap.m.MessageBox.Icon.ERROR,
							actions: [sap.m.MessageBox.Action.OK]
						});
						that.getView().byId("fileUpload").setValue("");
						return false;
					}
					that._creatobjPy(sheetData);

				};
				reader.readAsArrayBuffer(file);
			}
		},
		_creatobjPy: function (Data) {
			var oMod = this.getView().getModel(),
				excelData = [];
			//Excel Header set
			for (var k = 0; k < Data.length; k++) {
				var data = Data[k];
				var oProductID = data["Product ID"] ? data["Product ID"].trim() : "";
				var oTypeCode = data["Type Code"] ? data["Type Code"].trim() : "";
				var oCategory = data["Category"] ? data["Category"].trim() : "";
				var oSupplierID = data["Supplier ID"] ? data["Supplier ID"].trim() : "";
				var Reference = data["Reference"] ? data["Reference"].trim() : "";
				var obj = {
					"ProductID": oProductID,
					"TypeCode": oTypeCode,
					"Category": oCategory,
					"SupplierID": oSupplierID
				};
				excelData.push(obj);
			}
			var oTable = this.getView().byId("swbTable").getTable();
			// var oContexeArry = [];
			// $.each(excelData, function (i, val) {
			// 	var oContext = oMod.createEntry("/ProductSet", {
			// 		properties: val
			// 	});
			// 	oContexeArry.push(oContext);
			// });
			// var oKeyPath = oTable.getBinding().aKeys;
			var oArray = Object.keys(oTable.getModel().oData);
			this.OModel = oTable.getModel();
			var that = this;
			$.each(oArray, function (i, oPath) {
				// var oKeyOobj = oPath.split("'")[1];
				var oKeyOobj = that.OModel.getProperty("/" + oPath);
				var a = excelData.filter(function (objt) {
					return objt.ProductID === oKeyOobj.ProductID;
				});
				if (a[0] !== undefined) {
					that.OModel.oData[oPath].TypeCode = a[0].TypeCode;
					that.OModel.oData[oPath].Category = a[0].Category;
					that.OModel.oData[oPath].SupplierID = a[0].SupplierID;
				}
			});
			this.OModel.updateBindings(true);
		},
		onPressSavefn: function (evt) {
			var oMDL = this.getOwnerComponent().getModel();

		},
		onPressCanclefn: function (evt) {
			var oTable = this.getView().byId("swbTable").getTable();
			var tblModel = oTable.getModel();
			tblModel.refresh(true);
		}
	});
});