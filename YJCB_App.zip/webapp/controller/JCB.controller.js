 $.sap.require('sap.ui.thirdparty.jqueryui.jquery-ui-core');
 $.sap.require('sap.ui.thirdparty.jqueryui.jquery-ui-widget');
 $.sap.require('sap.ui.thirdparty.jqueryui.jquery-ui-mouse');
 $.sap.require('sap.ui.thirdparty.jqueryui.jquery-ui-sortable');
 $.sap.require('sap.ui.thirdparty.jqueryui.jquery-ui-droppable');
 $.sap.require('sap.ui.thirdparty.jqueryui.jquery-ui-draggable');
 sap.ui.define([
 	"sap/ui/core/mvc/Controller"
 ], function (Controller) {
 	"use strict";

 	return Controller.extend("jcboard.YJCB_App.controller.JCB", {
 		onInit: function () {
 			var oModel = new sap.ui.model.json.JSONModel();
 			var obj = {
 				"results": [{
 					"order": "EXT300056",
 					"c": [{
 						"order": "E301300471",
 						"type": "Accept"
 					}, {
 						"order": "E301300462",
 						"type": "Accept"
 					}, {
 						"order": "E301300461",
 						"type": "Accept"
 					}, {
 						"order": "E301300451",
 						"type": "Reject"
 					}, {
 						"order": "E301300441",
 						"type": "Reject"
 					}]
 				}]
 			};
 			oModel.setData(obj);
 			this.getView().setModel(oModel, "orderModel");
 			var oheaderData = {
 				startDate: new Date("2019", "01", "08", "8", "0"),
 				"oData": [{
 					"name": "BAY01 - QUICK SERVICE",
 					"role": "",
 					// "appointments": [{
 					// 	start: new Date("2016", "01", "15", "10", "0"),
 					// 	end: new Date("2016", "11", "25", "12", "0"),
 					// 	title: "Team collaboration",
 					// 	info: "room 1",
 					// 	type: "Type01",
 					// 	pic: "sap-icon://sap-ui5",
 					// 	tentative: false
 					// }, {
 					// 	start: new Date("2016", "01", "13", "9", "0"),
 					// 	end: new Date("2016", "01", "09", "10", "0"),
 					// 	title: "Reminder",
 					// 	type: "Type06"
 					// }, {
 					// 	start: new Date("2016", "07", "10", "0", "0"),
 					// 	end: new Date("2016", "09", "16", "23", "59"),
 					// 	title: "Vacation",
 					// 	info: "out of office",
 					// 	type: "Type04",
 					// 	tentative: false
 					// }, {
 					// 	start: new Date("2016", "07", "1", "0", "0"),
 					// 	end: new Date("2016", "09", "31", "23", "59"),
 					// 	title: "New quarter",
 					// 	type: "Type10",
 					// 	tentative: false
 					// }, {
 					// 	start: new Date("2019", "0", "03", "0", "01"),
 					// 	end: new Date("2019", "0", "04", "23", "59"),
 					// 	title: "Workshop",
 					// 	info: "regular",
 					// 	type: "Type07",
 					// 	pic: "sap-icon://sap-ui5",
 					// 	tentative: false
 					// }, {
 					// 	start: new Date("2019", "0", "05", "08", "30"),
 					// 	end: new Date("2019", "0", "05", "09", "30"),
 					// 	title: "Meet Donna Moore",
 					// 	type: "Type02",
 					// 	tentative: false
 					// }, {
 					// 	start: new Date("2019", "0", "08", "10", "0"),
 					// 	end: new Date("2019", "0", "08", "12", "0"),
 					// 	title: "Team meeting",
 					// 	info: "room 1",
 					// 	type: "Type01",
 					// 	pic: "sap-icon://sap-ui5",
 					// 	tentative: false
 					// }, {
 					// 	start: new Date("2019", "0", "09", "0", "0"),
 					// 	end: new Date("2019", "0", "09", "23", "59"),
 					// 	title: "Vacation",
 					// 	info: "out of office",
 					// 	type: "Type02",
 					// 	tentative: false
 					// }, {
 					// 	start: new Date("2019", "0", "11", "0", "0"),
 					// 	end: new Date("2019", "0", "12", "23", "59"),
 					// 	title: "Education",
 					// 	info: "",
 					// 	type: "Type03",
 					// 	tentative: false
 					// }, {
 					// 	start: new Date("2019", "0", "16", "00", "30"),
 					// 	end: new Date("2019", "0", "16", "23", "30"),
 					// 	title: "New Product",
 					// 	info: "room 105",
 					// 	type: "Type04",
 					// 	tentative: true
 					// }, {
 					// 	start: new Date("2019", "0", "18", "11", "30"),
 					// 	end: new Date("2019", "0", "18", "13", "30"),
 					// 	title: "Lunch",
 					// 	info: "canteen",
 					// 	type: "Type03",
 					// 	tentative: true
 					// }, {
 					// 	start: new Date("2019", "0", "20", "11", "30"),
 					// 	end: new Date("2019", "0", "20", "13", "30"),
 					// 	title: "Lunch",
 					// 	info: "canteen",
 					// 	type: "Type03",
 					// 	tentative: true
 					// }, {
 					// 	start: new Date("2019", "0", "18", "0", "01"),
 					// 	end: new Date("2019", "0", "19", "23", "59"),
 					// 	title: "Working out of the building",
 					// 	type: "Type07",
 					// 	pic: "sap-icon://sap-ui5",
 					// 	tentative: false
 					// }, {
 					// 	start: new Date("2019", "0", "23", "08", "00"),
 					// 	end: new Date("2019", "0", "24", "18", "30"),
 					// 	title: "Discussion of the plan",
 					// 	info: "Online meeting",
 					// 	type: "Type04",
 					// 	tentative: false
 					// }, {
 					// 	start: new Date("2019", "0", "25", "0", "01"),
 					// 	end: new Date("2019", "0", "26", "23", "59"),
 					// 	title: "Workshop",
 					// 	info: "regular",
 					// 	type: "Type07",
 					// 	pic: "sap-icon://sap-ui5",
 					// 	tentative: false
 					// }, {
 					// 	start: new Date("2019", "2", "30", "10", "0"),
 					// 	end: new Date("2019", "4", "33", "12", "0"),
 					// 	title: "Working out of the building",
 					// 	type: "Type07",
 					// 	pic: "sap-icon://sap-ui5",
 					// 	tentative: false
 					// }, {
 					// 	start: new Date("2019", "8", "1", "00", "30"),
 					// 	end: new Date("2019", "10", "15", "23", "30"),
 					// 	title: "Development of a new Product",
 					// 	info: "room 207",
 					// 	type: "Type03",
 					// 	tentative: true
 					// }, {
 					// 	start: new Date("2019", "1", "15", "10", "0"),
 					// 	end: new Date("2019", "2", "25", "12", "0"),
 					// 	title: "Team collaboration",
 					// 	info: "room 1",
 					// 	type: "Type01",
 					// 	pic: "sap-icon://sap-ui5",
 					// 	tentative: false
 					// }, {
 					// 	start: new Date("2019", "2", "13", "9", "0"),
 					// 	end: new Date("2019", "3", "09", "10", "0"),
 					// 	title: "Reminder",
 					// 	type: "Type06"
 					// }, {
 					// 	start: new Date("2019", "03", "10", "0", "0"),
 					// 	end: new Date("2019", "05", "16", "23", "59"),
 					// 	title: "Vacation",
 					// 	info: "out of office",
 					// 	type: "Type04",
 					// 	tentative: false
 					// }, {
 					// 	start: new Date("2019", "07", "1", "0", "0"),
 					// 	end: new Date("2019", "09", "31", "23", "59"),
 					// 	title: "New quarter",
 					// 	type: "Type10",
 					// 	tentative: false
 					// }],
 					"headers": [{
 						start: new Date("2019", "01", "08", "8", "0"),
 						end: new Date("2019", "01", "08", "11", "30"),
 						title: "National",
 						type: "Type04"
 					}, {
 						start: new Date("2019", "01", "10", "10", "0"),
 						end: new Date("2019", "01", "10", "12", "59"),
 						title: "Birthday",
 						type: "Type05"
 					}, {
 						start: new Date("2019", "01", "17", "0", "0"),
 						end: new Date("2019", "01", "17", "23", "59"),
 						title: "Reminder",
 						type: "Type06"
 					}]
 				}, {
 					"name": "BAY02 - ELECTRICAL",
 					"role": "",
 					"headers": [{
 						start: new Date("2019", "01", "08", "0", "0"),
 						end: new Date("2019", "01", "08", "23", "59"),
 						title: "National",
 						type: "Type04"
 					}]
 				}, {
 					"name": "BAY03 - MECHANICAL",
 					"role": "",
 					"headers": [{
 						start: new Date("2019", "01", "08", "0", "0"),
 						end: new Date("2019", "01", "08", "23", "59"),
 						title: "National",
 						type: "Type04"
 					}]
 				}]
 			};
 			var oAppntModel = new sap.ui.model.json.JSONModel();
 			oAppntModel.setData(oheaderData);
 			this.getView().setModel(oAppntModel, "intervalModel");
 			var oSortableList = this.getView().byId("DragList");
 			var listId = oSortableList.getId();
 			var listUlId = listId + "-listUl";
 			//var materialModel = new sap.ui.model.json.JSONModel();
 			//var oDropableTable = this.getView().byId("dropableTable");
 			//var tableId = oDropableTable.getId();
 			// oSortableList.onAfterRendering = function () {
 			// 	if (sap.m.List.prototype.onAfterRendering) {
 			// 		sap.m.List.prototype.onAfterRendering.apply(this);
 			// 	}
 			// 	$("#" + listUlId + " li").draggable({
 			// 		helper: "clone"
 			// 	});
 			// };
 		},
 		onListUpDatefinnsed: function (evt) {
 			var src = evt.getSource();
 			var item = src.getItems()[0];
 			var oinItems = item.getContent()[0].getItems();
 			$.each(oinItems, function (i, o) {
 				var buttonId = oinItems[i].getId();
 				$("#" + buttonId).css("z-index", "2");
 				$("#" + buttonId).draggable({
 					helper: "clone",
 					cancel: false
 				});
 			});
 			// var a = src.getItems()[0];
 		},
 		onPresReorderAssgin: function (evt) {
 			var oevt = evt.getSource();
 			var sfragment = "jcboard.YJCB_App.view.Reorder";
 			if (!this._dialog) {
 				this._dialog = sap.ui.xmlfragment(sfragment, this);
 				this.getView().addDependent(this._dialog);
 			}
 			// open dialog
 			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._dialog);
 			this._dialog.open();
 		},
 		onCancelDailog: function (evt) {
 			this._dialog.close();
 		},
 		onAfterRendering: function (evt) {
 				var plCalanderId = this.getView().byId("PC1");
 				$("#" + plCalanderId.getId()).droppable({
 					drop: function (event, ui) {
 						var listElementId = ui.draggable.context.id;
 						var draggedElement = sap.ui.getCore().byId(listElementId);
 						var oContext = draggedElement.getBindingContext("orderModel");
 					}
 				});
 			}
 			// onDragStart: function (evt) {
 			// 	debugger;
 			// }
 	});
 });