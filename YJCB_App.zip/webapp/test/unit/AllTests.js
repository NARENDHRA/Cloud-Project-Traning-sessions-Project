sap.ui.define([
	"jcboard/YJCB_App/test/unit/controller/JCB.controller"
], function () {
	"use strict";
});