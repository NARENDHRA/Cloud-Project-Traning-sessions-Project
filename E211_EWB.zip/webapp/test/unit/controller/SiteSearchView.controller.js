/*global QUnit*/

sap.ui.define([
	"com/p66/w/E211_EWB/controller/SiteSearchView.controller"
], function (Controller) {
	"use strict";

	QUnit.module("SiteSearchView Controller");

	QUnit.test("I should test the SiteSearchView controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});