sap.ui.define([
	"com/p66/w/E211_EWB/test/unit/controller/SiteSearchView.controller"
], function () {
	"use strict";
});