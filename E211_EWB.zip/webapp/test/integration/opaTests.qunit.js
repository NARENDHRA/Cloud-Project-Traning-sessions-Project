/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"com/p66/w/E211_EWB/test/integration/AllJourneys"
	], function () {
		QUnit.start();
	});
});