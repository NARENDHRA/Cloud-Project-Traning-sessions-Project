sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("com.p66.w.E211_EWB.controller.SiteSearchView", {
		onInit: function () {
			this.getRouter();
		},
		onInitSmartFilterBar: function (evt) {
			var s = evt.getSource(),
				Maxesults = s.getControlByKey("DimUnit");
			Maxesults.setValue("100");
		},
		getRouter: function () {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},
		onPressLineItemSiteNo: function (evt) {
			var siteNoVal = evt.getSource().getBindingContext().getObject().ProductID;
			this.getRouter().navTo("SiteInfoViewsec", {
				siteNo: siteNoVal,
				NewSiteAction: "X"
			});
		},
		onPressNonEnvironmentalNewSite: function (evt) {
			var OnewSiteAction = evt.getSource().getText();
			this.getRouter().navTo("SiteInfoViewsec", {
				siteNo: "X",
				NewSiteAction: OnewSiteAction
			});

		}
	});
});