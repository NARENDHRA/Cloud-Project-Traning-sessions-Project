/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"smarcomplib/ZSMART_CONTROL/test/unit/AllTests"
	], function () {
		QUnit.start();
	});
});
