/*global location */

sap.ui.define([
	"wipeditor/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"wipeditor/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	'sap/m/MessageToast'

], function(BaseController, JSONModel, History, formatter, Filter, FilterOperator, MessageToast) {
	"use strict";

	return BaseController.extend("wipeditor.controller.Detail", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		onInit: function() {
			// this.byId("idsmartTable").setUseExportToExcel(true);
			this.byId("idsmartTable").setHeight("100%");
			// this.byId("idsmartTable").setInitiallyVisibleFields("Pspid,Matnr,LstarText,Budat,Zzwerks,Pernr,Sname");
			this.oTable = this.getView().byId("idsmartTable");
			var oView = this.getView();
			var oIconTabBar = oView.byId("iconTabBar");
			oIconTabBar.setSelectedKey("Info");
			this.sKey = "Info";

			// Model used to manipulate control states. The chosen values make sure,
			// detail page is busy indication immediately so there is no break in
			// between the busy indication for loading the view's meta data
			var oViewModel = new JSONModel({
				busy: false,
				delay: 0,
				lineItemListTitle: this.getResourceBundle().getText("detailLineItemTableHeading"),
				SaveButton: false,
				ReviewedButton: false,
				UnReviewButton: false,
				ReplaceWordButton: false,
				ModifyReverse: false,
				UpdateCodesButton: false,
				MassTransferButton: false,
				SplitTransferButton: false,
				ConsolidateButton: false,
				Message: true,
				Meinh: true,
				ToMatter: true,
				Quantity: true,
				PerCent: true,
				Narrative: true,
				Material: true,
				LstarText: true,
				ReviewComplete: true,
				Belnr: true,
				Budat: true,
				Buzei: true,
				Zzwerks: true,
				Pernr: true,
				Sname: true,
				Megbtr: true,
				Zzbgrp: true,
				ZzbgrpDesc: true,
				Zzteam: true,
				ZzteamDesc: true,
				Zzfepgrp: true,
				ZzfepgrpDesc: true,
				Zzphasecode: true,
				Zztskcd: true,
				Zzactcd: true,
				Zzffactcd: true,
				ToZzfftskcd: true,
				Isiserror: "",
				ChangeFrom: "",
				ChangeTo: "",
				DocumentNo: "",
				OrginalHours: "",
				NewHours: "",
				UnitHours: "",
				Phasecode: "",
				TaskCodes: "",
				ActivityCodes: "",
				FfTaskCode: "",
				FfActivityCodes: "",
				PhCodeApply: false,
				TaskCodeApply: false,
				ActCodeApply: false,
				FfTCodeApply: false,
				FFActCodeApply: false
			});

			this.getRouter().getRoute("detail").attachPatternMatched(this._onObjectMatched, this);

			this.setModel(oViewModel, "detailView");
			oViewModel.setProperty("/SaveButton", false);

			this.byId("idsmartTable").attachBeforeRebindTable(this.onBeforeRebindTable, this);
			//matter to Phase model for f04
			var fo4Model = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_VALUE_HELP_SRV/");
			this.setModel(fo4Model, "fo4Model");

		},

		handleValueHelpTargetMatter: function(oEvent) {
			var sFrgmntName;
			sFrgmntName = "wipeditor.fragment.matterToPhase";
			if (!this._valueHelpMatterToPhaseDialog) {
				this._valueHelpMatterToPhaseDialog = sap.ui.xmlfragment(sFrgmntName, this);
				this.getView().addDependent(this._valueHelpMatterToPhaseDialog);
			}
			if (this._valueHelpMatterToPhaseDialog.getBinding("items")) {
				this._valueHelpMatterToPhaseDialog.getBinding("items").filter([]);
			}
			var that = this,
				oSource = oEvent.getSource();
			this._valueHelpMatterToPhaseDialog.attachConfirm(that, function(evt) {
				// var a = oSource.getBindingContext();
				// var m = a.getModel();
				// m.setProperty(a.getPath() + "/ToMatter", evt.getParameter("selectedItem").getTitle());
				oSource.setValue(evt.getParameter("selectedItem").getTitle());
				that._valueHelpMatterToPhaseDialog.destroy();
			}, null);
			this._valueHelpMatterToPhaseDialog.open();

		},

		// _handleMattertoPhaseValueHelpClose: function(oEvent) {

		// 	this._valueHelpMatterToPhase.destroy();

		// },

		handleValueHelpSearchMatter: function(oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new sap.ui.model.Filter("Pspid", sap.ui.model.FilterOperator.Contains, sValue);
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilter]);

		},

		/// method for  Task Code fileds 
		getCodesSet: function(Pspid, Workdate) {
			var actCodeJSONModel = new sap.ui.model.json.JSONModel({});
			this.setModel(actCodeJSONModel, "actCodeModel");
			var actCodeModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_WIPCODES_SRV/");
			actCodeModel.setUseBatch(true);
			// ActCodeModel  with filter Values of  Matter and Workdate	
			var actCodeFilter = [],
				batchrequest = [],
				callBacks = [];
			actCodeFilter.push(new sap.ui.model.Filter("Pspid", sap.ui.model.FilterOperator.EQ, Pspid));
			actCodeFilter.push(new sap.ui.model.Filter("Workdate", sap.ui.model.FilterOperator.EQ, Workdate));
			var mParameters = {
				filters: actCodeFilter,
				error: function(oError) {
					// this.getTable().setBusy(false);
				}
			};
			mParameters.success = function(oData, response) {
				// set the odata JSON as data of JSON model
				actCodeJSONModel.setData(oData);
				actCodeJSONModel.refresh();
			};

			//actCodeModel.read("/ActCodeSet", mParameters);
			callBacks["ActCodeSet"] = function(oData, response) {
				// set the odata JSON as data of JSON model
				actCodeJSONModel.setData(oData);
				actCodeJSONModel.refresh();
			};
			var entityType = actCodeModel.oMetadata._getEntityTypeByPath("/ActCodeSet"),
				readPath = "/ActCodeSet?" + sap.ui.model.odata.ODataUtils.createFilterParams(actCodeFilter, actCodeModel.oMetadata, entityType);
			batchrequest.push(actCodeModel.createBatchOperation(readPath, "GET"));

			// TaskCode model passing with Filter Value with PhaseCode.

			var taskCodeFilter = [];
			taskCodeFilter.push(new sap.ui.model.Filter("Phasecode", sap.ui.model.FilterOperator.EQ, ""));

			var taskCodeJSONModel = new sap.ui.model.json.JSONModel({});
			this.setModel(taskCodeJSONModel, "taskCodeModel");
			mParameters.filters = taskCodeFilter;
			mParameters.success = function(oData, response) {
				// set the odata JSON as data of JSON model
				taskCodeJSONModel.setData(oData);
				taskCodeJSONModel.refresh();
			};

			//actCodeModel.read("/TaskCodeSet", mParameters);
			callBacks["TaskCodeSet"] = function(oData, response) {
				// set the odata JSON as data of JSON model
				taskCodeJSONModel.setData(oData);
				taskCodeJSONModel.refresh();
			};
			entityType = actCodeModel.oMetadata._getEntityTypeByPath("/TaskCodeSet");
			readPath = "/TaskCodeSet?" + sap.ui.model.odata.ODataUtils.createFilterParams(taskCodeFilter, actCodeModel.oMetadata, entityType);
			batchrequest.push(actCodeModel.createBatchOperation(readPath, "GET"));

			// FFTaskCode model with filter value with  matter

			var fftaskCodeFilter = [];
			fftaskCodeFilter.push(new sap.ui.model.Filter("Matter", sap.ui.model.FilterOperator.EQ, Pspid));

			var ffTaskCodeJSONModel = new sap.ui.model.json.JSONModel({});
			this.setModel(ffTaskCodeJSONModel, "fftaskCodeModel");
			mParameters.filters = fftaskCodeFilter;
			mParameters.success = function(oData, response) {
				// set the odata JSON as data of JSON model
				ffTaskCodeJSONModel.setData(oData);
				ffTaskCodeJSONModel.refresh();
			};
			//actCodeModel.read("/FfTaskCodeSet", mParameters);
			callBacks["FfTaskCodeSet"] = function(oData, response) {
				// set the odata JSON as data of JSON model
				ffTaskCodeJSONModel.setData(oData);
				ffTaskCodeJSONModel.refresh();
			};
			entityType = actCodeModel.oMetadata._getEntityTypeByPath("/FfTaskCodeSet");
			readPath = "/FfTaskCodeSet?" + sap.ui.model.odata.ODataUtils.createFilterParams(fftaskCodeFilter, actCodeModel.oMetadata,
				entityType);
			batchrequest.push(actCodeModel.createBatchOperation(readPath, "GET"));

			// PhaseCode model with filter values with matter (Pspid) & workdate	
			var phaseCodeFilter = [];
			phaseCodeFilter.push(new sap.ui.model.Filter("Pspid", sap.ui.model.FilterOperator.EQ, Pspid));
			phaseCodeFilter.push(new sap.ui.model.Filter("Workdate", sap.ui.model.FilterOperator.EQ, Workdate));
			var phaseCodeJSONModel = new sap.ui.model.json.JSONModel({});
			this.setModel(phaseCodeJSONModel, "phaseCodeModel");
			mParameters.filters = phaseCodeFilter;
			mParameters.success = function(oData, response) {
				phaseCodeJSONModel.setData(oData);
				phaseCodeJSONModel.refresh();
			};

			//actCodeModel.read("/PhaseCodeSet", mParameters);
			callBacks["PhaseCodeSet"] = function(oData, response) {
				// set the odata JSON as data of JSON model
				phaseCodeJSONModel.setData(oData);
				phaseCodeJSONModel.refresh();
			};
			entityType = actCodeModel.oMetadata._getEntityTypeByPath("/PhaseCodeSet");
			readPath = "/PhaseCodeSet?" + sap.ui.model.odata.ODataUtils.createFilterParams(phaseCodeFilter, actCodeModel.oMetadata, entityType);
			batchrequest.push(actCodeModel.createBatchOperation(readPath, "GET"));

			// make a batch call
			actCodeModel.addBatchReadOperations(batchrequest);
			actCodeModel.submitBatch(
				function(r) {
					var callEntity;
					$.each(r.__batchResponses, function(i, br) {
						if (br && br.data) {
							callEntity = br.data.__metadata.title;
							callBacks[callEntity](br.data);
						}
					});
				},
				function(e) {

				},
				true);
		},

		_onObjectMatched: function(oEvent) {
			this.sObjectId = oEvent.getParameter("arguments").Pspid;
			this.sObjKunnr = oEvent.getParameter("arguments").Kunnr;
			this.sObjworkDate = oEvent.getParameter("arguments").Workdate;

			this.getModel().metadataLoaded().then(function() {
				var sObjectPath = this.getModel().createKey("/WipMattersSet", {
					Pspid: this.sObjectId
				});
				// service is required to change for single record read.
				//	this._bindView("/" + sObjectPath);

				this.oFilter = new sap.ui.model.Filter("Pspid", sap.ui.model.FilterOperator.EQ, this.sObjectId);

				this.byId("idsmartTable").rebindTable();
				this.getCodesSet(this.sObjectId, this.sObjworkDate);
				var oIconTabBar = this.byId("iconTabBar");
				oIconTabBar.setSelectedKey("Info");

			}.bind(this));

		},
		onBeforeRebindTable: function(oEvent) {
			var mBindingParams = oEvent.getParameter("bindingParams");
			var aFilter = [];
			if (this.sObjectId) {
				aFilter.push(new sap.ui.model.Filter("Pspid", sap.ui.model.FilterOperator.EQ, this.sObjectId));
				mBindingParams.filters = aFilter;

			}
		},

		// for table column visible on  selected  tabe 
		// Info:true,
		// 			ToMatter:true,
		// 			Quantity:true,
		// 			PerCent:true,
		handleDataReceived: function(oEvt) {
			var oViewModel = this.getModel("detailView");
			oViewModel.setProperty("/Message", false);
			oViewModel.setProperty("/ToMatter", false);
			oViewModel.setProperty("/Quantity", false);
			oViewModel.setProperty("/PerCent", false);
			oViewModel.setProperty("/Meinh", false);

			oViewModel.setProperty("/Narrative", false);
			oViewModel.setProperty("/Material", true);
			oViewModel.setProperty("/SaveButton", false);
			oViewModel.setProperty("/ReviewComplete", false);
			oViewModel.setProperty("/SplitTransferButton", false);
			oViewModel.setProperty("/MassTransferButton", false);
			oViewModel.setProperty("/UpdateCodesButton", false);
			oViewModel.setProperty("/ReviewedButton", false);
			oViewModel.setProperty("/ModifyReverse", false);
			oViewModel.setProperty("/UnReviewButton", false);
			oViewModel.setProperty("/ReplaceWordButton", false);
			oViewModel.setProperty("/Buzei", false);
		},

		//Table Columns Visible Fields in narrative Edit
		narrativieEditTabFields: function() {
			var oViewModel = this.getModel("detailView");

			//Button Visible or unVisible
			oViewModel.setProperty("/SaveButton", true);
			oViewModel.setProperty("/ReviewedButton", false);
			oViewModel.setProperty("/UnReviewButton", false);
			oViewModel.setProperty("/ReplaceWordButton", false);
			oViewModel.setProperty("/MassTransferButton", false);
			oViewModel.setProperty("/SplitTransferButton", false);
			oViewModel.setProperty("/ConsolidateButton", false);
			oViewModel.setProperty("/ModifyReverse", false);
			// Table Columns 
			oViewModel.setProperty("/Meinh", false);
			oViewModel.setProperty("/Message", false);
			oViewModel.setProperty("/ToMatter", false);
			oViewModel.setProperty("/Quantity", false);
			oViewModel.setProperty("/PerCent", false);
			oViewModel.setProperty("/Narrative", true);
			oViewModel.setProperty("/UpdateCodesButton", false);
			oViewModel.setProperty("/Budat", true);
			oViewModel.setProperty("/Pernr", true);
			oViewModel.setProperty("/Sname", true);
			oViewModel.setProperty("/Zzwerks", true);
			oViewModel.setProperty("/ReviewComplete", true);
			oViewModel.setProperty("/Belnr", false);
			oViewModel.setProperty("/Megbtr", false);
			oViewModel.setProperty("/Material", false);
			oViewModel.setProperty("/Zzbgrp", false);
			oViewModel.setProperty("/ZzbgrpDesc", false);
			oViewModel.setProperty("/ZzteamDesc", false);
			oViewModel.setProperty("/ZzfepgrpDesc", false);
			oViewModel.setProperty("/Zzteam", false);
			oViewModel.setProperty("/Zzfepgrp", false);
			oViewModel.setProperty("/Zzphasecode", false);
			oViewModel.setProperty("/Zztskcd", false);
			oViewModel.setProperty("/Zzactcd", false);
			oViewModel.setProperty("/Zzffactcd", false);
			oViewModel.setProperty("/ToZzfftskcd", false);

		},

		// Table Visible fileds for  lineItemEdit 
		lineItemEditFields: function(oEvt) {
			var oViewModel = this.getModel("detailView");
			oViewModel.setProperty("/SaveButton", true);
			oViewModel.setProperty("/ReviewedButton", false);
			oViewModel.setProperty("/UnReviewButton", false);
			oViewModel.setProperty("/ReplaceWordButton", false);
			oViewModel.setProperty("/MassTransferButton", false);
			oViewModel.setProperty("/SplitTransferButton", false);
			oViewModel.setProperty("/ConsolidateButton", false);
			oViewModel.setProperty("/UpdateCodesButton", false);
			oViewModel.setProperty("/ModifyReverse", false);
			oViewModel.setProperty("/Message", true);
			oViewModel.setProperty("/ToMatter", false);
			oViewModel.setProperty("/Quantity", false);
			oViewModel.setProperty("/PerCent", false);
			oViewModel.setProperty("/Meinh", true);
			oViewModel.setProperty("/Narrative", false);
			oViewModel.setProperty("/Budat", true);
			oViewModel.setProperty("/Pernr", true);
			oViewModel.setProperty("/Sname", true);
			oViewModel.setProperty("/Zzwerks", true);
			oViewModel.setProperty("/ReviewComplete", true);
			oViewModel.setProperty("/Belnr", true);
			oViewModel.setProperty("/Buzei", true);

			oViewModel.setProperty("/Megbtr", true);
			oViewModel.setProperty("/Material", false);
			oViewModel.setProperty("/Zzbgrp", true);
			oViewModel.setProperty("/ZzbgrpDesc", true);
			oViewModel.setProperty("/ZzteamDesc", true);
			oViewModel.setProperty("/ZzfepgrpDesc", true);
			oViewModel.setProperty("/Zzteam", true);
			oViewModel.setProperty("/Zzfepgrp", true);
			oViewModel.setProperty("/Zzphasecode", true);
			oViewModel.setProperty("/Zztskcd", true);
			oViewModel.setProperty("/Zzactcd", true);
			oViewModel.setProperty("/Zzffactcd", true);
			oViewModel.setProperty("/ToZzfftskcd", true);

		},
		lineItemTranferFields: function(oEvt) {
			var oViewModel = this.getModel("detailView");
			oViewModel.setProperty("/SaveButton", true);
			oViewModel.setProperty("/ReviewedButton", false);
			oViewModel.setProperty("/UnReviewButton", false);
			oViewModel.setProperty("/ReplaceWordButton", false);
			oViewModel.setProperty("/MassTransferButton", false);
			oViewModel.setProperty("/SplitTransferButton", false);
			oViewModel.setProperty("/ConsolidateButton", false);
			oViewModel.setProperty("/UpdateCodesButton", false);
			oViewModel.setProperty("/ModifyReverse", false);
			oViewModel.setProperty("/Meinh", false);
			oViewModel.setProperty("/Message", true);
			oViewModel.setProperty("/ToMatter", true);
			oViewModel.setProperty("/Quantity", true);
			oViewModel.setProperty("/PerCent", true);
			oViewModel.setProperty("/Narrative", false);
			oViewModel.setProperty("/Budat", true);
			oViewModel.setProperty("/Pernr", true);
			oViewModel.setProperty("/Sname", true);
			oViewModel.setProperty("/Zzwerks", true);
			oViewModel.setProperty("/ReviewComplete", false);
			oViewModel.setProperty("/Belnr", true);
			oViewModel.setProperty("/Megbtr", true);
			oViewModel.setProperty("/Material", false);
			oViewModel.setProperty("/Zzbgrp", true);
			oViewModel.setProperty("/ZzbgrpDesc", true);
			oViewModel.setProperty("/ZzteamDesc", true);
			oViewModel.setProperty("/ZzfepgrpDesc", true);
			oViewModel.setProperty("/Zzteam", true);
			oViewModel.setProperty("/Zzfepgrp", true);
			oViewModel.setProperty("/Zzphasecode", true);
			oViewModel.setProperty("/Zztskcd", true);
			oViewModel.setProperty("/Zzactcd", true);
			oViewModel.setProperty("/Zzffactcd", true);
			oViewModel.setProperty("/ToZzfftskcd", true);
			oViewModel.setProperty("/Buzei", true);
		},

		// IconTabFilter 
		onQuickFilter: function(oEvent) {
			this.sKey = oEvent.getParameter("selectedKey");
			if (!this.sKey) {
				this.sKey = this.getView().byId("idIconTabBar").getSelectedKey();
			}
			var oTable = this.getView().byId("idsmartTable");

			this.setIconTab(this.sKey);
		},
		setIconTab: function(sKey) {
			var that = this;
			var oViewModel = this.getModel("detailView");
			var oTable = this.byId("idsmartTable");
			var tbl = oTable.getTable();
			switch (sKey) {
				case "Info":
					this.getTable().setSelectionMode("None");
					this.handleDataReceived();
					tbl.clearSelection(true);
					tbl.setVisibleRowCount(11);
					break;
				case "NarrativeEdit":
					this.getTable().setSelectionMode("MultiToggle");
					this.narrativieEditTabFields();
					tbl.clearSelection(true);
					tbl.setVisibleRowCount(6);
					break;
				case "LineItemedit":
					this.getTable().setSelectionMode("MultiToggle");
					this.lineItemEditFields();
					tbl.clearSelection(true);
					tbl.setVisibleRowCount(11);
					break;
				case "LineItemTransfor":
					this.getTable().setSelectionMode("MultiToggle");
					oTable._oTable.clearSelection(true);
					tbl.setVisibleRowCount(11);
					this.lineItemTranferFields();
					// oViewModel.setProperty("/SaveButton", true);
					break;
			}
		},

		onPress: function(evt) {
			var oViewModel = this.getModel("detailView");
			var skey1 = this.getView().byId("iconTabBar").getSelectedKey();
			var length = evt.getSource().getSelectedIndices().length;
			if (length === 1) {
				switch (skey1) {
					case "NarrativeEdit":
						oViewModel.setProperty("/ReviewedButton", true);
						oViewModel.setProperty("/UnReviewButton", true);
						oViewModel.setProperty("/ReplaceWordButton", true);
						break;

					case "LineItemedit":
						oViewModel.setProperty("/ReviewedButton", true);
						oViewModel.setProperty("/UnReviewButton", true);
						oViewModel.setProperty("/ReplaceWordButton", false);
						oViewModel.setProperty("/UpdateCodesButton", true);
						oViewModel.setProperty("/ModifyReverse", true);
						oViewModel.setProperty("/MassTransferButton", false);
						oViewModel.setProperty("/SplitTransferButton", false);
						break;
					case "LineItemTransfor":
						oViewModel.setProperty("/ReviewedButton", false);
						oViewModel.setProperty("/UnReviewButton", false);
						oViewModel.setProperty("/ReplaceWordButton", false);
						oViewModel.setProperty("/ModifyReverse", false);
						oViewModel.setProperty("/UpdateCodesButton", true);
						oViewModel.setProperty("/MassTransferButton", true);
						oViewModel.setProperty("/SplitTransferButton", true);

						break;

				}

			} else if (length > 1) {
				switch (skey1) {
					case "LineItemTransfor":
						oViewModel.setProperty("/ReviewedButton", false);
						oViewModel.setProperty("/UnReviewButton", false);
						oViewModel.setProperty("/ReplaceWordButton", false);
						oViewModel.setProperty("/UpdateCodesButton", true);
						oViewModel.setProperty("/MassTransferButton", true);
						oViewModel.setProperty("/SplitTransferButton", false);
						oViewModel.setProperty("/ConsolidateButton", true);
						break;
					case "LineItemedit":
						oViewModel.setProperty("/ModifyReverse", false);
				}

			} else if (length === 0) {
				switch (skey1) {
					case "NarrativeEdit":
						oViewModel.setProperty("/ReviewedButton", false);
						oViewModel.setProperty("/UnReviewButton", false);
						oViewModel.setProperty("/ReplaceWordButton", false);
						oViewModel.setProperty("/ModifyReverse", false);
						break;
					case "LineItemedit":
						oViewModel.setProperty("/ReviewedButton", false);
						oViewModel.setProperty("/UnReviewButton", false);
						oViewModel.setProperty("/ReplaceWordButton", false);
						oViewModel.setProperty("/UpdateCodesButton", false);
						oViewModel.setProperty("/ModifyReverse", false);
						break;
					case "LineItemTransfor":
						oViewModel.setProperty("/ReviewedButton", false);
						oViewModel.setProperty("/UnReviewButton", false);
						oViewModel.setProperty("/ReplaceWordButton", false);
						oViewModel.setProperty("/UpdateCodesButton", false);
						oViewModel.setProperty("/MassTransferButton", false);
						oViewModel.setProperty("/SplitTransferButton", false);
						oViewModel.setProperty("/ModifyReverse", false);
						break;
				}

			}

		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Event handler when the share by E-Mail button has been clicked
		 * @public
		 */
		onShareEmailPress: function() {
			var oViewModel = this.getModel("detailView");

			sap.m.URLHelper.triggerEmail(
				null,
				oViewModel.getProperty("/shareSendEmailSubject"),
				oViewModel.getProperty("/shareSendEmailMessage")
			);
		},

		/**
		 * Updates the item count within the line item table's header
		 * @param {object} oEvent an event containing the total number of items in the list
		 * @private
		 */
		onListUpdateFinished: function(oEvent) {
			var sTitle,
				iTotalItems = oEvent.getParameter("total"),
				oViewModel = this.getModel("detailView");

			// only update the counter if the length is final
			if (this.byId("lineItemsList").getBinding("items").isLengthFinal()) {
				if (iTotalItems) {
					sTitle = this.getResourceBundle().getText("detailLineItemTableHeadingCount", [iTotalItems]);
				} else {
					//Display 'Line Items' instead of 'Line items (0)'
					sTitle = this.getResourceBundle().getText("detailLineItemTableHeading");
				}
				oViewModel.setProperty("/lineItemListTitle", sTitle);
			}
		},

		/**
		 * Event handler  for navigating back.
		 * It there is a history entry we go one step back in the browser history
		 * If not, it will replace the current entry of the browser history with the master route.
		 * @public
		 */
		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash();

			if (sPreviousHash !== undefined) {
				history.go(-1);
			} else {
				this.getRouter().navTo("worklist", {}, true);
			}
		},

		/// filter button functionalty 
		onFilterButtonpress: function() {
			var sFrgmntName = "Filter";
			if (!this.oDialogFragment) {
				this.oDialogFragment = sap.ui.xmlfragment("wipeditor.fragment." + sFrgmntName, this);
				this.getView().addDependent(this.oDialogFragment);
			}
			this.oDialogFragment.open(this);
		},
		closeDialog: function() {
			this.oDialogFragment.close();
		},

		// getTable: function() {
		// 	var oTable = this.getView().byId("idsmartTable");
		// 	return oTable.getTable();
		// },
		/// refresh button function
		onRefreshButtonpress: function(evt) {
			var oTable = this.getView().byId("idsmartTable");
			var tbl = oTable.getTable();
			// 	tbl.clearSelection(true);
			// this.sKey = this.getView().byId("idIconTabBar").getSelectedKey();
			// 	this.setIconTab(this.sKey);
			// 	// this.lineItemTranferFields();
			this.messageRest(tbl);

		},
		messageRest: function(tbl) {
			var that = this;
			$.each(tbl.getSelectedIndices(), function(i, o) {
				var ctx = tbl.getContextByIndex(o);
				var m = ctx.getModel(ctx.getPath());
				m.setProperty(ctx.getPath() + "/ToMatter", "");
				m.setProperty(ctx.getPath() + "/ToMatter", "");
			});
			tbl.clearSelection();
		},
		OnReviewed: function() {
			var temp = "X";
			this.Review(temp);
		},
		OnUnReview: function() {
			var temp = "";
			this.Review(temp);
		},
		Review: function(temp) {
			var tbl = this.getTable();
			var oBelnrArray = [];
			var oReviewComplete = [];
			var oLineItem = [];

			$.each(tbl.getSelectedIndices(), function(i, index) {
				var context1 = tbl.getContextByIndex(index);
				var obj = context1.getObject();
				oBelnrArray.push(obj.Belnr);
				oReviewComplete.push(obj.ReviewComplete);
				oLineItem.push(obj.Buzei);
			});
			var reviewedModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_WIP_EDITOR_SRV/");
			var oUrlParams = {
				CoNumber: oBelnrArray,
				Buzei: oLineItem,
				ReviewStatus: temp
			};

			reviewedModel.callFunction("/WIPREVIEW", {
				method: "GET",
				urlParameters: oUrlParams,
				success: function(oData, responce) {
					$.each(tbl.getSelectedIndices(), function(i, o) {
						var context1 = tbl.getContextByIndex(o);
						var sobj = context1.getObject();
						var a = $.grep(oData.results, function(oo, ii) {
							return sobj.Belnr === oo.Belnr;
						});
						var ctx = tbl.getContextByIndex(o);

						var oReviewCompletestate = ctx.getPath() + "/ReviewComplete";
						var model = ctx.getModel();

						model.setProperty(oReviewCompletestate, temp);

					});
				},

				error: function(oError) {

				}
			});

		},
		// OnUnReview: function(evtu) {

		// },

		getTable: function() {
			var oTable = this.getView().byId("idsmartTable");
			return oTable.getTable();
		},

		getReplaceModel: function() {
			var that = this;
			var replaceJSONModel = new sap.ui.model.json.JSONModel({});
			this.setModel(replaceJSONModel, "replaceModel");
			var replaceFilter = [];
			replaceFilter.push(new sap.ui.model.Filter("Pspid", sap.ui.model.FilterOperator.EQ, that.sObjectId));
			replaceFilter.push(new sap.ui.model.Filter("Kunnr", sap.ui.model.FilterOperator.EQ, that.sObjKunnr));
			var mParameters = {
				filters: replaceFilter,
				error: function(oError) {

					that.getTable().setBusy(false);
				}
			};
			mParameters.success = function(oData, response) {
				// set the odata JSON as data of JSON model
				replaceJSONModel.setData(oData);
				replaceJSONModel.refresh();
			};
			this.getOwnerComponent().getModel().read("/ReplaceWordsSet", mParameters);

		},

		OnReplaceWord: function(evvt) {

			var sFrgmntName = "ReplaceWords";
			if (!this.replaceWordoDailog) {
				this.replaceWordoDailog = sap.ui.xmlfragment("wipeditor.fragment." + sFrgmntName, this);
				this.getView().addDependent(this.replaceWordoDailog);
			}
			this.replaceWordoDailog.open(this);
			this.getReplaceModel();

		},
		onCancelDialog: function() {
			var oViewModel = this.getModel("detailView");
			var viewModelData = oViewModel.getData();
			oViewModel.setProperty("/ChangeFrom", "");
			oViewModel.setProperty("/ChangeTo", " ");

			this.replaceWordoDailog.close();
		},
		onReplaceSelected: function(evt) {

			var oViewModel = this.getModel("detailView");
			var viewModelData = oViewModel.getData();
			var ochangeFrom = viewModelData.ChangeFrom,
				ochangeTo = viewModelData.ChangeTo;
			var tbl = this.getTable();
			//	var oNarrativeArray = [];
			$.each(tbl.getSelectedIndices(), function(i, index) {
				var context1 = tbl.getContextByIndex(index);
				var narrative = context1.getPath() + "/NarrativeString";
				var obj = context1.getObject();
				var str = obj.NarrativeString;
				var finRep = str.replace(ochangeFrom, ochangeTo);
				var model = context1.getModel();
				model.setProperty(narrative, finRep);

			});
			this.onCancelDialog();

		},

		// save button
		OnSavePress: function(evt) {

			var tbl = this.getTable();
			var oModel = this.getOwnerComponent().getModel();
			//	var oNarrativeArray = [];
			$.each(tbl.getSelectedIndices(), function(i, index) {
				var context1 = tbl.getContextByIndex(index);
				var narrative = context1.getPath();
				var obj = context1.getObject();
				var str = obj.NarrativeString;
				var oEntry = {};
				oEntry.NarrativeString = str;
				oModel.update(narrative, oEntry, null, function() {
					MessageToast.show(" Narrative Update Successfully");
				}, function() {
					MessageToast.show(" Narrative Update UnSuccessfully");
				});
			});

		},

		OnModifyReverse: function(evt) {
			var oViewModel = this.getModel("detailView");
			var tbl = this.getTable();
			var fragPath = "wipeditor.fragment.modifyReverse";

			if (!this.modifyReverseoDailog) {
				this.modifyReverseoDailog = sap.ui.xmlfragment(fragPath, this);
				this.getView().addDependent(this.modifyReverseoDailog);
			}
			var osCtx = tbl.getContextByIndex(tbl.getSelectedIndices());
			var obj = osCtx.getObject();
			// viewModelData.DocumentNo = obj.Belnr;
			// viewModelData.OrginalHours = obj.Megbtr;
			// viewModelData.UnitHours = obj.Meinh;
			oViewModel.setProperty("/DocumentNo", obj.Belnr);
			oViewModel.setProperty("/OrginalHours", obj.Megbtr);
			oViewModel.setProperty("/UnitHours", obj.Meinh);
			this.modifyReverseoDailog.openBy(evt.getSource());

		},
		OnCancleModify: function(evt) {
			var oViewModel = this.getModel("detailView");
			// var viewModelData = oViewModel.getData();
			oViewModel.setProperty("/NewHours", "");
			this.modifyReverseoDailog.close();
		},
		OnSaveModify: function(evt) {
			// var that = this;
			var oViewModel = this.getModel("detailView");
			var viewModelData = oViewModel.getData();
			var newValHour = viewModelData.NewHours;
			// var newValHour = sap.ui.getCore().byId("idNewHours").getValue();
			var tbl = this.getTable();
			var tblModel = tbl.getModel();
			var index = tbl.getSelectedIndices();
			var oBelnrArray = [];
			var oAction = "MODIFY";
			var oHours = [];
			var oPercent = [];
			var oToZzactcd = [];
			var oToZzffactcd = [];
			var oToZzfftskcd = [];
			var oToMatter = [];
			var oToZztskcd = [];
			var oLineItem = [];
			var oToPhaseCode = "";

			var context1 = tbl.getContextByIndex(index);
			var obj = context1.getObject();
			oBelnrArray.push(obj.Belnr);
			oHours.push(obj.Megbtr);
			oLineItem.push(obj.Buzei);
			oPercent.push(obj.Percent);
			oToMatter.push(obj.ToMatter);
			oToZztskcd.push(obj.ToZztskcd);
			oToZzfftskcd.push(obj.ToZzfftskcd);
			oToZzffactcd.push(obj.ToZzffactcd);
			oToZzactcd.push(obj.ToZzactcd);

			var ModifyModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_WIP_EDITOR_SRV/");
			var oUrlParams = {
				Action: oAction,
				CoNumber: oBelnrArray,
				Hours: newValHour,
				Percentage: oPercent,
				ToActivityCode: oToZzactcd,
				ToFfActivityCode: oToZzffactcd,
				ToFfTaskCode: oToZzfftskcd,
				ToMatter: oToMatter,
				ToTaskCode: oToZztskcd,
				Buzei: oLineItem,
				ToPhaseCode: oToPhaseCode

			};
			// var isSuccess;
			ModifyModel.callFunction("/WIPTRANSFER", {
				method: "GET",
				urlParameters: oUrlParams,
				success: function(oData, responce) {
					// var context1 = tbl.getContextByIndex(index);
					var Quantity = context1.getPath() + "/Megbtr";
					// var model = context1.getModel();

					var msg = oData.results[0].Message;
					if (obj.Megbtr >= newValHour) {
						tblModel.setProperty(Quantity, newValHour);
					} else
						tblModel.setProperty(Quantity, obj.Megbtr);
					sap.m.MessageBox.show(msg);
				},

				error: function(oError) {

				}
			});
			tbl.clearSelection();
			this.OnCancleModify();

		},

		OnUpdateCodeed: function(evt) {

			var fragPath = "wipeditor.fragment.updatecode";

			if (!this.updateCodeoDailog) {
				this.updateCodeoDailog = sap.ui.xmlfragment(fragPath, this);
				this.getView().addDependent(this.updateCodeoDailog);
			}
			this.updateCodeoDailog.openBy(evt.getSource());

		},
		closeDialogUp: function(oEvt) {
			this.updateCodeoDailog.close();
		},

		OnUpDateCodes: function(evt) {
				var tbl = this.getTable();
			var oViewModel = this.getModel("detailView");
			var oActVal = oViewModel.getProperty("/ActivityCodes"),
				oPhaseVal = oViewModel.getProperty("/Phasecode"),
				oTaskVal = oViewModel.getProperty("/TaskCodes"),
				oFFTaskVal = oViewModel.getProperty("/FfTaskCode"),
				oFFActVal = oViewModel.getProperty("/FfActivityCodes"),
				oPhCodeCheck = oViewModel.getProperty("/PhCodeApply"),
				oTCodeCheck = oViewModel.getProperty("/TaskCodeApply"),
				oActCodeCheck = oViewModel.getProperty("/ActCodeApply"),
				oFFTCodeCheck = oViewModel.getProperty("/FfTCodeApply"),
				oFFActCodeCheck = oViewModel.getProperty("/FFActCodeApply");
				$.each(tbl.getSelectedIndices(), function(i, index) {
				var context1 = tbl.getContextByIndex(index);
				var oPhaseCode = context1.getPath() + "/Zzphasecode";
				var oTaskCode = context1.getPath() + "/ToZztskcd";
				var oActivityCode = context1.getPath() + "/ToZzactcd";
				var oFFActCode = context1.getPath() + "/ToZzffactcd";
				var oFFTaskCode = context1.getPath() + "/ToZzfftskcd";
				var model = context1.getModel();
				var tblModel = tbl.getModel();
				if (oPhCodeCheck === true) {
					model.setProperty(oPhaseCode, oPhaseVal);
				}
				// else model.setProperty(oPhaseCode, "");
				if (oTCodeCheck === true) {
					model.setProperty(oTaskCode, oTaskVal);
				}
				if (oActCodeCheck === true) {
					model.setProperty(oActivityCode, oActVal);
				}
				if (oFFTCodeCheck === true) {
					model.setProperty(oFFActCode, oFFActVal);
				}
				if (oFFActCodeCheck === true) {
					model.setProperty(oFFTaskCode, oFFTaskVal);
				}

			});
			this.updateCodeoDailog.close();

		},

		OnMassTransfer: function(evt) {
			var tbl = this.getTable();

			var aTableData = [];
			// var mTTbl = sap.ui.getCore().byId("splitWipTbl");
			for (var k = 0; k < tbl.getSelectedIndices().length; k++) {
				var osCtx = tbl.getContextByIndex(k);
				var obj = osCtx.getObject();
				var oRow = {
					Belnr: obj.Belnr,
					Buzei: obj.Buzei

				};
				aTableData.push(oRow);
			}
			var oModel = new sap.ui.model.json.JSONModel();
			oModel.setData({
				modelData: aTableData
			});
			this.getView().setModel(oModel, "mTransfer");
			var sFrgmntName;
			sFrgmntName = "wipeditor.fragment.massTransfer";
			if (!this._valueHelpMatterTransferDialog) {
				this._valueHelpMatterTransferDialog = sap.ui.xmlfragment(sFrgmntName, this);
				this.getView().addDependent(this._valueHelpMatterTransferDialog);
			}

			//Create a model and bind the table rows to this model

			// mTTbl.setModel(oModel);
			// mTTbl.bindRows("/modelData");

			this._valueHelpMatterTransferDialog.open();

		},
		onCancelMasstransferDialog: function() {
			this._valueHelpMatterTransferDialog.close();
		},
		OnTransfer: function(oEvent) {
			var osc = sap.ui.getCore(),
				oTargetMatter = osc.byId("idTargetMatter").getValue(),
				oPercentage = osc.byId("idPercentage").getValue();
			var tbl = this.getTable();
			//	var oNarrativeArray = [];
			$.each(tbl.getSelectedIndices(), function(i, index) {
				var context1 = tbl.getContextByIndex(index);
				var toMatter = context1.getPath() + "/ToMatter";
				var toPercent = context1.getPath() + "/Percent";
				var model = context1.getModel();
				model.setProperty(toMatter, oTargetMatter);
				model.setProperty(toPercent, oPercentage);

			});
			this.onCancelMasstransferDialog();
		},
		onDeletedIconPress: function(oTblRow) {
			var oView = this.getView();
			var that = this;

			var oTable = sap.ui.getCore().byId("splitWipTbl");
			var m = oTable.getModel();
			var data = m.getData();
			var aSelIndices = oTable.getSelectedIndex();
			// aSelIndices = aSelIndices.reverse();
			// var count = aSelIndices.length;

			var oConfirmMsg = "Are you sure you want to delete?";
			sap.m.MessageBox.confirm(oConfirmMsg, {
				icon: sap.m.MessageBox.Icon.QUESTION,
				title: "Confirmation",
				onClose: function(oEvent1) {
					if (oEvent1 === "OK") {

						// for (var i = 0; i < count; i++) {
						var value = aSelIndices;
						// that._aDelTableBF.push(data.modelData[value]);
						data.massTransfer.splice(value, 1);
						// }
						m.setData(data);
						oTable.clearSelection();
						// sap.m.MessageToast.show("Rows deleted: " + count);
					}
				}
			});

		},

		OnSplitTransfer: function(oEvt) {
			var tbl = this.getTable(),
				aNavValues = [];
			$.each(tbl.getSelectedIndices(), function(i, index) {
				var osCtx = tbl.getContextByIndex(index);
				var obj = osCtx.getObject();
				aNavValues.push(obj);
			});
			this.getRouter().navTo("SplitWip", {
				Belnr: aNavValues[0].Belnr
			});
			var delayInvk = (function(av) {
				return function() {
					$.sap.require("sap.ui.core.EventBus");
					var oBus = sap.ui.getCore().getEventBus();
					oBus.publish("splitWip", "fromWipDetail", av);
				};
			})(aNavValues);
			jQuery.sap.delayedCall(1000, this, delayInvk);
		},
		// value help dailog for to matter pahse in splitransfer function

		handleValueHelpMatterPhase: function(oEvent) {
			var sFieldName1, sFrgmntName;
			sFieldName1 = "Pspid";
			sFrgmntName = "matterToPhase";
			var sInputValue = oEvent.getSource().getValue();
			if (!this._valueHelpMatterToPhase) {
				this._valueHelpMatterToPhase = sap.ui.xmlfragment("wipeditor.fragment." + sFrgmntName, this);
				this.getView().addDependent(this._valueHelpMatterToPhase);
			}
			// create a filter for the binding
			var aFilter = [];
			var oFilter;
			if (sInputValue !== "") {
				oFilter = new sap.ui.model.Filter(sFieldName1, sap.ui.model.FilterOperator.EQ, sInputValue);
				aFilter.push(oFilter);
				this._valueHelpMatterToPhase._list.getBinding("items").filter(aFilter);
			}

			// open value help dialog filtered by the input value
			this._valueHelpMatterToPhase.open(sInputValue);
			var that = this;
			// if (oEvent.getSource().getPlaceholder() === "From")
			// 	this._valueHelpMatterToPhase.attachConfirm(that, function(evt) {
			// 		if (evt.sId === "confirm") {
			// 			that.byId("").setValue(evt.getParameters("selectedItems").selectedItem.getTitle());
			// 			that._valueHelpMatterToPhase.destroy();
			// 		}
			// 	}

			if (oEvent.getSource().getPlaceHolder() === "") {

			}

		},

		OnSplitTransfer_old: function(evts) {
			var sFrgmntName = "splitTransfer";
			if (!this.splitDailog) {
				this.splitDailog = sap.ui.xmlfragment("wipeditor.fragment." + sFrgmntName, this);
				this.getView().addDependent(this.splitDailog);
			}

			// var splitJSONModel = new sap.ui.model.json.JSONModel({});
			// this.setModel(splitJSONModel, "splitJSONModel");
			// var tbl = this.getTable();
			// 	$.each(tbl.getSelectedIndices(), function(i, index) {
			// 	var context1 = tbl.getContextByIndex(index);
			// 	var obj = context1.getObject();
			// 	});

			this.splitDailog.open();

		},
		onSplitClose: function(oEvt) {
			this.splitDailog.close();
		},

		OnConsolidate: function(evt) {
			var oViewModel = this.getModel("detailView");
			var tbl = this.getTable();
			var tblModel = tbl.getModel();

			var oBelnrArray = [];
			var oAction = "CONSOLIDATE";
			var oLineItem = [];
			var oPercent = [];
			var oQuantity = [];
			var oToMatter = [];
			var oToZztskcd = [];
			var oToZzfftskcd = [];
			var oToZzffactcd = [];
			var oToZzactcd = [];
			var oToPhaseCode = "";

			$.each(tbl.getSelectedIndices(), function(i, index) {
				var context1 = tbl.getContextByIndex(index);
				var obj = context1.getObject();
				oBelnrArray.push(obj.Belnr);
				oLineItem.push(obj.Buzei);
				oPercent.push(obj.Percent);
				oQuantity.push(obj.Quantity);
				oToMatter.push(obj.ToMatter);
				oToZztskcd.push(obj.ToZztskcd);
				oToZzfftskcd.push(obj.ToZzfftskcd);
				oToZzffactcd.push(obj.ToZzffactcd);
				oToZzactcd.push(obj.ToZzactcd);

			});
			var consolidateModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_WIP_EDITOR_SRV/");
			var oUrlParams = {
				Action: oAction,
				CoNumber: oBelnrArray,
				Buzei: oLineItem,
				Hours: oQuantity,
				Percentage: oPercent,
				ToActivityCode: oToZzactcd,
				ToFfActivityCode: oToZzffactcd,
				ToFfTaskCode: oToZzfftskcd,
				ToMatter: oToMatter,
				ToTaskCode: oToZztskcd,
				ToPhaseCode: oToPhaseCode
			};
			// var isSuccess;
			consolidateModel.callFunction("/WIPTRANSFER", {
				method: "GET",
				urlParameters: oUrlParams,
				success: function(oData, responce) {
					// $.each(tbl.getSelectedIndices(), function(i, o) {

					// var a = $.grep(oData.results, function(oo, ii) {

					// 	oViewModel.setProperty("/Isiserror", oo.Message);

					// 	return sobj.Belnr === oo.Belnr;

					// });
					for (var i = 0; i < tbl.getSelectedIndices().length; i++) {

						var context1 = tbl.getContextByIndex(i);
						// var sobj = context1.getObject();
						// var ctx = tbl.getContextByIndex(i);

						var iserrorstate = context1.getPath() + "/Isiserror";
						var model = context1.getModel();
						// model.setProperty(iserrorstate, oData.results.Message );
						tblModel.setProperty(iserrorstate, oData.results[0].Isiserror);
						// tbl.getRows()[0].mAggregations.cells[0].mProperties.text = "abc";

						// model.setProperty("/Isiserror", oData.results.Message);

					}

					// });
				},

				error: function(oError) {

				}
			});

		},

		onDocNoSearch: function(oEvent) {
			var tbl = this.getTable();
			var sQuery = oEvent.getParameter("query");
			var tFilter = [];
			if (sQuery) {
				tFilter.push(new sap.ui.model.Filter("Belnr", sap.ui.model.FilterOperator.EQ, sQuery));
			}
			tbl.getBinding("rows").filter(tFilter);

		},
		_applySearch: function(oTableSearchState) {
			var oViewModel = this.getModel("detailView");
			var oTable = this.getTable();
			oTable.getBinding("rows").filter(oTableSearchState);
			// changes the noDataText of the list in case there are no filter results
			if (oTableSearchState.length !== 0) {
				oViewModel.setProperty("/tableNoDataText", this.getResourceBundle().getText("worklistNoDataWithSearchText"));
			}
		},

		/* =========================================================== */
		/* begin: internal methods                                     */
		/* =========================================================== */

		/**
		 * Binds the view to the object path and expands the aggregated line items.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */

		/**
		 * Binds the view to the object path.
		 * @function
		 * @param {string} sObjectPath path to the object to be bound
		 * @private
		 */
		_bindView: function(sObjectPath) {
			var oViewModel = this.getModel("detailView"),
				oDataModel = this.getModel();

			this.getView().bindElement({
				path: sObjectPath,
				events: {
					change: this._onBindingChange.bind(this),
					dataRequested: function() {
						oDataModel.metadataLoaded().then(function() {
							// Busy indicator on view should only be set if metadata is loaded,
							// otherwise there may be two busy indications next to each other on the
							// screen. This happens because route matched handler already calls '_bindView'
							// while metadata is loaded.
							oViewModel.setProperty("/busy", true);
						});
					},
					dataReceived: function() {
						oViewModel.setProperty("/busy", false);
					}
				}
			});
		},

		_onBindingChange: function() {
			var oView = this.getView(),
				oViewModel = this.getModel("detailView"),
				oElementBinding = oView.getElementBinding();

			// No data for the binding
			if (!oElementBinding.getBoundContext()) {
				this.getRouter().getTargets().display("objectNotFound");
				return;
			}

			var oResourceBundle = this.getResourceBundle(),
				oObject = oView.getBindingContext().getObject(),
				sObjectId = oObject.Pspid,
				sObjectName = oObject.Pspid;

			// Everything went fine.
			oViewModel.setProperty("/busy", false);
			oViewModel.setProperty("/shareSendEmailSubject",
				oResourceBundle.getText("shareSendEmailObjectSubject", [sObjectId]));
			oViewModel.setProperty("/shareSendEmailMessage",
				oResourceBundle.getText("shareSendEmailObjectMessage", [sObjectName, sObjectId, location.href]));
		}

	});

});