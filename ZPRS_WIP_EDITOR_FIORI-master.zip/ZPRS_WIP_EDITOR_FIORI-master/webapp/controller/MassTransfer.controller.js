/*global location */
 
sap.ui.define([  
	"wipeditor/controller/BaseController",
	"sap/ui/model/json/JSONModel",  
	"sap/ui/core/routing/History",
	"wipeditor/model/formatter",
	'sap/m/MessageToast'
], function(BaseController, JSONModel, History, formatter, MessageToast) {
	"use strict";

	return BaseController.extend("wipeditor.controller.MassTransfer", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		onInit: function() {
			this.getRouter().getRoute("massTransfer").attachPatternMatched(this._onObjectMatchedm, this);
			$.sap.require("sap.ui.core.EventBus");
			var oBus = sap.ui.getCore().getEventBus();
			oBus.subscribe("massTransfer", "fromWipDetail", this.fromWipDetail, this);
			// //matter to Phase model for f04
			 var MView = this.getView();
			 MView.setModel(new JSONModel({
			MattertoPhase: ""
			}), "searchModel");
			var fo4Model = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_VALUE_HELP_SRV/");
			this.setModel(fo4Model, "fo4Model");
			
		},

		// f4 help model for ToMatterPhase

		fromWipDetail: function(sChannelId, sEventId, oData) {
			var mtModel = new JSONModel({
					massTransfer: oData
				}),
				oTable = this.getTable();
			oTable.setModel(mtModel);
			oTable.bindRows({
				path: "/massTransfer"
			});
		},
		getTable: function() {
			return this.getView().byId("splitWipTbl");
		},

		_onObjectMatchedm: function(oEvent) {

			var a;

		},
		
		OnMassTransfer: function(oEvent){
				var mtbl = this.getView().byId("splitWipTbl");
				var aNavValue = [];
			var oMatter = this.getView().byId("idTargetMatter").getValue();
			var oPercent = this.getView().byId("idPercentage").getValue();
				$.each(mtbl.getSelectedIndices(), function(i, index) {
				var osCtx = mtbl.getContextByIndex(index);
				var obj = osCtx.getObject();
				aNavValue.push(obj);
			});
			
			
				var sPreviousHash = History.getInstance().getPreviousHash();

			if (sPreviousHash !== undefined) {
				history.go(-1);
			} else {
				this.getRouter().navTo("detail", {}, true);
				
				
			}
			
			
		},
		
		
		handleCellClick: function(oEvent) {
			var oTblRow = oEvent.getParameter("rowIndex");
			this.onDeletedIconPress(oTblRow);
		},
		onDeletedIconPress: function(oTblRow) {
			var oView = this.getView();
			var that = this;

			var oTable = oView.byId("splitWipTbl");
			var m = oTable.getModel();
			var data = m.getData();
			var aSelIndices = oTable.getSelectedIndex();
			// aSelIndices = aSelIndices.reverse();
			// var count = aSelIndices.length;

			var oConfirmMsg = "Are you sure you want to delete?";
			sap.m.MessageBox.confirm(oConfirmMsg, {
				icon: sap.m.MessageBox.Icon.QUESTION,
				title: "Confirmation",
				onClose: function(oEvent1) {
					if (oEvent1 === "OK") {

						// for (var i = 0; i < count; i++) {
						var value = aSelIndices;
						// that._aDelTableBF.push(data.modelData[value]);
						data.massTransfer.splice(value, 1);
						// }
						m.setData(data);
						oTable.clearSelection();
						// sap.m.MessageToast.show("Rows deleted: " + count);
					}
				}
			});

		},

		OnMassTransferBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash();

			if (sPreviousHash !== undefined) {
				history.go(-1);
			} else {
				this.getRouter().navTo("detail", {}, true);
			}
		},

		handleValueHelpTargetMatter: function(oEvent) {
			var sFrgmntName;
			sFrgmntName = "wipeditor.fragment.matterToPhase";
			if (!this._valueHelpMatterToPhaseDialog) {
				this._valueHelpMatterToPhaseDialog = sap.ui.xmlfragment(sFrgmntName, this);
				this.getView().addDependent(this._valueHelpMatterToPhaseDialog);
			}
			this._valueHelpMatterToPhaseDialog.getBinding("items").filter([]);
			this._valueHelpMatterToPhaseDialog.open();

		},

		// _handleMattertoPhaseValueHelpClose: function(oEvent) {
			
		// 	this._valueHelpMatterToPhase.destroy();

		// },
		handleMatterConfirm: function(evt){
				var aContext = evt.getParameter("selectedContexts")[0];
			var searchModel = this.getView().getModel("searchModel");
			searchModel.setProperty("/MattertoPhase", aContext.getProperty("Pspid"));
			
		},

		handleValueHelpSearchMatter: function(oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new sap.ui.model.Filter("Pspid", sap.ui.model.FilterOperator.Contains, sValue);
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilter]);
			
	}
		// _handleMattertoPhaseValueHelpClose: function(evt){
		//   	var aContext = evt.getParameter("selectedContexts")[0];
		// 	var searchModel = this.getView().getModel("searchModel");
		// 	searchModel.setProperty("/MattertoPhase", aContext.getProperty("Pspid"));	
		// }
		
		

		// _bindView: function(sObjectPath) {
		// 	var oViewModel = this.getModel("detailView"),
		// 		oDataModel = this.getModel();

		// 	this.getView().bindElement({
		// 		path: sObjectPath,
		// 		events: {
		// 			change: this._onBindingChange.bind(this),
		// 			dataRequested: function() {
		// 				oDataModel.metadataLoaded().then(function() {
		// 					// Busy indicator on view should only be set if metadata is loaded,
		// 					// otherwise there may be two busy indications next to each other on the
		// 					// screen. This happens because route matched handler already calls '_bindView'
		// 					// while metadata is loaded.
		// 					oViewModel.setProperty("/busy", true);
		// 				});
		// 			},
		// 			dataReceived: function() {
		// 				oViewModel.setProperty("/busy", false);
		// 			}
		// 		}
		// 	});
		// },

		// _onBindingChange: function() {
		// 	var oView = this.getView(),
		// 		oViewModel = this.getModel("detailView"),
		// 		oElementBinding = oView.getElementBinding();

		// 	// No data for the binding
		// 	if (!oElementBinding.getBoundContext()) {
		// 		this.getRouter().getTargets().display("objectNotFound");
		// 		return;
		// 	}

		// 	var oResourceBundle = this.getResourceBundle(),
		// 		oObject = oView.getBindingContext().getObject(),
		// 		sObjectId = oObject.Pspid,
		// 		sObjectName = oObject.Pspid;

		// 	// Everything went fine.
		// 	oViewModel.setProperty("/busy", false);
		// 	oViewModel.setProperty("/shareSendEmailSubject",
		// 		oResourceBundle.getText("shareSendEmailObjectSubject", [sObjectId]));
		// 	oViewModel.setProperty("/shareSendEmailMessage",
		// 		oResourceBundle.getText("shareSendEmailObjectMessage", [sObjectName, sObjectId, location.href]));
		// }

	});

});