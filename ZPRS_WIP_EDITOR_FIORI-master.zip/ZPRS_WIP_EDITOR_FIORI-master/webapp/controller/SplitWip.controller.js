/*global location */

sap.ui.define([
	"wipeditor/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"wipeditor/model/formatter",
	'sap/m/MessageToast'
], function(BaseController, JSONModel, History, formatter, MessageToast) {
	"use strict";

	return BaseController.extend("wipeditor.controller.SplitWip", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		onInit: function() {
			this.getRouter().getRoute("SplitWip").attachPatternMatched(this._onObjectMatchedm, this);
			$.sap.require("sap.ui.core.EventBus");
			var oBus = sap.ui.getCore().getEventBus();
			oBus.subscribe("splitWip", "fromWipDetail", this.fromWipDetail, this);
			//matter to Phase model for f04
			var fo4Model = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_VALUE_HELP_SRV/");
			this.setModel(fo4Model, "fo4Model");
			// var splitView = new JSONModel({
			// 	transDelColumn : false,
			// 	transAddColumn: true
				
			// });
		},
		fromWipDetail: function(sChannelId, sEventId, oData) {
			var splitWipModel = new JSONModel({
					splitWip: oData
				}),
				oTable = this.getTable();
			oTable.setModel(splitWipModel);
			oTable.bindRows({
				path: "/splitWip"
			});
			var otlb = this.getTrnsTable();
			otlb.setModel(splitWipModel);
			otlb.bindRows({
				path: "/splitWip"
			});
		},
		getTable: function() {
			return this.getView().byId("splitWipTbl");
		},
		getTrnsTable: function() {
			return this.getView().byId("TransferTable");
		},
		_onObjectMatchedm: function(oEvent) {},

		OnsplitCancel: function() {
			var sPreviousHash = History.getInstance().getPreviousHash();
			if (sPreviousHash !== undefined) {
				history.go(-1);
			} else {
				this.getRouter().navTo("detail", {}, true);
			}
		},
		
		onPress: function(evt){
		 var a ;	
		},
		
		// Add Column Function 
		onADDColumn: function(evt) {
			var TransTable = this.getView().byId("TransferTable"),
				tabModel = TransTable.getModel(),
				modelData = tabModel.getData();
			// var arow = TransTable.rows;
			var aTable = [];
			for (var i = 0; i < modelData.splitWip.length; i++) {
				var value = modelData.splitWip[i];
				aTable.push(value);
			}
			var oRow = {
				ToMatter: "",
				ToZzactcd: "",
				// 				Phasecode: "",
				ToZzffactcd: "",
				ToZztskcd: "",
				ToZzfftskcd: ""

			};
			aTable.push(oRow);
			tabModel.setData({
				splitWip: aTable
			});
			sap.m.MessageToast.show("Rows added: " + 1);
		},

		handleValueHelpSearchMatter: function(oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new sap.ui.model.Filter("Pspid", sap.ui.model.FilterOperator.Contains, sValue);
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilter]);

		},
		handleValueHelpMatterPhase: function(oEvent) {
			var sFrgmntName;
			sFrgmntName = "wipeditor.fragment.matterToPhase";
			if (!this._valueHelpMatterToPhaseDialog) {
				this._valueHelpMatterToPhaseDialog = sap.ui.xmlfragment(sFrgmntName, this);
				this.getView().addDependent(this._valueHelpMatterToPhaseDialog);
			}
			if (this._valueHelpMatterToPhaseDialog.getBinding("items")) {
				this._valueHelpMatterToPhaseDialog.getBinding("items").filter([]);
			}
			var that = this,
				oSource = oEvent.getSource();
			this._valueHelpMatterToPhaseDialog.attachConfirm(that, function(evt) {
				// var a = oSource.getBindingContext();
				// var m = a.getModel();
				// m.setProperty(a.getPath() + "/ToMatter", evt.getParameter("selectedItem").getTitle());
				oSource.setValue(evt.getParameter("selectedItem").getTitle());
				that._valueHelpMatterToPhaseDialog.destroy();
			}, null);
			this._valueHelpMatterToPhaseDialog.open();

		},
		OnSplit: function(oEvt) {

		}
	});

});