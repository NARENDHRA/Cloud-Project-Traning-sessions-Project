/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"htmltypeview/ZDemo_htmlViewProject/test/integration/AllJourneys"
	], function () {
		QUnit.start();
	});
});