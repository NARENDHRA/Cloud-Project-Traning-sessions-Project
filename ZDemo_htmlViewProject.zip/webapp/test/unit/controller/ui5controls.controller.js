/*global QUnit*/

sap.ui.define([
	"htmltypeview/ZDemo_htmlViewProject/controller/ui5controls.controller"
], function (Controller) {
	"use strict";

	QUnit.module("ui5controls Controller");

	QUnit.test("I should test the ui5controls controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});