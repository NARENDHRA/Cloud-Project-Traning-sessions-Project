sap.ui.define([
	"htmltypeview/ZDemo_htmlViewProject/test/unit/controller/ui5controls.controller"
], function () {
	"use strict";
});