sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("htmltypeview.ZDemo_htmlViewProject.controller.ui5controls", {
		onInit: function () {

		}
	});
});