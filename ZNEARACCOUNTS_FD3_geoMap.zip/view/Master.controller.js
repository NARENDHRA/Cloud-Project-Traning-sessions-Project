//**************************************************************************//
//	CR1	-	Three New filters added - MIF, UCC & HPP Accounts
//**************************************************************************//
// jQuery.sap.registerModulePath("zNearAccnts.icons");
jQuery.sap.require("sap.m.MessageToast");
jQuery.sap.require("sap.ui.core.mvc.Controller");
jQuery.sap.require("zNearAccnts.util.messages");
sap.ui.core.mvc.Controller.extend("zNearAccnts.view.Master", {
	_oResourceBundle: null,

	onInit: function() {
		this.setLegendModel();
		var that = this;
		this.initLoc(that);
		// this.createMap();
	/*	
		jQuery.ajax({
			type: 'POST',
			url: "https://www.googleapis.com/geolocation/v1/geolocate?key=AIzaSyDaVXuAKP1CvNOKBBdXMu7IbyKDcQg0vfk",
			cache: false,
			dataType: "application/json",
			async: true,
			error: function(response) {
				// that.initialize();
				// that.wait(5000);
				var data = JSON.parse(response.responseText);
				that.myPosition = data.location;
				if (window.localStorage.getItem("filter") || window.localStorage.getItem("range")) {
					that.getView().byId("idSlider").setValue(Number(window.localStorage.getItem("range")));
					if (window.localStorage.getItem("filter") !== null) {
						that.resetFilterStatus();
						that.setFilter(window.localStorage.getItem("filter"));
						that.handleSpots(Number(window.localStorage.getItem("range")), window.localStorage.getItem("filter"));
					} else
						that.handleSpots(Number(window.localStorage.getItem("range")), null);
					window.localStorage.removeItem("filter");
					window.localStorage.removeItem("range");
				} else
					that.handleSpots(10, null);
				that.setMyLocation();
				// that.getView().byId("GeoMap").setZoomlevel(7);
			}
			
		});
	*/ // trying to get current location by device geo position	
		that.initialize();
	},
	
	initLoc:function (that) {
             // Try HTML5 geolocation.
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(function(position) {
            var pos = {
              lat: position.coords.latitude,
              lng: position.coords.longitude
            };
			// console.log("Found current location - Suji");
			console.log(pos);
            that.myPosition = pos;
            if(window.localStorage.getItem("filter") || window.localStorage.getItem("range")){
					that.getView().byId("idSlider").setValue(Number(window.localStorage.getItem("range")));
					if(window.localStorage.getItem("filter") !== null){
						that.resetFilterStatus();
						that.setFilter(window.localStorage.getItem("filter"));
						that.handleSpots(Number(window.localStorage.getItem("range")), window.localStorage.getItem("filter"));
					} else 
						that.handleSpots(Number(window.localStorage.getItem("range")), null);
					window.localStorage.removeItem("filter");
					window.localStorage.removeItem("range");
				} else
					that.handleSpots(10, null);
				that.setMyLocation();
          }
           
          , function() {
          console.log("Error occured while finding current location - Suji")
          that.initLocAlt(that);
          });
        } 
        else {
          // Browser doesn't support Geolocation
         console.log("Browser does not support finding current location")
         that.initLocAlt(that);
        }
      },
    initLocAlt: function(that){
    	jQuery.ajax({
			type: 'POST',
			url: "https://www.googleapis.com/geolocation/v1/geolocate?key=AIzaSyDaVXuAKP1CvNOKBBdXMu7IbyKDcQg0vfk",
			cache: false,
			dataType: "application/json",
			async: true,
			error: function(response) {
				// that.initialize();
				// that.wait(5000);
				var data = JSON.parse(response.responseText);
				that.myPosition = data.location;
				if (window.localStorage.getItem("filter") || window.localStorage.getItem("range")) {
					that.getView().byId("idSlider").setValue(Number(window.localStorage.getItem("range")));
					if (window.localStorage.getItem("filter") !== null) {
						that.resetFilterStatus();
						that.setFilter(window.localStorage.getItem("filter"));
						that.handleSpots(Number(window.localStorage.getItem("range")), window.localStorage.getItem("filter"));
					} else
						that.handleSpots(Number(window.localStorage.getItem("range")), null);
					window.localStorage.removeItem("filter");
					window.localStorage.removeItem("range");
				} else
					that.handleSpots(10, null);
				that.setMyLocation();
				// that.getView().byId("GeoMap").setZoomlevel(7);
			}
			
		});
    },
	
	setLegendModel: function(){
		var Data = {  
			"Legend": 
				[
					{
						// "text": "Your Position",
						"text": "HPP",
						"color": "rgb(100,149,237)"	// Sky Blue Color
					},
					{
						// "text": "Ship-To",
						"text": "Customers",
						"color": "rgb(248, 196, 113)"  //"rgb(204,204,0)"	//	Dark Yellow Color
					},
					{
						// "text": "Sold-To",
						"text": "UCC",
						"color": "rgb(178,34,34)"	// Fire Brick Red Color
					},
					{
						"text": "Prospects",		// Black Color
						"color": "rgb(86, 101, 115)"  //"rgb(0,0,0)"
					},
					{
						"text": "Open-Opportunities",
						"color": "rgb(30, 132, 73)"	// Green Yellow Color
					}
				]
		};
		
		var oModel = new sap.ui.model.json.JSONModel();
		oModel.setData(Data);
		this.getView().byId("GeoMap").setModel(oModel, "legend");
	},
	// wait: function(ms){
	//   var start = new Date().getTime();
	//   var end = start;
	//   while(end < start + ms) {
	//      end = new Date().getTime();
	// 	}
	// },

	setFilter: function(sFilter) {
		if (this.getView().getModel("i18n").getProperty("ALL") === sFilter)
			this.getView().getModel('viewModel').setProperty("/allAccountsFilterEnable", false);
		else if (this.getView().getModel("i18n").getProperty("SOLD_TO") === sFilter)
			this.getView().getModel('viewModel').setProperty("/soldToFilterEnable", false);
		else if (this.getView().getModel("i18n").getProperty("PROSPECT") === sFilter)
			this.getView().getModel('viewModel').setProperty("/prospectFilterEnable", false);
		else if (this.getView().getModel("i18n").getProperty("SHIP_TO") === sFilter)
			this.getView().getModel('viewModel').setProperty("/shipToFilterEnable", false);
		// Added new filters	-	CR1
		else if (this.getView().getModel("i18n").getProperty("MIF") === sFilter)
			this.getView().getModel('viewModel').setProperty("/mifFilterEnable", false);
		else if (this.getView().getModel("i18n").getProperty("UCC") === sFilter)
			this.getView().getModel('viewModel').setProperty("/uccFilterEnable", false);
		else if (this.getView().getModel("i18n").getProperty("HPP") === sFilter)
			this.getView().getModel('viewModel').setProperty("/hppFilterEnable", false);
	},
	getFilter: function() { // function by Suji
		if (!this.getView().getModel('viewModel').getProperty("/allAccountsFilterEnable"))
			return this.getView().getModel("i18n").getProperty("ALL");
		else if (!this.getView().getModel('viewModel').getProperty("/soldToFilterEnable"))
			return this.getView().getModel("i18n").getProperty("SOLD_TO");
		else if (!this.getView().getModel('viewModel').getProperty("/shipToFilterEnable"))
			return this.getView().getModel("i18n").getProperty("SHIP_TO");
		else if (!this.getView().getModel('viewModel').getProperty("/prospectFilterEnable"))
			return this.getView().getModel("i18n").getProperty("PROSPECT");
		else if (!this.getView().getModel('viewModel').getProperty("/mifFilterEnable"))
			return this.getView().getModel("i18n").getProperty("MIF");
		else if (!this.getView().getModel('viewModel').getProperty("/uccFilterEnable"))
			return this.getView().getModel("i18n").getProperty("UCC");
		else if (!this.getView().getModel('viewModel').getProperty("/hppFilterEnable"))
			return this.getView().getModel("i18n").getProperty("HPP");
	},

	initialize: function() {
		// this._oView = this.getView();
		// this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this._oView));
		// this._oResourceBundle = this._oComponent.getModel("i18n").getResourceBundle();
		// this._oRouter = this._oComponent.getRouter();

		var oViewModel = new sap.ui.model.json.JSONModel();
		var data = {
			prospectFilterEnable: true,
			soldToFilterEnable: true,
			shipToFilterEnable: true,
			allAccountsFilterEnable: false,
			mifFilterEnable: true,
			uccFilterEnable: true,
			hppFilterEnable: true
		};
		oViewModel.setData(data);
		this.getView().setModel(oViewModel, "viewModel");

		// Get List of accounts
		this.getAccounts();

		this.createMap();
	},

	getAccounts: function() {
		var that = this;
		var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZAM_ACCOUNT_GOOGLE_MAP_SRV/");
		this.getView().setModel(oModel);
		var params = {
			context: null,
			urlParameters: null,
			async: false,
			// filters: filters,
			sorters: null,
			success: function(oData, response) {
				that.oData = oData;
			}
		};
		oModel.read("/AccountGoogleMapSet", params);
	},

	createMap: function() {
		var oGeoMap = this.getView().byId("GeoMap");
		// var oMapConfig = {
		// 	"MapProvider": [{
		// 		"name": "HEREMAPS",
		// 		"type": "",
		// 		"description": "",
		// 		"tileX": "256",
		// 		"tileY": "256",
		// 		"maxLOD": "20",
		// 		"copyright": "Konica Minolta Business Solutions",
		// 		"Source": [{
		// 			"id": "s1",
		// 			"url": "https://1.base.maps.cit.api.here.com/maptile/2.1/maptile/newest/reduced.day/{LOD}/{X}/{Y}/256/png?app_id=Ox6HxB1sO8VtLSJkOfNY&app_code=7mQfXz05-XtjRXdCuxkApA"
		// 		}, {
		// 			"id": "s2",
		// 			"url": "https://2.base.maps.cit.api.here.com/maptile/2.1/maptile/newest/reduced.day/{LOD}/{X}/{Y}/256/png?app_id=Ox6HxB1sO8VtLSJkOfNY&app_code=7mQfXz05-XtjRXdCuxkApA"
		// 		}]
		// 	}],
		// 	"MapLayerStacks": [{
		// 		"name": "Default",
		// 		"MapLayer": {
		// 			"name": "layer1",
		// 			"refMapProvider": "HEREMAPS",
		// 			"opacity": "1.0",
		// 			"colBkgnd": "RGB(255,255,255)"
		// 		}
		// 	}]
		// };

		var oMapConfig = {
			"MapProvider": [{
				"name": "GMAP",
				"Source": [{
					"id": "s1",
					"url": "https://mt.google.com/vt/x={X}&y={Y}&z={LOD}"
				}]
			}],
			"MapLayerStacks": [{
				"name": "DEFAULT",
				"MapLayer": {
					"name": "layer1",
					"refMapProvider": "GMAP",
					"opacity": "1",
					"colBkgnd": "RGB(255,255,255)"
				}
			}]
		};

		oGeoMap.setMapConfiguration(oMapConfig);
		oGeoMap.setRefMapLayerStack("DEFAULT");
	},

	setMyLocation: function() {
		var oGeoMap = this.getView().byId("GeoMap");
		var position = this.myPosition.lng + ";" + this.myPosition.lat + ";0";
		oGeoMap.setCenterPosition(position);
		oGeoMap.addVo(new sap.ui.vbm.Spots({
			items: [
				new sap.ui.vbm.Spot({
					position: position,
					type: "Default",
					tooltip: "You are here!",
					labelPos: position,
					labelType: "Success",
					labelText: "You are here!"
				})
			]
		}));
	},

	handleSpots: function(val, sFilter) {
		var oGeoMap = this.getView().byId("GeoMap");
		var that = this;
		that.acCOUNTs = 0;
		var rangeInKms = this.convertMilesToKms(val);
		if (this.oData && this.oData.results) {
			//////////////////////////////////////// Filter Accounts on roles
			if (sFilter === this.getView().getModel("i18n").getProperty("PROSPECT")) { // Prospects Filter Processing
				$.each(this.oData.results, function(i, position) {
					//////////////////////////////////////// Filter Accounts in Range
					// The target longitude and latitude
					var targetlong = position.ZzLongitude;
					var targetlat = position.ZzLatitude;
					var distance = that.getDistanceFromLatLonInKm(that.myPosition.lat, that.myPosition.lng, targetlat, targetlong);
					// Is it in the right distance?
					if (distance <= rangeInKms) { // if account falls in radius selected by user
						position.pos = position.ZzLongitude + ";" + position.ZzLatitude + ";0";
						if (position.Rltype === "BUP002") { // Prospect
							that.acCOUNTs = that.acCOUNTs + 1;
							if (position.OpenOpportunity !== "" && position.OpenOpportunity !== null && position.OpenOpportunity !== undefined)
								position.type = "Success";
							else
								position.type = "Inactive";
						} else
							position.type = "Hidden";
					} else // Do something here cause they reached their destination
						position.type = "Hidden";
				});
			} else if (sFilter === this.getView().getModel("i18n").getProperty("SOLD_TO")) { // Sold To Filter Processing
				$.each(this.oData.results, function(i, position) {
					//////////////////////////////////////// Filter Accounts in Range
					// The target longitude and latitude
					var targetlong = position.ZzLongitude;
					var targetlat = position.ZzLatitude;
					var distance = that.getDistanceFromLatLonInKm(that.myPosition.lat, that.myPosition.lng, targetlat, targetlong);
					// Is it in the right distance?
					if (distance <= rangeInKms) { // if account falls in radius selected by user
						position.pos = position.ZzLongitude + ";" + position.ZzLatitude + ";0";
						if (position.Rltype === "CRM000") { // Sold To
							that.acCOUNTs = that.acCOUNTs + 1;
							if (position.OpenOpportunity !== "" && position.OpenOpportunity !== null && position.OpenOpportunity !== undefined) {
								position.type = "Success";
								// position.image = "icons/red.png";
								// position.image = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACQAAAAvCAYAAACLx2hbAAAACXBIWXMAABYlAAAWJQFJUiTwAAAAB3RJTUUH4goaCxwlQ2rZiAAAAAd0RVh0QXV0aG9yAKmuzEgAAAAMdEVYdERlc2NyaXB0aW9uABMJISMAAAAKdEVYdENvcHlyaWdodACsD8w6AAAADnRFWHRDcmVhdGlvbiB0aW1lADX3DwkAAAAJdEVYdFNvZnR3YXJlAF1w/zoAAAALdEVYdERpc2NsYWltZXIAt8C0jwAAAAh0RVh0V2FybmluZwDAG+aHAAAAB3RFWHRTb3VyY2UA9f+D6wAAAAh0RVh0Q29tbWVudAD2zJa/AAAABnRFWHRUaXRsZQCo7tInAAAHJklEQVRYhe2YW2xU1RrHf2t6mem0lA6UOk4p01IH2x4ePKeYYCweIYEXI9hGIygPJUYNKZoSL7EISSGKkoBUBG0UE02JlBjq7YVY00na8fAgPWiVSijQ65Rpi522zGVP57LOA+xNLzOdtpgcHvgn62Xttdf+7e/b32Vt4ff7JXeRdP9vgKm6BxRPdx1Q4nxvFELMeF3K+cXKnIAmQsQDUjVXsFkDCSFuQkQi+C5e5Po33zB85gyetjYiinJzM5OJ9IcfJmvzZhY/+SQJ6elzBhPx8pBqCSElow4HXXv3MupwxN1YZzBgffttsnfsQGc0IqWcFdSMQCqM9Hjo2rsXZ20tMhhkYUkJ95eXk7FuHclmMyLxpqEjPh/+K1cYrK+n//hxQm43qUVFPHj8OGnFxbOD8vv9MtpQFEUqiiK9fX3y/MaNshGkIz9fur7/Xo4rigwEAjIQCGjr1KHOe3p75YWXXpKNIO0mk+w/fVoGbq2J9Uy/3y9jWkgIQcTr5UplJa66OjI3bsT20Uckmc2zM70QCCkZOHGCSzt2oEtJoejkSTLWrp3RUlHzkBACAVyrrcVVV0fGY49FhVE/9IlDlZSSCJC1dSsrjh4l7PHQs38/QZdrxheJmRh9Fy7gPHYMo83GA0eOTIIRQhAaGqLnvfc4t3IlzXo9/zGbubh1K77ffmNiQpDAkmef5f7yckaamxk4cQJB7LQxDUgIAeEwA3V1BPr7ya6owFhQMAlm7OefOV9SQld1Nb6ODgBCbjeDX3/Nf0tK6KupgXD49p7JyWS/8goGq5WhhgaCAwNzs1BwaAi33c6C4mIyS0uZ6G3fn39y6eWXb8Ju387qq1f5dyDAmtFR/nHqFHqLhc49exj86ivNUlJKDPn5LCkt5UZrK6Nnz05z8YxA/suX8ba3k756NYmZmdq8HB/HWVODr6MD24cf8sDhwyRnZxOREmEwsPipp1j53Xek5ObS/c47+C9dum2lxEQWPv44AKMtLchQKL6FVGp/RwcyGCTtoYe0HAOgdHQw/OOPmNauZUlZGVIILWLUYSwoILuiAqW7G3dj4+1cJiVGm42U5csJ9PYS8fvjA2kPvnoVAENe3iRYpbeXQH8/GevWkWAyTQpfLfqEIG3VKhIWLMDb3o4cH9f2SDSZSMrMZNzlIhIIzB4oloKDgwAkm81Rr6tQienpJC1aRMTni+maWIoKlGKzAeBta5s0n5SVBYDS2Rl1M9U9obExgsPD6IxGzeVCCAJ9fShdXaTk55NgNMYHUl2woLgYvcXCXz/8QNjt1h5kyMlBb7EwdvasNq8VXzVipGSkqYnwjRukFhUhkpO1+eEzZxgfHCT9kUfQzQZIlcFmY9GGDYw4HLjt9mnzbrsd59GjEA5Py9Te33/n2uefY7BaMa1fr8EqXV0M1tdjtNkwbdgQs3xEBdLp9Zi3bUNnMND/8cdaItPp9WRXVmK02eg+cIArr73GuNOJTgikovDXt99y4emnCfT3Y929m5QVKzTrXD99Gm97O4ufeAJ9Tk5U6wDRq72iKNI/Nib/KC+XjSC7ampkYEIlH2pqki1Wq2yEaeOnpCR55f33peL1autH2tpki9Uqmy0W6W5tnbHix4wynV6P+YUXSDSZcB47hv9WiZBSkv7oo/zT4SC3uhrjrQBINJnIeuYZ/uVwsLSyEhISbrolFOLaZ5+hdHdjLi8npaAgtnWYoUFTa1r3vn30HDiA5cUXWX7o0O2PlOgFcmo34G5spH3LFlLy81nZ0ECSxTJj+xLTQlJKSEjAvG0bqUVFXPviC0aamqa1GFPHRIWGhug7dIiIorD01VdJzs6OCRIXSJUhL4+c118HoKu6mnGnc0YgrSsAXF9+idtuZ0lZGYs3bZpVCzsjkLpBZmkp9z33HJ5ff6Xv8OFJrcVUqeF/45df6Dl4EIPVyrK33iIhLS3eu8cH0hYZjSzduROjzYaztlYrmrGarLDbTfe+fYTcbnJ27sRYWDjrU0dcIK2KFxayrKoKgM5du1A6O6dBqYHg/OQThhsbydy0iaznn0cy+3PZrCw01XXe9nZ63n2XiNergahjtKWFviNHMFit5FZXTzos/m1A2mKjkWVVVaQWFTFQX8/1hgatKxRCEHS56Nm/n7DHQ+6ePXNy1ZyB1I0NeXnkf/ABCWlpXH7jDTznzqHT6SAcpvfgQUaam7lv82Yyy8rm5Ko5A02EWrhmDUsrKgi53VzdtYugy8VgfT3O2lqMNhs5b76JLjV1TiCq4p7to94kBNLn49L27QyeOsWC4mKC168THB6m6ORJTOvXz9lVqub9f0iXmsqyqio8589zo7UVgNzdu+OeTONpXhaC25E1YrfTvmUL6atWUVhXhy4jY94wdwSkQQH9n35Kxpo1pBQWAvP/e3bHQCrURN0JDNzBN/R3AUzVXfcX9h5QPN0Diqf/Ab2xIwqoeDglAAAAAElFTkSuQmCC";
								// position.color = "red";
							} else
								// position.type = "Error";
								position.type = "Warning";
						} else
							position.type = "Hidden";
					} else // Do something here cause they reached their destination
						position.type = "Hidden";
				});
			} else if (sFilter === this.getView().getModel("i18n").getProperty("SHIP_TO")) { // Ship To Filter Processing
				$.each(this.oData.results, function(i, position) {
					//////////////////////////////////////// Filter Accounts in Range
					// The target longitude and latitude
					var targetlong = position.ZzLongitude;
					var targetlat = position.ZzLatitude;
					var distance = that.getDistanceFromLatLonInKm(that.myPosition.lat, that.myPosition.lng, targetlat, targetlong);
					// Is it in the right distance?
					if (distance <= rangeInKms) { // if account falls in radius selected by user
						position.pos = position.ZzLongitude + ";" + position.ZzLatitude + ";0";
						if (position.Rltype === "CRM002") { // Ship 
							that.acCOUNTs = that.acCOUNTs + 1;
							if (position.OpenOpportunity !== "" && position.OpenOpportunity !== null && position.OpenOpportunity !== undefined)
								position.type = "Success";
							else
								position.type = "Warning";
						} else
							position.type = "Hidden";
					} else // Do something here cause they reached their destination
						position.type = "Hidden";
				});
			}
			// Added new filters - CR1
			else if (sFilter === this.getView().getModel("i18n").getProperty("MIF")) { // MIF Accounts Filter Processing
				$.each(this.oData.results, function(i, position) {
					//////////////////////////////////////// Filter Accounts in Range
					// The target longitude and latitude
					var targetlong = position.ZzLongitude;
					var targetlat = position.ZzLatitude;
					var distance = that.getDistanceFromLatLonInKm(that.myPosition.lat, that.myPosition.lng, targetlat, targetlong);
					// Is it in the right distance?
					if (distance <= rangeInKms) { // if account falls in radius selected by user
						position.pos = position.ZzLongitude + ";" + position.ZzLatitude + ";0";
						if (position.MIFAccount === "X") { // MIF Accounts
							that.acCOUNTs = that.acCOUNTs + 1;
							if (position.OpenOpportunity !== "" && position.OpenOpportunity !== null && position.OpenOpportunity !== undefined)
								position.type = "Success";
							else if (position.Rltype === "BUP002") // Prospect
								position.type = "Inactive";
							else if (position.Rltype === "CRM000") // Sold to
								position.type = "Error";
							else if (position.Rltype === "CRM002") // Ship to
								position.type = "Warning";
							//	position.type = "Warning";
						} else
							position.type = "Hidden";
					} else // Do something here cause they reached their destination
						position.type = "Hidden";
				});
			} else if (sFilter === this.getView().getModel("i18n").getProperty("UCC")) { // UCC Accounts Filter Processing
				$.each(this.oData.results, function(i, position) {
					//////////////////////////////////////// Filter Accounts in Range
					// The target longitude and latitude
					var targetlong = position.ZzLongitude;
					var targetlat = position.ZzLatitude;
					var distance = that.getDistanceFromLatLonInKm(that.myPosition.lat, that.myPosition.lng, targetlat, targetlong);
					// Is it in the right distance?
					if (distance <= rangeInKms) { // if account falls in radius selected by user
						position.pos = position.ZzLongitude + ";" + position.ZzLatitude + ";0";
						if (position.UCCAccount === "X") { // UCC Accounts
							that.acCOUNTs = that.acCOUNTs + 1;
							if (position.OpenOpportunity !== "" && position.OpenOpportunity !== null && position.OpenOpportunity !== undefined)
								position.type = "Success";
							// else if (position.Rltype === "BUP002") // Prospect
							// 	position.type = "Inactive";
							// else if (position.Rltype === "CRM000") // Sold to
							// 	position.type = "Error";
							// else if (position.Rltype === "CRM002") // Ship to
							// 	position.type = "Warning";
							else
								position.type = "Error";
						} else
							position.type = "Hidden";
					} else // Do something here cause they reached their destination
						position.type = "Hidden";
				});
			} else if (sFilter === this.getView().getModel("i18n").getProperty("HPP")) { // HPP Accounts Filter Processing
				$.each(this.oData.results, function(i, position) {
					//////////////////////////////////////// Filter Accounts in Range
					// The target longitude and latitude
					var targetlong = position.ZzLongitude;
					var targetlat = position.ZzLatitude;
					var distance = that.getDistanceFromLatLonInKm(that.myPosition.lat, that.myPosition.lng, targetlat, targetlong);
					// Is it in the right distance?
					if (distance <= rangeInKms) { // if account falls in radius selected by user
						position.pos = position.ZzLongitude + ";" + position.ZzLatitude + ";0";
						if (position.HPPAccount === "X") { // HPP Accounts 
							that.acCOUNTs = that.acCOUNTs + 1;
							if (position.OpenOpportunity !== "" && position.OpenOpportunity !== null && position.OpenOpportunity !== undefined)
								position.type = "Success";
							// else if (position.Rltype === "BUP002") // Prospect
							// 	position.type = "Inactive";
							// else if (position.Rltype === "CRM000") // Sold to
							// 	position.type = "Error";
							// else if (position.Rltype === "CRM002") // Ship to
							// 	position.type = "Warning";
							else
								position.type = "Inactive";
						} else
							position.type = "Hidden";
					} else // Do something here cause they reached their destination
						position.type = "Hidden";
				});
			} else { // All Accounts without filter
				$.each(this.oData.results, function(i, position) {
					//////////////////////////////////////// Filter Accounts in Range
					// The target longitude and latitude
					var targetlong = position.ZzLongitude;
					var targetlat = position.ZzLatitude;
					var distance = that.getDistanceFromLatLonInKm(that.myPosition.lat, that.myPosition.lng, targetlat, targetlong);
					// Is it in the right distance?
					if (distance <= rangeInKms) { // if account falls in radius selected by user
						that.acCOUNTs = that.acCOUNTs + 1;
						position.pos = position.ZzLongitude + ";" + position.ZzLatitude + ";0";
						if (position.OpenOpportunity !== "" && position.OpenOpportunity !== null && position.OpenOpportunity !== undefined)
							position.type = "Success";
						else {
							if (position.Rltype === "BUP002") // Prospect
								position.type = "Inactive";
							else if (position.Rltype === "CRM000") // Sold to
								// position.type = "Error";
								position.type = "Warning";
							else if (position.Rltype === "CRM002") // Ship to
								position.type = "Warning";
							// start of changes for CR-1
							/* commneting below code, because color legend by role only - Suji 
							else if (position.MIFAccount === "X") // MIF
								position.type = "Warning";
							else if (position.UCCAccount === "X") // UCC
								position.type = "Error";
							else if (position.HPPAccount === "X") // HPP
								position.type = "Inactive";
							*/
							// end of changes for CR-1
						}
					} else // Do something here cause they reached their destination
						position.type = "Hidden";
				});
			}
			if (!oGeoMap.getModel('spot')) {
				var oModel = new sap.ui.model.json.JSONModel('spot');
				oGeoMap.setModel(oModel, 'spot');
			} else {
				var oModel = oGeoMap.getModel('spot');
			}
			oModel.setSizeLimit(this.oData.results.length);
			oModel.setData(this.oData);

			oModel.updateBindings();
			this.setZoomLevel(val);
			
			this.setPageTitle(this.sFilterSelected, this.acCOUNTs);
			this.noAccountsMessage();
		}
	},

	setZoomLevel: function(val) {
		var oGeoMap = this.getView().byId("GeoMap");
		if (val >= 70)
			oGeoMap.setZoomlevel(8);
		else if (val >= 50)
			oGeoMap.setZoomlevel(10);
		else if (val >= 30)
			oGeoMap.setZoomlevel(12);
		else
			oGeoMap.setZoomlevel(14);
	},

	noAccountsMessage: function() {
		// Alert if no accounts found in range
		if (this.acCOUNTs === 0)
			sap.m.MessageToast.show("No Accounts found within selected range!");
	},

	getDistanceFromLatLonInKm: function(lat1, lon1, lat2, lon2) {
		var R = 6371; // Radius of the earth in km
		var dLat = this.deg2rad(lat2 - lat1); // deg2rad below
		var dLon = this.deg2rad(lon2 - lon1);
		var a =
			Math.sin(dLat / 2) * Math.sin(dLat / 2) +
			Math.cos(this.deg2rad(lat1)) * Math.cos(this.deg2rad(lat2)) *
			Math.sin(dLon / 2) * Math.sin(dLon / 2);
		var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
		var d = R * c; // Distance in km
		// d = d * 1000; // Distance in meters
		return d;
	},

	deg2rad: function(deg) {
		return deg * (Math.PI / 180);
	},

	setPageTitle: function(sFilter, count) {
		if (this.getView().getModel("i18n"))
			if (sFilter === this.getView().getModel("i18n").getProperty("PROSPECT"))
				this.getView().byId("page1").setTitle(this.getView().getModel("i18n").getProperty("title") + " - " + this.getView().getModel("i18n")
					.getProperty("PROSPECT") + " (" + count + ")");
			else if (sFilter === this.getView().getModel("i18n").getProperty("SOLD_TO"))
			this.getView().byId("page1").setTitle(this.getView().getModel("i18n").getProperty("title") + " - " + this.getView().getModel("i18n").getProperty(
				"SOLD_TO") + " (" + count + ")");
		else if (sFilter === this.getView().getModel("i18n").getProperty("SHIP_TO"))
			this.getView().byId("page1").setTitle(this.getView().getModel("i18n").getProperty("title") + " - " + this.getView().getModel("i18n").getProperty(
				"SHIP_TO") + " (" + count + ")");
		// Added new filters - CR1
		else if (sFilter === this.getView().getModel("i18n").getProperty("MIF"))
			this.getView().byId("page1").setTitle(this.getView().getModel("i18n").getProperty("title") + " - " + this.getView().getModel("i18n").getProperty(
				"MIF") + " (" + count + ")");
		else if (sFilter === this.getView().getModel("i18n").getProperty("UCC"))
			this.getView().byId("page1").setTitle(this.getView().getModel("i18n").getProperty("title") + " - " + this.getView().getModel("i18n").getProperty(
				"UCC") + " (" + count + ")");
		else if (sFilter === this.getView().getModel("i18n").getProperty("HPP"))
			this.getView().byId("page1").setTitle(this.getView().getModel("i18n").getProperty("title") + " - " + this.getView().getModel("i18n").getProperty(
				"HPP") + " (" + count + ")");
		else
			this.getView().byId("page1").setTitle(this.getView().getModel("i18n").getProperty("title") + " (" + count + ")");
		else
			this.getView().byId("page1").setTitle("Accounts Near Me (" + count + ")");
	},

	handleFilterPopOver: function(evt) {
		if (!this.actionSheet) {
			this.actionSheet = new sap.m.ActionSheet({
				placement: sap.m.PlacementType.Top,
				buttons: [new sap.m.Button({
						text: this.getView().getModel("i18n").getProperty("ALL"),
						press: [function(event) {
							this.sFilterSelected = this.getView().getModel("i18n").getProperty("ALL");
							this.resetFilterStatus();
							this.getView().getModel('viewModel').setProperty("/allAccountsFilterEnable", false);
							this.handleFilter(event);
						}, this],
						enabled: "{viewModel>/allAccountsFilterEnable}"
					}),
					new sap.m.Button({
						text: this.getView().getModel("i18n").getProperty("SOLD_TO"),
						press: [function(event) {
							this.sFilterSelected = this.getView().getModel("i18n").getProperty("SOLD_TO");
							this.resetFilterStatus();
							this.getView().getModel('viewModel').setProperty("/soldToFilterEnable", false);
							this.handleFilter(event);
						}, this],
						enabled: "{viewModel>/soldToFilterEnable}"
					}),
					new sap.m.Button({
						text: this.getView().getModel("i18n").getProperty("PROSPECT"),
						press: [function(event) {
							this.sFilterSelected = this.getView().getModel("i18n").getProperty("PROSPECT");
							this.resetFilterStatus();
							this.getView().getModel('viewModel').setProperty("/prospectFilterEnable", false);
							this.handleFilter(event);
						}, this],
						enabled: "{viewModel>/prospectFilterEnable}"
					}),
					new sap.m.Button({
						text: this.getView().getModel("i18n").getProperty("SHIP_TO"),
						press: [function(event) {
							this.sFilterSelected = this.getView().getModel("i18n").getProperty("SHIP_TO");
							this.resetFilterStatus();
							this.getView().getModel('viewModel').setProperty("/shipToFilterEnable", false);
							this.handleFilter(event);
						}, this],
						enabled: "{viewModel>/shipToFilterEnable}"
					}),
					// Added new filters - CR1
					new sap.m.Button({
						text: this.getView().getModel("i18n").getProperty("MIF"),
						press: [function(event) {
							this.sFilterSelected = this.getView().getModel("i18n").getProperty("MIF");
							this.resetFilterStatus();
							this.getView().getModel('viewModel').setProperty("/mifFilterEnable", false);
							this.handleFilter(event);
						}, this],
						enabled: "{viewModel>/mifFilterEnable}"
					}),
					new sap.m.Button({
						text: this.getView().getModel("i18n").getProperty("UCC"),
						press: [function(event) {
							this.sFilterSelected = this.getView().getModel("i18n").getProperty("UCC");
							this.resetFilterStatus();
							this.getView().getModel('viewModel').setProperty("/uccFilterEnable", false);
							this.handleFilter(event);
						}, this],
						enabled: "{viewModel>/uccFilterEnable}"
					}),
					new sap.m.Button({
						text: this.getView().getModel("i18n").getProperty("HPP"),
						press: [function(event) {
							this.sFilterSelected = this.getView().getModel("i18n").getProperty("HPP");
							this.resetFilterStatus();
							this.getView().getModel('viewModel').setProperty("/hppFilterEnable", false);
							this.handleFilter(event);
						}, this],
						enabled: "{viewModel>/hppFilterEnable}"
					})
				]
			});
			this.getView().byId("page1").addDependent(this.actionSheet);
			this.actionSheet.setModel(this.getView().getModel('viewModel'), 'viewModel');
		}
		this.actionSheet.openBy(evt.getSource());
	},

	resetFilterStatus: function() {
		this.getView().getModel('viewModel').setProperty("/allAccountsFilterEnable", true);
		this.getView().getModel('viewModel').setProperty("/soldToFilterEnable", true);
		this.getView().getModel('viewModel').setProperty("/prospectFilterEnable", true);
		this.getView().getModel('viewModel').setProperty("/shipToFilterEnable", true);
		// Added new filters - CR1
		this.getView().getModel('viewModel').setProperty("/mifFilterEnable", true);
		this.getView().getModel('viewModel').setProperty("/uccFilterEnable", true);
		this.getView().getModel('viewModel').setProperty("/hppFilterEnable", true);
	},

	handleFilter: function(evt) {
		// var filters = this.getFilters(evt.getSource());
		// if (filters.length === 0)
		// 	filters = null;
		// this.getAccounts(filters);
		var sFilter = evt.getSource().getText();
		this.setFilter(sFilter); // Updaing the viewModel - Suji
		this.sFilter = sFilter;
		this.getMilesRange(sFilter);
		// this.updateMap(1.60934);
	},

	// getFilters: function(oSource) {
	// 	var aFilters = [];
	// 	var sFilter = oSource.getText();

	// 	if (sFilter === this.getView().getModel("i18n").getProperty("PROSPECT")) {
	// 		aFilters.push(new sap.ui.model.Filter("Rltype", sap.ui.model.FilterOperator.EQ, "BUP002"));
	// 	} else if (sFilter === this.getView().getModel("i18n").getProperty("SOLD_TO")) {
	// 		aFilters.push(new sap.ui.model.Filter("Rltype", sap.ui.model.FilterOperator.EQ, "CRM000"));
	// 	} else if (sFilter === this.getView().getModel("i18n").getProperty("SHIP_TO")) {
	// 		aFilters.push(new sap.ui.model.Filter("Rltype", sap.ui.model.FilterOperator.EQ, "CRM002"));
	// 	}
	// 	return aFilters;
	// },

	updateMap: function(val, sFilter) {
		this.handleSpots(val, sFilter);
	},

	navToAccount: function(oEvent) {
		var AccountId = oEvent.getSource().getTooltip().split('/');
		if (AccountId[0] !== "" && AccountId[0] !== null) {
			var uri = "https://" + window.location.host + "/fiori/launchpad#ZAccounts-display&/detail/AccountCollection('" + AccountId[0] + "')";
			window.open(uri, "_self", null, false);
			if (this.sFilter)
				window.localStorage.setItem("filter", this.sFilter);
			window.localStorage.setItem("range", this.getView().byId("idSlider").getValue());
		} else
			sap.m.MessageToast.show("Invalid or No Account Available");
	},

	getMilesRange: function(sFilter) {
		var val = this.getView().byId("idSlider").getValue();
		//If slider event fires then existing sFilter value is not coming in. So adding code to retrieve. 
		var filter = this.getFilter();
		//this.updateMap(val, sFilter);
		this.updateMap(val, filter);
	},

	convertMilesToKms: function(miles) {
		return miles / 0.62137;
	},

	onNavBack: function() {
		history.go(-1);
	}

});