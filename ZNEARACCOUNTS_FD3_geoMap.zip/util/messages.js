jQuery.sap.declare("zNearAccnts.util.messages");
jQuery.sap.require("sap.ca.ui.message.message");

zNearAccnts.util.messages = {};

/**
 * Show an error dialog with information from the oData response object.
 *
 * @param {object}
 *            oParameter The object containing error information
 * @return {void}
 * @public
 */
 zNearAccnts.util.messages.radiusLabelVisibility = function(s){
	if(sap.ui.Device.system.phone === true) return false;
	else return true;
 };
 
zNearAccnts.util.messages.showErrorMessage = function(oParameter) {
	var oErrorDetails = zNearAccnts.util.messages._parseError(oParameter);
	var oMsgBox = sap.ca.ui.message.showMessageBox({
		type: sap.ca.ui.message.Type.ERROR,
		message: oErrorDetails.sMessage,
		details: oErrorDetails.sDetails
	});
	if (!sap.ui.Device.support.touch) {
		oMsgBox.addStyleClass("sapUiSizeCompact");
	}
};

zNearAccnts.util.messages.getErrorContent = function(oParameter) {
	return zNearAccntsts.util.messages._parseError(oParameter).sMessage;
};

zNearAccnts.util.messages._parseError = function(oParameter) {
	var sMessage = "",
		sDetails = "",
		oEvent = null,
		oResponse = null,
		oError = {};

	if (oParameter.mParameters) {
		oEvent = oParameter;
		sMessage = oEvent.getParameter("message");
		sDetails = oEvent.getParameter("responseText");
	} else {
		oResponse = oParameter;
		sMessage = oResponse.message;
		sDetails = oResponse.response.body;
	}

	if (jQuery.sap.startsWith(sDetails, "{\"error\":")) {
		var oErrModel = new sap.ui.model.json.JSONModel();
		oErrModel.setJSON(sDetails);
		sMessage = oErrModel.getProperty("/error/message/value");
	}

	oError.sDetails = sDetails;
	oError.sMessage = sMessage;
	return oError;
};

zNearAccnts.util.messages.formatMediumDate = function(v) {
	if(v === "" || v === "00000000" || v === null) return null;
	if (v) {
        // return v.replace(/(\d{2})(\d{2})(\d{4})/g, '$1/$2/$3');
        return v.replace(/(\d{4})(\d{2})(\d{2})/g, '$2/$3/$1');
	} else {
		return "";
	}
};