jQuery.sap.declare("ZINFY_API.dashboard.Dashboard");
jQuery.sap.require("sap.ui.core.Component");

sap.ui.core.Component.extend("ZINFY_API.dashboard.Dashboard", {

    initDashboard: function(that, panelParams) {
    	
        _that = that;
        _panelParams = panelParams;
      
        this.openDialog("DashboardDisplayDialog");
        this.initDashboardDisplayDialog();
    },

    // open dialog
    openDialog: function(sName) {

        if (!this[sName]) {
            this[sName] = sap.ui.xmlfragment("ZINFY_API/dashboard/" + sName, this);
            _that.getView().addDependent(this[sName]);
        }
        this[sName].open();
    },

    // close dialog
    onDialogclose: function(oEvent) {
        var sName = "";
        if (typeof oEvent == "object")
            sName = oEvent.getSource().getCustomData()[0].getValue();
        else
            sName = oEvent;
        this[sName].destroy();
        this[sName] = undefined;
    },

    // expand all panels
    _onApiAllPanelsExpand: function() {
        var verLayout = sap.ui.getCore().byId("API_DASHBOARD_DISP_VER_LAY").getContent();
        for (var i = 0; i < verLayout.length; i++) {
            verLayout[i].setExpanded(true);
        }
    },

    // collapse all panels
    _onApiAllPanelsCollapse: function() {
        var verLayout = sap.ui.getCore().byId("API_DASHBOARD_DISP_VER_LAY").getContent();
        for (var i = 0; i < verLayout.length; i++) {
            verLayout[i].setExpanded(false);
        }
    },

    // dashboard panel creation
    initDashboardDisplayDialog: function() {
        var that = this;
        var dashVL = sap.ui.getCore().byId("API_DASHBOARD_DISP_VER_LAY");
        for (var i = 0; i < _panelParams.length; i++) {
            switch (_panelParams[i]) {
                case "DemoClock":
                    if (!that.ar)
                        that.ar = new sap.ui.xmlfragment({
                            fragmentName: "ZINFY_API.dashboard.fragments.DemoClock",
                            type: "XML"
                        }, that);
                    dashVL.addContent(that.ar);
                    that.initDemoClock();
                    break;
                case "DemoChart":
                    if (!that.ac)
                        that.ac = new sap.ui.xmlfragment({
                            fragmentName: "ZINFY_API.dashboard.fragments.DemoChart",
                            type: "XML"
                        }, that);
                    dashVL.addContent(that.ac);
                    that.initDemoChart();
                    break;
                
            }
        }

        // always first panel should be expanded
        var verLayout = sap.ui.getCore().byId("API_DASHBOARD_DISP_VER_LAY").getContent();
        if (verLayout.length) {
            verLayout[0].setExpanded(true);
        }
    },
    
    initDemoChart : function(){
    	var tableData = [{"Ename" : "Mahesh",
    						  "EmpId" : "655851",
    						  "Email":"Mahesh.V@infosys.com",
    						  "Designation":"Technology Lead",
    						   "Address":"Infosys SEZ",
    						   "Location":"Hyderabad"
    						   },{
    						   "Ename" : "Karuna",
     						  "EmpId" : "655852",
     						  "Email":"Karuna.D@infosys.com",
     						  "Designation":"Technology Lead",
     						   "Address":"Infosys STP",
     						   "Location":"Hyderabad"
     						   },{
    						   "Ename" : "Kavya",
      						  "EmpId" : "655853",
      						  "Email":"Kavya.K@infosys.com",
      						  "Designation":"Associate Consultant",
      						   "Address":"Infosys SEZ",
      						   "Location":"Hyderabad"
      						   }];
    	 var tableModel = new sap.ui.model.json.JSONModel({
             "TableCollection": tableData
         });
    	 sap.ui.getCore().byId("API_TABLE_COUNT").setText("(" + tableModel.getData().TableCollection.length + ")");
    	 var oTableTempl = new sap.m.ColumnListItem({
             cells: [
                 new sap.m.Text({
                	 text:"{Ename}"
                 }),
                 new sap.m.Text({
                	 text:"{EmpId}"
                 }),
                 new sap.m.Text({
                	 text:"{Email}"
                 }),
                 new sap.m.Text({
                	 text:"{Designation}"
                 }),
                 new sap.m.Text({
                	 text:"{Address}"
                 }), 
                 new sap.m.Text({
                	 text:"{Location}"
                 })
                 ]
    	 });
    	 
    	var tableId = sap.ui.getCore().byId("API_CHARTRESULTS_DISP_TABLE");
    	tableId.unbindAggregation("items");
    	tableId.setModel(tableModel);
    	tableId.bindAggregation("items", "/TableCollection", oTableTempl);
    },
    
    _handleEmpSearch : function(oEvent){
    	var sValue = oEvent.getSource().getValue();
        var oFilter1 = new sap.ui.model.Filter("Ename", sap.ui.model.FilterOperator.Contains, sValue);
       // var oFilter2 = new sap.ui.model.Filter("ShortText", sap.ui.model.FilterOperator.Contains, sValue);
        var allFilter = new sap.ui.model.Filter([oFilter1], false);
        var oBinding = sap.ui.getCore().byId("API_CHARTRESULTS_DISP_TABLE").getBinding("items");
        oBinding.filter(allFilter);
    },
    
    initDemoClock : function(){
    	
    		var chart = AmCharts.makeChart( "chartdiv", {
    			  "type": "gauge",
    			  "theme": "light",
    			  "startDuration": 0.3,
    			  "marginTop": 150,
    			  "marginBottom": 150,
    			  "axes": [ {
    			    "axisAlpha": 0.3,
    			    "endAngle": 360,
    			    "endValue": 12,
    			    "minorTickInterval": 0.2,
    			    "showFirstLabel": false,
    			    "startAngle": 0,
    			    "axisThickness": 1,
    			    "valueInterval": 1
    			  } ],
    			  "arrows": [ {
    			    "radius": "50%",
    			    "innerRadius": 0,
    			    "clockWiseOnly": true,
    			    "nailRadius": 10,
    			    "nailAlpha": 1
    			  }, {
    			    "nailRadius": 0,
    			    "radius": "80%",
    			    "startWidth": 6,
    			    "innerRadius": 0,
    			    "clockWiseOnly": true
    			  }, {
    			    "color": "#CC0000",
    			    "nailRadius": 4,
    			    "startWidth": 3,
    			    "innerRadius": 0,
    			    "clockWiseOnly": true,
    			    "nailAlpha": 1
    			  } ]
    			} );

    			// update each second
    			setInterval( updateClock, 1000 );

    			// update clock
    			function updateClock() {
    			  if(chart.arrows.length > 0){
    			    // get current date
    			    var date = new Date();
    			    var hours = date.getHours();
    			    var minutes = date.getMinutes();
    			    var seconds = date.getSeconds();
    			  
    			    if(chart.arrows[ 0 ].setValue){
    			      // set hours
    			      chart.arrows[ 0 ].setValue( hours + minutes / 60 );
    			      // set minutes
    			      chart.arrows[ 1 ].setValue( 12 * ( minutes + seconds / 60 ) / 60 );
    			      // set seconds
    			      chart.arrows[ 2 ].setValue( 12 * date.getSeconds() / 60 );
    			      }
    			  }
    			}
    	
    }
});