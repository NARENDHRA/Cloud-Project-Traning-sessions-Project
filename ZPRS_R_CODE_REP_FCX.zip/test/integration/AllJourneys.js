jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
		"sap/ui/test/Opa5",
		"fgt/sc/rcoderep/test/integration/pages/Common",
		"sap/ui/test/opaQunit",
		"fgt/sc/rcoderep/test/integration/pages/Worklist",
		"fgt/sc/rcoderep/test/integration/pages/Object",
		"fgt/sc/rcoderep/test/integration/pages/NotFound",
		"fgt/sc/rcoderep/test/integration/pages/Browser",
		"fgt/sc/rcoderep/test/integration/pages/App"
	], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "fgt.sc.rcoderep.view."
	});

	sap.ui.require([
		"fgt/sc/rcoderep/test/integration/WorklistJourney",
		"fgt/sc/rcoderep/test/integration/ObjectJourney",
		"fgt/sc/rcoderep/test/integration/NavigationJourney",
		"fgt/sc/rcoderep/test/integration/NotFoundJourney"
	], function () {
		QUnit.start();
	});
});