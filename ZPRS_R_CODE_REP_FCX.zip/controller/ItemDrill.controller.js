sap.ui.define([
	"fgt/sc/rcoderep/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"fgt/sc/rcoderep/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox"
], function(BaseController, JSONModel, formatter, Filter, FilterOperator, MessageBox) {
	"use strict";

	return BaseController.extend("fgt.sc.rcoderep.controller.ItemDrill", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the ItemDrill controller is instantiated.
		 * @public
		 */
		onInit: function() {
			this.oRouter = this.getOwnerComponent().getRouter();
			this.oRouter.getRoute("itemDrill").attachPatternMatched(this._onPartnerMatched, this);
		},

		_onPartnerMatched: function(oEvent) {
			//Code: Handling fiori launchpad nav back button
			/*---Starts Here---*/
			this.fBackButton = sap.ui.getCore().byId("backBtn").mEventRegistry.press[0].fFunction;
			sap.ui.getCore().byId("backBtn").mEventRegistry.press[0].fFunction = function() {
				window.history.back();
			}.bind(this);
			/*---Ends Here---*/

			this._reasonCode = oEvent.getParameter("arguments").reasonCode || this._reasonCode || "0";
			this._sSet = oEvent.getParameter("arguments").sSet || this._sSet || "0";
			this.getView().byId("idSTItemData").rebindTable();
		},

		onBeforeRebindTable: function(oSource) {
			var oBindingParams = oSource.getParameter("bindingParams");
			oBindingParams.parameters = oBindingParams.parameters || {};
			var afilter = new sap.ui.model.Filter("Zzreasoncode", sap.ui.model.FilterOperator.EQ, this._reasonCode);
			var afilter1 = new sap.ui.model.Filter("Set", sap.ui.model.FilterOperator.EQ, this._sSet);
			oBindingParams.filters.push(afilter);
			oBindingParams.filters.push(afilter1);
		},
		
		onNavBack: function() {
			window.history.go(-1);
		}
		
	});
});