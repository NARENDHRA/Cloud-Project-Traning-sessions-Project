sap.ui.define([
	"fgt/sc/rcoderep/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"fgt/sc/rcoderep/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/Device"
], function(BaseController, JSONModel, formatter, Filter, FilterOperator, Device) {
	"use strict";

	return BaseController.extend("fgt.sc.rcoderep.controller.Worklist", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function() {
			this.oRouter = this.getOwnerComponent().getRouter();
		},

		onbeforeRebindTable: function(oSource) {

		},

		onCollapseAll: function() {
			this.byId("idSTable").getTable().collapseAll();
		},

		onExpandAll: function() {
			this.byId("idSTable").getTable().setNumberOfExpandedLevels(2);
		},

		onCellClick: function(oEvent) {
			if (oEvent.getSource().getContextInfoByIndex(oEvent.getParameter("rowIndex")).level !== 3) {
				if (!oEvent.getSource().getContextInfoByIndex(oEvent.getParameter("rowIndex")).nodeState.expanded) {
					oEvent.getSource().expand(oEvent.getParameter("rowIndex"));
				} else {
					oEvent.getSource().collapse(oEvent.getParameter("rowIndex"));
				}
			}
		},

		onLinkPress: function(oEvent) {
			var sReasonCode = oEvent.getSource().getParent().getBindingContext().getProperty("Zzreasoncode"),
				sSet = oEvent.getSource().getParent().getBindingContext().getProperty("Set");
			this.oRouter.navTo("itemDrill", {
				reasonCode: sReasonCode,
				sSet: sSet
			});
		}

	});
});