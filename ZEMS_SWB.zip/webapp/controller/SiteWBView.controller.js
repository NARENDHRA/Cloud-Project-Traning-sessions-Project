sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("siteworkbench.ZEMS_SWB.controller.SiteWBView", {
		onInit: function () {
			this.getRouter();

		},
		getRouter: function () {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},
		onPressLineItemSiteNo: function (evt) {
			var siteNoVal = evt.getSource().getBindingContext().getObject().ProductID;
			this.getRouter().navTo("SiteSectionInfo", {
				siteNo: siteNoVal
			});

		},
		onInitSmartFilterBar: function (evt) {
			var s = evt.getSource(),
				Maxesults = s.getControlByKey("DimUnit");
			Maxesults.setValue("100");
		}
	});
});