sap.ui.define([
	"siteworkbench/ZEMS_SWB/test/unit/controller/SiteWBView.controller"
], function () {
	"use strict";
});