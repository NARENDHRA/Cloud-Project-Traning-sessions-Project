/*global QUnit*/

sap.ui.define([
	"siteworkbench/ZEMS_SWB/controller/SiteWBView.controller"
], function (Controller) {
	"use strict";

	QUnit.module("SiteWBView Controller");

	QUnit.test("I should test the SiteWBView controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});