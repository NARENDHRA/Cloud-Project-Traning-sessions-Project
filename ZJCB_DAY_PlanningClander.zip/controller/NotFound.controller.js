sap.ui.define([
		"ndbs/jcb/common/controller/BaseController"
	], function (BaseController) {
		"use strict";

		return BaseController.extend("ndbs.jcb.job.daily.controller.NotFound", {

			/**
			 * Navigates to the worklist when the link is pressed
			 * @public
			 */
			onLinkPressed : function () {
				this.getRouter().navTo("worklist");
			}

		});

	}
);