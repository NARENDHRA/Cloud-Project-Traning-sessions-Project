sap.ui.define([
		"sap/ui/core/mvc/Controller",
		"sap/ui/model/json/JSONModel",
		"sap/ui/unified/CalendarAppointment",
		"sap/ui/model/Filter",
		"sap/ui/model/FilterOperator",
		"sap/m/MessagePopover",
		"sap/m/MessagePopoverItem",
		"sap/m/MessageToast",
		"ndbs/jcb/common/utils/formatter",
		"ndbs/jcb/common/controller/BaseController",
		"ndbs/jcb/common/utils/FormValidation",
		"./messages"
	],
	function(Controller, JSONModel, CalendarAppointment, Filter, FilterOperator, MessagePopover, MessagePopoverItem, MessageToast, formatter,
		BaseController, FormValidation, messages) {
		"use strict";

		return BaseController.extend("ndbs.jcb.job.daily.controller.S1_Planner", {

			formatter: formatter,

			onInit: function() {
				this._oModel = this.getOwnerComponent().getModel();
				this.getView().setModel(this._oModel);
				this._oResourceBundle = this.getResourceBundle();

				//var oStartDate = new Date("2016", "01", "23", "7", "00");
				var oStartDate = new Date();
				// oStartDate.setHours(7);
				oStartDate.setMinutes(0);
				var oMaxDate = new Date(oStartDate.getTime());
				oMaxDate.setDate(oStartDate.getDate() + 1);
				//oMaxDate.setDate(oStartDate.getDate());
				oMaxDate.setHours(23);
				oMaxDate.setMinutes(59);
				var oMinDate = new Date(oStartDate.getTime());
				//oMinDate.setDate(oStartDate.getDate() - 1);
				// oMinDate.setHours(23);
				// oMinDate.setMinutes(59);
				oMinDate.setDate(oStartDate.getDate());
				oMinDate.setHours(0);
				oMinDate.setMinutes(0);
				var oRates = [{
					"desc": "15 sec",
					"val": "15000"
				}, {
					"desc": "30 sec",
					"val": "30000"
				}, {
					"desc": "45 sec",
					"val": "45000"
				}, {
					"desc": "60 sec",
					"val": "60000"
				}];
				var oMaxRows = [{
					"desc": "2 Bays",
					"val": "2"
				}, {
					"desc": "5 Bays",
					"val": "5"
				}, {
					"desc": "10 Bays",
					"val": "10"
				}];

				this.oViewModel = new JSONModel({
					StartDate: oStartDate, //use current date
					MinDate: oMinDate,
					MaxDate: oMaxDate,
					BookReason: [],
					BayType: [],
					Type: [],
					Bays: [],
					WorkStart: null,
					WorkEnd: null,
					bookingTitle: this._oResourceBundle.getText("xtit.bookingDetailTitle"),
					Rate: oRates,
					MaxRows: oMaxRows
				});

				this.getView().setModel(this.oViewModel, "vm");

				var oViewModelPlanLegend,
					oViewModelBookReason,
					oViewModelBayTypes;
				var that = this;

				// Set working start time and end time
				this._oModel.read("/AppControlSet", {
					success: function(oData) {
						that.oViewModel.setProperty("/WorkStart", oData.results[0].WorkStart);
						that.oViewModel.setProperty("/WorkEnd", oData.results[0].WorkEnd);
					}
				});

				// Store PlanLegend to JSONModel
				oViewModelPlanLegend = new JSONModel();
				this.getView().setModel(oViewModelPlanLegend, "vmLegend");
				this._oModel.read("/LegendSet", {
					success: function(oData) {
						oViewModelPlanLegend.setProperty("/LegendSet", oData.results);
					}
				});

				// Store BookReason to JSONModel
				oViewModelBookReason = new JSONModel();
				this.getView().setModel(oViewModelBookReason, "vmBookReason");
				this._oModel.read("/VH_BookReasonSet", {
					success: function(oData) {
						oViewModelBookReason.setProperty("/VH_BookReasonSet", oData.results);
						var aBookReason = [];
						if (oData.results) {
							for (var i = 0; i < oData.results.length; i++) {
								aBookReason.push(oData.results[i].BookReason);
							}
							that.oViewModel.setProperty("/BookReason", aBookReason);
						}
					}
				});

				// Store BayType to JSONModel
				oViewModelBayTypes = new JSONModel();
				this.getView().setModel(oViewModelBayTypes, "vmBayTypes");
				this._oModel.read("/VH_BayTypeSet", {
					success: function(oData) {
						oViewModelBayTypes.setProperty("/VH_BayTypeSet", oData.results);
						var aBayType = [];
						if (oData.results) {
							for (var i = 0; i < oData.results.length; i++) {
								aBayType.push(oData.results[i].BayType);
							}
							that.oViewModel.setProperty("/BayType", aBayType);
							that.onBayTypeChange(undefined, aBayType);
						}
					}
				});

				this.oMessageManager = sap.ui.getCore().getMessageManager();
				this.getView().setModel(this.oMessageManager.getMessageModel(), "msg");

				this.oPlanningCalendar = this.byId("PC1");

				// this.oPlanningCalendar.setStartDate(oStartDate);
				this.oRowTemplate = this.byId("PC1Row").clone();

				this.oTokenizer = this.byId("idTokenizer");
				this.oTokenTemplate = this.byId("idToken").clone();
				this.oTokenizer.addEventDelegate({
					onAfterRendering: function() {
						var aTokens = this.oTokenizer.getTokens();
						var oPC = this.oPlanningCalendar;
						var that = this;
						var dAppointmentDate;
						aTokens.forEach(function(oToken) {
							if (oToken.getBindingContext()) {
								that.formatter.tokenColor(oToken);
								dAppointmentDate = oToken.getBindingContext().getProperty("AppointmentDateTime");
								// if (dAppointmentDate) {
								// 	oToken.setTooltip(dAppointmentDate);
								// }
							}
							oToken.ontouchend = function(oEvent) {
								sap.m.Token.prototype.ontouchend.apply(this, arguments);
								this._isDragging = false;
							}.bind(oToken);
							oToken.$().attr("draggable", true);
							oToken.$().on("dragstart", oPC.onTokenDragStart.bind(oPC));
						});
					}.bind(this)
				});

				this.getView().setBusyIndicatorDelay(0);

				this.AutoIndex = 0;
				this.EndIndex = 0;
				this._oModel.setSizeLimit("9999");
			},

			onBeforeRendering: function() {
				this._oLegend = this.byId("idLegend");

				var aStandardLegend = this._oLegend.getAggregation("standardItems");
				for (var i = 1; i < aStandardLegend.length; i++) {
					var aLegend = aStandardLegend[i];
					aLegend.destroy();
				}

			},

			onAfterRendering: function() {
				if (!this._oViewSettingsDialog) {
					this._oViewSettingsDialog = sap.ui.xmlfragment("ndbs.jcb.job.daily.view.fragment.ViewSettings", this);
					this._oViewSettingsDialog.setModel(this.oViewModel, "vm");
					//this.onBayTypeChange(undefined, this.oViewModel.getProperty("/BayType"));
					this.getView().addDependent(this._oViewSettingsDialog);
					this.oCbAuto = sap.ui.getCore().byId("idCbAuto");
					this.oSelAuto = sap.ui.getCore().byId("idSelAuto");
					this.oInpMaxBays = sap.ui.getCore().byId("idInputMaxBays");
					// this.oSelMaxBays = sap.ui.getCore().byId("idSelMaxBays");
				}

				if (!this._oViewSettingsDialogBooking) {
					this._oViewSettingsDialogBooking = sap.ui.xmlfragment("ndbs.jcb.job.daily.view.fragment.ViewSettingsBooking", this);
					this._oViewSettingsDialog.setModel(this.oViewModel, "vm");
					this.getView().addDependent(this._oViewSettingsDialogBooking);
				}

				if (!this._oAppointmentDetailDialog) {
					this._oAppointmentDetailDialog = sap.ui.xmlfragment("ndbs.jcb.job.daily.view.fragment.AppointmentDetail", this);
					this.getView().addDependent(this._oAppointmentDetailDialog);
					this._oAppointmentDetailDialog.setModel(this.oViewModel, "vm");

				}

				if (!this._oBookingDetailDialog) {
					this._oBookingDetailDialog = sap.ui.xmlfragment("ndbs.jcb.job.daily.view.fragment.BookingDetail", this);
					this.getView().addDependent(this._oBookingDetailDialog);
				}

				this._aFormFields = [{
					control: sap.ui.getCore().byId("idDTStartDate"),
					mandatoryMsgID: "ymsg.errorTimeStart",
					dateTimeRangeHigh: "EndDate",
					rangeMsgID: "ymsg.errorDateTimeHighRange"
				}, {
					control: sap.ui.getCore().byId("idDTEndDate"),
					mandatoryMsgID: "ymsg.errorTimeEnd",
					dateTimeRangeLow: "StartDate",
					rangeMsgID: "ymsg.errorDateTimeLowRange"
				}];

				this._oFormValidation = new FormValidation(this._aFormFields, this._oModel, this._oResourceBundle);

				this.onStartDateChanged();
			},

			onStartDateChanged: function(oEvent) {
				this.setViewBusy(true);
				this.submitChanges();
				this.setFilters();
				this.bindBookings();
				this.bindPlanningCalendar();
			},

			bindPlanningCalendar: function() {
				this.oPlanningCalendar.bindAggregation("rows", {
					path: "/BaySet",
					sorter: null,
					parameters: {
						expand: "Appointments"
					},
					template: this.oRowTemplate,
					filters: this.aFilterBy,
					templateShareable: true,
					events: {
						dataReceived: this.onBaysDataReceived.bind(this)
					}
				});
			},

			// bindAppointments: function(oData) {
			//     var oRow = this.oPlanningCalendar.getRowByKey(oData.BayId);
			//     oRow.bindAggregation("appointments", {
			//         path: "/Appointments",
			//         sorter: null,
			//         template: new CalendarAppointment({
			//             key: "{AppointmentId}",
			//             startDate: "{Start}",
			//             endDate: "{End}",
			//             title: "{RegNo}",
			//             icon: "{Icon}",
			//             text: "{Remarks}",
			//             type: "{Type}"
			//         }),
			//         templateShareable: true,
			//         filters: [new Filter("BayId", FilterOperator.EQ, oData.BayId, null)].concat(this.aFilterDate)
			//     });
			// },

			bindBookings: function() {
				this.oTokenizer.bindAggregation("tokens", {
					path: "/BookingSet",
					sorter: null,
					template: this.oTokenTemplate,
					// templateShareable: true,
					// filters: [].concat(this.aFilterStart, this.aFilterBookReason)
					filters: this.aFilterBooking,
					events: {
						dataReceived: this.onBookingsDataReceived.bind(this)
					}
				});
			},

			onBaysDataReceived: function(oEvent) {
				this.setViewBusy(false);
				// var aData = oEvent.getParameter("data").results;
				// aData.forEach(function(oData) {
				//     this.bindAppointments(oData);
				// }.bind(this));
				if (this.oCbAuto.getSelected()) {
					this.sDelayTimeOutId = this.refreshBayList(); // refresh bay list once timeout
				} else {
					jQuery.sap.clearDelayedCall(this.sDelayTimeOutId);
					this.sDelayTimeOutId = undefined;
				}
			},

			/** 
			 * set View Busy Indicator to false in the event of data received during binding 
			 * @param {Object} oEvent Event object
			 */
			onBookingsDataReceived: function(oEvent) {
				this.setViewBusy(false);
			},

			onAppointmentSelect: function(oEvent) {
				var oAppointment = oEvent.getParameter("appointment");

				if (this.oPlanningCalendar.getIsResizeDragging()) {
					return;
				}

				var oContext = oAppointment.getBindingContext();
				this._oAppointmentDetailDialog.setBindingContext(oContext);
				this._oFormValidation.setContext(oContext);
				this._oAppointmentDetailDialog.open();
			},

			setViewBusy: function(bBusy) {
				// var oView = this.getView();
				var oView = this.oPlanningCalendar;
				if (bBusy) {
					oView.setBusyIndicatorDelay(0);
				} else {
					oView.setBusyIndicatorDelay(null);
				}

				oView.setBusy(bBusy);
			},

			submitChanges: function() {
				var fnBusy = this.setViewBusy.bind(this);
				var that = this;
				if (this._oModel.hasPendingChanges()) {
					this.setViewBusy(true);
					this._oModel.submitChanges({
						success: function() {
							fnBusy(false);
							that.onSuccessSubmit();
						},
						error: function(oResponse) {
							fnBusy(false);
							that.onErrorSubmit(oResponse);
						}
					});
				}
			},

			/** 
			 * Submit Success event; Check on Error exists
			 * @returns
			 */
			onSuccessSubmit: function() {
				// Search error message from Server
				var fnError = function(sErrorMessage) {
					return sErrorMessage.type === "Error";
				};
				// Get Return Message from Server
				var aData = this.oMessageManager.getMessageModel().oData;
				if (aData.length > 0) {
					aData.filter(fnError);
					if (aData.length > 0) {
						this.serverMessage(aData);
						messages.showMessage(this._oResourceBundle.getText("ymsg.errorUpdate"), "E", this._oResourceBundle.getText(
							"xtit.errorTitle"));
					} else {
						messages.showMessage(this._oResourceBundle.getText("ymsg.successUpdate"), "S", this._oResourceBundle.getText("xtit.success"));
					}
				} else {
					messages.showMessage(this._oResourceBundle.getText("ymsg.successUpdate"), "S", this._oResourceBundle.getText("xtit.success"));
				}
				this.rebindall();
			},

			onErrorSubmit: function(oResponse) {
				this._oModel.resetChanges();
				messages.showErrorMessage(oResponse, this._oResourceBundle.getText("xtit.errorTitle"));
				this.rebindall();
			},

			onSave: function(oEvent) {
				this.submitChanges();
				jQuery.sap.delayedCall(200, this, function() {
					this.rebindall();
				});
			},

			rebindall: function() {
				this.setFilters();
				this.bindBookings();
				this.bindPlanningCalendar();
			},

			onAppointmentDelete: function(oEvent) {
				var oContext = this._oAppointmentDetailDialog.getBindingContext();
				var oData = oContext.getObject();
				var oPlanningCalendarRow = this.oPlanningCalendar.getRowByKey(oData.BayId);

				var sPath = oContext.getPath();

				// delete appointment
				if (!oData.__metadata.created) {
					this._oModel.remove(sPath);
				} else {
					this._oModel.deleteCreatedEntry(oContext);
					//
				}
				oPlanningCalendarRow._appointmentRemove(sPath.substr(1));
				// oPlanningCalendarRow.invalidate();

				this.resetBooking(oData.BookId);
				this._oAppointmentDetailDialog.setBindingContext();

				jQuery.sap.delayedCall(100, this, function() {
					// this.onAppointmentSubmit(oEvent); //can't use because it has field validation checking
					this.submitChanges();
					jQuery.sap.delayedCall(200, this, function() {
						this.rebindall();
						this._oAppointmentDetailDialog.close();
					});
				});

			},

			resetBooking: function(sBookId) {
				var sPath = this._oModel.createKey("/BookingSet", {
					BookId: sBookId
				});
				var oContext = this._oModel.getContext(sPath);
				if (oContext) {
					this._oModel.setProperty("Assigned", false, oContext);
				}
			},

			onAppointmentSubmit: function(oEvent) {
				//validate fields
				this._oFormValidation.validateAllFields();

				// exit if there's error
				if (this._oFormValidation.hasErrors()) {
					return;
				}

				if (this.checkCollision()) {
					this._oModel.resetChanges();
					MessageToast.show("Collision");
					this.rebindall();
					this._oAppointmentDetailDialog.close();
				} else {
					this.submitChanges();
					jQuery.sap.delayedCall(200, this, function() {
						this.rebindall();
						this._oAppointmentDetailDialog.close();
					});
				}
			},

			onViewSettingsDialog: function(oEvent) {
				this._oViewSettingsDialog.open();
			},

			onViewSettingsDialogBooking: function(oEvent) {
				this._oViewSettingsDialogBooking.open();
			},

			onBayTypeChange: function(oEvent, sBayType) {
				var oMCBays = sap.ui.getCore().byId("idMCBays");
				if (oEvent) {
					sBayType = oEvent.oSource.getSelectedKeys();
					oMCBays.setSelectedKeys("");
				}

				var aBayFilters = [];
				if (sBayType.length > 0) {
					for (var i = 0; i < sBayType.length; i++) {
						aBayFilters.push(new Filter("BayType", FilterOperator.EQ, sBayType[i], null));
					}
				} else {
					aBayFilters = [new Filter("BayType", FilterOperator.EQ, "", null)];
				}

				oMCBays.setEnabled(true);
				oMCBays.bindAggregation("items", {
					path: "/BayFilterSet",
					template: new sap.ui.core.Item({
						key: "{BayId}",
						text: "{BayId} - {Description}"
					}),
					templateShareable: true,
					filters: aBayFilters,
					events: {
						dataReceived: this.onBayIDReceived.bind(this)
					}
				});

			},

			onBayIDReceived: function(oEvent) {
				var aBayID = [];
				var oData = oEvent.getParameter("data");
				if (oData.results) {
					for (var i = 0; i < oData.results.length; i++) {
						aBayID.push(oData.results[i].BayId);
					}
					this.oViewModel.setProperty("/Bays", aBayID);
				}
			},

			onConfirmViewSettingsDialog: function(oEvent) {
				var _fnClosePending = function(oAction) {
					if (oAction === "YES") {
						this.submitChanges();
						// this.saveChanges();
						jQuery.sap.delayedCall(200, this, function() {
							this.resetBayIndex();
							this.EndIndex = parseInt(this.oInpMaxBays.getValue());
							this.rebindall();
						});
					} else {
						this._oModel.resetChanges();
						this.resetBayIndex();
						this.EndIndex = parseInt(this.oInpMaxBays.getValue());
						this.rebindall();
					}
				}.bind(this);

				if (this._oModel.hasPendingChanges()) {
					// Warning if changes made
					sap.m.MessageBox.show(this._oResourceBundle.getText("ymsg.warningUnsavedOnViewSetting"), {
						icon: sap.m.MessageBox.Icon.WARNING, // default
						title: this._oResourceBundle.getText("xtit.warning"), // default
						actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO], // default
						styleClass: "", // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit, // default
						verticalScrolling: true, // default
						horizontalScrolling: true,
						onClose: _fnClosePending
					});
				} else {
					this.resetBayIndex();
					this.EndIndex = parseInt(this.oInpMaxBays.getValue());
					this.rebindall();
				}

				this._oViewSettingsDialog.close();

				this.AutoIndex = 0; //reset index
				this.setFilters(this.oCbAuto.getSelected());
				this.bindBookings();
				this.bindPlanningCalendar();

				this._oViewSettingsDialog.close();
			},

			/** 
			 * Confirm button event in Settings Fragment
			 * reset filters and rebind appointment & bookings
			 * @param {Object} oEvent Event object
			 */
			onConfirmViewSettingsBookingDialog: function(oEvent) {
				this.setFilters();
				this.bindBookings();
				this._oViewSettingsDialogBooking.close();
			},

			setFilters: function(sAuto) {
				this.aFilterBy = [];
				this.aFilterBayType = [];
				this.aFilterBay = [];
				this.aFilterDate = [];
				this.aFilterBookReason = [];
				this.aFilterByType = [];
				this.aFilterCSPlate = [];

				/*if (this.oViewModel.getProperty("/Bays").length > 0) {
					this.aFilterBay = this.oViewModel.getProperty("/Bays").sort().map(function(sBayId) {
						return new Filter("BayId", FilterOperator.EQ, sBayId, null);
					});
				}*/
				var aBay = [];
				if (this.oViewModel.getProperty("/Bays").length > 0) {
					aBay = this.oViewModel.getProperty("/Bays").sort().map(function(sBayId) {
						return new Filter("BayId", FilterOperator.EQ, sBayId, null);
					});
				}

				if (this.EndIndex === 0 || isNaN(this.EndIndex)) {
					this.aFilterBay = aBay;
				} else {
					// if both are equal means no update on next bay index
					if (this.AutoIndex === this.EndIndex) {
						this.AutoIndex = this.AutoIndex - parseInt(this.oInpMaxBays.getValue()); //remain the current set of bays index
					}
					this.aFilterBay = aBay.slice(this.AutoIndex, this.EndIndex);
					this.AutoIndex = this.EndIndex;
				}

				// if (sAuto) {
				// 	var oEndIndex = this.AutoIndex + parseInt(this.oSelMaxBays.getSelectedKey());
				// 	this.aFilterBay = aBay.slice(this.AutoIndex, oEndIndex);
				// 	if (this.oViewModel.getProperty("/Bays").length > oEndIndex) {
				// 		this.AutoIndex = oEndIndex;
				// 	} else {
				// 		this.AutoIndex = 0;
				// 	}
				// } else {
				// 	this.aFilterBay = aBay;
				// }

				//this.aFilterBayType = [new Filter("BayType", FilterOperator.EQ, this.oViewModel.getProperty("/BayType"), null)];
				//if (this.oViewModel.getProperty("/BayType").length > 0) {
				this.aFilterBayType = this.oViewModel.getProperty("/BayType").map(function(sBayType) {
					return new Filter("BayType", FilterOperator.EQ, sBayType, null);
				});
				//}

				if (this.oViewModel.getProperty("/BookReason").length > 0) {
					this.aFilterBookReason = this.oViewModel.getProperty("/BookReason").map(function(sBookReason) {
						return new Filter("BookReason", FilterOperator.Contains, sBookReason, null);
					});
				}

				if (this.oViewModel.getProperty("/Type").length > 0) {
					this.aFilterByType = this.oViewModel.getProperty("/Type").sort().map(function(sType) {
						return new Filter("Type", FilterOperator.EQ, sType, null);
					});
				}
				
				var oInputCSPlacte = sap.ui.getCore().byId("idInputCSPlate");
				if (oInputCSPlacte && oInputCSPlacte.getValue().length > 0) {
					this.aFilterCSPlate = new Filter("RegNo", FilterOperator.Contains, oInputCSPlacte.getValue());
				}

				var oStart = this.oPlanningCalendar.getStartDate();
				var oEnd = this.oPlanningCalendar.getRowEndDate();
				var oFilterStart = new Filter("StartDate", FilterOperator.LE, oEnd, null);
				var oFilterEnd = new Filter("EndDate", FilterOperator.GT, oStart, null);
				this.aFilterDate = new Filter({
					filters: [oFilterStart, oFilterEnd],
					and: true
				});
				this.aFilterStart = [new Filter("StartDate", FilterOperator.BT, oStart, oEnd)];
				this.aFilterBy = [].concat(this.aFilterBayType, this.aFilterBay, this.aFilterDate, this.aFilterBookReason, this.aFilterCSPlate);
				this.aFilterBooking = [].concat(this.aFilterStart, this.aFilterBookReason, this.aFilterByType, this.aFilterCSPlate);
			},

			onAppointmentCancel: function(oEvent) {
				this._oFormValidation.clearAllValidation();
				this._oModel.resetChanges();
				//this.rebindall();
				this._oAppointmentDetailDialog.close();
			},

			onAppointmentClose: function(oEvent) {
				//validate fields
				this._oFormValidation.validateAllFields();

				// exit if there's error
				if (this._oFormValidation.hasErrors()) {
					return;
				}

				if (this.checkCollision()) {
					this._oModel.resetChanges();
					MessageToast.show("Collision");
					this.rebindall();
				}
				this._oAppointmentDetailDialog.close();
			},

			checkCollision: function() {
				var oContext = this._oAppointmentDetailDialog.getBindingContext();
				if (oContext) {
					var oData = oContext.getObject();
					if (oData) {
						var oPlanningCalendarRow = this.oPlanningCalendar.getRowByKey(oData.BayId);
						var fnSome = function(o) {
							if (oData.RegNo) { //check if PlateNo is empty, otherwise use CsNo for checking
								return ((o.getEndDate() > oData.StartDate) && (o.getStartDate() < oData.EndDate) && o.getTitle() !== oData.RegNo);
							} else {
								return ((o.getEndDate() > oData.StartDate) && (o.getStartDate() < oData.EndDate) && o.getTitle() !== oData.CsNo);
							}
						};
						return oPlanningCalendarRow.getAppointments().some(fnSome);
					}
				}
				return false;
			},

			onTokenPress: function(oEvent) {
				var oToken = oEvent.getSource();
				if (!oToken._isDragging) {
					if (oToken.getBindingContext()) {
						var iBookId = oToken.getBindingContext().getObject().BookId;

						this.getModel("vm").setProperty("/bookingTitle",
							iBookId ?
							this._oResourceBundle.getText("xtit.bookingDetailTitleID", [iBookId]) :
							this._oResourceBundle.getText("xtit.bookingDetailTitle"));
					}

					this._oBookingDetailDialog.setBindingContext(oToken.getBindingContext());
					this._oBookingDetailDialog.open();
				}
			},

			onBookingDetailClose: function(oEvent) {
				this._oBookingDetailDialog.close();
			},

			showMessages: function(oEvent) {

				if (!this.oMessagePopover) {
					this.oMessagePopover = new MessagePopover({
						items: {
							path: "msg>/",
							template: new MessagePopoverItem({
								type: "{msg>type}",
								title: "{msg>message}",
								description: "{msg>description}"
							})
						}
					});
					this.oMessagePopover.setModel(this.oMessageManager.getMessageModel(), "msg");
				}

				this.oMessagePopover.openBy(oEvent.getSource());
			},

			onBaySelectionChange: function(oEvent) {
				var oSelectedItem = oEvent.getParameter("selectedItem");
				var sPath = oEvent.getSource().getBindingContext().getPath().substr(1);
				var sOldBay = this._oModel.oData[sPath].BayId;
				var sNewBay = oSelectedItem.getKey();

				this.oPlanningCalendar.getRowByKey(sOldBay)._appointmentRemove(sPath);
				this.oPlanningCalendar.getRowByKey(sNewBay)._appointmentAdd(sPath);
			},

			onDataReset: function() {
				if (this._oModel.hasPendingChanges()) {
					this._oModel.resetChanges();
					this.rebindall();
					jQuery.sap.require("sap.m.MessageBox");
					sap.m.MessageBox.show(
						this._oResourceBundle.getText("ymsg.resetsuccess"), {
							icon: sap.m.MessageBox.Icon.NONE, // default
							title: this._oResourceBundle.getText("xtit.successboxTitle"), // default
							actions: sap.m.MessageBox.Action.OK, // default
							onClose: null, // default
							styleClass: "", // default
							initialFocus: null, // default
							textDirection: sap.ui.core.TextDirection.Inherit, // default
							verticalScrolling: true, // default
							horizontalScrolling: true
								// default
						});
				}
			},

			/** 
			 * token display format for users (take either RegNo or CsNo)
			 * @param {String} sRegNo - Registration No
			 * @param {String} sCsNo - CS Number
			 * @returns {String} Vehicle Display number
			 */
			formatVehicleDisplay: function(sRegNo, sCsNo) {
				var sPlate = sRegNo || sCsNo;
				return sPlate;
			},

			/** 
			 * display format for JobType
			 * @param sType
			 * @returns
			 */
			formatJobType: function(sType) {
				var oViewModelPlanLegend = this.getModel("vmLegend");
				var aLegendType = oViewModelPlanLegend.getData().LegendSet;

				for (var i = 0; i < aLegendType.length; i++) {
					if (aLegendType[i].LegendType === sType) {
						return aLegendType[i].LegendDesc;
					}
				}
			},

			/**
			 * Navigates back in the browser history, if the entry was created by this app.
			 * If not, it navigates to the Fiori Launchpad home page.
			 * @public
			 */
			onNavBack: function() {
				var oHistory = sap.ui.core.routing.History.getInstance(),
					sPreviousHash = oHistory.getPreviousHash();
				var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

				var _fnClosePending = function(oAction) {
					if (oAction === "YES") {
						this._oModel.resetChanges();
						if (sPreviousHash !== undefined) {
							// The history contains a previous entry
							history.go(-1);
						} else {
							// Navigate back to FLP home
							oCrossAppNavigator.toExternal({
								target: {
									shellHash: "#Shell-home"
								}
							});
						}
					}
				}.bind(this);

				if (this._oModel.hasPendingChanges()) {
					// Warning if changes made
					sap.m.MessageBox.show(this._oResourceBundle.getText("ymsg.warningUnsavedChanges"), {
						icon: sap.m.MessageBox.Icon.WARNING, // default
						title: this._oResourceBundle.getText("xtit.warning"), // default
						actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO], // default
						styleClass: "", // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit, // default
						verticalScrolling: true, // default
						horizontalScrolling: true,
						onClose: _fnClosePending
					});
				} else {
					if (sPreviousHash !== undefined) {
						// The history contains a previous entry
						history.go(-1);
					} else {
						// Navigate back to FLP home
						oCrossAppNavigator.toExternal({
							target: {
								shellHash: "#Shell-home"
							}
						});
					}
				}
			},

			displayControl: function(oEvent) {
				var bSelected = oEvent.getSource().getSelected();
				this.oSelAuto.setVisible(bSelected);
				// this.oSelMaxBays.setVisible(bSelected);
			},

			/**
			 * refresh bay list
			 * @return {string} Delayed Callid, can be used to clear refresh
			 */
			refreshBayList: function() {
				if (!this.sDelayTimeOutId) {
					var dStartDate = new Date();
					dStartDate.setMinutes(0);
					this.oPlanningCalendar.setStartDate(dStartDate); // Rerender start time for Planning Calendar
					this.oViewModel.setProperty("StartDate", dStartDate);
					return jQuery.sap.delayedCall(this.oSelAuto.getSelectedKey(), this, function() {
						jQuery.sap.log.info("Refresh Bay List");
						this.sDelayTimeOutId = null;
						this._oModel.refresh(false, false); //easiest way to ensure reload
						if (this.oViewModel.getProperty("/Bays").length <= this.EndIndex) {
							this.AutoIndex = 0;
							this.EndIndex = 0;
						}
						this.EndIndex = this.AutoIndex + parseInt(this.oInpMaxBays.getValue());
						this.setFilters(true);
						this.setViewBusy(true);
						this.bindPlanningCalendar();
					});
				}
				return null;
			},

			checkMaxBays: function(oEvent) {
				var sValue = oEvent.getParameters().newValue;
				if (sValue > 20) {
					this.oInpMaxBays.setValue(20);
				}
			},

			onNextBay: function(oEvent) {
				var _fnClosePending = function(oAction) {
					if (oAction === "YES") {
						// this.saveChanges();
						this.submitChanges();
						jQuery.sap.delayedCall(200, this, function() {
							this.rebindall();
						});
					} else {
						this._oModel.resetChanges();
						this.rebindall();
					}
				}.bind(this);

				if (this._oModel.hasPendingChanges()) {
					// Warning if changes made
					sap.m.MessageBox.show(this._oResourceBundle.getText("ymsg.warningUnsavedOnView"), {
						icon: sap.m.MessageBox.Icon.WARNING, // default
						title: this._oResourceBundle.getText("xtit.warning"), // default
						actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO], // default
						styleClass: "", // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit, // default
						verticalScrolling: true, // default
						horizontalScrolling: true,
						onClose: _fnClosePending
					});
				} else {
					if (this.oViewModel.getProperty("/Bays").length <= this.EndIndex) {
						this.AutoIndex = 0;
						this.EndIndex = 0;
					}
					this.EndIndex = this.AutoIndex + parseInt(this.oInpMaxBays.getValue());

					this.setFilters();
					this.setViewBusy(true);
					this.bindPlanningCalendar();
				}
			},

			resetBayIndex: function() {
				this.AutoIndex = 0; //reset index
				this.EndIndex = 0;
				var oNextButton = this.byId("idNextBay");
				oNextButton.setVisible(this.setVisibleNextBay());
			},

			setVisibleNextBay: function() {
				if (this.oCbAuto.getSelected()) {
					return false;
				}
				var bVisible = true;
				var nMaxBays = parseInt(this.oInpMaxBays.getValue());
				if (nMaxBays === 0 || isNaN(nMaxBays)) {
					bVisible = false;
				} else {
					if (this.oViewModel.getProperty("/Bays").length <= nMaxBays) {
						bVisible = false;
					}
				}
				return bVisible;
			}

		});
	});