sap.ui.define(["sap/ui/base/Object"], function(Object) {
    "use strict";
    return Object.extend("MockRequests", {
        constructor: function(oMockServer) {
            this._bError = false; //true if a this._sjax request failed
            this._sErrorTxt = ""; //error text for the oXhr error respons
            this._oMockServer = oMockServer;
            this._oMockServer.attachBefore("GET", this.onGetBaysBefore.bind(this), "Bays");
            this._oMockServer.attachAfter("GET", this.onGetBaysAfter.bind(this), "Bays");
        },

        getRequests: function() {
            return [];
        },


        mockBaysExpandedRequest: function() {
            return {
                method: "GET",
                path: new RegExp("Bays?(.*)"),
                response: this.getBaysExpanded.bind(this)
            };
        },

        onGetBaysBefore: function(oEvent) {
            var sUrlParams = decodeURIComponent(oEvent.getParameter("sUrlParams"));

            // need to query Bays with a start date, so we can filter the expanded Appointements
            // here we add the filer Low date to the mockdata from Bays so it is returned
            if (sUrlParams && sUrlParams.indexOf("Start") > -1) {
                var oDateFilter = this.getDateFilter(sUrlParams);

                this._oMockServer._oMockdata.Bays.forEach(function(oBay) {
                    oBay.Start = oDateFilter.start;
                    oBay.End = oDateFilter.end;
                });
            }
        },

        onGetBaysAfter: function(oEvent) {
            var oXhr = oEvent.getParameter("oXhr");
            var sUrl = decodeURIComponent(oXhr.url);

            // here we apply the Start filter to the $expand=Appointments so we get only the relevant appointments
            if (sUrl && sUrl.indexOf("Start") > -1 && sUrl.indexOf("$count") < 0) {
                var oData = oEvent.getParameter("oEntry") || oEvent.getParameter("oFilteredData");
                var aBays = oData.results;
                var sFilter = this.getDateFilter(sUrl).filter;
                var fnQuery = this._oMockServer._applyQueryOnCollection.bind(this._oMockServer);

                aBays.forEach(function(oBay) {
                    if (oBay.Appointments.results && oBay.Appointments.results.length > 0) {
                        // apply date filter to the expand results
                        fnQuery(oBay.Appointments, sFilter, "Appointments");
                    }
                });
            }

        },

        getDateFilter: function(sFilter) {
            var fnFilter = function(str) {
                return str.indexOf("Start") > -1 || str.indexOf("End") > -1;
            };

            sFilter = sFilter.replace(/\&/g, " and ");

            // (Start le datetime'End' and End gt datetime'Start')
            var sDateFilter = "$filter=" + sFilter.split("and").filter(fnFilter).join("and").trim();

            var rxHigh = /\le(.*?)\and/; //read datetime after "le"
            var rxLow = /\gt(.*?)\)/;  //read datetime after "gt"
            var sLow = rxLow.exec(sDateFilter)[1];
            var sHigh = rxHigh.exec(sDateFilter)[1];

            //get the JSon Date representation of datetime
            var sJSonLowDate = this._oMockServer._getJsonDate(sLow.trim());
            var sJSonHighDate = this._oMockServer._getJsonDate(sHigh.trim());

            return {
                filter: sDateFilter,
                start: sJSonLowDate,
                end: sJSonHighDate
            };
        }

    });
});
