sap.ui.define([
        "jquery.sap.global"
    ],
    function(jQuery) {
        "use strict";

        /**
         * Utility functionality to work with �lements, e.g. iterate through aggregations, find parents, ...
         **/
        return {
            getElementInstance: function(vElement) {
                if (typeof vElement === "string") {
                    return sap.ui.getCore().byId(vElement);
                } else {
                    return vElement;
                }
            },

            isInstanceOf: function(oElement, sType) {
                var oInstance = jQuery.sap.getObject(sType);
                if (typeof oInstance === "function") {
                    return oElement instanceof oInstance;
                } else {
                    return false;
                }
            },

            getClosestElementForNode: function(oNode) {
                var $ClosestElement = jQuery(oNode).closest("[data-sap-ui]");
                return $ClosestElement.length ? sap.ui.getCore().byId($ClosestElement.data("sap-ui")) : undefined;
            }
        };

    }, /* bExport= */ true);
