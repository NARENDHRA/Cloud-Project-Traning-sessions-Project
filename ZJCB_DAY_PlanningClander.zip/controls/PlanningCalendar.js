sap.ui.define(["sap/m/PlanningCalendar", "sap/m/PlanningCalendarRenderer", "sap/ui/unified/calendar/CalendarUtils",
		"sap/ui/core/date/UniversalDate",
		"sap/ui/unified/CalendarAppointment", "./ElementUtil", "sap/m/MessageToast", "../controller/messages"
	],
	function(PlanningCalendar, PlanningCalendarRenderer, CalendarUtils, UniversalDate, CalendarAppointment, ElementUtil, MessageToast,
		Messages) {
		"use strict";

		return PlanningCalendar.extend("ndbs.jcb.job.daily.controls.PlanningCalendar", {
			metadata: {
				properties: {
					minDate: {
						type: "object",
						group: "Data"
					},
					maxDate: {
						type: "object",
						group: "Data"
					},
					showSubIntervals: {
						type: "boolean",
						group: "Appearance",
						defaultValue: false
					},
					isResizeDragging: {
						type: "boolean",
						group: "Data",
						defaultValue: false
					},
					opStart: {
						type: "object",
						group: "Data"
					},
					opEnd: {
						type: "object",
						group: "Data"
					}
				}
			},
			renderer: PlanningCalendarRenderer,
			init: function() {
				PlanningCalendar.prototype.init.apply(this, arguments);
				this.sStyleLeft = "appointmentResizeLeft";
				this.sStyleRight = "appointmentResizeRight";

				// hide interval select
				this._oIntervalTypeSelect.setVisible(false);
				this._oTodayButton.setVisible(false);
				// this._oHeaderToolbar.addContent(new sap.m.Text({text: "tttt"}));
				//
				this._oCalendarRowEventDelegate = {
					onBeforeRendering: this.onBeforeRowRendering,
					onAfterRendering: this.onAfterRowRendering

				};

			},

			setViewKey: function(sKey) {
				PlanningCalendar.prototype.setViewKey.apply(this, arguments);
				if (this.getMinDate()) {
					this._oTimeInterval._oMinDate = new UniversalDate(this.getMinDate());
				}

				if (this.getMaxDate()) {
					this._oTimeInterval._oMaxDate = new UniversalDate(this.getMaxDate());
				}

				this._aViews.forEach(function(oView) {
					oView.setShowSubIntervals(true);
				});
			},

			addRow: function(oRow) {

				PlanningCalendar.prototype.addRow.apply(this, arguments);

				oRow.checkCollision = function(oStartDate, oEndDate, oAppointment) {
					var fnSome = function(o) {
						if (oAppointment) {
							return ((o.getEndDate() > oStartDate) && (o.getStartDate() < oEndDate) && o.getTitle() !== oAppointment.getTitle());
						}
						return ((o.getEndDate() > oStartDate) && (o.getStartDate() < oEndDate));
					};

					return this.getAppointments().some(fnSome);
				}.bind(oRow);

				// refresh the row binging after appointment added / removed
				oRow._bindAppointments = function() {
					this.bindAggregation("appointments", this.getBindingInfo("appointments"));
				};

				oRow._appointmentAdd = function(sPath) {
					var oContext = this.getBindingContext();
					var oModel = oContext.getModel();
					var aAppointments = oModel.getProperty("Appointments", oContext);
					if (aAppointments.indexOf(sPath) === -1) {
						aAppointments.push(sPath);
						this._bindAppointments();
					}
				};

				// remove the appointment from current row bingind
				oRow._appointmentRemove = function(sPath, bDontRefresh) {
					var oContext = this.getBindingContext();
					var oModel = oContext.getModel();
					var aAppointments = oModel.getProperty("Appointments", oContext);
					var bFound;

					for (var i = aAppointments.length - 1; i >= 0; i--) {
						if (oModel.getContext("/" + aAppointments[i]).getPath().split("/")[1] === sPath) {
							aAppointments.splice(i, 1);
							bFound = true;
						}
					}

					if (bFound && !bDontRefresh) {
						this._bindAppointments();
					}
				};

				oRow.getCalendarRow().addEventDelegate(this._oCalendarRowEventDelegate, this);
			},

			getRowEndDate: function() {
				return new Date(this.getStartDate().getTime() + this._iRowSize);
			},

			getRowByKey: function(sKey) {
				return this.findRow("key", sKey);
			},

			findRow: function(sProperty, sValue) {
				var sMethod = "get" + sProperty.charAt(0).toUpperCase() + sProperty.slice(1);

				for (var i = 0, aRows = this.getRows(); i < aRows.length; i++) {
					if (aRows[i][sMethod]() === sValue) {
						return aRows[i];
					}
				}

				return null;
			},

			onBeforeRowRendering: function(oEvent) {
				var oCalendarRow = oEvent.srcControl;

				this._iRowSize = oCalendarRow._iRowSize;

				if (oCalendarRow && oCalendarRow.$()) {
					oCalendarRow.detachBrowserEvent("dragover", this.onDragOver, this);
					oCalendarRow.detachBrowserEvent("drop", this.onDrop, this);
				}
			},

			onAfterRowRendering: function(oEvent) {
				var oCalendarRow = oEvent.srcControl;

				oCalendarRow.attachBrowserEvent("dragover", this.onDragOver, this);
				oCalendarRow.attachBrowserEvent("drop", this.onDrop, this);

				var aAppointments = oCalendarRow.getAppointments();
				aAppointments.forEach(this.appointmentStyling.bind(this));
			},

			appointmentStyling: function(oAppointment) {
				//check if appointment is editable
				if (!oAppointment.getBindingContext().getObject().Editable) {
					return false;
				}

				// add the resize pointers to each  side of appointment
				var oSpanLeft = document.createElement("span");
				oSpanLeft.className = this.sStyleLeft;

				var oSpanRight = document.createElement("span");
				oSpanRight.className = this.sStyleRight;

				oAppointment.$().append(oSpanLeft);
				oAppointment.$().append(oSpanRight);

				oAppointment.$().find("." + this.sStyleLeft).mousedown(this._onResizeStart.bind(this));
				oAppointment.$().find("." + this.sStyleRight).mousedown(this._onResizeStart.bind(this));

				// set the body of the appointment to draggable
				var $AppCont = oAppointment.$().find(".sapUiCalendarAppCont");
				$AppCont.attr("draggable", true);
				$AppCont.toggleClass("appointmentDragDrop", true);
				$AppCont.on("dragstart", this.onAppointmentDragStart.bind(this));
			},

			onTokenDragStart: function(oEvent) {
				var oToken = ElementUtil.getClosestElementForNode(oEvent.target);

				if (oToken) {
					this._oDragSession = {
						oToken: oToken
					};

					oToken._isDragging = true;
					this.setIsResizeDragging(true);
				}
			},

			onAppointmentDragStart: function(oEvent) {
				var oAppointment = ElementUtil.getClosestElementForNode(oEvent.target);
				var oCalendarRow = oAppointment.getParent().getCalendarRow();

				this._oDragSession = {
					oAppointment: oAppointment,
					oOldRow: oCalendarRow,
					oNewRow: oCalendarRow
				};

				this.setIsResizeDragging(true);
			},

			onDragOver: function(oEvent) {
				oEvent.preventDefault();
				oEvent.originalEvent.preventDefault();
			},

			onDrop: function(oEvent) {
				jQuery.sap.log.info(oEvent.type);
				oEvent.stopPropagation();
				oEvent.originalEvent.preventDefault();

				if (!jQuery(oEvent.target).hasClass("sapUiCalendarRowAppsInt") && !jQuery(oEvent.target).hasClass("sapUiCalendarRowAppsSubInt") ||
					!this._oDragSession) {
					return false;
				}
				this.getCalendarRowDetails(oEvent, this._oDragSession);
				if (this._oDragSession.oAppointment) {
					this._appointmentDrop(this._oDragSession);
				}

				if (this._oDragSession.oToken) {
					this._tokenDrop(this._oDragSession);
				}

				this.setIsResizeDragging(false);
				this._oDragSession = undefined;
			},

			_tokenDrop: function(oSession) {
				var oToken = oSession.oToken;
				var oModel = oToken.getBindingContext().getModel();
				var oPlanningCalendarRow = oSession.oNewRow._oPlanningCalendarRow;
				// var iDuration = (2 * 60 * 60 * 1000);
				var iDuration = parseInt(oModel.getProperty("Duration", oToken.getBindingContext()), 10);
				var oInterval = this.getTimeStartEnd(iDuration, oSession);

				var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;
				var sWorkStart = new Date(this.mProperties.opStart.ms + TZOffsetMs).toTimeString();
				var sWorkEnd = new Date(this.mProperties.opEnd.ms + TZOffsetMs).toTimeString();

				var sDropStart = new Date(oInterval.start).toTimeString();
				var sDropEnd = new Date(oInterval.end).toTimeString();

				var oProperties = {
					StartDate: oInterval.start,
					EndDate: oInterval.end, //
					RegNo: oModel.getProperty("RegNo", oToken.getBindingContext()),
					Remarks: oModel.getProperty("Remarks", oToken.getBindingContext()),
					BookId: oModel.getProperty("BookId", oToken.getBindingContext()),
					Type: oModel.getProperty("Type", oToken.getBindingContext()),
					BayId: oPlanningCalendarRow.getBindingContext().getObject().BayId,
					Editable: true,
					BookReason: oModel.getProperty("BookReason", oToken.getBindingContext()),
					DealerCode: oModel.getProperty("DealerCode", oToken.getBindingContext()),
					TitleDesc: oModel.getProperty("TitleDesc", oToken.getBindingContext()),
					Name: oModel.getProperty("Name", oToken.getBindingContext()),
					MobileNo: oModel.getProperty("MobileNo", oToken.getBindingContext()),
					CsNo: oModel.getProperty("CsNo", oToken.getBindingContext()),
					Mileage: oModel.getProperty("Mileage", oToken.getBindingContext()),
					AppointmentDateTime: oModel.getProperty("AppointmentDateTime", oToken.getBindingContext()),
					PickupDateTime: oModel.getProperty("PickupDateTime", oToken.getBindingContext()),
					PromisedDateTime: oModel.getProperty("PromisedDateTime", oToken.getBindingContext()),
					JODateTime: oModel.getProperty("JODateTime", oToken.getBindingContext()),
					ServiceAdvisor: oModel.getProperty("ServiceAdvisor", oToken.getBindingContext()),
					LastTechnician: oModel.getProperty("LastTechnician", oToken.getBindingContext()),
					JOStatus: oModel.getProperty("JOStatus", oToken.getBindingContext())
				};

				if (oSession.oNewRow._oPlanningCalendarRow.checkCollision(oInterval.start, oInterval.end)) {
					MessageToast.show("Collision");
					return;
				}

				if (sDropStart < sWorkStart || sDropEnd > sWorkEnd) {
					var _fnClosePending = function(oAction) {
						if (oAction === "NO") {
							return;
						} else {
							oModel.setProperty("Assigned", true, oToken.getBindingContext());

							var oContext = oModel.createEntry(
								"/Appointments", {
									properties: oProperties
								}
							);
							oPlanningCalendarRow._appointmentAdd(oContext.getPath().substr(1));
						}
					};
					// Warning if changes made
					sap.m.MessageBox.show("Appointment is before/after Operating Hour. Are you sure?", {
						icon: sap.m.MessageBox.Icon.WARNING, // default
						title: "Warning", // default
						actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO], // default
						styleClass: "", // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit, // default
						verticalScrolling: true, // default
						horizontalScrolling: true,
						onClose: _fnClosePending
					});
				} else {
					oModel.setProperty("Assigned", true, oToken.getBindingContext());

					var oContext = oModel.createEntry(
						"/Appointments", {
							properties: oProperties
						}
					);
					oPlanningCalendarRow._appointmentAdd(oContext.getPath().substr(1));
				}
			},

			_appointmentDrop: function(oSession) {
				var oAppointment = oSession.oAppointment;
				var oContext = oAppointment.getBindingContext();
				var oModel = oContext.getModel();

				var iDuration = oAppointment.getEndDate() - oAppointment.getStartDate();
				var oInterval = this.getTimeStartEnd(iDuration, this._oDragSession);

				var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;
				var sWorkStart = new Date(this.mProperties.opStart.ms + TZOffsetMs).toTimeString();
				var sWorkEnd = new Date(this.mProperties.opEnd.ms + TZOffsetMs).toTimeString();

				var sDropStart = new Date(oInterval.start).toTimeString();
				var sDropEnd = new Date(oInterval.end).toTimeString();

				if (oSession.oNewRow._oPlanningCalendarRow.checkCollision(oInterval.start, oInterval.end)) {
					MessageToast.show("Collision");
					return;
				}

				if (sDropStart < sWorkStart || sDropEnd > sWorkEnd) {
					var _fnClosePending = function(oAction) {
						if (oAction === "NO") {
							return;
						} else {
							oModel.setProperty("StartDate", oInterval.start, oContext, true);
							oModel.setProperty("EndDate", oInterval.end, oContext, true);

							var sOldBay = oSession.oOldRow._oPlanningCalendarRow.getBindingContext().getObject().BayId;
							var sNewBay = oSession.oNewRow._oPlanningCalendarRow.getBindingContext().getObject().BayId;

							if (sNewBay !== sOldBay) {
								oModel.setProperty("BayId", sNewBay, oContext, true);
								oSession.oOldRow._oPlanningCalendarRow._appointmentRemove(oContext.getPath().substr(1));
								oSession.oNewRow._oPlanningCalendarRow._appointmentAdd(oContext.getPath().substr(1));
							} else {
								oSession.oNewRow._oPlanningCalendarRow._bindAppointments();
							}
						}
					};
					// Warning if changes made
					sap.m.MessageBox.show("Appointment is before/after Operating Hour. Are you sure?", {
						icon: sap.m.MessageBox.Icon.WARNING, // default
						title: "Warning", // default
						actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO], // default
						styleClass: "", // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit, // default
						verticalScrolling: true, // default
						horizontalScrolling: true,
						onClose: _fnClosePending
					});
				} else {
					oModel.setProperty("StartDate", oInterval.start, oContext, true);
					oModel.setProperty("EndDate", oInterval.end, oContext, true);

					var sOldBay = oSession.oOldRow._oPlanningCalendarRow.getBindingContext().getObject().BayId;
					var sNewBay = oSession.oNewRow._oPlanningCalendarRow.getBindingContext().getObject().BayId;

					if (sNewBay !== sOldBay) {
						oModel.setProperty("BayId", sNewBay, oContext, true);
						oSession.oOldRow._oPlanningCalendarRow._appointmentRemove(oContext.getPath().substr(1));
						oSession.oNewRow._oPlanningCalendarRow._appointmentAdd(oContext.getPath().substr(1));
					} else {
						oSession.oNewRow._oPlanningCalendarRow._bindAppointments();
					}
				}
			},

			getCalendarRowDetails: function(oEvent, oSession) {
				var $Row, $RowInterval, $RowSubInterval;

				if (jQuery(oEvent.target).hasClass("sapUiCalendarRowAppsSubInt")) {
					$RowSubInterval = jQuery(oEvent.target);
					$RowInterval = $RowSubInterval.parents(".sapUiCalendarRowAppsInt");
					$Row = $RowInterval.parents(".sapUiCalendarRow");

					oSession.iInterval = $RowInterval.index();
					oSession.iSubInterval = $RowSubInterval.index();
					oSession.iSubIntervals = $RowInterval.children(".sapUiCalendarRowAppsSubInt").length;
					oSession.oNewRow = sap.ui.getCore().byId($Row.attr("id"));
				}
			},

			getTimeStartEnd: function(iDuration, oSession) {
				var oCalendarRow = oSession.oNewRow;
				var oStartDate = oCalendarRow._getStartDate();
				var oIntervalStartDate = new UniversalDate(oStartDate.getTime());
				var oIntervalEndDate;

				// calculate with hours, days and months and not timestamps and millisecons because of rounding issues

				oIntervalStartDate.setUTCHours(oIntervalStartDate.getUTCHours() + oSession.iInterval);
				if (oSession.iSubIntervals > 0) {
					oIntervalStartDate.setUTCMinutes(oIntervalStartDate.getUTCMinutes() + oSession.iSubInterval * 60 / oSession.iSubIntervals);
				}

				oIntervalEndDate = new UniversalDate(oIntervalStartDate.getTime());
				oIntervalEndDate.setUTCMilliseconds(oIntervalEndDate.getUTCMilliseconds() + iDuration);

				oIntervalStartDate = CalendarUtils._createLocalDate(oIntervalStartDate, true);
				oIntervalEndDate = CalendarUtils._createLocalDate(oIntervalEndDate, true);

				return {
					start: oIntervalStartDate,
					end: oIntervalEndDate
				};
			},

			_onResizeStart: function(oEvent) {
				var oAppointment = ElementUtil.getClosestElementForNode(oEvent.target);
				var oCalendarRow = oAppointment.getParent().getCalendarRow();

				// determine the direction of the resize
				this._bResize = oEvent.target.className === this.sStyleLeft || oEvent.target.className === this.sStyleRight;

				if (this._bResize) {
					this._oResizeSession = {
						oAppointment: oAppointment,
						sDirection: oEvent.target.className === this.sStyleLeft ? "left" : "right",
						oStartDate: oAppointment.getStartDate(),
						oEndDate: oAppointment.getEndDate(),
						oCalendarRow: oCalendarRow,
						iRowSize: oCalendarRow._oUTCEndDate.getTime() - oCalendarRow._oUTCStartDate.getTime(),
						iRowWidth: oCalendarRow.$().width()
					};

					jQuery(document).on("touchmove mousemove", this._onResizeMove.bind(this));
					jQuery(document).on("touchend touchcancel mouseup", this._onResizeEnd.bind(this));
				}
			},

			_onResizeMove: function(oEvent) {
				if (this._oResizeSession) {
					if (this._oResizeSession.sDirection === "left") {
						this._oResizeSession.oStartDate = this._calculateOffset(oEvent.pageX, this._oResizeSession);
					} else {
						this._oResizeSession.oEndDate = this._calculateOffset(oEvent.pageX, this._oResizeSession);
					}
					var oAppointmentStartDate = CalendarUtils._createUniversalUTCDate(this._oResizeSession.oStartDate, undefined, true);
					var oAppointmentEndDate = CalendarUtils._createUniversalUTCDate(this._oResizeSession.oEndDate, undefined, true);

					var iBegin = this._calculatePerCent(oAppointmentStartDate, true, this._oResizeSession);
					var iEnd = this._calculatePerCent(oAppointmentEndDate, false, this._oResizeSession);

					this._oResizeSession.oAppointment.$().css("left", iBegin + "%");
					this._oResizeSession.oAppointment.$().css("right", iEnd + "%");
				}
			},

			_onResizeEnd: function(oEvent) {
				oEvent.stopPropagation();
				oEvent.originalEvent.preventDefault();

				jQuery(document).off("touchmove mousemove", this._onResizeMove.bind(this));
				jQuery(document).off("touchend touchcancel mouseup", this._onResizeEnd.bind(this));

				this.setIsResizeDragging(false);
				if (this._oResizeSession) {
					if (this._oResizeSession.oCalendarRow._oPlanningCalendarRow.checkCollision(this._oResizeSession.oStartDate, this._oResizeSession.oEndDate,
							this._oResizeSession.oAppointment)) {
						MessageToast.show("Collision");
					} else {
						this._oResizeSession.oAppointment.setStartDate(this._oResizeSession.oStartDate);
						this._oResizeSession.oAppointment.setEndDate(this._oResizeSession.oEndDate);
					}
					this._oResizeSession.oCalendarRow._oPlanningCalendarRow._bindAppointments();
					this._oResizeSession = undefined;
				}
			},

			_calculateOffset: function(iPageX, oSession) {
				var oOffset = oSession.oCalendarRow.$().offset();
				var iDifference = iPageX - oOffset.left;
				var iTime = Math.floor(oSession.iRowSize * (iDifference / oSession.iRowWidth));
				var oDate = new Date(oSession.oCalendarRow.getStartDate().getTime() + iTime);

				// round to nearest 15 min
				var coeff = 1000 * 60 * 15;
				return new Date(Math.round(oDate.getTime() / coeff) * coeff);
			},

			_calculatePerCent: function(oAppointmentDate, bBegin, oSession) {
				var iPerCent = 0;
				var iStartTime = oSession.oCalendarRow._getStartDate().getTime();

				if (bBegin) {
					iPerCent = 100 * (oAppointmentDate.getTime() - iStartTime) / oSession.iRowSize;
				} else {
					iPerCent = 100 - (100 * (oAppointmentDate.getTime() - iStartTime) / oSession.iRowSize);
				}

				if (iPerCent < 0) {
					iPerCent = 0;
				}

				// round because of minimal calculation differences
				iPerCent = Math.round(iPerCent * 100000) / 100000;

				return iPerCent;
			}
		});

	}, /* bExport= */ true);