sap.ui.define([
	"sap/m/InputBase",
	"sap/m/DatePicker",
	"sap/m/TimePicker",
	"sap/m/HBox"
], function(Control, DatePicker, TimePicker, HBox) {
	"use strict";

	return Control.extend("ndbs.jcb.job.daily.controls.DateTime", {

		metadata: {
			properties: {
				dateValue: {
					type: "object",
					group: "Data",
					defaultValue: null
				},
				editable: {
					type: "boolean",
					group: "Data",
					defaultValue: true
				}
			},
			aggregations: {
				_datePicker: {
					type: "sap.m.DatePicker",
					multiple: false,
					visibility: "hidden"
				},
				_timePicker: {
					type: "sap.m.TimePicker",
					multiple: false,
					visibility: "hidden"
				}
			},
			events: {
				change: {
					parameters: {
						dateValue: {
							type: "object"
						}
					}
				}
			}
		},

		init: function() {
			this.oDatePicker = new DatePicker({
				displayFormat: "MM/dd/yyyy",
				change: this.onChange.bind(this)
			});
			this.oTimePicker = new TimePicker({
				displayFormat: "hh:mm a",
				change: this.onChange.bind(this)
			});

			this.oHBox = new HBox({
			    items: [this.oDatePicker, this.oTimePicker]
			});
			/*this.oHBox = new HBox({
				items: [this.oTimePicker]
			});*/

		},

		setDateValue: function(oDateValue) {
			this.setProperty("dateValue", oDateValue, true);
			this.oDatePicker.setProperty("dateValue", oDateValue, true);
			this.oTimePicker.setProperty("dateValue", oDateValue, true);
		},

		setEditable: function(bEditable) {
			this.setProperty("editable", bEditable, true);
			this.oDatePicker.setProperty("editable", bEditable, true);
			this.oTimePicker.setProperty("editable", bEditable, true);
		},

		setValueState: function(bState) {
			this.oDatePicker.setValueState(bState);
			this.oTimePicker.setValueState(bState);
		},

		setValueStateText: function(sMsg) {
			this.oDatePicker.setValueStateText(sMsg);
			this.oTimePicker.setValueStateText(sMsg);
		},

		onChange: function(oEvent) {
			var oSource = oEvent.getSource();
			var oNew = oSource.getDateValue();
			var oOld = this.getDateValue();
			var oDate;			
			if (oOld && oNew) { //17 Feb 2017 TC
				if (oOld.getTime() !== oNew.getTime()) {
					if (oSource.getMetadata().getName() === "sap.m.DatePicker") {
						oDate = this.newDate(oNew, oOld);
					} else {
						oDate = this.newDate(oOld, oNew);
					}
					this.setDateValue(oDate);
				}
			} else {
				//Added 17 Feb 2017 
				if (oSource.getMetadata().getName() === "sap.m.TimePicker") {
					oDate = this.newTime(oNew);
				} else {
					oDate = oNew;
				}
				this.setDateValue(oDate);
			}
		},
		
		onAfterRendering: function() {
			var oDateInner = this.oDatePicker.$().find('.sapMInputBaseInner');
			var oDateID = oDateInner[0].id;
			var oTimeInner = this.oTimePicker.$().find('.sapMInputBaseInner');
			var oTimeID = oTimeInner[0].id;

			$('#' + oDateID).attr("disabled", "disabled");
			$('#' + oTimeID).attr("disabled", "disabled");
		},

		newDate: function(oDate1, oDate2) {
			return new Date(oDate1.getFullYear(), oDate1.getMonth(), oDate1.getDate(), oDate2.getHours(), oDate2.getMinutes(), oDate2.getMilliseconds());
		},
		
		//17 Feb 2017 TC
		newTime: function(oDate1) {
			var oDate = new Date();
			return new Date(oDate.getFullYear(), oDate.getMonth(), oDate.getDate(), oDate1.getHours(), oDate1.getMinutes(), oDate1.getMilliseconds());
		},

		renderer: function(oRM, oControl) {
			oRM.renderControl(oControl.oHBox);

		}
	});

});