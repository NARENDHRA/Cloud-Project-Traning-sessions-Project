/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"htmlelements/Zsample_HtmlDemo/test/integration/AllJourneys"
	], function () {
		QUnit.start();
	});
});