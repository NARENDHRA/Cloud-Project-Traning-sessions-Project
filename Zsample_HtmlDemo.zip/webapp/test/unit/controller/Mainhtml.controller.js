/*global QUnit*/

sap.ui.define([
	"htmlelements/Zsample_HtmlDemo/controller/Mainhtml.controller"
], function (Controller) {
	"use strict";

	QUnit.module("Mainhtml Controller");

	QUnit.test("I should test the Mainhtml controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});