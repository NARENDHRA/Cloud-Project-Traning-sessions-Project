sap.ui.define([
	"htmlelements/Zsample_HtmlDemo/test/unit/controller/Mainhtml.controller"
], function () {
	"use strict";
});