sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("htmlelements.Zsample_HtmlDemo.controller.Mainhtml", {
		// onInit: function () {

		// },
		onClick: function (evt) {
			debugger;
			this.getView().byId("inputid").setEditable(true);
		}
	});
});