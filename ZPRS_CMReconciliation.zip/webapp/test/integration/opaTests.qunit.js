/* global QUnit */

QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function() {
	"use strict";

	sap.ui.require([
		"fgtcmrec/ZPRS_CMReconciliation/test/integration/AllJourneys"
	], function() {
		QUnit.start();
	});
});