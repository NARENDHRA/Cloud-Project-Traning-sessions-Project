sap.ui.define([
	"icexpreviewapproval/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"icexpreviewapproval/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageToast",
	"sap/m/MessageBox"
], function(BaseController, JSONModel, History, formatter, Filter, FilterOperator, MessageToast, MessageBox) {
	"use strict";

	return BaseController.extend("icexpreviewapproval.controller.Worklist", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function() {
			var oViewModel,
				iOriginalBusyDelay;
			// Model used to manipulate control states
			this._oAppStateSetData = {
				parmasFilter: []
			};

			oViewModel = new JSONModel({
				worklistTableTitle: this.getResourceBundle().getText("worklistTableTitle"),
				saveAsTileTitle: this.getResourceBundle().getText("worklistViewTitle"),
				shareOnJamTitle: this.getResourceBundle().getText("worklistViewTitle"),
				shareSendEmailSubject: this.getResourceBundle().getText("shareSendEmailWorklistSubject"),
				shareSendEmailMessage: this.getResourceBundle().getText("shareSendEmailWorklistMessage", [location.href]),
				tableNoDataText: this.getResourceBundle().getText("tableNoDataText"),
				tableBusyDelay: 0,
				Clearbt: false,
				Approvebt: true,
				visbutton: true,
				CompanyCodeName: "Receiving Legal Entity (RLE)",
				Office: "Receving Office",
				isSelected: false,
				billedLink: false,
				unbilledLink: true,
				oExptArray: [],
				VisFB03: false,
				VisZVA03: false,
				VisPrintDraft: false
			});
			this.setModel(oViewModel, "worklistView");
			this._oModel = this.getOwnerComponent().getModel();
			this._oModel.setDefaultBindingMode("TwoWay");
			this._inGlAccountValue();
			var oHashChanger = sap.ui.core.routing.HashChanger.getInstance();
			if (sap.ushell.Container !== undefined) {
				var that = this;
				// that.stateinitial = true;
				var sHash = oHashChanger.getHash();
				if (window.performance.navigation.type === 1) {
					// "This page is reloaded or refreshing the window"
					oHashChanger.setHash("");
					this.iswindowRefresh = true;
				}
				if (sHash) {
					var sAppStateKey = /(?:sap-iapp-state=)([^&=]+)/.exec(sHash)[1];
					var component = that.getOwnerComponent();
					sap.ushell.Container
						.getService("CrossApplicationNavigation")
						.getAppState(component, sAppStateKey)
						.done(function(oSavedAppState) {
							if (that.iswindowRefresh === undefined) {
								that._oInitAppSateSetting(oSavedAppState);
							}
						});
				}
			}
		},
		_oInitAppSateSetting: function(appstateData, stateAppinital) {
			this.stateAppinital = true;
			this.oBingparmfilter = appstateData.getData();
			var oAppStateFilterData = this.oBingparmfilter.parmasFilter;
			this.__SetFilterstoSmartFilterbar(oAppStateFilterData);
			this.getView().byId("ExpensesReviewApprovalId").search();
		},
		_inGlAccountValue: function() {
			var that = this;
			that.getView().setBusy(true);
			var sfid = that.byId("ExpensesReviewApprovalId");
			this._oModel.read("/HKONT_DATAS", {
				success: function(odata, res) {
					if (odata.results) {
						var GL = sfid.getControlByKey("Hkont");
						GL.setValue(odata.results[0].Hkont);
						// GL.setEnabled(false);
						that.oHkont = odata.results[0].Hkont;
						that.getView().setBusy(false);
					}
				},
				error: function(error) {
					MessageToast.show("error");
				}
			});
		},
		onInitSmartFilterBar: function(evt) {
			// that._inGlAccountValue();
			var s = evt.getSource(),
				Action = s.getControlByKey("Action"),
				oBukrst = s.getControlByKey("Bukrst");
			oBukrst.setEnabled(false);
			Action.setSelectedKey("RA");
			Action.setValue("For Review and Approve");
			// this.isSFBinitial = true;
		},
		onBeforeRebindTable: function(evt) {
			var src = evt.getSource(),
				SFID = this.getView().byId("ExpensesReviewApprovalId"),
				oBindingParams = evt.getParameter("bindingParams");
			oBindingParams.filters = oBindingParams.filters || [];
			oBindingParams.parameters = oBindingParams.parameters || {};
			this._initBindingTbl(SFID, oBindingParams);
		},
		_initBindingTbl: function(sFId, Params) {
			var afilter = [],
				i = 0,
				value, oFilter;
			var oFilterData = sFId.getFilterData(),
				oBukrst = sFId.getControlByKey("Bukrst"),
				oBukrs = sFId.getControlByKey("Bukrs"),
				oHkont = sFId.getControlByKey("Hkont"),
				oRecOfficet = sFId.getControlByKey("RecOfficet"),
				oAction = sFId.getControlByKey("Action"),
				oRecOffice = sFId.getControlByKey("RecOffice"),
				oRevAllRec = sFId.getControlByKey("RevAllRec");
			if (oBukrs !== undefined && oBukrst !== undefined) {
				value = oBukrs.getValue();
				oFilter = new Filter("Bukrs", FilterOperator.EQ, value);
				Params.filters.push(oFilter);
			}
			if (oRecOfficet !== undefined && oRecOffice !== undefined) {
				value = oRecOffice.getValue();
				oFilter = new Filter("RecOffice", FilterOperator.EQ, value);
				afilter.push(oFilter);
				Params.filters.push(oFilter);
			}
			if (oRevAllRec !== undefined) {
				var oKey = oRevAllRec.getSelected();
				if (oKey === false) {
					oFilter = new Filter("RevAllRec", FilterOperator.EQ, " ");
					Params.filters.push(oFilter);
				} else {
					oFilter = new Filter("RevAllRec", FilterOperator.EQ, "RA");
					Params.filters.push(oFilter);
				}
			}
			this._oAppStateSetData.parmasFilter = Params.filters;
		},
		onPressRefresh: function(evt) {
			var tbl = this.getView().byId("smartTable_ExpenReviewTableId0");
			var omodel = tbl.getTable().getModel();
			omodel.refresh(true);
			tbl.rebindTable();
		},
		/**
		 * Event handler when a table item gets pressed
		 * @param {sap.ui.base.Event} oEvent the table selectionChange event
		 * @public
		 */
		onPress: function(oEvent) {
			// The source is the list item that got pressed
			this._showObject(oEvent.getSource());
		},
		onApproveReviewExprensesPress: function(evt) {
			var oViewModel = this.getView().getModel("worklistView");
			var oBtAction = evt.getSource().getProperty("text"),
				tbl = this.getView().byId("smartTable_ExpenReviewTableId0").getTable(),
				oRows = tbl.getSelectedIndices();
			// this.oActionBt;
			this.oExptArray = [];
			this.BtID = evt.getParameters().id;
			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZPRS_SC_IC_EXP_REVIEW_SRV");
			if (oBtAction === "Clear") {
				this.oActionBt = "C";
			} else {
				this.oActionBt = "A";
			}
			if (oRows.length === 0) {
				var smsg = "Please select atleast one line item";
				sap.m.MessageBox.show(smsg, sap.m.MessageBox.Icon.WARNING, "WARNING");
				return;
			}
			tbl.setBusy(true);
			var batchChanges = [];
			var that = this;
			$.each(tbl.getSelectedIndices(), function(i, o) {
				var ctx = tbl.getContextByIndex(o),
					obj = ctx.getObject();
				obj.BtAction = that.oActionBt;
				delete(obj.__metadata);
				if (that.oActionBt === "A") {
					if (obj.Zuonr !== "APPROVED") {
						batchChanges.push(oModel.createBatchOperation("/EXP_REVIEWS", "POST", obj));
					} else {
						that.oExptArray.push(obj);
					}
				} else if (that.oActionBt === "C") {
					if (obj.Zuonr !== "") {
						batchChanges.push(oModel.createBatchOperation("/EXP_REVIEWS", "POST", obj));
					} else {
						that.oExptArray.push(obj);
					}
				}
			});
			if (batchChanges.length > 0) {
				oModel.addBatchChangeOperations(batchChanges);
				oModel.setUseBatch(true);
				// var that = this;
				oModel.submitBatch(function(data) {
						var errorData = {};
						errorData.results = [];
						var receivedData = data.__batchResponses[0].__changeResponses;
						// if (receivedData !== undefined) {
						$.each(tbl.getSelectedIndices(), function(inx, o) {
							var sobj = tbl.getContextByIndex(o).getObject();
							var a = receivedData.filter(function(obj) {
								return obj.data.Bukrs === sobj.Bukrs;
							});
							var ctx = tbl.getContextByIndex(o);
							var m = ctx.getModel(ctx.getPath());
							if (a.length >= 1) {
								m.setProperty(ctx.getPath() + "/Zuonr", a[0].data.Zuonr);
							}
						});

						if (that.oExptArray.length > 0) {
							var oarray = that.oExptArray,
								oAction = that.oActionBt;
							that.__ExceptionRaiseMethod(oarray, oAction);
						}
						tbl.setBusy(false);

					},
					function(oErr) {
						tbl.setBusy(false);
					});
			} else {
				if (that.oExptArray.length > 0) {
					var oarray = that.oExptArray,
						oAction = that.oActionBt;
					that.__ExceptionRaiseMethod(oarray, oAction);
				}
				tbl.setBusy(false);
			}
		},

		/**
		 * Event handler for navigating back.
		 * It there is a history entry or an previous app-to-app navigation we go one step back in the browser history
		 * If not, it will navigate to the shell home
		 * @public
		 */
		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				oCrossAppNavigator.toExternal({
					target: {
						shellHash: "#Shell-home"
					}
				});
			}
		},
		onBeforeExport: function(oEvnt) {
			oEvnt.mParameters.exportSettings.fileName = "IC Expenses Review & Approval";
			var oColumns = oEvnt.mParameters.exportSettings.workbook.columns,
				df = new sap.ui.model.type.Date().getOutputPattern();
			$.each(oColumns, function(i, obj) {
				if (obj.property === "PostDate") {
					obj.type = "date";
					obj.format = df.toLowerCase();
					obj.width = 18;
				}
			});
		},

		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */

		/**
		 * Shows the selected item on the object page
		 * On phones a additional history entry is created
		 * @param {sap.m.ObjectListItem} oItem selected Item
		 * @private
		 */
		_showObject: function(oItem) {
			this.getRouter().navTo("object", {
				objectId: oItem.getBindingContext().getProperty("Belnr")
			});
		},

		onfilterchange: function(evt) {
			var sfid = this.byId("ExpensesReviewApprovalId");
			var ovalSel = sfid.getControlByKey("Action").getValue();
			var oGLAccount = sfid.getControlByKey("Hkont").getValue();
			var oViewModel = this.getView().getModel("worklistView");
			var selcted = oViewModel.getProperty("/isSelected");
			if (oGLAccount !== this.oHkont) {
				var smg = "Please enter G/L Account " + this.oHkont + " " + "only";
				MessageBox.warning(smg);
			}
			if (ovalSel === "Billed" || ovalSel === "Billed and Cleared") {
				if (selcted === false) {
					oViewModel.setProperty("/visbutton", false);
					// oViewModel.setProperty("/billedLink", true);
					oViewModel.setProperty("/unbilledLink", true);
				}
			} else if (ovalSel === "For Review and Approval") {
				if (selcted === false) {
					oViewModel.setProperty("/Approvebt", true);
					oViewModel.setProperty("/Clearbt", false);
					oViewModel.setProperty("/visbutton", true);
					// oViewModel.setProperty("/billedLink", false);
					oViewModel.setProperty("/unbilledLink", false);
				}

			} else if (ovalSel === "Approved, To Be Billed") {
				if (selcted === false) {
					oViewModel.setProperty("/Approvebt", false);
					oViewModel.setProperty("/Clearbt", true);
					oViewModel.setProperty("/visbutton", true);
					// oViewModel.setProperty("/billedLink", false);
					oViewModel.setProperty("/unbilledLink", false);
				}
			}

		},
		onChangeCheckBoxSelection: function(evt) {
			var oViewModel = this.getView().getModel("worklistView");
			var selected = evt.getParameters("selected").selected;
			var sfid = this.byId("ExpensesReviewApprovalId");
			var ovalSel = sfid.getControlByKey("Action").getValue();
			if (selected === true) {
				oViewModel.setProperty("/isSelected", true);
				oViewModel.setProperty("/CompanyCodeName", "Sending Legal Entity (SLE)");
				oViewModel.setProperty("/Office", "Sending Office");
				oViewModel.setProperty("/Approvebt", false);
				oViewModel.setProperty("/Clearbt", false);
				oViewModel.setProperty("/visbutton", false);
			} else {
				oViewModel.setProperty("/isSelected", false);
				oViewModel.setProperty("/CompanyCodeName", "Receiving Legal Entity (RLE)");
				oViewModel.setProperty("/Office", "Receiving Office");
				if (ovalSel === "Billed" || ovalSel === "Billed and Cleared") {
					oViewModel.setProperty("/visbutton", false);
				} else if (ovalSel === "For Review and Approval") {
					oViewModel.setProperty("/Approvebt", true);
					oViewModel.setProperty("/Clearbt", false);
					oViewModel.setProperty("/visbutton", true);

				} else if (ovalSel === "Approved, To Be Billed") {
					oViewModel.setProperty("/Approvebt", false);
					oViewModel.setProperty("/Clearbt", true);
					oViewModel.setProperty("/visbutton", true);
				}
			}
		},
		onShowPopUp: function(evt) {
			var src = evt.getSource(),
				fragPath = "icexpreviewapproval.fragments.Assignment";

			if (!this.oQuick) {
				this.oQuick = sap.ui.xmlfragment(fragPath, this);
				this.getView().addDependent(this.oQuick);
			}
			this.oQuick.setBindingContext(src.getBindingContext());
			this.oQuick.openBy(evt.getSource());
		},
		onbeforeOpenPOPUP: function(evt) {
			var oModel = this.getView().getModel("worklistView");
			var obj = evt.getSource().getBindingContext().getObject();
			if (obj.IsError === "F") {
				oModel.setProperty("/VisPrintDraft", true);
				oModel.setProperty("/VisFB03", true);
				oModel.setProperty("/VisZVA03", false);
			} else if (obj.IsError === "D") {
				oModel.setProperty("/VisPrintDraft", false);
				oModel.setProperty("/VisZVA03", true);
				oModel.setProperty("/VisFB03", false);
			}
		},
		onAfterClosePOPUP: function(evt) {
			var oModel = this.getView().getModel("worklistView");
			var obj = evt.getSource().getBindingContext().getObject();
			if (obj.IsError === "F") {
				oModel.setProperty("/VisPrintDraft", false);
				oModel.setProperty("/VisFB03", false);
				oModel.setProperty("/VisZVA03", false);
			} else if (obj.IsError === "D") {
				oModel.setProperty("/VisPrintDraft", false);
				oModel.setProperty("/VisFB03", false);
				oModel.setProperty("/VisZVA03", false);
			}
		},
		onManageJournalEntry: function(evt) {
			var ICARDoCNo = true;
			this.handleDcoumentDisplay(evt, ICARDoCNo);
		},
		onPressDocumentNo: function(evt) {
			this.switchApp(evt);
		},
		onPressPrintPDF: function(evt) {
			var param_1, param_2;
			var src = evt.getSource(),
				obj = src.getBindingContext().getObject();
			//if(obj.IsError === "D"){
			//	param_1 = obj.IsError;
			//}else 
			if (obj.IsError === "F") {
				param_1 = obj.IsError;
			}
			param_2 = obj.Zuonr;
			var printUrl =
				"/sap/opu/odata/SAP/ZPRS_SC_IC_EXP_REVIEW_SRV/PDFS(Kappl=" + "'" + param_1 + "'" + ",Vbeln='" + param_2 + "')/$value";
			sap.m.URLHelper.redirect(printUrl, true);
		},
		switchApp: function(oEvent) {
			var s1 = oEvent.getSource(),
				obj1 = s1.getBindingContext().getObject();
			var oAssign = obj1.Zuonr;
			var oCrossAppNav = sap.ushell.Container.getService("CrossApplicationNavigation");
			oCrossAppNav.toExternal({
				target: {
					semanticObject: "ZVA03",
					action: "display"
				},
				params: {
					"OrdNum": oAssign
				}
			});
		},
		handleInterApDocDisplay: function(evt) {
			var ICARDoCNo = "InterApDoc";
			this.handleDcoumentDisplay(evt, ICARDoCNo);
		},

		handleDcoumentDisplay: function(evt, ICARDoCNo) {
			var oACTCOC, oCompanyCode, oFiscalYear;
			this.iswindowRefresh = false;
			var s = evt.getSource(),
				obj = s.getBindingContext().getObject();
			if (ICARDoCNo === true) {
				oACTCOC = obj.Zuonr;
				oCompanyCode = obj.Bukrs;
				oFiscalYear = obj.Gjahr;
			} else if (ICARDoCNo === "InterApDoc") {
				oACTCOC = obj.InterApDoc;
				oCompanyCode = obj.BurksR;
				oFiscalYear = obj.PostDate.getUTCFullYear().toString();
			}
			if (ICARDoCNo === undefined) {
				oACTCOC = obj.Belnr;
				oCompanyCode = obj.Bukrs;
				oFiscalYear = obj.Gjahr;
			}
			var oParamters = {
				"AccountingDocument": oACTCOC,
				"CompanyCode": oCompanyCode,
				"FiscalYear": oFiscalYear
			};

			// create a new Application state (oAppState) for this Application instance
			this._oAppState = sap.ushell.Container.getService("AppState");
			var oStateAppinit = this._oAppState.createEmptyAppState(this.getOwnerComponent());
			oStateAppinit.setData(this._oAppStateSetData); // object of values needed to be restored
			oStateAppinit.save();
			this._oHashChanger = sap.ui.core.routing.HashChanger.getInstance();
			var sNewHash = "?" + "sap-iapp-state=" + oStateAppinit.getKey();
			this._oHashChanger.replaceHash(sNewHash);

			var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
				target: {
					semanticObject: "AccountingDocument",
					action: "manage"
				},
				params: oParamters,
				appStateKey: oStateAppinit.getKey()
			})) || "";
			oCrossAppNavigator.toExternal({
				target: {
					shellHash: hash
				}
			});

		},
		onAssignedFiltersChanged: function(oEvent) {
			this.byId("statusDyPage").setText(this.byId("ExpensesReviewApprovalId").retrieveFiltersWithValuesAsText());
		}
	});
});