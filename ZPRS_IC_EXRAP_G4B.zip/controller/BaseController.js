sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function(Controller, JSONModel) {
	"use strict";

	return Controller.extend("icexpreviewapproval.controller.BaseController", {
		/**
		 * Convenience method for accessing the router.
		 * @public
		 * @returns {sap.ui.core.routing.Router} the router for this component
		 */
		getRouter: function() {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},

		/**
		 * Convenience method for getting the view model by name.
		 * @public
		 * @param {string} [sName] the model name
		 * @returns {sap.ui.model.Model} the model instance
		 */
		getModel: function(sName) {
			return this.getView().getModel(sName);
		},

		/**
		 * Convenience method for setting the view model.
		 * @public
		 * @param {sap.ui.model.Model} oModel the model instance
		 * @param {string} sName the model name
		 * @returns {sap.ui.mvc.View} the view instance
		 */
		setModel: function(oModel, sName) {
			return this.getView().setModel(oModel, sName);
		},

		/**
		 * Getter for the resource bundle.
		 * @public
		 * @returns {sap.ui.model.resource.ResourceModel} the resourceModel of the component
		 */
		getResourceBundle: function() {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},
		__ExceptionRaiseMethod: function(res, action) {
			// Document number 12000000 's line item 004 has already APPROVED"
			var omodel = new JSONModel();
			for (var i = 0; i < res.length; i++) {
				if (action === "C") {
					res[i].IsError = "Document number " + res[i].Belnr + "'s" + " " + "line item " + res[i].Buzei + " " + " has already CLEARED";
					var sId = "ClearBtIds";
				} else {
					res[i].IsError = "Document number " + res[i].Belnr + "'s" + " " + "line item " + res[i].Buzei + " " + "has already APPROVED";
					sId = "ERAApproveIds";
				}
			}
			omodel.setData({
				results: res
			});
			if (!this._errorpopover) {
				this._errorpopover = sap.ui.xmlfragment(this.getView().getId(), "icexpreviewapproval.fragments.ErrorDetails",
					this);
				this.getView().addDependent(this._errorpopover);
			}
			this._errorpopover.openBy(this.getView().byId(sId));
			this._errorpopover.setModel(omodel, "ErrorModel");
		},
		/**
		 * Event handler when the share by E-Mail button has been clicked
		 * @public
		 */
		onShareEmailPress: function() {
			var oViewModel = (this.getModel("objectView") || this.getModel("worklistView"));
			sap.m.URLHelper.triggerEmail(
				null,
				oViewModel.getProperty("/shareSendEmailSubject"),
				oViewModel.getProperty("/shareSendEmailMessage")
			);
		},
		__SetFilterstoSmartFilterbar: function(filters) {
			var dateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
				pattern: "MM.dd.yyyy",
				UTC: true
			});
			var oViewModel = this.getView().getModel("worklistView");
			var sfBId = this.getView().byId("ExpensesReviewApprovalId");
			var oCheckSelected = oViewModel.getProperty("/isSelected");
			for (var i = 0; i < filters[0].aFilters.length; i++) {
				var sKey = filters[0].aFilters[i].sPath;
				if (sKey !== "EntryDate" && sKey !== "Action") {
					var val = val = filters[0].aFilters[i].oValue1;
					sfBId.getControlByKey(sKey).setValue(val);
				}
				if (sKey === "EntryDate" || sKey === "PostDate") {
					var oVal1 = filters[0].aFilters[i].oValue1.split("T")[0],
						oVal2 = filters[0].aFilters[i].oValue2.split("T")[0];
					if (oVal1) {
						var oFInVal1 = dateFormat.format(new Date(oVal1));
						sfBId.getControlByKey(sKey).setDateValue(new Date(oFInVal1));
					}
					if (oVal2) {
						var oFInVal2 = dateFormat.format(new Date(oVal2));
						sfBId.getControlByKey(sKey).setSecondDateValue(new Date(oFInVal2));
					}
				}
				if (sKey === "Action") {
					var valA = filters[0].aFilters[i].oValue1;
					if (valA === "RA") {
						var sval = "For Review and Approval";
					} else if (valA === "BI") {
						sval = "Billed";
					} else if (valA === "TB") {
						sval = "Approved, To Be Billed";
					} else if (valA === "BC") {
						sval = "Billed and Cleared";
					}
					sfBId.getControlByKey(sKey).setSelectedKey(valA);
					sfBId.getControlByKey(sKey).setValue(sval);
					this.oActionkey = sfBId.getControlByKey(sKey).getValue();
					if (valA === "BI" || valA === "BC") {
						if (oCheckSelected === false) {
							oViewModel.setProperty("/visbutton", false);
							oViewModel.setProperty("/unbilledLink", true);
						}
					} else if (valA === "RA") {
						if (oCheckSelected === false) {
							oViewModel.setProperty("/Approvebt", true);
							oViewModel.setProperty("/Clearbt", false);
							oViewModel.setProperty("/visbutton", true);
							oViewModel.setProperty("/unbilledLink", false);
						}

					} else if (valA === "TB") {
						if (oCheckSelected === false) {
							oViewModel.setProperty("/Approvebt", false);
							oViewModel.setProperty("/Clearbt", true);
							oViewModel.setProperty("/visbutton", true);
							oViewModel.setProperty("/unbilledLink", false);
						}
					}
					//ReportingOption for CheckBox Selected..
					if (oCheckSelected === true) {
						oViewModel.setProperty("/isSelected", true);
						oViewModel.setProperty("/CompanyCodeName", "Sending Legal Entity (SLE)");
						oViewModel.setProperty("/Office", "Sending Office");
						oViewModel.setProperty("/Approvebt", false);
						oViewModel.setProperty("/Clearbt", false);
						oViewModel.setProperty("/visbutton", false);
					} else {
						oViewModel.setProperty("/isSelected", false);
						oViewModel.setProperty("/CompanyCodeName", "Receiving Legal Entity (RLE)");
						oViewModel.setProperty("/Office", "Receiving Office");
						if (this.oActionkey === "Billed" || this.oActionkey === "Billed and Cleared") {
							oViewModel.setProperty("/visbutton", false);
							oViewModel.setProperty("/unbilledLink", true);
						} else if (this.oActionkey === "For Review and Approval") {
							oViewModel.setProperty("/Approvebt", true);
							oViewModel.setProperty("/Clearbt", false);
							oViewModel.setProperty("/visbutton", true);
							oViewModel.setProperty("/unbilledLink", false);

						} else if (this.oActionkey === "Approved, To Be Billed") {
							oViewModel.setProperty("/Approvebt", false);
							oViewModel.setProperty("/Clearbt", true);
							oViewModel.setProperty("/visbutton", true);
							oViewModel.setProperty("/unbilledLink", false);
						}
					}
				}

			}
			for (var j = 1; j < filters.length; j++) {
				var oVal = filters[j].oValue1;
				var oSkey = filters[j].sPath;
				if (oSkey !== "RevAllRec") {
					sfBId.getControlByKey(oSkey).setValue(oVal);
				} else {
					if (oVal === " ") {
						sfBId.getControlByKey("RevAllRec").setSelected(false);

					} else {
						sfBId.getControlByKey("RevAllRec").setSelected(true);
					}
				}
				if (oVal !== " ") {
					oViewModel.setProperty("/isSelected", true);
					oViewModel.setProperty("/CompanyCodeName", "Sending Legal Entity (SLE)");
					oViewModel.setProperty("/Office", "Sending Office");
					oViewModel.setProperty("/Approvebt", false);
					oViewModel.setProperty("/Clearbt", false);
					oViewModel.setProperty("/visbutton", false);
				} else {
					oViewModel.setProperty("/isSelected", false);
					oViewModel.setProperty("/CompanyCodeName", "Receiving Legal Entity (RLE)");
					oViewModel.setProperty("/Office", "Receiving Office");
					if (this.oActionkey === "Billed" || this.oActionkey === "Billed and Cleared") {
						oViewModel.setProperty("/visbutton", false);
					} else if (this.oActionkey === "For Review and Approve") {
						oViewModel.setProperty("/Approvebt", true);
						oViewModel.setProperty("/Clearbt", false);
						oViewModel.setProperty("/visbutton", true);

					} else if (this.oActionkey === "Approved, To Be Billed") {
						oViewModel.setProperty("/Approvebt", false);
						oViewModel.setProperty("/Clearbt", true);
						oViewModel.setProperty("/visbutton", true);
					}
				}
			}
		}

	});

});