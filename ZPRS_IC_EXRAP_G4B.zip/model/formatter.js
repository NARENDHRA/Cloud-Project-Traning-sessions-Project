sap.ui.define([], function() {
	"use strict";

	return {

		/**
		 * Rounds the number unit value to 2 digits
		 * @public
		 * @param {string} sValue the number string to be rounded
		 * @returns {string} sValue with 2 digits rounded
		 */
		numberUnit: function(sValue) {
			if (!sValue) {
				return "";
			}
			return parseFloat(sValue).toFixed(2);
		},
		myFormatterVisble: function(val) {
			if (val === "F") {
				return true;
			} else {
				return false;
			}
		},
		myFormatterSVisble: function(val) {
			if (val === "D") {
				return true;
			} else {
				return false;
			}
		},
		// 	convertTimestamp: function(date) {
		// 					var dt = date.split("T");
		// 					// var fine = dt[0].concat("T" + c);
		// 					var dateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
		// 											style: "medium",UTC:true
		// 										});
		// 					var fdt = new Date(dt);
		// 					var TZOffsetMs = fdt.getTimezoneOffset() * 60 * 1000;
		// 					var dateStr = dateFormat.format(new Date(fdt));
		// 					return dateStr;
		// 	/*var sDate = oDate.split("T");
		// 	var sTime = oTime.slice(2, 4) + ":" + oTime.slice(5, 7) + ":" + oTime.slice(8, 10);
		// 	var sTimestamp = sDate[0].concat("," + " " + sTime);
		// 	return sTimestamp;*/
		// },

	};

});