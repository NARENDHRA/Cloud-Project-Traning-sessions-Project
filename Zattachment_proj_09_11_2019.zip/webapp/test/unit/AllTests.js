sap.ui.define([
	"attchment/Zattachment_proj/test/unit/controller/View1.controller"
], function () {
	"use strict";
});