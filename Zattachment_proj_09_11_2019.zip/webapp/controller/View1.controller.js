sap.ui.define([
	"sap/ui/core/mvc/Controller",
	'sap/ui/core/Fragment',
	'sap/ui/model/json/JSONModel'
], function (Controller, Fragment, JSONModel) {
	"use strict";

	return Controller.extend("attchment.Zattachment_proj.controller.View1", {
		onInit: function () {

			var oObj = {
				"resultsScore": [{
					"key": "1",
					"text": "1"
				}, {
					"key": "2",
					"text": "2"
				}, {
					"key": "3",
					"text": "3"
				}],
				"tableitems": [{
					"itemmNo": "0001",
					"ParmId": "FS01",
					"Catgery": "Buliding Location",
					"require": "AAAAAAAAAAAAAAAAAAAAA",
					"Observ": "",
					"score": "000",
					"yesno": "",
					"Quantity": "5.000",
					"Rep": "2",
					"fine": "1500.000",
					"attachData0001": [],
					"editable": false
				}, {
					"itemmNo": "0002",
					"ParmId": "FS02",
					"Catgery": "Buliding Structure",
					"require": "AAAAAAAAAAAAAAAAAAAAA",
					"Observ": "",
					"score": "000",
					"yesno": "",
					"Quantity": "0.000",
					"Rep": "2",
					"fine": "15000.00",
					"attachData0002": [],
					"editable": false
				}, {
					"itemmNo": "0003",
					"ParmId": "FS03",
					"Catgery": "Equipment Design construction",
					"require": "CCCCCCCCCCCCCCCCCC",
					"Observ": "",
					"score": "0004",
					"yesno": "",
					"Quantity": "0.000",
					"Rep": "0",
					"fine": "0.00",
					"attachData0003": [],
					"editable": false
				}, {
					"itemmNo": "0004",
					"ParmId": "FS04",
					"Catgery": "Equipment Operation",
					"require": "DDDDDDDDDDDDDDDD",
					"Observ": "",
					"score": "000",
					"yesno": "yes/no",
					"Quantity": "0.000",
					"Rep": "0",
					"fine": "0.000",
					"attachData0004": [],
					"editable": false
				}, {
					"itemmNo": "0005",
					"ParmId": "FS05",
					"Catgery": "Equipment Operation",
					"require": "EEEEEEEE",
					"Observ": "",
					"score": "111",
					"yesno": "",
					"Quantity": "0.000",
					"Rep": "0",
					"fine": "0.000",
					"attachData0005": [],
					"editable": false
				}]
			};
			var oModel = new sap.ui.model.json.JSONModel();
			oModel.setData(oObj);
			this.getView().setModel(oModel, "AttachModel");
			this._ofileArray = [];
		},
		onPressAttachment: function (oEvent) {
			var sPath = oEvent.getSource().getParent().getParent().getBindingContextPath();
			var oAttachModel1 = new JSONModel();
			var oModel = this.getView().getModel("AttachModel");
			this.oSelObj = oModel.getProperty(sPath);
			var obj = {};
			if (this.oSelObj.attachData0001) {
				obj["attchresults"] = this.oSelObj.attachData0001;
			} else if (this.oSelObj.attachData0002) {
				obj["attchresults"] = this.oSelObj.attachData0002;
			} else if (this.oSelObj.attachData0003) {
				obj["attchresults"] = this.oSelObj.attachData0003;
			} else if (this.oSelObj.attachData0004) {
				obj["attchresults"] = this.oSelObj.attachData0004;
			} else if (this.oSelObj.attachData0005) {
				obj["attchresults"] = this.oSelObj.attachData0005;
			}
			oAttachModel1.setData(obj);
			// var oButton = oEvent.getSource();
			if (!this._oDialog) {
				Fragment.load({
					name: "attchment.Zattachment_proj.fragments.attachments",
					controller: this
				}).then(function (oDialog) {
					this._oDialog = oDialog;
					// this._oDialog.setModel(this.getView().getModel("AttachModel"), "AttachModel1");
					this._oDialog.setModel(oAttachModel1, "AttachModel1");
					this._oDialog.open();
				}.bind(this));
			} else {
				this._oDialog.setModel(oAttachModel1, "AttachModel1");
				this._oDialog.open();
			}
		},
		onSelectionChange: function (oEvent) {
			var oKey = oEvent.getSource().getSelectedKey();
			var oTable = this.getView().byId("idProductsTable");
			var oitems = oTable.getItems();
			var currentRow = oEvent.getSource().getParent();
			var path = oEvent.getSource().oPropagatedProperties.oBindingContexts.AttachModel.sPath.split("/")[2];
			if (oKey === "3") {
				currentRow.getCells()[4].setEnabled(true);
			} else {
				currentRow.getCells()[4].setEnabled(false);
				currentRow.getCells()[4].setValue("");
			}
		},
		onCancelPress: function (evt) {
			// sap.ui.getCore().byId("UploadCollection").getItems()[0].destroy();
			this._oDialog.close();

		},
		ojsonModelSavearraydata: function (ofiledataarry, a) {
			if (ofiledataarry.length !== 0) {
				for (var i = 0; i < ofiledataarry.length; i++) {
					var mimeDet = ofiledataarry[i].type,
						fileName = ofiledataarry[i].name;
					this.base64coonversionMethod(mimeDet, fileName, ofiledataarry[i], "001", a);
				}
			}
		},
		onSavePress: function (oEvnt) {
			var sObj = this.oSelObj;
			var a;
			var ofiledataarry = this._ofileArray;
			if (this.oSelObj.attachData0001) {
				a = sObj.attachData0001;
				this.ojsonModelSavearraydata(ofiledataarry, a);
			} else if (this.oSelObj.attachData0002) {
				a = sObj.attachData0002;
				this.ojsonModelSavearraydata(ofiledataarry, a);
			} else if (this.oSelObj.attachData0003) {
				a = sObj.attachData0003;
				this.ojsonModelSavearraydata(ofiledataarry, a);
			} else if (this.oSelObj.attachData0004) {
				a = sObj.attachData0004;
				this.ojsonModelSavearraydata(ofiledataarry, a);
			} else if (this.oSelObj.attachData0005) {
				a = sObj.attachData0005;
				this.ojsonModelSavearraydata(ofiledataarry, a);
			}
			this._ofileArray = [];
			this._oDialog.close();
			console.log(a[0]);
		},
		onChange: function (oEvent) {
			var fileDetails = oEvent.getParameters("file").files[0];
			this._ofileArray.push(fileDetails);
			sap.ui.getCore().fileUploadArr = [];
			// if (fileDetails) {
			// 	var mimeDet = fileDetails.type,
			// 		fileName = fileDetails.name;

			// 	// Calling method....
			// 	this.base64coonversionMethod(mimeDet, fileName, fileDetails, "001");
			// } else {
			// 	sap.ui.getCore().fileUploadArr = [];
			// }
		},

		// Base64 conversion of selected file(Called method)....
		base64coonversionMethod: function (fileMime, fileName, fileDetails, DocNum, a) {
			var that = this;
			if (!FileReader.prototype.readAsBinaryString) {
				FileReader.prototype.readAsBinaryString = function (fileData) {
					var binary = "";
					var reader = new FileReader();
					reader.onload = function (e) {
						var bytes = new Uint8Array(reader.result);
						var length = bytes.byteLength;
						for (var i = 0; i < length; i++) {
							binary += String.fromCharCode(bytes[i]);
						}
						that.base64ConversionRes = btoa(binary);
						a.push({
							"DocumentType": DocNum,
							"MimeType": fileMime,
							"FileName": fileName,
							"Content": that.base64ConversionRes
						});
					};
					reader.readAsArrayBuffer(fileData);
				};
			}
			var reader = new FileReader();
			reader.onload = function (readerEvt) {
				var binaryString = readerEvt.target.result;
				that.base64ConversionRes = btoa(binaryString);
				a.push({
					"DocumentType": DocNum,
					"MimeType": fileMime,
					"FileName": fileName,
					"Content": that.base64ConversionRes

				});
			};
			reader.readAsBinaryString(fileDetails);
		},
		onPressViewItem: function (oEvent) {

			var omgModel = new JSONModel({
				"src": ""
			});
			this.oContent = "";
			var omodelData = oEvent.getSource()._oListItem._oUploadCollectionItem.oBindingContexts.AtachlistModel12.oModel.oData.results;
			var oFilename = oEvent.getSource().getFileName();
			for (var i = 0; i < omodelData.length; i++) {
				var oDatamodelfilename = omodelData[i].FileName;
				if (oFilename === oDatamodelfilename) {
					this.oContent = omodelData[i].Content;
				}
			}
			if (!this._oImgDialog) {
				Fragment.load({
					name: "attchment.Zattachment_proj.fragments.imageAttach",
					controller: this
				}).then(function (_oImgDialog) {
					this._oImgDialog = _oImgDialog;
					this._oImgDialog.setModel(omgModel, "omgModel1");
					var o = "data:image/bmp;base64," + this.oContent;
					this._oImgDialog.getModel("omgModel1").setProperty("/src", o);
					this._oImgDialog.open();

				}.bind(this));
			} else {
				this._oImgDialog.setModel(omgModel, "omgModel1");
				var o = "data:image/bmp;base64," + this.oContent;
				this._oImgDialog.getModel("omgModel1").setProperty("/src", o);
				this._oImgDialog.open();
			}

			// var oimg = new sap.m.Image();
			// var o = "data:image/bmp;base64," + this.oAttachObj.attachData[0].Content;
			// console.log(oimg.setSrc(o);
		},
		onPressImgDiagClose: function (evt) {
			this._oImgDialog.close();
		},
		handleResponsivePopoverPress: function (oEvent) {
			var oButton = oEvent.getSource();
			var sObjImgdata;
			var iPath = oEvent.getSource().getParent().getParent().getBindingContextPath();
			var oModel = this.getView().getModel("AttachModel");
			this.oAttachObj = oModel.getProperty(iPath);
			if (this.oAttachObj.attachData0001) {
				sObjImgdata = this.oAttachObj.attachData0001;
			} else if (this.oAttachObj.attachData0002) {
				sObjImgdata = this.oAttachObj.attachData0002;
			} else if (this.oAttachObj.attachData0003) {
				sObjImgdata = this.oAttachObj.attachData0003;
			} else if (this.oAttachObj.attachData0004) {
				sObjImgdata = this.oAttachObj.attachData0004;
			} else if (this.oAttachObj.attachData0005) {
				sObjImgdata = this.oAttachObj.attachData0005;
			}
			var oAtachlistModel = new JSONModel({
				results: sObjImgdata
			});
			if (sObjImgdata.length === 0) {
				sap.m.MessageToast.show("No attachements available for Selected Line Item");
			} else {
				if (!this._oPopover) {
					Fragment.load({
						name: "attchment.Zattachment_proj.fragments.POPOverAttach",
						controller: this
					}).then(function (oPopover) {
						this._oPopover = oPopover;
						this._oPopover.setModel(oAtachlistModel, "AtachlistModel12");
						this.getView().addDependent(this._oPopover);
						this._oPopover.openBy(oButton);
					}.bind(this));
				} else {
					this._oPopover.setModel(oAtachlistModel, "AtachlistModel12");
					this._oPopover.openBy(oButton);
				}
			}

		}

	});
});