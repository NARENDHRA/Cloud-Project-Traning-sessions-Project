/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
sap.ui.base.Object.extend("cus.crm.myaccounts.controller.SearchController",{constructor:function(){},onInit:function(){}});
