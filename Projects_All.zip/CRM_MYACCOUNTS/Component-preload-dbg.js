jQuery.sap.registerPreloadedModules({
"name":"cus/crm/myaccounts/Component-preload",
"version":"2.0",
"modules":{
	"cus/crm/myaccounts/Component.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
// define a root UIComponent which exposes the main view
jQuery.sap.declare("cus.crm.myaccounts.Component");
jQuery.sap.require("sap.ca.scfld.md.ComponentBase");
jQuery.sap.require("sap.ui.core.routing.HashChanger");
jQuery.sap.require("cus.crm.myaccounts.util.Util");
sap.ca.scfld.md.ComponentBase.extend("cus.crm.myaccounts.Component", {

    metadata : sap.ca.scfld.md.ComponentBase.createMetaData("FS", {
	"name" : "My Accounts",
	"version" : "1.6.5",
	"library" : "cus.crm.myaccounts",
	"includes" : ["css/app.css"],  
	"dependencies" : {
	    "libs" : [ "sap.m", "sap.me" ],
	    "components" : []
	},
	"config" : {
	    "resourceBundle" : "i18n/i18n.properties",
	    "titleResource" : "FULLSCREEN_TITLE",
	    "icon" : "sap-icon://Fiori2/F0002",
	    "favIcon" : "./resources/sap/ca/ui/themes/base/img/favicon/F0002_My_Accounts.ico",
	    "homeScreenIconPhone" : "./resources/sap/ca/ui/themes/base/img/launchicon/F0002_My_Accounts/57_iPhone_Desktop_Launch.png",
	    "homeScreenIconPhone@2" : "./resources/sap/ca/ui/themes/base/img/launchicon/F0002_My_Accounts/114_iPhone-Retina_Web_Clip.png",
	    "homeScreenIconTablet" : "./resources/sap/ca/ui/themes/base/img/launchicon/F0002_My_Accounts/72_iPad_Desktop_Launch.png",
	    "homeScreenIconTablet@2" : "./resources/sap/ca/ui/themes/base/img/launchicon/F0002_My_Accounts/144_iPad_Retina_Web_Clip.png",
	    "startupImage320x460" : "./resources/sap/ca/ui/themes/base/img/splashscreen/320_x_460.png",
	    "startupImage640x920" : "./resources/sap/ca/ui/themes/base/img/splashscreen/640_x_920.png",
	    "startupImage640x1096" : "./resources/sap/ca/ui/themes/base/img/splashscreen/640_x_1096.png",
	    "startupImage768x1004" : "./resources/sap/ca/ui/themes/base/img/splashscreen/768_x_1004.png",
	    "startupImage748x1024" : "./resources/sap/ca/ui/themes/base/img/splashscreen/748_x_1024.png",
	    "startupImage1536x2008" : "./resources/sap/ca/ui/themes/base/img/splashscreen/1536_x_2008.png",
	    "startupImage1496x2048" : "./resources/sap/ca/ui/themes/base/img/splashscreen/1496_x_2048.png"
	},
	viewPath : "cus.crm.myaccounts.view",
	fullScreenPageRoutes : {
		
		"S2" : {
		pattern : "",
		view : "search.SearchResult"

	    },
	    "mainPage" : {
			pattern : "mainPage/{filterState}",
			view : "search.SearchResult"

		},
		"detail" : {
			pattern : "detail/{contextPath}", // will be the url and from
			view : "overview.OverviewPage"
		},
		"s360" : {
			pattern : "s360/{contextPath}", // will be the url and from
			view : "S360"
		},
		"subdetail" : {
			pattern : "detail/{contextPath}/{selectedTab}", // will be the url and from
			view : "overview.OverviewPage"
		},
		"edit" : {
			pattern : "edit/{contextPath}",
			view : "maintain.GeneralDataEdit"
		},
		"new" : {
			pattern : "new/{accountCategory}",
			view : "maintain.GeneralDataEdit"
		},
	    "AccountNotes" : {
			pattern : "AccountNotes/{contextPath}", // will be the url and
			view : "S4Notes"

	    },
	    "AccountAttachments" : {
			pattern : "AccountAttachments/{contextPath}", // will be the
			view : "S4Attachments"
	    }

	}
    }),

    /**
     * Initialize the application
     * 
     * @returns {sap.ui.core.Control} the content
     */
    createContent : function() {
    	cus.crm.myaccounts.util.Util.setComponentConfiguration(this.getMetadata().getConfig());

    	var oViewData = {
	    component : this
    	};

    	return sap.ui.view({
    		viewName : "cus.crm.myaccounts.Main",
    		type : sap.ui.core.mvc.ViewType.XML,
    		viewData : oViewData
    	});
    }
});
},
	"cus/crm/myaccounts/Configuration.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("cus.crm.myaccounts.Configuration");
jQuery.sap.require("sap.ca.scfld.md.app.Application");
jQuery.sap.require("cus.crm.myaccounts.util.Util");

sap.ca.scfld.md.ConfigurationBase.extend("cus.crm.myaccounts.Configuration", {

    oServiceParams : {
		serviceList : [ {
		    name : "CRM_BUPA_ODATA",
		    serviceUrl : "/sap/opu/odata/sap/CRM_BUPA_ODATA",
		    countSupported : true,
		    isDefault : true,
		    useBatch:true,
		    noBusyIndicator:true,
		    mockedDataSource : "model/metadata.xml"
		} ],
		externalServiceList : [ {
		    name : "ERP_BUPA_ODATA",
		    serviceUrl : "/sap/opu/odata/sap/ERP_BUPA_ODATA",
		    countSupported : false,
		    isDefault : true,
		    useBatch:true,
		    mockedDataSource : "model/metadata.xml"
		} ]
    },

    /**
     * @inherit
     */
    getServiceList : function() {
    	cus.crm.myaccounts.util.Util.setApplicationConfiguration(this);
    	return this.oServiceParams.serviceList;
    },
    
	setApplicationFacade : function(oApplicationFacade) {
		sap.ca.scfld.md.ConfigurationBase.prototype.setApplicationFacade.call(this, oApplicationFacade);
		cus.crm.myaccounts.util.Util.setApplicationFacade(oApplicationFacade);
	}
});
},
	"cus/crm/myaccounts/Main.controller.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
sap.ui.controller("cus.crm.myaccounts.Main", {

	onInit : function() {
        jQuery.sap.require("sap.ca.scfld.md.Startup");				
		sap.ca.scfld.md.Startup.init('cus.crm.myaccounts', this);
	},
	
	/**
	 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
	 * 
	 * @memberOf MainXML
	 */
	onExit : function() {
		//exit cleanup code here
	}
		
});
},
	"cus/crm/myaccounts/Main.view.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core"\n\txmlns="sap.m" controllerName="cus.crm.myaccounts.Main" displayBlock="true"\n\theight="100%">\n\t<App id="fioriContent" class="cusCrmMyAccounts" showHeader="false">                                                              \t\n\t</App>  \n</core:View>',
	"cus/crm/myaccounts/controller/Base360Controller.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("cus.crm.myaccounts.controller.Base360Controller");
jQuery.sap.require("sap.ui.core.mvc.Controller");
jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");

sap.ca.scfld.md.controller.BaseFullscreenController.extend("cus.crm.myaccounts.controller.Base360Controller", {

	getTargetAggregation: function(){
		return "content";
	},
	getControl :function(){
		
	},
	getTargetBinding: function(){
		var oControl = this.getControl();
		if(oControl){
			return this.getControl().getBinding(this.getTargetAggregation());
		}
		return undefined;
	}

});
},
	"cus/crm/myaccounts/controller/SearchController.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
sap.ui.base.Object.extend("cus.crm.myaccounts.controller.SearchController", {

	constructor : function() {

	},
   
	onInit: function() {

	}
	

});
},
	"cus/crm/myaccounts/i18n/i18n.properties":'#Fiori CRM My Accounts application\n# __ldi.translation.uuid=c54f52f0-2066-11e3-8224-0800200c9a66\n# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\n\n# Note: This file was created according to the conventions that can be found at \n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\n\n#XFLD, 30: Facet title for general Data\nGENERAL_DATA=General Information\n\n#XTIT, 40: this is the title for the fullscreen section\nFULLSCREEN_TITLE=My Accounts\n\n#XTIT, 40: this is the title for the detail screen\nDETAIL_TITLE=Account\n\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\nREVENUE_CURRENT=Revenue YTD\n\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\nREVENUE_CURRENT_TOOLTIP=Revenue to date current year\n\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\nREVENUE_LAST=Revenue Last Year\n\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\nREVENUE_LAST_TOOLTIP=Revenue to last year\n\n# XFLD, 30: Facet title for opportunities and label in facet general data\nOPPORTUNITIES=Opportunities\n\n#XFLD, 30: Facet title for leads\nLEADS=Leads\n\n#XFLD, 30: Facet title for tasks\nTASKS=Tasks\n\n#XFLD, 30: Facet title for appointments\nAPPOINTMENTS=Appointments\n\n#XFLD, 30: Facet title for quotations\nQUOTATIONS=Quotations\n\n#XFLD, 30: Facet title for sales orders\nSALES_ORDERS=Sales Orders\n\n#XFLD, 30: W7: Facet title for marketing attributes\nMARKETINGATTRIBUTES=Marketing Attributes\n\n#XFLD, 30: W6: Title for popup with products\nPRODUCTS=Products\n\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\nEMPLOYEE_RESPONSIBLE=Employee Responsible\n\n#XFLD, 30: Facet title for Attachments\nATTACHMENTS=Attachments\n\n#XFLD, 30: Facet title for Notes\nNOTES=Notes\n\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\nNEW_NOTE=New Note\n\n#XFLD, 30: Facet title for Contacts\nCONTACTS=Contacts\n\n#XFLD, 30: Label for Address in facet general data\nADDRESS=Address\n\n#XFLD, 30: Label for Opportunities in facet general data\nUNWEIGHTED_OPPORTUNITIES=Opportunities\n\n#XFLD, 30: Label for Rating in facet general data\nRATING=Rating\n\n# XFLD, 30: Label for Next contact in facet Appointments\nNEXT_APPOINTMENT=Next Appointment\n\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\nLAST_APPOINTMENT=Last Appointment\n\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\nIMAGE=Image\n\n#XBUT, 20: Button to show the create actionsheet\nCREATE= Create\n\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\nDISCUSS_ENTRY=Discuss in SAP Jam\n\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\nSHARE_ENTRY=Share on SAP Jam\n\n#XBUT, 20: Button to share the note\nDETAIL_BUTTON_SHARE=Share\n\n#XBUT, 20: Button to cancel sharing\nDETAIL_BUTTON_CANCEL=Cancel\n\n#XFLD,20: All accounts for filter\nALL_ACCOUNTS=All Accounts\n\n#XFLD,35: All individual accounts for filter\nALL_INDIVIDUAL_ACCOUNTS=All Individual Accounts\n\n#XFLD,35: All corporate accounts for filter\nALL_CORPORATE_ACCOUNTS=All Corporate Accounts\n\n#XFLD,35: All group accounts for filter\nALL_ACCOUNT_GROUPS=All Account Groups\n\n#XFLD,20: my account for filter\nMY_ACCOUNT=My Accounts\n\n#XFLD,35: my individual accounts for filter\nMY_INDIVIDUAL_ACCOUNTS=My Individual Accounts\n\n#XFLD,35: my corporate accounts for filter\nMY_CORPORATE_ACCOUNTS=My Corporate Accounts\n\n#XFLD,35: my group accounts for filter\nMY_ACCOUNT_GROUPS=My Account Groups\n\n#XFLD,30: Account type -> for the DDLB in case of create\nINDIVIDUAL_ACCOUNT=Individual Account\n\n#XFLD,30: Account type -> for the DDLB in case of create\nCORPORATE_ACCOUNT=Corporate Account\n\n#XFLD,30: Account type -> for the DDLB in case of create\nACCOUNT_GROUP=Account Group\n\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\nSTARTING=Starting {0}\n\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\nCLOSING=Closing {0}\n\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\nDUE=Due {0}\n\n#XFLD,20: All accounts for title\nALL_ACCOUNTS_TITLE=All Accounts ({0})\n\n#XFLD,35: All individual accounts for title\nALL_INDIVIDUAL_ACCOUNTS_TITLE=All Individual Accounts ({0})\n\n#XFLD,35: All corporate accounts for title\nALL_CORPORATE_ACCOUNTS_TITLE=All Corporate Accounts ({0})\n\n#XFLD,35: All group accounts for title\nALL_ACCOUNT_GROUPS_TITLE=All Account Groups ({0})\n\n#XFLD,20: my account for title\nMY_ACCOUNT_TITLE=My Accounts ({0})\n\n#XFLD,35: my individual account for title\nMY_INDIVIDUAL_ACCOUNT_TITLE=My Individual Accounts ({0})\n\n#XFLD,35: my corporate account for title.\nMY_CORPORATE_ACCOUNT_TITLE=My Corporate Accounts ({0})\n\n#XFLD,35: my group account for title\nMY_ACCOUNT_GROUP_TITLE=My Account Groups ({0})\n\n#XFLD,30: filtered by info\nFILTERED_BY=Filtered By: {0}\n\n#XFLD,30: label, search for accounts\nSEARCH_ACCOUNTS=Search\n\n#XFLD,30: comma separator for location\nLOCATION={0}, {1}\n\n#XFLD: W4: Label for All day text in Appointments\nALL_DAY_EVENT=All Day\n\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\nDURATION_MINUTE={0} min\n\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\nDURATION_HOUR={0} h\n\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\nDURATION_DAY={0} day\n\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\nDURATION_DAYS={0} days\n\n#XFLD: W4: Label for Private meeting\nPRIVATE=Private\n\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\nSELECT_TRANSACTION_TYPE=Select Transaction Type\n\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\nNEW_TASK_INPUT_PLACEHOLDER=New Task\n\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\nNO_DATA_TEXT=No Data\n\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\nLOADING_TEXT=Loading...\n\n#XFLD,25: W4: Column label for name of contact person in contacts\nNAME=Name\n\n#XFLD,25: W5: Column label for department of contact person in contacts\nDEPARTMENT=Department\n\n#XFLD,15: W6: Column label for actions of contact person in contacts\nACTIONS=Actions\n\n#XFLD,25: W4: Column label for description of lead in Leads\nDESCRIPTION=Description\n\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\nASSIGNED_TO=Assigned To\n\n#XFLD,15: W4: Column label for end date of lead in Leads\nEND_DATE=End Date\n\n#XFLD,15: W4: Column label for qualification level of lead in Leads\nQUALIFICATION=Qualification\n\n#XFLD,15: W4: Column label for status of lead in Leads\nSTATUS=Status\n\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\nMAIN_CONTACT=Main Contact\n\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\nVOLUME=Volume\n\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\nPROBABILITY=Probability\n\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\nCLOSE_BY=Close By\n\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \nVIEWS=Views\n\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\nCONTACT_TITLE=Contact\n\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\nEMPLOYEE_TITLE=Employee\n\n#XTIT,20: W7: Title of pop-up used in confirm popup\nCONFIRM_TITLE=Confirm\n\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\nCOMPANY_NAME=Name\n\n#XFLD,20: W4: Label for name 1 of a company used general data\nCOMPANY_NAME1=Name 1\n\n#XFLD,20: W4: Label for name 2 of a company used general data\nCOMPANY_NAME2=Name 2\n\n#XFLD,20: W4: Label for first name of a person used general data\nFIRST_NAME=First Name\n\n#XFLD,20: W4: Label for last name of a person used general data\nLAST_NAME=Last Name\n\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\nBIRTHDAY=Birthday\n\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\nTITLE=Title\n\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\nACADEMIC_TITLE=Academic Title\n\n#XFLD,20: W4: Label for mobile phone number used general data\nMOBILE=Mobile\n\n#XFLD,20: W4: Label for phone number used general data\nPHONE=Phone\n\n#XFLD,20: W4: Label for e-mail used general data\nEMAIL=E-Mail\n\n#XFLD,20: W4: Label for web site used general data\nWEBSITE=Web Site\n\n#XFLD,20: W4: Label for country used general data\nCOUNTRY=Country\n\n#XFLD,20: W4: Label for region used general data\nREGION=Region\n\n#XFLD,20: W4: Label for city used general data\nCITY=City\n\n#XFLD,20: W4: Label for postal code used general data\nPOSTAL_CODE=Postal Code\n\n#XFLD,20: W4: Label for street used general data\nSTREET=Street\n\n#XFLD,10: W4: Label for house number used general data\nHOUSE_NUMBER=House No.\n\n#XFLD,15: W6: Label for ID used in Quotations\nID=ID\n\n#XFLD,15: W6: Label for Amount used in Quotations\nAMOUNT=Amount\n\n#XFLD,20: W6: Label for Expiration Date used in Quotations\nEXPIRATION_DATE=Expiration Date\n\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\nDELIVERY_DATE=Delivery Date\n\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\nSALES_EMPLOYEE=Sales Employee\n\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\nATTRIBUTESET=Attribute Set\n\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\nATTRIBUTE=Attribute\n\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\nVALUE=Value\n\n#XBUT, 20: Button to create an Account\nBUTTON_ADD=Add\n\n#XBUT, 20: Button to edit an Account\nBUTTON_EDIT=Edit\n\n#XBUT, 20: Button to save changes\nBUTTON_SAVE=Save\n\n#XBUT, 20: Button to cancel changes\nBUTTON_CANCEL=Cancel\n\n#XBUT, 30: Button which shows the personalization buttons\nBUTTON_SHOW_PERSONALIZATION=Show Personalization\n\n#XBUT, 30: Button which hides the personalization buttons\nBUTTON_HIDE_PERSONALIZATION=Hide Personalization\n\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\nMSG_CONFIRM_CANCEL=Leave this page without saving the changes you may have made?\n\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\nMSG_CONFIRM_DELETE_CONTACT=The contact will be unassigned from the account. Do you want to continue?\n\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\nMSG_UPDATE_SUCCESS=Account updated.\n\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\nMSG_UPDATE_ERROR=Update failed\n\n# XMSG : Account update succeeded\nMSG_CREATION_SUCCESS=Account created\n\n# XMSG : Task creation succeeded\nMSG_TASK_CREATION_SUCCESS=Task created\n\n# XMSG : Contact creation failed\nMSG_CREATION_ERROR=Creation failed\n\n# XMSG: message that will be displayed, if the user has entered wrong country\nMSG_WRONG_COUNTRY_ERROR=Country "{0}" does not exist.\n\n# XMSG: message that will be displayed, if the user has entered wrong region\nMSG_WRONG_REGION_ERROR=Region "{0}" does not exist for the given country.\n\n# XMSG: message that will be displayed, if the user has entered wrong employee\nMSG_WRONG_EMPLOYEE_ERROR=Employee "{0}" does not exist.\n\n# XMSG: message that will be displayed, if the user has entered invalid website url\nMSG_WRONG_URL_ERROR=Entered URL "{0}" is not valid.\n\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\nMSG_MANDATORY_FIELDS=Not all mandatory fields are filled.\n\n# XMSG: message that will be displayed in case of conflicting data during account editing\nMSG_CONFLICTING_DATA=Data has been changed by another user. Do you want to overwrite the other user\'s changes with your own?\n\n# XMSG: message that will be displayed in case of conflicts during file renaming\nMSG_CONFLICTING_FILE_NAME=The file name has been changed by another user. Do you want to overwrite the other user\'s changes with your own?\n\n# XMSG: message that will be displayed in case of conflicting data during account editing\nMSG_CONFLICTING_DATA_WITH_REFRESH=Data has been changed by another user. Data will be refreshed.\n\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\nMSG_NOT_IN_MAIN_CONTACT=You can only view business cards of contacts that have been assigned to this account\n\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\nMSG_EXCEEDING_FILE_NAME_LENGTH=Your file name can have a maximum of 40 characters.\n\n# XTOL, 20: tooltip shown on search result list for button to add an account"\nADD_ACCOUNT_TOOLTIP=Add Account\n\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\nADD_MARKETING_ATTRIBUTE_TOOLTIP=Add Marketing Attribute\n\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\nADD_CONTACT_TOOLTIP=Add Contact\n\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\nADD_APPOINTMENT_TOOLTIP=Add Appointment\n\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\nADD_TASK_TOOLTIP=Add Task\n\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\nADD_OPPORTUNITY_TOOLTIP=Add Opportunity\n',
	"cus/crm/myaccounts/i18n/i18n_ar.properties":'# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XFLD, 30: Facet title for general Data\r\nGENERAL_DATA=\\u0627\\u0644\\u0628\\u064A\\u0627\\u0646\\u0627\\u062A \\u0627\\u0644\\u0639\\u0627\\u0645\\u0629\r\n\r\n#XTIT, 40: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=\\u0639\\u0645\\u0644\\u0627\\u0626\\u064A\r\n\r\n#XTIT, 40: this is the title for the detail screen\r\nDETAIL_TITLE=\\u0627\\u0644\\u0639\\u0645\\u064A\\u0644\r\n\r\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\r\nREVENUE_CURRENT=\\u0625\\u064A\\u0631\\u0627\\u062F\\: \\u0633\\u0646\\u0629 \\u0644\\u062A\\u0627\\u0631\\u064A\\u062E\\u0647\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\r\nREVENUE_CURRENT_TOOLTIP=\\u0625\\u064A\\u0631\\u0627\\u062F\\u0627\\u062A \\u0627\\u0644\\u0633\\u0646\\u0629 \\u0627\\u0644\\u062D\\u0627\\u0644\\u064A\\u0629 \\u062D\\u062A\\u0649 \\u062A\\u0627\\u0631\\u064A\\u062E\\u0647\r\n\r\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\r\nREVENUE_LAST=\\u0625\\u064A\\u0631\\u0627\\u062F\\u0627\\u062A \\u0633\\u0646\\u0629 \\u0645\\u0627\\u0636\\u064A\\u0629\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\r\nREVENUE_LAST_TOOLTIP=\\u0627\\u0644\\u0625\\u064A\\u0631\\u0627\\u062F\\u0627\\u062A \\u0627\\u0644\\u0633\\u0646\\u0629 \\u0627\\u0644\\u0645\\u0627\\u0636\\u064A\\u0629\r\n\r\n# XFLD, 30: Facet title for opportunities and label in facet general data\r\nOPPORTUNITIES=\\u0627\\u0644\\u0641\\u0631\\u0635 \\u0627\\u0644\\u0628\\u064A\\u0639\\u064A\\u0629\r\n\r\n#XFLD, 30: Facet title for leads\r\nLEADS=\\u0641\\u0631\\u0635 \\u062A\\u0633\\u0648\\u064A\\u0642\\u064A\\u0629\r\n\r\n#XFLD, 30: Facet title for tasks\r\nTASKS=\\u0627\\u0644\\u0645\\u0647\\u0627\\u0645\r\n\r\n#XFLD, 30: Facet title for appointments\r\nAPPOINTMENTS=\\u0627\\u0644\\u0645\\u0648\\u0627\\u0639\\u064A\\u062F\r\n\r\n#XFLD, 30: Facet title for quotations\r\nQUOTATIONS=\\u0639\\u0631\\u0648\\u0636 \\u0627\\u0644\\u0623\\u0633\\u0639\\u0627\\u0631\r\n\r\n#XFLD, 30: Facet title for sales orders\r\nSALES_ORDERS=\\u0623\\u0648\\u0627\\u0645\\u0631 \\u0627\\u0644\\u0645\\u0628\\u064A\\u0639\\u0627\\u062A\r\n\r\n#XFLD, 30: W7: Facet title for marketing attributes\r\nMARKETINGATTRIBUTES=\\u0633\\u0645\\u0627\\u062A \\u0627\\u0644\\u062A\\u0633\\u0648\\u064A\\u0642\r\n\r\n#XFLD, 30: W6: Title for popup with products\r\nPRODUCTS=\\u0627\\u0644\\u0645\\u0646\\u062A\\u062C\\u0627\\u062A\r\n\r\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\r\nEMPLOYEE_RESPONSIBLE=\\u0627\\u0644\\u0645\\u0648\\u0638\\u0641 \\u0627\\u0644\\u0645\\u0633\\u0624\\u0648\\u0644\r\n\r\n#XFLD, 30: Facet title for Attachments\r\nATTACHMENTS=\\u0645\\u0631\\u0641\\u0642\\u0627\\u062A\r\n\r\n#XFLD, 30: Facet title for Notes\r\nNOTES=\\u0645\\u0644\\u0627\\u062D\\u0638\\u0627\\u062A\r\n\r\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\r\nNEW_NOTE=\\u0645\\u0644\\u0627\\u062D\\u0638\\u0629 \\u062C\\u062F\\u064A\\u062F\\u0629\r\n\r\n#XFLD, 30: Facet title for Contacts\r\nCONTACTS=\\u062C\\u0647\\u0627\\u062A \\u0627\\u0644\\u0627\\u062A\\u0635\\u0627\\u0644\r\n\r\n#XFLD, 30: Label for Address in facet general data\r\nADDRESS=\\u0627\\u0644\\u0639\\u0646\\u0648\\u0627\\u0646\r\n\r\n#XFLD, 30: Label for Opportunities in facet general data\r\nUNWEIGHTED_OPPORTUNITIES=\\u0627\\u0644\\u0641\\u0631\\u0635 \\u0627\\u0644\\u0628\\u064A\\u0639\\u064A\\u0629\r\n\r\n#XFLD, 30: Label for Rating in facet general data\r\nRATING=\\u0627\\u0644\\u062A\\u0635\\u0646\\u064A\\u0641\r\n\r\n# XFLD, 30: Label for Next contact in facet Appointments\r\nNEXT_APPOINTMENT=\\u0627\\u0644\\u0645\\u0648\\u0639\\u062F \\u0627\\u0644\\u062A\\u0627\\u0644\\u064A\r\n\r\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\r\nLAST_APPOINTMENT=\\u0622\\u062E\\u0631 \\u0645\\u0648\\u0639\\u062F\r\n\r\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\r\nIMAGE=\\u0627\\u0644\\u0635\\u0648\\u0631\\u0629\r\n\r\n#XBUT, 20: Button to show the create actionsheet\r\nCREATE=\\u0625\\u0646\\u0634\\u0627\\u0621\r\n\r\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\r\nDISCUSS_ENTRY=\\u0645\\u0646\\u0627\\u0642\\u0634\\u0629 \\u0641\\u064A SAP Jam\r\n\r\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\r\nSHARE_ENTRY=\\u0645\\u0634\\u0627\\u0631\\u0643\\u0629 \\u0639\\u0644\\u0649 SAP Jam\r\n\r\n#XBUT, 20: Button to share the note\r\nDETAIL_BUTTON_SHARE=\\u0645\\u0634\\u0627\\u0631\\u0643\\u0629\r\n\r\n#XBUT, 20: Button to cancel sharing\r\nDETAIL_BUTTON_CANCEL=\\u0625\\u0644\\u063A\\u0627\\u0621\r\n\r\n#XFLD,20: All accounts for filter\r\nALL_ACCOUNTS=\\u0643\\u0644 \\u0627\\u0644\\u062D\\u0633\\u0627\\u0628\\u0627\\u062A\r\n\r\n#XFLD,35: All individual accounts for filter\r\nALL_INDIVIDUAL_ACCOUNTS=\\u0643\\u0644 \\u0627\\u0644\\u0639\\u0645\\u0644\\u0627\\u0621 \\u0627\\u0644\\u0641\\u0631\\u062F\\u064A\\u064A\\u0646\r\n\r\n#XFLD,35: All corporate accounts for filter\r\nALL_CORPORATE_ACCOUNTS=\\u0643\\u0644 \\u0639\\u0645\\u0644\\u0627\\u0621 \\u0627\\u0644\\u0634\\u0631\\u0643\\u0629\r\n\r\n#XFLD,35: All group accounts for filter\r\nALL_ACCOUNT_GROUPS=\\u0643\\u0627\\u0641\\u0629 \\u0645\\u062C\\u0645\\u0648\\u0639\\u0627\\u062A \\u0627\\u0644\\u0639\\u0645\\u0644\\u0627\\u0621\r\n\r\n#XFLD,20: my account for filter\r\nMY_ACCOUNT=\\u0639\\u0645\\u0644\\u0627\\u0626\\u064A\r\n\r\n#XFLD,35: my individual accounts for filter\r\nMY_INDIVIDUAL_ACCOUNTS=\\u0639\\u0645\\u0644\\u0627\\u0626\\u064A \\u0627\\u0644\\u0641\\u0631\\u062F\\u064A\\u0648\\u0646\r\n\r\n#XFLD,35: my corporate accounts for filter\r\nMY_CORPORATE_ACCOUNTS=\\u0639\\u0645\\u0644\\u0627\\u0621 \\u0627\\u0644\\u0634\\u0631\\u0643\\u0629 \\u0627\\u0644\\u062A\\u0627\\u0628\\u0639\\u064A\\u0646 \\u0644\\u064A\r\n\r\n#XFLD,35: my group accounts for filter\r\nMY_ACCOUNT_GROUPS=\\u0645\\u062C\\u0645\\u0648\\u0639\\u0627\\u062A \\u0627\\u0644\\u0639\\u0645\\u0644\\u0627\\u0621 \\u0627\\u0644\\u062A\\u0627\\u0628\\u0639\\u0629 \\u0644\\u064A\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nINDIVIDUAL_ACCOUNT=\\u0639\\u0645\\u064A\\u0644 \\u0641\\u0631\\u062F\\u064A\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nCORPORATE_ACCOUNT=\\u0639\\u0645\\u064A\\u0644 \\u0634\\u0631\\u0643\\u0629\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nACCOUNT_GROUP=\\u0645\\u062C\\u0645\\u0648\\u0639\\u0629 \\u0639\\u0645\\u0644\\u0627\\u0621\r\n\r\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\r\nSTARTING=\\u062A\\u0627\\u0631\\u064A\\u062E \\u0627\\u0644\\u0628\\u062F\\u0627\\u064A\\u0629\\: {0}\r\n\r\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\r\nCLOSING=\\u062A\\u0627\\u0631\\u064A\\u062E \\u0627\\u0644\\u0625\\u063A\\u0644\\u0627\\u0642\\: {0}\r\n\r\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\r\nDUE=\\u062A\\u0627\\u0631\\u064A\\u062E \\u0627\\u0644\\u0627\\u0633\\u062A\\u062D\\u0642\\u0627\\u0642\\: {0}\r\n\r\n#XFLD,20: All accounts for title\r\nALL_ACCOUNTS_TITLE=\\u062C\\u0645\\u064A\\u0639 \\u0627\\u0644\\u0639\\u0645\\u0644\\u0627\\u0621 ({0})\r\n\r\n#XFLD,35: All individual accounts for title\r\nALL_INDIVIDUAL_ACCOUNTS_TITLE=\\u0643\\u0644 \\u0627\\u0644\\u0639\\u0645\\u0644\\u0627\\u0621 \\u0627\\u0644\\u0641\\u0631\\u062F\\u064A\\u064A\\u0646 ({0})\r\n\r\n#XFLD,35: All corporate accounts for title\r\nALL_CORPORATE_ACCOUNTS_TITLE=\\u062C\\u0645\\u064A\\u0639 \\u0639\\u0645\\u0644\\u0627\\u0621 \\u0627\\u0644\\u0634\\u0631\\u0643\\u0629 ({0})\r\n\r\n#XFLD,35: All group accounts for title\r\nALL_ACCOUNT_GROUPS_TITLE=\\u0643\\u0627\\u0641\\u0629 \\u0645\\u062C\\u0645\\u0648\\u0639\\u0627\\u062A \\u0627\\u0644\\u0639\\u0645\\u0644\\u0627\\u0621 ({0})\r\n\r\n#XFLD,20: my account for title\r\nMY_ACCOUNT_TITLE=\\u0639\\u0645\\u0644\\u0627\\u0626\\u064A ({0})\r\n\r\n#XFLD,35: my individual account for title\r\nMY_INDIVIDUAL_ACCOUNT_TITLE=\\u0627\\u0644\\u0639\\u0645\\u0644\\u0627\\u0621 \\u0627\\u0644\\u0641\\u0631\\u062F\\u064A\\u0648\\u0646 \\u0627\\u0644\\u062A\\u0627\\u0628\\u0639\\u064A\\u0646 \\u0644\\u064A ({0})\r\n\r\n#XFLD,35: my corporate account for title.\r\nMY_CORPORATE_ACCOUNT_TITLE=\\u0639\\u0645\\u0644\\u0627\\u0621 \\u0627\\u0644\\u0634\\u0631\\u0643\\u0629 \\u0627\\u0644\\u062A\\u0627\\u0628\\u0639\\u064A\\u0646 \\u0644\\u064A ({0})\r\n\r\n#XFLD,35: my group account for title\r\nMY_ACCOUNT_GROUP_TITLE=\\u0645\\u062C\\u0645\\u0648\\u0639\\u0627\\u062A \\u0627\\u0644\\u0639\\u0645\\u0644\\u0627\\u0621 \\u0627\\u0644\\u062A\\u0627\\u0628\\u0639\\u064A\\u0646 \\u0644\\u064A ({0})\r\n\r\n#XFLD,30: filtered by info\r\nFILTERED_BY=\\u062A\\u0645\\u062A \\u0627\\u0644\\u062A\\u0635\\u0641\\u064A\\u0629 \\u062D\\u0633\\u0628\\: {0}\r\n\r\n#XFLD,30: label, search for accounts\r\nSEARCH_ACCOUNTS=\\u0628\\u062D\\u062B\r\n\r\n#XFLD,30: comma separator for location\r\nLOCATION={0}, {1}\r\n\r\n#XFLD: W4: Label for All day text in Appointments\r\nALL_DAY_EVENT=\\u0637\\u0648\\u0627\\u0644 \\u0627\\u0644\\u064A\\u0648\\u0645\r\n\r\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\r\nDURATION_MINUTE={0} \\u062F\\u0642\\u064A\\u0642\\u0629 (\\u062F\\u0642\\u0627\\u0626\\u0642)\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\r\nDURATION_HOUR={0} \\u0633\\u0627\\u0639\\u0629 (\\u0633\\u0627\\u0639\\u0627\\u062A)\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\r\nDURATION_DAY={0} \\u064A\\u0648\\u0645 (\\u0623\\u064A\\u0627\\u0645)\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\r\nDURATION_DAYS={0} \\u064A\\u0648\\u0645 (\\u0623\\u064A\\u0627\\u0645)\r\n\r\n#XFLD: W4: Label for Private meeting\r\nPRIVATE=\\u062E\\u0627\\u0635\r\n\r\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\r\nSELECT_TRANSACTION_TYPE=\\u062A\\u062D\\u062F\\u064A\\u062F \\u0646\\u0648\\u0639 \\u0627\\u0644\\u0645\\u0639\\u0627\\u0645\\u0644\\u0629\r\n\r\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\r\nNEW_TASK_INPUT_PLACEHOLDER=\\u0645\\u0647\\u0645\\u0629 \\u062C\\u062F\\u064A\\u062F\\u0629\r\n\r\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nNO_DATA_TEXT=\\u0644\\u0627 \\u062A\\u0648\\u062C\\u062F \\u0628\\u064A\\u0627\\u0646\\u0627\\u062A\r\n\r\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nLOADING_TEXT=\\u062C\\u0627\\u0631\\u064D \\u0627\\u0644\\u062A\\u062D\\u0645\\u064A\\u0644...\r\n\r\n#XFLD,25: W4: Column label for name of contact person in contacts\r\nNAME=\\u0627\\u0644\\u0627\\u0633\\u0645\r\n\r\n#XFLD,25: W5: Column label for department of contact person in contacts\r\nDEPARTMENT=\\u0627\\u0644\\u0642\\u0633\\u0645\r\n\r\n#XFLD,15: W6: Column label for actions of contact person in contacts\r\nACTIONS=\\u0627\\u0644\\u0625\\u062C\\u0631\\u0627\\u0621\\u0627\\u062A\r\n\r\n#XFLD,25: W4: Column label for description of lead in Leads\r\nDESCRIPTION=\\u0627\\u0644\\u0648\\u0635\\u0641\r\n\r\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\r\nASSIGNED_TO=\\u062A\\u0645 \\u0627\\u0644\\u062A\\u0639\\u064A\\u064A\\u0646 \\u0625\\u0644\\u0649\r\n\r\n#XFLD,15: W4: Column label for end date of lead in Leads\r\nEND_DATE=\\u062A\\u0627\\u0631\\u064A\\u062E \\u0627\\u0644\\u0627\\u0646\\u062A\\u0647\\u0627\\u0621\r\n\r\n#XFLD,15: W4: Column label for qualification level of lead in Leads\r\nQUALIFICATION=\\u0627\\u0644\\u0645\\u0624\\u0647\\u0644\r\n\r\n#XFLD,15: W4: Column label for status of lead in Leads\r\nSTATUS=\\u0627\\u0644\\u062D\\u0627\\u0644\\u0629\r\n\r\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\r\nMAIN_CONTACT=\\u062C\\u0647\\u0629 \\u0627\\u0644\\u0627\\u062A\\u0635\\u0627\\u0644 \\u0627\\u0644\\u0631\\u0626\\u064A\\u0633\\u064A\\u0629\r\n\r\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\r\nVOLUME=\\u0627\\u0644\\u062D\\u062C\\u0645\r\n\r\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\r\nPROBABILITY=\\u0627\\u0644\\u0627\\u062D\\u062A\\u0645\\u0627\\u0644\\u064A\\u0629\r\n\r\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\r\nCLOSE_BY=\\u0625\\u063A\\u0644\\u0627\\u0642 \\u0628\\u0648\\u0627\\u0633\\u0637\\u0629\r\n\r\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \r\nVIEWS=\\u0627\\u0644\\u0639\\u0631\\u0648\\u0636\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\r\nCONTACT_TITLE=\\u062C\\u0647\\u0629 \\u0627\\u0644\\u0627\\u062A\\u0635\\u0627\\u0644\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\r\nEMPLOYEE_TITLE=\\u0627\\u0644\\u0645\\u0648\\u0638\\u0641\r\n\r\n#XTIT,20: W7: Title of pop-up used in confirm popup\r\nCONFIRM_TITLE=\\u062A\\u0623\\u0643\\u064A\\u062F\r\n\r\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\r\nCOMPANY_NAME=\\u0627\\u0644\\u0627\\u0633\\u0645\r\n\r\n#XFLD,20: W4: Label for name 1 of a company used general data\r\nCOMPANY_NAME1=\\u0627\\u0644\\u0627\\u0633\\u0645 1\r\n\r\n#XFLD,20: W4: Label for name 2 of a company used general data\r\nCOMPANY_NAME2=\\u0627\\u0644\\u0627\\u0633\\u0645 2\r\n\r\n#XFLD,20: W4: Label for first name of a person used general data\r\nFIRST_NAME=\\u0627\\u0644\\u0627\\u0633\\u0645 \\u0627\\u0644\\u0623\\u0648\\u0644\r\n\r\n#XFLD,20: W4: Label for last name of a person used general data\r\nLAST_NAME=\\u0627\\u0644\\u0627\\u0633\\u0645 \\u0627\\u0644\\u0623\\u062E\\u064A\\u0631\r\n\r\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nBIRTHDAY=\\u062A\\u0627\\u0631\\u064A\\u062E \\u0627\\u0644\\u0645\\u064A\\u0644\\u0627\\u062F\r\n\r\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nTITLE=\\u0627\\u0644\\u0639\\u0646\\u0648\\u0627\\u0646\r\n\r\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nACADEMIC_TITLE=\\u0644\\u0642\\u0628 \\u0623\\u0643\\u0627\\u062F\\u064A\\u0645\\u064A\r\n\r\n#XFLD,20: W4: Label for mobile phone number used general data\r\nMOBILE=\\u0627\\u0644\\u062C\\u0648\\u0627\\u0644\r\n\r\n#XFLD,20: W4: Label for phone number used general data\r\nPHONE=\\u0627\\u0644\\u0647\\u0627\\u062A\\u0641\r\n\r\n#XFLD,20: W4: Label for e-mail used general data\r\nEMAIL=\\u0627\\u0644\\u0628\\u0631\\u064A\\u062F \\u0627\\u0644\\u0625\\u0644\\u0643\\u062A\\u0631\\u0648\\u0646\\u064A\r\n\r\n#XFLD,20: W4: Label for web site used general data\r\nWEBSITE=\\u0645\\u0648\\u0642\\u0639 \\u0627\\u0644\\u0648\\u064A\\u0628\r\n\r\n#XFLD,20: W4: Label for country used general data\r\nCOUNTRY=\\u0627\\u0644\\u062F\\u0648\\u0644\\u0629\r\n\r\n#XFLD,20: W4: Label for region used general data\r\nREGION=\\u0627\\u0644\\u0645\\u0646\\u0637\\u0642\\u0629\r\n\r\n#XFLD,20: W4: Label for city used general data\r\nCITY=\\u0627\\u0644\\u0645\\u062F\\u064A\\u0646\\u0629\r\n\r\n#XFLD,20: W4: Label for postal code used general data\r\nPOSTAL_CODE=\\u0627\\u0644\\u0631\\u0645\\u0632 \\u0627\\u0644\\u0628\\u0631\\u064A\\u062F\\u064A\r\n\r\n#XFLD,20: W4: Label for street used general data\r\nSTREET=\\u0627\\u0644\\u0634\\u0627\\u0631\\u0639\r\n\r\n#XFLD,10: W4: Label for house number used general data\r\nHOUSE_NUMBER=\\u0631\\u0642\\u0645 \\u0627\\u0644\\u0645\\u0646\\u0632\\u0644\r\n\r\n#XFLD,15: W6: Label for ID used in Quotations\r\nID=\\u0627\\u0644\\u0645\\u0639\\u0631\\u0641\r\n\r\n#XFLD,15: W6: Label for Amount used in Quotations\r\nAMOUNT=\\u0627\\u0644\\u0645\\u0628\\u0644\\u063A\r\n\r\n#XFLD,20: W6: Label for Expiration Date used in Quotations\r\nEXPIRATION_DATE=\\u062A\\u0627\\u0631\\u064A\\u062E \\u0627\\u0646\\u062A\\u0647\\u0627\\u0621 \\u0635\\u0644\\u0627\\u062D\\u064A\\u0629\r\n\r\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\r\nDELIVERY_DATE=\\u062A\\u0627\\u0631\\u064A\\u062E \\u0627\\u0644\\u062A\\u0633\\u0644\\u064A\\u0645\r\n\r\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\r\nSALES_EMPLOYEE=\\u0645\\u0648\\u0638\\u0641 \\u0645\\u0628\\u064A\\u0639\\u0627\\u062A\r\n\r\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\r\nATTRIBUTESET=\\u0645\\u062C\\u0645\\u0648\\u0639\\u0629 \\u0627\\u0644\\u0633\\u0645\\u0627\\u062A\r\n\r\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\r\nATTRIBUTE=\\u0627\\u0644\\u0633\\u0645\\u0629\r\n\r\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\r\nVALUE=\\u0627\\u0644\\u0642\\u064A\\u0645\\u0629\r\n\r\n#XBUT, 20: Button to create an Account\r\nBUTTON_ADD=\\u0625\\u0636\\u0627\\u0641\\u0629\r\n\r\n#XBUT, 20: Button to edit an Account\r\nBUTTON_EDIT=\\u062A\\u062D\\u0631\\u064A\\u0631\r\n\r\n#XBUT, 20: Button to save changes\r\nBUTTON_SAVE=\\u062D\\u0641\\u0638\r\n\r\n#XBUT, 20: Button to cancel changes\r\nBUTTON_CANCEL=\\u0625\\u0644\\u063A\\u0627\\u0621\r\n\r\n#XBUT, 30: Button which shows the personalization buttons\r\nBUTTON_SHOW_PERSONALIZATION=\\u0625\\u0638\\u0647\\u0627\\u0631 \\u0627\\u0644\\u062A\\u062E\\u0635\\u064A\\u0635\r\n\r\n#XBUT, 30: Button which hides the personalization buttons\r\nBUTTON_HIDE_PERSONALIZATION=\\u0625\\u062E\\u0641\\u0627\\u0621 \\u0627\\u0644\\u062A\\u062E\\u0635\\u064A\\u0635\r\n\r\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_CONFIRM_CANCEL=\\u0633\\u064A\\u062A\\u0645 \\u0641\\u0642\\u062F\\u0627\\u0646 \\u0623\\u064A\\u0629 \\u062A\\u063A\\u064A\\u064A\\u0631\\u0627\\u062A \\u063A\\u064A\\u0631 \\u0645\\u062D\\u0641\\u0648\\u0638\\u0629. \\u0647\\u0644 \\u062A\\u0631\\u064A\\u062F \\u0627\\u0644\\u0645\\u062A\\u0627\\u0628\\u0639\\u0629\\u061F\r\n\r\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\r\nMSG_CONFIRM_DELETE_CONTACT=\\u0633\\u064A\\u062A\\u0645 \\u0625\\u0644\\u063A\\u0627\\u0621 \\u062A\\u0639\\u064A\\u064A\\u0646 \\u062C\\u0647\\u0629 \\u0627\\u0644\\u0627\\u062A\\u0635\\u0627\\u0644 \\u0645\\u0646 \\u0627\\u0644\\u062D\\u0633\\u0627\\u0628. \\u0647\\u0644 \\u062A\\u0631\\u064A\\u062F \\u0627\\u0644\\u0645\\u062A\\u0627\\u0628\\u0639\\u0629\\u061F\r\n\r\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_SUCCESS=\\u062A\\u0645 \\u062A\\u062D\\u062F\\u064A\\u062B \\u0628\\u064A\\u0627\\u0646\\u0627\\u062A \\u0627\\u0644\\u0639\\u0645\\u064A\\u0644\r\n\r\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_ERROR=\\u0641\\u0634\\u0644 \\u0627\\u0644\\u062A\\u062D\\u062F\\u064A\\u062B\r\n\r\n# XMSG : Account update succeeded\r\nMSG_CREATION_SUCCESS=\\u062A\\u0645 \\u0625\\u0646\\u0634\\u0627\\u0621 \\u0628\\u064A\\u0627\\u0646\\u0627\\u062A \\u0639\\u0645\\u064A\\u0644\r\n\r\n# XMSG : Task creation succeeded\r\nMSG_TASK_CREATION_SUCCESS=\\u062A\\u0645 \\u0625\\u0646\\u0634\\u0627\\u0621 \\u0627\\u0644\\u0645\\u0647\\u0645\\u0629\r\n\r\n# XMSG : Contact creation failed\r\nMSG_CREATION_ERROR=\\u0641\\u0634\\u0644 \\u0627\\u0644\\u0625\\u0646\\u0634\\u0627\\u0621\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong country\r\nMSG_WRONG_COUNTRY_ERROR=\\u0627\\u0644\\u062F\\u0648\\u0644\\u0629 "{0}" \\u063A\\u064A\\u0631 \\u0645\\u0648\\u062C\\u0648\\u062F\\u0629\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong region\r\nMSG_WRONG_REGION_ERROR=\\u0627\\u0644\\u0645\\u0646\\u0637\\u0642\\u0629 {0}" \\u063A\\u064A\\u0631 \\u0645\\u0648\\u062C\\u0648\\u062F\\u0629 \\u0644\\u0644\\u062F\\u0648\\u0644\\u0629\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong employee\r\nMSG_WRONG_EMPLOYEE_ERROR=\\u0627\\u0644\\u0645\\u0648\\u0638\\u0641 "{0}" \\u063A\\u064A\\u0631 \\u0645\\u0648\\u062C\\u0648\\u062F.\r\n\r\n# XMSG: message that will be displayed, if the user has entered invalid website url\r\nMSG_WRONG_URL_ERROR=\\u0639\\u0646\\u0648\\u0627\\u0646 \\u0645\\u062D\\u062F\\u062F \\u0645\\u0648\\u0627\\u0642\\u0639 \\u0627\\u0644\\u0645\\u0639\\u0644\\u0648\\u0645\\u0627\\u062A "{0}" \\u063A\\u064A\\u0631 \\u0635\\u0627\\u0644\\u062D.\r\n\r\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\r\nMSG_MANDATORY_FIELDS=\\u0644\\u0645 \\u064A\\u062A\\u0645 \\u0645\\u0644\\u0621 \\u062C\\u0645\\u064A\\u0639 \\u0627\\u0644\\u062D\\u0642\\u0648\\u0644 \\u0627\\u0644\\u0625\\u0644\\u0632\\u0627\\u0645\\u064A\\u0629\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA=\\u062A\\u0645 \\u062A\\u063A\\u064A\\u064A\\u0631 \\u0627\\u0644\\u0628\\u064A\\u0627\\u0646\\u0627\\u062A \\u0628\\u0648\\u0627\\u0633\\u0637\\u0629 \\u0645\\u0633\\u062A\\u062E\\u062F\\u0645 \\u0622\\u062E\\u0631. \\u0647\\u0644 \\u062A\\u0631\\u064A\\u062F \\u0627\\u0633\\u062A\\u0628\\u062F\\u0627\\u0644 \\u062A\\u063A\\u064A\\u064A\\u0631\\u0627\\u062A \\u0627\\u0644\\u0645\\u0633\\u062A\\u062E\\u062F\\u0645 \\u0627\\u0644\\u0622\\u062E\\u0631 \\u0628\\u0627\\u0644\\u062A\\u063A\\u064A\\u064A\\u0631\\u0627\\u062A \\u0627\\u0644\\u062E\\u0627\\u0635\\u0629 \\u0628\\u0643\\u061F\r\n\r\n# XMSG: message that will be displayed in case of conflicts during file renaming\r\nMSG_CONFLICTING_FILE_NAME=\\u062A\\u0645 \\u062A\\u063A\\u064A\\u064A\\u0631 \\u0627\\u0633\\u0645 \\u0627\\u0644\\u0645\\u0644\\u0641 \\u0628\\u0648\\u0627\\u0633\\u0637\\u0629 \\u0645\\u0633\\u062A\\u062E\\u062F\\u0645 \\u0622\\u062E\\u0631. \\u0647\\u0644 \\u062A\\u0631\\u064A\\u062F \\u0627\\u0633\\u062A\\u0628\\u062F\\u0627\\u0644 \\u062A\\u063A\\u064A\\u064A\\u0631\\u0627\\u062A \\u0627\\u0644\\u0645\\u0633\\u062A\\u062E\\u062F\\u0645 \\u0627\\u0644\\u0622\\u062E\\u0631 \\u0628\\u0627\\u0644\\u062A\\u063A\\u064A\\u064A\\u0631\\u0627\\u062A \\u0627\\u0644\\u062E\\u0627\\u0635\\u0629 \\u0628\\u0643\\u061F\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA_WITH_REFRESH=\\u0627\\u0644\\u0628\\u064A\\u0627\\u0646\\u0627\\u062A \\u0627\\u0644\\u062A\\u064A \\u062A\\u0645 \\u062A\\u063A\\u064A\\u064A\\u0631\\u0647\\u0627 \\u0628\\u0648\\u0627\\u0633\\u0637\\u0629 \\u0645\\u0633\\u062A\\u062E\\u062F\\u0645 \\u0622\\u062E\\u0631. \\u0633\\u062A\\u0638\\u0647\\u0631 \\u0647\\u0630\\u0647 \\u0627\\u0644\\u062A\\u063A\\u064A\\u064A\\u0631\\u0627\\u062A \\u0641\\u064A \\u0627\\u0644\\u062A\\u0637\\u0628\\u064A\\u0642.\r\n\r\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\r\nMSG_NOT_IN_MAIN_CONTACT=\\u0644\\u0627 \\u064A\\u0645\\u0643\\u0646\\u0643 \\u0625\\u0644\\u0627 \\u0639\\u0631\\u0636 \\u062A\\u0641\\u0627\\u0635\\u064A\\u0644 \\u0627\\u0644\\u0627\\u062A\\u0635\\u0627\\u0644\\u0627\\u062A \\u0627\\u0644\\u0645\\u0639\\u064A\\u0646\\u0629 \\u0644\\u0647\\u0630\\u0627 \\u0627\\u0644\\u062D\\u0633\\u0627\\u0628\r\n\r\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\r\nMSG_EXCEEDING_FILE_NAME_LENGTH=\\u064A\\u0645\\u0643\\u0646 \\u0623\\u0646 \\u064A\\u0643\\u0648\\u0646 \\u0637\\u0648\\u0644 \\u0627\\u0633\\u0645 \\u0627\\u0644\\u0645\\u0644\\u0641 40 \\u062D\\u0631\\u0641\\u064B\\u0627 \\u0643\\u062D\\u062F \\u0623\\u0642\\u0635\\u0649.\r\n\r\n# XTOL, 20: tooltip shown on search result list for button to add an account"\r\n\r\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\r\n\r\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\r\n\r\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\r\n\r\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\r\n\r\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\r\n',
	"cus/crm/myaccounts/i18n/i18n_bg.properties":'# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XFLD, 30: Facet title for general Data\r\nGENERAL_DATA=\\u041E\\u0431\\u0449\\u0438 \\u0434\\u0430\\u043D\\u043D\\u0438\r\n\r\n#XTIT, 40: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=\\u041C\\u043E\\u0438\\u0442\\u0435 \\u0430\\u043A\\u0430\\u0443\\u043D\\u0442\\u0438\r\n\r\n#XTIT, 40: this is the title for the detail screen\r\nDETAIL_TITLE=\\u0410\\u043A\\u0430\\u0443\\u043D\\u0442\r\n\r\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\r\nREVENUE_CURRENT=\\u041F\\u0440\\u0438\\u0445\\u043E\\u0434\\u041D\\u0430\\u0447\\u0413\\u043E\\u0434\\u0414\\u043E\\u0414\\u0430\\u0442\\u0430\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\r\nREVENUE_CURRENT_TOOLTIP=\\u041F\\u0440\\u0438\\u0445\\u043E\\u0434 \\u0434\\u043E \\u0434\\u0430\\u0442\\u0430 \\u043E\\u0442 \\u0442\\u0435\\u043A\\u0443\\u0449\\u0430\\u0442\\u0430 \\u0433\\u043E\\u0434\\u0438\\u043D\\u0430\r\n\r\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\r\nREVENUE_LAST=\\u041F\\u0440\\u0438\\u0445\\u043E\\u0434 \\u043C\\u0438\\u043D.\\u0433\\u043E\\u0434\\u0438\\u043D\\u0430\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\r\nREVENUE_LAST_TOOLTIP=\\u041F\\u0440\\u0438\\u0445\\u043E\\u0434 \\u043C\\u0438\\u043D.\\u0433\\u043E\\u0434\\u0438\\u043D\\u0430\r\n\r\n# XFLD, 30: Facet title for opportunities and label in facet general data\r\nOPPORTUNITIES=\\u0412\\u044A\\u0437\\u043C\\u043E\\u0436\\u043D\\u043E\\u0441\\u0442\\u0438\r\n\r\n#XFLD, 30: Facet title for leads\r\nLEADS=\\u041F\\u043E\\u0442\\u0435\\u043D\\u0446\\u0438\\u0430\\u043B\\u043D\\u0438 \\u0432\\u044A\\u0437\\u043C\\u043E\\u0436\\u043D\\u043E\\u0441\\u0442\\u0438\r\n\r\n#XFLD, 30: Facet title for tasks\r\nTASKS=\\u0417\\u0430\\u0434\\u0430\\u043D\\u0438\\u044F\r\n\r\n#XFLD, 30: Facet title for appointments\r\nAPPOINTMENTS=\\u0421\\u0440\\u043E\\u043A\\u043E\\u0432\\u0435\r\n\r\n#XFLD, 30: Facet title for quotations\r\nQUOTATIONS=\\u041E\\u0444\\u0435\\u0440\\u0442\\u0438\r\n\r\n#XFLD, 30: Facet title for sales orders\r\nSALES_ORDERS=\\u041A\\u043B\\u0438\\u0435\\u043D\\u0442\\u0441\\u043A\\u0438 \\u043F\\u043E\\u0440\\u044A\\u0447\\u043A\\u0438\r\n\r\n#XFLD, 30: W7: Facet title for marketing attributes\r\nMARKETINGATTRIBUTES=\\u041C\\u0430\\u0440\\u043A\\u0435\\u0442\\u0438\\u043D\\u0433\\u043E\\u0432\\u0438 \\u0430\\u0442\\u0440\\u0438\\u0431\\u0443\\u0442\\u0438\r\n\r\n#XFLD, 30: W6: Title for popup with products\r\nPRODUCTS=\\u041F\\u0440\\u043E\\u0434\\u0443\\u043A\\u0442\\u0438\r\n\r\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\r\nEMPLOYEE_RESPONSIBLE=\\u041E\\u0442\\u0433\\u043E\\u0432\\u043E\\u0440\\u0435\\u043D \\u0441\\u043B\\u0443\\u0436\\u0438\\u0442\\u0435\\u043B\r\n\r\n#XFLD, 30: Facet title for Attachments\r\nATTACHMENTS=\\u041F\\u0440\\u0438\\u043B\\u043E\\u0436\\u0435\\u043D\\u0438\\u044F\r\n\r\n#XFLD, 30: Facet title for Notes\r\nNOTES=\\u0411\\u0435\\u043B\\u0435\\u0436\\u043A\\u0438\r\n\r\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\r\nNEW_NOTE=\\u041D\\u043E\\u0432\\u0430 \\u0431\\u0435\\u043B\\u0435\\u0436\\u043A\\u0430\r\n\r\n#XFLD, 30: Facet title for Contacts\r\nCONTACTS=\\u041A\\u043E\\u043D\\u0442\\u0430\\u043A\\u0442\\u0438\r\n\r\n#XFLD, 30: Label for Address in facet general data\r\nADDRESS=\\u0410\\u0434\\u0440\\u0435\\u0441\r\n\r\n#XFLD, 30: Label for Opportunities in facet general data\r\nUNWEIGHTED_OPPORTUNITIES=\\u0412\\u044A\\u0437\\u043C\\u043E\\u0436\\u043D\\u043E\\u0441\\u0442\\u0438\r\n\r\n#XFLD, 30: Label for Rating in facet general data\r\nRATING=\\u041E\\u0446\\u0435\\u043D\\u043A\\u0430\r\n\r\n# XFLD, 30: Label for Next contact in facet Appointments\r\nNEXT_APPOINTMENT=\\u0421\\u043B\\u0435\\u0434\\u0432\\u0430\\u0449 \\u0441\\u0440\\u043E\\u043A\r\n\r\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\r\nLAST_APPOINTMENT=\\u041F\\u043E\\u0441\\u043B\\u0435\\u0434\\u0435\\u043D \\u0441\\u0440\\u043E\\u043A\r\n\r\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\r\nIMAGE=\\u0418\\u0437\\u043E\\u0431\\u0440\\u0430\\u0436.\r\n\r\n#XBUT, 20: Button to show the create actionsheet\r\nCREATE=\\u0421\\u044A\\u0437\\u0434\\u0430\\u0432\\u0430\\u043D\\u0435\r\n\r\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\r\nDISCUSS_ENTRY=\\u041E\\u0431\\u0441\\u044A\\u0436\\u0434\\u0430\\u043D\\u0435 \\u0432 SAP Jam\r\n\r\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\r\nSHARE_ENTRY=\\u0421\\u043F\\u043E\\u0434\\u0435\\u043B\\u044F\\u043D\\u0435 \\u0432 SAP Jam\r\n\r\n#XBUT, 20: Button to share the note\r\nDETAIL_BUTTON_SHARE=\\u0421\\u043F\\u043E\\u0434\\u0435\\u043B\\u044F\\u043D\\u0435\r\n\r\n#XBUT, 20: Button to cancel sharing\r\nDETAIL_BUTTON_CANCEL=\\u041E\\u0442\\u043A\\u0430\\u0437\r\n\r\n#XFLD,20: All accounts for filter\r\nALL_ACCOUNTS=\\u0412\\u0441\\u0438\\u0447\\u043A\\u0438 \\u0430\\u043A\\u0430\\u0443\\u043D\\u0442\\u0438\r\n\r\n#XFLD,35: All individual accounts for filter\r\nALL_INDIVIDUAL_ACCOUNTS=\\u0412\\u0441\\u0438\\u0447\\u043A\\u0438 \\u0438\\u043D\\u0434\\u0438\\u0432\\u0438\\u0434\\u0443\\u0430\\u043B\\u043D\\u0438 \\u0430\\u043A\\u0430\\u0443\\u043D\\u0442\\u0438\r\n\r\n#XFLD,35: All corporate accounts for filter\r\nALL_CORPORATE_ACCOUNTS=\\u0412\\u0441\\u0438\\u0447\\u043A\\u0438 \\u043A\\u043E\\u0440\\u043F\\u043E\\u0440\\u0430\\u0442\\u0438\\u0432\\u043D\\u0438 \\u0430\\u043A\\u0430\\u0443\\u043D\\u0442\\u0438\r\n\r\n#XFLD,35: All group accounts for filter\r\nALL_ACCOUNT_GROUPS=\\u0412\\u0441\\u0438\\u0447\\u043A\\u0438 \\u0433\\u0440\\u0443\\u043F\\u0438 \\u0430\\u043A\\u0430\\u0443\\u043D\\u0442\\u0438\r\n\r\n#XFLD,20: my account for filter\r\nMY_ACCOUNT=\\u041C\\u043E\\u0438\\u0442\\u0435 \\u0430\\u043A\\u0430\\u0443\\u043D\\u0442\\u0438\r\n\r\n#XFLD,35: my individual accounts for filter\r\nMY_INDIVIDUAL_ACCOUNTS=\\u041C\\u043E\\u0438\\u0442\\u0435 \\u0438\\u043D\\u0434\\u0438\\u0432\\u0438\\u0434\\u0443\\u0430\\u043B\\u043D\\u0438 \\u0430\\u043A\\u0430\\u0443\\u043D\\u0442\\u0438\r\n\r\n#XFLD,35: my corporate accounts for filter\r\nMY_CORPORATE_ACCOUNTS=\\u041C\\u043E\\u0438\\u0442\\u0435 \\u043A\\u043E\\u0440\\u043F\\u043E\\u0440\\u0430\\u0442\\u0438\\u0432\\u043D\\u0438 \\u0430\\u043A\\u0430\\u0443\\u043D\\u0442\\u0438\r\n\r\n#XFLD,35: my group accounts for filter\r\nMY_ACCOUNT_GROUPS=\\u041C\\u043E\\u0438\\u0442\\u0435 \\u0433\\u0440\\u0443\\u043F\\u0438 \\u0430\\u043A\\u0430\\u0443\\u043D\\u0442\\u0438\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nINDIVIDUAL_ACCOUNT=\\u0418\\u043D\\u0434\\u0438\\u0432\\u0438\\u0434\\u0443\\u0430\\u043B\\u0435\\u043D \\u0430\\u043A\\u0430\\u0443\\u043D\\u0442\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nCORPORATE_ACCOUNT=\\u041A\\u043E\\u0440\\u043F\\u043E\\u0440\\u0430\\u0442\\u0438\\u0432\\u0435\\u043D \\u0430\\u043A\\u0430\\u0443\\u043D\\u0442\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nACCOUNT_GROUP=\\u0413\\u0440\\u0443\\u043F\\u0430 \\u0430\\u043A\\u0430\\u0443\\u043D\\u0442\\u0438\r\n\r\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\r\nSTARTING=\\u041D\\u0430\\u0447\\u0430\\u043B\\u043D\\u0430 \\u0434\\u0430\\u0442\\u0430\\: {0}\r\n\r\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\r\nCLOSING=\\u0414\\u0430\\u0442\\u0430 \\u043F\\u0440\\u0438\\u043A\\u043B\\u044E\\u0447\\u0432\\u0430\\u043D\\u0435\\: {0}\r\n\r\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\r\nDUE=\\u041A\\u0440\\u0430\\u0439\\u043D\\u0430 \\u0434\\u0430\\u0442\\u0430\\: {0}\r\n\r\n#XFLD,20: All accounts for title\r\nALL_ACCOUNTS_TITLE=\\u0412\\u0441\\u0438\\u0447\\u043A\\u0438 \\u0430\\u043A\\u0430\\u0443\\u043D\\u0442\\u0438 ({0})\r\n\r\n#XFLD,35: All individual accounts for title\r\nALL_INDIVIDUAL_ACCOUNTS_TITLE=\\u0412\\u0441\\u0438\\u0447\\u043A\\u0438 \\u0438\\u043D\\u0434\\u0438\\u0432\\u0438\\u0434\\u0443\\u0430\\u043B\\u043D\\u0438 \\u0430\\u043A\\u0430\\u0443\\u043D\\u0442\\u0438 ({0})\r\n\r\n#XFLD,35: All corporate accounts for title\r\nALL_CORPORATE_ACCOUNTS_TITLE=\\u0412\\u0441\\u0438\\u0447\\u043A\\u0438 \\u043A\\u043E\\u0440\\u043F\\u043E\\u0440\\u0430\\u0442\\u0438\\u0432\\u043D\\u0438 \\u0430\\u043A\\u0430\\u0443\\u043D\\u0442\\u0438 ({0})\r\n\r\n#XFLD,35: All group accounts for title\r\nALL_ACCOUNT_GROUPS_TITLE=\\u0412\\u0441\\u0438\\u0447\\u043A\\u0438 \\u0433\\u0440\\u0443\\u043F\\u0438 \\u0430\\u043A\\u0430\\u0443\\u043D\\u0442\\u0438 ({0})\r\n\r\n#XFLD,20: my account for title\r\nMY_ACCOUNT_TITLE=\\u041C\\u043E\\u0438\\u0442\\u0435 \\u0430\\u043A\\u0430\\u0443\\u043D\\u0442\\u0438 ({0})\r\n\r\n#XFLD,35: my individual account for title\r\nMY_INDIVIDUAL_ACCOUNT_TITLE=\\u041C\\u043E\\u0438\\u0442\\u0435 \\u0438\\u043D\\u0434\\u0438\\u0432\\u0438\\u0434\\u0443\\u0430\\u043B\\u043D\\u0438 \\u0430\\u043A\\u0430\\u0443\\u043D\\u0442\\u0438 ({0})\r\n\r\n#XFLD,35: my corporate account for title.\r\nMY_CORPORATE_ACCOUNT_TITLE=\\u041C\\u043E\\u0438\\u0442\\u0435 \\u043A\\u043E\\u0440\\u043F\\u043E\\u0440\\u0430\\u0442\\u0438\\u0432\\u043D\\u0438 \\u0430\\u043A\\u0430\\u0443\\u043D\\u0442\\u0438 ({0})\r\n\r\n#XFLD,35: my group account for title\r\nMY_ACCOUNT_GROUP_TITLE=\\u041C\\u043E\\u0438\\u0442\\u0435 \\u0433\\u0440\\u0443\\u043F\\u0438 \\u0430\\u043A\\u0430\\u0443\\u043D\\u0442\\u0438 ({0})\r\n\r\n#XFLD,30: filtered by info\r\nFILTERED_BY=\\u0424\\u0438\\u043B\\u0442\\u0440\\u0438\\u0440\\u0430\\u043D \\u043F\\u043E\\: {0}\r\n\r\n#XFLD,30: label, search for accounts\r\nSEARCH_ACCOUNTS=\\u0422\\u044A\\u0440\\u0441\\u0435\\u043D\\u0435\r\n\r\n#XFLD,30: comma separator for location\r\nLOCATION={0}, {1}\r\n\r\n#XFLD: W4: Label for All day text in Appointments\r\nALL_DAY_EVENT=\\u0426\\u044F\\u043B \\u0434\\u0435\\u043D\r\n\r\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\r\nDURATION_MINUTE={0} \\u043C\\u0438\\u043D\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\r\nDURATION_HOUR={0} \\u0447\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\r\nDURATION_DAY={0} \\u0434\\u0435\\u043D\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\r\nDURATION_DAYS={0} \\u0434\\u043D\\u0438\r\n\r\n#XFLD: W4: Label for Private meeting\r\nPRIVATE=\\u041B\\u0438\\u0447\\u0435\\u043D\r\n\r\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\r\nSELECT_TRANSACTION_TYPE=\\u0418\\u0437\\u0431\\u043E\\u0440 \\u043D\\u0430 \\u0432\\u0438\\u0434 \\u0442\\u0440\\u0430\\u043D\\u0437\\u0430\\u043A\\u0446\\u0438\\u044F\r\n\r\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\r\nNEW_TASK_INPUT_PLACEHOLDER=\\u041D\\u043E\\u0432\\u0430 \\u0437\\u0430\\u0434\\u0430\\u0447\\u0430\r\n\r\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nNO_DATA_TEXT=\\u041D\\u044F\\u043C\\u0430 \\u0434\\u0430\\u043D\\u043D\\u0438\r\n\r\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nLOADING_TEXT=\\u0417\\u0430\\u0440\\u0435\\u0436\\u0434\\u0430\\u043D\\u0435...\r\n\r\n#XFLD,25: W4: Column label for name of contact person in contacts\r\nNAME=\\u0418\\u043C\\u0435\r\n\r\n#XFLD,25: W5: Column label for department of contact person in contacts\r\nDEPARTMENT=\\u041E\\u0442\\u0434\\u0435\\u043B\r\n\r\n#XFLD,15: W6: Column label for actions of contact person in contacts\r\nACTIONS=\\u0414\\u0435\\u0439\\u0441\\u0442\\u0432\\u0438\\u044F\r\n\r\n#XFLD,25: W4: Column label for description of lead in Leads\r\nDESCRIPTION=\\u041E\\u043F\\u0438\\u0441\\u0430\\u043D\\u0438\\u0435\r\n\r\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\r\nASSIGNED_TO=\\u041F\\u0440\\u0438\\u0441\\u044A\\u0435\\u0434\\u0438\\u043D\\u0435\\u043D \\u043A\\u044A\\u043C\r\n\r\n#XFLD,15: W4: Column label for end date of lead in Leads\r\nEND_DATE=\\u041A\\u0440\\u0430\\u0439\\u043D\\u0430 \\u0434\\u0430\\u0442\\u0430\r\n\r\n#XFLD,15: W4: Column label for qualification level of lead in Leads\r\nQUALIFICATION=\\u041A\\u0432\\u0430\\u043B\\u0438\\u0444\\u0438\\u043A\\u0430\\u0446\\u0438\\u044F\r\n\r\n#XFLD,15: W4: Column label for status of lead in Leads\r\nSTATUS=\\u0421\\u0442\\u0430\\u0442\\u0443\\u0441\r\n\r\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\r\nMAIN_CONTACT=\\u041E\\u0441\\u043D\\u043E\\u0432\\u0435\\u043D \\u0434\\u043E\\u0433\\u043E\\u0432\\u043E\\u0440\r\n\r\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\r\nVOLUME=\\u041E\\u0431\\u0435\\u043C\r\n\r\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\r\nPROBABILITY=\\u0412\\u0435\\u0440\\u043E\\u044F\\u0442\\u043D\\u043E\\u0441\\u0442\r\n\r\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\r\nCLOSE_BY=\\u0417\\u0430\\u043A\\u0440\\u0438\\u0432\\u0430\\u043D\\u0435 \\u0434\\u043E\r\n\r\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \r\nVIEWS=\\u0410\\u0441\\u043F\\u0435\\u043A\\u0442\\u0438\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\r\nCONTACT_TITLE=\\u041A\\u043E\\u043D\\u0442\\u0430\\u043A\\u0442\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\r\nEMPLOYEE_TITLE=\\u0421\\u043B\\u0443\\u0436\\u0438\\u0442\\u0435\\u043B\r\n\r\n#XTIT,20: W7: Title of pop-up used in confirm popup\r\nCONFIRM_TITLE=\\u041F\\u043E\\u0442\\u0432\\u044A\\u0440\\u0436\\u0434\\u0435\\u043D\\u0438\\u0435\r\n\r\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\r\nCOMPANY_NAME=\\u0418\\u043C\\u0435\r\n\r\n#XFLD,20: W4: Label for name 1 of a company used general data\r\nCOMPANY_NAME1=\\u0418\\u043C\\u0435 1\r\n\r\n#XFLD,20: W4: Label for name 2 of a company used general data\r\nCOMPANY_NAME2=\\u0418\\u043C\\u0435 2\r\n\r\n#XFLD,20: W4: Label for first name of a person used general data\r\nFIRST_NAME=\\u0421\\u043E\\u0431\\u0441\\u0442\\u0432\\u0435\\u043D\\u043E \\u0438\\u043C\\u0435\r\n\r\n#XFLD,20: W4: Label for last name of a person used general data\r\nLAST_NAME=\\u0424\\u0430\\u043C\\u0438\\u043B\\u0438\\u044F\r\n\r\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nBIRTHDAY=\\u0414\\u0430\\u0442\\u0430 \\u043D\\u0430 \\u0440\\u0430\\u0436\\u0434\\u0430\\u043D\\u0435\r\n\r\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nTITLE=\\u0417\\u0430\\u0433\\u043B\\u0430\\u0432\\u0438\\u0435\r\n\r\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nACADEMIC_TITLE=\\u041D\\u0430\\u0443\\u0447\\u043D\\u0430 \\u0441\\u0442\\u0435\\u043F\\u0435\\u043D\r\n\r\n#XFLD,20: W4: Label for mobile phone number used general data\r\nMOBILE=\\u041C\\u043E\\u0431\\u0438\\u043B\\u0435\\u043D\r\n\r\n#XFLD,20: W4: Label for phone number used general data\r\nPHONE=\\u0422\\u0435\\u043B\\u0435\\u0444\\u043E\\u043D\r\n\r\n#XFLD,20: W4: Label for e-mail used general data\r\nEMAIL=\\u0418\\u043C\\u0435\\u0439\\u043B\r\n\r\n#XFLD,20: W4: Label for web site used general data\r\nWEBSITE=\\u0423\\u0435\\u0431\\u0441\\u0430\\u0439\\u0442\r\n\r\n#XFLD,20: W4: Label for country used general data\r\nCOUNTRY=\\u0414\\u044A\\u0440\\u0436\\u0430\\u0432\\u0430\r\n\r\n#XFLD,20: W4: Label for region used general data\r\nREGION=\\u0420\\u0435\\u0433\\u0438\\u043E\\u043D\r\n\r\n#XFLD,20: W4: Label for city used general data\r\nCITY=\\u0413\\u0440\\u0430\\u0434\r\n\r\n#XFLD,20: W4: Label for postal code used general data\r\nPOSTAL_CODE=\\u041F\\u043E\\u0449\\u0435\\u043D\\u0441\\u043A\\u0438 \\u041A\\u043E\\u0434\r\n\r\n#XFLD,20: W4: Label for street used general data\r\nSTREET=\\u0423\\u043B\\u0438\\u0446\\u0430\r\n\r\n#XFLD,10: W4: Label for house number used general data\r\nHOUSE_NUMBER=\\u041D\\u043E\\u043C\\u0435\\u0440 \\u043A\\u044A\\u0449\\u0430\r\n\r\n#XFLD,15: W6: Label for ID used in Quotations\r\nID=\\u0418\\u0414\r\n\r\n#XFLD,15: W6: Label for Amount used in Quotations\r\nAMOUNT=\\u0421\\u0443\\u043C\\u0430\r\n\r\n#XFLD,20: W6: Label for Expiration Date used in Quotations\r\nEXPIRATION_DATE=\\u0421\\u0440\\u043E\\u043A \\u043D\\u0430 \\u0432\\u0430\\u043B\\u0438\\u0434\\u043D\\u043E\\u0441\\u0442\r\n\r\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\r\nDELIVERY_DATE=\\u0414\\u0430\\u0442\\u0430 \\u043D\\u0430 \\u0434\\u043E\\u0441\\u0442\\u0430\\u0432\\u043A\\u0430\r\n\r\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\r\nSALES_EMPLOYEE=\\u0422\\u044A\\u0440\\u0433\\u043E\\u0432\\u0441\\u043A\\u0438 \\u0441\\u043B\\u0443\\u0436\\u0438\\u0442\\u0435\\u043B\r\n\r\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\r\nATTRIBUTESET=\\u041D\\u0430\\u0431\\u043E\\u0440 \\u0430\\u0442\\u0440\\u0438\\u0431\\u0443\\u0442\\u0438\r\n\r\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\r\nATTRIBUTE=\\u0410\\u0442\\u0440\\u0438\\u0431\\u0443\\u0442\r\n\r\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\r\nVALUE=\\u0421\\u0442\\u043E\\u0439\\u043D\\u043E\\u0441\\u0442\r\n\r\n#XBUT, 20: Button to create an Account\r\nBUTTON_ADD=\\u0414\\u043E\\u0431\\u0430\\u0432\\u044F\\u043D\\u0435\r\n\r\n#XBUT, 20: Button to edit an Account\r\nBUTTON_EDIT=\\u0420\\u0435\\u0434\\u0430\\u043A\\u0446\\u0438\\u044F\r\n\r\n#XBUT, 20: Button to save changes\r\nBUTTON_SAVE=\\u0417\\u0430\\u043F\\u0430\\u0437\\u0432\\u0430\\u043D\\u0435\r\n\r\n#XBUT, 20: Button to cancel changes\r\nBUTTON_CANCEL=\\u041E\\u0442\\u043A\\u0430\\u0437\r\n\r\n#XBUT, 30: Button which shows the personalization buttons\r\nBUTTON_SHOW_PERSONALIZATION=\\u041F\\u043E\\u043A\\u0430\\u0437\\u0432\\u0430\\u043D\\u0435 \\u043D\\u0430 \\u043F\\u0435\\u0440\\u0441\\u043E\\u043D\\u0430\\u043B\\u0438\\u0437\\u0430\\u0446\\u0438\\u044F\r\n\r\n#XBUT, 30: Button which hides the personalization buttons\r\nBUTTON_HIDE_PERSONALIZATION=\\u0421\\u043A\\u0440\\u0438\\u0432\\u0430\\u043D\\u0435 \\u043D\\u0430 \\u043F\\u0435\\u0440\\u0441\\u043E\\u043D\\u0430\\u043B\\u0438\\u0437\\u0430\\u0446\\u0438\\u044F\r\n\r\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_CONFIRM_CANCEL=\\u041D\\u0435\\u0437\\u0430\\u043F\\u0430\\u0437\\u0435\\u043D\\u0438\\u0442\\u0435 \\u043F\\u0440\\u043E\\u043C\\u0435\\u043D\\u0438 \\u0449\\u0435 \\u0431\\u044A\\u0434\\u0430\\u0442 \\u0438\\u0437\\u0433\\u0443\\u0431\\u0435\\u043D\\u0438. \\u0416\\u0435\\u043B\\u0430\\u0435\\u0442\\u0435 \\u043B\\u0438 \\u043F\\u0440\\u043E\\u0434\\u044A\\u043B\\u0436\\u0430\\u0432\\u0430\\u043D\\u0435?\r\n\r\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\r\nMSG_CONFIRM_DELETE_CONTACT=\\u041F\\u0440\\u0438\\u0441\\u044A\\u0435\\u0434\\u0438\\u043D\\u044F\\u0432\\u0430\\u043D\\u0435\\u0442\\u043E \\u043D\\u0430 \\u043A\\u043E\\u043D\\u0442\\u0430\\u043A\\u0442\\u0430 \\u0430\\u043A\\u0430\\u0443\\u043D\\u0442\\u0430 \\u0449\\u0435 \\u0431\\u044A\\u0434\\u0435 \\u043E\\u0442\\u043C\\u0435\\u043D\\u0435\\u043D\\u043E. \\u0416\\u0435\\u043B\\u0430\\u0435\\u0442\\u0435 \\u043B\\u0438 \\u0434\\u0430 \\u043F\\u0440\\u043E\\u0434\\u044A\\u043B\\u0436\\u0438\\u0442\\u0435?\r\n\r\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_SUCCESS=\\u0410\\u043A\\u0430\\u0443\\u043D\\u0442\\u044A\\u0442 \\u0435 \\u0430\\u043A\\u0442\\u0443\\u0430\\u043B\\u0438\\u0437\\u0438\\u0440\\u0430\\u043D\r\n\r\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_ERROR=\\u041D\\u0435\\u0443\\u0441\\u043F\\u0435\\u0448\\u043D\\u0430 \\u0430\\u043A\\u0442\\u0443\\u0430\\u043B\\u0438\\u0437\\u0430\\u0446\\u0438\\u044F\r\n\r\n# XMSG : Account update succeeded\r\nMSG_CREATION_SUCCESS=\\u0410\\u043A\\u0430\\u0443\\u043D\\u0442\\u044A\\u0442 \\u0435 \\u0441\\u044A\\u0437\\u0434\\u0430\\u0434\\u0435\\u043D\r\n\r\n# XMSG : Task creation succeeded\r\nMSG_TASK_CREATION_SUCCESS=\\u0417\\u0430\\u0434\\u0430\\u0447\\u0430\\u0442\\u0430 \\u0435 \\u0441\\u044A\\u0437\\u0434\\u0430\\u0434\\u0435\\u043D\\u0430\r\n\r\n# XMSG : Contact creation failed\r\nMSG_CREATION_ERROR=\\u041D\\u0435\\u0443\\u0441\\u043F\\u0435\\u0448\\u043D\\u043E \\u0441\\u044A\\u0437\\u0434\\u0430\\u0432\\u0430\\u043D\\u0435\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong country\r\nMSG_WRONG_COUNTRY_ERROR=\\u0414\\u044A\\u0440\\u0436\\u0430\\u0432\\u0430 "{0}" \\u043D\\u0435 \\u0441\\u044A\\u0449\\u0435\\u0441\\u0442\\u0432\\u0443\\u0432\\u0430\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong region\r\nMSG_WRONG_REGION_ERROR=\\u0420\\u0435\\u0433\\u0438\\u043E\\u043D "{0}" \\u043D\\u0435 \\u0441\\u044A\\u0449\\u0435\\u0441\\u0442\\u0432\\u0443\\u0432\\u0430 \\u0437\\u0430 \\u0434\\u044A\\u0440\\u0436\\u0430\\u0432\\u0430\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong employee\r\nMSG_WRONG_EMPLOYEE_ERROR=\\u0421\\u043B\\u0443\\u0436\\u0438\\u0442\\u0435\\u043B "{0}" \\u043D\\u0435 \\u0441\\u044A\\u0449\\u0435\\u0441\\u0442\\u0432\\u0443\\u0432\\u0430.\r\n\r\n# XMSG: message that will be displayed, if the user has entered invalid website url\r\nMSG_WRONG_URL_ERROR=\\u0412\\u044A\\u0432\\u0435\\u0434\\u0435\\u043D\\u0438\\u044F\\u0442 URL "{0}" \\u0435 \\u043D\\u0435\\u0432\\u0430\\u043B\\u0438\\u0434\\u0435\\u043D.\r\n\r\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\r\nMSG_MANDATORY_FIELDS=\\u041D\\u0435 \\u0441\\u0430 \\u043F\\u043E\\u043F\\u044A\\u043B\\u043D\\u0435\\u043D\\u0438 \\u0432\\u0441\\u0438\\u0447\\u043A\\u0438 \\u0437\\u0430\\u0434\\u044A\\u043B\\u0436\\u0438\\u0442\\u0435\\u043B\\u043D\\u0438 \\u043F\\u043E\\u043B\\u0435\\u0442\\u0430\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA=\\u0414\\u0430\\u043D\\u043D\\u0438\\u0442\\u0435 \\u0441\\u0430 \\u043F\\u0440\\u043E\\u043C\\u0435\\u043D\\u0435\\u043D\\u0438 \\u043E\\u0442 \\u0434\\u0440\\u0443\\u0433 \\u043F\\u043E\\u0442\\u0440\\u0435\\u0431\\u0438\\u0442\\u0435\\u043B. \\u0416\\u0435\\u043B\\u0430\\u0435\\u0442\\u0435 \\u043B\\u0438 \\u0434\\u0430 \\u043F\\u0440\\u0435\\u0437\\u0430\\u043F\\u0438\\u0448\\u0435\\u0442\\u0435 \\u043D\\u0435\\u0433\\u043E\\u0432\\u0438\\u0442\\u0435 \\u043F\\u0440\\u043E\\u043C\\u0435\\u043D\\u0438 \\u0441 \\u0432\\u0430\\u0448\\u0438\\u0442\\u0435?\r\n\r\n# XMSG: message that will be displayed in case of conflicts during file renaming\r\nMSG_CONFLICTING_FILE_NAME=\\u0418\\u043C\\u0435\\u0442\\u043E \\u043D\\u0430 \\u0444\\u0430\\u0439\\u043B\\u0430 \\u0435 \\u043F\\u0440\\u043E\\u043C\\u0435\\u043D\\u0435\\u043D\\u043E \\u043E\\u0442 \\u0434\\u0440\\u0443\\u0433 \\u043F\\u043E\\u0442\\u0440\\u0435\\u0431\\u0438\\u0442\\u0435\\u043B. \\u0416\\u0435\\u043B\\u0430\\u0435\\u0442\\u0435 \\u043B\\u0438 \\u0434\\u0430 \\u043F\\u0440\\u0435\\u0437\\u0430\\u043F\\u0438\\u0448\\u0435\\u0442\\u0435 \\u043D\\u0435\\u0433\\u043E\\u0432\\u0438\\u0442\\u0435 \\u043F\\u0440\\u043E\\u043C\\u0435\\u043D\\u0438 \\u0441 \\u0432\\u0430\\u0448\\u0438\\u0442\\u0435?\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA_WITH_REFRESH=\\u0414\\u0430\\u043D\\u043D\\u0438\\u0442\\u0435 \\u0441\\u0430 \\u043F\\u0440\\u043E\\u043C\\u0435\\u043D\\u0435\\u043D\\u0438 \\u043E\\u0442 \\u0434\\u0440\\u0443\\u0433 \\u043F\\u043E\\u0442\\u0440\\u0435\\u0431\\u0438\\u0442\\u0435\\u043B. \\u0422\\u0435\\u0437\\u0438 \\u043F\\u0440\\u043E\\u043C\\u0435\\u043D\\u0438 \\u0432\\u0435\\u0447\\u0435 \\u0449\\u0435 \\u0441\\u0435 \\u043F\\u043E\\u044F\\u0432\\u044F\\u0442 \\u0432 \\u043F\\u0440\\u0438\\u043B\\u043E\\u0436\\u0435\\u043D\\u0438\\u0435\\u0442\\u043E.\r\n\r\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\r\nMSG_NOT_IN_MAIN_CONTACT=\\u041C\\u043E\\u0436\\u0435\\u0442\\u0435 \\u0434\\u0430 \\u043F\\u0440\\u0435\\u0433\\u043B\\u0435\\u0434\\u0430\\u0442\\u0435 \\u0441\\u0430\\u043C\\u043E \\u043F\\u043E\\u0434\\u0440\\u043E\\u0431\\u043D\\u0438 \\u0434\\u0430\\u043D\\u043D\\u0438 \\u0437\\u0430 \\u043A\\u043E\\u043D\\u0442\\u0430\\u043A\\u0442\\u0438, \\u043A\\u043E\\u0438\\u0442\\u043E \\u0441\\u0430 \\u043F\\u0440\\u0438\\u0441\\u044A\\u0435\\u0434\\u0438\\u043D\\u0435\\u043D\\u0438 \\u043A\\u044A\\u043C \\u0442\\u043E\\u0437\\u0438 \\u0430\\u043A\\u0430\\u0443\\u043D\\u0442\r\n\r\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\r\nMSG_EXCEEDING_FILE_NAME_LENGTH=\\u0418\\u043C\\u0435\\u0442\\u043E \\u043D\\u0430 \\u0432\\u0430\\u0448\\u0438\\u044F \\u0444\\u0430\\u0439\\u043B \\u043C\\u043E\\u0436\\u0435 \\u0434\\u0430 \\u0438\\u043C\\u0430 \\u043C\\u0430\\u043A\\u0441\\u0438\\u043C\\u0443\\u043C 40 \\u0441\\u0438\\u043C\\u0432\\u043E\\u043B\\u0430.\r\n\r\n# XTOL, 20: tooltip shown on search result list for button to add an account"\r\n\r\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\r\n\r\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\r\n\r\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\r\n\r\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\r\n\r\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\r\n',
	"cus/crm/myaccounts/i18n/i18n_cs.properties":'# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XFLD, 30: Facet title for general Data\r\nGENERAL_DATA=Obecn\\u00E1 data\r\n\r\n#XTIT, 40: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=Moji z\\u00E1kazn\\u00EDci\r\n\r\n#XTIT, 40: this is the title for the detail screen\r\nDETAIL_TITLE=Z\\u00E1kazn\\u00EDk\r\n\r\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\r\nREVENUE_CURRENT=V\\u00FDnos-aktRokDodnes\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\r\nREVENUE_CURRENT_TOOLTIP=V\\u00FDnosy do dne\\u0161ka - aktu\\u00E1ln\\u00ED rok\r\n\r\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\r\nREVENUE_LAST=V\\u00FDnos posledn\\u00ED rok\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\r\nREVENUE_LAST_TOOLTIP=V\\u00FDnosy posledn\\u00ED rok\r\n\r\n# XFLD, 30: Facet title for opportunities and label in facet general data\r\nOPPORTUNITIES=P\\u0159\\u00EDle\\u017Eitosti\r\n\r\n#XFLD, 30: Facet title for leads\r\nLEADS=Tipy\r\n\r\n#XFLD, 30: Facet title for tasks\r\nTASKS=\\u00DAlohy\r\n\r\n#XFLD, 30: Facet title for appointments\r\nAPPOINTMENTS=Sch\\u016Fzky\r\n\r\n#XFLD, 30: Facet title for quotations\r\nQUOTATIONS=Nab\\u00EDdky\r\n\r\n#XFLD, 30: Facet title for sales orders\r\nSALES_ORDERS=Zak\\u00E1zky odb\\u011Bratele\r\n\r\n#XFLD, 30: W7: Facet title for marketing attributes\r\nMARKETINGATTRIBUTES=Marketingov\\u00E9 atributy\r\n\r\n#XFLD, 30: W6: Title for popup with products\r\nPRODUCTS=Produkty\r\n\r\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\r\nEMPLOYEE_RESPONSIBLE=Odpov\\u011Bdn\\u00FD zam\\u011Bstnanec\r\n\r\n#XFLD, 30: Facet title for Attachments\r\nATTACHMENTS=P\\u0159\\u00EDlohy\r\n\r\n#XFLD, 30: Facet title for Notes\r\nNOTES=Pozn\\u00E1mky\r\n\r\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\r\nNEW_NOTE=Nov\\u00E1 pozn\\u00E1mka\r\n\r\n#XFLD, 30: Facet title for Contacts\r\nCONTACTS=Kontakty\r\n\r\n#XFLD, 30: Label for Address in facet general data\r\nADDRESS=Adresa\r\n\r\n#XFLD, 30: Label for Opportunities in facet general data\r\nUNWEIGHTED_OPPORTUNITIES=P\\u0159\\u00EDle\\u017Eitosti\r\n\r\n#XFLD, 30: Label for Rating in facet general data\r\nRATING=Rating\r\n\r\n# XFLD, 30: Label for Next contact in facet Appointments\r\nNEXT_APPOINTMENT=Dal\\u0161\\u00ED sch\\u016Fzka\r\n\r\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\r\nLAST_APPOINTMENT=Posledn\\u00ED sch\\u016Fzka\r\n\r\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\r\nIMAGE=Obr\\u00E1zek\r\n\r\n#XBUT, 20: Button to show the create actionsheet\r\nCREATE=Vytvo\\u0159it\r\n\r\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\r\nDISCUSS_ENTRY=Diskutovat v SAP Jam\r\n\r\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\r\nSHARE_ENTRY=Sd\\u00EDlet v SAP Jam\r\n\r\n#XBUT, 20: Button to share the note\r\nDETAIL_BUTTON_SHARE=Sd\\u00EDlet\r\n\r\n#XBUT, 20: Button to cancel sharing\r\nDETAIL_BUTTON_CANCEL=Zru\\u0161it\r\n\r\n#XFLD,20: All accounts for filter\r\nALL_ACCOUNTS=V\\u0161ichni z\\u00E1kazn\\u00EDci\r\n\r\n#XFLD,35: All individual accounts for filter\r\nALL_INDIVIDUAL_ACCOUNTS=V\\u0161ichni individu\\u00E1ln\\u00ED z\\u00E1kazn\\u00EDci\r\n\r\n#XFLD,35: All corporate accounts for filter\r\nALL_CORPORATE_ACCOUNTS=V\\u0161ichni podnikov\\u00ED z\\u00E1kazn\\u00EDci\r\n\r\n#XFLD,35: All group accounts for filter\r\nALL_ACCOUNT_GROUPS=V\\u0161echny skupiny z\\u00E1kazn\\u00EDk\\u016F\r\n\r\n#XFLD,20: my account for filter\r\nMY_ACCOUNT=Moji z\\u00E1kazn\\u00EDci\r\n\r\n#XFLD,35: my individual accounts for filter\r\nMY_INDIVIDUAL_ACCOUNTS=Moji individu\\u00E1ln\\u00ED z\\u00E1kazn\\u00EDci\r\n\r\n#XFLD,35: my corporate accounts for filter\r\nMY_CORPORATE_ACCOUNTS=Moji podnikov\\u00ED z\\u00E1kazn\\u00EDci\r\n\r\n#XFLD,35: my group accounts for filter\r\nMY_ACCOUNT_GROUPS=Moje skupiny z\\u00E1kazn\\u00EDk\\u016F\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nINDIVIDUAL_ACCOUNT=Individu\\u00E1ln\\u00ED z\\u00E1kazn\\u00EDk\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nCORPORATE_ACCOUNT=Podnikov\\u00FD z\\u00E1kazn\\u00EDk\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nACCOUNT_GROUP=\\u00DA\\u010Dtov\\u00E1 skupina\r\n\r\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\r\nSTARTING=Po\\u010D\\u00E1te\\u010Dn\\u00ED datum\\: {0}\r\n\r\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\r\nCLOSING=Datum uzav\\u0159en\\u00ED\\: {0}\r\n\r\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\r\nDUE=Term\\u00EDn\\: {0}\r\n\r\n#XFLD,20: All accounts for title\r\nALL_ACCOUNTS_TITLE=V\\u0161ichni z\\u00E1kazn\\u00EDci ({0})\r\n\r\n#XFLD,35: All individual accounts for title\r\nALL_INDIVIDUAL_ACCOUNTS_TITLE=V\\u0161ichni individu\\u00E1ln\\u00ED z\\u00E1kazn\\u00EDci ({0})\r\n\r\n#XFLD,35: All corporate accounts for title\r\nALL_CORPORATE_ACCOUNTS_TITLE=V\\u0161ichni podnikov\\u00ED z\\u00E1kazn\\u00EDci ({0})\r\n\r\n#XFLD,35: All group accounts for title\r\nALL_ACCOUNT_GROUPS_TITLE=V\\u0161echny skupiny z\\u00E1kazn\\u00EDk\\u016F ({0})\r\n\r\n#XFLD,20: my account for title\r\nMY_ACCOUNT_TITLE=Moji z\\u00E1kazn\\u00EDci ({0})\r\n\r\n#XFLD,35: my individual account for title\r\nMY_INDIVIDUAL_ACCOUNT_TITLE=Moji individu\\u00E1ln\\u00ED z\\u00E1kazn\\u00EDci ({0})\r\n\r\n#XFLD,35: my corporate account for title.\r\nMY_CORPORATE_ACCOUNT_TITLE=Moji podnikov\\u00ED z\\u00E1kazn\\u00EDci ({0})\r\n\r\n#XFLD,35: my group account for title\r\nMY_ACCOUNT_GROUP_TITLE=Moje skupiny z\\u00E1kazn\\u00EDk\\u016F ({0})\r\n\r\n#XFLD,30: filtered by info\r\nFILTERED_BY=Filtrov\\u00E1no podle\\: {0}\r\n\r\n#XFLD,30: label, search for accounts\r\nSEARCH_ACCOUNTS=Hledat\r\n\r\n#XFLD,30: comma separator for location\r\nLOCATION={0}, {1}\r\n\r\n#XFLD: W4: Label for All day text in Appointments\r\nALL_DAY_EVENT=Cel\\u00FD den\r\n\r\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\r\nDURATION_MINUTE={0} min.\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\r\nDURATION_HOUR={0} hod.\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\r\nDURATION_DAY={0} den\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\r\nDURATION_DAYS={0} dn\\u00ED\r\n\r\n#XFLD: W4: Label for Private meeting\r\nPRIVATE=Soukrom\\u00E9\r\n\r\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\r\nSELECT_TRANSACTION_TYPE=Vybrat typ transakce\r\n\r\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\r\nNEW_TASK_INPUT_PLACEHOLDER=Nov\\u00E1 \\u00FAloha\r\n\r\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nNO_DATA_TEXT=Chyb\\u00ED data\r\n\r\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nLOADING_TEXT=Zav\\u00E1d\\u00ED se...\r\n\r\n#XFLD,25: W4: Column label for name of contact person in contacts\r\nNAME=Jm\\u00E9no\r\n\r\n#XFLD,25: W5: Column label for department of contact person in contacts\r\nDEPARTMENT=Odd\\u011Blen\\u00ED\r\n\r\n#XFLD,15: W6: Column label for actions of contact person in contacts\r\nACTIONS=\\u010Cinnosti\r\n\r\n#XFLD,25: W4: Column label for description of lead in Leads\r\nDESCRIPTION=Popis\r\n\r\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\r\nASSIGNED_TO=P\\u0159i\\u0159azeno k\r\n\r\n#XFLD,15: W4: Column label for end date of lead in Leads\r\nEND_DATE=Koncov\\u00E9 datum\r\n\r\n#XFLD,15: W4: Column label for qualification level of lead in Leads\r\nQUALIFICATION=Kvalifikace\r\n\r\n#XFLD,15: W4: Column label for status of lead in Leads\r\nSTATUS=Status\r\n\r\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\r\nMAIN_CONTACT=Hlavn\\u00ED kontakt\r\n\r\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\r\nVOLUME=Objem\r\n\r\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\r\nPROBABILITY=Pravd\\u011Bpodobnost\r\n\r\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\r\nCLOSE_BY=Uzav\\u0159en\\u00ED do\r\n\r\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \r\nVIEWS=Zobrazen\\u00ED\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\r\nCONTACT_TITLE=Kontakt\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\r\nEMPLOYEE_TITLE=Zam\\u011Bstnanec\r\n\r\n#XTIT,20: W7: Title of pop-up used in confirm popup\r\nCONFIRM_TITLE=Potvrzen\\u00ED\r\n\r\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\r\nCOMPANY_NAME=N\\u00E1zev\r\n\r\n#XFLD,20: W4: Label for name 1 of a company used general data\r\nCOMPANY_NAME1=Jm\\u00E9no 1\r\n\r\n#XFLD,20: W4: Label for name 2 of a company used general data\r\nCOMPANY_NAME2=Jm\\u00E9no 2\r\n\r\n#XFLD,20: W4: Label for first name of a person used general data\r\nFIRST_NAME=K\\u0159estn\\u00ED jm\\u00E9no\r\n\r\n#XFLD,20: W4: Label for last name of a person used general data\r\nLAST_NAME=P\\u0159\\u00EDjmen\\u00ED\r\n\r\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nBIRTHDAY=Datum narozen\\u00ED\r\n\r\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nTITLE=Titul\r\n\r\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nACADEMIC_TITLE=Akademick\\u00FD titul\r\n\r\n#XFLD,20: W4: Label for mobile phone number used general data\r\nMOBILE=Mobiln\\u00ED telefon\r\n\r\n#XFLD,20: W4: Label for phone number used general data\r\nPHONE=Telefon\r\n\r\n#XFLD,20: W4: Label for e-mail used general data\r\nEMAIL=E-mail\r\n\r\n#XFLD,20: W4: Label for web site used general data\r\nWEBSITE=Webov\\u00E1 str\\u00E1nka\r\n\r\n#XFLD,20: W4: Label for country used general data\r\nCOUNTRY=St\\u00E1t\r\n\r\n#XFLD,20: W4: Label for region used general data\r\nREGION=Region\r\n\r\n#XFLD,20: W4: Label for city used general data\r\nCITY=M\\u011Bsto\r\n\r\n#XFLD,20: W4: Label for postal code used general data\r\nPOSTAL_CODE=PS\\u010C\r\n\r\n#XFLD,20: W4: Label for street used general data\r\nSTREET=Ulice\r\n\r\n#XFLD,10: W4: Label for house number used general data\r\nHOUSE_NUMBER=\\u010C. domu\r\n\r\n#XFLD,15: W6: Label for ID used in Quotations\r\nID=ID\r\n\r\n#XFLD,15: W6: Label for Amount used in Quotations\r\nAMOUNT=\\u010C\\u00E1stka\r\n\r\n#XFLD,20: W6: Label for Expiration Date used in Quotations\r\nEXPIRATION_DATE=Datum expirace\r\n\r\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\r\nDELIVERY_DATE=Datum dod\\u00E1vky\r\n\r\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\r\nSALES_EMPLOYEE=Pracovn\\u00EDk odbytu\r\n\r\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\r\nATTRIBUTESET=Sada atribut\\u016F\r\n\r\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\r\nATTRIBUTE=Atribut\r\n\r\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\r\nVALUE=Hodnota\r\n\r\n#XBUT, 20: Button to create an Account\r\nBUTTON_ADD=P\\u0159idat\r\n\r\n#XBUT, 20: Button to edit an Account\r\nBUTTON_EDIT=Upravit\r\n\r\n#XBUT, 20: Button to save changes\r\nBUTTON_SAVE=Ulo\\u017Eit\r\n\r\n#XBUT, 20: Button to cancel changes\r\nBUTTON_CANCEL=Zru\\u0161it\r\n\r\n#XBUT, 30: Button which shows the personalization buttons\r\nBUTTON_SHOW_PERSONALIZATION=Zobrazit personalizaci\r\n\r\n#XBUT, 30: Button which hides the personalization buttons\r\nBUTTON_HIDE_PERSONALIZATION=Skr\\u00FDt personalizaci\r\n\r\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_CONFIRM_CANCEL=V\\u0161echny neulo\\u017Een\\u00E9 zm\\u011Bny budou ztraceny. Chcete pokra\\u010Dovat?\r\n\r\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\r\nMSG_CONFIRM_DELETE_CONTACT=P\\u0159i\\u0159azen\\u00ED kontaktu k z\\u00E1kazn\\u00EDkovi bude zru\\u0161eno. Chcete pokra\\u010Dovat?\r\n\r\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_SUCCESS=Z\\u00E1kazn\\u00EDk aktualizov\\u00E1n\r\n\r\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_ERROR=Aktualizace se nezda\\u0159ila\r\n\r\n# XMSG : Account update succeeded\r\nMSG_CREATION_SUCCESS=Z\\u00E1kazn\\u00EDk vytvo\\u0159en\r\n\r\n# XMSG : Task creation succeeded\r\nMSG_TASK_CREATION_SUCCESS=\\u00DAloha vytvo\\u0159ena\r\n\r\n# XMSG : Contact creation failed\r\nMSG_CREATION_ERROR=Vytvo\\u0159en\\u00ED se nezda\\u0159ilo\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong country\r\nMSG_WRONG_COUNTRY_ERROR=St\\u00E1t \\u201E{0}\\u201C neexistuje\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong region\r\nMSG_WRONG_REGION_ERROR=Region \\u201E{0}\\u201C neexistuje pro st\\u00E1t\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong employee\r\nMSG_WRONG_EMPLOYEE_ERROR=Zam\\u011Bstnanec \\u201E{0}\\u201C neexistuje.\r\n\r\n# XMSG: message that will be displayed, if the user has entered invalid website url\r\nMSG_WRONG_URL_ERROR=Zadan\\u00E9 URL \\u201E{0}\\u201C nen\\u00ED platn\\u00E9.\r\n\r\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\r\nMSG_MANDATORY_FIELDS=V\\u0161echna povinn\\u00E1 pole nejsou vypln\\u011Bna.\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA=Data zm\\u011Bnil jin\\u00FD u\\u017Eivatel. Chcete p\\u0159epsat zm\\u011Bny jin\\u00E9ho u\\u017Eivatele vlastn\\u00EDmi?\r\n\r\n# XMSG: message that will be displayed in case of conflicts during file renaming\r\nMSG_CONFLICTING_FILE_NAME=N\\u00E1zev souboru zm\\u011Bnil jin\\u00FD u\\u017Eivatel. Chcete p\\u0159epsat zm\\u011Bny jin\\u00E9ho u\\u017Eivatele vlastn\\u00EDmi zm\\u011Bnami?\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA_WITH_REFRESH=Data zm\\u011Bnil jin\\u00FD u\\u017Eivatel. Tyto zm\\u011Bny se nyn\\u00ED zobraz\\u00ED v aplikaci.\r\n\r\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\r\nMSG_NOT_IN_MAIN_CONTACT=M\\u016F\\u017Eete zobrazit pouze detaily kontakt\\u016F, kter\\u00E9 jsou p\\u0159i\\u0159azen\\u00E9 tomuto z\\u00E1kazn\\u00EDkovi.\r\n\r\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\r\nMSG_EXCEEDING_FILE_NAME_LENGTH=N\\u00E1zev souboru m\\u016F\\u017Ee m\\u00EDt maxim\\u00E1ln\\u011B 40 znak\\u016F.\r\n\r\n# XTOL, 20: tooltip shown on search result list for button to add an account"\r\n\r\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\r\n\r\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\r\n\r\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\r\n\r\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\r\n\r\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\r\n',
	"cus/crm/myaccounts/i18n/i18n_de.properties":'# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XFLD, 30: Facet title for general Data\r\nGENERAL_DATA=Allgemeine Daten\r\n\r\n#XTIT, 40: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=Meine Accounts\r\n\r\n#XTIT, 40: this is the title for the detail screen\r\nDETAIL_TITLE=Account\r\n\r\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\r\nREVENUE_CURRENT=Umsatz lauf. Jahr\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\r\nREVENUE_CURRENT_TOOLTIP=Umsatz bis heute (laufendes Jahr)\r\n\r\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\r\nREVENUE_LAST=Umsatz Vorjahr\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\r\nREVENUE_LAST_TOOLTIP=Umsatz Vorjahr\r\n\r\n# XFLD, 30: Facet title for opportunities and label in facet general data\r\nOPPORTUNITIES=Opportunitys\r\n\r\n#XFLD, 30: Facet title for leads\r\nLEADS=Leads\r\n\r\n#XFLD, 30: Facet title for tasks\r\nTASKS=Aufgaben\r\n\r\n#XFLD, 30: Facet title for appointments\r\nAPPOINTMENTS=Termine\r\n\r\n#XFLD, 30: Facet title for quotations\r\nQUOTATIONS=Angebote\r\n\r\n#XFLD, 30: Facet title for sales orders\r\nSALES_ORDERS=Kundenauftr\\u00E4ge\r\n\r\n#XFLD, 30: W7: Facet title for marketing attributes\r\nMARKETINGATTRIBUTES=Marketingattribute\r\n\r\n#XFLD, 30: W6: Title for popup with products\r\nPRODUCTS=Produkte\r\n\r\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\r\nEMPLOYEE_RESPONSIBLE=Zust\\u00E4ndiger Mitarbeiter\r\n\r\n#XFLD, 30: Facet title for Attachments\r\nATTACHMENTS=Anlagen\r\n\r\n#XFLD, 30: Facet title for Notes\r\nNOTES=Notizen\r\n\r\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\r\nNEW_NOTE=Neue Notiz\r\n\r\n#XFLD, 30: Facet title for Contacts\r\nCONTACTS=Ansprechpartner\r\n\r\n#XFLD, 30: Label for Address in facet general data\r\nADDRESS=Adresse\r\n\r\n#XFLD, 30: Label for Opportunities in facet general data\r\nUNWEIGHTED_OPPORTUNITIES=Opportunitys\r\n\r\n#XFLD, 30: Label for Rating in facet general data\r\nRATING=Bewertung\r\n\r\n# XFLD, 30: Label for Next contact in facet Appointments\r\nNEXT_APPOINTMENT=N\\u00E4chster Termin\r\n\r\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\r\nLAST_APPOINTMENT=Letzter Termin\r\n\r\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\r\nIMAGE=Bild\r\n\r\n#XBUT, 20: Button to show the create actionsheet\r\nCREATE=Anlegen\r\n\r\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\r\nDISCUSS_ENTRY=In SAP Jam diskutieren\r\n\r\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\r\nSHARE_ENTRY=In SAP Jam teilen\r\n\r\n#XBUT, 20: Button to share the note\r\nDETAIL_BUTTON_SHARE=Teilen\r\n\r\n#XBUT, 20: Button to cancel sharing\r\nDETAIL_BUTTON_CANCEL=Abbrechen\r\n\r\n#XFLD,20: All accounts for filter\r\nALL_ACCOUNTS=Alle Accounts\r\n\r\n#XFLD,35: All individual accounts for filter\r\nALL_INDIVIDUAL_ACCOUNTS=Alle Privat-Accounts\r\n\r\n#XFLD,35: All corporate accounts for filter\r\nALL_CORPORATE_ACCOUNTS=Alle Unternehmens-Accounts\r\n\r\n#XFLD,35: All group accounts for filter\r\nALL_ACCOUNT_GROUPS=Alle Account-Gruppen\r\n\r\n#XFLD,20: my account for filter\r\nMY_ACCOUNT=Meine Accounts\r\n\r\n#XFLD,35: my individual accounts for filter\r\nMY_INDIVIDUAL_ACCOUNTS=Meine Privat-Accounts\r\n\r\n#XFLD,35: my corporate accounts for filter\r\nMY_CORPORATE_ACCOUNTS=Meine Unternehmens-Accounts\r\n\r\n#XFLD,35: my group accounts for filter\r\nMY_ACCOUNT_GROUPS=Meine Account-Gruppen\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nINDIVIDUAL_ACCOUNT=Privat-Account\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nCORPORATE_ACCOUNT=Unternehmens-Account\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nACCOUNT_GROUP=Account-Gruppe\r\n\r\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\r\nSTARTING=Startdatum\\: {0}\r\n\r\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\r\nCLOSING=Abschlussdatum\\: {0}\r\n\r\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\r\nDUE=F\\u00E4lligkeitsdatum\\: {0}\r\n\r\n#XFLD,20: All accounts for title\r\nALL_ACCOUNTS_TITLE=Alle Accounts ({0})\r\n\r\n#XFLD,35: All individual accounts for title\r\nALL_INDIVIDUAL_ACCOUNTS_TITLE=Alle Privat-Accounts ({0})\r\n\r\n#XFLD,35: All corporate accounts for title\r\nALL_CORPORATE_ACCOUNTS_TITLE=Alle Unternehmens-Accounts ({0})\r\n\r\n#XFLD,35: All group accounts for title\r\nALL_ACCOUNT_GROUPS_TITLE=Alle Account-Gruppen ({0})\r\n\r\n#XFLD,20: my account for title\r\nMY_ACCOUNT_TITLE=Meine Accounts ({0})\r\n\r\n#XFLD,35: my individual account for title\r\nMY_INDIVIDUAL_ACCOUNT_TITLE=Meine Privat-Accounts ({0})\r\n\r\n#XFLD,35: my corporate account for title.\r\nMY_CORPORATE_ACCOUNT_TITLE=Meine Unternehmens-Accounts ({0})\r\n\r\n#XFLD,35: my group account for title\r\nMY_ACCOUNT_GROUP_TITLE=Meine Account-Gruppen ({0})\r\n\r\n#XFLD,30: filtered by info\r\nFILTERED_BY=Gefiltert nach\\: {0}\r\n\r\n#XFLD,30: label, search for accounts\r\nSEARCH_ACCOUNTS=Suchen\r\n\r\n#XFLD,30: comma separator for location\r\nLOCATION={0}, {1}\r\n\r\n#XFLD: W4: Label for All day text in Appointments\r\nALL_DAY_EVENT=Ganzt\\u00E4gig\r\n\r\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\r\nDURATION_MINUTE={0} Min\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\r\nDURATION_HOUR={0} Std\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\r\nDURATION_DAY={0} Tag\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\r\nDURATION_DAYS={0} Tage\r\n\r\n#XFLD: W4: Label for Private meeting\r\nPRIVATE=Privat\r\n\r\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\r\nSELECT_TRANSACTION_TYPE=Vorgangsart ausw\\u00E4hlen\r\n\r\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\r\nNEW_TASK_INPUT_PLACEHOLDER=Neue Aufgabe\r\n\r\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nNO_DATA_TEXT=Keine Daten\r\n\r\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nLOADING_TEXT=Ladevorgang l\\u00E4uft...\r\n\r\n#XFLD,25: W4: Column label for name of contact person in contacts\r\nNAME=Name\r\n\r\n#XFLD,25: W5: Column label for department of contact person in contacts\r\nDEPARTMENT=Abteilung\r\n\r\n#XFLD,15: W6: Column label for actions of contact person in contacts\r\nACTIONS=Aktionen\r\n\r\n#XFLD,25: W4: Column label for description of lead in Leads\r\nDESCRIPTION=Beschreibung\r\n\r\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\r\nASSIGNED_TO=Zugeordnet zu\r\n\r\n#XFLD,15: W4: Column label for end date of lead in Leads\r\nEND_DATE=Enddatum\r\n\r\n#XFLD,15: W4: Column label for qualification level of lead in Leads\r\nQUALIFICATION=Qualifizierung\r\n\r\n#XFLD,15: W4: Column label for status of lead in Leads\r\nSTATUS=Status\r\n\r\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\r\nMAIN_CONTACT=Hauptansprechpartner\r\n\r\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\r\nVOLUME=Volumen\r\n\r\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\r\nPROBABILITY=Wahrscheinlichkeit\r\n\r\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\r\nCLOSE_BY=Abschluss bis\r\n\r\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \r\nVIEWS=Sichten\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\r\nCONTACT_TITLE=Ansprechpartner\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\r\nEMPLOYEE_TITLE=Mitarbeiter\r\n\r\n#XTIT,20: W7: Title of pop-up used in confirm popup\r\nCONFIRM_TITLE=Best\\u00E4tigen\r\n\r\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\r\nCOMPANY_NAME=Name\r\n\r\n#XFLD,20: W4: Label for name 1 of a company used general data\r\nCOMPANY_NAME1=Name 1\r\n\r\n#XFLD,20: W4: Label for name 2 of a company used general data\r\nCOMPANY_NAME2=Name 2\r\n\r\n#XFLD,20: W4: Label for first name of a person used general data\r\nFIRST_NAME=Vorname\r\n\r\n#XFLD,20: W4: Label for last name of a person used general data\r\nLAST_NAME=Nachname\r\n\r\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nBIRTHDAY=Geburtsdatum\r\n\r\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nTITLE=Anrede\r\n\r\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nACADEMIC_TITLE=Akademischer Titel\r\n\r\n#XFLD,20: W4: Label for mobile phone number used general data\r\nMOBILE=Mobil\r\n\r\n#XFLD,20: W4: Label for phone number used general data\r\nPHONE=Telefon\r\n\r\n#XFLD,20: W4: Label for e-mail used general data\r\nEMAIL=E-Mail\r\n\r\n#XFLD,20: W4: Label for web site used general data\r\nWEBSITE=Webseite\r\n\r\n#XFLD,20: W4: Label for country used general data\r\nCOUNTRY=Land\r\n\r\n#XFLD,20: W4: Label for region used general data\r\nREGION=Region\r\n\r\n#XFLD,20: W4: Label for city used general data\r\nCITY=Ort\r\n\r\n#XFLD,20: W4: Label for postal code used general data\r\nPOSTAL_CODE=Postleitzahl\r\n\r\n#XFLD,20: W4: Label for street used general data\r\nSTREET=Stra\\u00DFe\r\n\r\n#XFLD,10: W4: Label for house number used general data\r\nHOUSE_NUMBER=Hausnummer\r\n\r\n#XFLD,15: W6: Label for ID used in Quotations\r\nID=ID\r\n\r\n#XFLD,15: W6: Label for Amount used in Quotations\r\nAMOUNT=Betrag\r\n\r\n#XFLD,20: W6: Label for Expiration Date used in Quotations\r\nEXPIRATION_DATE=Ablaufdatum\r\n\r\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\r\nDELIVERY_DATE=Lieferdatum\r\n\r\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\r\nSALES_EMPLOYEE=Vertriebsmitarbeiter\r\n\r\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\r\nATTRIBUTESET=Attributgruppe\r\n\r\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\r\nATTRIBUTE=Attribut\r\n\r\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\r\nVALUE=Wert\r\n\r\n#XBUT, 20: Button to create an Account\r\nBUTTON_ADD=Hinzuf\\u00FCgen\r\n\r\n#XBUT, 20: Button to edit an Account\r\nBUTTON_EDIT=Bearbeiten\r\n\r\n#XBUT, 20: Button to save changes\r\nBUTTON_SAVE=Sichern\r\n\r\n#XBUT, 20: Button to cancel changes\r\nBUTTON_CANCEL=Abbrechen\r\n\r\n#XBUT, 30: Button which shows the personalization buttons\r\nBUTTON_SHOW_PERSONALIZATION=Personalisierung ein\r\n\r\n#XBUT, 30: Button which hides the personalization buttons\r\nBUTTON_HIDE_PERSONALIZATION=Personalisierung aus\r\n\r\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_CONFIRM_CANCEL=Ungesicherte \\u00C4nderungen gehen verloren. M\\u00F6chten Sie fortfahren?\r\n\r\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\r\nMSG_CONFIRM_DELETE_CONTACT=Die Zuordnung des Ansprechpartners zum Account wird entfernt. M\\u00F6chten Sie fortfahren?\r\n\r\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_SUCCESS=Account aktualisiert\r\n\r\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_ERROR=Aktualisierung fehlgeschlagen\r\n\r\n# XMSG : Account update succeeded\r\nMSG_CREATION_SUCCESS=Account angelegt\r\n\r\n# XMSG : Task creation succeeded\r\nMSG_TASK_CREATION_SUCCESS=Aufgabe angelegt\r\n\r\n# XMSG : Contact creation failed\r\nMSG_CREATION_ERROR=Anlegen fehlgeschlagen\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong country\r\nMSG_WRONG_COUNTRY_ERROR=Land "{0}" ist nicht vorhanden\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong region\r\nMSG_WRONG_REGION_ERROR=Region "{0}" ist f\\u00FCr das angegebene Land nicht vorhanden\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong employee\r\nMSG_WRONG_EMPLOYEE_ERROR=Mitarbeiter "{0}" ist nicht vorhanden.\r\n\r\n# XMSG: message that will be displayed, if the user has entered invalid website url\r\nMSG_WRONG_URL_ERROR=Die eingegebene URL "{0}" ist nicht g\\u00FCltig.\r\n\r\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\r\nMSG_MANDATORY_FIELDS=Es sind nicht alle erforderlichen Felder gef\\u00FCllt\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA=Daten wurden von einem anderen Benutzer ge\\u00E4ndert. M\\u00F6chten Sie die \\u00C4nderungen des anderen Benutzers mit Ihren \\u00C4nderungen \\u00FCberschreiben?\r\n\r\n# XMSG: message that will be displayed in case of conflicts during file renaming\r\nMSG_CONFLICTING_FILE_NAME=Der Dateiname wurde von einem anderen Benutzer ge\\u00E4ndert. M\\u00F6chten Sie die \\u00C4nderungen des anderen Benutzers mit Ihren \\u00C4nderungen \\u00FCberschreiben?\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA_WITH_REFRESH=Daten wurden von einem anderen Benutzer ge\\u00E4ndert. Diese \\u00C4nderungen sind nun in der App sichtbar.\r\n\r\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\r\nMSG_NOT_IN_MAIN_CONTACT=Sie k\\u00F6nnen nur Details zu Ansprechpartnern anzeigen, die zu diesem Account zugeordnet sind\r\n\r\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\r\nMSG_EXCEEDING_FILE_NAME_LENGTH=Ihr Dateiname darf maximal 40 Zeichen enthalten.\r\n\r\n# XTOL, 20: tooltip shown on search result list for button to add an account"\r\n\r\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\r\n\r\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\r\n\r\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\r\n\r\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\r\n\r\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\r\n',
	"cus/crm/myaccounts/i18n/i18n_en.properties":'# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XFLD, 30: Facet title for general Data\r\nGENERAL_DATA=General Data\r\n\r\n#XTIT, 40: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=My Accounts\r\n\r\n#XTIT, 40: this is the title for the detail screen\r\nDETAIL_TITLE=Account\r\n\r\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\r\nREVENUE_CURRENT=Revenue YTD\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\r\nREVENUE_CURRENT_TOOLTIP=Revenue to Date Current Year\r\n\r\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\r\nREVENUE_LAST=Revenue Last Year\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\r\nREVENUE_LAST_TOOLTIP=Revenue Last Year\r\n\r\n# XFLD, 30: Facet title for opportunities and label in facet general data\r\nOPPORTUNITIES=Opportunities\r\n\r\n#XFLD, 30: Facet title for leads\r\nLEADS=Leads\r\n\r\n#XFLD, 30: Facet title for tasks\r\nTASKS=Tasks\r\n\r\n#XFLD, 30: Facet title for appointments\r\nAPPOINTMENTS=Appointments\r\n\r\n#XFLD, 30: Facet title for quotations\r\nQUOTATIONS=Quotations\r\n\r\n#XFLD, 30: Facet title for sales orders\r\nSALES_ORDERS=Sales Orders\r\n\r\n#XFLD, 30: W7: Facet title for marketing attributes\r\nMARKETINGATTRIBUTES=Marketing Attributes\r\n\r\n#XFLD, 30: W6: Title for popup with products\r\nPRODUCTS=Products\r\n\r\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\r\nEMPLOYEE_RESPONSIBLE=Employee Responsible\r\n\r\n#XFLD, 30: Facet title for Attachments\r\nATTACHMENTS=Attachments\r\n\r\n#XFLD, 30: Facet title for Notes\r\nNOTES=Notes\r\n\r\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\r\nNEW_NOTE=New note\r\n\r\n#XFLD, 30: Facet title for Contacts\r\nCONTACTS=Contacts\r\n\r\n#XFLD, 30: Label for Address in facet general data\r\nADDRESS=Address\r\n\r\n#XFLD, 30: Label for Opportunities in facet general data\r\nUNWEIGHTED_OPPORTUNITIES=Opportunities\r\n\r\n#XFLD, 30: Label for Rating in facet general data\r\nRATING=Rating\r\n\r\n# XFLD, 30: Label for Next contact in facet Appointments\r\nNEXT_APPOINTMENT=Next Appointment\r\n\r\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\r\nLAST_APPOINTMENT=Last Appointment\r\n\r\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\r\nIMAGE=Image\r\n\r\n#XBUT, 20: Button to show the create actionsheet\r\nCREATE=Create\r\n\r\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\r\nDISCUSS_ENTRY=Discuss on SAP Jam\r\n\r\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\r\nSHARE_ENTRY=Share on SAP Jam\r\n\r\n#XBUT, 20: Button to share the note\r\nDETAIL_BUTTON_SHARE=Share\r\n\r\n#XBUT, 20: Button to cancel sharing\r\nDETAIL_BUTTON_CANCEL=Cancel\r\n\r\n#XFLD,20: All accounts for filter\r\nALL_ACCOUNTS=All Accounts\r\n\r\n#XFLD,35: All individual accounts for filter\r\nALL_INDIVIDUAL_ACCOUNTS=All Individual Accounts\r\n\r\n#XFLD,35: All corporate accounts for filter\r\nALL_CORPORATE_ACCOUNTS=All Corporate Accounts\r\n\r\n#XFLD,35: All group accounts for filter\r\nALL_ACCOUNT_GROUPS=All Account Groups\r\n\r\n#XFLD,20: my account for filter\r\nMY_ACCOUNT=My Accounts\r\n\r\n#XFLD,35: my individual accounts for filter\r\nMY_INDIVIDUAL_ACCOUNTS=My Individual Accounts\r\n\r\n#XFLD,35: my corporate accounts for filter\r\nMY_CORPORATE_ACCOUNTS=My Corporate Accounts\r\n\r\n#XFLD,35: my group accounts for filter\r\nMY_ACCOUNT_GROUPS=My Account Groups\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nINDIVIDUAL_ACCOUNT=Individual Account\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nCORPORATE_ACCOUNT=Corporate Account\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nACCOUNT_GROUP=Account Group\r\n\r\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\r\nSTARTING=Start Date\\: {0}\r\n\r\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\r\nCLOSING=Closing Date\\: {0}\r\n\r\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\r\nDUE=Due Date\\: {0}\r\n\r\n#XFLD,20: All accounts for title\r\nALL_ACCOUNTS_TITLE=All Accounts ({0})\r\n\r\n#XFLD,35: All individual accounts for title\r\nALL_INDIVIDUAL_ACCOUNTS_TITLE=All Individual Accounts ({0})\r\n\r\n#XFLD,35: All corporate accounts for title\r\nALL_CORPORATE_ACCOUNTS_TITLE=All Corporate Accounts ({0})\r\n\r\n#XFLD,35: All group accounts for title\r\nALL_ACCOUNT_GROUPS_TITLE=All Account Groups ({0})\r\n\r\n#XFLD,20: my account for title\r\nMY_ACCOUNT_TITLE=My Accounts ({0})\r\n\r\n#XFLD,35: my individual account for title\r\nMY_INDIVIDUAL_ACCOUNT_TITLE=My Individual Accounts ({0})\r\n\r\n#XFLD,35: my corporate account for title.\r\nMY_CORPORATE_ACCOUNT_TITLE=My Corporate Accounts ({0})\r\n\r\n#XFLD,35: my group account for title\r\nMY_ACCOUNT_GROUP_TITLE=My Account Groups ({0})\r\n\r\n#XFLD,30: filtered by info\r\nFILTERED_BY=Filtered By\\: {0}\r\n\r\n#XFLD,30: label, search for accounts\r\nSEARCH_ACCOUNTS=Search\r\n\r\n#XFLD,30: comma separator for location\r\nLOCATION={0}, {1}\r\n\r\n#XFLD: W4: Label for All day text in Appointments\r\nALL_DAY_EVENT=All Day\r\n\r\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\r\nDURATION_MINUTE={0} min\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\r\nDURATION_HOUR={0} h\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\r\nDURATION_DAY={0} day\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\r\nDURATION_DAYS={0} days\r\n\r\n#XFLD: W4: Label for Private meeting\r\nPRIVATE=Private\r\n\r\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\r\nSELECT_TRANSACTION_TYPE=Select Transaction Type\r\n\r\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\r\nNEW_TASK_INPUT_PLACEHOLDER=New task\r\n\r\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nNO_DATA_TEXT=No data\r\n\r\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nLOADING_TEXT=Loading...\r\n\r\n#XFLD,25: W4: Column label for name of contact person in contacts\r\nNAME=Name\r\n\r\n#XFLD,25: W5: Column label for department of contact person in contacts\r\nDEPARTMENT=Department\r\n\r\n#XFLD,15: W6: Column label for actions of contact person in contacts\r\nACTIONS=Actions\r\n\r\n#XFLD,25: W4: Column label for description of lead in Leads\r\nDESCRIPTION=Description\r\n\r\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\r\nASSIGNED_TO=Assigned To\r\n\r\n#XFLD,15: W4: Column label for end date of lead in Leads\r\nEND_DATE=End Date\r\n\r\n#XFLD,15: W4: Column label for qualification level of lead in Leads\r\nQUALIFICATION=Qualification\r\n\r\n#XFLD,15: W4: Column label for status of lead in Leads\r\nSTATUS=Status\r\n\r\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\r\nMAIN_CONTACT=Main Contact\r\n\r\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\r\nVOLUME=Volume\r\n\r\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\r\nPROBABILITY=Probability\r\n\r\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\r\nCLOSE_BY=Close By\r\n\r\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \r\nVIEWS=Views\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\r\nCONTACT_TITLE=Contact\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\r\nEMPLOYEE_TITLE=Employee\r\n\r\n#XTIT,20: W7: Title of pop-up used in confirm popup\r\nCONFIRM_TITLE=Confirm\r\n\r\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\r\nCOMPANY_NAME=Name\r\n\r\n#XFLD,20: W4: Label for name 1 of a company used general data\r\nCOMPANY_NAME1=Name 1\r\n\r\n#XFLD,20: W4: Label for name 2 of a company used general data\r\nCOMPANY_NAME2=Name 2\r\n\r\n#XFLD,20: W4: Label for first name of a person used general data\r\nFIRST_NAME=First Name\r\n\r\n#XFLD,20: W4: Label for last name of a person used general data\r\nLAST_NAME=Last Name\r\n\r\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nBIRTHDAY=Date of Birth\r\n\r\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nTITLE=Title\r\n\r\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nACADEMIC_TITLE=Academic Title\r\n\r\n#XFLD,20: W4: Label for mobile phone number used general data\r\nMOBILE=Mobile\r\n\r\n#XFLD,20: W4: Label for phone number used general data\r\nPHONE=Phone\r\n\r\n#XFLD,20: W4: Label for e-mail used general data\r\nEMAIL=Email\r\n\r\n#XFLD,20: W4: Label for web site used general data\r\nWEBSITE=Website\r\n\r\n#XFLD,20: W4: Label for country used general data\r\nCOUNTRY=Country\r\n\r\n#XFLD,20: W4: Label for region used general data\r\nREGION=Region\r\n\r\n#XFLD,20: W4: Label for city used general data\r\nCITY=City\r\n\r\n#XFLD,20: W4: Label for postal code used general data\r\nPOSTAL_CODE=Postal Code\r\n\r\n#XFLD,20: W4: Label for street used general data\r\nSTREET=Street\r\n\r\n#XFLD,10: W4: Label for house number used general data\r\nHOUSE_NUMBER=House No.\r\n\r\n#XFLD,15: W6: Label for ID used in Quotations\r\nID=ID\r\n\r\n#XFLD,15: W6: Label for Amount used in Quotations\r\nAMOUNT=Amount\r\n\r\n#XFLD,20: W6: Label for Expiration Date used in Quotations\r\nEXPIRATION_DATE=Expiration Date\r\n\r\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\r\nDELIVERY_DATE=Delivery Date\r\n\r\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\r\nSALES_EMPLOYEE=Sales Employee\r\n\r\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\r\nATTRIBUTESET=Attribute Set\r\n\r\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\r\nATTRIBUTE=Attribute\r\n\r\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\r\nVALUE=Value\r\n\r\n#XBUT, 20: Button to create an Account\r\nBUTTON_ADD=Add\r\n\r\n#XBUT, 20: Button to edit an Account\r\nBUTTON_EDIT=Edit\r\n\r\n#XBUT, 20: Button to save changes\r\nBUTTON_SAVE=Save\r\n\r\n#XBUT, 20: Button to cancel changes\r\nBUTTON_CANCEL=Cancel\r\n\r\n#XBUT, 30: Button which shows the personalization buttons\r\nBUTTON_SHOW_PERSONALIZATION=Show Personalization\r\n\r\n#XBUT, 30: Button which hides the personalization buttons\r\nBUTTON_HIDE_PERSONALIZATION=Hide Personalization\r\n\r\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_CONFIRM_CANCEL=Any unsaved changes will be lost. Do you want to continue?\r\n\r\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\r\nMSG_CONFIRM_DELETE_CONTACT=The contact will be unassigned from the account. Do you want to continue?\r\n\r\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_SUCCESS=Account updated\r\n\r\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_ERROR=Update failed\r\n\r\n# XMSG : Account update succeeded\r\nMSG_CREATION_SUCCESS=Account created\r\n\r\n# XMSG : Task creation succeeded\r\nMSG_TASK_CREATION_SUCCESS=Task created\r\n\r\n# XMSG : Contact creation failed\r\nMSG_CREATION_ERROR=Creation failed\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong country\r\nMSG_WRONG_COUNTRY_ERROR=Country "{0}" does not exist\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong region\r\nMSG_WRONG_REGION_ERROR=Region "{0}" does not exist for country\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong employee\r\nMSG_WRONG_EMPLOYEE_ERROR=Employee "{0}" does not exist.\r\n\r\n# XMSG: message that will be displayed, if the user has entered invalid website url\r\nMSG_WRONG_URL_ERROR=Entered URL "{0}" is not valid.\r\n\r\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\r\nMSG_MANDATORY_FIELDS=Not all mandatory fields are filled\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA=Data has been changed by another user. Do you want to overwrite the other user\'s changes with your own?\r\n\r\n# XMSG: message that will be displayed in case of conflicts during file renaming\r\nMSG_CONFLICTING_FILE_NAME=The file name has been changed by another user. Do you want to overwrite the other user\'s changes with your own?\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA_WITH_REFRESH=Data has been changed by another user. These changes will now appear in the app.\r\n\r\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\r\nMSG_NOT_IN_MAIN_CONTACT=You can only view the details of contacts that are assigned to this account\r\n\r\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\r\nMSG_EXCEEDING_FILE_NAME_LENGTH=Your file name can have a maximum of 40 characters.\r\n\r\n# XTOL, 20: tooltip shown on search result list for button to add an account"\r\nADD_ACCOUNT_TOOLTIP=Add Account\r\n\r\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\r\nADD_MARKETING_ATTRIBUTE_TOOLTIP=Add Marketing Attribute\r\n\r\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\r\nADD_CONTACT_TOOLTIP=Add Contact\r\n\r\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\r\nADD_APPOINTMENT_TOOLTIP=Add Appointment\r\n\r\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\r\nADD_TASK_TOOLTIP=Add Task\r\n\r\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\r\nADD_OPPORTUNITY_TOOLTIP=Add Opportunity\r\n',
	"cus/crm/myaccounts/i18n/i18n_en_US_sappsd.properties":'# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XFLD, 30: Facet title for general Data\r\nGENERAL_DATA=[[[\\u0122\\u0113\\u014B\\u0113\\u0157\\u0105\\u013A \\u012C\\u014B\\u0192\\u014F\\u0157\\u0271\\u0105\\u0163\\u012F\\u014F\\u014B\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT, 40: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=[[[\\u039C\\u0177 \\u0100\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT, 40: this is the title for the detail screen\r\nDETAIL_TITLE=[[[\\u0100\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\r\nREVENUE_CURRENT=[[[\\u0158\\u0113\\u028B\\u0113\\u014B\\u0171\\u0113 \\u0176\\u0162\\u010E\\u2219]]]\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\r\nREVENUE_CURRENT_TOOLTIP=[[[\\u0158\\u0113\\u028B\\u0113\\u014B\\u0171\\u0113 \\u0163\\u014F \\u018C\\u0105\\u0163\\u0113 \\u010B\\u0171\\u0157\\u0157\\u0113\\u014B\\u0163 \\u0177\\u0113\\u0105\\u0157\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\r\nREVENUE_LAST=[[[\\!\\!\\!\\u0158\\u0113\\u028B\\u0113\\u014B\\u0171\\u0113 \\u013B\\u0105\\u015F\\u0163 \\u0176\\u0113\\u0105\\u0157]]]\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\r\nREVENUE_LAST_TOOLTIP=[[[\\u0158\\u0113\\u028B\\u0113\\u014B\\u0171\\u0113 \\u0163\\u014F \\u013A\\u0105\\u015F\\u0163 \\u0177\\u0113\\u0105\\u0157\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XFLD, 30: Facet title for opportunities and label in facet general data\r\nOPPORTUNITIES=[[[\\u014E\\u03C1\\u03C1\\u014F\\u0157\\u0163\\u0171\\u014B\\u012F\\u0163\\u012F\\u0113\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD, 30: Facet title for leads\r\nLEADS=[[[\\u013B\\u0113\\u0105\\u018C\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD, 30: Facet title for tasks\r\nTASKS=[[[\\u0162\\u0105\\u015F\\u0137\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD, 30: Facet title for appointments\r\nAPPOINTMENTS=[[[\\u0100\\u03C1\\u03C1\\u014F\\u012F\\u014B\\u0163\\u0271\\u0113\\u014B\\u0163\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD, 30: Facet title for quotations\r\nQUOTATIONS=[[[\\u01EC\\u0171\\u014F\\u0163\\u0105\\u0163\\u012F\\u014F\\u014B\\u015F\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD, 30: Facet title for sales orders\r\nSALES_ORDERS=[[[\\u015C\\u0105\\u013A\\u0113\\u015F \\u014E\\u0157\\u018C\\u0113\\u0157\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD, 30: W7: Facet title for marketing attributes\r\nMARKETINGATTRIBUTES=[[[\\u039C\\u0105\\u0157\\u0137\\u0113\\u0163\\u012F\\u014B\\u011F \\u0100\\u0163\\u0163\\u0157\\u012F\\u0183\\u0171\\u0163\\u0113\\u015F\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD, 30: W6: Title for popup with products\r\nPRODUCTS=[[[\\u01A4\\u0157\\u014F\\u018C\\u0171\\u010B\\u0163\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\r\nEMPLOYEE_RESPONSIBLE=[[[\\u0114\\u0271\\u03C1\\u013A\\u014F\\u0177\\u0113\\u0113 \\u0158\\u0113\\u015F\\u03C1\\u014F\\u014B\\u015F\\u012F\\u0183\\u013A\\u0113\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD, 30: Facet title for Attachments\r\nATTACHMENTS=[[[\\u0100\\u0163\\u0163\\u0105\\u010B\\u0125\\u0271\\u0113\\u014B\\u0163\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD, 30: Facet title for Notes\r\nNOTES=[[[\\u0143\\u014F\\u0163\\u0113\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\r\nNEW_NOTE=[[[\\u0143\\u0113\\u0175 \\u0143\\u014F\\u0163\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD, 30: Facet title for Contacts\r\nCONTACTS=[[[\\u0108\\u014F\\u014B\\u0163\\u0105\\u010B\\u0163\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD, 30: Label for Address in facet general data\r\nADDRESS=[[[\\u0100\\u018C\\u018C\\u0157\\u0113\\u015F\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD, 30: Label for Opportunities in facet general data\r\nUNWEIGHTED_OPPORTUNITIES=[[[\\u014E\\u03C1\\u03C1\\u014F\\u0157\\u0163\\u0171\\u014B\\u012F\\u0163\\u012F\\u0113\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD, 30: Label for Rating in facet general data\r\nRATING=[[[\\u0158\\u0105\\u0163\\u012F\\u014B\\u011F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XFLD, 30: Label for Next contact in facet Appointments\r\nNEXT_APPOINTMENT=[[[\\u0143\\u0113\\u03C7\\u0163 \\u0100\\u03C1\\u03C1\\u014F\\u012F\\u014B\\u0163\\u0271\\u0113\\u014B\\u0163\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\r\nLAST_APPOINTMENT=[[[\\u013B\\u0105\\u015F\\u0163 \\u0100\\u03C1\\u03C1\\u014F\\u012F\\u014B\\u0163\\u0271\\u0113\\u014B\\u0163\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\r\nIMAGE=[[[\\!\\!\\!\\u012C\\u0271\\u0105\\u011F\\u0113]]]\r\n\r\n#XBUT, 20: Button to show the create actionsheet\r\nCREATE=[[[\\u0108\\u0157\\u0113\\u0105\\u0163\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\r\nDISCUSS_ENTRY=[[[\\u010E\\u012F\\u015F\\u010B\\u0171\\u015F\\u015F \\u012F\\u014B \\u015C\\u0100\\u01A4 \\u0134\\u0105\\u0271\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\r\nSHARE_ENTRY=[[[\\u015C\\u0125\\u0105\\u0157\\u0113 \\u014F\\u014B \\u015C\\u0100\\u01A4 \\u0134\\u0105\\u0271\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XBUT, 20: Button to share the note\r\nDETAIL_BUTTON_SHARE=[[[\\u015C\\u0125\\u0105\\u0157\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XBUT, 20: Button to cancel sharing\r\nDETAIL_BUTTON_CANCEL=[[[\\u0108\\u0105\\u014B\\u010B\\u0113\\u013A\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,20: All accounts for filter\r\nALL_ACCOUNTS=[[[\\u0100\\u013A\\u013A \\u0100\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,35: All individual accounts for filter\r\nALL_INDIVIDUAL_ACCOUNTS=[[[\\u0100\\u013A\\u013A \\u012C\\u014B\\u018C\\u012F\\u028B\\u012F\\u018C\\u0171\\u0105\\u013A \\u0100\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,35: All corporate accounts for filter\r\nALL_CORPORATE_ACCOUNTS=[[[\\u0100\\u013A\\u013A \\u0108\\u014F\\u0157\\u03C1\\u014F\\u0157\\u0105\\u0163\\u0113 \\u0100\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,35: All group accounts for filter\r\nALL_ACCOUNT_GROUPS=[[[\\u0100\\u013A\\u013A \\u0100\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163 \\u0122\\u0157\\u014F\\u0171\\u03C1\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,20: my account for filter\r\nMY_ACCOUNT=[[[\\u039C\\u0177 \\u0100\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,35: my individual accounts for filter\r\nMY_INDIVIDUAL_ACCOUNTS=[[[\\u039C\\u0177 \\u012C\\u014B\\u018C\\u012F\\u028B\\u012F\\u018C\\u0171\\u0105\\u013A \\u0100\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,35: my corporate accounts for filter\r\nMY_CORPORATE_ACCOUNTS=[[[\\u039C\\u0177 \\u0108\\u014F\\u0157\\u03C1\\u014F\\u0157\\u0105\\u0163\\u0113 \\u0100\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,35: my group accounts for filter\r\nMY_ACCOUNT_GROUPS=[[[\\u039C\\u0177 \\u0100\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163 \\u0122\\u0157\\u014F\\u0171\\u03C1\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nINDIVIDUAL_ACCOUNT=[[[\\u012C\\u014B\\u018C\\u012F\\u028B\\u012F\\u018C\\u0171\\u0105\\u013A \\u0100\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nCORPORATE_ACCOUNT=[[[\\u0108\\u014F\\u0157\\u03C1\\u014F\\u0157\\u0105\\u0163\\u0113 \\u0100\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nACCOUNT_GROUP=[[[\\u0100\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163 \\u0122\\u0157\\u014F\\u0171\\u03C1\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\r\nSTARTING=[[[\\u015C\\u0163\\u0105\\u0157\\u0163\\u012F\\u014B\\u011F {0}]]]\r\n\r\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\r\nCLOSING=[[[\\u0108\\u013A\\u014F\\u015F\\u012F\\u014B\\u011F {0}]]]\r\n\r\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\r\nDUE=[[[\\u010E\\u0171\\u0113 {0}]]]\r\n\r\n#XFLD,20: All accounts for title\r\nALL_ACCOUNTS_TITLE=[[[\\u0100\\u013A\\u013A \\u0100\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163\\u015F ({0})]]]\r\n\r\n#XFLD,35: All individual accounts for title\r\nALL_INDIVIDUAL_ACCOUNTS_TITLE=[[[\\u0100\\u013A\\u013A \\u012C\\u014B\\u018C\\u012F\\u028B\\u012F\\u018C\\u0171\\u0105\\u013A \\u0100\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163\\u015F ({0})]]]\r\n\r\n#XFLD,35: All corporate accounts for title\r\nALL_CORPORATE_ACCOUNTS_TITLE=[[[\\u0100\\u013A\\u013A \\u0108\\u014F\\u0157\\u03C1\\u014F\\u0157\\u0105\\u0163\\u0113 \\u0100\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163\\u015F ({0})]]]\r\n\r\n#XFLD,35: All group accounts for title\r\nALL_ACCOUNT_GROUPS_TITLE=[[[\\u0100\\u013A\\u013A \\u0100\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163 \\u0122\\u0157\\u014F\\u0171\\u03C1\\u015F ({0})]]]\r\n\r\n#XFLD,20: my account for title\r\nMY_ACCOUNT_TITLE=[[[\\u039C\\u0177 \\u0100\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163\\u015F ({0})]]]\r\n\r\n#XFLD,35: my individual account for title\r\nMY_INDIVIDUAL_ACCOUNT_TITLE=[[[\\u039C\\u0177 \\u012C\\u014B\\u018C\\u012F\\u028B\\u012F\\u018C\\u0171\\u0105\\u013A \\u0100\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163\\u015F ({0})]]]\r\n\r\n#XFLD,35: my corporate account for title.\r\nMY_CORPORATE_ACCOUNT_TITLE=[[[\\u039C\\u0177 \\u0108\\u014F\\u0157\\u03C1\\u014F\\u0157\\u0105\\u0163\\u0113 \\u0100\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163\\u015F ({0})]]]\r\n\r\n#XFLD,35: my group account for title\r\nMY_ACCOUNT_GROUP_TITLE=[[[\\u039C\\u0177 \\u0100\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163 \\u0122\\u0157\\u014F\\u0171\\u03C1\\u015F ({0})]]]\r\n\r\n#XFLD,30: filtered by info\r\nFILTERED_BY=[[[\\u0191\\u012F\\u013A\\u0163\\u0113\\u0157\\u0113\\u018C \\u0181\\u0177\\: {0}]]]\r\n\r\n#XFLD,30: label, search for accounts\r\nSEARCH_ACCOUNTS=[[[\\u015C\\u0113\\u0105\\u0157\\u010B\\u0125\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,30: comma separator for location\r\nLOCATION=[[[{0}, {1}]]]\r\n\r\n#XFLD: W4: Label for All day text in Appointments\r\nALL_DAY_EVENT=[[[\\u0100\\u013A\\u013A \\u010E\\u0105\\u0177\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\r\nDURATION_MINUTE=[[[{0} \\u0271\\u012F\\u014B]]]\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\r\nDURATION_HOUR=[[[{0} \\u0125]]]\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\r\nDURATION_DAY=[[[{0} \\u018C\\u0105\\u0177]]]\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\r\nDURATION_DAYS=[[[{0} \\u018C\\u0105\\u0177\\u015F]]]\r\n\r\n#XFLD: W4: Label for Private meeting\r\nPRIVATE=[[[\\u01A4\\u0157\\u012F\\u028B\\u0105\\u0163\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\r\nSELECT_TRANSACTION_TYPE=[[[\\u015C\\u0113\\u013A\\u0113\\u010B\\u0163 \\u0162\\u0157\\u0105\\u014B\\u015F\\u0105\\u010B\\u0163\\u012F\\u014F\\u014B \\u0162\\u0177\\u03C1\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\r\nNEW_TASK_INPUT_PLACEHOLDER=[[[\\u0143\\u0113\\u0175 \\u0162\\u0105\\u015F\\u0137\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nNO_DATA_TEXT=[[[\\u0143\\u014F \\u010E\\u0105\\u0163\\u0105\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nLOADING_TEXT=[[[\\u013B\\u014F\\u0105\\u018C\\u012F\\u014B\\u011F...\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,25: W4: Column label for name of contact person in contacts\r\nNAME=[[[\\u0143\\u0105\\u0271\\u0113]]]\r\n\r\n#XFLD,25: W5: Column label for department of contact person in contacts\r\nDEPARTMENT=[[[\\u010E\\u0113\\u03C1\\u0105\\u0157\\u0163\\u0271\\u0113\\u014B\\u0163\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,15: W6: Column label for actions of contact person in contacts\r\nACTIONS=[[[\\u0100\\u010B\\u0163\\u012F\\u014F\\u014B\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,25: W4: Column label for description of lead in Leads\r\nDESCRIPTION=[[[\\u010E\\u0113\\u015F\\u010B\\u0157\\u012F\\u03C1\\u0163\\u012F\\u014F\\u014B\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\r\nASSIGNED_TO=[[[\\u0100\\u015F\\u015F\\u012F\\u011F\\u014B\\u0113\\u018C \\u0162\\u014F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,15: W4: Column label for end date of lead in Leads\r\nEND_DATE=[[[\\u0114\\u014B\\u018C \\u010E\\u0105\\u0163\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,15: W4: Column label for qualification level of lead in Leads\r\nQUALIFICATION=[[[\\!\\!\\!\\u01EC\\u0171\\u0105\\u013A\\u012F\\u0192\\u012F\\u010B\\u0105\\u0163\\u012F\\u014F\\u014B]]]\r\n\r\n#XFLD,15: W4: Column label for status of lead in Leads\r\nSTATUS=[[[\\u015C\\u0163\\u0105\\u0163\\u0171\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\r\nMAIN_CONTACT=[[[\\u039C\\u0105\\u012F\\u014B \\u0108\\u014F\\u014B\\u0163\\u0105\\u010B\\u0163\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\r\nVOLUME=[[[\\u01B2\\u014F\\u013A\\u0171\\u0271\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\r\nPROBABILITY=[[[\\u01A4\\u0157\\u014F\\u0183\\u0105\\u0183\\u012F\\u013A\\u012F\\u0163\\u0177\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\r\nCLOSE_BY=[[[\\u0108\\u013A\\u014F\\u015F\\u0113 \\u0181\\u0177\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \r\nVIEWS=[[[\\u01B2\\u012F\\u0113\\u0175\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\r\nCONTACT_TITLE=[[[\\u0108\\u014F\\u014B\\u0163\\u0105\\u010B\\u0163\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\r\nEMPLOYEE_TITLE=[[[\\u0114\\u0271\\u03C1\\u013A\\u014F\\u0177\\u0113\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT,20: W7: Title of pop-up used in confirm popup\r\nCONFIRM_TITLE=[[[\\u0108\\u014F\\u014B\\u0192\\u012F\\u0157\\u0271\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\r\nCOMPANY_NAME=[[[\\u0143\\u0105\\u0271\\u0113]]]\r\n\r\n#XFLD,20: W4: Label for name 1 of a company used general data\r\nCOMPANY_NAME1=[[[\\u0143\\u0105\\u0271\\u0113 1\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,20: W4: Label for name 2 of a company used general data\r\nCOMPANY_NAME2=[[[\\u0143\\u0105\\u0271\\u0113 2\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,20: W4: Label for first name of a person used general data\r\nFIRST_NAME=[[[\\u0191\\u012F\\u0157\\u015F\\u0163 \\u0143\\u0105\\u0271\\u0113\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,20: W4: Label for last name of a person used general data\r\nLAST_NAME=[[[\\u013B\\u0105\\u015F\\u0163 \\u0143\\u0105\\u0271\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nBIRTHDAY=[[[\\u0181\\u012F\\u0157\\u0163\\u0125\\u018C\\u0105\\u0177\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nTITLE=[[[\\u0162\\u012F\\u0163\\u013A\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nACADEMIC_TITLE=[[[\\u0100\\u010B\\u0105\\u018C\\u0113\\u0271\\u012F\\u010B \\u0162\\u012F\\u0163\\u013A\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,20: W4: Label for mobile phone number used general data\r\nMOBILE=[[[\\u039C\\u014F\\u0183\\u012F\\u013A\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,20: W4: Label for phone number used general data\r\nPHONE=[[[\\u01A4\\u0125\\u014F\\u014B\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,20: W4: Label for e-mail used general data\r\nEMAIL=[[[\\u0114-\\u039C\\u0105\\u012F\\u013A\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,20: W4: Label for web site used general data\r\nWEBSITE=[[[\\u0174\\u0113\\u0183 \\u015C\\u012F\\u0163\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,20: W4: Label for country used general data\r\nCOUNTRY=[[[\\u0108\\u014F\\u0171\\u014B\\u0163\\u0157\\u0177\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,20: W4: Label for region used general data\r\nREGION=[[[\\u0158\\u0113\\u011F\\u012F\\u014F\\u014B\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,20: W4: Label for city used general data\r\nCITY=[[[\\u0108\\u012F\\u0163\\u0177]]]\r\n\r\n#XFLD,20: W4: Label for postal code used general data\r\nPOSTAL_CODE=[[[\\u01A4\\u014F\\u015F\\u0163\\u0105\\u013A \\u0108\\u014F\\u018C\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,20: W4: Label for street used general data\r\nSTREET=[[[\\u015C\\u0163\\u0157\\u0113\\u0113\\u0163\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,10: W4: Label for house number used general data\r\nHOUSE_NUMBER=[[[\\!\\!\\!\\u0124\\u014F\\u0171\\u015F\\u0113 \\u0143\\u014F.]]]\r\n\r\n#XFLD,15: W6: Label for ID used in Quotations\r\nID=[[[\\u012C\\u010E\\u2219\\u2219]]]\r\n\r\n#XFLD,15: W6: Label for Amount used in Quotations\r\nAMOUNT=[[[\\u0100\\u0271\\u014F\\u0171\\u014B\\u0163\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,20: W6: Label for Expiration Date used in Quotations\r\nEXPIRATION_DATE=[[[\\!\\!\\!\\u0114\\u03C7\\u03C1\\u012F\\u0157\\u0105\\u0163\\u012F\\u014F\\u014B \\u010E\\u0105\\u0163\\u0113]]]\r\n\r\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\r\nDELIVERY_DATE=[[[\\u010E\\u0113\\u013A\\u012F\\u028B\\u0113\\u0157\\u0177 \\u010E\\u0105\\u0163\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\r\nSALES_EMPLOYEE=[[[\\u015C\\u0105\\u013A\\u0113\\u015F \\u0114\\u0271\\u03C1\\u013A\\u014F\\u0177\\u0113\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\r\nATTRIBUTESET=[[[\\u0100\\u0163\\u0163\\u0157\\u012F\\u0183\\u0171\\u0163\\u0113 \\u015C\\u0113\\u0163\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\r\nATTRIBUTE=[[[\\u0100\\u0163\\u0163\\u0157\\u012F\\u0183\\u0171\\u0163\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\r\nVALUE=[[[\\u01B2\\u0105\\u013A\\u0171\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XBUT, 20: Button to create an Account\r\nBUTTON_ADD=[[[\\u0100\\u018C\\u018C\\u2219]]]\r\n\r\n#XBUT, 20: Button to edit an Account\r\nBUTTON_EDIT=[[[\\u0114\\u018C\\u012F\\u0163]]]\r\n\r\n#XBUT, 20: Button to save changes\r\nBUTTON_SAVE=[[[\\u015C\\u0105\\u028B\\u0113]]]\r\n\r\n#XBUT, 20: Button to cancel changes\r\nBUTTON_CANCEL=[[[\\u0108\\u0105\\u014B\\u010B\\u0113\\u013A\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XBUT, 30: Button which shows the personalization buttons\r\nBUTTON_SHOW_PERSONALIZATION=[[[\\u015C\\u0125\\u014F\\u0175 \\u01A4\\u0113\\u0157\\u015F\\u014F\\u014B\\u0105\\u013A\\u012F\\u017E\\u0105\\u0163\\u012F\\u014F\\u014B\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XBUT, 30: Button which hides the personalization buttons\r\nBUTTON_HIDE_PERSONALIZATION=[[[\\u0124\\u012F\\u018C\\u0113 \\u01A4\\u0113\\u0157\\u015F\\u014F\\u014B\\u0105\\u013A\\u012F\\u017E\\u0105\\u0163\\u012F\\u014F\\u014B\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_CONFIRM_CANCEL=[[[\\u013B\\u0113\\u0105\\u028B\\u0113 \\u0163\\u0125\\u012F\\u015F \\u03C1\\u0105\\u011F\\u0113 \\u0175\\u012F\\u0163\\u0125\\u014F\\u0171\\u0163 \\u015F\\u0105\\u028B\\u012F\\u014B\\u011F \\u0163\\u0125\\u0113 \\u010B\\u0125\\u0105\\u014B\\u011F\\u0113\\u015F \\u0177\\u014F\\u0171 \\u0271\\u0105\\u0177 \\u0125\\u0105\\u028B\\u0113 \\u0271\\u0105\\u018C\\u0113?\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\r\nMSG_CONFIRM_DELETE_CONTACT=[[[\\u0162\\u0125\\u0113 \\u010B\\u014F\\u014B\\u0163\\u0105\\u010B\\u0163 \\u0175\\u012F\\u013A\\u013A \\u0183\\u0113 \\u0171\\u014B\\u0105\\u015F\\u015F\\u012F\\u011F\\u014B\\u0113\\u018C \\u0192\\u0157\\u014F\\u0271 \\u0163\\u0125\\u0113 \\u0105\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163. \\u010E\\u014F \\u0177\\u014F\\u0171 \\u0175\\u0105\\u014B\\u0163 \\u0163\\u014F \\u010B\\u014F\\u014B\\u0163\\u012F\\u014B\\u0171\\u0113?\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_SUCCESS=[[[\\u0100\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163 \\u0171\\u03C1\\u018C\\u0105\\u0163\\u0113\\u018C.\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_ERROR=[[[\\u016E\\u03C1\\u018C\\u0105\\u0163\\u0113 \\u0192\\u0105\\u012F\\u013A\\u0113\\u018C\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XMSG : Account update succeeded\r\nMSG_CREATION_SUCCESS=[[[\\u0100\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163 \\u010B\\u0157\\u0113\\u0105\\u0163\\u0113\\u018C\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XMSG : Task creation succeeded\r\nMSG_TASK_CREATION_SUCCESS=[[[\\u0162\\u0105\\u015F\\u0137 \\u010B\\u0157\\u0113\\u0105\\u0163\\u0113\\u018C\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XMSG : Contact creation failed\r\nMSG_CREATION_ERROR=[[[\\u0108\\u0157\\u0113\\u0105\\u0163\\u012F\\u014F\\u014B \\u0192\\u0105\\u012F\\u013A\\u0113\\u018C\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong country\r\nMSG_WRONG_COUNTRY_ERROR=[[[\\u0108\\u014F\\u0171\\u014B\\u0163\\u0157\\u0177 "{0}" \\u018C\\u014F\\u0113\\u015F \\u014B\\u014F\\u0163 \\u0113\\u03C7\\u012F\\u015F\\u0163.]]]\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong region\r\nMSG_WRONG_REGION_ERROR=[[[\\u0158\\u0113\\u011F\\u012F\\u014F\\u014B "{0}" \\u018C\\u014F\\u0113\\u015F \\u014B\\u014F\\u0163 \\u0113\\u03C7\\u012F\\u015F\\u0163 \\u0192\\u014F\\u0157 \\u0163\\u0125\\u0113 \\u011F\\u012F\\u028B\\u0113\\u014B \\u010B\\u014F\\u0171\\u014B\\u0163\\u0157\\u0177.]]]\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong employee\r\nMSG_WRONG_EMPLOYEE_ERROR=[[[\\u0114\\u0271\\u03C1\\u013A\\u014F\\u0177\\u0113\\u0113 "{0}" \\u018C\\u014F\\u0113\\u015F \\u014B\\u014F\\u0163 \\u0113\\u03C7\\u012F\\u015F\\u0163.]]]\r\n\r\n# XMSG: message that will be displayed, if the user has entered invalid website url\r\nMSG_WRONG_URL_ERROR=[[[\\u0114\\u014B\\u0163\\u0113\\u0157\\u0113\\u018C \\u016E\\u0158\\u013B "{0}" \\u012F\\u015F \\u014B\\u014F\\u0163 \\u028B\\u0105\\u013A\\u012F\\u018C.]]]\r\n\r\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\r\nMSG_MANDATORY_FIELDS=[[[\\u0143\\u014F\\u0163 \\u0105\\u013A\\u013A \\u0271\\u0105\\u014B\\u018C\\u0105\\u0163\\u014F\\u0157\\u0177 \\u0192\\u012F\\u0113\\u013A\\u018C\\u015F \\u0105\\u0157\\u0113 \\u0192\\u012F\\u013A\\u013A\\u0113\\u018C.\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA=[[[\\u010E\\u0105\\u0163\\u0105 \\u0125\\u0105\\u015F \\u0183\\u0113\\u0113\\u014B \\u010B\\u0125\\u0105\\u014B\\u011F\\u0113\\u018C \\u0183\\u0177 \\u0105\\u014B\\u014F\\u0163\\u0125\\u0113\\u0157 \\u0171\\u015F\\u0113\\u0157. \\u010E\\u014F \\u0177\\u014F\\u0171 \\u0175\\u0105\\u014B\\u0163 \\u0163\\u014F \\u014F\\u028B\\u0113\\u0157\\u0175\\u0157\\u012F\\u0163\\u0113 \\u0163\\u0125\\u0113 \\u014F\\u0163\\u0125\\u0113\\u0157 \\u0171\\u015F\\u0113\\u0157\'\\u015F \\u010B\\u0125\\u0105\\u014B\\u011F\\u0113\\u015F \\u0175\\u012F\\u0163\\u0125 \\u0177\\u014F\\u0171\\u0157 \\u014F\\u0175\\u014B?\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XMSG: message that will be displayed in case of conflicts during file renaming\r\nMSG_CONFLICTING_FILE_NAME=[[[\\u0162\\u0125\\u0113 \\u0192\\u012F\\u013A\\u0113 \\u014B\\u0105\\u0271\\u0113 \\u0125\\u0105\\u015F \\u0183\\u0113\\u0113\\u014B \\u010B\\u0125\\u0105\\u014B\\u011F\\u0113\\u018C \\u0183\\u0177 \\u0105\\u014B\\u014F\\u0163\\u0125\\u0113\\u0157 \\u0171\\u015F\\u0113\\u0157. \\u010E\\u014F \\u0177\\u014F\\u0171 \\u0175\\u0105\\u014B\\u0163 \\u0163\\u014F \\u014F\\u028B\\u0113\\u0157\\u0175\\u0157\\u012F\\u0163\\u0113 \\u0163\\u0125\\u0113 \\u014F\\u0163\\u0125\\u0113\\u0157 \\u0171\\u015F\\u0113\\u0157\'\\u015F \\u010B\\u0125\\u0105\\u014B\\u011F\\u0113\\u015F \\u0175\\u012F\\u0163\\u0125 \\u0177\\u014F\\u0171\\u0157 \\u014F\\u0175\\u014B?\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA_WITH_REFRESH=[[[\\u010E\\u0105\\u0163\\u0105 \\u0125\\u0105\\u015F \\u0183\\u0113\\u0113\\u014B \\u010B\\u0125\\u0105\\u014B\\u011F\\u0113\\u018C \\u0183\\u0177 \\u0105\\u014B\\u014F\\u0163\\u0125\\u0113\\u0157 \\u0171\\u015F\\u0113\\u0157. \\u010E\\u0105\\u0163\\u0105 \\u0175\\u012F\\u013A\\u013A \\u0183\\u0113 \\u0157\\u0113\\u0192\\u0157\\u0113\\u015F\\u0125\\u0113\\u018C.\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\r\nMSG_NOT_IN_MAIN_CONTACT=[[[\\u0176\\u014F\\u0171 \\u010B\\u0105\\u014B \\u014F\\u014B\\u013A\\u0177 \\u028B\\u012F\\u0113\\u0175 \\u0183\\u0171\\u015F\\u012F\\u014B\\u0113\\u015F\\u015F \\u010B\\u0105\\u0157\\u018C\\u015F \\u014F\\u0192 \\u010B\\u014F\\u014B\\u0163\\u0105\\u010B\\u0163\\u015F \\u0163\\u0125\\u0105\\u0163 \\u0125\\u0105\\u028B\\u0113 \\u0183\\u0113\\u0113\\u014B \\u0105\\u015F\\u015F\\u012F\\u011F\\u014B\\u0113\\u018C \\u0163\\u014F \\u0163\\u0125\\u012F\\u015F \\u0105\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\r\nMSG_EXCEEDING_FILE_NAME_LENGTH=[[[\\u0176\\u014F\\u0171\\u0157 \\u0192\\u012F\\u013A\\u0113 \\u014B\\u0105\\u0271\\u0113 \\u010B\\u0105\\u014B \\u0125\\u0105\\u028B\\u0113 \\u0105 \\u0271\\u0105\\u03C7\\u012F\\u0271\\u0171\\u0271 \\u014F\\u0192 40 \\u010B\\u0125\\u0105\\u0157\\u0105\\u010B\\u0163\\u0113\\u0157\\u015F.\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XTOL, 20: tooltip shown on search result list for button to add an account"\r\nADD_ACCOUNT_TOOLTIP=[[[\\u0100\\u018C\\u018C \\u0100\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\r\nADD_MARKETING_ATTRIBUTE_TOOLTIP=[[[\\u0100\\u018C\\u018C \\u039C\\u0105\\u0157\\u0137\\u0113\\u0163\\u012F\\u014B\\u011F \\u0100\\u0163\\u0163\\u0157\\u012F\\u0183\\u0171\\u0163\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\r\nADD_CONTACT_TOOLTIP=[[[\\u0100\\u018C\\u018C \\u0108\\u014F\\u014B\\u0163\\u0105\\u010B\\u0163\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\r\nADD_APPOINTMENT_TOOLTIP=[[[\\u0100\\u018C\\u018C \\u0100\\u03C1\\u03C1\\u014F\\u012F\\u014B\\u0163\\u0271\\u0113\\u014B\\u0163\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\r\nADD_TASK_TOOLTIP=[[[\\u0100\\u018C\\u018C \\u0162\\u0105\\u015F\\u0137\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\r\nADD_OPPORTUNITY_TOOLTIP=[[[\\u0100\\u018C\\u018C \\u014E\\u03C1\\u03C1\\u014F\\u0157\\u0163\\u0171\\u014B\\u012F\\u0163\\u0177\\u2219\\u2219\\u2219\\u2219]]]\r\n',
	"cus/crm/myaccounts/i18n/i18n_en_US_saptrc.properties":'# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XFLD, 30: Facet title for general Data\r\nGENERAL_DATA=o1s2JNJQ54SwTJw8VYktOg_General Information\r\n\r\n#XTIT, 40: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=raMMwoe0U05Gax5C4S4KRA_My Accounts\r\n\r\n#XTIT, 40: this is the title for the detail screen\r\nDETAIL_TITLE=geCCXv1WyUERK7c5K7qArQ_Account\r\n\r\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\r\nREVENUE_CURRENT=k2YyuJfz/MbYnunZ/ie/CA_Revenue YTD\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\r\nREVENUE_CURRENT_TOOLTIP=iGse+H+EAxCZXm9Tz8krEA_Revenue to date current year\r\n\r\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\r\nREVENUE_LAST=1eRAMcXp9keY4ncvrmTfIg_Revenue Last Year\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\r\nREVENUE_LAST_TOOLTIP=NSOBnaduOcNpkvpB5tZwoA_Revenue to last year\r\n\r\n# XFLD, 30: Facet title for opportunities and label in facet general data\r\nOPPORTUNITIES=GXbNjB/zkYf3aRxRooxW1w_Opportunities\r\n\r\n#XFLD, 30: Facet title for leads\r\nLEADS=OTH7Hfvp2gRBXtuOQCrzOQ_Leads\r\n\r\n#XFLD, 30: Facet title for tasks\r\nTASKS=CYViBnlQf+NlOgUSkdxNPQ_Tasks\r\n\r\n#XFLD, 30: Facet title for appointments\r\nAPPOINTMENTS=Hhy0HkYB2JAXn9t20hlgMQ_Appointments\r\n\r\n#XFLD, 30: Facet title for quotations\r\nQUOTATIONS=cqqs8R+OOVzpzq3QWmu6Bg_Quotations\r\n\r\n#XFLD, 30: Facet title for sales orders\r\nSALES_ORDERS=eFVZK1kbHtW5jRXvVlp4Dg_Sales Orders\r\n\r\n#XFLD, 30: W7: Facet title for marketing attributes\r\nMARKETINGATTRIBUTES=wQ2JhtMbMJb4Qtv8HS+2wQ_Marketing Attributes\r\n\r\n#XFLD, 30: W6: Title for popup with products\r\nPRODUCTS=Ac1SclUr5vE38GJsGrpp7A_Products\r\n\r\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\r\nEMPLOYEE_RESPONSIBLE=R6LrlS5vLdm5TOCuaTZI/w_Employee Responsible\r\n\r\n#XFLD, 30: Facet title for Attachments\r\nATTACHMENTS=h3Kq6fq2wl0r4xwSpQ9s9g_Attachments\r\n\r\n#XFLD, 30: Facet title for Notes\r\nNOTES=YJEpjbfi1itt123DurKapA_Notes\r\n\r\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\r\nNEW_NOTE=sLXLZnHcx+3f2LCWTDW8uA_New Note\r\n\r\n#XFLD, 30: Facet title for Contacts\r\nCONTACTS=/3FpLsjR7pomnRbQldWyXg_Contacts\r\n\r\n#XFLD, 30: Label for Address in facet general data\r\nADDRESS=iMgg8PDXsKV7e6jPSPRn6Q_Address\r\n\r\n#XFLD, 30: Label for Opportunities in facet general data\r\nUNWEIGHTED_OPPORTUNITIES=uhvHQ/ITcU1XCXAZVHLdpA_Opportunities\r\n\r\n#XFLD, 30: Label for Rating in facet general data\r\nRATING=DRFdOpqCpbMAmIp16zKmUg_Rating\r\n\r\n# XFLD, 30: Label for Next contact in facet Appointments\r\nNEXT_APPOINTMENT=NfblvLBNTWkwK0WknwkUOg_Next Appointment\r\n\r\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\r\nLAST_APPOINTMENT=Px9RYx2HM1GutoNCR/UZvg_Last Appointment\r\n\r\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\r\nIMAGE=gAL4gzaWr5W6bPZ0FJwXsA_Image\r\n\r\n#XBUT, 20: Button to show the create actionsheet\r\nCREATE=jTXR83bEP3NYOT7EbUlGdQ_Create\r\n\r\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\r\nDISCUSS_ENTRY=Z1ILu3wctalBOpIm/B3o/A_Discuss in SAP Jam\r\n\r\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\r\nSHARE_ENTRY=iZyX6TxzLxlGmTHW74VNBA_Share on SAP Jam\r\n\r\n#XBUT, 20: Button to share the note\r\nDETAIL_BUTTON_SHARE=apJfOLVAMwjICUeSWLrcAw_Share\r\n\r\n#XBUT, 20: Button to cancel sharing\r\nDETAIL_BUTTON_CANCEL=X6T5myzA/mz2In6OrttQpQ_Cancel\r\n\r\n#XFLD,20: All accounts for filter\r\nALL_ACCOUNTS=XLtt9JR+S7RDD3/4NuWtjw_All Accounts\r\n\r\n#XFLD,35: All individual accounts for filter\r\nALL_INDIVIDUAL_ACCOUNTS=VUL6yO3BTzy9SF+xOydUkg_All Individual Accounts\r\n\r\n#XFLD,35: All corporate accounts for filter\r\nALL_CORPORATE_ACCOUNTS=Hume8s/Y4c44+7fpYozEaQ_All Corporate Accounts\r\n\r\n#XFLD,35: All group accounts for filter\r\nALL_ACCOUNT_GROUPS=RGiNFqm6HGHx1hU5uVlhwQ_All Account Groups\r\n\r\n#XFLD,20: my account for filter\r\nMY_ACCOUNT=YSPKDUFoKsyg3oYeL3rE/Q_My Accounts\r\n\r\n#XFLD,35: my individual accounts for filter\r\nMY_INDIVIDUAL_ACCOUNTS=P5GB7p7jN1SFfbJ9vkewuw_My Individual Accounts\r\n\r\n#XFLD,35: my corporate accounts for filter\r\nMY_CORPORATE_ACCOUNTS=3qOES1xpvc2qUUNp6oUwAA_My Corporate Accounts\r\n\r\n#XFLD,35: my group accounts for filter\r\nMY_ACCOUNT_GROUPS=+/9sLOpndKVAjQNjWOfIww_My Account Groups\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nINDIVIDUAL_ACCOUNT=ziuxDS0gQeHqZEpO6R6jow_Individual Account\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nCORPORATE_ACCOUNT=OLulWtRBsXuW2PuFVWn61g_Corporate Account\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nACCOUNT_GROUP=t+CG7y6axeXa1d5rglHafw_Account Group\r\n\r\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\r\nSTARTING=6Twrva4eeB9IfZSa+FWLwA_Starting {0}\r\n\r\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\r\nCLOSING=a4n7uEcIhfWZJhTobniDig_Closing {0}\r\n\r\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\r\nDUE=oAypZo8ctJPZ0dD5UM7iSA_Due {0}\r\n\r\n#XFLD,20: All accounts for title\r\nALL_ACCOUNTS_TITLE=njLJBWBQHtT+LS6Lqp+kUg_All Accounts ({0})\r\n\r\n#XFLD,35: All individual accounts for title\r\nALL_INDIVIDUAL_ACCOUNTS_TITLE=3pMQLffZcHUgFrAbidY4sg_All Individual Accounts ({0})\r\n\r\n#XFLD,35: All corporate accounts for title\r\nALL_CORPORATE_ACCOUNTS_TITLE=U6nksoKWhbmeFnAEdufOtw_All Corporate Accounts ({0})\r\n\r\n#XFLD,35: All group accounts for title\r\nALL_ACCOUNT_GROUPS_TITLE=njXWaoDXnuSpRfM/NTJJqw_All Account Groups ({0})\r\n\r\n#XFLD,20: my account for title\r\nMY_ACCOUNT_TITLE=54Wlleq3eZf2kWprDEZtYA_My Accounts ({0})\r\n\r\n#XFLD,35: my individual account for title\r\nMY_INDIVIDUAL_ACCOUNT_TITLE=igXFwcHXA+rnCnS3qSo+7g_My Individual Accounts ({0})\r\n\r\n#XFLD,35: my corporate account for title.\r\nMY_CORPORATE_ACCOUNT_TITLE=WM5doSsrr1jWVtTOq+x4wg_My Corporate Accounts ({0})\r\n\r\n#XFLD,35: my group account for title\r\nMY_ACCOUNT_GROUP_TITLE=8+3hvFTOqm1FwBW4FV88qA_My Account Groups ({0})\r\n\r\n#XFLD,30: filtered by info\r\nFILTERED_BY=LB+A/+NxyYNMtwBK4EXakw_Filtered By\\: {0}\r\n\r\n#XFLD,30: label, search for accounts\r\nSEARCH_ACCOUNTS=wTaPxEpjR2UWuKHIit41EA_Search\r\n\r\n#XFLD,30: comma separator for location\r\nLOCATION=QYO/nFxc996k5MzaJ9/u1A_{0}, {1}\r\n\r\n#XFLD: W4: Label for All day text in Appointments\r\nALL_DAY_EVENT=eAJ9VqtNsRHLSFnadY+HBw_All Day\r\n\r\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\r\nDURATION_MINUTE=lmnCpHP4ZFp9SikUix6yHQ_{0} min\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\r\nDURATION_HOUR=ANzEWHv3gw6GKP5xsh287A_{0} h\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\r\nDURATION_DAY=rCYXExQ10FxGyrf0mixWtg_{0} day\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\r\nDURATION_DAYS=Wu+9Q3ZOWBQLUoY6VysFNg_{0} days\r\n\r\n#XFLD: W4: Label for Private meeting\r\nPRIVATE=GhhGGdy829mJjmMov45YWg_Private\r\n\r\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\r\nSELECT_TRANSACTION_TYPE=y+pJCKFAXarFKFUbUWHWKQ_Select Transaction Type\r\n\r\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\r\nNEW_TASK_INPUT_PLACEHOLDER=FsrnNXcjtqpcdK4qyrpWGQ_New Task\r\n\r\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nNO_DATA_TEXT=QexTuVUNRhZ7U1XUHz1ELw_No Data\r\n\r\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nLOADING_TEXT=ZjZCQYk/lSw93k8gPot01A_Loading...\r\n\r\n#XFLD,25: W4: Column label for name of contact person in contacts\r\nNAME=ihjkI6IHm2dKp03SI+vvsQ_Name\r\n\r\n#XFLD,25: W5: Column label for department of contact person in contacts\r\nDEPARTMENT=olRuUPCymMvf4Fa/gfps2Q_Department\r\n\r\n#XFLD,15: W6: Column label for actions of contact person in contacts\r\nACTIONS=bL1P259Xy9GchsJnaDQm3g_Actions\r\n\r\n#XFLD,25: W4: Column label for description of lead in Leads\r\nDESCRIPTION=GVKTiLQSMkNvDN301AhyuQ_Description\r\n\r\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\r\nASSIGNED_TO=MSqO1ZZrRRiN7WkjTd5JHA_Assigned To\r\n\r\n#XFLD,15: W4: Column label for end date of lead in Leads\r\nEND_DATE=NoajQE1vm93KsqekrtpB8Q_End Date\r\n\r\n#XFLD,15: W4: Column label for qualification level of lead in Leads\r\nQUALIFICATION=CgMf989g8KKOeNCSRpqK5Q_Qualification\r\n\r\n#XFLD,15: W4: Column label for status of lead in Leads\r\nSTATUS=xhw2L1u3pnvqTDCkJrQ8/w_Status\r\n\r\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\r\nMAIN_CONTACT=Br0GXpnFkouA3o8EcYpgqw_Main Contact\r\n\r\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\r\nVOLUME=D/Os+vtxEyu8wl+anA4L1g_Volume\r\n\r\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\r\nPROBABILITY=oM8eb0MmRqJoJteVN/WkSA_Probability\r\n\r\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\r\nCLOSE_BY=X7GcDowdhOc/5t/JPPlpLQ_Close By\r\n\r\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \r\nVIEWS=LeeIYDnkmVM6F37bWrkt5g_Views\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\r\nCONTACT_TITLE=/2aZzT9FQW2ht8bKHT18QQ_Contact\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\r\nEMPLOYEE_TITLE=YXUMksaB88dvR3DuR+8jUA_Employee\r\n\r\n#XTIT,20: W7: Title of pop-up used in confirm popup\r\nCONFIRM_TITLE=U8gL20FO8qfpdUsAz1kdhA_Confirm\r\n\r\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\r\nCOMPANY_NAME=Gf+KwvsORENcSvuhT/EEUg_Name\r\n\r\n#XFLD,20: W4: Label for name 1 of a company used general data\r\nCOMPANY_NAME1=329N5O7mp/m8Fdnw2w0gVA_Name 1\r\n\r\n#XFLD,20: W4: Label for name 2 of a company used general data\r\nCOMPANY_NAME2=of6GApvM4xLfboq1UNrXIQ_Name 2\r\n\r\n#XFLD,20: W4: Label for first name of a person used general data\r\nFIRST_NAME=5PhFX5URLQFK4Huh0U3pfw_First Name\r\n\r\n#XFLD,20: W4: Label for last name of a person used general data\r\nLAST_NAME=rbX4rpME/kheMJdoMPJLQA_Last Name\r\n\r\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nBIRTHDAY=XGOTv1kOM7GgJVacDDpe6A_Birthday\r\n\r\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nTITLE=jdUydkdnfGFwn3/D1XaEpA_Title\r\n\r\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nACADEMIC_TITLE=3gxglfZVa/91cIqsAZGn5A_Academic Title\r\n\r\n#XFLD,20: W4: Label for mobile phone number used general data\r\nMOBILE=xAkt8SDQPeFLZ57DRopu/Q_Mobile\r\n\r\n#XFLD,20: W4: Label for phone number used general data\r\nPHONE=Zw9jAj9ZnAgZu9/HtCcsCg_Phone\r\n\r\n#XFLD,20: W4: Label for e-mail used general data\r\nEMAIL=YSWTIP6ZU/w2KG1RClQyiw_E-Mail\r\n\r\n#XFLD,20: W4: Label for web site used general data\r\nWEBSITE=UGszmm5+2iBSBRh8KYRyow_Web Site\r\n\r\n#XFLD,20: W4: Label for country used general data\r\nCOUNTRY=nZ5Qj9f9h141wPwcFRBlUg_Country\r\n\r\n#XFLD,20: W4: Label for region used general data\r\nREGION=hOMnYynO5XvjCY19p6OfNw_Region\r\n\r\n#XFLD,20: W4: Label for city used general data\r\nCITY=uzf1uNb8wSqbjOaAQme9Zw_City\r\n\r\n#XFLD,20: W4: Label for postal code used general data\r\nPOSTAL_CODE=h+3UwSihB9Sceuk/u/cFkA_Postal Code\r\n\r\n#XFLD,20: W4: Label for street used general data\r\nSTREET=xcY181ccXGL7cmkfv9WFuA_Street\r\n\r\n#XFLD,10: W4: Label for house number used general data\r\nHOUSE_NUMBER=Whej81WQLfdGhFsqUaAFmw_House No.\r\n\r\n#XFLD,15: W6: Label for ID used in Quotations\r\nID=QeH6yc1PXIPT5K0Ui2yhbg_ID\r\n\r\n#XFLD,15: W6: Label for Amount used in Quotations\r\nAMOUNT=NSg6gpahSW2Txrq3j+Qx9w_Amount\r\n\r\n#XFLD,20: W6: Label for Expiration Date used in Quotations\r\nEXPIRATION_DATE=2hKMvM5DYmecfzQsOs/EYA_Expiration Date\r\n\r\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\r\nDELIVERY_DATE=/g8NPv4Bmp/2XtwhMd0EAg_Delivery Date\r\n\r\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\r\nSALES_EMPLOYEE=LXoZdhiKLhYLr1LdQunNxA_Sales Employee\r\n\r\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\r\nATTRIBUTESET=QeYp2egsEO4NDCwIfeXLNQ_Attribute Set\r\n\r\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\r\nATTRIBUTE=DVIXXlmhfTRvcmPZsenDtw_Attribute\r\n\r\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\r\nVALUE=5YqZpPmW69NpwMxzpzGl4w_Value\r\n\r\n#XBUT, 20: Button to create an Account\r\nBUTTON_ADD=qT53Ygsk4lHX0y3Ctorj3g_Add\r\n\r\n#XBUT, 20: Button to edit an Account\r\nBUTTON_EDIT=vjynZ+mnCi+bvB7NUE2b7g_Edit\r\n\r\n#XBUT, 20: Button to save changes\r\nBUTTON_SAVE=Ewc6ltjmddK16kLuE50Ixw_Save\r\n\r\n#XBUT, 20: Button to cancel changes\r\nBUTTON_CANCEL=GtNfSPCsTTq0Y5DJQ1Et1w_Cancel\r\n\r\n#XBUT, 30: Button which shows the personalization buttons\r\nBUTTON_SHOW_PERSONALIZATION=Y6L+eeb+tvYx0SWXuwiqPg_Show Personalization\r\n\r\n#XBUT, 30: Button which hides the personalization buttons\r\nBUTTON_HIDE_PERSONALIZATION=3okcO0N/76yFVSqaAzcmtA_Hide Personalization\r\n\r\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_CONFIRM_CANCEL=TTj5LoLF6F3aYhWa13bcQw_Leave this page without saving the changes you may have made?\r\n\r\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\r\nMSG_CONFIRM_DELETE_CONTACT=KRu6jRkJHRBWNVbxGE0Vqg_The contact will be unassigned from the account. Do you want to continue?\r\n\r\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_SUCCESS=l9vc4ZNSi0q9WjigwDfmZA_Account updated.\r\n\r\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_ERROR=lGDGdq3P9Hguh72RVSCyPQ_Update failed\r\n\r\n# XMSG : Account update succeeded\r\nMSG_CREATION_SUCCESS=Uah80HnDooT1/lVrBDry4A_Account created\r\n\r\n# XMSG : Task creation succeeded\r\nMSG_TASK_CREATION_SUCCESS=q+L9UzmFfLdpTbxBz2mDoA_Task created\r\n\r\n# XMSG : Contact creation failed\r\nMSG_CREATION_ERROR=Owo/W8ORoW9vI+oMY/kc5g_Creation failed\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong country\r\nMSG_WRONG_COUNTRY_ERROR=K3vsu9GEAxYl4vkrGSIB5g_Country "{0}" does not exist.\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong region\r\nMSG_WRONG_REGION_ERROR=6OJRowX6ztunSVVb1ZQPlQ_Region "{0}" does not exist for the given country.\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong employee\r\nMSG_WRONG_EMPLOYEE_ERROR=wQCefhzXwRzijQKp6T+FqA_Employee "{0}" does not exist.\r\n\r\n# XMSG: message that will be displayed, if the user has entered invalid website url\r\nMSG_WRONG_URL_ERROR=ruBZPafqRHiuVMiblJwuKg_Entered URL "{0}" is not valid.\r\n\r\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\r\nMSG_MANDATORY_FIELDS=dyh1WLFrxqUSNtzrlRvXnw_Not all mandatory fields are filled.\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA=iwePxnrzRthfEfLZ0SI3ZQ_Data has been changed by another user. Do you want to overwrite the other user\'s changes with your own?\r\n\r\n# XMSG: message that will be displayed in case of conflicts during file renaming\r\nMSG_CONFLICTING_FILE_NAME=5XMCfnSB/I3Nv2k/xzNqgQ_The file name has been changed by another user. Do you want to overwrite the other user\'s changes with your own?\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA_WITH_REFRESH=3uSZPtoK49mTjd33XERZZQ_Data has been changed by another user. Data will be refreshed.\r\n\r\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\r\nMSG_NOT_IN_MAIN_CONTACT=Wj09DwcBUtdFN/SDZmxCew_You can only view business cards of contacts that have been assigned to this account\r\n\r\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\r\nMSG_EXCEEDING_FILE_NAME_LENGTH=fmgBqjQvaVFWXiEbAcq81g_Your file name can have a maximum of 40 characters.\r\n\r\n# XTOL, 20: tooltip shown on search result list for button to add an account"\r\nADD_ACCOUNT_TOOLTIP=Noc4L2mPCcjs2msz1KeBKw_Add Account\r\n\r\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\r\nADD_MARKETING_ATTRIBUTE_TOOLTIP=g8zK3sGkfUQyVkbVtKVIHQ_Add Marketing Attribute\r\n\r\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\r\nADD_CONTACT_TOOLTIP=yw+o/Jgrm7toxI3ZmNg3GA_Add Contact\r\n\r\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\r\nADD_APPOINTMENT_TOOLTIP=gZOOTQtQH4PyrKtvuh2Thg_Add Appointment\r\n\r\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\r\nADD_TASK_TOOLTIP=Mt3tzeDm+JWynXmqMOBTag_Add Task\r\n\r\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\r\nADD_OPPORTUNITY_TOOLTIP=Qh7vX6WixnGkiqvY6TuThw_Add Opportunity\r\n',
	"cus/crm/myaccounts/i18n/i18n_es.properties":'# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XFLD, 30: Facet title for general Data\r\nGENERAL_DATA=Datos generales\r\n\r\n#XTIT, 40: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=Mis clientes\r\n\r\n#XTIT, 40: this is the title for the detail screen\r\nDETAIL_TITLE=Cliente\r\n\r\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\r\nREVENUE_CURRENT=Ingresos an.acum.\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\r\nREVENUE_CURRENT_TOOLTIP=Ingresos hasta el a\\u00F1o actual\r\n\r\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\r\nREVENUE_LAST=Ingresos a\\u00F1o pas.\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\r\nREVENUE_LAST_TOOLTIP=Ingresos hasta el a\\u00F1o pasado\r\n\r\n# XFLD, 30: Facet title for opportunities and label in facet general data\r\nOPPORTUNITIES=Oportunidades\r\n\r\n#XFLD, 30: Facet title for leads\r\nLEADS=Leads\r\n\r\n#XFLD, 30: Facet title for tasks\r\nTASKS=Tareas\r\n\r\n#XFLD, 30: Facet title for appointments\r\nAPPOINTMENTS=Citas\r\n\r\n#XFLD, 30: Facet title for quotations\r\nQUOTATIONS=Ofertas\r\n\r\n#XFLD, 30: Facet title for sales orders\r\nSALES_ORDERS=Pedidos de cliente\r\n\r\n#XFLD, 30: W7: Facet title for marketing attributes\r\nMARKETINGATTRIBUTES=Atributos de marketing\r\n\r\n#XFLD, 30: W6: Title for popup with products\r\nPRODUCTS=Productos\r\n\r\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\r\nEMPLOYEE_RESPONSIBLE=Empleado responsable\r\n\r\n#XFLD, 30: Facet title for Attachments\r\nATTACHMENTS=Anexos\r\n\r\n#XFLD, 30: Facet title for Notes\r\nNOTES=Notas\r\n\r\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\r\nNEW_NOTE=Nota nueva\r\n\r\n#XFLD, 30: Facet title for Contacts\r\nCONTACTS=Contactos\r\n\r\n#XFLD, 30: Label for Address in facet general data\r\nADDRESS=Direcci\\u00F3n\r\n\r\n#XFLD, 30: Label for Opportunities in facet general data\r\nUNWEIGHTED_OPPORTUNITIES=Oportunidades\r\n\r\n#XFLD, 30: Label for Rating in facet general data\r\nRATING=Clasificaci\\u00F3n\r\n\r\n# XFLD, 30: Label for Next contact in facet Appointments\r\nNEXT_APPOINTMENT=Siguiente cita\r\n\r\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\r\nLAST_APPOINTMENT=\\u00DAltima cita\r\n\r\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\r\nIMAGE=Imagen\r\n\r\n#XBUT, 20: Button to show the create actionsheet\r\nCREATE=Crear\r\n\r\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\r\nDISCUSS_ENTRY=Debatir SAP Jam\r\n\r\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\r\nSHARE_ENTRY=Compartir en SAP Jam\r\n\r\n#XBUT, 20: Button to share the note\r\nDETAIL_BUTTON_SHARE=Compartir\r\n\r\n#XBUT, 20: Button to cancel sharing\r\nDETAIL_BUTTON_CANCEL=Cancelar\r\n\r\n#XFLD,20: All accounts for filter\r\nALL_ACCOUNTS=Todos los clientes\r\n\r\n#XFLD,35: All individual accounts for filter\r\nALL_INDIVIDUAL_ACCOUNTS=Todos los clientes individuales\r\n\r\n#XFLD,35: All corporate accounts for filter\r\nALL_CORPORATE_ACCOUNTS=Todos los clientes empresariales\r\n\r\n#XFLD,35: All group accounts for filter\r\nALL_ACCOUNT_GROUPS=Todos los grupos de clientes\r\n\r\n#XFLD,20: my account for filter\r\nMY_ACCOUNT=Mis clientes\r\n\r\n#XFLD,35: my individual accounts for filter\r\nMY_INDIVIDUAL_ACCOUNTS=Mis clientes individuales\r\n\r\n#XFLD,35: my corporate accounts for filter\r\nMY_CORPORATE_ACCOUNTS=Mis clientes empresariales\r\n\r\n#XFLD,35: my group accounts for filter\r\nMY_ACCOUNT_GROUPS=Mis grupos de clientes\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nINDIVIDUAL_ACCOUNT=Cliente individual\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nCORPORATE_ACCOUNT=Ciente corporativo\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nACCOUNT_GROUP=Grupo de clientes\r\n\r\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\r\nSTARTING=Fecha de inicio\\: {0}\r\n\r\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\r\nCLOSING=Fecha de cierre\\: {0}\r\n\r\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\r\nDUE=Fecha de vencimiento\\: {0}\r\n\r\n#XFLD,20: All accounts for title\r\nALL_ACCOUNTS_TITLE=Todos los clientes ({0})\r\n\r\n#XFLD,35: All individual accounts for title\r\nALL_INDIVIDUAL_ACCOUNTS_TITLE=Todos los clientes individuales ({0})\r\n\r\n#XFLD,35: All corporate accounts for title\r\nALL_CORPORATE_ACCOUNTS_TITLE=Todos los clientes empresariales ({0})\r\n\r\n#XFLD,35: All group accounts for title\r\nALL_ACCOUNT_GROUPS_TITLE=Todos los grupos de clientes ({0})\r\n\r\n#XFLD,20: my account for title\r\nMY_ACCOUNT_TITLE=Mis clientes ({0})\r\n\r\n#XFLD,35: my individual account for title\r\nMY_INDIVIDUAL_ACCOUNT_TITLE=Mis clientes individuales ({0})\r\n\r\n#XFLD,35: my corporate account for title.\r\nMY_CORPORATE_ACCOUNT_TITLE=Mis clientes empresariales ({0})\r\n\r\n#XFLD,35: my group account for title\r\nMY_ACCOUNT_GROUP_TITLE=Todos mis grupos de clientes ({0})\r\n\r\n#XFLD,30: filtered by info\r\nFILTERED_BY=Filtrado por\\: {0}\r\n\r\n#XFLD,30: label, search for accounts\r\nSEARCH_ACCOUNTS=Buscar\r\n\r\n#XFLD,30: comma separator for location\r\nLOCATION={0}, {1}\r\n\r\n#XFLD: W4: Label for All day text in Appointments\r\nALL_DAY_EVENT=Todo el d\\u00EDa\r\n\r\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\r\nDURATION_MINUTE={0} min\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\r\nDURATION_HOUR={0} h\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\r\nDURATION_DAY={0} d\\u00EDa\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\r\nDURATION_DAYS={0} d\\u00EDas\r\n\r\n#XFLD: W4: Label for Private meeting\r\nPRIVATE=Privado\r\n\r\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\r\nSELECT_TRANSACTION_TYPE=Seleccionar tipo de transacci\\u00F3n\r\n\r\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\r\nNEW_TASK_INPUT_PLACEHOLDER=Nueva tarea\r\n\r\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nNO_DATA_TEXT=No hay datos\r\n\r\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nLOADING_TEXT=Cargando...\r\n\r\n#XFLD,25: W4: Column label for name of contact person in contacts\r\nNAME=Nombre\r\n\r\n#XFLD,25: W5: Column label for department of contact person in contacts\r\nDEPARTMENT=Departamento\r\n\r\n#XFLD,15: W6: Column label for actions of contact person in contacts\r\nACTIONS=Acciones\r\n\r\n#XFLD,25: W4: Column label for description of lead in Leads\r\nDESCRIPTION=Descripci\\u00F3n\r\n\r\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\r\nASSIGNED_TO=Asignado a\r\n\r\n#XFLD,15: W4: Column label for end date of lead in Leads\r\nEND_DATE=Fecha de fin\r\n\r\n#XFLD,15: W4: Column label for qualification level of lead in Leads\r\nQUALIFICATION=Calificaci\\u00F3n\r\n\r\n#XFLD,15: W4: Column label for status of lead in Leads\r\nSTATUS=Estado\r\n\r\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\r\nMAIN_CONTACT=Contacto principal\r\n\r\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\r\nVOLUME=Volumen\r\n\r\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\r\nPROBABILITY=Probabilidad\r\n\r\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\r\nCLOSE_BY=Cerrar el\r\n\r\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \r\nVIEWS=Vistas\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\r\nCONTACT_TITLE=Contacto\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\r\nEMPLOYEE_TITLE=Empleado\r\n\r\n#XTIT,20: W7: Title of pop-up used in confirm popup\r\nCONFIRM_TITLE=Confirmar\r\n\r\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\r\nCOMPANY_NAME=Nombre\r\n\r\n#XFLD,20: W4: Label for name 1 of a company used general data\r\nCOMPANY_NAME1=Nombre 1\r\n\r\n#XFLD,20: W4: Label for name 2 of a company used general data\r\nCOMPANY_NAME2=Nombre 2\r\n\r\n#XFLD,20: W4: Label for first name of a person used general data\r\nFIRST_NAME=Nombre\r\n\r\n#XFLD,20: W4: Label for last name of a person used general data\r\nLAST_NAME=Apellido\r\n\r\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nBIRTHDAY=Fecha de nacimiento\r\n\r\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nTITLE=T\\u00EDtulo\r\n\r\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nACADEMIC_TITLE=T\\u00EDtulo acad\\u00E9mico\r\n\r\n#XFLD,20: W4: Label for mobile phone number used general data\r\nMOBILE=Tel\\u00E9fono m\\u00F3vil\r\n\r\n#XFLD,20: W4: Label for phone number used general data\r\nPHONE=Tel\\u00E9fono\r\n\r\n#XFLD,20: W4: Label for e-mail used general data\r\nEMAIL=Correo electr\\u00F3nico\r\n\r\n#XFLD,20: W4: Label for web site used general data\r\nWEBSITE=Sitio Web\r\n\r\n#XFLD,20: W4: Label for country used general data\r\nCOUNTRY=Pa\\u00EDs\r\n\r\n#XFLD,20: W4: Label for region used general data\r\nREGION=Regi\\u00F3n\r\n\r\n#XFLD,20: W4: Label for city used general data\r\nCITY=Ciudad\r\n\r\n#XFLD,20: W4: Label for postal code used general data\r\nPOSTAL_CODE=C\\u00F3digo postal\r\n\r\n#XFLD,20: W4: Label for street used general data\r\nSTREET=Calle\r\n\r\n#XFLD,10: W4: Label for house number used general data\r\nHOUSE_NUMBER=N\\u00BA de casa\r\n\r\n#XFLD,15: W6: Label for ID used in Quotations\r\nID=ID\r\n\r\n#XFLD,15: W6: Label for Amount used in Quotations\r\nAMOUNT=Importe\r\n\r\n#XFLD,20: W6: Label for Expiration Date used in Quotations\r\nEXPIRATION_DATE=Fecha de vencimiento\r\n\r\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\r\nDELIVERY_DATE=Fecha de entrega\r\n\r\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\r\nSALES_EMPLOYEE=Representante vta.\r\n\r\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\r\nATTRIBUTESET=Grupo de atributos\r\n\r\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\r\nATTRIBUTE=Atributos\r\n\r\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\r\nVALUE=Valor\r\n\r\n#XBUT, 20: Button to create an Account\r\nBUTTON_ADD=A\\u00F1adir\r\n\r\n#XBUT, 20: Button to edit an Account\r\nBUTTON_EDIT=Editar\r\n\r\n#XBUT, 20: Button to save changes\r\nBUTTON_SAVE=Grabar\r\n\r\n#XBUT, 20: Button to cancel changes\r\nBUTTON_CANCEL=Cancelar\r\n\r\n#XBUT, 30: Button which shows the personalization buttons\r\nBUTTON_SHOW_PERSONALIZATION=Mostrar personalizaci\\u00F3n\r\n\r\n#XBUT, 30: Button which hides the personalization buttons\r\nBUTTON_HIDE_PERSONALIZATION=Ocultar personalizaci\\u00F3n\r\n\r\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_CONFIRM_CANCEL=Cualquier modificaci\\u00F3n que no haya guardado se perder\\u00E1. \\u00BFDesea continuar?\r\n\r\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\r\nMSG_CONFIRM_DELETE_CONTACT=Se cancelar\\u00E1 la asignaci\\u00F3n del contacto de la cuenta. \\u00BFDesea continuar?\r\n\r\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_SUCCESS=Cuenta actualizada\r\n\r\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_ERROR=Error de actualizaci\\u00F3n\r\n\r\n# XMSG : Account update succeeded\r\nMSG_CREATION_SUCCESS=Cuenta creada\r\n\r\n# XMSG : Task creation succeeded\r\nMSG_TASK_CREATION_SUCCESS=Tarea creada\r\n\r\n# XMSG : Contact creation failed\r\nMSG_CREATION_ERROR=Error de creaci\\u00F3n\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong country\r\nMSG_WRONG_COUNTRY_ERROR=El pa\\u00EDs "{0}" no existe\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong region\r\nMSG_WRONG_REGION_ERROR=No existe la regi\\u00F3n "{0}" para el pa\\u00EDs\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong employee\r\nMSG_WRONG_EMPLOYEE_ERROR=El empleado "{0}" no existe.\r\n\r\n# XMSG: message that will be displayed, if the user has entered invalid website url\r\nMSG_WRONG_URL_ERROR=La direcci\\u00F3n URL introducida "{0}" no es v\\u00E1lida.\r\n\r\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\r\nMSG_MANDATORY_FIELDS=No se han rellenado todos los campos obligatorios\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA=Otro usuario ha modificado los datos. \\u00BFDesea sobrescribir las modificaciones del otro usuario con sus propias modificaciones?\r\n\r\n# XMSG: message that will be displayed in case of conflicts during file renaming\r\nMSG_CONFLICTING_FILE_NAME=Otro usuario ha modificado el nombre del fichero. \\u00BFDesea sobrescribir las modificaciones del otro usuario con sus propias modificaciones?\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA_WITH_REFRESH=Otro usuario ha modificado los datos. Estas modificaciones ahora aparecer\\u00E1n en la aplicaci\\u00F3n.\r\n\r\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\r\nMSG_NOT_IN_MAIN_CONTACT=Solo puede ver los detalles de los contactos asignados a esta cuenta\r\n\r\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\r\nMSG_EXCEEDING_FILE_NAME_LENGTH=El nombre del archivo puede tener un m\\u00E1ximo de 40 caracteres.\r\n\r\n# XTOL, 20: tooltip shown on search result list for button to add an account"\r\n\r\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\r\n\r\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\r\n\r\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\r\n\r\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\r\n\r\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\r\n',
	"cus/crm/myaccounts/i18n/i18n_fr.properties":'# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XFLD, 30: Facet title for general Data\r\nGENERAL_DATA=Donn\\u00E9es g\\u00E9n\\u00E9rales\r\n\r\n#XTIT, 40: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=Mes comptes\r\n\r\n#XTIT, 40: this is the title for the detail screen\r\nDETAIL_TITLE=Compte\r\n\r\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\r\nREVENUE_CURRENT=Produit ann\\u00E9e cum.\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\r\nREVENUE_CURRENT_TOOLTIP=Revenu \\u00E0 date ann\\u00E9e en cours\r\n\r\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\r\nREVENUE_LAST=ProduitAnn\\u00E9ePr\\u00E9c.\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\r\nREVENUE_LAST_TOOLTIP=Produit ann\\u00E9e pr\\u00E9c\\u00E9dente\r\n\r\n# XFLD, 30: Facet title for opportunities and label in facet general data\r\nOPPORTUNITIES=Opportunit\\u00E9s\r\n\r\n#XFLD, 30: Facet title for leads\r\nLEADS=Int\\u00E9r\\u00EAts potentiels\r\n\r\n#XFLD, 30: Facet title for tasks\r\nTASKS=T\\u00E2ches\r\n\r\n#XFLD, 30: Facet title for appointments\r\nAPPOINTMENTS=Rendez-vous\r\n\r\n#XFLD, 30: Facet title for quotations\r\nQUOTATIONS=Offres\r\n\r\n#XFLD, 30: Facet title for sales orders\r\nSALES_ORDERS=Commandes client\r\n\r\n#XFLD, 30: W7: Facet title for marketing attributes\r\nMARKETINGATTRIBUTES=Attributs marketing\r\n\r\n#XFLD, 30: W6: Title for popup with products\r\nPRODUCTS=Produits\r\n\r\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\r\nEMPLOYEE_RESPONSIBLE=Responsable\r\n\r\n#XFLD, 30: Facet title for Attachments\r\nATTACHMENTS=Pi\\u00E8ces jointes\r\n\r\n#XFLD, 30: Facet title for Notes\r\nNOTES=Notes\r\n\r\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\r\nNEW_NOTE=Nouvelle note\r\n\r\n#XFLD, 30: Facet title for Contacts\r\nCONTACTS=Contacts\r\n\r\n#XFLD, 30: Label for Address in facet general data\r\nADDRESS=Adresse\r\n\r\n#XFLD, 30: Label for Opportunities in facet general data\r\nUNWEIGHTED_OPPORTUNITIES=Opportunit\\u00E9s\r\n\r\n#XFLD, 30: Label for Rating in facet general data\r\nRATING=\\u00C9valuation\r\n\r\n# XFLD, 30: Label for Next contact in facet Appointments\r\nNEXT_APPOINTMENT=Prochain rendez-vous\r\n\r\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\r\nLAST_APPOINTMENT=Dernier rendez-vous\r\n\r\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\r\nIMAGE=Image\r\n\r\n#XBUT, 20: Button to show the create actionsheet\r\nCREATE=Cr\\u00E9er\r\n\r\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\r\nDISCUSS_ENTRY=En discuter sur SAP Jam\r\n\r\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\r\nSHARE_ENTRY=Partager via SAP JAM\r\n\r\n#XBUT, 20: Button to share the note\r\nDETAIL_BUTTON_SHARE=Partager\r\n\r\n#XBUT, 20: Button to cancel sharing\r\nDETAIL_BUTTON_CANCEL=Interrompre\r\n\r\n#XFLD,20: All accounts for filter\r\nALL_ACCOUNTS=Tous les comptes\r\n\r\n#XFLD,35: All individual accounts for filter\r\nALL_INDIVIDUAL_ACCOUNTS=Tous les comptes priv\\u00E9s\r\n\r\n#XFLD,35: All corporate accounts for filter\r\nALL_CORPORATE_ACCOUNTS=Tous les comptes d\'entreprise\r\n\r\n#XFLD,35: All group accounts for filter\r\nALL_ACCOUNT_GROUPS=Tous les groupes de comptes\r\n\r\n#XFLD,20: my account for filter\r\nMY_ACCOUNT=Mes comptes\r\n\r\n#XFLD,35: my individual accounts for filter\r\nMY_INDIVIDUAL_ACCOUNTS=Mes comptes priv\\u00E9s\r\n\r\n#XFLD,35: my corporate accounts for filter\r\nMY_CORPORATE_ACCOUNTS=Mes comptes d\'entreprise\r\n\r\n#XFLD,35: my group accounts for filter\r\nMY_ACCOUNT_GROUPS=Mes groupes de comptes\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nINDIVIDUAL_ACCOUNT=Compte priv\\u00E9\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nCORPORATE_ACCOUNT=Compte d\\u2019entreprise\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nACCOUNT_GROUP=Groupe de comptes\r\n\r\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\r\nSTARTING=Date de d\\u00E9but\\u00A0\\: {0}\r\n\r\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\r\nCLOSING=Date de cl\\u00F4ture\\u00A0\\: {0}\r\n\r\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\r\nDUE=Date d\'\'\\u00E9ch\\u00E9ance\\u00A0\\: {0}\r\n\r\n#XFLD,20: All accounts for title\r\nALL_ACCOUNTS_TITLE=Tous les comptes ({0})\r\n\r\n#XFLD,35: All individual accounts for title\r\nALL_INDIVIDUAL_ACCOUNTS_TITLE=Tous les comptes priv\\u00E9s ({0})\r\n\r\n#XFLD,35: All corporate accounts for title\r\nALL_CORPORATE_ACCOUNTS_TITLE=Tous les comptes d\'\'entreprise ({0})\r\n\r\n#XFLD,35: All group accounts for title\r\nALL_ACCOUNT_GROUPS_TITLE=Tous les groupes de comptes ({0})\r\n\r\n#XFLD,20: my account for title\r\nMY_ACCOUNT_TITLE=Mes comptes ({0})\r\n\r\n#XFLD,35: my individual account for title\r\nMY_INDIVIDUAL_ACCOUNT_TITLE=Mes comptes priv\\u00E9s ({0})\r\n\r\n#XFLD,35: my corporate account for title.\r\nMY_CORPORATE_ACCOUNT_TITLE=Mes comptes d\'\'entreprise ({0})\r\n\r\n#XFLD,35: my group account for title\r\nMY_ACCOUNT_GROUP_TITLE=Mes groupes de comptes ({0})\r\n\r\n#XFLD,30: filtered by info\r\nFILTERED_BY=Filtr\\u00E9 par\\u00A0\\: {0}\r\n\r\n#XFLD,30: label, search for accounts\r\nSEARCH_ACCOUNTS=Rechercher\r\n\r\n#XFLD,30: comma separator for location\r\nLOCATION={0}, {1}\r\n\r\n#XFLD: W4: Label for All day text in Appointments\r\nALL_DAY_EVENT=Toute la journ\\u00E9e\r\n\r\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\r\nDURATION_MINUTE={0} mn.\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\r\nDURATION_HOUR={0}\\u00A0h\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\r\nDURATION_DAY={0}\\u00A0jour\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\r\nDURATION_DAYS={0}\\u00A0jours\r\n\r\n#XFLD: W4: Label for Private meeting\r\nPRIVATE=Priv\\u00E9\r\n\r\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\r\nSELECT_TRANSACTION_TYPE=S\\u00E9lection du type d\'op\\u00E9ration\r\n\r\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\r\nNEW_TASK_INPUT_PLACEHOLDER=Nouvelle t\\u00E2che\r\n\r\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nNO_DATA_TEXT=Aucune donn\\u00E9e\r\n\r\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nLOADING_TEXT=Chargement...\r\n\r\n#XFLD,25: W4: Column label for name of contact person in contacts\r\nNAME=Nom\r\n\r\n#XFLD,25: W5: Column label for department of contact person in contacts\r\nDEPARTMENT=Service\r\n\r\n#XFLD,15: W6: Column label for actions of contact person in contacts\r\nACTIONS=Actions\r\n\r\n#XFLD,25: W4: Column label for description of lead in Leads\r\nDESCRIPTION=Description\r\n\r\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\r\nASSIGNED_TO=Affect\\u00E9 \\u00E0\r\n\r\n#XFLD,15: W4: Column label for end date of lead in Leads\r\nEND_DATE=Date de fin\r\n\r\n#XFLD,15: W4: Column label for qualification level of lead in Leads\r\nQUALIFICATION=Qualification\r\n\r\n#XFLD,15: W4: Column label for status of lead in Leads\r\nSTATUS=Statut\r\n\r\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\r\nMAIN_CONTACT=Contact principal\r\n\r\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\r\nVOLUME=Volume\r\n\r\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\r\nPROBABILITY=Probabilit\\u00E9\r\n\r\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\r\nCLOSE_BY=Cl\\u00F4turer avant\r\n\r\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \r\nVIEWS=Vues\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\r\nCONTACT_TITLE=Contact\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\r\nEMPLOYEE_TITLE=Salari\\u00E9\r\n\r\n#XTIT,20: W7: Title of pop-up used in confirm popup\r\nCONFIRM_TITLE=Confirmation\r\n\r\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\r\nCOMPANY_NAME=Nom\r\n\r\n#XFLD,20: W4: Label for name 1 of a company used general data\r\nCOMPANY_NAME1=Nom 1\r\n\r\n#XFLD,20: W4: Label for name 2 of a company used general data\r\nCOMPANY_NAME2=Nom 2\r\n\r\n#XFLD,20: W4: Label for first name of a person used general data\r\nFIRST_NAME=Pr\\u00E9nom\r\n\r\n#XFLD,20: W4: Label for last name of a person used general data\r\nLAST_NAME=Nom\r\n\r\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nBIRTHDAY=Date de naissance\r\n\r\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nTITLE=Titre\r\n\r\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nACADEMIC_TITLE=Titre universitaire\r\n\r\n#XFLD,20: W4: Label for mobile phone number used general data\r\nMOBILE=N\\u00B0 t\\u00E9l. portable\r\n\r\n#XFLD,20: W4: Label for phone number used general data\r\nPHONE=N\\u00B0 de t\\u00E9l\\u00E9phone\r\n\r\n#XFLD,20: W4: Label for e-mail used general data\r\nEMAIL=E-mail\r\n\r\n#XFLD,20: W4: Label for web site used general data\r\nWEBSITE=Site Web\r\n\r\n#XFLD,20: W4: Label for country used general data\r\nCOUNTRY=Pays\r\n\r\n#XFLD,20: W4: Label for region used general data\r\nREGION=R\\u00E9gion\r\n\r\n#XFLD,20: W4: Label for city used general data\r\nCITY=Ville\r\n\r\n#XFLD,20: W4: Label for postal code used general data\r\nPOSTAL_CODE=Code postal\r\n\r\n#XFLD,20: W4: Label for street used general data\r\nSTREET=Rue\r\n\r\n#XFLD,10: W4: Label for house number used general data\r\nHOUSE_NUMBER=N\\u00B0 de rue\r\n\r\n#XFLD,15: W6: Label for ID used in Quotations\r\nID=ID\r\n\r\n#XFLD,15: W6: Label for Amount used in Quotations\r\nAMOUNT=Montant\r\n\r\n#XFLD,20: W6: Label for Expiration Date used in Quotations\r\nEXPIRATION_DATE=Date d\'expiration\r\n\r\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\r\nDELIVERY_DATE=Date de livraison\r\n\r\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\r\nSALES_EMPLOYEE=Commercial\r\n\r\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\r\nATTRIBUTESET=Ensemble d\'attributs\r\n\r\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\r\nATTRIBUTE=Attribut\r\n\r\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\r\nVALUE=Valeur\r\n\r\n#XBUT, 20: Button to create an Account\r\nBUTTON_ADD=Ajouter\r\n\r\n#XBUT, 20: Button to edit an Account\r\nBUTTON_EDIT=Modifier\r\n\r\n#XBUT, 20: Button to save changes\r\nBUTTON_SAVE=Sauvegarder\r\n\r\n#XBUT, 20: Button to cancel changes\r\nBUTTON_CANCEL=Interrompre\r\n\r\n#XBUT, 30: Button which shows the personalization buttons\r\nBUTTON_SHOW_PERSONALIZATION=Aff. personnalisat.\r\n\r\n#XBUT, 30: Button which hides the personalization buttons\r\nBUTTON_HIDE_PERSONALIZATION=Masquer personnalis.\r\n\r\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_CONFIRM_CANCEL=Toutes les modifications non sauvegard\\u00E9es seront perdues. Voulez-vous continuer ?\r\n\r\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\r\nMSG_CONFIRM_DELETE_CONTACT=Le contact ne sera plus affect\\u00E9 au compte. Voulez-vous poursuivre ?\r\n\r\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_SUCCESS=Compte mis \\u00E0 jour\r\n\r\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_ERROR=\\u00C9chec de la mise \\u00E0 jour\r\n\r\n# XMSG : Account update succeeded\r\nMSG_CREATION_SUCCESS=Compte cr\\u00E9\\u00E9\r\n\r\n# XMSG : Task creation succeeded\r\nMSG_TASK_CREATION_SUCCESS=T\\u00E2che cr\\u00E9\\u00E9e\r\n\r\n# XMSG : Contact creation failed\r\nMSG_CREATION_ERROR=\\u00C9chec de la cr\\u00E9ation\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong country\r\nMSG_WRONG_COUNTRY_ERROR=Le pays "{0}" n\'\'existe pas.\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong region\r\nMSG_WRONG_REGION_ERROR=La r\\u00E9gion "{0}" n\'\'existe pas pour ce pays.\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong employee\r\nMSG_WRONG_EMPLOYEE_ERROR=Le salari\\u00E9 "{0}" n\'\'existe pas.\r\n\r\n# XMSG: message that will be displayed, if the user has entered invalid website url\r\nMSG_WRONG_URL_ERROR=L\'\'URL "{0}" saisi n\'\'est pas valide.\r\n\r\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\r\nMSG_MANDATORY_FIELDS=Certaines zones obligatoires ne sont pas renseign\\u00E9es.\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA=Les donn\\u00E9es ont \\u00E9t\\u00E9 modifi\\u00E9es par un autre utilisateur. Voulez-vous remplacer les modifications de l\'autre utilisateur par vos entr\\u00E9es ?\r\n\r\n# XMSG: message that will be displayed in case of conflicts during file renaming\r\nMSG_CONFLICTING_FILE_NAME=Le nom du fichier a \\u00E9t\\u00E9 modifi\\u00E9 par un autre utilisateur. Voulez-vous remplacer les modifications de l\'autre utilisateur par vos entr\\u00E9es ?\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA_WITH_REFRESH=Donn\\u00E9es modifi\\u00E9es par un autre utilisateur. Ces modifications seront d\\u00E9sormais visibles dans l\'application.\r\n\r\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\r\nMSG_NOT_IN_MAIN_CONTACT=Vous pouvez uniquement afficher les d\\u00E9tails des contacts affect\\u00E9s \\u00E0 ce compte.\r\n\r\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\r\nMSG_EXCEEDING_FILE_NAME_LENGTH=La longueur maximale du nom du fichier est de 40 caract\\u00E8res.\r\n\r\n# XTOL, 20: tooltip shown on search result list for button to add an account"\r\n\r\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\r\n\r\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\r\n\r\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\r\n\r\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\r\n\r\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\r\n',
	"cus/crm/myaccounts/i18n/i18n_hr.properties":'# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XFLD, 30: Facet title for general Data\r\nGENERAL_DATA=Op\\u0107i podaci\r\n\r\n#XTIT, 40: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=Moja klijenti\r\n\r\n#XTIT, 40: this is the title for the detail screen\r\nDETAIL_TITLE=Klijent\r\n\r\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\r\nREVENUE_CURRENT=Prihod god. do dtm\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\r\nREVENUE_CURRENT_TOOLTIP=Prihodi do datuma teku\\u0107a godina\r\n\r\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\r\nREVENUE_LAST=Prihod pro\\u0161le god.\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\r\nREVENUE_LAST_TOOLTIP=Prihod pro\\u0161le godine\r\n\r\n# XFLD, 30: Facet title for opportunities and label in facet general data\r\nOPPORTUNITIES=Prilike\r\n\r\n#XFLD, 30: Facet title for leads\r\nLEADS=Leadovi\r\n\r\n#XFLD, 30: Facet title for tasks\r\nTASKS=Zadaci\r\n\r\n#XFLD, 30: Facet title for appointments\r\nAPPOINTMENTS=Sastanci\r\n\r\n#XFLD, 30: Facet title for quotations\r\nQUOTATIONS=Ponude\r\n\r\n#XFLD, 30: Facet title for sales orders\r\nSALES_ORDERS=Prodajni nalozi\r\n\r\n#XFLD, 30: W7: Facet title for marketing attributes\r\nMARKETINGATTRIBUTES=Marketin\\u0161ki atributi\r\n\r\n#XFLD, 30: W6: Title for popup with products\r\nPRODUCTS=Proizvodi\r\n\r\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\r\nEMPLOYEE_RESPONSIBLE=Odgovorni zaposlenik\r\n\r\n#XFLD, 30: Facet title for Attachments\r\nATTACHMENTS=Prilozi\r\n\r\n#XFLD, 30: Facet title for Notes\r\nNOTES=Bilje\\u0161ke\r\n\r\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\r\nNEW_NOTE=Nova bilje\\u0161ka\r\n\r\n#XFLD, 30: Facet title for Contacts\r\nCONTACTS=Kontakti\r\n\r\n#XFLD, 30: Label for Address in facet general data\r\nADDRESS=Adresa\r\n\r\n#XFLD, 30: Label for Opportunities in facet general data\r\nUNWEIGHTED_OPPORTUNITIES=Prilike\r\n\r\n#XFLD, 30: Label for Rating in facet general data\r\nRATING=Ocjenjivanje\r\n\r\n# XFLD, 30: Label for Next contact in facet Appointments\r\nNEXT_APPOINTMENT=Sljede\\u0107i sastanak\r\n\r\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\r\nLAST_APPOINTMENT=Zadnji sastanak\r\n\r\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\r\nIMAGE=Slika\r\n\r\n#XBUT, 20: Button to show the create actionsheet\r\nCREATE=Kreiraj\r\n\r\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\r\nDISCUSS_ENTRY=Rasprava u SAP Jamu\r\n\r\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\r\nSHARE_ENTRY=Podijeli u SAP Jamu\r\n\r\n#XBUT, 20: Button to share the note\r\nDETAIL_BUTTON_SHARE=Otpusti\r\n\r\n#XBUT, 20: Button to cancel sharing\r\nDETAIL_BUTTON_CANCEL=Otka\\u017Ei\r\n\r\n#XFLD,20: All accounts for filter\r\nALL_ACCOUNTS=Svi klijenti\r\n\r\n#XFLD,35: All individual accounts for filter\r\nALL_INDIVIDUAL_ACCOUNTS=Sva pojedina\\u010Dni klijenti\r\n\r\n#XFLD,35: All corporate accounts for filter\r\nALL_CORPORATE_ACCOUNTS=Svi klijenti poduze\\u0107a\r\n\r\n#XFLD,35: All group accounts for filter\r\nALL_ACCOUNT_GROUPS=Sve grupe klijenata\r\n\r\n#XFLD,20: my account for filter\r\nMY_ACCOUNT=Moja klijenti\r\n\r\n#XFLD,35: my individual accounts for filter\r\nMY_INDIVIDUAL_ACCOUNTS=Moji pojedina\\u010Dni klijenti\r\n\r\n#XFLD,35: my corporate accounts for filter\r\nMY_CORPORATE_ACCOUNTS=Moja klijenti poduze\\u0107a\r\n\r\n#XFLD,35: my group accounts for filter\r\nMY_ACCOUNT_GROUPS=Moje grupe klijenata\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nINDIVIDUAL_ACCOUNT=Pojedina\\u010Dni klijent\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nCORPORATE_ACCOUNT=Klijent poduze\\u0107a\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nACCOUNT_GROUP=Grupa klijenata\r\n\r\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\r\nSTARTING=Start Date\\: {0}\r\n\r\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\r\nCLOSING=Closing Date\\: {0}\r\n\r\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\r\nDUE=Due Date\\: {0}\r\n\r\n#XFLD,20: All accounts for title\r\nALL_ACCOUNTS_TITLE=All Accounts ({0})\r\n\r\n#XFLD,35: All individual accounts for title\r\nALL_INDIVIDUAL_ACCOUNTS_TITLE=All Individual Accounts ({0})\r\n\r\n#XFLD,35: All corporate accounts for title\r\nALL_CORPORATE_ACCOUNTS_TITLE=All Corporate Accounts ({0})\r\n\r\n#XFLD,35: All group accounts for title\r\nALL_ACCOUNT_GROUPS_TITLE=All Account Groups ({0})\r\n\r\n#XFLD,20: my account for title\r\nMY_ACCOUNT_TITLE=My Accounts ({0})\r\n\r\n#XFLD,35: my individual account for title\r\nMY_INDIVIDUAL_ACCOUNT_TITLE=My Individual Accounts ({0})\r\n\r\n#XFLD,35: my corporate account for title.\r\nMY_CORPORATE_ACCOUNT_TITLE=My Corporate Accounts ({0})\r\n\r\n#XFLD,35: my group account for title\r\nMY_ACCOUNT_GROUP_TITLE=My Account Groups ({0})\r\n\r\n#XFLD,30: filtered by info\r\nFILTERED_BY=Filtered By\\: {0}\r\n\r\n#XFLD,30: label, search for accounts\r\nSEARCH_ACCOUNTS=Tra\\u017Eenje\r\n\r\n#XFLD,30: comma separator for location\r\nLOCATION={0}, {1}\r\n\r\n#XFLD: W4: Label for All day text in Appointments\r\nALL_DAY_EVENT=Cijeli dan\r\n\r\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\r\nDURATION_MINUTE={0} min\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\r\nDURATION_HOUR={0} h\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\r\nDURATION_DAY={0} day\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\r\nDURATION_DAYS={0} days\r\n\r\n#XFLD: W4: Label for Private meeting\r\nPRIVATE=Osobno\r\n\r\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\r\nSELECT_TRANSACTION_TYPE=Odaberi tip transakcije\r\n\r\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\r\nNEW_TASK_INPUT_PLACEHOLDER=Novi zadatak\r\n\r\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nNO_DATA_TEXT=Nema podataka\r\n\r\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nLOADING_TEXT=U\\u010Ditavanje...\r\n\r\n#XFLD,25: W4: Column label for name of contact person in contacts\r\nNAME=Naziv\r\n\r\n#XFLD,25: W5: Column label for department of contact person in contacts\r\nDEPARTMENT=Odjel\r\n\r\n#XFLD,15: W6: Column label for actions of contact person in contacts\r\nACTIONS=Radnje\r\n\r\n#XFLD,25: W4: Column label for description of lead in Leads\r\nDESCRIPTION=Opis\r\n\r\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\r\nASSIGNED_TO=Dodijeljeno\r\n\r\n#XFLD,15: W4: Column label for end date of lead in Leads\r\nEND_DATE=Datum zavr\\u0161etka\r\n\r\n#XFLD,15: W4: Column label for qualification level of lead in Leads\r\nQUALIFICATION=Kvalifikacija\r\n\r\n#XFLD,15: W4: Column label for status of lead in Leads\r\nSTATUS=Status\r\n\r\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\r\nMAIN_CONTACT=Glavni kontakt\r\n\r\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\r\nVOLUME=Obujam\r\n\r\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\r\nPROBABILITY=Vjerojatnost\r\n\r\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\r\nCLOSE_BY=Zatvori do\r\n\r\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \r\nVIEWS=Pogledi\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\r\nCONTACT_TITLE=Kontakt\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\r\nEMPLOYEE_TITLE=Zaposlenik\r\n\r\n#XTIT,20: W7: Title of pop-up used in confirm popup\r\nCONFIRM_TITLE=Potvrdi\r\n\r\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\r\nCOMPANY_NAME=Naziv\r\n\r\n#XFLD,20: W4: Label for name 1 of a company used general data\r\nCOMPANY_NAME1=Naziv 1\r\n\r\n#XFLD,20: W4: Label for name 2 of a company used general data\r\nCOMPANY_NAME2=Naziv 2\r\n\r\n#XFLD,20: W4: Label for first name of a person used general data\r\nFIRST_NAME=Ime\r\n\r\n#XFLD,20: W4: Label for last name of a person used general data\r\nLAST_NAME=Prezime\r\n\r\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nBIRTHDAY=Datum ro\\u0111enja\r\n\r\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nTITLE=Naslov\r\n\r\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nACADEMIC_TITLE=Akademska titula\r\n\r\n#XFLD,20: W4: Label for mobile phone number used general data\r\nMOBILE=Mobilni telefon\r\n\r\n#XFLD,20: W4: Label for phone number used general data\r\nPHONE=Telefon\r\n\r\n#XFLD,20: W4: Label for e-mail used general data\r\nEMAIL=E-po\\u0161ta\r\n\r\n#XFLD,20: W4: Label for web site used general data\r\nWEBSITE=Web stranica\r\n\r\n#XFLD,20: W4: Label for country used general data\r\nCOUNTRY=Dr\\u017Eava\r\n\r\n#XFLD,20: W4: Label for region used general data\r\nREGION=Regija\r\n\r\n#XFLD,20: W4: Label for city used general data\r\nCITY=Grad\r\n\r\n#XFLD,20: W4: Label for postal code used general data\r\nPOSTAL_CODE=Po\\u0161tanski broj\r\n\r\n#XFLD,20: W4: Label for street used general data\r\nSTREET=Ulica\r\n\r\n#XFLD,10: W4: Label for house number used general data\r\nHOUSE_NUMBER=Ku\\u0107ni broj\r\n\r\n#XFLD,15: W6: Label for ID used in Quotations\r\nID=ID\r\n\r\n#XFLD,15: W6: Label for Amount used in Quotations\r\nAMOUNT=Iznos\r\n\r\n#XFLD,20: W6: Label for Expiration Date used in Quotations\r\nEXPIRATION_DATE=Datum isteka\r\n\r\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\r\nDELIVERY_DATE=Datum isporuke\r\n\r\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\r\nSALES_EMPLOYEE=Zaposlenik u prodaji\r\n\r\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\r\nATTRIBUTESET=Skup atributa\r\n\r\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\r\nATTRIBUTE=Atribut\r\n\r\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\r\nVALUE=Vrijednost\r\n\r\n#XBUT, 20: Button to create an Account\r\nBUTTON_ADD=Dodaj\r\n\r\n#XBUT, 20: Button to edit an Account\r\nBUTTON_EDIT=Uredi\r\n\r\n#XBUT, 20: Button to save changes\r\nBUTTON_SAVE=Snimi\r\n\r\n#XBUT, 20: Button to cancel changes\r\nBUTTON_CANCEL=Otka\\u017Ei\r\n\r\n#XBUT, 30: Button which shows the personalization buttons\r\nBUTTON_SHOW_PERSONALIZATION=Poka\\u017Ei personalizaciju\r\n\r\n#XBUT, 30: Button which hides the personalization buttons\r\nBUTTON_HIDE_PERSONALIZATION=Sakrij personalizaciju\r\n\r\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_CONFIRM_CANCEL=Nesnimljene promjene \\u0107e se izgubiti. \\u017Delite li nastaviti?\r\n\r\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\r\nMSG_CONFIRM_DELETE_CONTACT=Dodjela kontakta klijentu bit \\u0107e poni\\u0161tena. \\u017Delite li nastaviti?\r\n\r\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_SUCCESS=Klijent a\\u017Euriran\r\n\r\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_ERROR=A\\u017Euriranje nije uspjelo\r\n\r\n# XMSG : Account update succeeded\r\nMSG_CREATION_SUCCESS=Klijent kreiran\r\n\r\n# XMSG : Task creation succeeded\r\nMSG_TASK_CREATION_SUCCESS=Zadatak kreiran\r\n\r\n# XMSG : Contact creation failed\r\nMSG_CREATION_ERROR=Kreiranje nije uspjelo\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong country\r\nMSG_WRONG_COUNTRY_ERROR=Country "{0}" does not exist\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong region\r\nMSG_WRONG_REGION_ERROR=Region "{0}" does not exist for country\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong employee\r\nMSG_WRONG_EMPLOYEE_ERROR=Employee "{0}" does not exist.\r\n\r\n# XMSG: message that will be displayed, if the user has entered invalid website url\r\nMSG_WRONG_URL_ERROR=Entered URL "{0}" is not valid.\r\n\r\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\r\nMSG_MANDATORY_FIELDS=Sva polja obaveznog unosa nisu popunjena\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA=Podatke je promijenio drugi korisnik. \\u017Delite li pisati preko promjena drugog korisnika?\r\n\r\n# XMSG: message that will be displayed in case of conflicts during file renaming\r\nMSG_CONFLICTING_FILE_NAME=Naziv datoteke promijenio je drugi korisnik. \\u017Delite li pisati preko promjena drugog korisnika?\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA_WITH_REFRESH=Podatke je promijenio drugi korisnik. Ove promjene pojavit \\u0107e se sada u aplikaciji.\r\n\r\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\r\nMSG_NOT_IN_MAIN_CONTACT=Mo\\u017Eete pregledati samo detalje kontakata koji su dodijeljeni ovom klijentu\r\n\r\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\r\nMSG_EXCEEDING_FILE_NAME_LENGTH=Naziv datoteke mo\\u017Ee imati maksimalno 40 znakova.\r\n\r\n# XTOL, 20: tooltip shown on search result list for button to add an account"\r\n\r\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\r\n\r\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\r\n\r\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\r\n\r\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\r\n\r\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\r\n',
	"cus/crm/myaccounts/i18n/i18n_hu.properties":'# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XFLD, 30: Facet title for general Data\r\nGENERAL_DATA=\\u00C1ltal\\u00E1nos adatok\r\n\r\n#XTIT, 40: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=Saj\\u00E1t fi\\u00F3kok\r\n\r\n#XTIT, 40: this is the title for the detail screen\r\nDETAIL_TITLE=Fi\\u00F3k\r\n\r\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\r\nREVENUE_CURRENT=Forgalom YTD\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\r\nREVENUE_CURRENT_TOOLTIP=Forgalom m\\u00E1ig (aktu\\u00E1lis \\u00E9v)\r\n\r\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\r\nREVENUE_LAST=Forg. el\\u0151z\\u0151 \\u00E9vben\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\r\nREVENUE_LAST_TOOLTIP=Forgalom az el\\u0151z\\u0151 \\u00E9vben\r\n\r\n# XFLD, 30: Facet title for opportunities and label in facet general data\r\nOPPORTUNITIES=Opportunityk\r\n\r\n#XFLD, 30: Facet title for leads\r\nLEADS=Leadek\r\n\r\n#XFLD, 30: Facet title for tasks\r\nTASKS=Feladatok\r\n\r\n#XFLD, 30: Facet title for appointments\r\nAPPOINTMENTS=Tal\\u00E1lkoz\\u00F3k\r\n\r\n#XFLD, 30: Facet title for quotations\r\nQUOTATIONS=Aj\\u00E1nlatok\r\n\r\n#XFLD, 30: Facet title for sales orders\r\nSALES_ORDERS=Vev\\u0151i rendel\\u00E9sek\r\n\r\n#XFLD, 30: W7: Facet title for marketing attributes\r\nMARKETINGATTRIBUTES=Marketingattrib\\u00FAtumok\r\n\r\n#XFLD, 30: W6: Title for popup with products\r\nPRODUCTS=Term\\u00E9kek\r\n\r\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\r\nEMPLOYEE_RESPONSIBLE=Illet\\u00E9kes dolgoz\\u00F3\r\n\r\n#XFLD, 30: Facet title for Attachments\r\nATTACHMENTS=Mell\\u00E9kletek\r\n\r\n#XFLD, 30: Facet title for Notes\r\nNOTES=Megjegyz\\u00E9sek\r\n\r\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\r\nNEW_NOTE=\\u00DAj jegyzet\r\n\r\n#XFLD, 30: Facet title for Contacts\r\nCONTACTS=Kapcsolatok\r\n\r\n#XFLD, 30: Label for Address in facet general data\r\nADDRESS=C\\u00EDm\r\n\r\n#XFLD, 30: Label for Opportunities in facet general data\r\nUNWEIGHTED_OPPORTUNITIES=Opportunityk\r\n\r\n#XFLD, 30: Label for Rating in facet general data\r\nRATING=Min\\u0151s\\u00EDt\\u00E9s\r\n\r\n# XFLD, 30: Label for Next contact in facet Appointments\r\nNEXT_APPOINTMENT=K\\u00F6vetkez\\u0151 tal\\u00E1lkoz\\u00F3\r\n\r\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\r\nLAST_APPOINTMENT=Utols\\u00F3 tal\\u00E1lkoz\\u00F3\r\n\r\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\r\nIMAGE=K\\u00E9p\r\n\r\n#XBUT, 20: Button to show the create actionsheet\r\nCREATE=L\\u00E9trehoz\\u00E1s\r\n\r\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\r\nDISCUSS_ENTRY=Vita itt\\: SAP Jam\r\n\r\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\r\nSHARE_ENTRY=Megoszt\\u00E1s itt\\: SAP Jam\r\n\r\n#XBUT, 20: Button to share the note\r\nDETAIL_BUTTON_SHARE=Megoszt\\u00E1s\r\n\r\n#XBUT, 20: Button to cancel sharing\r\nDETAIL_BUTTON_CANCEL=M\\u00E9gse\r\n\r\n#XFLD,20: All accounts for filter\r\nALL_ACCOUNTS=\\u00D6sszes \\u00FCgyf\\u00E9l\r\n\r\n#XFLD,35: All individual accounts for filter\r\nALL_INDIVIDUAL_ACCOUNTS=\\u00D6sszes mag\\u00E1n\\u00FCgyf\\u00E9l\r\n\r\n#XFLD,35: All corporate accounts for filter\r\nALL_CORPORATE_ACCOUNTS=\\u00D6sszes v\\u00E1llalati \\u00FCgyf\\u00E9l\r\n\r\n#XFLD,35: All group accounts for filter\r\nALL_ACCOUNT_GROUPS=\\u00D6sszes \\u00FCgyf\\u00E9lcsoport\r\n\r\n#XFLD,20: my account for filter\r\nMY_ACCOUNT=Saj\\u00E1t fi\\u00F3kok\r\n\r\n#XFLD,35: my individual accounts for filter\r\nMY_INDIVIDUAL_ACCOUNTS=Saj\\u00E1t mag\\u00E1n\\u00FCgyfelek\r\n\r\n#XFLD,35: my corporate accounts for filter\r\nMY_CORPORATE_ACCOUNTS=Saj\\u00E1t v\\u00E1llalati \\u00FCgyfelek\r\n\r\n#XFLD,35: my group accounts for filter\r\nMY_ACCOUNT_GROUPS=Saj\\u00E1t \\u00FCgyf\\u00E9lcsoportok\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nINDIVIDUAL_ACCOUNT=Mag\\u00E1nszem\\u00E9ly \\u00FCgyf\\u00E9l\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nCORPORATE_ACCOUNT=V\\u00E1llalati \\u00FCgyf\\u00E9l\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nACCOUNT_GROUP=Sz\\u00E1mlacsoport\r\n\r\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\r\nSTARTING=Ind\\u00EDt\\u00E1s d\\u00E1tuma\\: {0}\r\n\r\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\r\nCLOSING=Z\\u00E1r\\u00F3 d\\u00E1tum\\: {0}\r\n\r\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\r\nDUE=Esed\\u00E9kess\\u00E9gi d\\u00E1tum\\: {0}\r\n\r\n#XFLD,20: All accounts for title\r\nALL_ACCOUNTS_TITLE=\\u00D6sszes sz\\u00E1mla ({0})\r\n\r\n#XFLD,35: All individual accounts for title\r\nALL_INDIVIDUAL_ACCOUNTS_TITLE=\\u00D6sszes priv\\u00E1t \\u00FCgyf\\u00E9l ({0})\r\n\r\n#XFLD,35: All corporate accounts for title\r\nALL_CORPORATE_ACCOUNTS_TITLE=\\u00D6sszes v\\u00E1llalati \\u00FCgyf\\u00E9l ({0})\r\n\r\n#XFLD,35: All group accounts for title\r\nALL_ACCOUNT_GROUPS_TITLE=\\u00D6sszes \\u00FCgyf\\u00E9lcsoport ({0})\r\n\r\n#XFLD,20: my account for title\r\nMY_ACCOUNT_TITLE=Saj\\u00E1t sz\\u00E1ml\\u00E1k ({0})\r\n\r\n#XFLD,35: my individual account for title\r\nMY_INDIVIDUAL_ACCOUNT_TITLE=Saj\\u00E1t priv\\u00E1t \\u00FCgyfelek ({0})\r\n\r\n#XFLD,35: my corporate account for title.\r\nMY_CORPORATE_ACCOUNT_TITLE=Saj\\u00E1t v\\u00E1llalati \\u00FCgyfelek ({0})\r\n\r\n#XFLD,35: my group account for title\r\nMY_ACCOUNT_GROUP_TITLE=Saj\\u00E1t \\u00FCgyf\\u00E9lcsoportok ({0})\r\n\r\n#XFLD,30: filtered by info\r\nFILTERED_BY=Sz\\u0171r\\u00E9s a k\\u00F6vetkez\\u0151 szerint\\: {0}\r\n\r\n#XFLD,30: label, search for accounts\r\nSEARCH_ACCOUNTS=Keres\\u00E9s\r\n\r\n#XFLD,30: comma separator for location\r\nLOCATION={0}, {1}\r\n\r\n#XFLD: W4: Label for All day text in Appointments\r\nALL_DAY_EVENT=Eg\\u00E9sz nap\r\n\r\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\r\nDURATION_MINUTE={0} min\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\r\nDURATION_HOUR={0} h\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\r\nDURATION_DAY={0} nap\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\r\nDURATION_DAYS={0} nap\r\n\r\n#XFLD: W4: Label for Private meeting\r\nPRIVATE=Priv\\u00E1t\r\n\r\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\r\nSELECT_TRANSACTION_TYPE=Tranzakci\\u00F3fajta kiv\\u00E1laszt\\u00E1sa\r\n\r\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\r\nNEW_TASK_INPUT_PLACEHOLDER=\\u00DAj feladat\r\n\r\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nNO_DATA_TEXT=Nincs adat\r\n\r\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nLOADING_TEXT=Bet\\u00F6lt\\u00E9s...\r\n\r\n#XFLD,25: W4: Column label for name of contact person in contacts\r\nNAME=N\\u00E9v\r\n\r\n#XFLD,25: W5: Column label for department of contact person in contacts\r\nDEPARTMENT=Oszt\\u00E1ly\r\n\r\n#XFLD,15: W6: Column label for actions of contact person in contacts\r\nACTIONS=M\\u0171veletek\r\n\r\n#XFLD,25: W4: Column label for description of lead in Leads\r\nDESCRIPTION=Le\\u00EDr\\u00E1s\r\n\r\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\r\nASSIGNED_TO=Hozz\\u00E1rendelve -\r\n\r\n#XFLD,15: W4: Column label for end date of lead in Leads\r\nEND_DATE=Z\\u00E1r\\u00F3 d\\u00E1tum\r\n\r\n#XFLD,15: W4: Column label for qualification level of lead in Leads\r\nQUALIFICATION=Kvalifik\\u00E1ci\\u00F3\r\n\r\n#XFLD,15: W4: Column label for status of lead in Leads\r\nSTATUS=St\\u00E1tus\r\n\r\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\r\nMAIN_CONTACT=F\\u0151 t\\u00E1rgyal\\u00F3partner\r\n\r\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\r\nVOLUME=Mennyis\\u00E9g\r\n\r\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\r\nPROBABILITY=Val\\u00F3sz\\u00EDn\\u0171s\\u00E9g\r\n\r\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\r\nCLOSE_BY=Lez\\u00E1r\\u00E1s eddig\r\n\r\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \r\nVIEWS=N\\u00E9zetek\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\r\nCONTACT_TITLE=T\\u00E1rgyal\\u00F3partner\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\r\nEMPLOYEE_TITLE=Dolgoz\\u00F3\r\n\r\n#XTIT,20: W7: Title of pop-up used in confirm popup\r\nCONFIRM_TITLE=Visszaigazol\\u00E1s\r\n\r\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\r\nCOMPANY_NAME=N\\u00E9v\r\n\r\n#XFLD,20: W4: Label for name 1 of a company used general data\r\nCOMPANY_NAME1=1. n\\u00E9v\r\n\r\n#XFLD,20: W4: Label for name 2 of a company used general data\r\nCOMPANY_NAME2=2. n\\u00E9v\r\n\r\n#XFLD,20: W4: Label for first name of a person used general data\r\nFIRST_NAME=Ut\\u00F3n\\u00E9v\r\n\r\n#XFLD,20: W4: Label for last name of a person used general data\r\nLAST_NAME=Csal\\u00E1dn\\u00E9v\r\n\r\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nBIRTHDAY=Sz\\u00FClet\\u00E9si d\\u00E1tum\r\n\r\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nTITLE=C\\u00EDm\r\n\r\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nACADEMIC_TITLE=Tudom\\u00E1nyos fokozat\r\n\r\n#XFLD,20: W4: Label for mobile phone number used general data\r\nMOBILE=Mobil\r\n\r\n#XFLD,20: W4: Label for phone number used general data\r\nPHONE=Telefon\r\n\r\n#XFLD,20: W4: Label for e-mail used general data\r\nEMAIL=E-mail\r\n\r\n#XFLD,20: W4: Label for web site used general data\r\nWEBSITE=Webhely\r\n\r\n#XFLD,20: W4: Label for country used general data\r\nCOUNTRY=Orsz\\u00E1g\r\n\r\n#XFLD,20: W4: Label for region used general data\r\nREGION=R\\u00E9gi\\u00F3\r\n\r\n#XFLD,20: W4: Label for city used general data\r\nCITY=V\\u00E1ros\r\n\r\n#XFLD,20: W4: Label for postal code used general data\r\nPOSTAL_CODE=Ir\\u00E1ny\\u00EDt\\u00F3sz\\u00E1m\r\n\r\n#XFLD,20: W4: Label for street used general data\r\nSTREET=Utca\r\n\r\n#XFLD,10: W4: Label for house number used general data\r\nHOUSE_NUMBER=H\\u00E1zsz\\u00E1m\r\n\r\n#XFLD,15: W6: Label for ID used in Quotations\r\nID=Azonos\\u00EDt\\u00F3\r\n\r\n#XFLD,15: W6: Label for Amount used in Quotations\r\nAMOUNT=\\u00D6sszeg\r\n\r\n#XFLD,20: W6: Label for Expiration Date used in Quotations\r\nEXPIRATION_DATE=Lej\\u00E1rat d\\u00E1tuma\r\n\r\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\r\nDELIVERY_DATE=Sz\\u00E1ll\\u00EDt\\u00E1si d\\u00E1tum\r\n\r\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\r\nSALES_EMPLOYEE=\\u00C9rt\\u00E9kes\\u00EDt\\u0151\r\n\r\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\r\nATTRIBUTESET=Attrib\\u00FAtumcsoport\r\n\r\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\r\nATTRIBUTE=Attrib\\u00FAtumok\r\n\r\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\r\nVALUE=\\u00C9rt\\u00E9k\r\n\r\n#XBUT, 20: Button to create an Account\r\nBUTTON_ADD=Hozz\\u00E1ad\\u00E1s\r\n\r\n#XBUT, 20: Button to edit an Account\r\nBUTTON_EDIT=Feldolgoz\\u00E1s\r\n\r\n#XBUT, 20: Button to save changes\r\nBUTTON_SAVE=Ment\\u00E9s\r\n\r\n#XBUT, 20: Button to cancel changes\r\nBUTTON_CANCEL=M\\u00E9gse\r\n\r\n#XBUT, 30: Button which shows the personalization buttons\r\nBUTTON_SHOW_PERSONALIZATION=Szem\\u00E9lyre szab\\u00E1s megjelen\\u00EDt\\u00E9se\r\n\r\n#XBUT, 30: Button which hides the personalization buttons\r\nBUTTON_HIDE_PERSONALIZATION=Szem\\u00E9lyre szab\\u00E1s elrejt\\u00E9se\r\n\r\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_CONFIRM_CANCEL=Elv\\u00E9sz minden el nem mentett m\\u00F3dos\\u00EDt\\u00E1s. Szeretn\\u00E9 folytatni?\r\n\r\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\r\nMSG_CONFIRM_DELETE_CONTACT=A kapcsolattart\\u00F3 nem lesz hozz\\u00E1rendelve az \\u00FCgyf\\u00E9lhez. Folytatja?\r\n\r\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_SUCCESS=Fi\\u00F3k aktualiz\\u00E1lva\r\n\r\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_ERROR=Aktualiz\\u00E1l\\u00E1s sikertelen\r\n\r\n# XMSG : Account update succeeded\r\nMSG_CREATION_SUCCESS=Sz\\u00E1mla l\\u00E9trehozva\r\n\r\n# XMSG : Task creation succeeded\r\nMSG_TASK_CREATION_SUCCESS=Feladat l\\u00E9trej\\u00F6tt\r\n\r\n# XMSG : Contact creation failed\r\nMSG_CREATION_ERROR=L\\u00E9trehoz\\u00E1s sikertelen\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong country\r\nMSG_WRONG_COUNTRY_ERROR="{0}" orsz\\u00E1g nem l\\u00E9tezik\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong region\r\nMSG_WRONG_REGION_ERROR="{0}" r\\u00E9gi\\u00F3 nem l\\u00E9tezik az orsz\\u00E1gban\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong employee\r\nMSG_WRONG_EMPLOYEE_ERROR="{0}" dolgoz\\u00F3 nem l\\u00E9tezik.\r\n\r\n# XMSG: message that will be displayed, if the user has entered invalid website url\r\nMSG_WRONG_URL_ERROR=A megadott "{0}" URL \\u00E9rv\\u00E9nytelen.\r\n\r\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\r\nMSG_MANDATORY_FIELDS=Nincs kit\\u00F6ltve az \\u00F6sszes k\\u00F6telez\\u0151 mez\\u0151\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA=Az adatokat egy m\\u00E1sik felhaszn\\u00E1l\\u00F3 m\\u00F3dos\\u00EDtotta. Szeretn\\u00E9 fel\\u00FCl\\u00EDrni ezeket a m\\u00F3dos\\u00EDt\\u00E1sokat?\r\n\r\n# XMSG: message that will be displayed in case of conflicts during file renaming\r\nMSG_CONFLICTING_FILE_NAME=A f\\u00E1jl nev\\u00E9t egy m\\u00E1sik felhaszn\\u00E1l\\u00F3 m\\u00F3dos\\u00EDtotta. Szeretn\\u00E9 fel\\u00FCl\\u00EDrni ezt a m\\u00F3dos\\u00EDt\\u00E1st?\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA_WITH_REFRESH=Az adatokat egy m\\u00E1sik felhaszn\\u00E1l\\u00F3 m\\u00F3dos\\u00EDtotta. Ezek a m\\u00F3dos\\u00EDt\\u00E1sok most m\\u00E1r megjelennek az alkalmaz\\u00E1sban.\r\n\r\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\r\nMSG_NOT_IN_MAIN_CONTACT=Csak a fi\\u00F3khoz rendelt kapcsolattart\\u00F3k adatait l\\u00E1thatja\r\n\r\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\r\nMSG_EXCEEDING_FILE_NAME_LENGTH=A f\\u00E1jln\\u00E9v maximum 40 karaktert tartalmazhat.\r\n\r\n# XTOL, 20: tooltip shown on search result list for button to add an account"\r\nADD_ACCOUNT_TOOLTIP=Fi\\u00F3k hozz\\u00E1ad\\u00E1sa\r\n\r\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\r\nADD_MARKETING_ATTRIBUTE_TOOLTIP=Marketing attrib\\u00FAtum hozz\\u00E1ad\\u00E1sa\r\n\r\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\r\nADD_CONTACT_TOOLTIP=T\\u00E1rgyal\\u00F3partner hozz\\u00E1ad\\u00E1sa\r\n\r\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\r\nADD_APPOINTMENT_TOOLTIP=Id\\u0151pont hozz\\u00E1ad\\u00E1sa\r\n\r\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\r\nADD_TASK_TOOLTIP=Feladat hozz\\u00E1ad\\u00E1sa\r\n\r\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\r\nADD_OPPORTUNITY_TOOLTIP=Opportunity hozz\\u00E1ad\\u00E1sa\r\n',
	"cus/crm/myaccounts/i18n/i18n_it.properties":'# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XFLD, 30: Facet title for general Data\r\nGENERAL_DATA=Dati generali\r\n\r\n#XTIT, 40: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=I miei clienti\r\n\r\n#XTIT, 40: this is the title for the detail screen\r\nDETAIL_TITLE=Cliente\r\n\r\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\r\nREVENUE_CURRENT=Ricavi ad oggi\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\r\nREVENUE_CURRENT_TOOLTIP=Ricavi fino ad oggi (anno in corso)\r\n\r\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\r\nREVENUE_LAST=Ricavi anno scorso\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\r\nREVENUE_LAST_TOOLTIP=Ricavi anno scorso\r\n\r\n# XFLD, 30: Facet title for opportunities and label in facet general data\r\nOPPORTUNITIES=Opportunit\\u00E0\r\n\r\n#XFLD, 30: Facet title for leads\r\nLEADS=Leads\r\n\r\n#XFLD, 30: Facet title for tasks\r\nTASKS=Tasks\r\n\r\n#XFLD, 30: Facet title for appointments\r\nAPPOINTMENTS=Appuntamenti\r\n\r\n#XFLD, 30: Facet title for quotations\r\nQUOTATIONS=Offerte\r\n\r\n#XFLD, 30: Facet title for sales orders\r\nSALES_ORDERS=Ordini di vendita\r\n\r\n#XFLD, 30: W7: Facet title for marketing attributes\r\nMARKETINGATTRIBUTES=Attributi di marketing\r\n\r\n#XFLD, 30: W6: Title for popup with products\r\nPRODUCTS=Prodotti\r\n\r\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\r\nEMPLOYEE_RESPONSIBLE=Dipendente responsabile\r\n\r\n#XFLD, 30: Facet title for Attachments\r\nATTACHMENTS=Allegati\r\n\r\n#XFLD, 30: Facet title for Notes\r\nNOTES=Note\r\n\r\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\r\nNEW_NOTE=Nuova nota\r\n\r\n#XFLD, 30: Facet title for Contacts\r\nCONTACTS=Contatti\r\n\r\n#XFLD, 30: Label for Address in facet general data\r\nADDRESS=Indirizzo\r\n\r\n#XFLD, 30: Label for Opportunities in facet general data\r\nUNWEIGHTED_OPPORTUNITIES=Opportunit\\u00E0\r\n\r\n#XFLD, 30: Label for Rating in facet general data\r\nRATING=Classificazione\r\n\r\n# XFLD, 30: Label for Next contact in facet Appointments\r\nNEXT_APPOINTMENT=Appuntamento successivo\r\n\r\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\r\nLAST_APPOINTMENT=Ultimo appuntamento\r\n\r\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\r\nIMAGE=Immagine\r\n\r\n#XBUT, 20: Button to show the create actionsheet\r\nCREATE=Crea\r\n\r\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\r\nDISCUSS_ENTRY=Discuti in SAP Jam\r\n\r\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\r\nSHARE_ENTRY=Condividi in SAP Jam\r\n\r\n#XBUT, 20: Button to share the note\r\nDETAIL_BUTTON_SHARE=Condividi\r\n\r\n#XBUT, 20: Button to cancel sharing\r\nDETAIL_BUTTON_CANCEL=Annulla\r\n\r\n#XFLD,20: All accounts for filter\r\nALL_ACCOUNTS=Tutti i clienti\r\n\r\n#XFLD,35: All individual accounts for filter\r\nALL_INDIVIDUAL_ACCOUNTS=Tutti i clienti individuali\r\n\r\n#XFLD,35: All corporate accounts for filter\r\nALL_CORPORATE_ACCOUNTS=Tutti i clienti aziendali\r\n\r\n#XFLD,35: All group accounts for filter\r\nALL_ACCOUNT_GROUPS=Tutti i gruppi di clienti\r\n\r\n#XFLD,20: my account for filter\r\nMY_ACCOUNT=I miei clienti\r\n\r\n#XFLD,35: my individual accounts for filter\r\nMY_INDIVIDUAL_ACCOUNTS=I miei clienti individuali\r\n\r\n#XFLD,35: my corporate accounts for filter\r\nMY_CORPORATE_ACCOUNTS=I miei clienti aziendali\r\n\r\n#XFLD,35: my group accounts for filter\r\nMY_ACCOUNT_GROUPS=I miei gruppi di clienti\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nINDIVIDUAL_ACCOUNT=Cliente privato\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nCORPORATE_ACCOUNT=Cliente organizzazione\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nACCOUNT_GROUP=Gruppo di clienti\r\n\r\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\r\nSTARTING=Data di inizio\\: {0}\r\n\r\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\r\nCLOSING=Data di chiusura\\: {0}\r\n\r\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\r\nDUE=Scadenza\\: {0}\r\n\r\n#XFLD,20: All accounts for title\r\nALL_ACCOUNTS_TITLE=Tutti i clienti ({0})\r\n\r\n#XFLD,35: All individual accounts for title\r\nALL_INDIVIDUAL_ACCOUNTS_TITLE=Tutti i clienti individuali ({0})\r\n\r\n#XFLD,35: All corporate accounts for title\r\nALL_CORPORATE_ACCOUNTS_TITLE=Tutti i clienti aziendali ({0})\r\n\r\n#XFLD,35: All group accounts for title\r\nALL_ACCOUNT_GROUPS_TITLE=Tutti i gruppi di clienti ({0})\r\n\r\n#XFLD,20: my account for title\r\nMY_ACCOUNT_TITLE=I miei clienti ({0})\r\n\r\n#XFLD,35: my individual account for title\r\nMY_INDIVIDUAL_ACCOUNT_TITLE=I miei clienti individuali ({0})\r\n\r\n#XFLD,35: my corporate account for title.\r\nMY_CORPORATE_ACCOUNT_TITLE=I miei clienti aziendali ({0})\r\n\r\n#XFLD,35: my group account for title\r\nMY_ACCOUNT_GROUP_TITLE=I miei gruppi di clienti ({0})\r\n\r\n#XFLD,30: filtered by info\r\nFILTERED_BY=Filtrato in base a\\: {0}\r\n\r\n#XFLD,30: label, search for accounts\r\nSEARCH_ACCOUNTS=Cerca\r\n\r\n#XFLD,30: comma separator for location\r\nLOCATION={0}, {1}\r\n\r\n#XFLD: W4: Label for All day text in Appointments\r\nALL_DAY_EVENT=Tutto il giorno\r\n\r\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\r\nDURATION_MINUTE={0} min\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\r\nDURATION_HOUR={0} h\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\r\nDURATION_DAY={0} giorno\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\r\nDURATION_DAYS={0} giorni\r\n\r\n#XFLD: W4: Label for Private meeting\r\nPRIVATE=Privato\r\n\r\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\r\nSELECT_TRANSACTION_TYPE=Seleziona tipo di transazione\r\n\r\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\r\nNEW_TASK_INPUT_PLACEHOLDER=Nuovo task\r\n\r\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nNO_DATA_TEXT=Nessun dato\r\n\r\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nLOADING_TEXT=In caricamento...\r\n\r\n#XFLD,25: W4: Column label for name of contact person in contacts\r\nNAME=Nome\r\n\r\n#XFLD,25: W5: Column label for department of contact person in contacts\r\nDEPARTMENT=Reparto\r\n\r\n#XFLD,15: W6: Column label for actions of contact person in contacts\r\nACTIONS=Azioni\r\n\r\n#XFLD,25: W4: Column label for description of lead in Leads\r\nDESCRIPTION=Descrizione\r\n\r\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\r\nASSIGNED_TO=Attribuito a\r\n\r\n#XFLD,15: W4: Column label for end date of lead in Leads\r\nEND_DATE=Data di fine\r\n\r\n#XFLD,15: W4: Column label for qualification level of lead in Leads\r\nQUALIFICATION=Qualificazione\r\n\r\n#XFLD,15: W4: Column label for status of lead in Leads\r\nSTATUS=Stato\r\n\r\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\r\nMAIN_CONTACT=Contatto principale\r\n\r\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\r\nVOLUME=Volume\r\n\r\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\r\nPROBABILITY=Probabilit\\u00E0\r\n\r\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\r\nCLOSE_BY=Chiusura per\r\n\r\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \r\nVIEWS=Views\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\r\nCONTACT_TITLE=Contatto\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\r\nEMPLOYEE_TITLE=Dipendente\r\n\r\n#XTIT,20: W7: Title of pop-up used in confirm popup\r\nCONFIRM_TITLE=Conferma\r\n\r\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\r\nCOMPANY_NAME=Nome\r\n\r\n#XFLD,20: W4: Label for name 1 of a company used general data\r\nCOMPANY_NAME1=Nome 1\r\n\r\n#XFLD,20: W4: Label for name 2 of a company used general data\r\nCOMPANY_NAME2=Nome 2\r\n\r\n#XFLD,20: W4: Label for first name of a person used general data\r\nFIRST_NAME=Nome\r\n\r\n#XFLD,20: W4: Label for last name of a person used general data\r\nLAST_NAME=Cognome\r\n\r\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nBIRTHDAY=Data di nascita\r\n\r\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nTITLE=Titolo\r\n\r\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nACADEMIC_TITLE=Titolo accademico\r\n\r\n#XFLD,20: W4: Label for mobile phone number used general data\r\nMOBILE=Cellulare\r\n\r\n#XFLD,20: W4: Label for phone number used general data\r\nPHONE=Telefono\r\n\r\n#XFLD,20: W4: Label for e-mail used general data\r\nEMAIL=E-mail\r\n\r\n#XFLD,20: W4: Label for web site used general data\r\nWEBSITE=Sito Web\r\n\r\n#XFLD,20: W4: Label for country used general data\r\nCOUNTRY=Paese\r\n\r\n#XFLD,20: W4: Label for region used general data\r\nREGION=Regione\r\n\r\n#XFLD,20: W4: Label for city used general data\r\nCITY=Citt\\u00E0\r\n\r\n#XFLD,20: W4: Label for postal code used general data\r\nPOSTAL_CODE=Codice postale\r\n\r\n#XFLD,20: W4: Label for street used general data\r\nSTREET=Via\r\n\r\n#XFLD,10: W4: Label for house number used general data\r\nHOUSE_NUMBER=N. civico\r\n\r\n#XFLD,15: W6: Label for ID used in Quotations\r\nID=ID\r\n\r\n#XFLD,15: W6: Label for Amount used in Quotations\r\nAMOUNT=Importo\r\n\r\n#XFLD,20: W6: Label for Expiration Date used in Quotations\r\nEXPIRATION_DATE=Data di scadenza\r\n\r\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\r\nDELIVERY_DATE=Data di consegna\r\n\r\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\r\nSALES_EMPLOYEE=Addetto alle vendite\r\n\r\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\r\nATTRIBUTESET=Set attributi\r\n\r\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\r\nATTRIBUTE=Attributo\r\n\r\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\r\nVALUE=Valore\r\n\r\n#XBUT, 20: Button to create an Account\r\nBUTTON_ADD=Aggiungi\r\n\r\n#XBUT, 20: Button to edit an Account\r\nBUTTON_EDIT=Elabora\r\n\r\n#XBUT, 20: Button to save changes\r\nBUTTON_SAVE=Salva\r\n\r\n#XBUT, 20: Button to cancel changes\r\nBUTTON_CANCEL=Annulla\r\n\r\n#XBUT, 30: Button which shows the personalization buttons\r\nBUTTON_SHOW_PERSONALIZATION=Visualizza personalizzazione\r\n\r\n#XBUT, 30: Button which hides the personalization buttons\r\nBUTTON_HIDE_PERSONALIZATION=Nascondi personalizzazione\r\n\r\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_CONFIRM_CANCEL=Le modifiche non salvate andranno perse. Continuare?\r\n\r\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\r\nMSG_CONFIRM_DELETE_CONTACT=L\'attribuzione del contatto con il cliente sar\\u00E0 annullata. Proseguire?\r\n\r\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_SUCCESS=Cliente aggiornato\r\n\r\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_ERROR=Aggiornamento non riuscito\r\n\r\n# XMSG : Account update succeeded\r\nMSG_CREATION_SUCCESS=Cliente creato\r\n\r\n# XMSG : Task creation succeeded\r\nMSG_TASK_CREATION_SUCCESS=Task creato\r\n\r\n# XMSG : Contact creation failed\r\nMSG_CREATION_ERROR=Creazione non riuscita\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong country\r\nMSG_WRONG_COUNTRY_ERROR=Il paese "{0}" non esiste\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong region\r\nMSG_WRONG_REGION_ERROR=La regione "{0}" non esiste per il paese\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong employee\r\nMSG_WRONG_EMPLOYEE_ERROR=Il dipendente "{0}" non esiste\r\n\r\n# XMSG: message that will be displayed, if the user has entered invalid website url\r\nMSG_WRONG_URL_ERROR=L\'\'URL "{0}" inserito non \\u00E8 valido.\r\n\r\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\r\nMSG_MANDATORY_FIELDS=Non tutti i campi obbligatori sono stati alimentati\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA=I dati sono stati modificati da un altro utente. Vuoi sovrascrivere le modifiche dell\'altro utente con le tue?\r\n\r\n# XMSG: message that will be displayed in case of conflicts during file renaming\r\nMSG_CONFLICTING_FILE_NAME=Il nome file \\u00E8 stato modificato da un altro utente. Vuoi sovrascrivere le modifiche dell\'altro utente con le tue?\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA_WITH_REFRESH=Dati modificati da un altro utente. Queste modifiche non compariranno nell\'app.\r\n\r\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\r\nMSG_NOT_IN_MAIN_CONTACT=Possibile visualizzare solo i dettagli dei contatti attribuiti a questo account\r\n\r\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\r\nMSG_EXCEEDING_FILE_NAME_LENGTH=Il tuo nome file non pu\\u00F2 superare i 40 caratteri.\r\n\r\n# XTOL, 20: tooltip shown on search result list for button to add an account"\r\n\r\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\r\n\r\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\r\n\r\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\r\n\r\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\r\n\r\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\r\n',
	"cus/crm/myaccounts/i18n/i18n_iw.properties":'# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XFLD, 30: Facet title for general Data\r\nGENERAL_DATA=\\u05E0\\u05EA\\u05D5\\u05E0\\u05D9\\u05DD \\u05DB\\u05DC\\u05DC\\u05D9\\u05D9\\u05DD\r\n\r\n#XTIT, 40: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=\\u05D4\\u05DC\\u05E7\\u05D5\\u05D7\\u05D5\\u05EA \\u05E9\\u05DC\\u05D9\r\n\r\n#XTIT, 40: this is the title for the detail screen\r\nDETAIL_TITLE=\\u05DC\\u05E7\\u05D5\\u05D7\r\n\r\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\r\nREVENUE_CURRENT=\\u05D4\\u05DB.\\u05E2.\\u05D4\\u05D9\\u05D5\\u05DD \\u05D1.\\u05D4\\u05E0\\u05D5\\u05DB\\u05D7.\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\r\nREVENUE_CURRENT_TOOLTIP=\\u05D4\\u05DB\\u05E0\\u05E1\\u05D5\\u05EA \\u05E2\\u05D3 \\u05D4\\u05D9\\u05D5\\u05DD \\u05D1\\u05E9\\u05E0\\u05D4 \\u05D4\\u05E0\\u05D5\\u05DB\\u05D7\\u05D9\\u05EA\r\n\r\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\r\nREVENUE_LAST=\\u05D4\\u05DB\\u05E0\\u05E1\\u05D5\\u05EA \\u05D1\\u05E9\\u05E0\\u05D4 \\u05D4\\u05E7\\u05D5\\u05D3\\u05DE\\u05EA\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\r\nREVENUE_LAST_TOOLTIP=\\u05D4\\u05DB\\u05E0\\u05E1\\u05D5\\u05EA \\u05D1\\u05E9\\u05E0\\u05D4 \\u05D4\\u05E7\\u05D5\\u05D3\\u05DE\\u05EA\r\n\r\n# XFLD, 30: Facet title for opportunities and label in facet general data\r\nOPPORTUNITIES=\\u05D4\\u05D6\\u05D3\\u05DE\\u05E0\\u05D5\\u05D9\\u05D5\\u05EA\r\n\r\n#XFLD, 30: Facet title for leads\r\nLEADS=\\u05E4\\u05E8\\u05D9\\u05D8\\u05D9 Lead\r\n\r\n#XFLD, 30: Facet title for tasks\r\nTASKS=\\u05DE\\u05E9\\u05D9\\u05DE\\u05D5\\u05EA\r\n\r\n#XFLD, 30: Facet title for appointments\r\nAPPOINTMENTS=\\u05E4\\u05D2\\u05D9\\u05E9\\u05D5\\u05EA\r\n\r\n#XFLD, 30: Facet title for quotations\r\nQUOTATIONS=\\u05D4\\u05E6\\u05E2\\u05D5\\u05EA \\u05DE\\u05D7\\u05D9\\u05E8\r\n\r\n#XFLD, 30: Facet title for sales orders\r\nSALES_ORDERS=\\u05D4\\u05D6\\u05DE\\u05E0\\u05D5\\u05EA \\u05DC\\u05E7\\u05D5\\u05D7\r\n\r\n#XFLD, 30: W7: Facet title for marketing attributes\r\nMARKETINGATTRIBUTES=\\u05EA\\u05DB\\u05D5\\u05E0\\u05D5\\u05EA \\u05E9\\u05D9\\u05D5\\u05D5\\u05E7\r\n\r\n#XFLD, 30: W6: Title for popup with products\r\nPRODUCTS=\\u05DE\\u05D5\\u05E6\\u05E8\\u05D9\\u05DD\r\n\r\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\r\nEMPLOYEE_RESPONSIBLE=\\u05E2\\u05D5\\u05D1\\u05D3 \\u05D0\\u05D7\\u05E8\\u05D0\\u05D9\r\n\r\n#XFLD, 30: Facet title for Attachments\r\nATTACHMENTS=\\u05E7\\u05D1\\u05E6\\u05D9\\u05DD \\u05DE\\u05E6\\u05D5\\u05E8\\u05E4\\u05D9\\u05DD\r\n\r\n#XFLD, 30: Facet title for Notes\r\nNOTES=\\u05D4\\u05E2\\u05E8\\u05D5\\u05EA\r\n\r\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\r\nNEW_NOTE=\\u05D4\\u05E2\\u05E8\\u05D4 \\u05D7\\u05D3\\u05E9\\u05D4\r\n\r\n#XFLD, 30: Facet title for Contacts\r\nCONTACTS=\\u05D0\\u05E0\\u05E9\\u05D9 \\u05E7\\u05E9\\u05E8\r\n\r\n#XFLD, 30: Label for Address in facet general data\r\nADDRESS=\\u05DB\\u05EA\\u05D5\\u05D1\\u05EA\r\n\r\n#XFLD, 30: Label for Opportunities in facet general data\r\nUNWEIGHTED_OPPORTUNITIES=\\u05D4\\u05D6\\u05D3\\u05DE\\u05E0\\u05D5\\u05D9\\u05D5\\u05EA\r\n\r\n#XFLD, 30: Label for Rating in facet general data\r\nRATING=\\u05D3\\u05D9\\u05E8\\u05D5\\u05D2\r\n\r\n# XFLD, 30: Label for Next contact in facet Appointments\r\nNEXT_APPOINTMENT=\\u05D4\\u05E4\\u05D2\\u05D9\\u05E9\\u05D4 \\u05D4\\u05D1\\u05D0\\u05D4\r\n\r\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\r\nLAST_APPOINTMENT=\\u05E4\\u05D2\\u05D9\\u05E9\\u05D4 \\u05D0\\u05D7\\u05E8\\u05D5\\u05E0\\u05D4\r\n\r\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\r\nIMAGE=\\u05EA\\u05DE\\u05D5\\u05E0\\u05D4\r\n\r\n#XBUT, 20: Button to show the create actionsheet\r\nCREATE=\\u05E6\\u05D5\\u05E8\r\n\r\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\r\nDISCUSS_ENTRY=\\u05D3\\u05D5\\u05DF \\u05D1-SAP Jam\r\n\r\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\r\nSHARE_ENTRY=\\u05E9\\u05EA\\u05E3 \\u05D1-SAP Jam\r\n\r\n#XBUT, 20: Button to share the note\r\nDETAIL_BUTTON_SHARE=\\u05E9\\u05EA\\u05E3\r\n\r\n#XBUT, 20: Button to cancel sharing\r\nDETAIL_BUTTON_CANCEL=\\u05D1\\u05D8\\u05DC\r\n\r\n#XFLD,20: All accounts for filter\r\nALL_ACCOUNTS=\\u05DB\\u05DC \\u05D4\\u05DC\\u05E7\\u05D5\\u05D7\\u05D5\\u05EA\r\n\r\n#XFLD,35: All individual accounts for filter\r\nALL_INDIVIDUAL_ACCOUNTS=\\u05DB\\u05DC \\u05D4\\u05DC\\u05E7\\u05D5\\u05D7\\u05D5\\u05EA \\u05D4\\u05E4\\u05E8\\u05D8\\u05D9\\u05D9\\u05DD\r\n\r\n#XFLD,35: All corporate accounts for filter\r\nALL_CORPORATE_ACCOUNTS=\\u05DB\\u05DC \\u05D4\\u05DC\\u05E7\\u05D5\\u05D7\\u05D5\\u05EA \\u05D4\\u05E2\\u05E1\\u05E7\\u05D9\\u05D9\\u05DD\r\n\r\n#XFLD,35: All group accounts for filter\r\nALL_ACCOUNT_GROUPS=\\u05DB\\u05DC \\u05E7\\u05D1\\u05D5\\u05E6\\u05D5\\u05EA \\u05D4\\u05DC\\u05E7\\u05D5\\u05D7\\u05D5\\u05EA\r\n\r\n#XFLD,20: my account for filter\r\nMY_ACCOUNT=\\u05D4\\u05DC\\u05E7\\u05D5\\u05D7\\u05D5\\u05EA \\u05E9\\u05DC\\u05D9\r\n\r\n#XFLD,35: my individual accounts for filter\r\nMY_INDIVIDUAL_ACCOUNTS=\\u05D4\\u05DC\\u05E7\\u05D5\\u05D7\\u05D5\\u05EA \\u05D4\\u05E4\\u05E8\\u05D8\\u05D9\\u05D9\\u05DD \\u05E9\\u05DC\\u05D9\r\n\r\n#XFLD,35: my corporate accounts for filter\r\nMY_CORPORATE_ACCOUNTS=\\u05DB\\u05DC \\u05D4\\u05DC\\u05E7\\u05D5\\u05D7\\u05D5\\u05EA \\u05D4\\u05E2\\u05E1\\u05E7\\u05D9\\u05D9\\u05DD \\u05E9\\u05DC\\u05D9\r\n\r\n#XFLD,35: my group accounts for filter\r\nMY_ACCOUNT_GROUPS=\\u05DB\\u05DC \\u05E7\\u05D1\\u05D5\\u05E6\\u05D5\\u05EA \\u05D4\\u05DC\\u05E7\\u05D5\\u05D7\\u05D5\\u05EA \\u05E9\\u05DC\\u05D9\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nINDIVIDUAL_ACCOUNT=\\u05DC\\u05E7\\u05D5\\u05D7 \\u05E4\\u05E8\\u05D8\\u05D9\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nCORPORATE_ACCOUNT=\\u05DC\\u05E7\\u05D5\\u05D7 \\u05E2\\u05E1\\u05E7\\u05D9\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nACCOUNT_GROUP=\\u05E7\\u05D1\\u05D5\\u05E6\\u05EA \\u05DC\\u05E7\\u05D5\\u05D7\\u05D5\\u05EA\r\n\r\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\r\nSTARTING=\\u05EA\\u05D0\\u05E8\\u05D9\\u05DA \\u05D4\\u05EA\\u05D7\\u05DC\\u05D4\\: {0}\r\n\r\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\r\nCLOSING=\\u05EA\\u05D0\\u05E8\\u05D9\\u05DA \\u05E1\\u05D2\\u05D9\\u05E8\\u05D4\\: {0}\r\n\r\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\r\nDUE=\\u05EA\\u05D0\\u05E8\\u05D9\\u05DA \\u05D9\\u05E2\\u05D3\\: {0}\r\n\r\n#XFLD,20: All accounts for title\r\nALL_ACCOUNTS_TITLE=\\u05DB\\u05DC \\u05D4\\u05DC\\u05E7\\u05D5\\u05D7\\u05D5\\u05EA ({0})\r\n\r\n#XFLD,35: All individual accounts for title\r\nALL_INDIVIDUAL_ACCOUNTS_TITLE=\\u05DB\\u05DC \\u05D4\\u05DC\\u05E7\\u05D5\\u05D7\\u05D5\\u05EA \\u05D4\\u05E4\\u05E8\\u05D8\\u05D9\\u05D9\\u05DD ({0})\r\n\r\n#XFLD,35: All corporate accounts for title\r\nALL_CORPORATE_ACCOUNTS_TITLE=\\u05DB\\u05DC \\u05D4\\u05DC\\u05E7\\u05D5\\u05D7\\u05D5\\u05EA \\u05D4\\u05E2\\u05E1\\u05E7\\u05D9\\u05D9\\u05DD ({0})\r\n\r\n#XFLD,35: All group accounts for title\r\nALL_ACCOUNT_GROUPS_TITLE=\\u05DB\\u05DC \\u05E7\\u05D1\\u05D5\\u05E6\\u05D5\\u05EA \\u05D4\\u05DC\\u05E7\\u05D5\\u05D7\\u05D5\\u05EA ({0})\r\n\r\n#XFLD,20: my account for title\r\nMY_ACCOUNT_TITLE=\\u05D4\\u05DC\\u05E7\\u05D5\\u05D7\\u05D5\\u05EA \\u05E9\\u05DC\\u05D9 ({0})\r\n\r\n#XFLD,35: my individual account for title\r\nMY_INDIVIDUAL_ACCOUNT_TITLE=\\u05D4\\u05DC\\u05E7\\u05D5\\u05D7\\u05D5\\u05EA \\u05D4\\u05E4\\u05E8\\u05D8\\u05D9\\u05D9\\u05DD \\u05E9\\u05DC\\u05D9 ({0})\r\n\r\n#XFLD,35: my corporate account for title.\r\nMY_CORPORATE_ACCOUNT_TITLE=\\u05D4\\u05DC\\u05E7\\u05D5\\u05D7\\u05D5\\u05EA \\u05D4\\u05E2\\u05E1\\u05E7\\u05D9\\u05D9\\u05DD \\u05E9\\u05DC\\u05D9 ({0})\r\n\r\n#XFLD,35: my group account for title\r\nMY_ACCOUNT_GROUP_TITLE=\\u05DB\\u05DC \\u05E7\\u05D1\\u05D5\\u05E6\\u05D5\\u05EA \\u05D4\\u05DC\\u05E7\\u05D5\\u05D7\\u05D5\\u05EA \\u05E9\\u05DC\\u05D9 ({0})\r\n\r\n#XFLD,30: filtered by info\r\nFILTERED_BY=\\u05E1\\u05D5\\u05E0\\u05DF \\u05DC\\u05E4\\u05D9\\: {0}\r\n\r\n#XFLD,30: label, search for accounts\r\nSEARCH_ACCOUNTS=\\u05D7\\u05E4\\u05E9\r\n\r\n#XFLD,30: comma separator for location\r\nLOCATION={0}, {1}\r\n\r\n#XFLD: W4: Label for All day text in Appointments\r\nALL_DAY_EVENT=\\u05DB\\u05DC \\u05D4\\u05D9\\u05D5\\u05DD\r\n\r\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\r\nDURATION_MINUTE={0} \\u05D3\\u05E7\\u05D5\\u05EA\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\r\nDURATION_HOUR={0} \\u05E9\\u05E2\\u05D5\\u05EA\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\r\nDURATION_DAY=\\u05D9\\u05D5\\u05DD {0} \r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\r\nDURATION_DAYS={0} \\u05D9\\u05DE\\u05D9\\u05DD\r\n\r\n#XFLD: W4: Label for Private meeting\r\nPRIVATE=\\u05E4\\u05E8\\u05D8\\u05D9\r\n\r\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\r\nSELECT_TRANSACTION_TYPE=\\u05D1\\u05D7\\u05E8 \\u05E1\\u05D5\\u05D2 \\u05EA\\u05E0\\u05D5\\u05E2\\u05D4\r\n\r\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\r\nNEW_TASK_INPUT_PLACEHOLDER=\\u05DE\\u05E9\\u05D9\\u05DE\\u05D4 \\u05D7\\u05D3\\u05E9\\u05D4\r\n\r\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nNO_DATA_TEXT=\\u05D0\\u05D9\\u05DF \\u05E0\\u05EA\\u05D5\\u05E0\\u05D9\\u05DD\r\n\r\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nLOADING_TEXT=\\u05D8\\u05D5\\u05E2\\u05DF...\r\n\r\n#XFLD,25: W4: Column label for name of contact person in contacts\r\nNAME=\\u05E9\\u05DD\r\n\r\n#XFLD,25: W5: Column label for department of contact person in contacts\r\nDEPARTMENT=\\u05DE\\u05D7\\u05DC\\u05E7\\u05D4\r\n\r\n#XFLD,15: W6: Column label for actions of contact person in contacts\r\nACTIONS=\\u05E4\\u05E2\\u05D5\\u05DC\\u05D5\\u05EA\r\n\r\n#XFLD,25: W4: Column label for description of lead in Leads\r\nDESCRIPTION=\\u05EA\\u05D9\\u05D0\\u05D5\\u05E8\r\n\r\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\r\nASSIGNED_TO=\\u05DE\\u05D5\\u05E7\\u05E6\\u05D4 \\u05DC-\r\n\r\n#XFLD,15: W4: Column label for end date of lead in Leads\r\nEND_DATE=\\u05EA\\u05D0\\u05E8\\u05D9\\u05DA \\u05E1\\u05D9\\u05D5\\u05DD\r\n\r\n#XFLD,15: W4: Column label for qualification level of lead in Leads\r\nQUALIFICATION=\\u05D4\\u05E2\\u05E8\\u05DB\\u05D4\r\n\r\n#XFLD,15: W4: Column label for status of lead in Leads\r\nSTATUS=\\u05E1\\u05D8\\u05D0\\u05D8\\u05D5\\u05E1\r\n\r\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\r\nMAIN_CONTACT=\\u05D0\\u05D9\\u05E9 \\u05E7\\u05E9\\u05E8 \\u05E8\\u05D0\\u05E9\\u05D9\r\n\r\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\r\nVOLUME=\\u05E0\\u05E4\\u05D7\r\n\r\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\r\nPROBABILITY=\\u05D4\\u05E1\\u05EA\\u05D1\\u05E8\\u05D5\\u05EA\r\n\r\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\r\nCLOSE_BY=\\u05E1\\u05D2\\u05D5\\u05E8 \\u05E2\\u05D3\r\n\r\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \r\nVIEWS=\\u05EA\\u05E6\\u05D5\\u05D2\\u05D5\\u05EA\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\r\nCONTACT_TITLE=\\u05D0\\u05D9\\u05E9 \\u05E7\\u05E9\\u05E8\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\r\nEMPLOYEE_TITLE=\\u05E2\\u05D5\\u05D1\\u05D3\r\n\r\n#XTIT,20: W7: Title of pop-up used in confirm popup\r\nCONFIRM_TITLE=\\u05D0\\u05E9\\u05E8\r\n\r\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\r\nCOMPANY_NAME=\\u05E9\\u05DD\r\n\r\n#XFLD,20: W4: Label for name 1 of a company used general data\r\nCOMPANY_NAME1=\\u05E9\\u05DD 1\r\n\r\n#XFLD,20: W4: Label for name 2 of a company used general data\r\nCOMPANY_NAME2=\\u05E9\\u05DD 2\r\n\r\n#XFLD,20: W4: Label for first name of a person used general data\r\nFIRST_NAME=\\u05E9\\u05DD \\u05E4\\u05E8\\u05D8\\u05D9\r\n\r\n#XFLD,20: W4: Label for last name of a person used general data\r\nLAST_NAME=\\u05E9\\u05DD \\u05DE\\u05E9\\u05E4\\u05D7\\u05D4\r\n\r\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nBIRTHDAY=\\u05EA\\u05D0\\u05E8\\u05D9\\u05DA \\u05DC\\u05D9\\u05D3\\u05D4\r\n\r\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nTITLE=\\u05DB\\u05D5\\u05EA\\u05E8\\u05EA\r\n\r\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nACADEMIC_TITLE=\\u05EA\\u05D5\\u05D0\\u05E8 \\u05D0\\u05E7\\u05D3\\u05DE\\u05D9\r\n\r\n#XFLD,20: W4: Label for mobile phone number used general data\r\nMOBILE=\\u05D8\\u05DC\\u05E4\\u05D5\\u05DF \\u05E0\\u05D9\\u05D9\\u05D3\r\n\r\n#XFLD,20: W4: Label for phone number used general data\r\nPHONE=\\u05D8\\u05DC\\u05E4\\u05D5\\u05DF\r\n\r\n#XFLD,20: W4: Label for e-mail used general data\r\nEMAIL=\\u05D3\\u05D5\\u05D0"\\u05DC\r\n\r\n#XFLD,20: W4: Label for web site used general data\r\nWEBSITE=\\u05D0\\u05EA\\u05E8 \\u05D0\\u05D9\\u05E0\\u05D8\\u05E8\\u05E0\\u05D8\r\n\r\n#XFLD,20: W4: Label for country used general data\r\nCOUNTRY=\\u05DE\\u05D3\\u05D9\\u05E0\\u05D4\r\n\r\n#XFLD,20: W4: Label for region used general data\r\nREGION=\\u05D0\\u05D6\\u05D5\\u05E8\r\n\r\n#XFLD,20: W4: Label for city used general data\r\nCITY=\\u05E2\\u05D9\\u05E8\r\n\r\n#XFLD,20: W4: Label for postal code used general data\r\nPOSTAL_CODE=\\u05DE\\u05D9\\u05E7\\u05D5\\u05D3\r\n\r\n#XFLD,20: W4: Label for street used general data\r\nSTREET=\\u05E8\\u05D7\\u05D5\\u05D1\r\n\r\n#XFLD,10: W4: Label for house number used general data\r\nHOUSE_NUMBER=\\u05DE\\u05E1\\u05E4\\u05E8 \\u05D1\\u05D9\\u05EA\r\n\r\n#XFLD,15: W6: Label for ID used in Quotations\r\nID=\\u05D6\\u05D9\\u05D4\\u05D5\\u05D9\r\n\r\n#XFLD,15: W6: Label for Amount used in Quotations\r\nAMOUNT=\\u05E1\\u05DB\\u05D5\\u05DD\r\n\r\n#XFLD,20: W6: Label for Expiration Date used in Quotations\r\nEXPIRATION_DATE=\\u05EA\\u05D0\\u05E8\\u05D9\\u05DA \\u05EA\\u05E4\\u05D5\\u05D2\\u05D4\r\n\r\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\r\nDELIVERY_DATE=\\u05EA\\u05D0\\u05E8\\u05D9\\u05DA \\u05D0\\u05E1\\u05E4\\u05E7\\u05D4\r\n\r\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\r\nSALES_EMPLOYEE=\\u05E2\\u05D5\\u05D1\\u05D3 \\u05DE\\u05DB\\u05D9\\u05E8\\u05D5\\u05EA\r\n\r\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\r\nATTRIBUTESET=\\u05E1\\u05D8 \\u05EA\\u05DB\\u05D5\\u05E0\\u05D5\\u05EA\r\n\r\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\r\nATTRIBUTE=\\u05EA\\u05DB\\u05D5\\u05E0\\u05D4\r\n\r\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\r\nVALUE=\\u05E2\\u05E8\\u05DA\r\n\r\n#XBUT, 20: Button to create an Account\r\nBUTTON_ADD=\\u05D4\\u05D5\\u05E1\\u05E3\r\n\r\n#XBUT, 20: Button to edit an Account\r\nBUTTON_EDIT=\\u05E2\\u05E8\\u05D5\\u05DA\r\n\r\n#XBUT, 20: Button to save changes\r\nBUTTON_SAVE=\\u05E9\\u05DE\\u05D5\\u05E8\r\n\r\n#XBUT, 20: Button to cancel changes\r\nBUTTON_CANCEL=\\u05D1\\u05D8\\u05DC\r\n\r\n#XBUT, 30: Button which shows the personalization buttons\r\nBUTTON_SHOW_PERSONALIZATION=\\u05D4\\u05E6\\u05D2 \\u05D4\\u05EA\\u05D0\\u05DE\\u05D4 \\u05D0\\u05D9\\u05E9\\u05D9\\u05EA\r\n\r\n#XBUT, 30: Button which hides the personalization buttons\r\nBUTTON_HIDE_PERSONALIZATION=\\u05D4\\u05E1\\u05EA\\u05E8 \\u05D4\\u05EA\\u05D0\\u05DE\\u05D4 \\u05D0\\u05D9\\u05E9\\u05D9\\u05EA\r\n\r\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_CONFIRM_CANCEL=\\u05DB\\u05DC \\u05D4\\u05E9\\u05D9\\u05E0\\u05D5\\u05D9\\u05D9\\u05DD \\u05E9\\u05DC\\u05D0 \\u05E0\\u05E9\\u05DE\\u05E8\\u05D5 \\u05D9\\u05D0\\u05D1\\u05D3\\u05D5. \\u05D4\\u05D0\\u05DD \\u05D1\\u05E8\\u05E6\\u05D5\\u05E0\\u05DA \\u05DC\\u05D4\\u05DE\\u05E9\\u05D9\\u05DA?\r\n\r\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\r\nMSG_CONFIRM_DELETE_CONTACT=\\u05EA\\u05D5\\u05E1\\u05E8 \\u05D4\\u05E7\\u05E6\\u05D0\\u05EA \\u05D0\\u05D9\\u05E9 \\u05D4\\u05E7\\u05E9\\u05E8 \\u05DE\\u05D4\\u05DC\\u05E7\\u05D5\\u05D7. \\u05D4\\u05D0\\u05DD \\u05D1\\u05E8\\u05E6\\u05D5\\u05E0\\u05DA \\u05DC\\u05D4\\u05DE\\u05E9\\u05D9\\u05DA?\r\n\r\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_SUCCESS=\\u05D4\\u05DC\\u05E7\\u05D5\\u05D7 \\u05E2\\u05D5\\u05D3\\u05DB\\u05DF\r\n\r\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_ERROR=\\u05E2\\u05D3\\u05DB\\u05D5\\u05DF \\u05E0\\u05DB\\u05E9\\u05DC\r\n\r\n# XMSG : Account update succeeded\r\nMSG_CREATION_SUCCESS=\\u05D4\\u05DC\\u05E7\\u05D5\\u05D7 \\u05E0\\u05D5\\u05E6\\u05E8\r\n\r\n# XMSG : Task creation succeeded\r\nMSG_TASK_CREATION_SUCCESS=\\u05DE\\u05E9\\u05D9\\u05DE\\u05D4 \\u05E0\\u05D5\\u05E6\\u05E8\\u05D4\r\n\r\n# XMSG : Contact creation failed\r\nMSG_CREATION_ERROR=\\u05D9\\u05E6\\u05D9\\u05E8\\u05D4 \\u05E0\\u05DB\\u05E9\\u05DC\\u05D4\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong country\r\nMSG_WRONG_COUNTRY_ERROR=\\u05D4\\u05DE\\u05D3\\u05D9\\u05E0\\u05D4 "{0}" \\u05DC\\u05D0 \\u05E7\\u05D9\\u05D9\\u05DE\\u05EA\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong region\r\nMSG_WRONG_REGION_ERROR=\\u05D4\\u05D0\\u05D6\\u05D5\\u05E8 "{0}" \\u05DC\\u05D0 \\u05E7\\u05D9\\u05D9\\u05DD \\u05E2\\u05D1\\u05D5\\u05E8 \\u05D4\\u05DE\\u05D3\\u05D9\\u05E0\\u05D4\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong employee\r\nMSG_WRONG_EMPLOYEE_ERROR=\\u05D4\\u05E2\\u05D5\\u05D1\\u05D3 "{0}" \\u05DC\\u05D0 \\u05E7\\u05D9\\u05D9\\u05DD.\r\n\r\n# XMSG: message that will be displayed, if the user has entered invalid website url\r\nMSG_WRONG_URL_ERROR=\\u05DB\\u05EA\\u05D5\\u05D1\\u05EA \\u05D4-URL \\u05E9\\u05D4\\u05D5\\u05D6\\u05E0\\u05D4 "{0}" \\u05DC\\u05D0 \\u05D7\\u05D5\\u05E7\\u05D9\\u05EA.\r\n\r\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\r\nMSG_MANDATORY_FIELDS=\\u05DC\\u05D0 \\u05DB\\u05DC \\u05E9\\u05D3\\u05D5\\u05EA \\u05D4\\u05D7\\u05D5\\u05D1\\u05D4 \\u05DE\\u05D5\\u05DC\\u05D0\\u05D5\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA=\\u05D4\\u05E0\\u05EA\\u05D5\\u05E0\\u05D9\\u05DD \\u05E9\\u05D5\\u05E0\\u05D5 \\u05E2\\u05DC-\\u05D9\\u05D3\\u05D9 \\u05DE\\u05E9\\u05EA\\u05DE\\u05E9 \\u05D0\\u05D7\\u05E8. \\u05D4\\u05D0\\u05DD \\u05D1\\u05E8\\u05E6\\u05D5\\u05E0\\u05DA \\u05DC\\u05E9\\u05DB\\u05EA\\u05D1 \\u05D0\\u05EA \\u05D4\\u05E9\\u05D9\\u05E0\\u05D5\\u05D9\\u05D9\\u05DD \\u05E9\\u05DC \\u05D4\\u05DE\\u05E9\\u05EA\\u05DE\\u05E9 \\u05D5\\u05DC\\u05E8\\u05E9\\u05D5\\u05DD \\u05D0\\u05EA \\u05D4\\u05E9\\u05D9\\u05E0\\u05D5\\u05D9\\u05D9\\u05DD \\u05E9\\u05DC\\u05DA?\r\n\r\n# XMSG: message that will be displayed in case of conflicts during file renaming\r\nMSG_CONFLICTING_FILE_NAME=\\u05E9\\u05DD \\u05D4\\u05E7\\u05D5\\u05D1\\u05E5 \\u05E9\\u05D5\\u05E0\\u05D4 \\u05E2\\u05DC-\\u05D9\\u05D3\\u05D9 \\u05DE\\u05E9\\u05EA\\u05DE\\u05E9 \\u05D0\\u05D7\\u05E8. \\u05D4\\u05D0\\u05DD \\u05D1\\u05E8\\u05E6\\u05D5\\u05E0\\u05DA \\u05DC\\u05E9\\u05DB\\u05EA\\u05D1 \\u05D0\\u05EA \\u05D4\\u05E9\\u05D9\\u05E0\\u05D5\\u05D9\\u05D9\\u05DD \\u05E9\\u05DC \\u05D4\\u05DE\\u05E9\\u05EA\\u05DE\\u05E9 \\u05D5\\u05DC\\u05E8\\u05E9\\u05D5\\u05DD \\u05D0\\u05EA \\u05D4\\u05E9\\u05D9\\u05E0\\u05D5\\u05D9\\u05D9\\u05DD \\u05E9\\u05DC\\u05DA?\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA_WITH_REFRESH=\\u05D4\\u05E0\\u05EA\\u05D5\\u05E0\\u05D9\\u05DD \\u05E9\\u05D5\\u05E0\\u05D5 \\u05E2\\u05DC-\\u05D9\\u05D3\\u05D9 \\u05DE\\u05E9\\u05EA\\u05DE\\u05E9 \\u05D0\\u05D7\\u05E8. \\u05E9\\u05D9\\u05E0\\u05D5\\u05D9\\u05D9\\u05DD \\u05D0\\u05DC\\u05D4 \\u05DC\\u05D0 \\u05D5\\u05D9\\u05E4\\u05D9\\u05E2\\u05D5 \\u05D1\\u05D9\\u05D9\\u05E9\\u05D5\\u05DD\r\n\r\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\r\nMSG_NOT_IN_MAIN_CONTACT=\\u05EA\\u05D5\\u05DB\\u05DC \\u05DC\\u05D4\\u05E6\\u05D9\\u05D2 \\u05E8\\u05E7 \\u05D0\\u05EA \\u05D4\\u05E4\\u05E8\\u05D8\\u05D9\\u05DD \\u05E9\\u05DC \\u05D0\\u05E0\\u05E9\\u05D9 \\u05D4\\u05E7\\u05E9\\u05E8 \\u05D4\\u05DE\\u05D5\\u05E7\\u05E6\\u05D9\\u05DD \\u05DC\\u05DC\\u05E7\\u05D5\\u05D7 \\u05D6\\u05D4\r\n\r\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\r\nMSG_EXCEEDING_FILE_NAME_LENGTH=\\u05E9\\u05DD \\u05D4\\u05E7\\u05D5\\u05D1\\u05E5 \\u05E9\\u05DC\\u05DA \\u05D9\\u05DB\\u05D5\\u05DC \\u05DC\\u05D4\\u05DB\\u05D9\\u05DC \\u05E2\\u05D3 40 \\u05EA\\u05D5\\u05D5\\u05D9\\u05DD.\r\n\r\n# XTOL, 20: tooltip shown on search result list for button to add an account"\r\n\r\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\r\n\r\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\r\n\r\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\r\n\r\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\r\n\r\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\r\n',
	"cus/crm/myaccounts/i18n/i18n_ja.properties":'# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XFLD, 30: Facet title for general Data\r\nGENERAL_DATA=\\u4E00\\u822C\\u30C7\\u30FC\\u30BF\r\n\r\n#XTIT, 40: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=\\u9867\\u5BA2\r\n\r\n#XTIT, 40: this is the title for the detail screen\r\nDETAIL_TITLE=\\u9867\\u5BA2\r\n\r\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\r\nREVENUE_CURRENT=\\u53CE\\u76CA (\\u5E74\\u521D\\u6765)\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\r\nREVENUE_CURRENT_TOOLTIP=\\u73FE\\u5728\\u307E\\u3067\\u306E\\u53CE\\u76CA (\\u5F53\\u5E74\\u5EA6)\r\n\r\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\r\nREVENUE_LAST=\\u53CE\\u76CA (\\u524D\\u5E74\\u5EA6)\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\r\nREVENUE_LAST_TOOLTIP=\\u53CE\\u76CA (\\u524D\\u5E74\\u5EA6)\r\n\r\n# XFLD, 30: Facet title for opportunities and label in facet general data\r\nOPPORTUNITIES=\\u6848\\u4EF6\r\n\r\n#XFLD, 30: Facet title for leads\r\nLEADS=\\u30EA\\u30FC\\u30C9\r\n\r\n#XFLD, 30: Facet title for tasks\r\nTASKS=\\u30BF\\u30B9\\u30AF\r\n\r\n#XFLD, 30: Facet title for appointments\r\nAPPOINTMENTS=\\u4E88\\u5B9A\r\n\r\n#XFLD, 30: Facet title for quotations\r\nQUOTATIONS=\\u898B\\u7A4D\r\n\r\n#XFLD, 30: Facet title for sales orders\r\nSALES_ORDERS=\\u53D7\\u6CE8\r\n\r\n#XFLD, 30: W7: Facet title for marketing attributes\r\nMARKETINGATTRIBUTES=\\u30DE\\u30FC\\u30B1\\u30C6\\u30A3\\u30F3\\u30B0\\u5C5E\\u6027\r\n\r\n#XFLD, 30: W6: Title for popup with products\r\nPRODUCTS=\\u88FD\\u54C1\r\n\r\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\r\nEMPLOYEE_RESPONSIBLE=\\u7BA1\\u7406\\u8CAC\\u4EFB\\u8005\r\n\r\n#XFLD, 30: Facet title for Attachments\r\nATTACHMENTS=\\u6DFB\\u4ED8\\u6587\\u66F8\r\n\r\n#XFLD, 30: Facet title for Notes\r\nNOTES=\\u30E1\\u30E2\r\n\r\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\r\nNEW_NOTE=\\u65B0\\u898F\\u30E1\\u30E2\r\n\r\n#XFLD, 30: Facet title for Contacts\r\nCONTACTS=\\u53D6\\u5F15\\u5148\\u62C5\\u5F53\\u8005\r\n\r\n#XFLD, 30: Label for Address in facet general data\r\nADDRESS=\\u30A2\\u30C9\\u30EC\\u30B9\r\n\r\n#XFLD, 30: Label for Opportunities in facet general data\r\nUNWEIGHTED_OPPORTUNITIES=\\u6848\\u4EF6\r\n\r\n#XFLD, 30: Label for Rating in facet general data\r\nRATING=\\u683C\\u4ED8\r\n\r\n# XFLD, 30: Label for Next contact in facet Appointments\r\nNEXT_APPOINTMENT=\\u6B21\\u56DE\\u306E\\u4E88\\u5B9A\r\n\r\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\r\nLAST_APPOINTMENT=\\u524D\\u56DE\\u306E\\u4E88\\u5B9A\r\n\r\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\r\nIMAGE=\\u30A4\\u30E1\\u30FC\\u30B8\r\n\r\n#XBUT, 20: Button to show the create actionsheet\r\nCREATE=\\u767B\\u9332\r\n\r\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\r\nDISCUSS_ENTRY=SAP Jam \\u3067\\u30C7\\u30A3\\u30B9\\u30AB\\u30C3\\u30B7\\u30E7\\u30F3\r\n\r\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\r\nSHARE_ENTRY=SAP Jam \\u3067\\u5171\\u6709\r\n\r\n#XBUT, 20: Button to share the note\r\nDETAIL_BUTTON_SHARE=\\u5171\\u6709\r\n\r\n#XBUT, 20: Button to cancel sharing\r\nDETAIL_BUTTON_CANCEL=\\u4E2D\\u6B62\r\n\r\n#XFLD,20: All accounts for filter\r\nALL_ACCOUNTS=\\u3059\\u3079\\u3066\\u306E\\u9867\\u5BA2\r\n\r\n#XFLD,35: All individual accounts for filter\r\nALL_INDIVIDUAL_ACCOUNTS=\\u3059\\u3079\\u3066\\u306E\\u500B\\u4EBA\\u9867\\u5BA2\r\n\r\n#XFLD,35: All corporate accounts for filter\r\nALL_CORPORATE_ACCOUNTS=\\u3059\\u3079\\u3066\\u306E\\u6CD5\\u4EBA\\u9867\\u5BA2\r\n\r\n#XFLD,35: All group accounts for filter\r\nALL_ACCOUNT_GROUPS=\\u3059\\u3079\\u3066\\u306E\\u9867\\u5BA2\\u30B0\\u30EB\\u30FC\\u30D7\r\n\r\n#XFLD,20: my account for filter\r\nMY_ACCOUNT=My \\u9867\\u5BA2\r\n\r\n#XFLD,35: my individual accounts for filter\r\nMY_INDIVIDUAL_ACCOUNTS=My \\u500B\\u4EBA\\u9867\\u5BA2\r\n\r\n#XFLD,35: my corporate accounts for filter\r\nMY_CORPORATE_ACCOUNTS=My \\u6CD5\\u4EBA\\u9867\\u5BA2\r\n\r\n#XFLD,35: my group accounts for filter\r\nMY_ACCOUNT_GROUPS=My \\u9867\\u5BA2\\u30B0\\u30EB\\u30FC\\u30D7\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nINDIVIDUAL_ACCOUNT=\\u500B\\u4EBA\\u9867\\u5BA2\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nCORPORATE_ACCOUNT=\\u6CD5\\u4EBA\\u9867\\u5BA2\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nACCOUNT_GROUP=\\u9867\\u5BA2\\u30B0\\u30EB\\u30FC\\u30D7\r\n\r\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\r\nSTARTING=\\u958B\\u59CB\\u65E5\\u4ED8\\:  {0}\r\n\r\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\r\nCLOSING=\\u898B\\u8FBC\\u6210\\u7D04\\u65E5\\:  {0}\r\n\r\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\r\nDUE=\\u671F\\u65E5\\:  {0}\r\n\r\n#XFLD,20: All accounts for title\r\nALL_ACCOUNTS_TITLE=\\u3059\\u3079\\u3066\\u306E\\u9867\\u5BA2 ({0})\r\n\r\n#XFLD,35: All individual accounts for title\r\nALL_INDIVIDUAL_ACCOUNTS_TITLE=\\u3059\\u3079\\u3066\\u306E\\u500B\\u4EBA\\u9867\\u5BA2 ({0})\r\n\r\n#XFLD,35: All corporate accounts for title\r\nALL_CORPORATE_ACCOUNTS_TITLE=\\u3059\\u3079\\u3066\\u306E\\u6CD5\\u4EBA\\u9867\\u5BA2 ({0})\r\n\r\n#XFLD,35: All group accounts for title\r\nALL_ACCOUNT_GROUPS_TITLE=\\u3059\\u3079\\u3066\\u306E\\u9867\\u5BA2\\u30B0\\u30EB\\u30FC\\u30D7 ({0})\r\n\r\n#XFLD,20: my account for title\r\nMY_ACCOUNT_TITLE=My \\u9867\\u5BA2 ({0})\r\n\r\n#XFLD,35: my individual account for title\r\nMY_INDIVIDUAL_ACCOUNT_TITLE=My \\u500B\\u4EBA\\u9867\\u5BA2 ({0})\r\n\r\n#XFLD,35: my corporate account for title.\r\nMY_CORPORATE_ACCOUNT_TITLE=My \\u6CD5\\u4EBA\\u9867\\u5BA2 ({0})\r\n\r\n#XFLD,35: my group account for title\r\nMY_ACCOUNT_GROUP_TITLE=My \\u9867\\u5BA2\\u30B0\\u30EB\\u30FC\\u30D7 ({0})\r\n\r\n#XFLD,30: filtered by info\r\nFILTERED_BY=\\u30D5\\u30A3\\u30EB\\u30BF\\u57FA\\u6E96\\:  {0}\r\n\r\n#XFLD,30: label, search for accounts\r\nSEARCH_ACCOUNTS=\\u691C\\u7D22\r\n\r\n#XFLD,30: comma separator for location\r\nLOCATION={0}, {1}\r\n\r\n#XFLD: W4: Label for All day text in Appointments\r\nALL_DAY_EVENT=\\u7D42\\u65E5\r\n\r\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\r\nDURATION_MINUTE={0} \\u5206\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\r\nDURATION_HOUR={0} \\u6642\\u9593\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\r\nDURATION_DAY={0} \\u65E5\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\r\nDURATION_DAYS={0} \\u65E5\r\n\r\n#XFLD: W4: Label for Private meeting\r\nPRIVATE=\\u975E\\u516C\\u958B\r\n\r\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\r\nSELECT_TRANSACTION_TYPE=\\u30C8\\u30E9\\u30F3\\u30B6\\u30AF\\u30B7\\u30E7\\u30F3\\u30BF\\u30A4\\u30D7\\u9078\\u629E\r\n\r\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\r\nNEW_TASK_INPUT_PLACEHOLDER=\\u65B0\\u898F\\u30BF\\u30B9\\u30AF\r\n\r\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nNO_DATA_TEXT=\\u30C7\\u30FC\\u30BF\\u306A\\u3057\r\n\r\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nLOADING_TEXT=\\u30ED\\u30FC\\u30C9\\u4E2D...\r\n\r\n#XFLD,25: W4: Column label for name of contact person in contacts\r\nNAME=\\u6C0F\\u540D\r\n\r\n#XFLD,25: W5: Column label for department of contact person in contacts\r\nDEPARTMENT=\\u90E8\\u9580\r\n\r\n#XFLD,15: W6: Column label for actions of contact person in contacts\r\nACTIONS=\\u30A2\\u30AF\\u30B7\\u30E7\\u30F3\r\n\r\n#XFLD,25: W4: Column label for description of lead in Leads\r\nDESCRIPTION=\\u30C6\\u30AD\\u30B9\\u30C8\r\n\r\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\r\nASSIGNED_TO=\\u5272\\u5F53\\u5148\r\n\r\n#XFLD,15: W4: Column label for end date of lead in Leads\r\nEND_DATE=\\u7D42\\u4E86\\u65E5\\u4ED8\r\n\r\n#XFLD,15: W4: Column label for qualification level of lead in Leads\r\nQUALIFICATION=\\u9078\\u5B9A\r\n\r\n#XFLD,15: W4: Column label for status of lead in Leads\r\nSTATUS=\\u30B9\\u30C6\\u30FC\\u30BF\\u30B9\r\n\r\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\r\nMAIN_CONTACT=\\u4E3B\\u8981\\u53D6\\u5F15\\u5148\\u62C5\\u5F53\\u8005\r\n\r\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\r\nVOLUME=\\u91D1\\u984D\r\n\r\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\r\nPROBABILITY=\\u53D7\\u6CE8\\u53EF\\u80FD\\u6027\r\n\r\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\r\nCLOSE_BY=\\u6210\\u7D04\\u671F\\u9650\r\n\r\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \r\nVIEWS=\\u30D3\\u30E5\\u30FC\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\r\nCONTACT_TITLE=\\u53D6\\u5F15\\u5148\\u62C5\\u5F53\\u8005\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\r\nEMPLOYEE_TITLE=\\u5F93\\u696D\\u54E1\r\n\r\n#XTIT,20: W7: Title of pop-up used in confirm popup\r\nCONFIRM_TITLE=\\u78BA\\u8A8D\r\n\r\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\r\nCOMPANY_NAME=\\u540D\\u79F0\r\n\r\n#XFLD,20: W4: Label for name 1 of a company used general data\r\nCOMPANY_NAME1=\\u540D\\u79F0 1\r\n\r\n#XFLD,20: W4: Label for name 2 of a company used general data\r\nCOMPANY_NAME2=\\u540D\\u79F0 2\r\n\r\n#XFLD,20: W4: Label for first name of a person used general data\r\nFIRST_NAME=\\u540D\r\n\r\n#XFLD,20: W4: Label for last name of a person used general data\r\nLAST_NAME=\\u59D3\r\n\r\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nBIRTHDAY=\\u751F\\u5E74\\u6708\\u65E5\r\n\r\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nTITLE=\\u8868\\u984C\r\n\r\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nACADEMIC_TITLE=\\u5B66\\u4F4D\\u79F0\\u53F7\r\n\r\n#XFLD,20: W4: Label for mobile phone number used general data\r\nMOBILE=\\u643A\\u5E2F\\u96FB\\u8A71\r\n\r\n#XFLD,20: W4: Label for phone number used general data\r\nPHONE=\\u96FB\\u8A71\r\n\r\n#XFLD,20: W4: Label for e-mail used general data\r\nEMAIL=\\u30E1\\u30FC\\u30EB\r\n\r\n#XFLD,20: W4: Label for web site used general data\r\nWEBSITE=Web \\u30B5\\u30A4\\u30C8\r\n\r\n#XFLD,20: W4: Label for country used general data\r\nCOUNTRY=\\u56FD\r\n\r\n#XFLD,20: W4: Label for region used general data\r\nREGION=\\u5730\\u57DF\r\n\r\n#XFLD,20: W4: Label for city used general data\r\nCITY=\\u5E02\\u533A\\u753A\\u6751\r\n\r\n#XFLD,20: W4: Label for postal code used general data\r\nPOSTAL_CODE=\\u90F5\\u4FBF\\u756A\\u53F7\r\n\r\n#XFLD,20: W4: Label for street used general data\r\nSTREET=\\u5730\\u540D\r\n\r\n#XFLD,10: W4: Label for house number used general data\r\nHOUSE_NUMBER=\\u756A\\u5730-\\u53F7\r\n\r\n#XFLD,15: W6: Label for ID used in Quotations\r\nID=ID\r\n\r\n#XFLD,15: W6: Label for Amount used in Quotations\r\nAMOUNT=\\u91D1\\u984D\r\n\r\n#XFLD,20: W6: Label for Expiration Date used in Quotations\r\nEXPIRATION_DATE=\\u6709\\u52B9\\u671F\\u9650\r\n\r\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\r\nDELIVERY_DATE=\\u7D0D\\u5165\\u65E5\\u4ED8\r\n\r\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\r\nSALES_EMPLOYEE=\\u55B6\\u696D\\u54E1\r\n\r\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\r\nATTRIBUTESET=\\u5C5E\\u6027\\u30BB\\u30C3\\u30C8\r\n\r\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\r\nATTRIBUTE=\\u5C5E\\u6027\r\n\r\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\r\nVALUE=\\u5024\r\n\r\n#XBUT, 20: Button to create an Account\r\nBUTTON_ADD=\\u8FFD\\u52A0\r\n\r\n#XBUT, 20: Button to edit an Account\r\nBUTTON_EDIT=\\u7DE8\\u96C6\r\n\r\n#XBUT, 20: Button to save changes\r\nBUTTON_SAVE=\\u4FDD\\u5B58\r\n\r\n#XBUT, 20: Button to cancel changes\r\nBUTTON_CANCEL=\\u4E2D\\u6B62\r\n\r\n#XBUT, 30: Button which shows the personalization buttons\r\nBUTTON_SHOW_PERSONALIZATION=\\u30D1\\u30FC\\u30BD\\u30CA\\u30E9\\u30A4\\u30BC\\u30FC\\u30B7\\u30E7\\u30F3\\u8868\\u793A\r\n\r\n#XBUT, 30: Button which hides the personalization buttons\r\nBUTTON_HIDE_PERSONALIZATION=\\u30D1\\u30FC\\u30BD\\u30CA\\u30E9\\u30A4\\u30BC\\u30FC\\u30B7\\u30E7\\u30F3\\u975E\\u8868\\u793A\r\n\r\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_CONFIRM_CANCEL=\\u672A\\u4FDD\\u5B58\\u306E\\u5909\\u66F4\\u306F\\u5931\\u308F\\u308C\\u307E\\u3059\\u3002\\u7D9A\\u884C\\u3057\\u307E\\u3059\\u304B\\u3002\r\n\r\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\r\nMSG_CONFIRM_DELETE_CONTACT=\\u53D6\\u5F15\\u5148\\u62C5\\u5F53\\u8005\\u304C\\u9867\\u5BA2\\u304B\\u3089\\u5272\\u5F53\\u89E3\\u9664\\u3055\\u308C\\u307E\\u3059\\u3002\\u7D9A\\u884C\\u3057\\u307E\\u3059\\u304B\\u3002\r\n\r\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_SUCCESS=\\u9867\\u5BA2\\u304C\\u66F4\\u65B0\\u3055\\u308C\\u307E\\u3057\\u305F\r\n\r\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_ERROR=\\u66F4\\u65B0\\u3067\\u304D\\u307E\\u305B\\u3093\\u3067\\u3057\\u305F\r\n\r\n# XMSG : Account update succeeded\r\nMSG_CREATION_SUCCESS=\\u9867\\u5BA2\\u304C\\u767B\\u9332\\u3055\\u308C\\u307E\\u3057\\u305F\r\n\r\n# XMSG : Task creation succeeded\r\nMSG_TASK_CREATION_SUCCESS=\\u30BF\\u30B9\\u30AF\\u304C\\u767B\\u9332\\u3055\\u308C\\u307E\\u3057\\u305F\r\n\r\n# XMSG : Contact creation failed\r\nMSG_CREATION_ERROR=\\u767B\\u9332\\u3067\\u304D\\u307E\\u305B\\u3093\\u3067\\u3057\\u305F\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong country\r\nMSG_WRONG_COUNTRY_ERROR=\\u56FD "{0}" \\u306F\\u5B58\\u5728\\u3057\\u307E\\u305B\\u3093\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong region\r\nMSG_WRONG_REGION_ERROR=\\u3053\\u306E\\u56FD\\u306B\\u5730\\u57DF "{0}" \\u306F\\u5B58\\u5728\\u3057\\u307E\\u305B\\u3093\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong employee\r\nMSG_WRONG_EMPLOYEE_ERROR=\\u5F93\\u696D\\u54E1 "{0}" \\u306F\\u5B58\\u5728\\u3057\\u307E\\u305B\\u3093\\u3002\r\n\r\n# XMSG: message that will be displayed, if the user has entered invalid website url\r\nMSG_WRONG_URL_ERROR=\\u5165\\u529B\\u3055\\u308C\\u305F URL "{0}" \\u306F\\u7121\\u52B9\\u3067\\u3059\\u3002\r\n\r\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\r\nMSG_MANDATORY_FIELDS=\\u4E00\\u90E8\\u306E\\u5165\\u529B\\u5FC5\\u9808\\u9805\\u76EE\\u304C\\u5165\\u529B\\u3055\\u308C\\u3066\\u3044\\u307E\\u305B\\u3093\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA=\\u30C7\\u30FC\\u30BF\\u306F\\u5225\\u306E\\u30E6\\u30FC\\u30B6\\u306B\\u3088\\u308A\\u5909\\u66F4\\u3055\\u308C\\u3066\\u3044\\u307E\\u3059\\u3002\\u3053\\u306E\\u30E6\\u30FC\\u30B6\\u306B\\u3088\\u308B\\u5909\\u66F4\\u3092\\u81EA\\u5206\\u306E\\u5909\\u66F4\\u3067\\u4E0A\\u66F8\\u304D\\u3057\\u307E\\u3059\\u304B\\u3002\r\n\r\n# XMSG: message that will be displayed in case of conflicts during file renaming\r\nMSG_CONFLICTING_FILE_NAME=\\u30D5\\u30A1\\u30A4\\u30EB\\u540D\\u306F\\u5225\\u306E\\u30E6\\u30FC\\u30B6\\u306B\\u3088\\u308A\\u5909\\u66F4\\u3055\\u308C\\u3066\\u3044\\u307E\\u3059\\u3002\\u3053\\u306E\\u30E6\\u30FC\\u30B6\\u306B\\u3088\\u308B\\u5909\\u66F4\\u3092\\u81EA\\u5206\\u306E\\u5909\\u66F4\\u3067\\u4E0A\\u66F8\\u304D\\u3057\\u307E\\u3059\\u304B\\u3002\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA_WITH_REFRESH=\\u30C7\\u30FC\\u30BF\\u306F\\u5225\\u306E\\u30E6\\u30FC\\u30B6\\u306B\\u3088\\u308A\\u5909\\u66F4\\u3055\\u308C\\u3066\\u3044\\u307E\\u3059\\u3002\\u3053\\u308C\\u3089\\u306E\\u5909\\u66F4\\u304C\\u30A2\\u30D7\\u30EA\\u306B\\u8868\\u793A\\u3055\\u308C\\u307E\\u3059\\u3002\r\n\r\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\r\nMSG_NOT_IN_MAIN_CONTACT=\\u3053\\u306E\\u9867\\u5BA2\\u306B\\u5272\\u308A\\u5F53\\u3066\\u3089\\u308C\\u3066\\u3044\\u308B\\u53D6\\u5F15\\u5148\\u62C5\\u5F53\\u8005\\u306E\\u8A73\\u7D30\\u306E\\u307F\\u7167\\u4F1A\\u3059\\u308B\\u3053\\u3068\\u304C\\u3067\\u304D\\u307E\\u3059\r\n\r\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\r\nMSG_EXCEEDING_FILE_NAME_LENGTH=\\u30D5\\u30A1\\u30A4\\u30EB\\u540D\\u306B\\u306F\\u6700\\u5927 40 \\u6587\\u5B57\\u8A2D\\u5B9A\\u3059\\u308B\\u3053\\u3068\\u304C\\u3067\\u304D\\u307E\\u3059\\u3002\r\n\r\n# XTOL, 20: tooltip shown on search result list for button to add an account"\r\n\r\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\r\n\r\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\r\n\r\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\r\n\r\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\r\n\r\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\r\n',
	"cus/crm/myaccounts/i18n/i18n_no.properties":'# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XFLD, 30: Facet title for general Data\r\nGENERAL_DATA=Generelle data\r\n\r\n#XTIT, 40: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=Mine kunder\r\n\r\n#XTIT, 40: this is the title for the detail screen\r\nDETAIL_TITLE=Kunde\r\n\r\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\r\nREVENUE_CURRENT=Omsetn. dette \\u00E5ret\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\r\nREVENUE_CURRENT_TOOLTIP=Omsetning til dato innev\\u00E6rende \\u00E5r\r\n\r\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\r\nREVENUE_LAST=Omsetn. forrige \\u00E5r\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\r\nREVENUE_LAST_TOOLTIP=Omsetning forrige \\u00E5r\r\n\r\n# XFLD, 30: Facet title for opportunities and label in facet general data\r\nOPPORTUNITIES=Salgsmuligheter\r\n\r\n#XFLD, 30: Facet title for leads\r\nLEADS=Lead\r\n\r\n#XFLD, 30: Facet title for tasks\r\nTASKS=Oppgaver\r\n\r\n#XFLD, 30: Facet title for appointments\r\nAPPOINTMENTS=Avtaler\r\n\r\n#XFLD, 30: Facet title for quotations\r\nQUOTATIONS=Tilbud\r\n\r\n#XFLD, 30: Facet title for sales orders\r\nSALES_ORDERS=Kundeordrer\r\n\r\n#XFLD, 30: W7: Facet title for marketing attributes\r\nMARKETINGATTRIBUTES=Markedsf\\u00F8ringsattributter\r\n\r\n#XFLD, 30: W6: Title for popup with products\r\nPRODUCTS=Produkter\r\n\r\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\r\nEMPLOYEE_RESPONSIBLE=Ansvarlig medarbeider\r\n\r\n#XFLD, 30: Facet title for Attachments\r\nATTACHMENTS=Vedlegg\r\n\r\n#XFLD, 30: Facet title for Notes\r\nNOTES=Merknader\r\n\r\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\r\nNEW_NOTE=Ny merknad\r\n\r\n#XFLD, 30: Facet title for Contacts\r\nCONTACTS=Kontakter\r\n\r\n#XFLD, 30: Label for Address in facet general data\r\nADDRESS=Adresse\r\n\r\n#XFLD, 30: Label for Opportunities in facet general data\r\nUNWEIGHTED_OPPORTUNITIES=Salgsmuligheter\r\n\r\n#XFLD, 30: Label for Rating in facet general data\r\nRATING=Vurdering\r\n\r\n# XFLD, 30: Label for Next contact in facet Appointments\r\nNEXT_APPOINTMENT=Neste avtale\r\n\r\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\r\nLAST_APPOINTMENT=Siste avtale\r\n\r\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\r\nIMAGE=Bilde\r\n\r\n#XBUT, 20: Button to show the create actionsheet\r\nCREATE=Opprett\r\n\r\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\r\nDISCUSS_ENTRY=Diskuter p\\u00E5 SAP Jam\r\n\r\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\r\nSHARE_ENTRY=Del p\\u00E5 SAP Jam\r\n\r\n#XBUT, 20: Button to share the note\r\nDETAIL_BUTTON_SHARE=Del\r\n\r\n#XBUT, 20: Button to cancel sharing\r\nDETAIL_BUTTON_CANCEL=Avbryt\r\n\r\n#XFLD,20: All accounts for filter\r\nALL_ACCOUNTS=Alle kunder\r\n\r\n#XFLD,35: All individual accounts for filter\r\nALL_INDIVIDUAL_ACCOUNTS=Alle personkunder\r\n\r\n#XFLD,35: All corporate accounts for filter\r\nALL_CORPORATE_ACCOUNTS=Alle bedriftskunder\r\n\r\n#XFLD,35: All group accounts for filter\r\nALL_ACCOUNT_GROUPS=Alle kontogrupper\r\n\r\n#XFLD,20: my account for filter\r\nMY_ACCOUNT=Mine kunder\r\n\r\n#XFLD,35: my individual accounts for filter\r\nMY_INDIVIDUAL_ACCOUNTS=Mine personkunder\r\n\r\n#XFLD,35: my corporate accounts for filter\r\nMY_CORPORATE_ACCOUNTS=Mine bedriftskunder\r\n\r\n#XFLD,35: my group accounts for filter\r\nMY_ACCOUNT_GROUPS=Mine kontogrupper\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nINDIVIDUAL_ACCOUNT=Individuell konto\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nCORPORATE_ACCOUNT=Firmakonto\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nACCOUNT_GROUP=Kontogruppe\r\n\r\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\r\nSTARTING=Startdato\\: {0}\r\n\r\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\r\nCLOSING=Avslutningsdato\\: {0}\r\n\r\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\r\nDUE=Forfallsdato\\: {0}\r\n\r\n#XFLD,20: All accounts for title\r\nALL_ACCOUNTS_TITLE=Alle kunder ({0})\r\n\r\n#XFLD,35: All individual accounts for title\r\nALL_INDIVIDUAL_ACCOUNTS_TITLE=Alle personkunder ({0})\r\n\r\n#XFLD,35: All corporate accounts for title\r\nALL_CORPORATE_ACCOUNTS_TITLE=Alle bedriftskunder ({0})\r\n\r\n#XFLD,35: All group accounts for title\r\nALL_ACCOUNT_GROUPS_TITLE=Alle kontogrupper ({0})\r\n\r\n#XFLD,20: my account for title\r\nMY_ACCOUNT_TITLE=Mine kunder ({0})\r\n\r\n#XFLD,35: my individual account for title\r\nMY_INDIVIDUAL_ACCOUNT_TITLE=Mine personkunder ({0})\r\n\r\n#XFLD,35: my corporate account for title.\r\nMY_CORPORATE_ACCOUNT_TITLE=Mine bedriftskunder ({0})\r\n\r\n#XFLD,35: my group account for title\r\nMY_ACCOUNT_GROUP_TITLE=Mine kontogrupper ({0})\r\n\r\n#XFLD,30: filtered by info\r\nFILTERED_BY=Filtrert etter\\: {0}\r\n\r\n#XFLD,30: label, search for accounts\r\nSEARCH_ACCOUNTS=S\\u00F8k\r\n\r\n#XFLD,30: comma separator for location\r\nLOCATION={0}, {1}\r\n\r\n#XFLD: W4: Label for All day text in Appointments\r\nALL_DAY_EVENT=Hele dagen\r\n\r\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\r\nDURATION_MINUTE={0} min\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\r\nDURATION_HOUR={0} t\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\r\nDURATION_DAY={0} dag\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\r\nDURATION_DAYS={0} dager\r\n\r\n#XFLD: W4: Label for Private meeting\r\nPRIVATE=Privat\r\n\r\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\r\nSELECT_TRANSACTION_TYPE=Velg transaksjonstype\r\n\r\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\r\nNEW_TASK_INPUT_PLACEHOLDER=Ny oppgave\r\n\r\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nNO_DATA_TEXT=Ingen data\r\n\r\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nLOADING_TEXT=Laster ...\r\n\r\n#XFLD,25: W4: Column label for name of contact person in contacts\r\nNAME=Navn\r\n\r\n#XFLD,25: W5: Column label for department of contact person in contacts\r\nDEPARTMENT=Avdeling\r\n\r\n#XFLD,15: W6: Column label for actions of contact person in contacts\r\nACTIONS=Aktiviteter\r\n\r\n#XFLD,25: W4: Column label for description of lead in Leads\r\nDESCRIPTION=Beskrivelse\r\n\r\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\r\nASSIGNED_TO=Tilordnet til\r\n\r\n#XFLD,15: W4: Column label for end date of lead in Leads\r\nEND_DATE=Sluttdato\r\n\r\n#XFLD,15: W4: Column label for qualification level of lead in Leads\r\nQUALIFICATION=Kvalifisering\r\n\r\n#XFLD,15: W4: Column label for status of lead in Leads\r\nSTATUS=Status\r\n\r\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\r\nMAIN_CONTACT=Hovedkontakt\r\n\r\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\r\nVOLUME=Volum\r\n\r\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\r\nPROBABILITY=Sannsynlighet\r\n\r\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\r\nCLOSE_BY=Avslutning innen\r\n\r\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \r\nVIEWS=Visninger\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\r\nCONTACT_TITLE=Kontakt\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\r\nEMPLOYEE_TITLE=Medarbeider\r\n\r\n#XTIT,20: W7: Title of pop-up used in confirm popup\r\nCONFIRM_TITLE=Bekreft\r\n\r\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\r\nCOMPANY_NAME=Navn\r\n\r\n#XFLD,20: W4: Label for name 1 of a company used general data\r\nCOMPANY_NAME1=Navn 1\r\n\r\n#XFLD,20: W4: Label for name 2 of a company used general data\r\nCOMPANY_NAME2=Navn 2\r\n\r\n#XFLD,20: W4: Label for first name of a person used general data\r\nFIRST_NAME=Fornavn\r\n\r\n#XFLD,20: W4: Label for last name of a person used general data\r\nLAST_NAME=Etternavn\r\n\r\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nBIRTHDAY=F\\u00F8dselsdato\r\n\r\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nTITLE=Tittel\r\n\r\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nACADEMIC_TITLE=Akademisk tittel\r\n\r\n#XFLD,20: W4: Label for mobile phone number used general data\r\nMOBILE=Mobil\r\n\r\n#XFLD,20: W4: Label for phone number used general data\r\nPHONE=Telefon\r\n\r\n#XFLD,20: W4: Label for e-mail used general data\r\nEMAIL=E-post\r\n\r\n#XFLD,20: W4: Label for web site used general data\r\nWEBSITE=Nettsted\r\n\r\n#XFLD,20: W4: Label for country used general data\r\nCOUNTRY=Land\r\n\r\n#XFLD,20: W4: Label for region used general data\r\nREGION=Region\r\n\r\n#XFLD,20: W4: Label for city used general data\r\nCITY=Sted\r\n\r\n#XFLD,20: W4: Label for postal code used general data\r\nPOSTAL_CODE=Postnummer\r\n\r\n#XFLD,20: W4: Label for street used general data\r\nSTREET=Gate/vei\r\n\r\n#XFLD,10: W4: Label for house number used general data\r\nHOUSE_NUMBER=Husnr.\r\n\r\n#XFLD,15: W6: Label for ID used in Quotations\r\nID=ID\r\n\r\n#XFLD,15: W6: Label for Amount used in Quotations\r\nAMOUNT=Bel\\u00F8p\r\n\r\n#XFLD,20: W6: Label for Expiration Date used in Quotations\r\nEXPIRATION_DATE=Utl\\u00F8psdato\r\n\r\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\r\nDELIVERY_DATE=Leveringsdato\r\n\r\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\r\nSALES_EMPLOYEE=Salgsmedarbeider\r\n\r\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\r\nATTRIBUTESET=Attributtsett\r\n\r\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\r\nATTRIBUTE=Attributt\r\n\r\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\r\nVALUE=Verdi\r\n\r\n#XBUT, 20: Button to create an Account\r\nBUTTON_ADD=Tilf\\u00F8y\r\n\r\n#XBUT, 20: Button to edit an Account\r\nBUTTON_EDIT=Rediger\r\n\r\n#XBUT, 20: Button to save changes\r\nBUTTON_SAVE=Lagre\r\n\r\n#XBUT, 20: Button to cancel changes\r\nBUTTON_CANCEL=Avbryt\r\n\r\n#XBUT, 30: Button which shows the personalization buttons\r\nBUTTON_SHOW_PERSONALIZATION=Vis personlighetstilpasning\r\n\r\n#XBUT, 30: Button which hides the personalization buttons\r\nBUTTON_HIDE_PERSONALIZATION=Skjul personlighetstilpasning\r\n\r\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_CONFIRM_CANCEL=Ikke lagrede endringer vil g\\u00E5 tapt. Fortsette?\r\n\r\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\r\nMSG_CONFIRM_DELETE_CONTACT=Kontakten vil miste tilordning til konto. Fortsette?\r\n\r\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_SUCCESS=Konto oppdatert\r\n\r\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_ERROR=Oppdatering mislyktes\r\n\r\n# XMSG : Account update succeeded\r\nMSG_CREATION_SUCCESS=Konto opprettet\r\n\r\n# XMSG : Task creation succeeded\r\nMSG_TASK_CREATION_SUCCESS=Oppgave opprettet\r\n\r\n# XMSG : Contact creation failed\r\nMSG_CREATION_ERROR=Oppretting mislyktes\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong country\r\nMSG_WRONG_COUNTRY_ERROR=Land "{0}" finnes ikke\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong region\r\nMSG_WRONG_REGION_ERROR=Region "{0}" finnes ikke for land\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong employee\r\nMSG_WRONG_EMPLOYEE_ERROR=Medarbeider "{0}" finnes ikke\r\n\r\n# XMSG: message that will be displayed, if the user has entered invalid website url\r\nMSG_WRONG_URL_ERROR=Oppgitt URL "{0}" er ikke gyldig.\r\n\r\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\r\nMSG_MANDATORY_FIELDS=Alle obligatoriske felt er ikke utfylt\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA=En annen bruker har endret dataene. Vil du overskrive endringene til den andre brukeren med dine egne?\r\n\r\n# XMSG: message that will be displayed in case of conflicts during file renaming\r\nMSG_CONFLICTING_FILE_NAME=En annen bruker har endret filnavnet. Vil du overskrive endringene til den andre brukeren med dine egne?\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA_WITH_REFRESH=Data er endret av en annen bruker. Disse endringene vil n\\u00E5 synes i appen.\r\n\r\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\r\nMSG_NOT_IN_MAIN_CONTACT=Du kan bare vise detaljer for kontaktpersoner som er tilordnet til denne kunden\r\n\r\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\r\nMSG_EXCEEDING_FILE_NAME_LENGTH=Filnavnet ditt kan ha maksimalt 40 tegn\r\n\r\n# XTOL, 20: tooltip shown on search result list for button to add an account"\r\n\r\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\r\n\r\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\r\n\r\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\r\n\r\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\r\n\r\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\r\n',
	"cus/crm/myaccounts/i18n/i18n_pl.properties":'# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XFLD, 30: Facet title for general Data\r\nGENERAL_DATA=Dane og\\u00F3lne\r\n\r\n#XTIT, 40: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=Moi klienci\r\n\r\n#XTIT, 40: this is the title for the detail screen\r\nDETAIL_TITLE=Klient\r\n\r\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\r\nREVENUE_CURRENT=Prz. od pocz. roku\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\r\nREVENUE_CURRENT_TOOLTIP=Przych\\u00F3d do dzi\\u015B bie\\u017C\\u0105cego roku\r\n\r\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\r\nREVENUE_LAST=Prz. w zesz\\u0142. roku\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\r\nREVENUE_LAST_TOOLTIP=Przych\\u00F3d w zesz\\u0142ym roku\r\n\r\n# XFLD, 30: Facet title for opportunities and label in facet general data\r\nOPPORTUNITIES=Szanse\r\n\r\n#XFLD, 30: Facet title for leads\r\nLEADS=Potencjalne szanse\r\n\r\n#XFLD, 30: Facet title for tasks\r\nTASKS=Zadania\r\n\r\n#XFLD, 30: Facet title for appointments\r\nAPPOINTMENTS=Spotkania\r\n\r\n#XFLD, 30: Facet title for quotations\r\nQUOTATIONS=Oferty\r\n\r\n#XFLD, 30: Facet title for sales orders\r\nSALES_ORDERS=Zlecenia klienta\r\n\r\n#XFLD, 30: W7: Facet title for marketing attributes\r\nMARKETINGATTRIBUTES=Atrybuty marketingowe\r\n\r\n#XFLD, 30: W6: Title for popup with products\r\nPRODUCTS=Produkty\r\n\r\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\r\nEMPLOYEE_RESPONSIBLE=Odpowiedzialny pracownik\r\n\r\n#XFLD, 30: Facet title for Attachments\r\nATTACHMENTS=Za\\u0142\\u0105czniki\r\n\r\n#XFLD, 30: Facet title for Notes\r\nNOTES=Notatki\r\n\r\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\r\nNEW_NOTE=Nowa notatka\r\n\r\n#XFLD, 30: Facet title for Contacts\r\nCONTACTS=Kontakty\r\n\r\n#XFLD, 30: Label for Address in facet general data\r\nADDRESS=Adres\r\n\r\n#XFLD, 30: Label for Opportunities in facet general data\r\nUNWEIGHTED_OPPORTUNITIES=Szanse\r\n\r\n#XFLD, 30: Label for Rating in facet general data\r\nRATING=Ocena\r\n\r\n# XFLD, 30: Label for Next contact in facet Appointments\r\nNEXT_APPOINTMENT=Nast\\u0119pne spotkanie\r\n\r\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\r\nLAST_APPOINTMENT=Ostatnie spotkanie\r\n\r\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\r\nIMAGE=Obraz\r\n\r\n#XBUT, 20: Button to show the create actionsheet\r\nCREATE=Utw\\u00F3rz\r\n\r\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\r\nDISCUSS_ENTRY=Om\\u00F3w za pomoc\\u0105 SAP Jam\r\n\r\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\r\nSHARE_ENTRY=Udost\\u0119pnij w SAP Jam\r\n\r\n#XBUT, 20: Button to share the note\r\nDETAIL_BUTTON_SHARE=Udost\\u0119pnij\r\n\r\n#XBUT, 20: Button to cancel sharing\r\nDETAIL_BUTTON_CANCEL=Anuluj\r\n\r\n#XFLD,20: All accounts for filter\r\nALL_ACCOUNTS=Wszyscy klienci\r\n\r\n#XFLD,35: All individual accounts for filter\r\nALL_INDIVIDUAL_ACCOUNTS=Wszyscy klienci indywidualni\r\n\r\n#XFLD,35: All corporate accounts for filter\r\nALL_CORPORATE_ACCOUNTS=Wszyscy klienci korporacyjni\r\n\r\n#XFLD,35: All group accounts for filter\r\nALL_ACCOUNT_GROUPS=Wszystkie grupy klient\\u00F3w\r\n\r\n#XFLD,20: my account for filter\r\nMY_ACCOUNT=Moi klienci\r\n\r\n#XFLD,35: my individual accounts for filter\r\nMY_INDIVIDUAL_ACCOUNTS=Moi klienci indywidualni\r\n\r\n#XFLD,35: my corporate accounts for filter\r\nMY_CORPORATE_ACCOUNTS=Moi klienci korporacyjni\r\n\r\n#XFLD,35: my group accounts for filter\r\nMY_ACCOUNT_GROUPS=Moje grupy klient\\u00F3w\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nINDIVIDUAL_ACCOUNT=Klient indywidualny\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nCORPORATE_ACCOUNT=Klient korporacyjny\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nACCOUNT_GROUP=Grupa kont\r\n\r\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\r\nSTARTING=Data rozpocz\\u0119cia\\: {0}\r\n\r\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\r\nCLOSING=Data zamkni\\u0119cia\\: {0}\r\n\r\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\r\nDUE=Termin\\: {0}\r\n\r\n#XFLD,20: All accounts for title\r\nALL_ACCOUNTS_TITLE=Wszyscy klienci ({0})\r\n\r\n#XFLD,35: All individual accounts for title\r\nALL_INDIVIDUAL_ACCOUNTS_TITLE=Wszyscy klienci indywidualni ({0})\r\n\r\n#XFLD,35: All corporate accounts for title\r\nALL_CORPORATE_ACCOUNTS_TITLE=Wszyscy klienci korporacyjni ({0})\r\n\r\n#XFLD,35: All group accounts for title\r\nALL_ACCOUNT_GROUPS_TITLE=Wszystkie grupy klient\\u00F3w ({0})\r\n\r\n#XFLD,20: my account for title\r\nMY_ACCOUNT_TITLE=Moi klienci ({0})\r\n\r\n#XFLD,35: my individual account for title\r\nMY_INDIVIDUAL_ACCOUNT_TITLE=Moi klienci indywidualni ({0})\r\n\r\n#XFLD,35: my corporate account for title.\r\nMY_CORPORATE_ACCOUNT_TITLE=Moi klienci korporacyjni ({0})\r\n\r\n#XFLD,35: my group account for title\r\nMY_ACCOUNT_GROUP_TITLE=Moje grupy klient\\u00F3w ({0})\r\n\r\n#XFLD,30: filtered by info\r\nFILTERED_BY=Przefiltrowane wed\\u0142ug\\: {0}\r\n\r\n#XFLD,30: label, search for accounts\r\nSEARCH_ACCOUNTS=Szukaj\r\n\r\n#XFLD,30: comma separator for location\r\nLOCATION={0}, {1}\r\n\r\n#XFLD: W4: Label for All day text in Appointments\r\nALL_DAY_EVENT=Ca\\u0142y dzie\\u0144\r\n\r\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\r\nDURATION_MINUTE={0} min\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\r\nDURATION_HOUR={0} godz.\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\r\nDURATION_DAY={0} dzie\\u0144\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\r\nDURATION_DAYS={0} dni\r\n\r\n#XFLD: W4: Label for Private meeting\r\nPRIVATE=Prywatne\r\n\r\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\r\nSELECT_TRANSACTION_TYPE=Wyb\\u00F3r typu transakcji\r\n\r\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\r\nNEW_TASK_INPUT_PLACEHOLDER=Nowe zadanie\r\n\r\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nNO_DATA_TEXT=Brak danych\r\n\r\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nLOADING_TEXT=Wczytywanie...\r\n\r\n#XFLD,25: W4: Column label for name of contact person in contacts\r\nNAME=Nazwa\r\n\r\n#XFLD,25: W5: Column label for department of contact person in contacts\r\nDEPARTMENT=Dzia\\u0142\r\n\r\n#XFLD,15: W6: Column label for actions of contact person in contacts\r\nACTIONS=Czynno\\u015Bci\r\n\r\n#XFLD,25: W4: Column label for description of lead in Leads\r\nDESCRIPTION=Opis\r\n\r\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\r\nASSIGNED_TO=Przypisane do\r\n\r\n#XFLD,15: W4: Column label for end date of lead in Leads\r\nEND_DATE=Data zako\\u0144.\r\n\r\n#XFLD,15: W4: Column label for qualification level of lead in Leads\r\nQUALIFICATION=Kwalifikacja\r\n\r\n#XFLD,15: W4: Column label for status of lead in Leads\r\nSTATUS=Status\r\n\r\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\r\nMAIN_CONTACT=G\\u0142\\u00F3wny kontakt\r\n\r\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\r\nVOLUME=Ilo\\u015B\\u0107\r\n\r\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\r\nPROBABILITY=Prawdopodobie\\u0144stwo\r\n\r\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\r\nCLOSE_BY=Zamkni\\u0119cie do\r\n\r\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \r\nVIEWS=Wgl\\u0105dy\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\r\nCONTACT_TITLE=Kontakt\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\r\nEMPLOYEE_TITLE=Pracownik\r\n\r\n#XTIT,20: W7: Title of pop-up used in confirm popup\r\nCONFIRM_TITLE=Potwierdzenie\r\n\r\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\r\nCOMPANY_NAME=Nazwa\r\n\r\n#XFLD,20: W4: Label for name 1 of a company used general data\r\nCOMPANY_NAME1=Nazwa 1\r\n\r\n#XFLD,20: W4: Label for name 2 of a company used general data\r\nCOMPANY_NAME2=Nazwa 2\r\n\r\n#XFLD,20: W4: Label for first name of a person used general data\r\nFIRST_NAME=Imi\\u0119\r\n\r\n#XFLD,20: W4: Label for last name of a person used general data\r\nLAST_NAME=Nazwisko\r\n\r\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nBIRTHDAY=Data urodzenia\r\n\r\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nTITLE=Tytu\\u0142\r\n\r\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nACADEMIC_TITLE=Tytu\\u0142 akademicki\r\n\r\n#XFLD,20: W4: Label for mobile phone number used general data\r\nMOBILE=Telefon kom\\u00F3rkowy\r\n\r\n#XFLD,20: W4: Label for phone number used general data\r\nPHONE=Telefon\r\n\r\n#XFLD,20: W4: Label for e-mail used general data\r\nEMAIL=E-mail\r\n\r\n#XFLD,20: W4: Label for web site used general data\r\nWEBSITE=Strona WWW\r\n\r\n#XFLD,20: W4: Label for country used general data\r\nCOUNTRY=Kraj\r\n\r\n#XFLD,20: W4: Label for region used general data\r\nREGION=Region\r\n\r\n#XFLD,20: W4: Label for city used general data\r\nCITY=Miejscowo\\u015B\\u0107\r\n\r\n#XFLD,20: W4: Label for postal code used general data\r\nPOSTAL_CODE=Kod pocztowy\r\n\r\n#XFLD,20: W4: Label for street used general data\r\nSTREET=Ulica\r\n\r\n#XFLD,10: W4: Label for house number used general data\r\nHOUSE_NUMBER=Numer domu\r\n\r\n#XFLD,15: W6: Label for ID used in Quotations\r\nID=ID\r\n\r\n#XFLD,15: W6: Label for Amount used in Quotations\r\nAMOUNT=Kwota\r\n\r\n#XFLD,20: W6: Label for Expiration Date used in Quotations\r\nEXPIRATION_DATE=Data wyga\\u015Bni\\u0119cia\r\n\r\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\r\nDELIVERY_DATE=Data dostawy\r\n\r\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\r\nSALES_EMPLOYEE=Pracownik dz. sprz.\r\n\r\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\r\nATTRIBUTESET=Zbi\\u00F3r atrybut\\u00F3w\r\n\r\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\r\nATTRIBUTE=Atrybut\r\n\r\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\r\nVALUE=Warto\\u015B\\u0107\r\n\r\n#XBUT, 20: Button to create an Account\r\nBUTTON_ADD=Dodaj\r\n\r\n#XBUT, 20: Button to edit an Account\r\nBUTTON_EDIT=Edytuj\r\n\r\n#XBUT, 20: Button to save changes\r\nBUTTON_SAVE=Zapisz\r\n\r\n#XBUT, 20: Button to cancel changes\r\nBUTTON_CANCEL=Anuluj\r\n\r\n#XBUT, 30: Button which shows the personalization buttons\r\nBUTTON_SHOW_PERSONALIZATION=Wy\\u015Bwietl personalizacj\\u0119\r\n\r\n#XBUT, 30: Button which hides the personalization buttons\r\nBUTTON_HIDE_PERSONALIZATION=Ukryj personalizacj\\u0119\r\n\r\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_CONFIRM_CANCEL=Niezapisane zmiany zostan\\u0105 utracone. Czy chcesz kontynuowa\\u0107?\r\n\r\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\r\nMSG_CONFIRM_DELETE_CONTACT=Przypisanie kontaktu do klienta zostanie anulowane. Czy chcesz kontynuowa\\u0107?\r\n\r\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_SUCCESS=Zaktualizowano klienta\r\n\r\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_ERROR=Aktualizacja nie powiod\\u0142a si\\u0119\r\n\r\n# XMSG : Account update succeeded\r\nMSG_CREATION_SUCCESS=Utworzono klienta\r\n\r\n# XMSG : Task creation succeeded\r\nMSG_TASK_CREATION_SUCCESS=Utworzono zadanie\r\n\r\n# XMSG : Contact creation failed\r\nMSG_CREATION_ERROR=Tworzenie nie powiod\\u0142o si\\u0119\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong country\r\nMSG_WRONG_COUNTRY_ERROR=Kraj "{0}" nie istnieje\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong region\r\nMSG_WRONG_REGION_ERROR=Region "{0}" nie istnieje dla kraju\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong employee\r\nMSG_WRONG_EMPLOYEE_ERROR=Pracownik "{0}" nie istnieje.\r\n\r\n# XMSG: message that will be displayed, if the user has entered invalid website url\r\nMSG_WRONG_URL_ERROR=Wprowadzony URL "{0}" jest nieprawid\\u0142owy.\r\n\r\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\r\nMSG_MANDATORY_FIELDS=Nie wszystkie pola obowi\\u0105zkowe s\\u0105 wype\\u0142nione\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA=Dane zosta\\u0142y zmienione przez innego u\\u017Cytkownika. Czy chcesz nadpisa\\u0107 zmiany innego u\\u017Cytkownika w\\u0142asnymi zmianami?\r\n\r\n# XMSG: message that will be displayed in case of conflicts during file renaming\r\nMSG_CONFLICTING_FILE_NAME=Nazwa pliku zosta\\u0142a zmieniona przez innego u\\u017Cytkownika. Czy chcesz nadpisa\\u0107 zmiany innego u\\u017Cytkownika w\\u0142asnymi zmianami?\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA_WITH_REFRESH=Dane zosta\\u0142y zmienione przez innego u\\u017Cytkownika. Te zmiany b\\u0119d\\u0105 teraz widoczne w aplikacji.\r\n\r\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\r\nMSG_NOT_IN_MAIN_CONTACT=Mo\\u017Cesz wy\\u015Bwietli\\u0107 tylko szczeg\\u00F3\\u0142y kontakt\\u00F3w przypisanych do tego konta\r\n\r\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\r\nMSG_EXCEEDING_FILE_NAME_LENGTH=Nazwa pliku mo\\u017Ce zawiera\\u0107 maksymalnie 40 znak\\u00F3w.\r\n\r\n# XTOL, 20: tooltip shown on search result list for button to add an account"\r\nADD_ACCOUNT_TOOLTIP=Dodaj klienta\r\n\r\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\r\nADD_MARKETING_ATTRIBUTE_TOOLTIP=Dodaj atrybut marketingowy\r\n\r\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\r\nADD_CONTACT_TOOLTIP=Dodaj kontakt\r\n\r\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\r\nADD_APPOINTMENT_TOOLTIP=Dodaj spotkanie\r\n\r\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\r\nADD_TASK_TOOLTIP=Dodaj zadanie\r\n\r\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\r\nADD_OPPORTUNITY_TOOLTIP=Dodaj szans\\u0119\r\n',
	"cus/crm/myaccounts/i18n/i18n_pt.properties":'# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XFLD, 30: Facet title for general Data\r\nGENERAL_DATA=Dados gerais\r\n\r\n#XTIT, 40: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=Minhas contas\r\n\r\n#XTIT, 40: this is the title for the detail screen\r\nDETAIL_TITLE=Conta\r\n\r\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\r\nREVENUE_CURRENT=Receita acum.anual\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\r\nREVENUE_CURRENT_TOOLTIP=Receita at\\u00E9 o ano atual\r\n\r\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\r\nREVENUE_LAST=Rec.ano passado\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\r\nREVENUE_LAST_TOOLTIP=Receita ano passado\r\n\r\n# XFLD, 30: Facet title for opportunities and label in facet general data\r\nOPPORTUNITIES=Oportunidades\r\n\r\n#XFLD, 30: Facet title for leads\r\nLEADS=Leads\r\n\r\n#XFLD, 30: Facet title for tasks\r\nTASKS=Tarefas\r\n\r\n#XFLD, 30: Facet title for appointments\r\nAPPOINTMENTS=Compromissos\r\n\r\n#XFLD, 30: Facet title for quotations\r\nQUOTATIONS=Cota\\u00E7\\u00F5es\r\n\r\n#XFLD, 30: Facet title for sales orders\r\nSALES_ORDERS=Pedidos do cliente\r\n\r\n#XFLD, 30: W7: Facet title for marketing attributes\r\nMARKETINGATTRIBUTES=Atributos de marketing\r\n\r\n#XFLD, 30: W6: Title for popup with products\r\nPRODUCTS=Produtos\r\n\r\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\r\nEMPLOYEE_RESPONSIBLE=Funcion\\u00E1rio respons\\u00E1vel\r\n\r\n#XFLD, 30: Facet title for Attachments\r\nATTACHMENTS=Anexos\r\n\r\n#XFLD, 30: Facet title for Notes\r\nNOTES=Notas\r\n\r\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\r\nNEW_NOTE=Nova nota\r\n\r\n#XFLD, 30: Facet title for Contacts\r\nCONTACTS=Contatos\r\n\r\n#XFLD, 30: Label for Address in facet general data\r\nADDRESS=Endere\\u00E7o\r\n\r\n#XFLD, 30: Label for Opportunities in facet general data\r\nUNWEIGHTED_OPPORTUNITIES=Oportunidades\r\n\r\n#XFLD, 30: Label for Rating in facet general data\r\nRATING=Classifica\\u00E7\\u00E3o\r\n\r\n# XFLD, 30: Label for Next contact in facet Appointments\r\nNEXT_APPOINTMENT=Pr\\u00F3ximo compromisso\r\n\r\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\r\nLAST_APPOINTMENT=\\u00DAltimo compromisso\r\n\r\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\r\nIMAGE=Imagem\r\n\r\n#XBUT, 20: Button to show the create actionsheet\r\nCREATE=Criar\r\n\r\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\r\nDISCUSS_ENTRY=Discutir no SAP Jam\r\n\r\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\r\nSHARE_ENTRY=Compartilhar em SAP Jam\r\n\r\n#XBUT, 20: Button to share the note\r\nDETAIL_BUTTON_SHARE=Compartilhar\r\n\r\n#XBUT, 20: Button to cancel sharing\r\nDETAIL_BUTTON_CANCEL=Anular\r\n\r\n#XFLD,20: All accounts for filter\r\nALL_ACCOUNTS=Todas as contas\r\n\r\n#XFLD,35: All individual accounts for filter\r\nALL_INDIVIDUAL_ACCOUNTS=Todas as contas individuais\r\n\r\n#XFLD,35: All corporate accounts for filter\r\nALL_CORPORATE_ACCOUNTS=Todas as contas corporate\r\n\r\n#XFLD,35: All group accounts for filter\r\nALL_ACCOUNT_GROUPS=Todos os grupos de conta\r\n\r\n#XFLD,20: my account for filter\r\nMY_ACCOUNT=Minhas contas\r\n\r\n#XFLD,35: my individual accounts for filter\r\nMY_INDIVIDUAL_ACCOUNTS=Minhas contas individuais\r\n\r\n#XFLD,35: my corporate accounts for filter\r\nMY_CORPORATE_ACCOUNTS=Minhas contas corporate\r\n\r\n#XFLD,35: my group accounts for filter\r\nMY_ACCOUNT_GROUPS=Meus grupos de contas\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nINDIVIDUAL_ACCOUNT=Conta individual\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nCORPORATE_ACCOUNT=Conta corporate\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nACCOUNT_GROUP=Grupo de contas\r\n\r\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\r\nSTARTING=Data de in\\u00EDcio\\: {0}\r\n\r\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\r\nCLOSING=Data de encerramento\\: {0}\r\n\r\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\r\nDUE=Prazo\\: {0}\r\n\r\n#XFLD,20: All accounts for title\r\nALL_ACCOUNTS_TITLE=Todas as contas ({0})\r\n\r\n#XFLD,35: All individual accounts for title\r\nALL_INDIVIDUAL_ACCOUNTS_TITLE=Todas as contas individuais ({0})\r\n\r\n#XFLD,35: All corporate accounts for title\r\nALL_CORPORATE_ACCOUNTS_TITLE=Todas as contas corporate ({0})\r\n\r\n#XFLD,35: All group accounts for title\r\nALL_ACCOUNT_GROUPS_TITLE=Todos os grupos de conta ({0})\r\n\r\n#XFLD,20: my account for title\r\nMY_ACCOUNT_TITLE=Minhas contas ({0})\r\n\r\n#XFLD,35: my individual account for title\r\nMY_INDIVIDUAL_ACCOUNT_TITLE=Minhas contas individuais ({0})\r\n\r\n#XFLD,35: my corporate account for title.\r\nMY_CORPORATE_ACCOUNT_TITLE=Minhas contas corporate ({0})\r\n\r\n#XFLD,35: my group account for title\r\nMY_ACCOUNT_GROUP_TITLE=Meus grupos de conta ({0})\r\n\r\n#XFLD,30: filtered by info\r\nFILTERED_BY=Filtrado por\\: {0}\r\n\r\n#XFLD,30: label, search for accounts\r\nSEARCH_ACCOUNTS=Procurar\r\n\r\n#XFLD,30: comma separator for location\r\nLOCATION={0}, {1}\r\n\r\n#XFLD: W4: Label for All day text in Appointments\r\nALL_DAY_EVENT=O dia inteiro\r\n\r\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\r\nDURATION_MINUTE={0} min\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\r\nDURATION_HOUR={0} h\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\r\nDURATION_DAY={0} dia\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\r\nDURATION_DAYS={0} dias\r\n\r\n#XFLD: W4: Label for Private meeting\r\nPRIVATE=Privado\r\n\r\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\r\nSELECT_TRANSACTION_TYPE=Selecionar tipo de transa\\u00E7\\u00E3o\r\n\r\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\r\nNEW_TASK_INPUT_PLACEHOLDER=Nova tarefa\r\n\r\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nNO_DATA_TEXT=Sem dados\r\n\r\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nLOADING_TEXT=Carregando...\r\n\r\n#XFLD,25: W4: Column label for name of contact person in contacts\r\nNAME=Nome\r\n\r\n#XFLD,25: W5: Column label for department of contact person in contacts\r\nDEPARTMENT=Departamento\r\n\r\n#XFLD,15: W6: Column label for actions of contact person in contacts\r\nACTIONS=A\\u00E7\\u00F5es\r\n\r\n#XFLD,25: W4: Column label for description of lead in Leads\r\nDESCRIPTION=Descri\\u00E7\\u00E3o\r\n\r\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\r\nASSIGNED_TO=Atribu\\u00EDdo a\r\n\r\n#XFLD,15: W4: Column label for end date of lead in Leads\r\nEND_DATE=Data final\r\n\r\n#XFLD,15: W4: Column label for qualification level of lead in Leads\r\nQUALIFICATION=Qualifica\\u00E7\\u00E3o\r\n\r\n#XFLD,15: W4: Column label for status of lead in Leads\r\nSTATUS=Status\r\n\r\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\r\nMAIN_CONTACT=Contato principal\r\n\r\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\r\nVOLUME=Volume\r\n\r\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\r\nPROBABILITY=Probabilidade\r\n\r\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\r\nCLOSE_BY=Encerramento at\\u00E9\r\n\r\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \r\nVIEWS=Vis\\u00F5es\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\r\nCONTACT_TITLE=Contato\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\r\nEMPLOYEE_TITLE=Funcion\\u00E1rio\r\n\r\n#XTIT,20: W7: Title of pop-up used in confirm popup\r\nCONFIRM_TITLE=Confirmar\r\n\r\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\r\nCOMPANY_NAME=Nome\r\n\r\n#XFLD,20: W4: Label for name 1 of a company used general data\r\nCOMPANY_NAME1=Nome 1\r\n\r\n#XFLD,20: W4: Label for name 2 of a company used general data\r\nCOMPANY_NAME2=Nome 2\r\n\r\n#XFLD,20: W4: Label for first name of a person used general data\r\nFIRST_NAME=1\\u00BA nome\r\n\r\n#XFLD,20: W4: Label for last name of a person used general data\r\nLAST_NAME=Sobrenome\r\n\r\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nBIRTHDAY=Data de nascimento\r\n\r\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nTITLE=T\\u00EDtulo\r\n\r\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nACADEMIC_TITLE=T\\u00EDtulo acad\\u00EAmico\r\n\r\n#XFLD,20: W4: Label for mobile phone number used general data\r\nMOBILE=Celular\r\n\r\n#XFLD,20: W4: Label for phone number used general data\r\nPHONE=Telefone\r\n\r\n#XFLD,20: W4: Label for e-mail used general data\r\nEMAIL=E-mail\r\n\r\n#XFLD,20: W4: Label for web site used general data\r\nWEBSITE=Site da Web\r\n\r\n#XFLD,20: W4: Label for country used general data\r\nCOUNTRY=Pa\\u00EDs\r\n\r\n#XFLD,20: W4: Label for region used general data\r\nREGION=Regi\\u00E3o\r\n\r\n#XFLD,20: W4: Label for city used general data\r\nCITY=Cidade\r\n\r\n#XFLD,20: W4: Label for postal code used general data\r\nPOSTAL_CODE=C\\u00F3digo postal\r\n\r\n#XFLD,20: W4: Label for street used general data\r\nSTREET=Rua\r\n\r\n#XFLD,10: W4: Label for house number used general data\r\nHOUSE_NUMBER=N\\u00BA casa\r\n\r\n#XFLD,15: W6: Label for ID used in Quotations\r\nID=ID\r\n\r\n#XFLD,15: W6: Label for Amount used in Quotations\r\nAMOUNT=Montante\r\n\r\n#XFLD,20: W6: Label for Expiration Date used in Quotations\r\nEXPIRATION_DATE=Data de vencimento\r\n\r\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\r\nDELIVERY_DATE=Data do fornecimento\r\n\r\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\r\nSALES_EMPLOYEE=Representante vendas\r\n\r\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\r\nATTRIBUTESET=Set de atributos\r\n\r\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\r\nATTRIBUTE=Atributo\r\n\r\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\r\nVALUE=Valor\r\n\r\n#XBUT, 20: Button to create an Account\r\nBUTTON_ADD=Adicionar\r\n\r\n#XBUT, 20: Button to edit an Account\r\nBUTTON_EDIT=Editar\r\n\r\n#XBUT, 20: Button to save changes\r\nBUTTON_SAVE=Gravar\r\n\r\n#XBUT, 20: Button to cancel changes\r\nBUTTON_CANCEL=Cancelar\r\n\r\n#XBUT, 30: Button which shows the personalization buttons\r\nBUTTON_SHOW_PERSONALIZATION=Exibir personaliza\\u00E7\\u00E3o\r\n\r\n#XBUT, 30: Button which hides the personalization buttons\r\nBUTTON_HIDE_PERSONALIZATION=Ocultar personaliza\\u00E7\\u00E3o\r\n\r\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_CONFIRM_CANCEL=As modifica\\u00E7\\u00F5es n\\u00E3o gravadas se perder\\u00E3o. Continuar?\r\n\r\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\r\nMSG_CONFIRM_DELETE_CONTACT=A atribui\\u00E7\\u00E3o do contato \\u00E0 conta ser\\u00E1 eliminada. Continuar?\r\n\r\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_SUCCESS=Conta atualizada\r\n\r\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_ERROR=Falha ao atualizar\r\n\r\n# XMSG : Account update succeeded\r\nMSG_CREATION_SUCCESS=Conta criada\r\n\r\n# XMSG : Task creation succeeded\r\nMSG_TASK_CREATION_SUCCESS=Tarefa criada\r\n\r\n# XMSG : Contact creation failed\r\nMSG_CREATION_ERROR=Falha ao criar\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong country\r\nMSG_WRONG_COUNTRY_ERROR=O pa\\u00EDs "{0}" n\\u00E3o existe\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong region\r\nMSG_WRONG_REGION_ERROR=A regi\\u00E3o "{0}" n\\u00E3o existe para o pa\\u00EDs\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong employee\r\nMSG_WRONG_EMPLOYEE_ERROR=O funcion\\u00E1rio "{0}" n\\u00E3o existe.\r\n\r\n# XMSG: message that will be displayed, if the user has entered invalid website url\r\nMSG_WRONG_URL_ERROR=O URL inserido "{0}" n\\u00E3o \\u00E9 v\\u00E1lido.\r\n\r\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\r\nMSG_MANDATORY_FIELDS=Nem todos os campos obrigat\\u00F3rios foram preenchidos\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA=Os dados foram modificados por outro usu\\u00E1rio. Sobregravar as modifica\\u00E7\\u00F5es do outro usu\\u00E1rio com suas pr\\u00F3prias?\r\n\r\n# XMSG: message that will be displayed in case of conflicts during file renaming\r\nMSG_CONFLICTING_FILE_NAME=O nome do arquivo foi modificado por outro usu\\u00E1rio. Sobregravar as modifica\\u00E7\\u00F5es do outro usu\\u00E1rio com suas pr\\u00F3prias?\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA_WITH_REFRESH=Dados modificados por outro usu\\u00E1rio. Estas modifica\\u00E7\\u00F5es aparecer\\u00E3o agora no app.\r\n\r\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\r\nMSG_NOT_IN_MAIN_CONTACT=S\\u00F3 \\u00E9 poss\\u00EDvel exibir detalhes de contatos atribu\\u00EDdos a esta conta\r\n\r\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\r\nMSG_EXCEEDING_FILE_NAME_LENGTH=Seu nome de arquivo pode ter no m\\u00E1ximo 40 caracteres.\r\n\r\n# XTOL, 20: tooltip shown on search result list for button to add an account"\r\nADD_ACCOUNT_TOOLTIP=Adicionar conta\r\n\r\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\r\nADD_MARKETING_ATTRIBUTE_TOOLTIP=Adicionar atributo de marketing\r\n\r\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\r\nADD_CONTACT_TOOLTIP=Inserir contato\r\n\r\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\r\nADD_APPOINTMENT_TOOLTIP=Adicionar compromisso\r\n\r\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\r\nADD_TASK_TOOLTIP=Adicionar tarefa\r\n\r\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\r\nADD_OPPORTUNITY_TOOLTIP=Adicionar oportunidade\r\n',
	"cus/crm/myaccounts/i18n/i18n_ro.properties":'# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XFLD, 30: Facet title for general Data\r\nGENERAL_DATA=Date generale\r\n\r\n#XTIT, 40: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=Conturile mele\r\n\r\n#XTIT, 40: this is the title for the detail screen\r\nDETAIL_TITLE=Cont\r\n\r\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\r\nREVENUE_CURRENT=VenitCumulatPnLaAn\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\r\nREVENUE_CURRENT_TOOLTIP=Venit cumulat pe an p\\u00E2n\\u0103 la dat\\u0103 curent\\u0103\r\n\r\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\r\nREVENUE_LAST=Venit anul trecut\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\r\nREVENUE_LAST_TOOLTIP=Venit anul trecut\r\n\r\n# XFLD, 30: Facet title for opportunities and label in facet general data\r\nOPPORTUNITIES=Oportunit\\u0103\\u0163i\r\n\r\n#XFLD, 30: Facet title for leads\r\nLEADS=Interese poten\\u0163iale\r\n\r\n#XFLD, 30: Facet title for tasks\r\nTASKS=Sarcini\r\n\r\n#XFLD, 30: Facet title for appointments\r\nAPPOINTMENTS=\\u00CEnt\\u00E2lniri fixate\r\n\r\n#XFLD, 30: Facet title for quotations\r\nQUOTATIONS=Oferte\r\n\r\n#XFLD, 30: Facet title for sales orders\r\nSALES_ORDERS=Comenzi de v\\u00E2nz\\u0103ri\r\n\r\n#XFLD, 30: W7: Facet title for marketing attributes\r\nMARKETINGATTRIBUTES=Atribute de marketing\r\n\r\n#XFLD, 30: W6: Title for popup with products\r\nPRODUCTS=Produse\r\n\r\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\r\nEMPLOYEE_RESPONSIBLE=Angajat responsabil\r\n\r\n#XFLD, 30: Facet title for Attachments\r\nATTACHMENTS=Anexe\r\n\r\n#XFLD, 30: Facet title for Notes\r\nNOTES=Note\r\n\r\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\r\nNEW_NOTE=Not\\u0103 nou\\u0103\r\n\r\n#XFLD, 30: Facet title for Contacts\r\nCONTACTS=Persoane de contact\r\n\r\n#XFLD, 30: Label for Address in facet general data\r\nADDRESS=Adres\\u0103\r\n\r\n#XFLD, 30: Label for Opportunities in facet general data\r\nUNWEIGHTED_OPPORTUNITIES=Oportunit\\u0103\\u0163i\r\n\r\n#XFLD, 30: Label for Rating in facet general data\r\nRATING=Evaluare\r\n\r\n# XFLD, 30: Label for Next contact in facet Appointments\r\nNEXT_APPOINTMENT=\\u00CEnt\\u00E2lnire fixat\\u0103 urm\\u0103toare\r\n\r\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\r\nLAST_APPOINTMENT=Ultima \\u00EEnt\\u00E2lnire fixat\\u0103\r\n\r\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\r\nIMAGE=Imagine\r\n\r\n#XBUT, 20: Button to show the create actionsheet\r\nCREATE=Creare\r\n\r\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\r\nDISCUSS_ENTRY=Discutare pe SAP Jam\r\n\r\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\r\nSHARE_ENTRY=Partajare pe SAP Jam\r\n\r\n#XBUT, 20: Button to share the note\r\nDETAIL_BUTTON_SHARE=Partajare\r\n\r\n#XBUT, 20: Button to cancel sharing\r\nDETAIL_BUTTON_CANCEL=Anulare\r\n\r\n#XFLD,20: All accounts for filter\r\nALL_ACCOUNTS=Toate conturile\r\n\r\n#XFLD,35: All individual accounts for filter\r\nALL_INDIVIDUAL_ACCOUNTS=Toate conturile individuale\r\n\r\n#XFLD,35: All corporate accounts for filter\r\nALL_CORPORATE_ACCOUNTS=Toate conturile de companie\r\n\r\n#XFLD,35: All group accounts for filter\r\nALL_ACCOUNT_GROUPS=Toate grupurile de conturi\r\n\r\n#XFLD,20: my account for filter\r\nMY_ACCOUNT=Conturile mele\r\n\r\n#XFLD,35: my individual accounts for filter\r\nMY_INDIVIDUAL_ACCOUNTS=Conturile mele individuale\r\n\r\n#XFLD,35: my corporate accounts for filter\r\nMY_CORPORATE_ACCOUNTS=Conturile mele de companie\r\n\r\n#XFLD,35: my group accounts for filter\r\nMY_ACCOUNT_GROUPS=Grupurile mele de conturi\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nINDIVIDUAL_ACCOUNT=Cont individual\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nCORPORATE_ACCOUNT=Cont de companie\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nACCOUNT_GROUP=Grup conturi\r\n\r\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\r\nSTARTING=Dat\\u0103 de \\u00EEnceput\\: {0}\r\n\r\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\r\nCLOSING=Dat\\u0103 de \\u00EEnchidere\\: {0}\r\n\r\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\r\nDUE=Dat\\u0103 scaden\\u0163\\u0103\\: {0}\r\n\r\n#XFLD,20: All accounts for title\r\nALL_ACCOUNTS_TITLE=Toate conturile ({0})\r\n\r\n#XFLD,35: All individual accounts for title\r\nALL_INDIVIDUAL_ACCOUNTS_TITLE=Toate conturile individuale ({0})\r\n\r\n#XFLD,35: All corporate accounts for title\r\nALL_CORPORATE_ACCOUNTS_TITLE=Toate conturile de companie ({0})\r\n\r\n#XFLD,35: All group accounts for title\r\nALL_ACCOUNT_GROUPS_TITLE=Toate grupurile de conturi ({0})\r\n\r\n#XFLD,20: my account for title\r\nMY_ACCOUNT_TITLE=Conturile mele ({0})\r\n\r\n#XFLD,35: my individual account for title\r\nMY_INDIVIDUAL_ACCOUNT_TITLE=Conturile mele individuale ({0})\r\n\r\n#XFLD,35: my corporate account for title.\r\nMY_CORPORATE_ACCOUNT_TITLE=Conturile mele de companie ({0})\r\n\r\n#XFLD,35: my group account for title\r\nMY_ACCOUNT_GROUP_TITLE=Grupurile mele de conturi ({0})\r\n\r\n#XFLD,30: filtered by info\r\nFILTERED_BY=Filtrat dup\\u0103\\: {0}\r\n\r\n#XFLD,30: label, search for accounts\r\nSEARCH_ACCOUNTS=C\\u0103utare\r\n\r\n#XFLD,30: comma separator for location\r\nLOCATION={0}, {1}\r\n\r\n#XFLD: W4: Label for All day text in Appointments\r\nALL_DAY_EVENT=Toat\\u0103 ziua\r\n\r\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\r\nDURATION_MINUTE={0} min\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\r\nDURATION_HOUR={0} h\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\r\nDURATION_DAY={0} zi\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\r\nDURATION_DAYS={0} zile\r\n\r\n#XFLD: W4: Label for Private meeting\r\nPRIVATE=Privat\r\n\r\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\r\nSELECT_TRANSACTION_TYPE=Selectare tip de opera\\u0163ie\r\n\r\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\r\nNEW_TASK_INPUT_PLACEHOLDER=Sarcin\\u0103 nou\\u0103\r\n\r\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nNO_DATA_TEXT=F\\u0103r\\u0103 date\r\n\r\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nLOADING_TEXT=\\u00CEnc\\u0103rcare ...\r\n\r\n#XFLD,25: W4: Column label for name of contact person in contacts\r\nNAME=Nume\r\n\r\n#XFLD,25: W5: Column label for department of contact person in contacts\r\nDEPARTMENT=Departament\r\n\r\n#XFLD,15: W6: Column label for actions of contact person in contacts\r\nACTIONS=Ac\\u0163iuni\r\n\r\n#XFLD,25: W4: Column label for description of lead in Leads\r\nDESCRIPTION=Descriere\r\n\r\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\r\nASSIGNED_TO=Alocat la\r\n\r\n#XFLD,15: W4: Column label for end date of lead in Leads\r\nEND_DATE=Dat\\u0103 de sf\\u00E2r\\u015Fit\r\n\r\n#XFLD,15: W4: Column label for qualification level of lead in Leads\r\nQUALIFICATION=Calificare\r\n\r\n#XFLD,15: W4: Column label for status of lead in Leads\r\nSTATUS=Stare\r\n\r\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\r\nMAIN_CONTACT=Persoan\\u0103 contact princip.\r\n\r\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\r\nVOLUME=Volum\r\n\r\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\r\nPROBABILITY=Probabilitate\r\n\r\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\r\nCLOSE_BY=\\u00CEnchidere p\\u00E2n\\u0103 la\r\n\r\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \r\nVIEWS=Imagini\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\r\nCONTACT_TITLE=Persoan\\u0103 de contact\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\r\nEMPLOYEE_TITLE=Angajat\r\n\r\n#XTIT,20: W7: Title of pop-up used in confirm popup\r\nCONFIRM_TITLE=Confirmare\r\n\r\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\r\nCOMPANY_NAME=Nume\r\n\r\n#XFLD,20: W4: Label for name 1 of a company used general data\r\nCOMPANY_NAME1=Nume 1\r\n\r\n#XFLD,20: W4: Label for name 2 of a company used general data\r\nCOMPANY_NAME2=Nume 2\r\n\r\n#XFLD,20: W4: Label for first name of a person used general data\r\nFIRST_NAME=Prenume\r\n\r\n#XFLD,20: W4: Label for last name of a person used general data\r\nLAST_NAME=Nume familie\r\n\r\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nBIRTHDAY=Dat\\u0103 de na\\u015Ftere\r\n\r\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nTITLE=Titlu\r\n\r\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nACADEMIC_TITLE=Titlu academic\r\n\r\n#XFLD,20: W4: Label for mobile phone number used general data\r\nMOBILE=Telefon mobil\r\n\r\n#XFLD,20: W4: Label for phone number used general data\r\nPHONE=Telefon\r\n\r\n#XFLD,20: W4: Label for e-mail used general data\r\nEMAIL=E-mail\r\n\r\n#XFLD,20: W4: Label for web site used general data\r\nWEBSITE=Site web\r\n\r\n#XFLD,20: W4: Label for country used general data\r\nCOUNTRY=\\u0162ar\\u0103\r\n\r\n#XFLD,20: W4: Label for region used general data\r\nREGION=Regiune\r\n\r\n#XFLD,20: W4: Label for city used general data\r\nCITY=Localitate\r\n\r\n#XFLD,20: W4: Label for postal code used general data\r\nPOSTAL_CODE=Cod po\\u015Ftal\r\n\r\n#XFLD,20: W4: Label for street used general data\r\nSTREET=Strad\\u0103\r\n\r\n#XFLD,10: W4: Label for house number used general data\r\nHOUSE_NUMBER=Nr.cas\\u0103\r\n\r\n#XFLD,15: W6: Label for ID used in Quotations\r\nID=ID\r\n\r\n#XFLD,15: W6: Label for Amount used in Quotations\r\nAMOUNT=Sum\\u0103\r\n\r\n#XFLD,20: W6: Label for Expiration Date used in Quotations\r\nEXPIRATION_DATE=Dat\\u0103 de expirare\r\n\r\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\r\nDELIVERY_DATE=Dat\\u0103 livrare\r\n\r\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\r\nSALES_EMPLOYEE=Angajat v\\u00E2nz\\u0103ri\r\n\r\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\r\nATTRIBUTESET=Set de atribute\r\n\r\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\r\nATTRIBUTE=Atribut\r\n\r\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\r\nVALUE=Valoare\r\n\r\n#XBUT, 20: Button to create an Account\r\nBUTTON_ADD=Ad\\u0103ugare\r\n\r\n#XBUT, 20: Button to edit an Account\r\nBUTTON_EDIT=Editare\r\n\r\n#XBUT, 20: Button to save changes\r\nBUTTON_SAVE=Salvare\r\n\r\n#XBUT, 20: Button to cancel changes\r\nBUTTON_CANCEL=Anulare\r\n\r\n#XBUT, 30: Button which shows the personalization buttons\r\nBUTTON_SHOW_PERSONALIZATION=Prezentare personalizare\r\n\r\n#XBUT, 30: Button which hides the personalization buttons\r\nBUTTON_HIDE_PERSONALIZATION=Mascare personalizare\r\n\r\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_CONFIRM_CANCEL=Orice modific\\u0103ri nesalvate vor fi pierdute. Dori\\u0163i s\\u0103 continua\\u0163i?\r\n\r\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\r\nMSG_CONFIRM_DELETE_CONTACT=Alocare persoan\\u0103 de contact la cont va fi anulat\\u0103. Dori\\u0163i s\\u0103 continua\\u0163i?\r\n\r\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_SUCCESS=Cont actualizat\r\n\r\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_ERROR=Actualizare nereu\\u015Fit\\u0103\r\n\r\n# XMSG : Account update succeeded\r\nMSG_CREATION_SUCCESS=Cont creat\r\n\r\n# XMSG : Task creation succeeded\r\nMSG_TASK_CREATION_SUCCESS=Sarcin\\u0103 creat\\u0103\r\n\r\n# XMSG : Contact creation failed\r\nMSG_CREATION_ERROR=Creare nereu\\u015Fit\\u0103\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong country\r\nMSG_WRONG_COUNTRY_ERROR=\\u0162ara "{0}" nu exist\\u0103\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong region\r\nMSG_WRONG_REGION_ERROR=Regiunea "{0}" nu exist\\u0103 pt. \\u0163ar\\u0103\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong employee\r\nMSG_WRONG_EMPLOYEE_ERROR=Angajatul "{0}" nu exist\\u0103.\r\n\r\n# XMSG: message that will be displayed, if the user has entered invalid website url\r\nMSG_WRONG_URL_ERROR=URL-ul introdus "{0}" nu este valabil.\r\n\r\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\r\nMSG_MANDATORY_FIELDS=Nu toate c\\u00E2mpurile de intrare obligatorie sunt completate\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA=Datele au fost modificate de alt utilizator. Dori\\u0163i s\\u0103 suprascrie\\u0163i modific\\u0103rile celuilalt utilizator cu ale dvs.?\r\n\r\n# XMSG: message that will be displayed in case of conflicts during file renaming\r\nMSG_CONFLICTING_FILE_NAME=Numele de fi\\u015Fier a fost modificat de alt utilizator. Dori\\u0163i s\\u0103 suprascrie\\u0163i modific\\u0103rile celuilalt utilizator cu ale dvs.?\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA_WITH_REFRESH=Datele au fost modificate de alt utilizator. Aceste modific\\u0103ri vor ap\\u0103rea acum \\u00EEn apl.\r\n\r\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\r\nMSG_NOT_IN_MAIN_CONTACT=Pute\\u0163i afi\\u015Fa doar detaliile despre persoanele de contact care sunt alocate la acest cont\r\n\r\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\r\nMSG_EXCEEDING_FILE_NAME_LENGTH=Numele dvs.de fi\\u015Fier poate avea maxim 40 de caractere.\r\n\r\n# XTOL, 20: tooltip shown on search result list for button to add an account"\r\n\r\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\r\n\r\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\r\n\r\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\r\n\r\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\r\n\r\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\r\n',
	"cus/crm/myaccounts/i18n/i18n_ru.properties":'# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XFLD, 30: Facet title for general Data\r\nGENERAL_DATA=\\u041E\\u0431\\u0449\\u0438\\u0435 \\u0434\\u0430\\u043D\\u043D\\u044B\\u0435\r\n\r\n#XTIT, 40: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=\\u041C\\u043E\\u0438 \\u043A\\u043B\\u0438\\u0435\\u043D\\u0442\\u044B\r\n\r\n#XTIT, 40: this is the title for the detail screen\r\nDETAIL_TITLE=\\u041A\\u043B\\u0438\\u0435\\u043D\\u0442\r\n\r\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\r\nREVENUE_CURRENT=\\u0412\\u044B\\u0440\\u0443\\u0447\\u043A\\u0430 \\u043D\\u0430 \\u0434\\u0430\\u0442\\u0443\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\r\nREVENUE_CURRENT_TOOLTIP=\\u0412\\u044B\\u0440\\u0443\\u0447\\u043A\\u0430 \\u043D\\u0430 \\u0434\\u0430\\u0442\\u0443 \\u0442\\u0435\\u043A\\u0443\\u0449\\u0435\\u0433\\u043E \\u0433\\u043E\\u0434\\u0430\r\n\r\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\r\nREVENUE_LAST=\\u0412\\u044B\\u0440\\u0443\\u0447\\u043A\\u0430/\\u043F\\u043E\\u0441\\u043B. \\u0433\\u043E\\u0434\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\r\nREVENUE_LAST_TOOLTIP=\\u0412\\u044B\\u0440\\u0443\\u0447\\u043A\\u0430 \\u0437\\u0430 \\u043F\\u043E\\u0441\\u043B\\u0435\\u0434\\u043D\\u0438\\u0439 \\u0433\\u043E\\u0434\r\n\r\n# XFLD, 30: Facet title for opportunities and label in facet general data\r\nOPPORTUNITIES=\\u0412\\u043E\\u0437\\u043C\\u043E\\u0436\\u043D\\u043E\\u0441\\u0442\\u0438\r\n\r\n#XFLD, 30: Facet title for leads\r\nLEADS=\\u041F\\u043E\\u0442\\u0435\\u043D\\u0446\\u0438\\u0430\\u043B\\u044C\\u043D\\u044B\\u0435 \\u0432\\u043E\\u0437\\u043C\\u043E\\u0436\\u043D\\u043E\\u0441\\u0442\\u0438\r\n\r\n#XFLD, 30: Facet title for tasks\r\nTASKS=\\u0417\\u0430\\u0434\\u0430\\u0447\\u0438\r\n\r\n#XFLD, 30: Facet title for appointments\r\nAPPOINTMENTS=\\u0412\\u0441\\u0442\\u0440\\u0435\\u0447\\u0438\r\n\r\n#XFLD, 30: Facet title for quotations\r\nQUOTATIONS=\\u041F\\u0440\\u0435\\u0434\\u043B\\u043E\\u0436\\u0435\\u043D\\u0438\\u044F\r\n\r\n#XFLD, 30: Facet title for sales orders\r\nSALES_ORDERS=\\u0417\\u0430\\u043A\\u0430\\u0437\\u044B \\u043A\\u043B\\u0438\\u0435\\u043D\\u0442\\u0430\r\n\r\n#XFLD, 30: W7: Facet title for marketing attributes\r\nMARKETINGATTRIBUTES=\\u041C\\u0430\\u0440\\u043A\\u0435\\u0442\\u0438\\u043D\\u0433\\u043E\\u0432\\u044B\\u0435 \\u0430\\u0442\\u0440\\u0438\\u0431\\u0443\\u0442\\u044B\r\n\r\n#XFLD, 30: W6: Title for popup with products\r\nPRODUCTS=\\u041F\\u0440\\u043E\\u0434\\u0443\\u043A\\u0442\\u044B\r\n\r\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\r\nEMPLOYEE_RESPONSIBLE=\\u041E\\u0442\\u0432\\u0435\\u0442\\u0441\\u0442\\u0432\\u0435\\u043D\\u043D\\u044B\\u0439 \\u0441\\u043E\\u0442\\u0440\\u0443\\u0434\\u043D\\u0438\\u043A\r\n\r\n#XFLD, 30: Facet title for Attachments\r\nATTACHMENTS=\\u0412\\u043B\\u043E\\u0436\\u0435\\u043D\\u0438\\u044F\r\n\r\n#XFLD, 30: Facet title for Notes\r\nNOTES=\\u041F\\u0440\\u0438\\u043C\\u0435\\u0447\\u0430\\u043D\\u0438\\u044F\r\n\r\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\r\nNEW_NOTE=\\u041D\\u043E\\u0432\\u043E\\u0435 \\u043F\\u0440\\u0438\\u043C\\u0435\\u0447\\u0430\\u043D\\u0438\\u0435\r\n\r\n#XFLD, 30: Facet title for Contacts\r\nCONTACTS=\\u041A\\u043E\\u043D\\u0442\\u0430\\u043A\\u0442\\u044B\r\n\r\n#XFLD, 30: Label for Address in facet general data\r\nADDRESS=\\u0410\\u0434\\u0440\\u0435\\u0441\r\n\r\n#XFLD, 30: Label for Opportunities in facet general data\r\nUNWEIGHTED_OPPORTUNITIES=\\u0412\\u043E\\u0437\\u043C\\u043E\\u0436\\u043D\\u043E\\u0441\\u0442\\u0438\r\n\r\n#XFLD, 30: Label for Rating in facet general data\r\nRATING=\\u0420\\u0435\\u0439\\u0442\\u0438\\u043D\\u0433\r\n\r\n# XFLD, 30: Label for Next contact in facet Appointments\r\nNEXT_APPOINTMENT=\\u0421\\u043B\\u0435\\u0434\\u0443\\u044E\\u0449\\u0430\\u044F \\u0432\\u0441\\u0442\\u0440\\u0435\\u0447\\u0430\r\n\r\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\r\nLAST_APPOINTMENT=\\u041F\\u043E\\u0441\\u043B\\u0435\\u0434\\u043D\\u044F\\u044F \\u0432\\u0441\\u0442\\u0440\\u0435\\u0447\\u0430\r\n\r\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\r\nIMAGE=\\u0418\\u0437\\u043E\\u0431\\u0440\\u0430\\u0436.\r\n\r\n#XBUT, 20: Button to show the create actionsheet\r\nCREATE=\\u0421\\u043E\\u0437\\u0434\\u0430\\u0442\\u044C\r\n\r\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\r\nDISCUSS_ENTRY=\\u0414\\u0438\\u0441\\u043A\\u0443\\u0441\\u0441\\u0438\\u044F \\u0432 SAP Jam\r\n\r\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\r\nSHARE_ENTRY=\\u041E\\u043F\\u0443\\u0431\\u043B\\u0438\\u043A\\u043E\\u0432\\u0430\\u0442\\u044C \\u0432 SAP Jam\r\n\r\n#XBUT, 20: Button to share the note\r\nDETAIL_BUTTON_SHARE=\\u041F\\u043E\\u0434\\u0435\\u043B\\u0438\\u0442\\u044C\\u0441\\u044F\r\n\r\n#XBUT, 20: Button to cancel sharing\r\nDETAIL_BUTTON_CANCEL=\\u041E\\u0442\\u043C\\u0435\\u043D\\u0438\\u0442\\u044C\r\n\r\n#XFLD,20: All accounts for filter\r\nALL_ACCOUNTS=\\u0412\\u0441\\u0435 \\u043A\\u043B\\u0438\\u0435\\u043D\\u0442\\u044B\r\n\r\n#XFLD,35: All individual accounts for filter\r\nALL_INDIVIDUAL_ACCOUNTS=\\u0412\\u0441\\u0435 \\u0438\\u043D\\u0434\\u0438\\u0432\\u0438\\u0434\\u0443\\u0430\\u043B\\u044C\\u043D\\u044B\\u0435 \\u043A\\u043B\\u0438\\u0435\\u043D\\u0442\\u044B\r\n\r\n#XFLD,35: All corporate accounts for filter\r\nALL_CORPORATE_ACCOUNTS=\\u0412\\u0441\\u0435 \\u043A\\u043E\\u0440\\u043F\\u043E\\u0440\\u0430\\u0442\\u0438\\u0432\\u043D\\u044B\\u0435 \\u043A\\u043B\\u0438\\u0435\\u043D\\u0442\\u044B\r\n\r\n#XFLD,35: All group accounts for filter\r\nALL_ACCOUNT_GROUPS=\\u0412\\u0441\\u0435 \\u0433\\u0440\\u0443\\u043F\\u043F\\u044B \\u043A\\u043B\\u0438\\u0435\\u043D\\u0442\\u043E\\u0432\r\n\r\n#XFLD,20: my account for filter\r\nMY_ACCOUNT=\\u041C\\u043E\\u0438 \\u043A\\u043B\\u0438\\u0435\\u043D\\u0442\\u044B\r\n\r\n#XFLD,35: my individual accounts for filter\r\nMY_INDIVIDUAL_ACCOUNTS=\\u041C\\u043E\\u0438 \\u0438\\u043D\\u0434\\u0438\\u0432\\u0438\\u0434\\u0443\\u0430\\u043B\\u044C\\u043D\\u044B\\u0435 \\u043A\\u043B\\u0438\\u0435\\u043D\\u0442\\u044B\r\n\r\n#XFLD,35: my corporate accounts for filter\r\nMY_CORPORATE_ACCOUNTS=\\u041C\\u043E\\u0438 \\u043A\\u043E\\u0440\\u043F\\u043E\\u0440\\u0430\\u0442\\u0438\\u0432\\u043D\\u044B\\u0435 \\u043A\\u043B\\u0438\\u0435\\u043D\\u0442\\u044B\r\n\r\n#XFLD,35: my group accounts for filter\r\nMY_ACCOUNT_GROUPS=\\u041C\\u043E\\u0438 \\u0433\\u0440\\u0443\\u043F\\u043F\\u044B \\u043A\\u043B\\u0438\\u0435\\u043D\\u0442\\u043E\\u0432\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nINDIVIDUAL_ACCOUNT=\\u0418\\u043D\\u0434\\u0438\\u0432\\u0438\\u0434\\u0443\\u0430\\u043B\\u044C\\u043D\\u044B\\u0439 \\u043A\\u043B\\u0438\\u0435\\u043D\\u0442\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nCORPORATE_ACCOUNT=\\u041A\\u043E\\u0440\\u043F\\u043E\\u0440\\u0430\\u0442\\u0438\\u0432\\u043D\\u044B\\u0439 \\u043A\\u043B\\u0438\\u0435\\u043D\\u0442\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nACCOUNT_GROUP=\\u0413\\u0440\\u0443\\u043F\\u043F\\u0430 \\u043A\\u043B\\u0438\\u0435\\u043D\\u0442\\u043E\\u0432\r\n\r\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\r\nSTARTING=\\u0414\\u0430\\u0442\\u0430 \\u043D\\u0430\\u0447\\u0430\\u043B\\u0430\\: {0}\r\n\r\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\r\nCLOSING=\\u0414\\u0430\\u0442\\u0430 \\u0437\\u0430\\u043A\\u0440\\u044B\\u0442\\u0438\\u044F\\: {0}\r\n\r\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\r\nDUE=\\u0414\\u0430\\u0442\\u0430 \\u0438\\u0441\\u043F\\u043E\\u043B\\u043D\\u0435\\u043D\\u0438\\u044F\\: {0}\r\n\r\n#XFLD,20: All accounts for title\r\nALL_ACCOUNTS_TITLE=\\u0412\\u0441\\u0435 \\u043A\\u043B\\u0438\\u0435\\u043D\\u0442\\u044B ({0})\r\n\r\n#XFLD,35: All individual accounts for title\r\nALL_INDIVIDUAL_ACCOUNTS_TITLE=\\u0412\\u0441\\u0435 \\u0438\\u043D\\u0434\\u0438\\u0432\\u0438\\u0434\\u0443\\u0430\\u043B\\u044C\\u043D\\u044B\\u0435 \\u043A\\u043B\\u0438\\u0435\\u043D\\u0442\\u044B ({0})\r\n\r\n#XFLD,35: All corporate accounts for title\r\nALL_CORPORATE_ACCOUNTS_TITLE=\\u0412\\u0441\\u0435 \\u043A\\u043E\\u0440\\u043F\\u043E\\u0440\\u0430\\u0442\\u0438\\u0432\\u043D\\u044B\\u0435 \\u043A\\u043B\\u0438\\u0435\\u043D\\u0442\\u044B ({0})\r\n\r\n#XFLD,35: All group accounts for title\r\nALL_ACCOUNT_GROUPS_TITLE=\\u0412\\u0441\\u0435 \\u0433\\u0440\\u0443\\u043F\\u043F\\u044B \\u043A\\u043B\\u0438\\u0435\\u043D\\u0442\\u043E\\u0432 ({0})\r\n\r\n#XFLD,20: my account for title\r\nMY_ACCOUNT_TITLE=\\u041C\\u043E\\u0438 \\u043A\\u043B\\u0438\\u0435\\u043D\\u0442\\u044B ({0})\r\n\r\n#XFLD,35: my individual account for title\r\nMY_INDIVIDUAL_ACCOUNT_TITLE=\\u041C\\u043E\\u0438 \\u0438\\u043D\\u0434\\u0438\\u0432\\u0438\\u0434\\u0443\\u0430\\u043B\\u044C\\u043D\\u044B\\u0435 \\u043A\\u043B\\u0438\\u0435\\u043D\\u0442\\u044B ({0})\r\n\r\n#XFLD,35: my corporate account for title.\r\nMY_CORPORATE_ACCOUNT_TITLE=\\u041C\\u043E\\u0438 \\u043A\\u043E\\u0440\\u043F\\u043E\\u0440\\u0430\\u0442\\u0438\\u0432\\u043D\\u044B\\u0435 \\u043A\\u043B\\u0438\\u0435\\u043D\\u0442\\u044B ({0})\r\n\r\n#XFLD,35: my group account for title\r\nMY_ACCOUNT_GROUP_TITLE=\\u041C\\u043E\\u0438 \\u0433\\u0440\\u0443\\u043F\\u043F\\u044B \\u043A\\u043B\\u0438\\u0435\\u043D\\u0442\\u043E\\u0432 ({0})\r\n\r\n#XFLD,30: filtered by info\r\nFILTERED_BY=\\u041E\\u0442\\u0444\\u0438\\u043B\\u044C\\u0442\\u0440\\u043E\\u0432\\u0430\\u043D\\u043E \\u043F\\u043E\\: {0}\r\n\r\n#XFLD,30: label, search for accounts\r\nSEARCH_ACCOUNTS=\\u041F\\u043E\\u0438\\u0441\\u043A\r\n\r\n#XFLD,30: comma separator for location\r\nLOCATION={0}, {1}\r\n\r\n#XFLD: W4: Label for All day text in Appointments\r\nALL_DAY_EVENT=\\u0412\\u0435\\u0441\\u044C \\u0434\\u0435\\u043D\\u044C\r\n\r\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\r\nDURATION_MINUTE={0} \\u043C\\u0438\\u043D\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\r\nDURATION_HOUR={0} \\u0447\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\r\nDURATION_DAY={0} \\u0434\\u0435\\u043D\\u044C\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\r\nDURATION_DAYS={0} \\u0434.\r\n\r\n#XFLD: W4: Label for Private meeting\r\nPRIVATE=\\u041B\\u0438\\u0447\\u043D\\u0430\\u044F\r\n\r\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\r\nSELECT_TRANSACTION_TYPE=\\u0412\\u044B\\u0431\\u043E\\u0440 \\u0442\\u0438\\u043F\\u0430 \\u0442\\u0440\\u0430\\u043D\\u0437\\u0430\\u043A\\u0446\\u0438\\u0438\r\n\r\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\r\nNEW_TASK_INPUT_PLACEHOLDER=\\u041D\\u043E\\u0432\\u0430\\u044F \\u0437\\u0430\\u0434\\u0430\\u0447\\u0430\r\n\r\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nNO_DATA_TEXT=\\u041D\\u0435\\u0442 \\u0434\\u0430\\u043D\\u043D\\u044B\\u0445\r\n\r\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nLOADING_TEXT=\\u0417\\u0430\\u0433\\u0440\\u0443\\u0437\\u043A\\u0430...\r\n\r\n#XFLD,25: W4: Column label for name of contact person in contacts\r\nNAME=\\u0418\\u043C\\u044F\r\n\r\n#XFLD,25: W5: Column label for department of contact person in contacts\r\nDEPARTMENT=\\u041F\\u043E\\u0434\\u0440\\u0430\\u0437\\u0434\\u0435\\u043B\\u0435\\u043D\\u0438\\u0435\r\n\r\n#XFLD,15: W6: Column label for actions of contact person in contacts\r\nACTIONS=\\u041E\\u043F\\u0435\\u0440\\u0430\\u0446\\u0438\\u0438\r\n\r\n#XFLD,25: W4: Column label for description of lead in Leads\r\nDESCRIPTION=\\u041E\\u043F\\u0438\\u0441\\u0430\\u043D\\u0438\\u0435\r\n\r\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\r\nASSIGNED_TO=\\u041F\\u0440\\u0438\\u0441\\u0432\\u043E\\u0435\\u043D\\u043E\r\n\r\n#XFLD,15: W4: Column label for end date of lead in Leads\r\nEND_DATE=\\u041A\\u043E\\u043D\\u0435\\u0447\\u043D\\u0430\\u044F \\u0434\\u0430\\u0442\\u0430\r\n\r\n#XFLD,15: W4: Column label for qualification level of lead in Leads\r\nQUALIFICATION=\\u041A\\u0432\\u0430\\u043B\\u0438\\u0444\\u0438\\u043A\\u0430\\u0446\\u0438\\u044F\r\n\r\n#XFLD,15: W4: Column label for status of lead in Leads\r\nSTATUS=\\u0421\\u0442\\u0430\\u0442\\u0443\\u0441\r\n\r\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\r\nMAIN_CONTACT=\\u041E\\u0441\\u043D\\u043E\\u0432\\u043D\\u043E\\u0439 \\u043A\\u043E\\u043D\\u0442\\u0430\\u043A\\u0442\r\n\r\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\r\nVOLUME=\\u041A\\u043E\\u043B\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u043E\r\n\r\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\r\nPROBABILITY=\\u0412\\u0435\\u0440\\u043E\\u044F\\u0442\\u043D\\u043E\\u0441\\u0442\\u044C\r\n\r\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\r\nCLOSE_BY=\\u0414\\u0430\\u0442\\u0430 \\u0437\\u0430\\u043A\\u0440\\u044B\\u0442\\u0438\\u044F\r\n\r\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \r\nVIEWS=\\u0420\\u0430\\u043A\\u0443\\u0440\\u0441\\u044B\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\r\nCONTACT_TITLE=\\u041A\\u043E\\u043D\\u0442\\u0430\\u043A\\u0442\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\r\nEMPLOYEE_TITLE=\\u0421\\u043E\\u0442\\u0440\\u0443\\u0434\\u043D\\u0438\\u043A\r\n\r\n#XTIT,20: W7: Title of pop-up used in confirm popup\r\nCONFIRM_TITLE=\\u041F\\u043E\\u0434\\u0442\\u0432\\u0435\\u0440\\u0434\\u0438\\u0442\\u044C\r\n\r\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\r\nCOMPANY_NAME=\\u0418\\u043C\\u044F\r\n\r\n#XFLD,20: W4: Label for name 1 of a company used general data\r\nCOMPANY_NAME1=\\u0418\\u043C\\u044F 1\r\n\r\n#XFLD,20: W4: Label for name 2 of a company used general data\r\nCOMPANY_NAME2=\\u0418\\u043C\\u044F 2\r\n\r\n#XFLD,20: W4: Label for first name of a person used general data\r\nFIRST_NAME=\\u0418\\u043C\\u044F\r\n\r\n#XFLD,20: W4: Label for last name of a person used general data\r\nLAST_NAME=\\u0424\\u0430\\u043C\\u0438\\u043B\\u0438\\u044F\r\n\r\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nBIRTHDAY=\\u0414\\u0430\\u0442\\u0430 \\u0440\\u043E\\u0436\\u0434\\u0435\\u043D\\u0438\\u044F\r\n\r\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nTITLE=\\u041E\\u0431\\u0440\\u0430\\u0449\\u0435\\u043D\\u0438\\u0435\r\n\r\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nACADEMIC_TITLE=\\u0423\\u0447\\u0435\\u043D\\u0430\\u044F \\u0441\\u0442\\u0435\\u043F\\u0435\\u043D\\u044C\r\n\r\n#XFLD,20: W4: Label for mobile phone number used general data\r\nMOBILE=\\u041C\\u043E\\u0431\\u0438\\u043B\\u044C\\u043D\\u044B\\u0439\r\n\r\n#XFLD,20: W4: Label for phone number used general data\r\nPHONE=\\u0422\\u0435\\u043B\\u0435\\u0444\\u043E\\u043D\r\n\r\n#XFLD,20: W4: Label for e-mail used general data\r\nEMAIL=\\u042D\\u043B\\u0435\\u043A\\u0442\\u0440\\u043E\\u043D\\u043D\\u0430\\u044F \\u043F\\u043E\\u0447\\u0442\\u0430\r\n\r\n#XFLD,20: W4: Label for web site used general data\r\nWEBSITE=\\u0412\\u0435\\u0431-\\u0441\\u0430\\u0439\\u0442\r\n\r\n#XFLD,20: W4: Label for country used general data\r\nCOUNTRY=\\u0421\\u0442\\u0440\\u0430\\u043D\\u0430\r\n\r\n#XFLD,20: W4: Label for region used general data\r\nREGION=\\u0420\\u0435\\u0433\\u0438\\u043E\\u043D\r\n\r\n#XFLD,20: W4: Label for city used general data\r\nCITY=\\u0413\\u043E\\u0440\\u043E\\u0434\r\n\r\n#XFLD,20: W4: Label for postal code used general data\r\nPOSTAL_CODE=\\u041F\\u043E\\u0447\\u0442\\u043E\\u0432\\u044B\\u0439 \\u0438\\u043D\\u0434\\u0435\\u043A\\u0441\r\n\r\n#XFLD,20: W4: Label for street used general data\r\nSTREET=\\u0423\\u043B\\u0438\\u0446\\u0430\r\n\r\n#XFLD,10: W4: Label for house number used general data\r\nHOUSE_NUMBER=\\u2116 \\u0434\\u043E\\u043C\\u0430\r\n\r\n#XFLD,15: W6: Label for ID used in Quotations\r\nID=\\u0418\\u0434.\r\n\r\n#XFLD,15: W6: Label for Amount used in Quotations\r\nAMOUNT=\\u0421\\u0443\\u043C\\u043C\\u0430\r\n\r\n#XFLD,20: W6: Label for Expiration Date used in Quotations\r\nEXPIRATION_DATE=\\u0414\\u0430\\u0442\\u0430 \\u0438\\u0441\\u0442\\u0435\\u0447\\u0435\\u043D\\u0438\\u044F \\u0441\\u0440\\u043E\\u043A\\u0430\r\n\r\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\r\nDELIVERY_DATE=\\u0414\\u0430\\u0442\\u0430 \\u043F\\u043E\\u0441\\u0442\\u0430\\u0432\\u043A\\u0438\r\n\r\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\r\nSALES_EMPLOYEE=\\u041C\\u0435\\u043D\\u0435\\u0434\\u0436\\u0435\\u0440 \\u043F\\u0440\\u043E\\u0434\\u0430\\u0436\r\n\r\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\r\nATTRIBUTESET=\\u041D\\u0430\\u0431\\u043E\\u0440 \\u0430\\u0442\\u0440\\u0438\\u0431\\u0443\\u0442\\u043E\\u0432\r\n\r\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\r\nATTRIBUTE=\\u0410\\u0442\\u0440\\u0438\\u0431\\u0443\\u0442\r\n\r\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\r\nVALUE=\\u0417\\u043D\\u0430\\u0447\\u0435\\u043D\\u0438\\u0435\r\n\r\n#XBUT, 20: Button to create an Account\r\nBUTTON_ADD=\\u0414\\u043E\\u0431\\u0430\\u0432\\u0438\\u0442\\u044C\r\n\r\n#XBUT, 20: Button to edit an Account\r\nBUTTON_EDIT=\\u0420\\u0435\\u0434\\u0430\\u043A\\u0442\\u0438\\u0440\\u043E\\u0432\\u0430\\u0442\\u044C\r\n\r\n#XBUT, 20: Button to save changes\r\nBUTTON_SAVE=\\u0421\\u043E\\u0445\\u0440\\u0430\\u043D\\u0438\\u0442\\u044C\r\n\r\n#XBUT, 20: Button to cancel changes\r\nBUTTON_CANCEL=\\u041E\\u0442\\u043C\\u0435\\u043D\\u0438\\u0442\\u044C\r\n\r\n#XBUT, 30: Button which shows the personalization buttons\r\nBUTTON_SHOW_PERSONALIZATION=\\u041F\\u043E\\u043A\\u0430\\u0437\\u0430\\u0442\\u044C \\u043F\\u0435\\u0440\\u0441\\u043E\\u043D\\u0430\\u043B\\u0438\\u0437\\u0430\\u0446\\u0438\\u044E\r\n\r\n#XBUT, 30: Button which hides the personalization buttons\r\nBUTTON_HIDE_PERSONALIZATION=\\u0421\\u043A\\u0440\\u044B\\u0442\\u044C \\u043F\\u0435\\u0440\\u0441\\u043E\\u043D\\u0430\\u043B\\u0438\\u0437\\u0430\\u0446\\u0438\\u044E\r\n\r\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_CONFIRM_CANCEL=\\u0412\\u0441\\u0435 \\u043D\\u0435\\u0441\\u043E\\u0445\\u0440\\u0430\\u043D\\u0435\\u043D\\u043D\\u044B\\u0435 \\u0438\\u0437\\u043C\\u0435\\u043D\\u0435\\u043D\\u0438\\u044F \\u0431\\u0443\\u0434\\u0443\\u0442 \\u043F\\u043E\\u0442\\u0435\\u0440\\u044F\\u043D\\u044B. \\u041F\\u0440\\u043E\\u0434\\u043E\\u043B\\u0436\\u0438\\u0442\\u044C?\r\n\r\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\r\nMSG_CONFIRM_DELETE_CONTACT=\\u041F\\u0440\\u0438\\u0441\\u0432\\u043E\\u0435\\u043D\\u0438\\u0435 \\u043A\\u043E\\u043D\\u0442\\u0430\\u043A\\u0442\\u0430 \\u043A\\u043B\\u0438\\u0435\\u043D\\u0442\\u0443 \\u0431\\u0443\\u0434\\u0435\\u0442 \\u043E\\u0442\\u043C\\u0435\\u043D\\u0435\\u043D\\u043E. \\u041F\\u0440\\u043E\\u0434\\u043E\\u043B\\u0436\\u0438\\u0442\\u044C?\r\n\r\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_SUCCESS=\\u041A\\u043B\\u0438\\u0435\\u043D\\u0442 \\u043E\\u0431\\u043D\\u043E\\u0432\\u043B\\u0435\\u043D\r\n\r\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_ERROR=\\u0421\\u0431\\u043E\\u0439 \\u043E\\u0431\\u043D\\u043E\\u0432\\u043B\\u0435\\u043D\\u0438\\u044F\r\n\r\n# XMSG : Account update succeeded\r\nMSG_CREATION_SUCCESS=\\u041A\\u043B\\u0438\\u0435\\u043D\\u0442 \\u0441\\u043E\\u0437\\u0434\\u0430\\u043D\r\n\r\n# XMSG : Task creation succeeded\r\nMSG_TASK_CREATION_SUCCESS=\\u0417\\u0430\\u0434\\u0430\\u0447\\u0430 \\u0441\\u043E\\u0437\\u0434\\u0430\\u043D\\u0430\r\n\r\n# XMSG : Contact creation failed\r\nMSG_CREATION_ERROR=\\u041D\\u0435 \\u0443\\u0434\\u0430\\u043B\\u043E\\u0441\\u044C \\u0441\\u043E\\u0437\\u0434\\u0430\\u0442\\u044C\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong country\r\nMSG_WRONG_COUNTRY_ERROR=\\u0421\\u0442\\u0440\\u0430\\u043D\\u0430 "{0}" \\u043D\\u0435 \\u0441\\u0443\\u0449\\u0435\\u0441\\u0442\\u0432\\u0443\\u0435\\u0442\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong region\r\nMSG_WRONG_REGION_ERROR=\\u0420\\u0435\\u0433\\u0438\\u043E\\u043D "{0}" \\u043D\\u0435 \\u0441\\u0443\\u0449\\u0435\\u0441\\u0442\\u0432\\u0443\\u0435\\u0442 \\u0432 \\u044D\\u0442\\u043E\\u0439 \\u0441\\u0442\\u0440\\u0430\\u043D\\u0435\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong employee\r\nMSG_WRONG_EMPLOYEE_ERROR=\\u0421\\u043E\\u0442\\u0440\\u0443\\u0434\\u043D\\u0438\\u043A "{0}" \\u043D\\u0435 \\u0441\\u0443\\u0449\\u0435\\u0441\\u0442\\u0432\\u0443\\u0435\\u0442.\r\n\r\n# XMSG: message that will be displayed, if the user has entered invalid website url\r\nMSG_WRONG_URL_ERROR=\\u0412\\u0432\\u0435\\u0434\\u0435\\u043D\\u043D\\u044B\\u0439 URL "{0}" \\u043D\\u0435\\u0434\\u0435\\u0439\\u0441\\u0442\\u0432\\u0438\\u0442\\u0435\\u043B\\u0435\\u043D.\r\n\r\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\r\nMSG_MANDATORY_FIELDS=\\u041D\\u0435 \\u0432\\u0441\\u0435 \\u043E\\u0431\\u044F\\u0437\\u0430\\u0442\\u0435\\u043B\\u044C\\u043D\\u044B\\u0435 \\u043F\\u043E\\u043B\\u044F \\u0437\\u0430\\u043F\\u043E\\u043B\\u043D\\u0435\\u043D\\u044B\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA=\\u0414\\u0430\\u043D\\u043D\\u044B\\u0435 \\u0438\\u0437\\u043C\\u0435\\u043D\\u0435\\u043D\\u044B \\u0434\\u0440\\u0443\\u0433\\u0438\\u043C \\u043F\\u043E\\u043B\\u044C\\u0437\\u043E\\u0432\\u0430\\u0442\\u0435\\u043B\\u0435\\u043C. \\u041F\\u0435\\u0440\\u0435\\u0437\\u0430\\u043F\\u0438\\u0441\\u0430\\u0442\\u044C \\u0438\\u0437\\u043C\\u0435\\u043D\\u0435\\u043D\\u0438\\u044F \\u0434\\u0440\\u0443\\u0433\\u043E\\u0433\\u043E \\u043F\\u043E\\u043B\\u044C\\u0437\\u043E\\u0432\\u0430\\u0442\\u0435\\u043B\\u044F \\u0441\\u0432\\u043E\\u0438\\u043C\\u0438?\r\n\r\n# XMSG: message that will be displayed in case of conflicts during file renaming\r\nMSG_CONFLICTING_FILE_NAME=\\u0418\\u043C\\u044F \\u0444\\u0430\\u0439\\u043B\\u0430 \\u0438\\u0437\\u043C\\u0435\\u043D\\u0435\\u043D\\u043E \\u0434\\u0440\\u0443\\u0433\\u0438\\u043C \\u043F\\u043E\\u043B\\u044C\\u0437\\u043E\\u0432\\u0430\\u0442\\u0435\\u043B\\u0435\\u043C. \\u041F\\u0435\\u0440\\u0435\\u0437\\u0430\\u043F\\u0438\\u0441\\u0430\\u0442\\u044C \\u0438\\u0437\\u043C\\u0435\\u043D\\u0435\\u043D\\u0438\\u044F \\u0434\\u0440\\u0443\\u0433\\u043E\\u0433\\u043E \\u043F\\u043E\\u043B\\u044C\\u0437\\u043E\\u0432\\u0430\\u0442\\u0435\\u043B\\u044F \\u0441\\u0432\\u043E\\u0438\\u043C\\u0438?\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA_WITH_REFRESH=\\u0414\\u0430\\u043D\\u043D\\u044B\\u0435 \\u0438\\u0437\\u043C\\u0435\\u043D\\u0435\\u043D\\u044B \\u0434\\u0440\\u0443\\u0433\\u0438\\u043C \\u043F\\u043E\\u043B\\u044C\\u0437\\u043E\\u0432\\u0430\\u0442\\u0435\\u043B\\u0435\\u043C. \\u042D\\u0442\\u0438 \\u0438\\u0437\\u043C\\u0435\\u043D\\u0435\\u043D\\u0438\\u044F \\u0431\\u0443\\u0434\\u0443\\u0442 \\u043E\\u0442\\u043E\\u0431\\u0440\\u0430\\u0436\\u0435\\u043D\\u044B \\u0432 \\u043F\\u0440\\u0438\\u043B\\u043E\\u0436\\u0435\\u043D\\u0438\\u0438.\r\n\r\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\r\nMSG_NOT_IN_MAIN_CONTACT=\\u0412\\u044B \\u043C\\u043E\\u0436\\u0435\\u0442\\u0435 \\u043F\\u0440\\u043E\\u0441\\u043C\\u043E\\u0442\\u0440\\u0435\\u0442\\u044C \\u0442\\u043E\\u043B\\u044C\\u043A\\u043E \\u0441\\u0432\\u0435\\u0434\\u0435\\u043D\\u0438\\u044F \\u043E \\u043A\\u043E\\u043D\\u0442\\u0430\\u043A\\u0442\\u0430\\u0445, \\u043F\\u0440\\u0438\\u0441\\u0432\\u043E\\u0435\\u043D\\u043D\\u044B\\u0445 \\u044D\\u0442\\u043E\\u043C\\u0443 \\u043A\\u043B\\u0438\\u0435\\u043D\\u0442\\u0443\r\n\r\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\r\nMSG_EXCEEDING_FILE_NAME_LENGTH=\\u0414\\u043B\\u0438\\u043D\\u0430 \\u0438\\u043C\\u0435\\u043D\\u0438 \\u0444\\u0430\\u0439\\u043B\\u0430 \\u043D\\u0435 \\u0434\\u043E\\u043B\\u0436\\u043D\\u0430 \\u043F\\u0440\\u0435\\u0432\\u044B\\u0448\\u0430\\u0442\\u044C 40 \\u0441\\u0438\\u043C\\u0432\\u043E\\u043B\\u043E\\u0432\r\n\r\n# XTOL, 20: tooltip shown on search result list for button to add an account"\r\n\r\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\r\n\r\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\r\n\r\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\r\n\r\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\r\n\r\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\r\n',
	"cus/crm/myaccounts/i18n/i18n_sh.properties":'# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XFLD, 30: Facet title for general Data\r\nGENERAL_DATA=Op\\u0161ti podaci\r\n\r\n#XTIT, 40: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=Moji klijenti\r\n\r\n#XTIT, 40: this is the title for the detail screen\r\nDETAIL_TITLE=Klijent\r\n\r\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\r\nREVENUE_CURRENT=Prih.-teku\\u0107a god.\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\r\nREVENUE_CURRENT_TOOLTIP=Prihod do dana\\u0161njeg datuma - teku\\u0107a god.\r\n\r\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\r\nREVENUE_LAST=Prihod - PG\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\r\nREVENUE_LAST_TOOLTIP=Prihod - pro\\u0161la godina\r\n\r\n# XFLD, 30: Facet title for opportunities and label in facet general data\r\nOPPORTUNITIES=Prilike\r\n\r\n#XFLD, 30: Facet title for leads\r\nLEADS=Potencijalni klijenti\r\n\r\n#XFLD, 30: Facet title for tasks\r\nTASKS=Zadaci\r\n\r\n#XFLD, 30: Facet title for appointments\r\nAPPOINTMENTS=Sastanci\r\n\r\n#XFLD, 30: Facet title for quotations\r\nQUOTATIONS=Ponude\r\n\r\n#XFLD, 30: Facet title for sales orders\r\nSALES_ORDERS=Prodajni nalozi\r\n\r\n#XFLD, 30: W7: Facet title for marketing attributes\r\nMARKETINGATTRIBUTES=Obele\\u017Eja marketinga\r\n\r\n#XFLD, 30: W6: Title for popup with products\r\nPRODUCTS=Proizvodi\r\n\r\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\r\nEMPLOYEE_RESPONSIBLE=Odgovorni zaposleni\r\n\r\n#XFLD, 30: Facet title for Attachments\r\nATTACHMENTS=Dodaci\r\n\r\n#XFLD, 30: Facet title for Notes\r\nNOTES=Bele\\u0161ke\r\n\r\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\r\nNEW_NOTE=Nova bele\\u0161ka\r\n\r\n#XFLD, 30: Facet title for Contacts\r\nCONTACTS=Kontakti\r\n\r\n#XFLD, 30: Label for Address in facet general data\r\nADDRESS=Adresa\r\n\r\n#XFLD, 30: Label for Opportunities in facet general data\r\nUNWEIGHTED_OPPORTUNITIES=Prilike\r\n\r\n#XFLD, 30: Label for Rating in facet general data\r\nRATING=Vrednovanje\r\n\r\n# XFLD, 30: Label for Next contact in facet Appointments\r\nNEXT_APPOINTMENT=Slede\\u0107i sastanak\r\n\r\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\r\nLAST_APPOINTMENT=Pro\\u0161li sastanak\r\n\r\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\r\nIMAGE=Slika\r\n\r\n#XBUT, 20: Button to show the create actionsheet\r\nCREATE=Kreiraj\r\n\r\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\r\nDISCUSS_ENTRY=Diskutuj na SAP Jam-u\r\n\r\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\r\nSHARE_ENTRY=Podeli na SAP Jam-u\r\n\r\n#XBUT, 20: Button to share the note\r\nDETAIL_BUTTON_SHARE=Podeli\r\n\r\n#XBUT, 20: Button to cancel sharing\r\nDETAIL_BUTTON_CANCEL=Odustani\r\n\r\n#XFLD,20: All accounts for filter\r\nALL_ACCOUNTS=Svi klijenti\r\n\r\n#XFLD,35: All individual accounts for filter\r\nALL_INDIVIDUAL_ACCOUNTS=Svi pojedina\\u010Dni klijenti\r\n\r\n#XFLD,35: All corporate accounts for filter\r\nALL_CORPORATE_ACCOUNTS=Svi korporativni klijenti\r\n\r\n#XFLD,35: All group accounts for filter\r\nALL_ACCOUNT_GROUPS=Sve grupe klijenata\r\n\r\n#XFLD,20: my account for filter\r\nMY_ACCOUNT=Moji klijenti\r\n\r\n#XFLD,35: my individual accounts for filter\r\nMY_INDIVIDUAL_ACCOUNTS=Moji pojedina\\u010Dni klijenti\r\n\r\n#XFLD,35: my corporate accounts for filter\r\nMY_CORPORATE_ACCOUNTS=Moji korporativni klijenti\r\n\r\n#XFLD,35: my group accounts for filter\r\nMY_ACCOUNT_GROUPS=Moje grupe klijenata\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nINDIVIDUAL_ACCOUNT=Pojedina\\u010Dni klijent\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nCORPORATE_ACCOUNT=Korporativni klijent\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nACCOUNT_GROUP=Grupa klijenata\r\n\r\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\r\nSTARTING=Datum po\\u010Detka\\: {0}\r\n\r\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\r\nCLOSING=Datum zatvaranja\\: {0}\r\n\r\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\r\nDUE=Datum dospe\\u0107a\\: {0}\r\n\r\n#XFLD,20: All accounts for title\r\nALL_ACCOUNTS_TITLE=Svi klijenti ({0})\r\n\r\n#XFLD,35: All individual accounts for title\r\nALL_INDIVIDUAL_ACCOUNTS_TITLE=Svi pojedina\\u010Dni klijenti ({0})\r\n\r\n#XFLD,35: All corporate accounts for title\r\nALL_CORPORATE_ACCOUNTS_TITLE=Svi korporativni klijenti ({0})\r\n\r\n#XFLD,35: All group accounts for title\r\nALL_ACCOUNT_GROUPS_TITLE=Sve grupe klijenata ({0})\r\n\r\n#XFLD,20: my account for title\r\nMY_ACCOUNT_TITLE=Moji klijenti ({0})\r\n\r\n#XFLD,35: my individual account for title\r\nMY_INDIVIDUAL_ACCOUNT_TITLE=Moji pojedina\\u010Dni klijenti ({0})\r\n\r\n#XFLD,35: my corporate account for title.\r\nMY_CORPORATE_ACCOUNT_TITLE=Moji korporativni klijenti ({0})\r\n\r\n#XFLD,35: my group account for title\r\nMY_ACCOUNT_GROUP_TITLE=Moje grupe klijenata ({0})\r\n\r\n#XFLD,30: filtered by info\r\nFILTERED_BY=Filtrirano po\\: {0}\r\n\r\n#XFLD,30: label, search for accounts\r\nSEARCH_ACCOUNTS=Tra\\u017Ei\r\n\r\n#XFLD,30: comma separator for location\r\nLOCATION={0}, {1}\r\n\r\n#XFLD: W4: Label for All day text in Appointments\r\nALL_DAY_EVENT=Ceo dan\r\n\r\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\r\nDURATION_MINUTE={0} min\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\r\nDURATION_HOUR={0} s\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\r\nDURATION_DAY={0} dan\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\r\nDURATION_DAYS={0} dana\r\n\r\n#XFLD: W4: Label for Private meeting\r\nPRIVATE=Privatno\r\n\r\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\r\nSELECT_TRANSACTION_TYPE=Odaberi tip transakcije\r\n\r\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\r\nNEW_TASK_INPUT_PLACEHOLDER=Novi zadatak\r\n\r\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nNO_DATA_TEXT=Nema podataka\r\n\r\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nLOADING_TEXT=U\\u010Ditavanje...\r\n\r\n#XFLD,25: W4: Column label for name of contact person in contacts\r\nNAME=Ime\r\n\r\n#XFLD,25: W5: Column label for department of contact person in contacts\r\nDEPARTMENT=Odeljak\r\n\r\n#XFLD,15: W6: Column label for actions of contact person in contacts\r\nACTIONS=Radnje\r\n\r\n#XFLD,25: W4: Column label for description of lead in Leads\r\nDESCRIPTION=Opis\r\n\r\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\r\nASSIGNED_TO=Dodeljeno\r\n\r\n#XFLD,15: W4: Column label for end date of lead in Leads\r\nEND_DATE=Datum zavr\\u0161etka\r\n\r\n#XFLD,15: W4: Column label for qualification level of lead in Leads\r\nQUALIFICATION=Kvalifikacija\r\n\r\n#XFLD,15: W4: Column label for status of lead in Leads\r\nSTATUS=Status\r\n\r\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\r\nMAIN_CONTACT=Glavni kontakt\r\n\r\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\r\nVOLUME=Zapremina\r\n\r\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\r\nPROBABILITY=Verovatno\\u0107a\r\n\r\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\r\nCLOSE_BY=Zatvori do\r\n\r\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \r\nVIEWS=Pogledi\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\r\nCONTACT_TITLE=Kontakt\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\r\nEMPLOYEE_TITLE=Zaposleni\r\n\r\n#XTIT,20: W7: Title of pop-up used in confirm popup\r\nCONFIRM_TITLE=Potvrdi\r\n\r\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\r\nCOMPANY_NAME=Naziv\r\n\r\n#XFLD,20: W4: Label for name 1 of a company used general data\r\nCOMPANY_NAME1=Ime 1\r\n\r\n#XFLD,20: W4: Label for name 2 of a company used general data\r\nCOMPANY_NAME2=Ime 2\r\n\r\n#XFLD,20: W4: Label for first name of a person used general data\r\nFIRST_NAME=Ime\r\n\r\n#XFLD,20: W4: Label for last name of a person used general data\r\nLAST_NAME=Prezime\r\n\r\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nBIRTHDAY=Datum ro\\u0111enja\r\n\r\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nTITLE=Naslov\r\n\r\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nACADEMIC_TITLE=Akademska titula\r\n\r\n#XFLD,20: W4: Label for mobile phone number used general data\r\nMOBILE=Mobilni telefon\r\n\r\n#XFLD,20: W4: Label for phone number used general data\r\nPHONE=Telefon\r\n\r\n#XFLD,20: W4: Label for e-mail used general data\r\nEMAIL=E-po\\u0161ta\r\n\r\n#XFLD,20: W4: Label for web site used general data\r\nWEBSITE=Web lokacija\r\n\r\n#XFLD,20: W4: Label for country used general data\r\nCOUNTRY=Zemlja\r\n\r\n#XFLD,20: W4: Label for region used general data\r\nREGION=Regija\r\n\r\n#XFLD,20: W4: Label for city used general data\r\nCITY=Grad\r\n\r\n#XFLD,20: W4: Label for postal code used general data\r\nPOSTAL_CODE=Po\\u0161tanski broj\r\n\r\n#XFLD,20: W4: Label for street used general data\r\nSTREET=Ulica\r\n\r\n#XFLD,10: W4: Label for house number used general data\r\nHOUSE_NUMBER=Ku\\u0107ni broj\r\n\r\n#XFLD,15: W6: Label for ID used in Quotations\r\nID=ID\r\n\r\n#XFLD,15: W6: Label for Amount used in Quotations\r\nAMOUNT=Iznos\r\n\r\n#XFLD,20: W6: Label for Expiration Date used in Quotations\r\nEXPIRATION_DATE=Datum isteka\r\n\r\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\r\nDELIVERY_DATE=Datum isporuke\r\n\r\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\r\nSALES_EMPLOYEE=Zaposleni u prodaji\r\n\r\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\r\nATTRIBUTESET=Skup obele\\u017Eja\r\n\r\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\r\nATTRIBUTE=Obele\\u017Eje\r\n\r\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\r\nVALUE=Vrednost\r\n\r\n#XBUT, 20: Button to create an Account\r\nBUTTON_ADD=Dodaj\r\n\r\n#XBUT, 20: Button to edit an Account\r\nBUTTON_EDIT=Uredi\r\n\r\n#XBUT, 20: Button to save changes\r\nBUTTON_SAVE=Sa\\u010Duvaj\r\n\r\n#XBUT, 20: Button to cancel changes\r\nBUTTON_CANCEL=Odustani\r\n\r\n#XBUT, 30: Button which shows the personalization buttons\r\nBUTTON_SHOW_PERSONALIZATION=Prika\\u017Ei personalizaciju\r\n\r\n#XBUT, 30: Button which hides the personalization buttons\r\nBUTTON_HIDE_PERSONALIZATION=Sakrij personalizaciju\r\n\r\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_CONFIRM_CANCEL=Sve nesa\\u010Duvane promene \\u0107e biti izgubljene. Da li \\u017Eelite da nastavite?\r\n\r\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\r\nMSG_CONFIRM_DELETE_CONTACT=Dodela kontakta klijentu \\u0107e biti poni\\u0161tena. Da li \\u017Eelite da nastavite?\r\n\r\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_SUCCESS=Klijent a\\u017Euriran\r\n\r\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_ERROR=A\\u017Euriranje nije uspelo\r\n\r\n# XMSG : Account update succeeded\r\nMSG_CREATION_SUCCESS=Klijent kreiran\r\n\r\n# XMSG : Task creation succeeded\r\nMSG_TASK_CREATION_SUCCESS=Zadatak kreiran\r\n\r\n# XMSG : Contact creation failed\r\nMSG_CREATION_ERROR=Kreiranje nije uspelo\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong country\r\nMSG_WRONG_COUNTRY_ERROR=Zemlja "{0}" ne postoji\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong region\r\nMSG_WRONG_REGION_ERROR=Regija "{0}" ne postoji za zemlju\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong employee\r\nMSG_WRONG_EMPLOYEE_ERROR=Zaposleni "{0}" ne postoji\r\n\r\n# XMSG: message that will be displayed, if the user has entered invalid website url\r\nMSG_WRONG_URL_ERROR=Uneti URL "{0}" nije va\\u017Ee\\u0107i.\r\n\r\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\r\nMSG_MANDATORY_FIELDS=Nisu popunjena sva obavezna polja\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA=Podatke je zamenio drugi korisnik. Da li \\u017Eelite da pi\\u0161ete sopstvene promene preko promena drugog korisnika?\r\n\r\n# XMSG: message that will be displayed in case of conflicts during file renaming\r\nMSG_CONFLICTING_FILE_NAME=Naziv fajla je promenio drugi korisnik. Da li \\u017Eelite da pi\\u0161ete sopstvene promene preko promena drugog korisnika?\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA_WITH_REFRESH=Podatke je promenio drugi korisnik. Ove promene \\u0107e se sada pojaviti u aplikaciji.\r\n\r\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\r\nMSG_NOT_IN_MAIN_CONTACT=Mo\\u017Eete pregledati samo detalje kontakata koji su dodeljeni ovom klijentu\r\n\r\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\r\nMSG_EXCEEDING_FILE_NAME_LENGTH=Va\\u0161 naziv fajla mo\\u017Ee imati maksimalno 40 znakova.\r\n\r\n# XTOL, 20: tooltip shown on search result list for button to add an account"\r\n\r\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\r\n\r\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\r\n\r\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\r\n\r\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\r\n\r\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\r\n',
	"cus/crm/myaccounts/i18n/i18n_sk.properties":'# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XFLD, 30: Facet title for general Data\r\nGENERAL_DATA=V\\u0161eobecn\\u00E9 d\\u00E1ta\r\n\r\n#XTIT, 40: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=Moji z\\u00E1kazn\\u00EDci\r\n\r\n#XTIT, 40: this is the title for the detail screen\r\nDETAIL_TITLE=Z\\u00E1kazn\\u00EDk\r\n\r\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\r\nREVENUE_CURRENT=V\\u00FDnos-AktRokDodnes\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\r\nREVENUE_CURRENT_TOOLTIP=V\\u00FDnosy dodnes (aktu\\u00E1lny rok)\r\n\r\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\r\nREVENUE_LAST=V\\u00FDnos posledn\\u00FD rok\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\r\nREVENUE_LAST_TOOLTIP=V\\u00FDnosy posledn\\u00FD rok\r\n\r\n# XFLD, 30: Facet title for opportunities and label in facet general data\r\nOPPORTUNITIES=Pr\\u00EDle\\u017Eitosti\r\n\r\n#XFLD, 30: Facet title for leads\r\nLEADS=Tipy\r\n\r\n#XFLD, 30: Facet title for tasks\r\nTASKS=\\u00DAlohy\r\n\r\n#XFLD, 30: Facet title for appointments\r\nAPPOINTMENTS=Sch\\u00F4dzky\r\n\r\n#XFLD, 30: Facet title for quotations\r\nQUOTATIONS=Ponuky\r\n\r\n#XFLD, 30: Facet title for sales orders\r\nSALES_ORDERS=Z\\u00E1kazky odberate\\u013Ea\r\n\r\n#XFLD, 30: W7: Facet title for marketing attributes\r\nMARKETINGATTRIBUTES=Marketingov\\u00E9 atrib\\u00FAty\r\n\r\n#XFLD, 30: W6: Title for popup with products\r\nPRODUCTS=Produkty\r\n\r\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\r\nEMPLOYEE_RESPONSIBLE=Zodpovedn\\u00FD zamestnanec\r\n\r\n#XFLD, 30: Facet title for Attachments\r\nATTACHMENTS=Pr\\u00EDlohy\r\n\r\n#XFLD, 30: Facet title for Notes\r\nNOTES=Pozn\\u00E1mky\r\n\r\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\r\nNEW_NOTE=Nov\\u00E1 pozn\\u00E1mka\r\n\r\n#XFLD, 30: Facet title for Contacts\r\nCONTACTS=Kontakty\r\n\r\n#XFLD, 30: Label for Address in facet general data\r\nADDRESS=Adresa\r\n\r\n#XFLD, 30: Label for Opportunities in facet general data\r\nUNWEIGHTED_OPPORTUNITIES=Pr\\u00EDle\\u017Eitosti\r\n\r\n#XFLD, 30: Label for Rating in facet general data\r\nRATING=Hodnotenie\r\n\r\n# XFLD, 30: Label for Next contact in facet Appointments\r\nNEXT_APPOINTMENT=\\u010Eal\\u0161ia sch\\u00F4dzka\r\n\r\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\r\nLAST_APPOINTMENT=Posledn\\u00E1 sch\\u00F4dzka\r\n\r\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\r\nIMAGE=Obr\\u00E1zok\r\n\r\n#XBUT, 20: Button to show the create actionsheet\r\nCREATE=Vytvori\\u0165\r\n\r\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\r\nDISCUSS_ENTRY=Diskutova\\u0165 v SAP Jam\r\n\r\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\r\nSHARE_ENTRY=Zdie\\u013Ea\\u0165 v SAP Jam\r\n\r\n#XBUT, 20: Button to share the note\r\nDETAIL_BUTTON_SHARE=Zdie\\u013Ea\\u0165\r\n\r\n#XBUT, 20: Button to cancel sharing\r\nDETAIL_BUTTON_CANCEL=Zru\\u0161i\\u0165\r\n\r\n#XFLD,20: All accounts for filter\r\nALL_ACCOUNTS=V\\u0161etci z\\u00E1kazn\\u00EDci\r\n\r\n#XFLD,35: All individual accounts for filter\r\nALL_INDIVIDUAL_ACCOUNTS=V\\u0161etci jednotliv\\u00ED z\\u00E1kazn\\u00EDci\r\n\r\n#XFLD,35: All corporate accounts for filter\r\nALL_CORPORATE_ACCOUNTS=V\\u0161etci podnikov\\u00ED z\\u00E1kazn\\u00EDci\r\n\r\n#XFLD,35: All group accounts for filter\r\nALL_ACCOUNT_GROUPS=V\\u0161etky skupiny z\\u00E1kazn\\u00EDkov\r\n\r\n#XFLD,20: my account for filter\r\nMY_ACCOUNT=Moji z\\u00E1kazn\\u00EDci\r\n\r\n#XFLD,35: my individual accounts for filter\r\nMY_INDIVIDUAL_ACCOUNTS=Moji jednotliv\\u00ED z\\u00E1kazn\\u00EDci\r\n\r\n#XFLD,35: my corporate accounts for filter\r\nMY_CORPORATE_ACCOUNTS=Moji podnikov\\u00ED z\\u00E1kazn\\u00EDci\r\n\r\n#XFLD,35: my group accounts for filter\r\nMY_ACCOUNT_GROUPS=Moje skupiny z\\u00E1kazn\\u00EDkov\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nINDIVIDUAL_ACCOUNT=Jednotliv\\u00FD z\\u00E1kazn\\u00EDk\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nCORPORATE_ACCOUNT=Podnikov\\u00FD z\\u00E1kazn\\u00EDk\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nACCOUNT_GROUP=\\u00DA\\u010Dtov\\u00E1 skupina\r\n\r\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\r\nSTARTING=Po\\u010Diato\\u010Dn\\u00FD d\\u00E1tum\\: {0}\r\n\r\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\r\nCLOSING=D\\u00E1tum uzavretia\\: {0}\r\n\r\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\r\nDUE=Term\\u00EDn\\: {0}\r\n\r\n#XFLD,20: All accounts for title\r\nALL_ACCOUNTS_TITLE=V\\u0161etci z\\u00E1kazn\\u00EDci ({0})\r\n\r\n#XFLD,35: All individual accounts for title\r\nALL_INDIVIDUAL_ACCOUNTS_TITLE=V\\u0161etci jednotliv\\u00ED z\\u00E1kazn\\u00EDci ({0})\r\n\r\n#XFLD,35: All corporate accounts for title\r\nALL_CORPORATE_ACCOUNTS_TITLE=V\\u0161etci podnikov\\u00ED z\\u00E1kazn\\u00EDci ({0})\r\n\r\n#XFLD,35: All group accounts for title\r\nALL_ACCOUNT_GROUPS_TITLE=V\\u0161etky skupiny z\\u00E1kazn\\u00EDkov ({0})\r\n\r\n#XFLD,20: my account for title\r\nMY_ACCOUNT_TITLE=Moji z\\u00E1kazn\\u00EDci ({0})\r\n\r\n#XFLD,35: my individual account for title\r\nMY_INDIVIDUAL_ACCOUNT_TITLE=Moji jednotliv\\u00ED z\\u00E1kazn\\u00EDci ({0})\r\n\r\n#XFLD,35: my corporate account for title.\r\nMY_CORPORATE_ACCOUNT_TITLE=Moji podnikov\\u00ED z\\u00E1kazn\\u00EDci ({0})\r\n\r\n#XFLD,35: my group account for title\r\nMY_ACCOUNT_GROUP_TITLE=Moje skupiny z\\u00E1kazn\\u00EDkov ({0})\r\n\r\n#XFLD,30: filtered by info\r\nFILTERED_BY=Filtrovan\\u00E9 pod\\u013Ea\\: {0}\r\n\r\n#XFLD,30: label, search for accounts\r\nSEARCH_ACCOUNTS=H\\u013Eada\\u0165\r\n\r\n#XFLD,30: comma separator for location\r\nLOCATION={0}, {1}\r\n\r\n#XFLD: W4: Label for All day text in Appointments\r\nALL_DAY_EVENT=Cel\\u00FD de\\u0148\r\n\r\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\r\nDURATION_MINUTE={0} min\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\r\nDURATION_HOUR={0} hod\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\r\nDURATION_DAY={0} de\\u0148\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\r\nDURATION_DAYS={0} dn\\u00ED\r\n\r\n#XFLD: W4: Label for Private meeting\r\nPRIVATE=S\\u00FAkromn\\u00E9\r\n\r\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\r\nSELECT_TRANSACTION_TYPE=Vybra\\u0165 typ transakcie\r\n\r\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\r\nNEW_TASK_INPUT_PLACEHOLDER=Nov\\u00E1 \\u00FAloha\r\n\r\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nNO_DATA_TEXT=\\u017Diadne d\\u00E1ta\r\n\r\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nLOADING_TEXT=Na\\u010D\\u00EDtava sa...\r\n\r\n#XFLD,25: W4: Column label for name of contact person in contacts\r\nNAME=Meno\r\n\r\n#XFLD,25: W5: Column label for department of contact person in contacts\r\nDEPARTMENT=Oddelenie\r\n\r\n#XFLD,15: W6: Column label for actions of contact person in contacts\r\nACTIONS=Akcie\r\n\r\n#XFLD,25: W4: Column label for description of lead in Leads\r\nDESCRIPTION=Popis\r\n\r\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\r\nASSIGNED_TO=Priraden\\u00E9 k\r\n\r\n#XFLD,15: W4: Column label for end date of lead in Leads\r\nEND_DATE=Koncov\\u00FD d\\u00E1tum\r\n\r\n#XFLD,15: W4: Column label for qualification level of lead in Leads\r\nQUALIFICATION=Kvalifik\\u00E1cia\r\n\r\n#XFLD,15: W4: Column label for status of lead in Leads\r\nSTATUS=Stav\r\n\r\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\r\nMAIN_CONTACT=Hlavn\\u00FD kontakt\r\n\r\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\r\nVOLUME=Objem\r\n\r\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\r\nPROBABILITY=Pravdepodobnos\\u0165\r\n\r\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\r\nCLOSE_BY=Uzavretie do\r\n\r\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \r\nVIEWS=N\\u00E1h\\u013Eady\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\r\nCONTACT_TITLE=Kontakt\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\r\nEMPLOYEE_TITLE=Zamestnanec\r\n\r\n#XTIT,20: W7: Title of pop-up used in confirm popup\r\nCONFIRM_TITLE=Potvrdenie\r\n\r\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\r\nCOMPANY_NAME=N\\u00E1zov\r\n\r\n#XFLD,20: W4: Label for name 1 of a company used general data\r\nCOMPANY_NAME1=N\\u00E1zov 1\r\n\r\n#XFLD,20: W4: Label for name 2 of a company used general data\r\nCOMPANY_NAME2=N\\u00E1zov 2\r\n\r\n#XFLD,20: W4: Label for first name of a person used general data\r\nFIRST_NAME=Meno\r\n\r\n#XFLD,20: W4: Label for last name of a person used general data\r\nLAST_NAME=Priezvisko\r\n\r\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nBIRTHDAY=D\\u00E1tum narodenia\r\n\r\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nTITLE=Oslovenie\r\n\r\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nACADEMIC_TITLE=Akademick\\u00FD titul\r\n\r\n#XFLD,20: W4: Label for mobile phone number used general data\r\nMOBILE=Mobiln\\u00FD telef\\u00F3n\r\n\r\n#XFLD,20: W4: Label for phone number used general data\r\nPHONE=Telef\\u00F3n\r\n\r\n#XFLD,20: W4: Label for e-mail used general data\r\nEMAIL=E-mail\r\n\r\n#XFLD,20: W4: Label for web site used general data\r\nWEBSITE=Webov\\u00E1 lokalita\r\n\r\n#XFLD,20: W4: Label for country used general data\r\nCOUNTRY=\\u0160t\\u00E1t\r\n\r\n#XFLD,20: W4: Label for region used general data\r\nREGION=Regi\\u00F3n\r\n\r\n#XFLD,20: W4: Label for city used general data\r\nCITY=Mesto\r\n\r\n#XFLD,20: W4: Label for postal code used general data\r\nPOSTAL_CODE=PS\\u010C\r\n\r\n#XFLD,20: W4: Label for street used general data\r\nSTREET=Ulica\r\n\r\n#XFLD,10: W4: Label for house number used general data\r\nHOUSE_NUMBER=\\u010C.domu\r\n\r\n#XFLD,15: W6: Label for ID used in Quotations\r\nID=ID\r\n\r\n#XFLD,15: W6: Label for Amount used in Quotations\r\nAMOUNT=\\u010Ciastka\r\n\r\n#XFLD,20: W6: Label for Expiration Date used in Quotations\r\nEXPIRATION_DATE=D\\u00E1tum exspir\\u00E1cie\r\n\r\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\r\nDELIVERY_DATE=D\\u00E1tum dod\\u00E1vky\r\n\r\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\r\nSALES_EMPLOYEE=Pracovn\\u00EDk odbytu\r\n\r\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\r\nATTRIBUTESET=Skupina atrib\\u00FAtov\r\n\r\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\r\nATTRIBUTE=Atrib\\u00FAt\r\n\r\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\r\nVALUE=Hodnota\r\n\r\n#XBUT, 20: Button to create an Account\r\nBUTTON_ADD=Prida\\u0165\r\n\r\n#XBUT, 20: Button to edit an Account\r\nBUTTON_EDIT=Upravi\\u0165\r\n\r\n#XBUT, 20: Button to save changes\r\nBUTTON_SAVE=Ulo\\u017Ei\\u0165\r\n\r\n#XBUT, 20: Button to cancel changes\r\nBUTTON_CANCEL=Zru\\u0161i\\u0165\r\n\r\n#XBUT, 30: Button which shows the personalization buttons\r\nBUTTON_SHOW_PERSONALIZATION=Zobrazi\\u0165 personaliz\\u00E1ciu\r\n\r\n#XBUT, 30: Button which hides the personalization buttons\r\nBUTTON_HIDE_PERSONALIZATION=Skry\\u0165 personaliz\\u00E1ciu\r\n\r\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_CONFIRM_CANCEL=V\\u0161etky neulo\\u017Een\\u00E9 zmeny sa stratia. Chcete pokra\\u010Dova\\u0165?\r\n\r\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\r\nMSG_CONFIRM_DELETE_CONTACT=Priradenie kontaktu k z\\u00E1kazn\\u00EDkovi bude zru\\u0161en\\u00E9. Chcete pokra\\u010Dova\\u0165?\r\n\r\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_SUCCESS=Z\\u00E1kazn\\u00EDk aktualizovan\\u00FD\r\n\r\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_ERROR=Aktualiz\\u00E1cia sa nepodarila\r\n\r\n# XMSG : Account update succeeded\r\nMSG_CREATION_SUCCESS=Z\\u00E1kazn\\u00EDk vytvoren\\u00FD\r\n\r\n# XMSG : Task creation succeeded\r\nMSG_TASK_CREATION_SUCCESS=\\u00DAloha vytvoren\\u00E1\r\n\r\n# XMSG : Contact creation failed\r\nMSG_CREATION_ERROR=Vytvorenie sa nepodarilo\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong country\r\nMSG_WRONG_COUNTRY_ERROR=\\u0160t\\u00E1t "{0}" neexistuje\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong region\r\nMSG_WRONG_REGION_ERROR=Regi\\u00F3n "{0}" neexistuje pre \\u0161t\\u00E1t\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong employee\r\nMSG_WRONG_EMPLOYEE_ERROR=Zamestnanec "{0}" neexistuje.\r\n\r\n# XMSG: message that will be displayed, if the user has entered invalid website url\r\nMSG_WRONG_URL_ERROR=Zadan\\u00E1 adresa URL "{0}" nie je platn\\u00E1.\r\n\r\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\r\nMSG_MANDATORY_FIELDS=Nie s\\u00FA vyplnen\\u00E9 v\\u0161etky povinn\\u00E9 polia\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA=D\\u00E1ta zmenil in\\u00FD pou\\u017E\\u00EDvate\\u013E. Chcete zmeny in\\u00E9ho pou\\u017E\\u00EDvate\\u013Ea prep\\u00EDsa\\u0165 vlastn\\u00FDmi zmenami?\r\n\r\n# XMSG: message that will be displayed in case of conflicts during file renaming\r\nMSG_CONFLICTING_FILE_NAME=N\\u00E1zov s\\u00FAboru zmenil in\\u00FD pou\\u017E\\u00EDvate\\u013E. Chcete zmeny in\\u00E9ho pou\\u017E\\u00EDvate\\u013Ea prep\\u00EDsa\\u0165 vlastn\\u00FDmi zmenami?\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA_WITH_REFRESH=D\\u00E1ta zmenil in\\u00FD pou\\u017E\\u00EDvate\\u013E. Tieto zmeny sa teraz zobrazia v aplik\\u00E1cii.\r\n\r\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\r\nMSG_NOT_IN_MAIN_CONTACT=M\\u00F4\\u017Eete zobrazi\\u0165 len detaily kontaktov, ktor\\u00E9 s\\u00FA priraden\\u00E9 tomuto z\\u00E1kazn\\u00EDkovi\r\n\r\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\r\nMSG_EXCEEDING_FILE_NAME_LENGTH=N\\u00E1zov s\\u00FAboru m\\u00F4\\u017Ee ma\\u0165 maxim\\u00E1lne 40 znakov.\r\n\r\n# XTOL, 20: tooltip shown on search result list for button to add an account"\r\n\r\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\r\n\r\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\r\n\r\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\r\n\r\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\r\n\r\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\r\n',
	"cus/crm/myaccounts/i18n/i18n_sl.properties":'# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XFLD, 30: Facet title for general Data\r\nGENERAL_DATA=Splo\\u0161ni podatki\r\n\r\n#XTIT, 40: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=Moje stranke\r\n\r\n#XTIT, 40: this is the title for the detail screen\r\nDETAIL_TITLE=Stranka\r\n\r\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\r\nREVENUE_CURRENT=Prihodki kumulir.\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\r\nREVENUE_CURRENT_TOOLTIP=Prihodki do datuma v trenutnem letu\r\n\r\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\r\nREVENUE_LAST=Prih.v zadn.letu\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\r\nREVENUE_LAST_TOOLTIP=Prihodki v zadnjem letu\r\n\r\n# XFLD, 30: Facet title for opportunities and label in facet general data\r\nOPPORTUNITIES=Prilo\\u017Enosti\r\n\r\n#XFLD, 30: Facet title for leads\r\nLEADS=Potencialne stranke\r\n\r\n#XFLD, 30: Facet title for tasks\r\nTASKS=Opravila\r\n\r\n#XFLD, 30: Facet title for appointments\r\nAPPOINTMENTS=Termini\r\n\r\n#XFLD, 30: Facet title for quotations\r\nQUOTATIONS=Ponudbe\r\n\r\n#XFLD, 30: Facet title for sales orders\r\nSALES_ORDERS=Prodajni nalogi\r\n\r\n#XFLD, 30: W7: Facet title for marketing attributes\r\nMARKETINGATTRIBUTES=Marketin\\u0161ki atributi\r\n\r\n#XFLD, 30: W6: Title for popup with products\r\nPRODUCTS=Proizvodi\r\n\r\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\r\nEMPLOYEE_RESPONSIBLE=Odgovorni zaposleni\r\n\r\n#XFLD, 30: Facet title for Attachments\r\nATTACHMENTS=Priloge\r\n\r\n#XFLD, 30: Facet title for Notes\r\nNOTES=Zabele\\u017Eke\r\n\r\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\r\nNEW_NOTE=Nova zabele\\u017Eka\r\n\r\n#XFLD, 30: Facet title for Contacts\r\nCONTACTS=Kontaktne osebe\r\n\r\n#XFLD, 30: Label for Address in facet general data\r\nADDRESS=Naslov\r\n\r\n#XFLD, 30: Label for Opportunities in facet general data\r\nUNWEIGHTED_OPPORTUNITIES=Prilo\\u017Enosti\r\n\r\n#XFLD, 30: Label for Rating in facet general data\r\nRATING=Vrednotenje\r\n\r\n# XFLD, 30: Label for Next contact in facet Appointments\r\nNEXT_APPOINTMENT=Naslednji termin\r\n\r\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\r\nLAST_APPOINTMENT=Zadnji termin\r\n\r\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\r\nIMAGE=Slika\r\n\r\n#XBUT, 20: Button to show the create actionsheet\r\nCREATE=Kreiranje\r\n\r\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\r\nDISCUSS_ENTRY=Razprava v SAP Jam\r\n\r\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\r\nSHARE_ENTRY=Skupna raba v SAP Jam\r\n\r\n#XBUT, 20: Button to share the note\r\nDETAIL_BUTTON_SHARE=Dele\\u017E\r\n\r\n#XBUT, 20: Button to cancel sharing\r\nDETAIL_BUTTON_CANCEL=Prekinitev\r\n\r\n#XFLD,20: All accounts for filter\r\nALL_ACCOUNTS=Vse stranke\r\n\r\n#XFLD,35: All individual accounts for filter\r\nALL_INDIVIDUAL_ACCOUNTS=Vse posamezne stranke\r\n\r\n#XFLD,35: All corporate accounts for filter\r\nALL_CORPORATE_ACCOUNTS=Vse pravne stranke\r\n\r\n#XFLD,35: All group accounts for filter\r\nALL_ACCOUNT_GROUPS=Vse skupine strank\r\n\r\n#XFLD,20: my account for filter\r\nMY_ACCOUNT=Moje stranke\r\n\r\n#XFLD,35: my individual accounts for filter\r\nMY_INDIVIDUAL_ACCOUNTS=Moje posamezne stranke\r\n\r\n#XFLD,35: my corporate accounts for filter\r\nMY_CORPORATE_ACCOUNTS=Moje pravne stranke\r\n\r\n#XFLD,35: my group accounts for filter\r\nMY_ACCOUNT_GROUPS=Moje skupine strank\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nINDIVIDUAL_ACCOUNT=Posamezna stranka\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nCORPORATE_ACCOUNT=Pravna stranka\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nACCOUNT_GROUP=Skupina ra\\u010Dunov\r\n\r\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\r\nSTARTING=Datum za\\u010Detka\\: {0}\r\n\r\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\r\nCLOSING=Datum zaklju\\u010Dka\\: {0}\r\n\r\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\r\nDUE=Datum zapadlosti\\: {0}\r\n\r\n#XFLD,20: All accounts for title\r\nALL_ACCOUNTS_TITLE=Vse stranke ({0})\r\n\r\n#XFLD,35: All individual accounts for title\r\nALL_INDIVIDUAL_ACCOUNTS_TITLE=Vse posamezne stranke ({0})\r\n\r\n#XFLD,35: All corporate accounts for title\r\nALL_CORPORATE_ACCOUNTS_TITLE=Vse pravne stranke ({0})\r\n\r\n#XFLD,35: All group accounts for title\r\nALL_ACCOUNT_GROUPS_TITLE=Vse skupine strank ({0})\r\n\r\n#XFLD,20: my account for title\r\nMY_ACCOUNT_TITLE=Moje stranke ({0})\r\n\r\n#XFLD,35: my individual account for title\r\nMY_INDIVIDUAL_ACCOUNT_TITLE=Moje posamezne stranke ({0})\r\n\r\n#XFLD,35: my corporate account for title.\r\nMY_CORPORATE_ACCOUNT_TITLE=Moje pravne stranke ({0})\r\n\r\n#XFLD,35: my group account for title\r\nMY_ACCOUNT_GROUP_TITLE=Moje skupine strank ({0})\r\n\r\n#XFLD,30: filtered by info\r\nFILTERED_BY=Filtrirano po\\: {0}\r\n\r\n#XFLD,30: label, search for accounts\r\nSEARCH_ACCOUNTS=Iskanje\r\n\r\n#XFLD,30: comma separator for location\r\nLOCATION={0}, {1}\r\n\r\n#XFLD: W4: Label for All day text in Appointments\r\nALL_DAY_EVENT=Ves dan\r\n\r\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\r\nDURATION_MINUTE={0} min\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\r\nDURATION_HOUR={0} h\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\r\nDURATION_DAY={0} dan\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\r\nDURATION_DAYS={0} dni\r\n\r\n#XFLD: W4: Label for Private meeting\r\nPRIVATE=Privatno\r\n\r\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\r\nSELECT_TRANSACTION_TYPE=Izberite tip transakcije\r\n\r\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\r\nNEW_TASK_INPUT_PLACEHOLDER=Nova naloga\r\n\r\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nNO_DATA_TEXT=Ni podatkov\r\n\r\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nLOADING_TEXT=Nalaganje ...\r\n\r\n#XFLD,25: W4: Column label for name of contact person in contacts\r\nNAME=Naziv\r\n\r\n#XFLD,25: W5: Column label for department of contact person in contacts\r\nDEPARTMENT=Oddelek\r\n\r\n#XFLD,15: W6: Column label for actions of contact person in contacts\r\nACTIONS=Akcije\r\n\r\n#XFLD,25: W4: Column label for description of lead in Leads\r\nDESCRIPTION=Opis\r\n\r\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\r\nASSIGNED_TO=Dodeljeno za\r\n\r\n#XFLD,15: W4: Column label for end date of lead in Leads\r\nEND_DATE=Datum konca\r\n\r\n#XFLD,15: W4: Column label for qualification level of lead in Leads\r\nQUALIFICATION=Kvalifikacija\r\n\r\n#XFLD,15: W4: Column label for status of lead in Leads\r\nSTATUS=Status\r\n\r\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\r\nMAIN_CONTACT=Glavna kontaktna oseba\r\n\r\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\r\nVOLUME=Glasnost\r\n\r\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\r\nPROBABILITY=Verjetnost\r\n\r\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\r\nCLOSE_BY=Zaklju\\u010Dek do\r\n\r\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \r\nVIEWS=Pogledi\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\r\nCONTACT_TITLE=Kontakt\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\r\nEMPLOYEE_TITLE=Zaposleni\r\n\r\n#XTIT,20: W7: Title of pop-up used in confirm popup\r\nCONFIRM_TITLE=Potrditev\r\n\r\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\r\nCOMPANY_NAME=Naziv\r\n\r\n#XFLD,20: W4: Label for name 1 of a company used general data\r\nCOMPANY_NAME1=Naziv 1\r\n\r\n#XFLD,20: W4: Label for name 2 of a company used general data\r\nCOMPANY_NAME2=Ime 2\r\n\r\n#XFLD,20: W4: Label for first name of a person used general data\r\nFIRST_NAME=Ime\r\n\r\n#XFLD,20: W4: Label for last name of a person used general data\r\nLAST_NAME=Priimek\r\n\r\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nBIRTHDAY=Datum rojstva\r\n\r\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nTITLE=Naslov\r\n\r\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nACADEMIC_TITLE=Akademski naslov\r\n\r\n#XFLD,20: W4: Label for mobile phone number used general data\r\nMOBILE=Mobilna naprava\r\n\r\n#XFLD,20: W4: Label for phone number used general data\r\nPHONE=Telefon\r\n\r\n#XFLD,20: W4: Label for e-mail used general data\r\nEMAIL=E-po\\u0161ta\r\n\r\n#XFLD,20: W4: Label for web site used general data\r\nWEBSITE=Spletna stran\r\n\r\n#XFLD,20: W4: Label for country used general data\r\nCOUNTRY=Dr\\u017Eava\r\n\r\n#XFLD,20: W4: Label for region used general data\r\nREGION=Podro\\u010Dje\r\n\r\n#XFLD,20: W4: Label for city used general data\r\nCITY=Mesto\r\n\r\n#XFLD,20: W4: Label for postal code used general data\r\nPOSTAL_CODE=Po\\u0161tna \\u0161tevilka\r\n\r\n#XFLD,20: W4: Label for street used general data\r\nSTREET=Ulica\r\n\r\n#XFLD,10: W4: Label for house number used general data\r\nHOUSE_NUMBER=Hi\\u0161na \\u0161t.\r\n\r\n#XFLD,15: W6: Label for ID used in Quotations\r\nID=ID\r\n\r\n#XFLD,15: W6: Label for Amount used in Quotations\r\nAMOUNT=Znesek\r\n\r\n#XFLD,20: W6: Label for Expiration Date used in Quotations\r\nEXPIRATION_DATE=Datum zapadlosti\r\n\r\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\r\nDELIVERY_DATE=Datum dobave\r\n\r\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\r\nSALES_EMPLOYEE=Prodajni referent\r\n\r\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\r\nATTRIBUTESET=Skupina karakteristik\r\n\r\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\r\nATTRIBUTE=Atribut\r\n\r\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\r\nVALUE=Vrednost\r\n\r\n#XBUT, 20: Button to create an Account\r\nBUTTON_ADD=Dodajanje\r\n\r\n#XBUT, 20: Button to edit an Account\r\nBUTTON_EDIT=Obdelava\r\n\r\n#XBUT, 20: Button to save changes\r\nBUTTON_SAVE=Shranjevanje\r\n\r\n#XBUT, 20: Button to cancel changes\r\nBUTTON_CANCEL=Prekinitev\r\n\r\n#XBUT, 30: Button which shows the personalization buttons\r\nBUTTON_SHOW_PERSONALIZATION=Prika\\u017Ei personalizacijo\r\n\r\n#XBUT, 30: Button which hides the personalization buttons\r\nBUTTON_HIDE_PERSONALIZATION=Skrij personalizacijo\r\n\r\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_CONFIRM_CANCEL=Vse neshranjene spremembe bodo izgubljene. \\u017Delite nadaljevati?\r\n\r\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\r\nMSG_CONFIRM_DELETE_CONTACT=Kontaktna oseba ne bo ve\\u010D dodeljena stranki. \\u017Delite nadaljevati?\r\n\r\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_SUCCESS=Stranka a\\u017Eurirana\r\n\r\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_ERROR=A\\u017Euriranje ni uspelo\r\n\r\n# XMSG : Account update succeeded\r\nMSG_CREATION_SUCCESS=Stranka kreirana\r\n\r\n# XMSG : Task creation succeeded\r\nMSG_TASK_CREATION_SUCCESS=Naloga kreirana\r\n\r\n# XMSG : Contact creation failed\r\nMSG_CREATION_ERROR=Kreiranje ni uspelo\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong country\r\nMSG_WRONG_COUNTRY_ERROR=Dr\\u017Eava "{0}" ne obstaja\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong region\r\nMSG_WRONG_REGION_ERROR=Regija "{0}" ne obstaja za dr\\u017Eavo\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong employee\r\nMSG_WRONG_EMPLOYEE_ERROR=Zaposleni "{0}" ne obstaja.\r\n\r\n# XMSG: message that will be displayed, if the user has entered invalid website url\r\nMSG_WRONG_URL_ERROR=Vneseni URL "{0}" ni veljaven.\r\n\r\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\r\nMSG_MANDATORY_FIELDS=Izpolnjena niso vsa obvezna polja\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA=Podatke je spremenil drug uporabnik. \\u017Delite prepisati spremembe drugega uporabnika s svojimi?\r\n\r\n# XMSG: message that will be displayed in case of conflicts during file renaming\r\nMSG_CONFLICTING_FILE_NAME=Naziv datoteke je spremenil drug uporabnik. \\u017Delite prepisati spremembe drugega uporabnika s svojimi?\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA_WITH_REFRESH=Podatke je spremenil drug uporabnik. Te spremembe bodo zdaj vidne v aplikaciji.\r\n\r\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\r\nMSG_NOT_IN_MAIN_CONTACT=Ogledate si lahko le detajle kontaktov, ki so dodeljeni tej stranki\r\n\r\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\r\nMSG_EXCEEDING_FILE_NAME_LENGTH=Va\\u0161 naziv datoteke ima lahko najve\\u010D 40 znakov.\r\n\r\n# XTOL, 20: tooltip shown on search result list for button to add an account"\r\n\r\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\r\n\r\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\r\n\r\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\r\n\r\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\r\n\r\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\r\n',
	"cus/crm/myaccounts/i18n/i18n_tr.properties":'# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XFLD, 30: Facet title for general Data\r\nGENERAL_DATA=Genel veriler\r\n\r\n#XTIT, 40: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=M\\u00FC\\u015Fterilerim\r\n\r\n#XTIT, 40: this is the title for the detail screen\r\nDETAIL_TITLE=M\\u00FC\\u015Fteri\r\n\r\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\r\nREVENUE_CURRENT=Bug\\u00FCne kdr.gelir\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\r\nREVENUE_CURRENT_TOOLTIP=Bug\\u00FCne kadarki gelir (g\\u00FCncel y\\u0131l)\r\n\r\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\r\nREVENUE_LAST=Gelir (ge\\u00E7en y\\u0131l)\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\r\nREVENUE_LAST_TOOLTIP=Gelir (ge\\u00E7en y\\u0131l)\r\n\r\n# XFLD, 30: Facet title for opportunities and label in facet general data\r\nOPPORTUNITIES=F\\u0131rsatlar\r\n\r\n#XFLD, 30: Facet title for leads\r\nLEADS=Aday m\\u00FC\\u015Fteriler\r\n\r\n#XFLD, 30: Facet title for tasks\r\nTASKS=G\\u00F6revler\r\n\r\n#XFLD, 30: Facet title for appointments\r\nAPPOINTMENTS=Randevular\r\n\r\n#XFLD, 30: Facet title for quotations\r\nQUOTATIONS=Teklifler\r\n\r\n#XFLD, 30: Facet title for sales orders\r\nSALES_ORDERS=Sat\\u0131\\u015F sipari\\u015Fleri\r\n\r\n#XFLD, 30: W7: Facet title for marketing attributes\r\nMARKETINGATTRIBUTES=Pazarlama nitelikleri\r\n\r\n#XFLD, 30: W6: Title for popup with products\r\nPRODUCTS=\\u00DCr\\u00FCnler\r\n\r\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\r\nEMPLOYEE_RESPONSIBLE=Sorumlu \\u00E7al\\u0131\\u015Fan\r\n\r\n#XFLD, 30: Facet title for Attachments\r\nATTACHMENTS=Ekler\r\n\r\n#XFLD, 30: Facet title for Notes\r\nNOTES=Notlar\r\n\r\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\r\nNEW_NOTE=Yeni not\r\n\r\n#XFLD, 30: Facet title for Contacts\r\nCONTACTS=\\u0130lgili ki\\u015Filer\r\n\r\n#XFLD, 30: Label for Address in facet general data\r\nADDRESS=Adres\r\n\r\n#XFLD, 30: Label for Opportunities in facet general data\r\nUNWEIGHTED_OPPORTUNITIES=F\\u0131rsatlar\r\n\r\n#XFLD, 30: Label for Rating in facet general data\r\nRATING=Derecelendirme\r\n\r\n# XFLD, 30: Label for Next contact in facet Appointments\r\nNEXT_APPOINTMENT=Sonraki randevu\r\n\r\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\r\nLAST_APPOINTMENT=Son randevu\r\n\r\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\r\nIMAGE=G\\u00F6r\\u00FCnt\\u00FC\r\n\r\n#XBUT, 20: Button to show the create actionsheet\r\nCREATE=Olu\\u015Ftur\r\n\r\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\r\nDISCUSS_ENTRY=SAP Jam\'de tart\\u0131\\u015F\r\n\r\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\r\nSHARE_ENTRY=SAP Jam\'de payla\\u015F\r\n\r\n#XBUT, 20: Button to share the note\r\nDETAIL_BUTTON_SHARE=Payla\\u015F\r\n\r\n#XBUT, 20: Button to cancel sharing\r\nDETAIL_BUTTON_CANCEL=\\u0130ptal\r\n\r\n#XFLD,20: All accounts for filter\r\nALL_ACCOUNTS=T\\u00FCm m\\u00FC\\u015Fteriler\r\n\r\n#XFLD,35: All individual accounts for filter\r\nALL_INDIVIDUAL_ACCOUNTS=T\\u00FCm m\\u00FCnferit m\\u00FC\\u015Fteriler\r\n\r\n#XFLD,35: All corporate accounts for filter\r\nALL_CORPORATE_ACCOUNTS=T\\u00FCm kurumsal m\\u00FC\\u015Fteriler\r\n\r\n#XFLD,35: All group accounts for filter\r\nALL_ACCOUNT_GROUPS=T\\u00FCm m\\u00FC\\u015Fteri gruplar\\u0131\r\n\r\n#XFLD,20: my account for filter\r\nMY_ACCOUNT=M\\u00FC\\u015Fterilerim\r\n\r\n#XFLD,35: my individual accounts for filter\r\nMY_INDIVIDUAL_ACCOUNTS=M\\u00FCnferit m\\u00FC\\u015Fterilerim\r\n\r\n#XFLD,35: my corporate accounts for filter\r\nMY_CORPORATE_ACCOUNTS=Kurumsal m\\u00FC\\u015Fterilerim\r\n\r\n#XFLD,35: my group accounts for filter\r\nMY_ACCOUNT_GROUPS=M\\u00FC\\u015Fteri gruplar\\u0131m\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nINDIVIDUAL_ACCOUNT=Bireysel m\\u00FC\\u015Fteri\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nCORPORATE_ACCOUNT=Kurumsal m\\u00FC\\u015Fteri\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nACCOUNT_GROUP=M\\u00FC\\u015Fteri grubu\r\n\r\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\r\nSTARTING=Ba\\u015Flang\\u0131\\u00E7 tarihi\\: {0}\r\n\r\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\r\nCLOSING=Kapan\\u0131\\u015F tarihi\\: {0}\r\n\r\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\r\nDUE=Son tarih\\: {0}\r\n\r\n#XFLD,20: All accounts for title\r\nALL_ACCOUNTS_TITLE=T\\u00FCm m\\u00FC\\u015Fteriler ({0})\r\n\r\n#XFLD,35: All individual accounts for title\r\nALL_INDIVIDUAL_ACCOUNTS_TITLE=T\\u00FCm m\\u00FCnferit m\\u00FC\\u015Fteriler ({0})\r\n\r\n#XFLD,35: All corporate accounts for title\r\nALL_CORPORATE_ACCOUNTS_TITLE=T\\u00FCm kurumsal m\\u00FC\\u015Fteriler ({0})\r\n\r\n#XFLD,35: All group accounts for title\r\nALL_ACCOUNT_GROUPS_TITLE=T\\u00FCm m\\u00FC\\u015Fteri gruplar\\u0131 ({0})\r\n\r\n#XFLD,20: my account for title\r\nMY_ACCOUNT_TITLE=M\\u00FC\\u015Fterilerim ({0})\r\n\r\n#XFLD,35: my individual account for title\r\nMY_INDIVIDUAL_ACCOUNT_TITLE=M\\u00FCnferit m\\u00FC\\u015Fterilerim ({0})\r\n\r\n#XFLD,35: my corporate account for title.\r\nMY_CORPORATE_ACCOUNT_TITLE=Kurumsal m\\u00FC\\u015Fterilerim ({0})\r\n\r\n#XFLD,35: my group account for title\r\nMY_ACCOUNT_GROUP_TITLE=M\\u00FC\\u015Fteri gruplar\\u0131m ({0})\r\n\r\n#XFLD,30: filtered by info\r\nFILTERED_BY=Filtreleme \\u00F6l\\u00E7\\u00FCt\\u00FC\\: {0}\r\n\r\n#XFLD,30: label, search for accounts\r\nSEARCH_ACCOUNTS=Ara\r\n\r\n#XFLD,30: comma separator for location\r\nLOCATION={0}, {1}\r\n\r\n#XFLD: W4: Label for All day text in Appointments\r\nALL_DAY_EVENT=T\\u00FCm g\\u00FCn\r\n\r\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\r\nDURATION_MINUTE={0} dak\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\r\nDURATION_HOUR={0} s\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\r\nDURATION_DAY={0} g\\u00FCn\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\r\nDURATION_DAYS={0} g\\u00FCn\r\n\r\n#XFLD: W4: Label for Private meeting\r\nPRIVATE=Ki\\u015Fisel\r\n\r\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\r\nSELECT_TRANSACTION_TYPE=\\u0130\\u015Flem t\\u00FCr\\u00FC se\\u00E7\r\n\r\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\r\nNEW_TASK_INPUT_PLACEHOLDER=Yeni g\\u00F6rev\r\n\r\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nNO_DATA_TEXT=Veri mevcut de\\u011Fil\r\n\r\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nLOADING_TEXT=Y\\u00FCkleniyor...\r\n\r\n#XFLD,25: W4: Column label for name of contact person in contacts\r\nNAME=Ad\r\n\r\n#XFLD,25: W5: Column label for department of contact person in contacts\r\nDEPARTMENT=Departman\r\n\r\n#XFLD,15: W6: Column label for actions of contact person in contacts\r\nACTIONS=\\u0130\\u015Flemler\r\n\r\n#XFLD,25: W4: Column label for description of lead in Leads\r\nDESCRIPTION=Tan\\u0131m\r\n\r\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\r\nASSIGNED_TO=\\u015Euna tayin edildi\r\n\r\n#XFLD,15: W4: Column label for end date of lead in Leads\r\nEND_DATE=Biti\\u015F tarihi\r\n\r\n#XFLD,15: W4: Column label for qualification level of lead in Leads\r\nQUALIFICATION=Nitelik\r\n\r\n#XFLD,15: W4: Column label for status of lead in Leads\r\nSTATUS=Durum\r\n\r\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\r\nMAIN_CONTACT=Ana ilgili ki\\u015Fi\r\n\r\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\r\nVOLUME=Sat\\u0131\\u015F has\\u0131lat\\u0131\r\n\r\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\r\nPROBABILITY=Olas\\u0131l\\u0131k\r\n\r\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\r\nCLOSE_BY=Kapan\\u0131\\u015F tarihi\r\n\r\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \r\nVIEWS=G\\u00F6r\\u00FCn\\u00FCmler\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\r\nCONTACT_TITLE=\\u0130lgili ki\\u015Fi\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\r\nEMPLOYEE_TITLE=\\u00C7al\\u0131\\u015Fan\r\n\r\n#XTIT,20: W7: Title of pop-up used in confirm popup\r\nCONFIRM_TITLE=Teyit et\r\n\r\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\r\nCOMPANY_NAME=Ad\r\n\r\n#XFLD,20: W4: Label for name 1 of a company used general data\r\nCOMPANY_NAME1=Ad 1\r\n\r\n#XFLD,20: W4: Label for name 2 of a company used general data\r\nCOMPANY_NAME2=Ad 2\r\n\r\n#XFLD,20: W4: Label for first name of a person used general data\r\nFIRST_NAME=Ad\\u0131\r\n\r\n#XFLD,20: W4: Label for last name of a person used general data\r\nLAST_NAME=Soyad\\u0131\r\n\r\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nBIRTHDAY=Do\\u011Fum tarihi\r\n\r\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nTITLE=Ba\\u015Fl\\u0131k\r\n\r\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nACADEMIC_TITLE=Akademik unvan\r\n\r\n#XFLD,20: W4: Label for mobile phone number used general data\r\nMOBILE=Cep telefonu\r\n\r\n#XFLD,20: W4: Label for phone number used general data\r\nPHONE=Telefon\r\n\r\n#XFLD,20: W4: Label for e-mail used general data\r\nEMAIL=E-posta\r\n\r\n#XFLD,20: W4: Label for web site used general data\r\nWEBSITE=Web sitesi\r\n\r\n#XFLD,20: W4: Label for country used general data\r\nCOUNTRY=\\u00DClke\r\n\r\n#XFLD,20: W4: Label for region used general data\r\nREGION=B\\u00F6lge\r\n\r\n#XFLD,20: W4: Label for city used general data\r\nCITY=\\u015Eehir\r\n\r\n#XFLD,20: W4: Label for postal code used general data\r\nPOSTAL_CODE=Posta kodu\r\n\r\n#XFLD,20: W4: Label for street used general data\r\nSTREET=Sokak\r\n\r\n#XFLD,10: W4: Label for house number used general data\r\nHOUSE_NUMBER=Konut no.\r\n\r\n#XFLD,15: W6: Label for ID used in Quotations\r\nID=Tan\\u0131t\\u0131c\\u0131\r\n\r\n#XFLD,15: W6: Label for Amount used in Quotations\r\nAMOUNT=Tutar\r\n\r\n#XFLD,20: W6: Label for Expiration Date used in Quotations\r\nEXPIRATION_DATE=Ge\\u00E7erlilik sonu\r\n\r\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\r\nDELIVERY_DATE=Teslimat tarihi\r\n\r\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\r\nSALES_EMPLOYEE=Sat\\u0131\\u015F \\u00E7al\\u0131\\u015Fan\\u0131\r\n\r\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\r\nATTRIBUTESET=Nitelik k\\u00FCmesi\r\n\r\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\r\nATTRIBUTE=Nitelik\r\n\r\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\r\nVALUE=De\\u011Fer\r\n\r\n#XBUT, 20: Button to create an Account\r\nBUTTON_ADD=Ekle\r\n\r\n#XBUT, 20: Button to edit an Account\r\nBUTTON_EDIT=D\\u00FCzenle\r\n\r\n#XBUT, 20: Button to save changes\r\nBUTTON_SAVE=Kaydet\r\n\r\n#XBUT, 20: Button to cancel changes\r\nBUTTON_CANCEL=\\u0130ptal\r\n\r\n#XBUT, 30: Button which shows the personalization buttons\r\nBUTTON_SHOW_PERSONALIZATION=Ki\\u015Fisll\\u015Ft.g\\u00F6ster\r\n\r\n#XBUT, 30: Button which hides the personalization buttons\r\nBUTTON_HIDE_PERSONALIZATION=Ki\\u015Fisll\\u015Ft.gizle\r\n\r\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_CONFIRM_CANCEL=Kaydedilmeyen de\\u011Fi\\u015Fiklikler kaybolacak. Devam etmek istiyor musunuz?\r\n\r\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\r\nMSG_CONFIRM_DELETE_CONTACT=M\\u00FC\\u015Fteriden irtibat tayini kald\\u0131r\\u0131lacak. Devam etmek istiyor musunuz?\r\n\r\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_SUCCESS=Hesap g\\u00FCncellendi\r\n\r\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_ERROR=G\\u00FCncelleme ba\\u015Far\\u0131s\\u0131z\r\n\r\n# XMSG : Account update succeeded\r\nMSG_CREATION_SUCCESS=Hesap olu\\u015Fturuldu\r\n\r\n# XMSG : Task creation succeeded\r\nMSG_TASK_CREATION_SUCCESS=G\\u00F6rev olu\\u015Fturuldu\r\n\r\n# XMSG : Contact creation failed\r\nMSG_CREATION_ERROR=Olu\\u015Fturma ba\\u015Far\\u0131s\\u0131z oldu\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong country\r\nMSG_WRONG_COUNTRY_ERROR=\\u00DClke "{0}" mevcut de\\u011Fil\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong region\r\nMSG_WRONG_REGION_ERROR=B\\u00F6lge "{0}" \\u00FClke i\\u00E7in mevcut de\\u011Fil\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong employee\r\nMSG_WRONG_EMPLOYEE_ERROR=\\u00C7al\\u0131\\u015Fan "{0}" mevcut de\\u011Fil.\r\n\r\n# XMSG: message that will be displayed, if the user has entered invalid website url\r\nMSG_WRONG_URL_ERROR=Girilen URL "{0}" ge\\u00E7erli de\\u011Fil.\r\n\r\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\r\nMSG_MANDATORY_FIELDS=T\\u00FCm zorunlu alanlar doldurulmad\\u0131\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA=Veriler ba\\u015Fka kullan\\u0131c\\u0131 taraf\\u0131ndan de\\u011Fi\\u015Ftirildi. Di\\u011Fer kullan\\u0131c\\u0131n\\u0131n de\\u011Fi\\u015Fikliklerinin \\u00FCzerine kendikilerinizi yazmak istiyor musunuz?\r\n\r\n# XMSG: message that will be displayed in case of conflicts during file renaming\r\nMSG_CONFLICTING_FILE_NAME=Dosya ad\\u0131 ba\\u015Fka kullan\\u0131c\\u0131 taraf\\u0131ndan de\\u011Fi\\u015Ftirildi. Di\\u011Fer kullan\\u0131c\\u0131n\\u0131n de\\u011Fi\\u015Fikliklerinin \\u00FCzerine kendikilerinizi yazmak istiyor musunuz?\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA_WITH_REFRESH=Veri ba\\u015Fka bir kullan\\u0131c\\u0131 taraf\\u0131ndan de\\u011Fi\\u015Ftirildi. Bu de\\u011Fi\\u015Fiklikler \\u015Fimdi uygulamada g\\u00F6r\\u00FCnecek.\r\n\r\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\r\nMSG_NOT_IN_MAIN_CONTACT=Yaln\\u0131zca bu hesaba tayin edilen ilgili ki\\u015Finin ayr\\u0131nt\\u0131lar\\u0131n\\u0131 g\\u00F6r\\u00FCnt\\u00FCleyebilirsiniz\r\n\r\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\r\nMSG_EXCEEDING_FILE_NAME_LENGTH=Dosya ad\\u0131n\\u0131z azami 40 karakter i\\u00E7erebilir.\r\n\r\n# XTOL, 20: tooltip shown on search result list for button to add an account"\r\nADD_ACCOUNT_TOOLTIP=M\\u00FC\\u015Fteri ekle\r\n\r\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\r\nADD_MARKETING_ATTRIBUTE_TOOLTIP=Pazarlama niteli\\u011Fi ekle\r\n\r\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\r\nADD_CONTACT_TOOLTIP=\\u0130lgili ki\\u015Fi ekle\r\n\r\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\r\nADD_APPOINTMENT_TOOLTIP=Randevu ekle\r\n\r\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\r\nADD_TASK_TOOLTIP=G\\u00F6rev ekle\r\n\r\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\r\nADD_OPPORTUNITY_TOOLTIP=F\\u0131rsat ekle\r\n',
	"cus/crm/myaccounts/i18n/i18n_zh_CN.properties":'# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XFLD, 30: Facet title for general Data\r\nGENERAL_DATA=\\u5E38\\u89C4\\u6570\\u636E\r\n\r\n#XTIT, 40: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=\\u6211\\u7684\\u5BA2\\u6237\r\n\r\n#XTIT, 40: this is the title for the detail screen\r\nDETAIL_TITLE=\\u5BA2\\u6237\r\n\r\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\r\nREVENUE_CURRENT=\\u5F53\\u524D\\u5E74\\u5EA6\\u8FC4\\u4ECA\\u7684\\u6536\\u5165\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\r\nREVENUE_CURRENT_TOOLTIP=\\u5F53\\u524D\\u5E74\\u5EA6\\u8FC4\\u4ECA\\u7684\\u6536\\u5165\r\n\r\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\r\nREVENUE_LAST=\\u53BB\\u5E74\\u7684\\u6536\\u5165\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\r\nREVENUE_LAST_TOOLTIP=\\u53BB\\u5E74\\u7684\\u6536\\u5165\r\n\r\n# XFLD, 30: Facet title for opportunities and label in facet general data\r\nOPPORTUNITIES=\\u673A\\u4F1A\r\n\r\n#XFLD, 30: Facet title for leads\r\nLEADS=\\u7EBF\\u7D22\r\n\r\n#XFLD, 30: Facet title for tasks\r\nTASKS=\\u4EFB\\u52A1\r\n\r\n#XFLD, 30: Facet title for appointments\r\nAPPOINTMENTS=\\u9884\\u7EA6\r\n\r\n#XFLD, 30: Facet title for quotations\r\nQUOTATIONS=\\u62A5\\u4EF7\r\n\r\n#XFLD, 30: Facet title for sales orders\r\nSALES_ORDERS=\\u9500\\u552E\\u8BA2\\u5355\r\n\r\n#XFLD, 30: W7: Facet title for marketing attributes\r\nMARKETINGATTRIBUTES=\\u5E02\\u573A\\u8425\\u9500\\u5C5E\\u6027\r\n\r\n#XFLD, 30: W6: Title for popup with products\r\nPRODUCTS=\\u4EA7\\u54C1\r\n\r\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\r\nEMPLOYEE_RESPONSIBLE=\\u8D1F\\u8D23\\u4EBA\r\n\r\n#XFLD, 30: Facet title for Attachments\r\nATTACHMENTS=\\u9644\\u4EF6\r\n\r\n#XFLD, 30: Facet title for Notes\r\nNOTES=\\u6CE8\\u91CA\r\n\r\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\r\nNEW_NOTE=\\u65B0\\u6CE8\\u91CA\r\n\r\n#XFLD, 30: Facet title for Contacts\r\nCONTACTS=\\u8054\\u7CFB\\u4EBA\r\n\r\n#XFLD, 30: Label for Address in facet general data\r\nADDRESS=\\u5730\\u5740\r\n\r\n#XFLD, 30: Label for Opportunities in facet general data\r\nUNWEIGHTED_OPPORTUNITIES=\\u673A\\u4F1A\r\n\r\n#XFLD, 30: Label for Rating in facet general data\r\nRATING=\\u8BC4\\u7EA7\r\n\r\n# XFLD, 30: Label for Next contact in facet Appointments\r\nNEXT_APPOINTMENT=\\u4E0B\\u4E2A\\u9884\\u7EA6\r\n\r\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\r\nLAST_APPOINTMENT=\\u6700\\u540E\\u4E00\\u4E2A\\u9884\\u7EA6\r\n\r\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\r\nIMAGE=\\u56FE\\u50CF\r\n\r\n#XBUT, 20: Button to show the create actionsheet\r\nCREATE=\\u521B\\u5EFA\r\n\r\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\r\nDISCUSS_ENTRY=\\u5728 SAP Jam \\u4E0A\\u8BA8\\u8BBA\r\n\r\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\r\nSHARE_ENTRY=\\u5728 SAP Jam \\u4E2D\\u5171\\u4EAB\r\n\r\n#XBUT, 20: Button to share the note\r\nDETAIL_BUTTON_SHARE=\\u5171\\u4EAB\r\n\r\n#XBUT, 20: Button to cancel sharing\r\nDETAIL_BUTTON_CANCEL=\\u53D6\\u6D88\r\n\r\n#XFLD,20: All accounts for filter\r\nALL_ACCOUNTS=\\u5168\\u90E8\\u5BA2\\u6237\r\n\r\n#XFLD,35: All individual accounts for filter\r\nALL_INDIVIDUAL_ACCOUNTS=\\u6240\\u6709\\u4E2A\\u4EBA\\u5BA2\\u6237\r\n\r\n#XFLD,35: All corporate accounts for filter\r\nALL_CORPORATE_ACCOUNTS=\\u6240\\u6709\\u516C\\u53F8\\u5BA2\\u6237\r\n\r\n#XFLD,35: All group accounts for filter\r\nALL_ACCOUNT_GROUPS=\\u6240\\u6709\\u5BA2\\u6237\\u7EC4\r\n\r\n#XFLD,20: my account for filter\r\nMY_ACCOUNT=\\u6211\\u7684\\u5BA2\\u6237\r\n\r\n#XFLD,35: my individual accounts for filter\r\nMY_INDIVIDUAL_ACCOUNTS=\\u6211\\u7684\\u4E2A\\u4EBA\\u5BA2\\u6237\r\n\r\n#XFLD,35: my corporate accounts for filter\r\nMY_CORPORATE_ACCOUNTS=\\u6211\\u7684\\u516C\\u53F8\\u5BA2\\u6237\r\n\r\n#XFLD,35: my group accounts for filter\r\nMY_ACCOUNT_GROUPS=\\u6211\\u7684\\u5BA2\\u6237\\u7EC4\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nINDIVIDUAL_ACCOUNT=\\u4E2A\\u4EBA\\u5BA2\\u6237\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nCORPORATE_ACCOUNT=\\u516C\\u53F8\\u5BA2\\u6237\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nACCOUNT_GROUP=\\u5BA2\\u6237\\u7EC4\r\n\r\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\r\nSTARTING=\\u5F00\\u59CB\\u65E5\\u671F\\uFF1A {0}\r\n\r\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\r\nCLOSING=\\u7ED3\\u675F\\u65E5\\u671F\\uFF1A {0}\r\n\r\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\r\nDUE=\\u5230\\u671F\\u65E5\\u671F\\uFF1A {0}\r\n\r\n#XFLD,20: All accounts for title\r\nALL_ACCOUNTS_TITLE=\\u6240\\u6709\\u5BA2\\u6237 ({0})\r\n\r\n#XFLD,35: All individual accounts for title\r\nALL_INDIVIDUAL_ACCOUNTS_TITLE=\\u6240\\u6709\\u4E2A\\u4EBA\\u5BA2\\u6237 ({0})\r\n\r\n#XFLD,35: All corporate accounts for title\r\nALL_CORPORATE_ACCOUNTS_TITLE=\\u6240\\u6709\\u516C\\u53F8\\u5BA2\\u6237 ({0})\r\n\r\n#XFLD,35: All group accounts for title\r\nALL_ACCOUNT_GROUPS_TITLE=\\u6240\\u6709\\u5BA2\\u6237\\u7EC4 ({0})\r\n\r\n#XFLD,20: my account for title\r\nMY_ACCOUNT_TITLE=\\u6211\\u7684\\u5BA2\\u6237 ({0})\r\n\r\n#XFLD,35: my individual account for title\r\nMY_INDIVIDUAL_ACCOUNT_TITLE=\\u6211\\u7684\\u4E2A\\u4EBA\\u5BA2\\u6237 ({0})\r\n\r\n#XFLD,35: my corporate account for title.\r\nMY_CORPORATE_ACCOUNT_TITLE=\\u6211\\u7684\\u516C\\u53F8\\u5BA2\\u6237 ({0})\r\n\r\n#XFLD,35: my group account for title\r\nMY_ACCOUNT_GROUP_TITLE=\\u6211\\u7684\\u5BA2\\u6237\\u7EC4 ({0})\r\n\r\n#XFLD,30: filtered by info\r\nFILTERED_BY=\\u8FC7\\u6EE4\\u6761\\u4EF6\\uFF1A {0}\r\n\r\n#XFLD,30: label, search for accounts\r\nSEARCH_ACCOUNTS=\\u641C\\u7D22\r\n\r\n#XFLD,30: comma separator for location\r\nLOCATION={0}, {1}\r\n\r\n#XFLD: W4: Label for All day text in Appointments\r\nALL_DAY_EVENT=\\u5168\\u5929\r\n\r\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\r\nDURATION_MINUTE={0} \\u5206\\u949F\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\r\nDURATION_HOUR={0} \\u5C0F\\u65F6\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\r\nDURATION_DAY={0} \\u5929\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\r\nDURATION_DAYS={0} \\u5929\r\n\r\n#XFLD: W4: Label for Private meeting\r\nPRIVATE=\\u79C1\\u4EBA\r\n\r\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\r\nSELECT_TRANSACTION_TYPE=\\u9009\\u62E9\\u4E8B\\u52A1\\u7C7B\\u578B\r\n\r\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\r\nNEW_TASK_INPUT_PLACEHOLDER=\\u65B0\\u5EFA\\u4EFB\\u52A1\r\n\r\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nNO_DATA_TEXT=\\u65E0\\u6570\\u636E\r\n\r\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nLOADING_TEXT=\\u6B63\\u5728\\u52A0\\u8F7D...\r\n\r\n#XFLD,25: W4: Column label for name of contact person in contacts\r\nNAME=\\u59D3\\u540D\r\n\r\n#XFLD,25: W5: Column label for department of contact person in contacts\r\nDEPARTMENT=\\u90E8\\u95E8\r\n\r\n#XFLD,15: W6: Column label for actions of contact person in contacts\r\nACTIONS=\\u64CD\\u4F5C\r\n\r\n#XFLD,25: W4: Column label for description of lead in Leads\r\nDESCRIPTION=\\u63CF\\u8FF0\r\n\r\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\r\nASSIGNED_TO=\\u5DF2\\u5206\\u914D\\u5230\r\n\r\n#XFLD,15: W4: Column label for end date of lead in Leads\r\nEND_DATE=\\u7ED3\\u675F\\u65E5\\u671F\r\n\r\n#XFLD,15: W4: Column label for qualification level of lead in Leads\r\nQUALIFICATION=\\u8D44\\u683C\\u5BA1\\u6838\r\n\r\n#XFLD,15: W4: Column label for status of lead in Leads\r\nSTATUS=\\u72B6\\u6001\r\n\r\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\r\nMAIN_CONTACT=\\u4E3B\\u8981\\u8054\\u7CFB\\u4EBA\r\n\r\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\r\nVOLUME=\\u9500\\u552E\\u989D\r\n\r\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\r\nPROBABILITY=\\u6982\\u7387\r\n\r\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\r\nCLOSE_BY=\\u5173\\u95ED\\u65E5\\u671F\r\n\r\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \r\nVIEWS=\\u89C6\\u56FE\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\r\nCONTACT_TITLE=\\u8054\\u7CFB\\u4EBA\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\r\nEMPLOYEE_TITLE=\\u5458\\u5DE5\r\n\r\n#XTIT,20: W7: Title of pop-up used in confirm popup\r\nCONFIRM_TITLE=\\u786E\\u8BA4\r\n\r\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\r\nCOMPANY_NAME=\\u540D\\u79F0\r\n\r\n#XFLD,20: W4: Label for name 1 of a company used general data\r\nCOMPANY_NAME1=\\u540D\\u79F0 1\r\n\r\n#XFLD,20: W4: Label for name 2 of a company used general data\r\nCOMPANY_NAME2=\\u540D\\u79F0 2\r\n\r\n#XFLD,20: W4: Label for first name of a person used general data\r\nFIRST_NAME=\\u540D\r\n\r\n#XFLD,20: W4: Label for last name of a person used general data\r\nLAST_NAME=\\u59D3\r\n\r\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nBIRTHDAY=\\u51FA\\u751F\\u65E5\\u671F\r\n\r\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nTITLE=\\u5934\\u8854\r\n\r\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nACADEMIC_TITLE=\\u804C\\u79F0\r\n\r\n#XFLD,20: W4: Label for mobile phone number used general data\r\nMOBILE=\\u624B\\u673A\r\n\r\n#XFLD,20: W4: Label for phone number used general data\r\nPHONE=\\u7535\\u8BDD\r\n\r\n#XFLD,20: W4: Label for e-mail used general data\r\nEMAIL=\\u7535\\u5B50\\u90AE\\u4EF6\r\n\r\n#XFLD,20: W4: Label for web site used general data\r\nWEBSITE=\\u7F51\\u7AD9\r\n\r\n#XFLD,20: W4: Label for country used general data\r\nCOUNTRY=\\u56FD\\u5BB6\r\n\r\n#XFLD,20: W4: Label for region used general data\r\nREGION=\\u5730\\u533A\r\n\r\n#XFLD,20: W4: Label for city used general data\r\nCITY=\\u57CE\\u5E02\r\n\r\n#XFLD,20: W4: Label for postal code used general data\r\nPOSTAL_CODE=\\u90AE\\u653F\\u7F16\\u7801\r\n\r\n#XFLD,20: W4: Label for street used general data\r\nSTREET=\\u8857\\u9053\r\n\r\n#XFLD,10: W4: Label for house number used general data\r\nHOUSE_NUMBER=\\u95E8\\u724C\\u53F7\r\n\r\n#XFLD,15: W6: Label for ID used in Quotations\r\nID=\\u6807\\u8BC6\r\n\r\n#XFLD,15: W6: Label for Amount used in Quotations\r\nAMOUNT=\\u91D1\\u989D\r\n\r\n#XFLD,20: W6: Label for Expiration Date used in Quotations\r\nEXPIRATION_DATE=\\u5230\\u671F\\u65E5\\u671F\r\n\r\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\r\nDELIVERY_DATE=\\u4EA4\\u8D27\\u65E5\\u671F\r\n\r\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\r\nSALES_EMPLOYEE=\\u9500\\u552E\\u5458\r\n\r\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\r\nATTRIBUTESET=\\u5C5E\\u6027\\u96C6\r\n\r\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\r\nATTRIBUTE=\\u5C5E\\u6027\r\n\r\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\r\nVALUE=\\u503C\r\n\r\n#XBUT, 20: Button to create an Account\r\nBUTTON_ADD=\\u6DFB\\u52A0\r\n\r\n#XBUT, 20: Button to edit an Account\r\nBUTTON_EDIT=\\u7F16\\u8F91\r\n\r\n#XBUT, 20: Button to save changes\r\nBUTTON_SAVE=\\u4FDD\\u5B58\r\n\r\n#XBUT, 20: Button to cancel changes\r\nBUTTON_CANCEL=\\u53D6\\u6D88\r\n\r\n#XBUT, 30: Button which shows the personalization buttons\r\nBUTTON_SHOW_PERSONALIZATION=\\u663E\\u793A\\u4E2A\\u6027\\u5316\\u8BBE\\u7F6E\r\n\r\n#XBUT, 30: Button which hides the personalization buttons\r\nBUTTON_HIDE_PERSONALIZATION=\\u9690\\u85CF\\u4E2A\\u6027\\u5316\\u8BBE\\u7F6E\r\n\r\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_CONFIRM_CANCEL=\\u6240\\u6709\\u672A\\u4FDD\\u5B58\\u7684\\u66F4\\u6539\\u5C06\\u4E22\\u5931\\u3002\\u662F\\u5426\\u7EE7\\u7EED\\uFF1F\r\n\r\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\r\nMSG_CONFIRM_DELETE_CONTACT=\\u5C06\\u53D6\\u6D88\\u8054\\u7CFB\\u4EBA\\u4E0E\\u5BA2\\u6237\\u7684\\u5173\\u7CFB\\u3002\\u662F\\u5426\\u7EE7\\u7EED\\uFF1F\r\n\r\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_SUCCESS=\\u5BA2\\u6237\\u5DF2\\u66F4\\u65B0\r\n\r\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_ERROR=\\u66F4\\u65B0\\u5931\\u8D25\r\n\r\n# XMSG : Account update succeeded\r\nMSG_CREATION_SUCCESS=\\u5BA2\\u6237\\u5DF2\\u521B\\u5EFA\r\n\r\n# XMSG : Task creation succeeded\r\nMSG_TASK_CREATION_SUCCESS=\\u4EFB\\u52A1\\u5DF2\\u521B\\u5EFA\r\n\r\n# XMSG : Contact creation failed\r\nMSG_CREATION_ERROR=\\u521B\\u5EFA\\u5931\\u8D25\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong country\r\nMSG_WRONG_COUNTRY_ERROR=\\u56FD\\u5BB6 "{0}" \\u4E0D\\u5B58\\u5728\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong region\r\nMSG_WRONG_REGION_ERROR=\\u56FD\\u5BB6\\u7684\\u5730\\u533A "{0}" \\u4E0D\\u5B58\\u5728\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong employee\r\nMSG_WRONG_EMPLOYEE_ERROR=\\u5458\\u5DE5 "{0}" \\u4E0D\\u5B58\\u5728\\u3002\r\n\r\n# XMSG: message that will be displayed, if the user has entered invalid website url\r\nMSG_WRONG_URL_ERROR=\\u8F93\\u5165\\u7684 URL "{0}" \\u65E0\\u6548\\u3002\r\n\r\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\r\nMSG_MANDATORY_FIELDS=\\u672A\\u586B\\u5199\\u90E8\\u5206\\u5FC5\\u586B\\u5B57\\u6BB5\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA=\\u6570\\u636E\\u5DF2\\u88AB\\u5176\\u4ED6\\u7528\\u6237\\u66F4\\u6539\\u3002\\u662F\\u5426\\u4F7F\\u7528\\u60A8\\u81EA\\u5DF1\\u7684\\u66F4\\u6539\\u8986\\u76D6\\u5176\\u4ED6\\u7528\\u6237\\u7684\\u66F4\\u6539\\uFF1F\r\n\r\n# XMSG: message that will be displayed in case of conflicts during file renaming\r\nMSG_CONFLICTING_FILE_NAME=\\u6587\\u4EF6\\u540D\\u5DF2\\u88AB\\u5176\\u4ED6\\u7528\\u6237\\u66F4\\u6539\\u3002\\u662F\\u5426\\u4F7F\\u7528\\u60A8\\u81EA\\u5DF1\\u7684\\u66F4\\u6539\\u8986\\u76D6\\u5176\\u4ED6\\u7528\\u6237\\u7684\\u66F4\\u6539\\uFF1F\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA_WITH_REFRESH=\\u5176\\u4ED6\\u7528\\u6237\\u5DF2\\u66F4\\u6539\\u6570\\u636E\\u3002\\u5E94\\u7528\\u4E2D\\u5C06\\u663E\\u793A\\u8FD9\\u4E9B\\u66F4\\u6539\\u3002\r\n\r\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\r\nMSG_NOT_IN_MAIN_CONTACT=\\u53EA\\u80FD\\u67E5\\u770B\\u5206\\u914D\\u7ED9\\u6B64\\u5BA2\\u6237\\u7684\\u8054\\u7CFB\\u4EBA\\u7684\\u8BE6\\u7EC6\\u4FE1\\u606F\r\n\r\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\r\nMSG_EXCEEDING_FILE_NAME_LENGTH=\\u6587\\u4EF6\\u540D\\u6700\\u591A\\u53EF\\u5305\\u542B 40 \\u4E2A\\u5B57\\u7B26\\u3002\r\n\r\n# XTOL, 20: tooltip shown on search result list for button to add an account"\r\nADD_ACCOUNT_TOOLTIP=\\u6DFB\\u52A0\\u5BA2\\u6237\r\n\r\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\r\nADD_MARKETING_ATTRIBUTE_TOOLTIP=\\u6DFB\\u52A0\\u5E02\\u573A\\u8425\\u9500\\u5C5E\\u6027\r\n\r\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\r\nADD_CONTACT_TOOLTIP=\\u6DFB\\u52A0\\u8054\\u7CFB\\u4EBA\r\n\r\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\r\nADD_APPOINTMENT_TOOLTIP=\\u6DFB\\u52A0\\u9884\\u7EA6\r\n\r\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\r\nADD_TASK_TOOLTIP=\\u6DFB\\u52A0\\u4EFB\\u52A1\r\n\r\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\r\nADD_OPPORTUNITY_TOOLTIP=\\u6DFB\\u52A0\\u673A\\u4F1A\r\n',
	"cus/crm/myaccounts/util/ApptListItem.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("cus.crm.myaccounts.util.ApptListItem");
jQuery.sap.require("sap.m.ListItemBase");

sap.m.ListItemBase.extend("cus.crm.myaccounts.util.ApptListItem", {

	metadata : {
		// ---- control specific ----
		library : "cus.crm.myaccounts.util",
		defaultAggregation : "content",
		aggregations : {
			"content" : {
				type : "sap.ui.core.Control",
				multiple : true,
				singularName : "content",
				bindable : "bindable"
			}
		},

		properties : {
			"title" : {
				type : "string"
			},
			"subtitle" : {
				type : "string"
			},
			"account" : {
				type : "string"
			},
			"location" : {
				type : "string"
			},
			"time" : {
				type : "string"
			},
			"duration" : {
				type : "string"
			},
			"privat" : {
				type : "boolean"
			}
		},
		
		events : {
			"press" : {allowPreventDefault : true}
		}
	},

	renderer : {

		renderLIContent : function(oRm, oControl) {

			oRm.write("<div class='listItemCSS'");
			oRm.write(">");			

			oRm.write("<div ");
			oRm.addClass("cusMyApptLiOutter");
			oRm.writeClasses();
			oRm.write(">");
			
			// attachment needle first
			oRm.write("<div ");
			oRm.addClass("cusMyApptLiAttch");
			oRm.writeClasses();
			oRm.write(">");
			oRm.renderControl(oControl.getContent()[1]); 
			oRm.write("</div>");			
			
			// - left part of item
			oRm.write("<div ");
			oRm.addClass("cusMyApptLiLeft");
			if (sap.ui.Device.system.phone) {
				oRm.addClass("cusMyApptLiLeftPhone");// different width as no Duration is needed
			}
			oRm.addClass("cusMyApptLiPadding");
			oRm.writeClasses();
			oRm.write(">");
			// -- Time
			oRm.write("<div ");
			oRm.addClass("cusMyApptLiTime");
			oRm.addClass("cusMyApptLiEllipsis");
			oRm.addClass("sapMSLITitle");
			oRm.addClass("sapThemeText-asColor");
			oRm.writeClasses();
			oRm.write(">");
			if (oControl.getTime()) {
				oRm.writeEscaped(oControl.getTime());
			}
			oRm.write("</div>");

			// -- Duration
			if (!sap.ui.Device.system.phone) { // Duration is not shown in phone layout
				oRm.write("<div ");
				oRm.addClass("cusMyApptLiEllipsis");
				oRm.addClass("sapMSLIDescription");
				oRm.writeClasses();
				oRm.write(">");
				if (oControl.getDuration()) {
					oRm.writeEscaped(oControl.getDuration());
				}
				oRm.write("</div>");
			}
			oRm.write("</div>");

			// - middle part Item

			oRm.write("<div ");
			oRm.addClass("cusMyApptLiMiddle");
			oRm.addClass("cusMyApptLiPadding");
			if (sap.ui.Device.system.phone) {
				oRm.addClass("cusMyApptLiMiddlePhone");// different width as there is no right part
			}
			oRm.writeClasses();
			oRm.write(">");

			// -- Titel
			oRm.write("<div ");
			oRm.addClass("cusMyApptLiEllipsis");
			oRm.addClass("cusMyApptLiTitel");
			oRm.addClass("sapThemeFontSize");
			oRm.addClass("sapMSLITitle");
			oRm.writeClasses();
			oRm.write(">");
			oRm.write("<a href='javascript:void(0);' class='sapMLnk'>");
			if (oControl.getTitle()) {
				oRm.writeEscaped(oControl.getTitle());
			}
			oRm.write("</a> ");
			oRm.write("</div>");

			// -- Subtitle
			if (sap.ui.Device.system.phone) {
				// --- Phone--> Location only
				oRm.write("<div ");
				oRm.addClass("sapMSLIDescription");
				oRm.addClass("cusMyApptLiEllipsis");
				oRm.writeClasses();
				oRm.write(">");
				if (oControl.getLocation()) {
					oRm.writeEscaped(oControl.getLocation());
				}
				oRm.write("</div>");
			} else { // Desktop + Tablet
				oRm.write("<div ");
				oRm.addClass("sapMSLIDescription");
				oRm.addClass("cusMyApptLiEllipsis");
				oRm.writeClasses();
				oRm.write(">");
				if (oControl.getSubtitle()) {
					oRm.writeEscaped(oControl.getSubtitle());
				}
				oRm.write("</div>");
			}
			oRm.write("</div>");

			// - right part of item
			// is not relevant in phone layout
			if (!sap.ui.Device.system.phone) {
				oRm.write("<div ");
				oRm.addClass("cusMyApptLiRight");
				oRm.addClass("cusMyApptLiPadding");
				oRm.writeClasses();
				oRm.write(">");

				// Status
				oRm.write("<div ");
				oRm.addClass("cusMyApptLiEllipsis");
				oRm.addClass("cusMyApptLiStatus");
				oRm.addClass("sapMSLIDescription");
				oRm.writeClasses();
				oRm.write(">");
				if (oControl.getContent()[0]) {
					oRm.renderControl(oControl.getContent()[0]);
				}
				oRm.write("</div>");

				// private Icon
				oRm.write("<div ");
				oRm.addClass("cusMyApptLiEllipsis");
				oRm.addClass("sapMSLIDescription");
				oRm.writeClasses();
				oRm.write(">");
				if (oControl.getPrivat()) {
					oRm.writeEscaped(cus.crm.myaccounts.util.Util.geti18NText("PRIVATE"));
				}
				oRm.write("</div>");

				oRm.write("</div>");
			}

			oRm.write("</div>");
			oRm.write("</div>");
		}
	}

});

cus.crm.myaccounts.util.ApptListItem.M_EVENTS = {'press':'press'};

/**
 * Function is called when Link is triggered.
 *
 * @param {jQuery.Event} oEvent
 * @private
 */
cus.crm.myaccounts.util.ApptListItem.prototype._handlePress = function(oEvent) {
	if(oEvent.target.className === "sapMLnk"){
		if (!this.firePress()) { // fire event and check return value whether default action should be prevented
			oEvent.preventDefault();
		}	
	}
	else {
		oEvent.preventDefault(); // even prevent URLs from being triggered
	}
};

if (jQuery.support.touch) {
	cus.crm.myaccounts.util.ApptListItem.prototype.ontap = cus.crm.myaccounts.util.ApptListItem.prototype._handlePress;
} else {
	cus.crm.myaccounts.util.ApptListItem.prototype.onclick = cus.crm.myaccounts.util.ApptListItem.prototype._handlePress;
}


cus.crm.myaccounts.util.ApptListItem.prototype.ontouchstart = function(oEvent) {
	// for controls which need to know whether they should handle events bubbling from here
	oEvent.originalEvent._sapui_handledByControl = true;
};
},
	"cus/crm/myaccounts/util/Constants.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
cus.crm.myaccounts.util.Constants = {
		
		accountCategoryPerson: "1",
		accountCategoryCompany: "2",
		accountCategoryGroup: "3",

		filterMyAccounts: "MY_ACCOUNT",
		filterMyIndividualAccounts: "MY_INDIVIDUAL_ACCOUNTS",
		filterMyCorporateAccounts: "MY_CORPORATE_ACCOUNTS",
		filterMyAccountGroups: "MY_ACCOUNT_GROUPS",
		filterAllAccounts: "ALL_ACCOUNTS",
		filterAllIndividualAccounts: "ALL_INDIVIDUAL_ACCOUNTS",
		filterAllCorporateAccounts: "ALL_CORPORATE_ACCOUNTS",
		filterAllAccountGroups: "ALL_ACCOUNT_GROUPS",

		dataTypeDATE: "DATE",
		dataTypeCHAR: "CHAR",
		dataTypeCURR: "CURR",
		dataTypeNUM:  "NUM",
		dataTypeTIME: "TIME",
		dataTypeCHEC: "CHEC",
		
		modeEdit: "EDIT",
		modeDisplay: "DISPLAY",
		
		fieldDate: "FIELD_DATE",
		fieldTime: "FIELD_TIME",
		fieldInput: "FIELD_INPUT",
		fieldSelect: "FIELD_SELECT",
		fieldCurrency: "FIELD_CURR"
		
};
},
	"cus/crm/myaccounts/util/Util.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("cus.crm.myaccounts.util.Util");
jQuery.sap.require("sap.ca.ui.quickoverview.Quickoverview");

cus.crm.myaccounts.util.Util = {
		
	setComponentConfiguration : function(oComponentConfiguration) {
		this.oComponentConfiguration = oComponentConfiguration;
	},
		
	setApplicationConfiguration : function(oApplicationConfiguration) {
		this.oApplicationConfiguration= oApplicationConfiguration;
	},
	
	getExternalServiceConfiguration: function(){
		if(this.oComponentConfiguration["cus.crm.myaccounts.externalServiceList"])
			return this.oApplicationConfiguration.oServiceParams.externalServiceList.concat(this.oComponentConfiguration["cus.crm.myaccounts.externalServiceList"]);
		else
			return this.oApplicationConfiguration.oServiceParams.externalServiceList;
	},

	setApplicationFacade : function(oApplicationFacade) {
		this.oApplicationFacade = oApplicationFacade;
	},

	geti18NResourceBundle : function() {
		if (this.oApplicationFacade) {
			return this.oApplicationFacade.getResourceBundle();
		} else {
			return null ;
		}
	},

	geti18NText : function(key) {
		if (this.geti18NResourceBundle()) {
			return this.geti18NResourceBundle().getText(key);
		} else {
			return null ;
		}
	},

	geti18NText1 : function(key, replace) {
		if (this.geti18NResourceBundle()) {
			return this.geti18NResourceBundle().getText(key, replace);
		} else {
			return null ;
		}
	},
	
	openQuickoverview : function(
			popoverTitle, title, subtitle, imageURL,
			oContextPerson, pathToPerson, pathToPersonDependentObject,
			oContextCompany, pathToCompany,
			triggeringObject, navigationCallBack){
		
		// Set path and model for retrieving data of person 
		var contextPathPerson = oContextPerson.getPath();
		var oModelPerson = oContextPerson.getModel();
		
		// Set path and model for retrieving data of company
		var contextPathCompany = oContextCompany.getPath();
		var oModelCompany = oContextCompany.getModel();
		
		// Collect all data for business card in one model
		var oModelData = {};
		oModelData.Company = {};
		oModelData.Company.Address = oModelCompany.getProperty(contextPathCompany+"/"+pathToCompany);
		oModelData.Company.name = cus.crm.myaccounts.util.formatter.AccountNameFormatter( oModelCompany.getProperty(contextPathCompany).fullName, oModelCompany.getProperty(contextPathCompany).name1);
		oModelData.Person = oModelPerson.getProperty(contextPathPerson+ "/"+pathToPerson);
		var personDependentObject = "";
		if(oModelData.Person && pathToPersonDependentObject) {
			personDependentObject = oModelPerson.getProperty(contextPathPerson+ "/"+pathToPerson+"/"+pathToPersonDependentObject);
			oModelData.Person.Address = personDependentObject;
		}
		
		// Set the model used for the business card
		var oBusinessCardModel = new sap.ui.model.json.JSONModel();
		oBusinessCardModel.setData(oModelData);
		
		// Determine the icon of the header in the business card
		var isNoHeaderIcon, headerImgURL;
		if(imageURL){
			isNoHeaderIcon = false;
			headerImgURL = imageURL;
		}
		else{
			isNoHeaderIcon = true;
			headerImgURL = "";
		}
		
		// Use the quickoverview control for displaying the business card
		var oBusinessCardDefinition = {
				popoverHeight:"32rem",
				title:popoverTitle,
				headerNoIcon:isNoHeaderIcon,
				headerImgURL:headerImgURL,
				headerTitle:title,
				headerSubTitle:subtitle,
				subViewName:"cus.crm.myaccounts.view.overview.Quickoverview",
				oModel:oBusinessCardModel,
				beforeExtNav:navigationCallBack
			};
		var oBusinessCard = new sap.ca.ui.quickoverview.Quickoverview(oBusinessCardDefinition);
		oBusinessCard.openBy(triggeringObject);
		
		// Check whether any data of the person is missing and has to be read from odata model
		if(!oModelData.Person || !personDependentObject){
			oModelPerson.read(pathToPerson, oContextPerson, ["$expand="+pathToPersonDependentObject], true,
				function(oData){	
					var oPerson = jQuery.parseJSON(JSON.stringify(oData));
					oModelData.Person = oPerson;
					oModelData.Person.Address = oPerson[pathToPersonDependentObject];
					var form = sap.ui.getCore().byId("cus.crm.myaccounts.view.overview.Quickoverview").byId("quickOverviewForm1");
					var item;
					for(var i in form.getContent()){
						item = sap.ui.getCore().byId(form.getContent()[i].getId());
						var textBinding = item.getBindingInfo("text");
						if (textBinding)
							textBinding.binding.refresh();
					}
				},
				function(oError){
					jQuery.sap.log.error("Read failed in Util.js:"+oError.response.body);
				}
			);
		}
		// Check whether any data of the company is missing and has to be read from odata model
		if(!oModelData.Company.Address){
			this.readODataObject(oContextCompany, pathToCompany, function(){});
		}		
	},
	
	readODataObjects: function(oContext, relationshipName, aFilters, callbackFunction){
		
		if (oContext.getModel().getProperty(oContext.sPath+"/"+relationshipName)){
			callbackFunction(oContext.getModel().getProperty(oContext.sPath+"/"+relationshipName));
			return;
		}
		
		var oItemTemplate = new sap.m.StandardListItem({text:""});
    	var oList = new sap.m.List({
    	    items: {
    			path: relationshipName, 
    			template: oItemTemplate,
    			filters: aFilters
    		}
    	});
    	
    	oList.setModel(oContext.getModel());
    	oList.setBindingContext(oContext);
    	
    	var oBinding = oList.getBinding("items");
    	var fnReceivedHandler = null;
    	fnReceivedHandler = jQuery.proxy(function (response) {

//    		if (response.getSource().aKeys.length > 0)
//    			oContextObject[relationshipName] = {__list: response.getSource().aKeys};
//    		else
//    			oContextObject[relationshipName] = null;
    
    		oBinding.detachDataReceived(fnReceivedHandler);
    		oList.destroy();
    		
    		callbackFunction(response.getSource().aKeys);
    		
    	}, this);
    	
    	oBinding.attachDataReceived(fnReceivedHandler);
	},
	
	readODataObject: function(oContext, relationshipName, callbackFunction){
		
		var oContextObject = oContext.getModel().getProperty(oContext.sPath);
		
		if (oContext.getModel().getProperty(oContext.sPath+"/"+relationshipName)){
			callbackFunction(oContext.getModel().getProperty(oContext.sPath+"/"+relationshipName));
			return;
		}
		
    	var oLabel = new sap.m.List();
    	oLabel.bindElement(oContext.sPath + "/" + relationshipName);
    	
    	oLabel.setModel(oContext.getModel());
    	oLabel.setBindingContext(oContext);
    	
    	var oBinding = oLabel.getElementBinding();
    	var fnReceivedHandler = null;
    	fnReceivedHandler = jQuery.proxy(function (response) {

    		if (response.getSource().getBoundContext())
    			oContextObject[relationshipName] = {__ref: response.getSource().getBoundContext().sPath.substr(1)};
    		else
    			oContextObject[relationshipName] = null;
    
    		oBinding.detachDataReceived(fnReceivedHandler);
    		oLabel.destroy();
    		
    		callbackFunction(oContext.getModel().getProperty(oContext.sPath+"/"+relationshipName));
    		
    	}, this);
    	
    	oBinding.attachDataReceived(fnReceivedHandler);
	},
	
	readExpandedODataObjects: function(oContext, expand, callbackFunction){
		
    	var oLabel = new sap.m.List();
    	oLabel.bindElement(oContext.sPath, {expand:expand});
    	oLabel.setModel(oContext.getModel());
    	oLabel.setBindingContext(oContext);
    	
    	var oBinding = oLabel.getElementBinding();
    	var fnReceivedHandler = null;
    	fnReceivedHandler = jQuery.proxy(function () {
    		oBinding.detachDataReceived(fnReceivedHandler);
    		oLabel.destroy();
    		if(callbackFunction)
    			callbackFunction(oContext.getModel().getProperty(oContext.sPath));
    	}, this);
    	
    	oBinding.attachDataReceived(fnReceivedHandler);
	},
	
	sendBatchReadRequests: function(oModel, aRequestURLs, callbackSuccess, callbackError){
		var aBatchOperation = [];
		for(var i in aRequestURLs){
			var oReadOp = oModel.createBatchOperation(aRequestURLs[i], "GET");
			aBatchOperation.push(oReadOp);
		}
		cus.crm.myaccounts.util.Util.sendBatchReadOperations(oModel, aBatchOperation, callbackSuccess, callbackError);
	},

	sendBatchReadOperations: function(oModel, aBatchOperation, callbackSuccess, callbackError){
		oModel.clearBatch();
		oModel.addBatchReadOperations(aBatchOperation);
				
		oModel.submitBatch(
				function(data){
					var oError = null;
					var aBatchResponse = data.__batchResponses;
					var responseObjects = {};
					for (var i = 0; i < aBatchResponse.length; i++) {
						
						if(aBatchResponse[i].statusCode === "200"){
							var key = aBatchOperation[i].requestUri;
							if(aBatchResponse[i].data.results){	//if the result is a collection
								responseObjects[key] = aBatchResponse[i].data.results; //put the results (collection) in the response object
							}
							else if (aBatchResponse[i].data.__metadata){ //if the result is an entity
								if(!responseObjects[key]){
									//1: if there is no entity for the given key, put the result (entity) to the response object
									responseObjects[key] = aBatchResponse[i].data;
								}
								else if (responseObjects[key] instanceof Array){
									//3: if there is an array for the given key, put the result (entity) to the array of the response object
									responseObjects[key].push(aBatchResponse[i].data);
								}
								else{
									//2: if there is already an entity for the given key (can happen if 2 requests were triggered with the same EntityCollection, example refresh several MarketingAttributes)
									// replace the object with an array and put both objects to this array
									var object = responseObjects[key];
									responseObjects[key] = [object];
									responseObjects[key].push(aBatchResponse[i].data);
								}
							}
							else	//required for Quotation ApplicationCustomizing
								responseObjects[key] = aBatchResponse[i].data[Object.keys(aBatchResponse[i].data)[0]];
						}
						else{
							var oResponse = jQuery.parseJSON(aBatchResponse[i].response.body);
							oError = {
								type : sap.ca.ui.message.Type.ERROR,
								code : oResponse.error.code,
								message : oResponse.error.message.value,
								details : oResponse.error.innererror.Error_Resolution.SAP_Note
							};
						}
					}
					if (oError) {
						if(callbackError)
							callbackError(oError);
						else
							sap.ca.ui.message.showMessageBox(oError);
					}
					else {
						callbackSuccess(responseObjects);
					}
				},
				function(oError){
					if (callbackError) {
						oError.response.body  = jQuery.parseJSON(oError.response.body);
						oError = {
							type : sap.ca.ui.message.Type.ERROR,
							code : oError.response.body.error.code,
							message : oError.response.body.error.message.value,
							details : oError.response.body.error.innererror.Error_Resolution.SAP_Note
						};
						callbackError(oError);
					}
					else {
						jQuery.sap.log.error("Read failed in Util.js->sendBatchReadOperations");	
					}
				}, true);
	},

	sendBatchChangeOperations: function(oModel, aBatchOperation, callbackSuccess, callbackError){
		oModel.clearBatch();
		oModel.addBatchChangeOperations(aBatchOperation);
		var that = this;
		oModel.submitBatch(
			jQuery.proxy(function (data) {
				var oError = {};
				var aBatchResponse = data.__batchResponses;
				var responseObject = [];
				for (var i = 0; i < aBatchResponse.length; i++) {
					if (aBatchResponse[i].response) {
						oError = jQuery.parseJSON(aBatchResponse[i].response.body).error;
						oError.statusCode = aBatchResponse[i].response.statusCode;
						oError.statusText = aBatchResponse[i].response.statusText;
					}
					if (aBatchResponse[i].__changeResponses &&
						aBatchResponse[i].__changeResponses.length > 0 &&
						aBatchResponse[i].__changeResponses[0].statusCode === "201"){
						responseObject.push(aBatchResponse[i].__changeResponses[0].data);
					}
				}
				if (!oError.message) {
					if (callbackSuccess)
						callbackSuccess.call(that, responseObject);
				}
				else {
					if (callbackError)
						callbackError.call(that, oError);
					else
						sap.m.MessageBox.alert(oError.message.value);
				}

			}, this),
			true);
	},

	getRefreshUIObject: function(oModel, contextPath, expand){
		
		if(!this.refreshList)
			this.refreshList = new sap.m.List();
		else{
			this.refreshList.unbindElement();
			this.refreshList.setModel(null);
		} 
		
		var oList = this.refreshList;
		
		if(expand)
			oList.bindElement(contextPath, {expand: expand});
		else
			oList.bindElement(contextPath);
		
		oList.setModel(oModel);
		var oBinding = oList.getElementBinding();
		
		var fnCleanUp = null;
		fnCleanUp = jQuery.proxy(function () {
			if(oBinding)
				oBinding.detachDataRequested(fnCleanUp);
			oBinding = null;
		}, this);
		oBinding.attachDataRequested(fnCleanUp);
		
		var oRefreshObject = {
			refresh: function(fnDataReceived){
				if(fnDataReceived)
					oBinding.attachDataReceived(fnDataReceived);
				if(oBinding)
					oBinding.refresh();
			},
			destroy: function(){
				fnCleanUp();
			}
		};
		
		return oRefreshObject;
	},
	
	getServiceSchemaVersion: function(oModel, entityType){
		var version = 0;
		var oEntityModel = oModel.oMetadata._getEntityTypeByPath(entityType);
		for(var i in oEntityModel.extensions){
			if(oEntityModel.extensions[i].name === "service-schema-version")
				version = oEntityModel.extensions[i].value;
		}
		return version;
	}

};
},
	"cus/crm/myaccounts/util/formatter.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
/*global URI: false */
jQuery.sap.declare("cus.crm.myaccounts.util.formatter");
jQuery.sap.require("cus.crm.myaccounts.util.Util");
jQuery.sap.require("sap.ca.ui.model.format.DateFormat");
jQuery.sap.require("sap.ca.ui.model.format.NumberFormat");
jQuery.sap.require("sap.ca.ui.model.format.AmountFormat");

cus.crm.myaccounts.util.formatter = {};

cus.crm.myaccounts.util.formatter.formatMediumTimeInterval = function(fromDate, toDate){
	if(fromDate && toDate){
		if(fromDate.getYear() === toDate.getYear() && fromDate.getMonth() === toDate.getMonth() && fromDate.getDay() === toDate.getDay())
			return sap.ca.ui.model.format.DateFormat.getDateInstance({style: "medium"}).format(fromDate);
		else{
			return sap.ca.ui.model.format.DateFormat.getDateInstance({style: "medium"}).format(fromDate)
			+
			" - "
			+
			sap.ca.ui.model.format.DateFormat.getDateInstance({style: "medium"}).format(toDate);
		}
	}
	else {
		return "";
	}
};

cus.crm.myaccounts.util.formatter.formatMediumDateTime = function(oValue){
	if(oValue) {
		return sap.ca.ui.model.format.DateFormat.getDateTimeInstance({style: "medium"}).format(oValue);
	} else {
		return "";
	}
};

cus.crm.myaccounts.util.formatter.formatMediumDate = function(oValue){
	if(oValue){
		return sap.ca.ui.model.format.DateFormat.getDateInstance({style: "medium"}).format(oValue);
	}
	else {
		return "";
	}
};

cus.crm.myaccounts.util.formatter.formatLongDate = function(oValue){
	if(oValue){
		return sap.ca.ui.model.format.DateFormat.getDateInstance({style: "long"}).format(oValue);
	}
	else {
		return "";
	}
};

cus.crm.myaccounts.util.formatter.formatShortDate = function(oValue){
	if(oValue){
		return sap.ca.ui.model.format.DateFormat.getDateInstance({style: "short"}).format(oValue);
	}
	else {
		return "";
	}
};

cus.crm.myaccounts.util.formatter.patternShortDate = function(){
	return sap.ca.ui.model.format.DateFormat.getDateInstance({style: "short"}).innerFormat.oFormatOptions.pattern;
};

cus.crm.myaccounts.util.formatter.formatAmounts = function(sValue, sCurrency){
	if(sValue > 0 ){
        return sap.ca.ui.model.format.AmountFormat.FormatAmountStandardWithCurrency(sValue , sCurrency );
	}
	return "";
};

cus.crm.myaccounts.util.formatter.formatShortAmounts = function(sValue, sCurrency){
	if(sValue && sValue >= 0){
        return sap.ca.ui.model.format.AmountFormat.FormatAmountShortWithCurrency(sValue , sCurrency);
	}
	return "";
};


cus.crm.myaccounts.util.formatter.formatMktAttrAmountInterval = function( amount, decimalPlaces, currency){
	if ( amount && decimalPlaces && currency ){
		var aValues = amount.split(" - ");
		for(var j = 0; j < aValues.length; j++) {
			aValues[j] = cus.crm.myaccounts.util.formatter.formatMktAttrAmount(aValues[j], decimalPlaces, currency);	
		}
		return aValues.join(" - ");
	}
	return amount; //Display not converted value in case of errors
};

cus.crm.myaccounts.util.formatter.formatMktAttrAmount = function( amount, decimalPlaces, currency){
	if ( amount && decimalPlaces && currency ) {
		// format of sValueID depends on the backend personalization:
		//   it can be 123,456,789.00
		//   or        123.456.789,00
		// -> remove all thousand separators
		var sValue = amount;
		var fValue = null;
		var iDecimalPlaces = parseInt(decimalPlaces);

		if (iDecimalPlaces === 0){
			// number without decimals
			sValue = sValue.replace(/[.,]/g, ''); //remove all dots and comas
			fValue = parseFloat(sValue);
		}
		else if (amount.charAt(amount.length-iDecimalPlaces-1) === "." || amount.charAt(amount.length-iDecimalPlaces-1) === ",") {
			// there is a decimal pointer ',' or '.' on the right position
			sValue = sValue.replace(/[.,]/g, ''); //remove all dots and comas
			// set decimal pointer again
			sValue = sValue.substring(0, sValue.length-iDecimalPlaces) + "." + sValue.substring(sValue.length-iDecimalPlaces,sValue.length);	
			fValue = parseFloat(sValue);
		}
		if (fValue) {
			return sap.ca.ui.model.format.AmountFormat.FormatAmountStandardWithCurrency(fValue, currency, iDecimalPlaces );
		}
		return amount; //Display unconverted value in case of errors
	}
};

cus.crm.myaccounts.util.formatter.formatMktAttrTime = function(time){
	var aTimeParts = time.split(":");
	if(aTimeParts.length>1)
		return  aTimeParts[0]+":"+aTimeParts[1];
};

cus.crm.myaccounts.util.formatter.formatMktAttrDisplayField = function(valueID, value, attributeDatatype, decimalPlaces, currency){
	var aValues;
	switch (attributeDatatype) {
		case cus.crm.myaccounts.util.Constants.dataTypeDATE:
			aValues = valueID.split(" - ");
			for(var j = 0; j < aValues.length; j++)
				aValues[j] = cus.crm.myaccounts.util.formatter.convertStringToDate(aValues[j]);
			return aValues.join(" - ");

		case cus.crm.myaccounts.util.Constants.dataTypeTIME:
			var dateFormatter = sap.ui.core.format.DateFormat.getTimeInstance({style : "short"});
			aValues = valueID.split(" - ");
			var j;
			for(j = 0; j < aValues.length; j++) {
				aValues[j] = aValues[j].replace(":", "");
				var oDate = dateFormatter.parse(aValues[j]);
				if (oDate)
					aValues[j] = dateFormatter.format(oDate);
			}
			return aValues.join(" - ");

		case cus.crm.myaccounts.util.Constants.dataTypeCURR:
			return cus.crm.myaccounts.util.formatter.formatMktAttrAmountInterval(valueID, decimalPlaces, currency);
		default:
			return value;
	}
};

cus.crm.myaccounts.util.formatter.formatShortNumber = function(sValue, sCurrency){
	if(sValue >= 0 ){
        return sap.ca.ui.model.format.AmountFormat.FormatAmountShort(sValue , sCurrency );
	}
	return "";
};

cus.crm.myaccounts.util.formatter.formatProbability = function(sValue){
	if(sValue >= 0 ){
		return sap.ca.ui.model.format.AmountFormat.FormatAmountStandard(sValue, 3, 0) + " %";
	}
	return "";
};

cus.crm.myaccounts.util.formatter.formatEmployeeResponsible = function(sFunction){
       if(sFunction){return sFunction;}
       else{return  sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText("EMPLOYEE_RESPONSIBLE");}
};

cus.crm.myaccounts.util.formatter.formatMediumDateTime = function(oValue){
	if(oValue){
		return sap.ca.ui.model.format.DateFormat.getDateTimeInstance({style: "medium"}).format(oValue);
	}
	else {
		return "";
	}
};

cus.crm.myaccounts.util.formatter.formatStartDate = function(oValue){
	if(oValue){
		var date=sap.ca.ui.model.format.DateFormat.getDateInstance({style: "medium"}).format(oValue);
		return  sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText("STARTING",[date]);
	}
	else {
		return "";
	}
};

cus.crm.myaccounts.util.formatter.formatCloseDate = function(oValue){
	if(oValue){
		var date=sap.ca.ui.model.format.DateFormat.getDateInstance({style: "medium"}).format(oValue);
		return  sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText("CLOSING",[date]);
	}
	else {
		return "";
	}
};

cus.crm.myaccounts.util.formatter.formatDueDate = function(oValue){
	if(oValue){
		var date=sap.ca.ui.model.format.DateFormat.getDateInstance({style: "medium"}).format(oValue);
		return  sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText("DUE",[date]);
	}
	else {
		return "";
	}
};

cus.crm.myaccounts.util.formatter.mimeTypeFormatter = function(value) {

	switch (value)
	{
		case 'application/vnd.openxmlformats-officedocument.presentationml.presentation':
		case 'application/vnd.ms-powerpoint':			
			return 'pptx';
		case 'application/msword':
		case 'application/vnd.openxmlformats-officedocument.wordprocessingml.document':
			return 'doc';
		case 'application/vnd.ms-excel':
		case 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet':
			return 'xls';
		case 'image/jpeg':
		case 'image/png':
		case 'image/tiff':
		case 'image/gif':		
			return 'jpg';
		case 'application/pdf':	
			return 'pdf';
		case 'text/plain':	
			return 'txt';
		default:
			return 'unknown'; 	
	}
};

cus.crm.myaccounts.util.formatter.getRelativePathFromURL = function(absoluteURL){
	var url = document.createElement('a');
	url.href = absoluteURL;
	if(url.pathname.substring(0, 1) === "/")
		return url.pathname;
	else
		return "/" + url.pathname;
};

cus.crm.myaccounts.util.formatter.logoUrlFormatter= function (mediaUrl, category) {
	
	// Return Account Logo 
	if (mediaUrl) {
		// return relative URL
		return cus.crm.myaccounts.util.formatter.getRelativePathFromURL(mediaUrl);
	}	
	else {	
		// If not exists, return icons dependent on account category
	
		switch (category){ 
		case '1':	//individual accounts
		  	return "sap-icon://person-placeholder";
		case '2':	//corporate accounts
	      	return "sap-icon://factory";
		case '3':	//groups
	      	return "sap-icon://group";
		default:    //default behavior when category is initial
			return "sap-icon://factory";
		}
	}
};

cus.crm.myaccounts.util.formatter.uploadUrlFormatter = function(accountID) {
	if(accountID) {
		var oModel = this.getModel();
		var urlParams = oModel.sUrlParams;
		return oModel.sServiceUrl + "/AccountCollection('" + accountID + "')/Attachments" + (urlParams ? '?' + urlParams : '');
	}
	return "";
};

cus.crm.myaccounts.util.formatter.attachmentLinkFormatter = function(url, metadata) {
	// In case the attachment is a URL to a website, the property URL of
	// the attachment is filled. Return this URL.
	// Otherwise the attachment is a file
	if(url) {
		return url;
	}
	if(metadata) {
		return cus.crm.myaccounts.util.formatter.getRelativePathFromURL(metadata.media_src);
	}
};

cus.crm.myaccounts.util.formatter.logoVisibilityFormatter= function (mediaUrl) {
	return mediaUrl ? true : false;
};

cus.crm.myaccounts.util.formatter.standardIconVisibilityFormatter= function (accountId, mediaUrl) {
	return (accountId && !mediaUrl) ? true : false;
};

cus.crm.myaccounts.util.formatter.pictureUrlFormatter= function (mediaUrl) {
	return mediaUrl ? mediaUrl : "sap-icon://person-placeholder";
};

cus.crm.myaccounts.util.formatter.locationFormatter= function (oCity, oCountry) {
	if(!oCity){
		return oCountry;
	}
	else if(!oCountry){
		return oCity;
	}
	else{
		return  sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText("LOCATION",[oCity,oCountry]);
	}
};

cus.crm.myaccounts.util.formatter.leadDescriptionFormatter= function(description, id) {
	if(description) {
		if(id) {
			return description + "\n" + id;
		} else {
			return description;
		}
	} else {
		if(id) {
			return id;
		}
	}
	return "";
};

cus.crm.myaccounts.util.formatter.nameAddressFormatter= function(name, address) {
	if(name) {
		if(address) {
			return name + "\n" + address;
		} else {
			return name;
		}
	} else {
		if(address) {
			return address;
		}
	}
	return "";
};



//Formatters for Appointments
cus.crm.myaccounts.util.formatter.formatLocationContact = function(loc, contxt) {
	var sResult = "";
	sResult = loc;

	if (contxt) {
		if(sResult)
			sResult = sResult + " | " + contxt;
		else
			sResult = contxt;	
	}
	return sResult;
};

cus.crm.myaccounts.util.formatter.formatTime = function(datetime,bAllDay) {
	if(bAllDay) {
		// return string "All Day"
		return cus.crm.myaccounts.util.Util.geti18NText("ALL_DAY_EVENT");
	}
	else if (datetime) {
		if (typeof datetime === "string") {
			// mock data json now "FromDate": "/Date(1356998400000)/",

			datetime = datetime.replace("/Date(", "").replace(")/", "");
			datetime = parseInt(datetime); // number ms
			datetime = new Date(datetime);

		}
		
		//
		var locale = new sap.ui.core.LocaleData(sap.ui.getCore().getConfiguration().getLocale());
	    var pattern = locale.getTimePattern("short");
		var formatter = sap.ui.core.format.DateFormat.getDateTimeInstance({pattern: pattern });
		var sTime = formatter.format(datetime);
		return sTime;
	}
};


cus.crm.myaccounts.util.formatter.formatDuration = function(from, to) {
	
	if (from !== null && to !== null ) {
		var diffmin;
		var diffms;
	
		if (typeof from === "string") {
			from = cus.crm.myaccounts.util.formatter.getDatefromString(from);
		}

		if (typeof to === "string") {
			to = cus.crm.myaccounts.util.formatter.getDatefromString(to);
		}

		diffms = to.getTime() - from.getTime();

		// in minutes ->
		diffmin = Math.round(diffms / 60000);

		if (diffmin < 60) {
			var number = diffmin.toString();
			var min = cus.crm.myaccounts.util.Util.geti18NText1("DURATION_MINUTE", number);
			return min;
		} else {
		// rule for >= 1 Hour and < 24 hours
			if (diffmin < 1440 ) { 

				var diffHalfHours = Math.round(diffmin / 30 );
				var diffHours = diffHalfHours / 2;
				var numberFormatter = sap.ui.core.format.NumberFormat.getFloatInstance();
				var diffHoursLocal = numberFormatter.format(diffHours);
				number = diffHoursLocal.toString();
				var hour = cus.crm.myaccounts.util.Util.geti18NText1("DURATION_HOUR", number);
			
				return hour;
			}
			else {
		// rule for > 1 day
				var days = Math.ceil(diffmin / 1440 );
				number = days.toString();
				var day;
				if (days === "1") {
					day = cus.crm.myaccounts.util.Util.geti18NText1("DURATION_DAY", number);
				}
				else {
					day = cus.crm.myaccounts.util.Util.geti18NText1("DURATION_DAYS", number);						
				}
				return day;
			
			}
		}
	}
};

cus.crm.myaccounts.util.formatter.getDatefromString = function(datetime) {
	// mock data json now "FromDate": "/Date(1356998400000)/",
	datetime = datetime.replace("/Date(", "").replace(")/", "");
	datetime = parseInt(datetime); // number ms
	datetime = new Date(datetime);

	return datetime;
};

cus.crm.myaccounts.util.formatter.formatStatusText = function(oStatus) {
	switch(oStatus){
		case 'E0001':    // Status Open -> black
			return sap.ui.core.ValueState.Neutral;
		case 'E0002':    // Status In Process -> black
			return sap.ui.core.ValueState.Neutral;
		case 'E0003':    // Status Completed -> green
			             // Status Won -> green
			return sap.ui.core.ValueState.Success;	
		case 'E0004':    // Status Lost -> red
			return sap.ui.core.ValueState.Error;
		case 'E0007':    // Status Rejected -> red
			return sap.ui.core.ValueState.Error;	
		default:					// for other not specified status
			return sap.ui.core.ValueState.None;
	}
};

cus.crm.myaccounts.util.formatter.formatSalesOrderStatusText = function(status) {
	switch(status) {
	case 'A': case 'B':
		return sap.ui.core.ValueState.Warning;
	case 'C':
		return sap.ui.core.ValueState.Success;
	default:
		return sap.ui.core.ValueState.None;
	}
};

cus.crm.myaccounts.util.formatter.websiteURL = function (value) {
	if(!value)
		return "";
	var oUri = URI(value);
	if (!oUri.protocol())
		oUri.protocol("http");
	if(jQuery.sap.validateUrl(oUri.toString()))
		return oUri.toString();
	else
		return "";
};

cus.crm.myaccounts.util.formatter.comaSeparator = function (value1, value2) {
	var string = value1;
	if (value2)
		return string ? string + ", " + value2 : value2;
	
	return string;
};

cus.crm.myaccounts.util.formatter.sleshSeparator = function (value1, value2) {
	var string = value1;
	if (value2)
		return string ? string + " / " + value2 : value2;

	return string;
};


cus.crm.myaccounts.util.formatter.AccountNameFormatter = function (fullName, name1) {
	if (fullName) { return fullName; }
	else { return name1; }
};

cus.crm.myaccounts.util.formatter.isEqual = function (value1, value2) {
	if(typeof(value1)==="string" && typeof(value2)==="string"){
		return value1.valueOf() === value2.valueOf();}
	else{
		return value1 === value2;
	}
		
};

cus.crm.myaccounts.util.formatter.areEqual = function (value1, value2, value3, value4) {
    return (cus.crm.myaccounts.util.formatter.isEqual(value1, value2) && cus.crm.myaccounts.util.formatter.isEqual(value3, value4));        
};

cus.crm.myaccounts.util.formatter.isUnequal = function (value1, value2) {
	if(typeof(value1)==="string" && typeof(value2)==="string"){
		return value1.valueOf() !== value2.valueOf();}
	else{
		return value1 !== value2;
	}
		
};

cus.crm.myaccounts.util.formatter.isNotInitial = function (value) {
	if (value)
		return true;
	else
		return false;
};

cus.crm.myaccounts.util.formatter.isInitial = function (value) {
	if (!value)
		return true;
	else
		return false;
};

cus.crm.myaccounts.util.formatter.AccountSpecificText = function (textPerson, textCompany, textGroup, accountType) {
	switch (accountType) {
	case cus.crm.myaccounts.util.Constants.accountCategoryPerson:
		return textPerson;
	case cus.crm.myaccounts.util.Constants.accountCategoryCompany:
		return textCompany;
	case cus.crm.myaccounts.util.Constants.accountCategoryGroup:
		return textGroup;
	}
};

cus.crm.myaccounts.util.formatter.formatExpiryState = function(validTo, status, threshold) {
    if (status === "C") { // if status is "completed", no color is shown
      return "None";
    }

    if (validTo) {
      var dNow = new Date();

      var date = new Date(validTo.getUTCFullYear(), validTo.getUTCMonth(), validTo.getUTCDate());
      dNow = new Date(dNow.getUTCFullYear(), dNow.getUTCMonth(), dNow.getUTCDate());
      
      var dayDiff = parseInt((date - dNow) / (24 * 3600 * 1000), 10);

      if (dayDiff <= threshold) {
        return "Error";
      }
      return "Success";
    }
    return "None";
  };
  
  cus.crm.myaccounts.util.formatter.convertDateStringToUTC = function( value ) {
	  
	  var newValue;
	  
	  if(value === ""){
			newValue = null;
		}
		else{
			var dateFormatter = sap.ui.core.format.DateFormat.getDateInstance({style : "medium"});
			var oDate = dateFormatter.parse( value );
			if(oDate){
				newValue = cus.crm.myaccounts.util.formatter.convertDateToUTC(oDate);
			}
			else{
				newValue = null;
			}
		}
	  return newValue;
  };
  
  cus.crm.myaccounts.util.formatter.convertDateToUTC = function( oDate ){
	  var utcDate = null;
	  if(oDate){
		  var oNewDate = new Date();
		  oNewDate.setUTCFullYear(oDate.getFullYear());
		  oNewDate.setUTCMonth(oDate.getMonth());
		  oNewDate.setUTCDate(oDate.getDate());
		  oNewDate.setUTCHours(0);
		  oNewDate.setUTCMinutes(0);
		  oNewDate.setUTCSeconds(0);
		  oNewDate.setUTCMilliseconds(0);
		  utcDate = oNewDate;
	  }
			
	  return utcDate;
  };

  cus.crm.myaccounts.util.formatter.convertStringToDate = function( value ) {
	  
	  var newValue;
	  
	  if(value === ""){
			newValue = null;
	  }
	  else{
			var dateFormatter = sap.ui.core.format.DateFormat.getDateInstance({style : "medium"});
			var oDate = dateFormatter.parse( value );
			if(oDate){
				newValue = dateFormatter.format(oDate);
			}
			else{
				newValue = value;
			}
	  }
	  return newValue;
  };
  
  cus.crm.myaccounts.util.formatter.convertStringToFloat = function(string) {
	  if(string) {
		  return parseFloat(string);
	  }
	  return 0;
  };
},
	"cus/crm/myaccounts/view/S2.controller.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("cus.crm.myaccounts.controller.Base360Controller");
jQuery.sap.require("sap.ca.ui.quickoverview.EmployeeLaunch");
jQuery.sap.require("cus.crm.myaccounts.util.formatter");
jQuery.sap.require("sap.ca.ui.model.format.AmountFormat");
jQuery.sap.require("cus.crm.myaccounts.util.Constants");
jQuery.sap.require("cus.crm.myaccounts.util.Util");

cus.crm.myaccounts.controller.Base360Controller.extend("cus.crm.myaccounts.view.S2", {

	onInit : function() {
    	if(cus.crm.myaccounts.view.overview && cus.crm.myaccounts.view.overview.OverviewPage.storage){
    		if (cus.crm.myaccounts.view.overview.OverviewPage.storage.onExit)
    			cus.crm.myaccounts.view.overview.OverviewPage.storage.onExit();
    		cus.crm.myaccounts.view.overview.OverviewPage.storage = null;
    	}
		// execute the onInit for the base class BaseDetailController
		cus.crm.myaccounts.controller.Base360Controller.prototype.onInit.call(this);
		this.resourceBundle = this.oApplicationFacade.getResourceBundle();
	
		var oModel = this.getView().getModel(); 
		oModel.forceNoCache(true);
		
		this.EHP2Backend = cus.crm.myaccounts.util.Util.getServiceSchemaVersion(oModel, "AccountCollection") < 1;
		
		var aMasterModelItems = [];
		if(this.EHP2Backend) {
			aMasterModelItems = [ {
				text : this.resourceBundle.getText("MY_ACCOUNT"),
				key : "MyAccount"
			    }, {
				text : this.resourceBundle.getText("ALL_ACCOUNTS"),
				key : "All"
				} ];
		}else{
			aMasterModelItems = [ {
				text : this.resourceBundle.getText("MY_ACCOUNT"),
				key : "MyAccount"
			    },  {
			    text : this.resourceBundle.getText("MY_INDIVIDUAL_ACCOUNTS"),
				key : "MyIndividual"
				}, {
				text : this.resourceBundle.getText("MY_CORPORATE_ACCOUNTS"),
				key : "MyCorporate"
				}, {
				text : this.resourceBundle.getText("MY_ACCOUNT_GROUPS"),
				key : "MyGroup"
				}, {
				text : this.resourceBundle.getText("ALL_ACCOUNTS"),
				key : "All"
				}, {
				text : this.resourceBundle.getText("ALL_INDIVIDUAL_ACCOUNTS"),
				key : "AllIndividual"
				}, {
				text : this.resourceBundle.getText("ALL_CORPORATE_ACCOUNTS"),
				key : "AllCorporate"
				}, {
				text : this.resourceBundle.getText("ALL_ACCOUNT_GROUPS"),
				key : "AllGroup"
			    } ];
		}
		
		// Settings
		var oMasterModel = new sap.ui.model.json.JSONModel({
		    isRefreshing : false,
		    searchValue : "",
		    selectedKey : "MyAccount",
		    threshold : this.getThreshold(),
		    items : aMasterModelItems
		});
	
		this.getView().setModel(oMasterModel, "config");
		this.oRouter.attachRouteMatched(this.handleNavTo, this);
	
    },
    
	onExit : function() {
		 if (this.oCreateAccountActionSheet){
			 this.oCreateAccountActionSheet.destroy();
			 this.oCreateAccountActionSheet = null;
		 }
	},
	
    destroy : function() {
	var oBinding = this.getTargetBinding();
	oBinding.detachChange(this._fnOnBindingChange);
    },
    handleNavTo : function(oEvent) {
		if (oEvent.getParameter("name") === "mainPage") {
        	var oArguments = oEvent.getParameter("arguments");
        	this.getView().getModel('config').setProperty("/selectedKey", oArguments.filterState);
        }
		
		if (oEvent.getParameter("name") === "S2" || oEvent.getParameter("name") === "mainPage") {
		    jQuery.sap.log.info("My accounts nav to " + oEvent.getParameter("name"));
		    // workaround to fix the pull to refresh that does not go
		    jQuery.sap.delayedCall(2000, this, function() {
			this.byId("myPullToRefresh").hide();
		    });
		    this._bindGrowingTileContainer();
			this.setHeaderFooterOptions(this._getHeaderFooterOptions());
		}
    },

    _bindGrowingTileContainer : function() {
    	if (!this.getView().byId("myOverviewTile"))
    		return;
		var oGrowingTile = this.getControl(), oBinding;
		if(!this.getTargetBinding()){
			oGrowingTile.setGrowingThreshold(this.getThreshold()).setGrowing(true);
			oGrowingTile.bindAggregation("content", {
			    path : '/AccountCollection',
			    filters : this._getFilters(),
			    parameters : {
				expand : 'MainContact,Classification,MainAddress,Logo,AccountFactsheet',
				// select all account attributes (*), and some special attribute of the other entities 
				select : '*,MainContact,Classification,MainAddress,Logo,AccountFactsheet/opportunityVolume,AccountFactsheet/revenueCurrentYear,AccountFactsheet/lastContact,AccountFactsheet/nextContact'	
			    },
			    template : this.getView().byId("myOverviewTile").clone()
			});
			this._fnOnBindingChange = jQuery.proxy(this.onBindingChange, this);
			oBinding = this.getTargetBinding();
			oBinding.attachChange(this._fnOnBindingChange);
		}
    },

    /**
     * @Override getControl
     */
    getControl : function() {
	return this._getTileContainer();
    },
    /**
     * @Override getTargetAggregation
     */
    getTargetAggregation : function() {
	return "content";
    },

    _getTileContainer : function() {
	return this.byId("tileContainer");
    },
    /**
     * check if filter on my account is set
     */
    _isMyAccount : function() {
    	var key = this.getView().getModel('config').getProperty("/selectedKey");
    	return ((key === "MyAccount") || (key === "MyIndividual") || (key === "MyCorporate") || (key === "MyGroup")) ? true : false;
        },

    /**
     * determines whether search (triggered by search field) is performed on
     * backend or frontend (frontend being default behavior).
     */
    isBackendSearch : function() {
	return true;
    },

    /**
     * @Override contains the server filter
     */
    applyBackendSearchPattern : function(sFilterPattern, oBinding) {
	var filters = this._getFilters(),
	// HACK: Remove initial filter (Status = New) which is by default
	// concatenated (or) to custom filters
	oBinding = this.getControl().getBinding(this.getTargetAggregation());

	oBinding.aApplicationFilters = [];
	// update master list binding
	oBinding.filter(filters);
    },
    onTileTap : function(oEvent) {
	// var title = oEvent.getSource().getTitle();
	this.oRouter.navTo("detail", {
	    contextPath : oEvent.getSource().getBindingContext().sPath.replace('/', "")
	});
    },
    openBusinessCard : function(oEvent) {
	var oEmpData = {};
	// get control that triggeres the BusinessCard
	if (oEvent) {
	    var oSource = oEvent.getSource();
	    if (oSource) {
		var oContext = oSource.getBindingContext();
		if (oContext) {
		    oEmpData = {
			name : oContext.getProperty("MainContact/fullName"),
			imgurl : this.photoUrlFormatter(oContext.getProperty("MainContact/Photo/__metadata/media_src")),
			department : oContext.getProperty("MainContact/department"),
			mobilephone : oContext.getProperty("MainContact/WorkAddress/mobilePhone"),
			officephone : oContext.getProperty("MainContact/WorkAddress/phone"),
			email : oContext.getProperty("MainContact/WorkAddress/email"),
			companyname : oContext.getProperty("MainContact/company"),
			companyaddress : oContext.getProperty("MainContact/WorkAddress/address")
		    };
		    // call 'Business Card' reuse component
		    var oEmployeeLaunch = new sap.ca.ui.quickoverview.EmployeeLaunch(oEmpData);
		    oEmployeeLaunch.openBy(oEvent.getParameters());
		}

	    }
	}
    },

   photoUrlFormatter : function(mediaUrl) {
	   if (mediaUrl) {
		   return cus.crm.myaccounts.util.formatter.getRelativePathFromURL(mediaUrl);
		}	
		else {	
			return "sap-icon://person-placeholder";
		}
    },

    _getHeaderFooterOptions : function() {
	// Update master Page title with total list items count
	// var nbItems = this.getList().getItems().length;
	// var oPage = this.getView().byId("page");
	var oController = this;
	var aButtonList = [];
	
	if(!this.EHP2Backend){
		aButtonList.push({
			sIcon:"sap-icon://add",
			onBtnPressed:function (oEvent) {
				oController._addAccount(oEvent);
			}});
	}

	// Set full-screen title with list-items count
	var fullscreenTitle = "";
	if(this._oControlStore && this._oControlStore.oTitle) {
		fullscreenTitle = this._oControlStore.oTitle.getText();
	}

	return {
		sFullscreenTitle: fullscreenTitle,
		aAdditionalSettingButtons: [],
		buttonList : aButtonList,
	    oFilterOptions : {
		aFilterItems : this.getView().getModel('config').getProperty("/items"),
		sSelectedItemKey : this.getView().getModel('config').getProperty("/selectedKey"),
		onFilterSelected : function(selectedKey) {
		    jQuery.sap.log.info(selectedKey + " has been selected");
		    oController.getView().getModel('config').setProperty("/selectedKey", selectedKey);
		    oController.handleFilter();
		}
	    },
	    oAddBookmarkSettings : {
		icon : "sap-icon://Fiori2/F0002"
	    }

	};
    },
    
    _addAccount: function(oEvent){
    	var that = this;
    	var aCategories =  this._getPossibleAccountCategories();
    	var aButtons = [];
    	for(var i in aCategories){
    		switch (aCategories[i]){
    			case cus.crm.myaccounts.util.Constants.accountCategoryCompany:
    				aButtons.push(new sap.m.Button({ text: this.resourceBundle.getText("CORPORATE_ACCOUNT"), press : function() {that._navigateToCreateScreen(cus.crm.myaccounts.util.Constants.accountCategoryCompany);} }));
    				break;
    			case cus.crm.myaccounts.util.Constants.accountCategoryPerson:
    				aButtons.push(new sap.m.Button({ text: this.resourceBundle.getText("INDIVIDUAL_ACCOUNT"), press : function() {that._navigateToCreateScreen(cus.crm.myaccounts.util.Constants.accountCategoryPerson);} }));
    				break;
    			case cus.crm.myaccounts.util.Constants.accountCategoryGroup:
    				aButtons.push(new sap.m.Button({ text: this.resourceBundle.getText("ACCOUNT_GROUP"), press : function() {that._navigateToCreateScreen(cus.crm.myaccounts.util.Constants.accountCategoryGroup);} }));
    				break;
    		}
    	}
    		
    	if(!this.oCreateAccountActionSheet){
    		this.oCreateAccountActionSheet = new sap.m.ActionSheet("AddAccountActionSheet", {
    			buttons: aButtons,
    			placement: sap.m.PlacementType.Top
    		});
    	}
    		
    	this.oCreateAccountActionSheet.openBy(oEvent.getSource());
    },
    
    _getPossibleAccountCategories: function(){
    	return [cus.crm.myaccounts.util.Constants.accountCategoryCompany, cus.crm.myaccounts.util.Constants.accountCategoryPerson, cus.crm.myaccounts.util.Constants.accountCategoryGroup];
    },
    
    _navigateToCreateScreen: function(accountCategory){
		var oParameter;
		oParameter = {
			accountCategory:accountCategory
		};
		this.oRouter.navTo("new", oParameter, false);
    },

    handleFilter : function() {
		var filters = this._getFilters(),
		// HACK: Remove initial filter (Status = New) which is by default
		// concatenated (or) to custom filters
		listBinding = this.getTargetBinding();
	
		listBinding.aApplicationFilters = [];
		// update master list binding
		listBinding.filter(filters);
		
		this._setFilterInURL();
    },
    
    _setFilterInURL:function () {
        var oParameter = {};
        oParameter.filterState = this.getView().getModel('config').getProperty("/selectedKey");
    	this.oRouter.navTo("mainPage", oParameter, true);
    },

    _getFilters : function() {
    	var filters = [], 
    		sValue = this.getView().getModel("config").getProperty("/searchValue"), 
    		isMyAccounts = this._isMyAccount(), 
    		selectedKey = this.getView().getModel("config").getProperty("/selectedKey");
    	
    	if (sValue && sValue.length > 0) {
    	    filters.push(new sap.ui.model.Filter("fullName", sap.ui.model.FilterOperator.Contains, sValue));
    	}
    	
    	filters.push(new sap.ui.model.Filter("isMyAccount", sap.ui.model.FilterOperator.EQ, isMyAccounts));

    	switch (selectedKey){
    	case "MyIndividual": case "AllIndividual":
    		filters.push(new sap.ui.model.Filter("category", sap.ui.model.FilterOperator.EQ, '1'));
    		break;
    	case "MyCorporate":  case "AllCorporate":
    		filters.push(new sap.ui.model.Filter("category", sap.ui.model.FilterOperator.EQ, '2'));
    		break;
    	case "MyGroup":   case "AllGroup":
    		filters.push(new sap.ui.model.Filter("category", sap.ui.model.FilterOperator.EQ, '3'));
    		break;
    	}
    	
    	return filters;

        },

    refreshList : function() {
	// workaround to fix the pull to refresh that does not go
	jQuery.sap.delayedCall(2000, this, function() {
	    this.byId("myPullToRefresh").hide();
	});
	var oControl = this.getControl(), isRefreshing = this.getView().getModel("config").getProperty("/isRefreshing"), oBinding = oControl.getBinding(this.getTargetAggregation()), fReceivedHandler = jQuery.proxy(function() {
	    this.getView().getModel("config").setProperty("/isRefreshing", false);
	    oBinding.detachDataReceived(fReceivedHandler);
	    sap.ca.ui.utils.busydialog.releaseBusyDialog();
	}, this), fRequestedHandler = jQuery.proxy(function() {
	    this.getView().getModel("config").setProperty("/isRefreshing", true);
	    sap.ca.ui.utils.busydialog.requireBusyDialog();
	    oBinding.detachDataRequested(fRequestedHandler);
	}, this), sValue;

	oBinding.attachDataRequested(fRequestedHandler);
	oBinding.attachDataReceived(fReceivedHandler);
	if (this.isBackendSearch() && !isRefreshing) {
	    sValue = this.getView().getModel("config").getProperty("/searchValue");
	    this.applyBackendSearchPattern(sValue, oBinding);
	}

    },

    onBindingChange : function() {
    	var title = undefined, 
    		selectedKey = this.getView().getModel("config").getProperty("/selectedKey");

    	switch (selectedKey){
    	case "MyAccount":
    		title = "MY_ACCOUNT_TITLE";
    		break;
    	case "MyIndividual":
    		title = "MY_INDIVIDUAL_ACCOUNT_TITLE";
    		break;
    	case "MyCorporate":
    		title = "MY_CORPORATE_ACCOUNT_TITLE";
    		break;
    	case "MyGroup":
    		title = "MY_ACCOUNT_GROUP_TITLE";
    		break;
    	case "All":
    		title = "ALL_ACCOUNTS_TITLE";
    		break;
    	case "AllIndividual":
    		title = "ALL_INDIVIDUAL_ACCOUNTS_TITLE";
    		break;
    	case "AllCorporate":
    		title = "ALL_CORPORATE_ACCOUNTS_TITLE";
    		break;
    	case "AllGroup":
    		title = "ALL_ACCOUNT_GROUPS_TITLE";
    		break;
    	}
    	
		var sI18NHeaderTitle = title, iCount = 0, oBinding = this.getTargetBinding();
	
		if (oBinding) {
		    iCount = oBinding.getLength();
		}
		if(iCount > 0)
			this._oControlStore.oTitle.setText(this.resourceBundle.getText(sI18NHeaderTitle, iCount));
		// Work around so that in the case there is a '0' count, the '0' is displayed properly in the title
		else
			this._oControlStore.oTitle.setText(this.resourceBundle.getText(sI18NHeaderTitle, "0"));
    },

    getThreshold : function() {
    if (sap.ui.Device.os.Android)
    	return 7;
	if (sap.ui.Device.system.phone) {
	    return 3;
	} else {
	    return 10;
	}
    }

});
},
	"cus/crm/myaccounts/view/S2.view.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core" xmlns="sap.m" xmlns:ca="sap.ca.ui"\n\txmlns:layout="sap.ui.layout" controllerName="cus.crm.myaccounts.view.S2"\n\tdisplayBlock="true" height="100%">\n\t<Page id="page">\n\t\t<subHeader>\n\t\t\t<Bar>\n\t\t\t\t<contentMiddle>\n\t\t\t\t\t<SearchField id="mySearchField" value="{config>/searchValue}"\n\t\t\t\t\t\tsearch="refreshList" showRefreshButton="{device>/isNoTouch}" placeholder="{i18n>SEARCH_ACCOUNTS}">\n\t\t\t\t\t</SearchField>\n\t\t\t\t</contentMiddle>\n\t\t\t</Bar>\n\t\t</subHeader>\n\t\t<content>\n\t\t\t<PullToRefresh id="myPullToRefresh" visible="{device>/isTouch}" refresh="refreshList"></PullToRefresh>\n\t\t\t<!-- Replace with required full screen control -->\n\n\t\t\t<ca:GrowingTileContainer id="tileContainer"\tvertical="true" horizontal="false" growingScrollToLoad="true">\n\n\t\t\t\t<!-- Extends the overview tile -->\n\t\t\t\t<core:ExtensionPoint name="extOverviewTile">\n\t\t\t\t\t<ca:OverviewTile id="myOverviewTile" contact="{path:\'MainContact/fullName\'}"\n\t\t\t\t\t\ticon="{parts:[{path:\'Logo/__metadata/media_src\'},{path: \'category\'}], formatter:\'cus.crm.myaccounts.util.formatter.logoUrlFormatter\'}"\n\t\t\t\t\t\taddress="{parts:[{path:\'MainAddress/city\'}, {path:\'MainAddress/country\'}],formatter:\'cus.crm.myaccounts.util.formatter.locationFormatter\'}"\n\t\t\t\t\t\ttitle= "{parts:[{path: \'fullName\'},{path: \'name1\'}],\n\t\t\t                formatter: \'cus.crm.myaccounts.util.formatter.AccountNameFormatter\'}" \t\t\t\t\t\t\n\t\t\t\t\t\trating="{Classification/ratingText}"\n\t\t\t\t\t\topportunities="{parts:[{path:\'AccountFactsheet/opportunityVolume/amount\'}, {path:\'AccountFactsheet/opportunityVolume/currency\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatShortAmounts\'}"\n\t\t\t\t\t\trevenue="{parts:[{path:\'AccountFactsheet/revenueCurrentYear/amount\'}, {path:\'AccountFactsheet/revenueCurrentYear/currency\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatShortAmounts\'}"\n\t\t\t\t\t\tlastContact="{parts:[{path:\'AccountFactsheet/lastContact/toDate\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatMediumDate\' }"\n\t\t\t\t\t\tnextContact="{parts:[{path:\'AccountFactsheet/nextContact/fromDate\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatMediumDate\' }"\n\t\t\t\t\t\tpress="onTileTap" contactPress="openBusinessCard">\n\t\t\t\t\t\t<ca:layoutData>\n\t\t\t\t\t\t\t<layout:GridData span="L4 M6 S12"></layout:GridData>\n\t\t\t\t\t\t</ca:layoutData>\n\t\t\t\t\t</ca:OverviewTile>\n\t\t\t\t</core:ExtensionPoint>\n\t\t\t\t\n\t\t\t</ca:GrowingTileContainer>\n\t\t</content>\n\t</Page>\n</core:View>\n',
	"cus/crm/myaccounts/view/S360.controller.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");
jQuery.sap.require("cus.crm.myaccounts.util.formatter");
jQuery.sap.require("cus.crm.myaccounts.util.Util");	

// Used for Cross Navigation to Leads, Opportunities, Tasks and Appointments
cus.crm.myaccounts.NavigationHelper = {};

sap.ca.scfld.md.controller.BaseFullscreenController.extend("cus.crm.myaccounts.view.S360", {

    onInit : function() {
	this.oRouter.attachRouteMatched(this.handleNavTo, this);
	
	this.backendSupportsEdit = cus.crm.myaccounts.util.Util.getServiceSchemaVersion(this
			.getView().getModel(), "AccountCollection") > 0;
    },
    
    onAfterRendering: function(){
        $('.sapCRMmyAccountsHeader .sapMFlexItem').attr("style","float:left");
    },

    handleNavTo : function(oEvent) {
	if (oEvent.getParameter("name") === "s360") {
	    var oController = this,
	    //
	    oView = this.getView(),
	    //
	    oModel = oView.getModel(),
	    //
	    sPath = '/' + oEvent.getParameter("arguments").contextPath,
	    //
	    context = new sap.ui.model.Context(oModel, '/' + oEvent.getParameter("arguments").contextPath),
	    //
	    fnBindViewContext = function() {
		oView.setBindingContext(context);
		var oOptions = oController._getHeaderFooterOptions();
		oController.setHeaderFooterOptions(oOptions);
	    };
	    oView.setBindingContext(undefined);
	    oModel.createBindingContext(sPath, "", {
		expand: this._getExpandForDataBinding() 
	    }, fnBindViewContext, true);
	}
    },
    
    _getExpandForDataBinding: function(){
		return 'AccountFactsheet,AccountFactsheet/Attachments,Logo,AccountFactsheet/Opportunities,AccountFactsheet/Notes,AccountFactsheet/Contacts,AccountFactsheet/Contacts/WorkAddress,AccountFactsheet/Leads,AccountFactsheet/Tasks,Classification,MainAddress,EmployeeResponsible,EmployeeResponsible/WorkAddress';
	},

    _getSelectedText : function() {
    	var oAccount = this.getView().getModel().getProperty(this.getView().getBindingContext().sPath);
    	var text=cus.crm.myaccounts.util.formatter.AccountNameFormatter(oAccount.fullName, oAccount.name1 )+"\n";
   	    var oMainAddress = this.getView().getModel().getProperty(this.getView().getBindingContext().sPath + "/MainAddress");
	    if (oMainAddress)
	      text += oMainAddress.address;

  	   return text;
    },
    
    _getShareDisplay : function() {
    	var oAccount = this.getView().getModel().getProperty(this.getView().getBindingContext().sPath);
    	var text=cus.crm.myaccounts.util.formatter.AccountNameFormatter(oAccount.fullName, oAccount.name1 );
	    var oMainAddress = this.getView().getModel().getProperty(this.getView().getBindingContext().sPath + "/MainAddress");
	    var text2 = "";
	    if (oMainAddress)
	      text2 = oMainAddress.address;

	    return new sap.m.StandardListItem({
	      title : text,
	      description : text2
	      });
    },
    
    _getDiscussID: function (){
		var url =  document.createElement('a');
		url.href = this.getView().getModel().sServiceUrl;
		return url.pathname + this.getView().getBindingContext().sPath;
		
//	return this.getView().getModel().getProperty(this.getView().getBindingContext().sPath).name1;
//
//	return new sap.m.StandardListItem({
//	    title : text,
//	    description : text2
//	});
    },
    _getDiscussType: function (){
		var url =  document.createElement('a');
		url.href = this.getView().getModel().sServiceUrl;
		return url.pathname + "/$metadata#AccountCollection";
	},
	
    _getDiscussName: function (){
    	var oAccount = this.getView().getModel().getProperty(this.getView().getBindingContext().sPath);
    	return cus.crm.myaccounts.util.formatter.AccountNameFormatter(oAccount.fullName, oAccount.name1 );
    },
    
    _getHeaderFooterOptions : function() {
	var that = this;
	var aButtonList = [];
	
	if(this.backendSupportsEdit){
		aButtonList.push({
			sI18nBtnTxt:"BUTTON_EDIT",
			onBtnPressed:function () {
				var oParameter;
				oParameter = {
					contextPath:that.getView().getBindingContext().sPath.substr(1)
				};
				that.oRouter.navTo("edit", oParameter, false);
			}});
	}
	
	return {
		buttonList : aButtonList,
	    sI18NFullscreenTitle : "DETAIL_TITLE",
	    onBack : function() {
		window.history.back();
	    },
	    oJamOptions : {
			oShareSettings : {
			    oDataServiceUrl : "/sap/opu/odata/sap/SM_INTEGRATION_SRV/",
			    object : {
				id : document.URL.replace(/&/g, "%26"),
				display : that._getShareDisplay(),
				share : that._getSelectedText()
			    }
			},
			oDiscussSettings : {
			    oDataServiceUrl : "/sap/opu/odata/sap/SM_INTEGRATION_SRV/",
			    feedType : "object",
			    object: {id: that._getDiscussID(),
						 type: that._getDiscussType(),
						 name: that._getDiscussName(),
						 ui_url:document.URL
				}
			}
	    },
	    oAddBookmarkSettings : {
		icon : "sap-icon://Fiori2/F0002"
	    }
	};
    },
    navToOpportunity : function() {
	var QtyForAccountID = this.getView().getModel().getProperty(this.getView().getBindingContext().sPath + "/AccountFactsheet/opportunitiesCount");
	this.navToOtherApplication("Opportunity", "manageOpportunity", this.getView().getModel().getProperty(this.getView().getBindingContext().sPath).accountID, QtyForAccountID, this.getView().getModel().getProperty(this.getView().getBindingContext().sPath).name1);
    },
    navToLead : function() {
	var QtyForAccountID = this.getView().getModel().getProperty(this.getView().getBindingContext().sPath + "/AccountFactsheet/leadsCount");
	this.navToOtherApplication("Lead", "manageLead", this.getView().getModel().getProperty(this.getView().getBindingContext().sPath).accountID, QtyForAccountID, this.getView().getModel().getProperty(this.getView().getBindingContext().sPath).name1);
    },
    navToAppointments : function() {
	// path:'AccountFactsheet/nextContact/fromDate'
	var accountID = this.getView().getModel().getProperty(this.getView().getBindingContext().sPath).accountID;
	var nextAppbinding = this.getView().getBindingContext().sPath + "/AccountFactsheet/nextContact/fromDate";
	var nextAppointmentDate = this.getView().getModel().getProperty(nextAppbinding);

	var QtyForAccountID = this.getView().getModel().getProperty(this.getView().getBindingContext().sPath + "/AccountFactsheet/futureActivitiesCount");

	// *XNav* (1) obtain cross app navigation interface
	var fgetService = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService;
	this.oCrossAppNavigator = fgetService && fgetService("CrossApplicationNavigation");
	if (null === nextAppointmentDate) {
	    // pass in format YYYYMMDD
	    nextAppointmentDate = new Date();
	}

	// pass in format YYYYMMDD
	var nextAppDate = this.getDateParameterfromDate(nextAppointmentDate);

	cus.crm.myaccounts.NavigationHelper.qty = QtyForAccountID;
	cus.crm.myaccounts.NavigationHelper.accountName = this.getView().getModel().getProperty(this.getView().getBindingContext().sPath).name1;

	// Stop listen for route matched events in this view we are leaving
	this.oRouter.detachRouteMatched(this.handleNavTo, this, this);

	// *XNav (2) generate cross application link
	if (this.oCrossAppNavigator)
		this.oCrossAppNavigator.toExternal({
		    target : {
			semanticObject : "Appointment",
			action : "myAppointments"
		    },
		    params : {
			"accountID" : [ accountID ],
			"Date" : [ nextAppDate ]
		    }
		});

    },
    getDateParameterfromDate : function(d) {
	// format: Date --> yyymmdd
	var sDay = d.getDate().toString();
	sDay = (sDay.length === 1) ? "0" + sDay : sDay;
	var sMonth = d.getMonth() + 1; // Months are zero based
	sMonth = sMonth.toString();
	sMonth = (sMonth.length === 1) ? "0" + sMonth : sMonth;
	var sYear = d.getFullYear();
	var sDate = "" + sYear + sMonth + sDay;
	return sDate;
    },
    navToTask : function() {
	var QtyForAccountID = this.getView().getModel().getProperty(this.getView().getBindingContext().sPath + "/AccountFactsheet/tasksCount");
	this.navToOtherApplication("Task", "manageTasks", this.getView().getModel().getProperty(this.getView().getBindingContext().sPath).accountID, QtyForAccountID, this.getView().getModel().getProperty(this.getView().getBindingContext().sPath).name1);
    },
    navToNote : function(oEvent) {
	this.oRouter.navTo("AccountNotes", {
	    contextPath : oEvent.getSource().getBindingContext().sPath.replace('/', "")
	// Remove initial /
	});

    },
    navToContact : function() {
	var QtyForAccountID = this.getView().getModel().getProperty(this.getView().getBindingContext().sPath + "/AccountFactsheet/contactsCount");
	this.navToOtherApplication("ContactPerson", "MyContacts", this.getView().getModel().getProperty(this.getView().getBindingContext().sPath).accountID, QtyForAccountID, this.getView().getModel().getProperty(this.getView().getBindingContext().sPath).name1);
    },
    navToOtherApplication : function(targetSemanticObject, targetAction, accountID, qtyForAccountID, accountName) {

	// *XNav* (1) obtain cross app navigation interface
	var fgetService = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService;
	this.oCrossAppNavigator = fgetService && fgetService("CrossApplicationNavigation");

	cus.crm.myaccounts.NavigationHelper.qty = qtyForAccountID;
	cus.crm.myaccounts.NavigationHelper.accountName = accountName;

	// Stop listen for route matched events in this view we are leaving
	this.oRouter.detachRouteMatched(this.handleNavTo, this, this);

	// *XNav (2) generate cross application link
	if(this.oCrossAppNavigator)
			this.oCrossAppNavigator.toExternal({
		    target : {
			semanticObject : targetSemanticObject,
			action : targetAction
		    },
		    params : {
			"accountID" : [ accountID ]
		    }
		});

    },
    navToAttachment : function(oEvent) {
	this.oRouter.navTo("AccountAttachments", {
	    contextPath : oEvent.getSource().getBindingContext().sPath.replace('/', "")
	// Remove initial /
	});
    }
});
},
	"cus/crm/myaccounts/view/S360.view.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core" xmlns:ui="sap.ca.ui" xmlns:suite="sap.suite.ui.commons" xmlns:layout="sap.ui.layout" xmlns:html="http://www.w3.org/1999/xhtml"\n\txmlns="sap.m" controllerName="cus.crm.myaccounts.view.S360">\n\n\n\t<Page id="page" title="{i18n>DETAIL_TITLE}" showNavButton="true">\n\t\t<content>\n\t\t\t<layout:Grid class ="sapSuiteUtiHeaderGrid sapSuiteUti sapCRMmyAccountsHeader" defaultSpan="L6 M6 S12" vSpacing="0" >\n\t\t\t\t<layout:content>\n\t\t\t\t\t<HBox>\n\t\t\t\t\t\t<Image src="{parts:[{path:\'Logo/__metadata/media_src\'},{path: \'category\'}], formatter:\'cus.crm.myaccounts.util.formatter.logoUrlFormatter\'}" \t\t\n\t\t\t\t\t\t\theight="5rem" \n\t\t\t\t\t\t\twidth="5rem"\n\t\t\t\t\t\t\tvisible="{path:\'Logo/__metadata/media_src\', formatter:\'cus.crm.myaccounts.util.formatter.logoVisibilityFormatter\'}" >\n\t\t\t\t\t\t</Image>\n\t\t\t\t\t\t<ObjectHeader title="{parts:[{path: \'fullName\'},{path: \'name1\'}], formatter: \'cus.crm.myaccounts.util.formatter.AccountNameFormatter\'}"\n\t\t\t\t\t\t\tclass="sapSuiteUtiHeader">\n\t\t\t\t\t\t\t<attributes>\n\t\t\t\t\t\t\t\t<ObjectAttribute text="{accountID}"></ObjectAttribute>\n\t\t\t\t\t\t\t</attributes>\n\t\t\t\t\t\t</ObjectHeader>\n\t\t\t\t\t</HBox>\n\t\t\t\t\t\n\t\t\t\t\t<core:ExtensionPoint name="extKpiBox">\n\t\t\t\t\t\t<HBox class="sapSuiteUtiKpiBox">\n\t\t\t\t\t\t\t<suite:KpiTile \n\t\t\t\t\t\t\t\tvalue="{parts:[{path:\'AccountFactsheet/revenueCurrentYear/amount\'},{path:\'AccountFactsheet/revenueCurrentYear/currency\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatShortNumber\'}"\n\t\t\t\t\t\t\t\tvalueUnit="{parts:[{path:\'AccountFactsheet/revenueCurrentYear/currency\'}]}"\n\t\t\t\t\t\t\t\tdescription="{i18n>REVENUE_CURRENT}"\n\t\t\t\t\t\t\t\tdoubleFontSize="true"\n\t\t\t\t\t\t\t\t>\n\t\t\t\t\t\t\t</suite:KpiTile>\n\t\t\t\t\t\t\t<suite:KpiTile \n\t\t\t\t\t\t\t\tvalue="{parts:[{path:\'AccountFactsheet/revenueLastYear/amount\'},{path:\'AccountFactsheet/revenueLastYear/currency\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatShortNumber\'}"\n\t\t\t\t\t\t\t\tvalueUnit="{parts:[{path:\'AccountFactsheet/revenueLastYear/currency\'}]}"\n\t\t\t\t\t\t\t\tdescription="{i18n>REVENUE_LAST}"\n\t\t\t\t\t\t\t\tdoubleFontSize="true"\n\t\t\t\t\t\t\t\t>\n\t\t\t\t\t\t\t</suite:KpiTile>\n\t\t\t\t\t\t\t<core:ExtensionPoint name="extKpiTile"/>\n\t\t\t\t\t\t</HBox>\n\t\t\t\t\t</core:ExtensionPoint>\n\t\t\t\t</layout:content>\n\t\t\t</layout:Grid>\n\t\t\t<layout:Grid defaultSpan="L6 M12 S12">\n\t\t\t\t<layout:content>\n\t\t\t\t\t<core:ExtensionPoint name="extGeneralInfo">\n\t\t\t\t\t\t<suite:FacetOverview\n\t\t\t\t\t\t\ttitle="{i18n>GENERAL_DATA}" width="100%" height="200px">\n\t\t\t\t\t\t\t<suite:content>\n\t\t\t\t\t\t\t\t<layout:Grid defaultSpan="L6 M6 S6" hSpacing="0">\n\t\t\t\t\t\t\t\t\t<layout:content>\n\t\t\t\t\t\t\t\t\t\t<VBox height="200px">\n\t\t\t\t\t\t\t\t\t\t\t<items>\n\t\t\t\t\t\t\t\t\t\t\t\t<Label text="{i18n>ADDRESS}"></Label>\n\t\t\t\t\t\t\t\t\t\t\t\t<Text text="{MainAddress/address}"></Text>\n\t\t\t\t\t\t\t\t\t\t\t\t<Text></Text>\n\t\t\t\t\t\t\t\t\t\t\t\t<Label text="{i18n>UNWEIGHTED_OPPORTUNITIES}"></Label>\n\t\t\t\t\t\t\t\t\t\t\t\t<Text text="{parts:[{path:\'AccountFactsheet/opportunityVolume/amount\'}, {path:\'AccountFactsheet/opportunityVolume/currency\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatShortAmounts\'}"></Text>\n\t\t\t\t\t\t\t\t\t\t\t\t<core:ExtensionPoint name="extGeneralInfoLeft"/>\n\t\t\t\t\t\t\t\t\t\t\t</items>\n\t\t\t\t\t\t\t\t\t\t</VBox>\n\t\t\t\t\t\t\t\t\t\t<VBox>\n\t\t\t\t\t\t\t\t\t\t\t<items>\n\t\t\t\t\t\t\t\t\t\t\t\t<Label text="{i18n>RATING}"></Label>\n\t\t\t\t\t\t\t\t\t\t\t\t<Text text="{Classification/ratingText}"></Text>\n\t\t\t\t\t\t\t\t\t\t\t\t<Text></Text>\n\t\t\t\t\t\t\t\t\t\t\t\t<Label text="{parts:[{path:\'EmployeeResponsible/WorkAddress/function\'}], formatter:\'cus.crm.myaccounts.util.formatter.formatEmployeeResponsible\'}"></Label>\n\t\t\t\t\t\t\t\t\t\t\t\t<Text text="{EmployeeResponsible/fullName}"></Text>\n\t\t\t\t\t\t\t\t\t\t\t\t<core:ExtensionPoint name="extGeneralInfoRight"/>\n\t\t\t\t\t\t\t\t\t\t\t</items>\n\t\t\t\t\t\t\t\t\t\t</VBox>\n\t\t\t\t\t\t\t\t\t</layout:content>\n\t\t\t\t\t\t\t\t</layout:Grid>\n\t\t\t\t\t\t\t</suite:content>\n\t\t\t\t\t\t</suite:FacetOverview>\n\t\t\t\t\t</core:ExtensionPoint>\n\t\t\t\t\t<core:ExtensionPoint name="extContacts">\n\t\t\t\t\t\t<suite:FacetOverview\n\t\t\t\t\t\t\ttitle="{i18n>CONTACTS}"\n\t\t\t\t\t\t\twidth="100%"\n\t\t\t\t\t\t\tpress="navToContact"\n\t\t\t\t\t\t\tquantity="{path:\'AccountFactsheet/contactsCount\'}"\n\t\t\t\t\t\t\theight="200px">\n\t\t\t\t\t\t\t<suite:content>\n\t\t\t\t\t\t\t\t<layout:Grid defaultSpan="L6 M6 S12"\n\t\t\t\t\t\t\t\t\t\t\thSpacing="0" \n\t\t\t\t\t\t\t\t\t\t\tcontent="{path:\'AccountFactsheet/Contacts\'}" >\n\t\t\t\t\t\t\t\t\t<layout:content>\n\t\t\t\t\t\t\t\t\t\t<VBox height="200px">\n\t\t\t\t\t\t\t\t\t\t\t<items>\n\t\t\t\t\t\t\t\t\t\t\t\t<Label text="{function}"></Label>\n\t\t\t\t\t\t\t\t\t\t\t\t<Text text="{fullName}"></Text>\n\t\t\t\t\t\t\t\t\t\t\t\t<Text text="{WorkAddress/mobilePhone}"></Text>\n\t\t\t\t\t\t\t\t\t\t\t\t<Text text="{WorkAddress/email}"></Text>\n\t\t\t\t\t\t\t\t\t\t\t\t<core:ExtensionPoint name="extContactsInfo"/>\n\t\t\t\t\t\t\t\t\t\t\t</items>\n\t\t\t\t\t\t\t\t\t\t</VBox>\n\t\t\t\t\t\t\t\t\t</layout:content>\n\t\t\t\t\t\t\t\t</layout:Grid>\n\t\t\t\t\t\t\t</suite:content>\n\t\t\t\t\t\t</suite:FacetOverview>\n\t\t\t\t\t</core:ExtensionPoint>\n\t\t\t\t\t<core:ExtensionPoint name="extOpportunities">\n\t\t\t\t\t\t<suite:FacetOverview\n\t\t\t\t\t\t\ttitle="{i18n>OPPORTUNITIES}"\n\t\t\t\t\t\t\tpress="navToOpportunity"\n\t\t\t\t\t\t\twidth="100%"\n\t\t\t\t\t\t\tquantity="{path:\'AccountFactsheet/opportunitiesCount\', parameters:{expand:\'AccountFactsheet\'}}"\n\t\t\t\t\t\t\theight="200px">\n\t\t\t\t\t\t\t<suite:content>\n\t\t\t\t\t\t\t\t<layout:Grid defaultSpan="L6 M6 S12"\n\t\t\t\t\t\t\t\t\t\t\thSpacing="0"\n\t\t\t\t\t\t\t\t\t\t\tcontent="{path:\'AccountFactsheet/Opportunities\'}" >\n\t\t\t\t\t\t\t\t\t<layout:content>\n\t\t\t\t\t\t\t\t\t\t<VBox height="200px">\n\t\t\t\t\t\t\t\t\t\t\t<items>\n\t\t\t\t\t\t\t\t\t\t\t\t<Label text="{parts:[{path:\'closingDate\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatCloseDate\' }"></Label>\n\t\t\t\t\t\t\t\t\t\t\t\t<Text text="{description}"></Text>\n\t\t\t\t\t\t\t\t\t\t\t\t<Text text="{parts:[{path : \'expRevenue\'},{path : \'currency\'}], formatter:\'cus.crm.myaccounts.util.formatter.formatAmounts\'}"></Text>\n\t\t\t\t\t\t\t\t\t\t\t\t<Text text="{currPhaseText}"></Text>\n\t\t\t\t\t\t\t\t\t\t\t\t<core:ExtensionPoint name="extOpportunityInfo"/>\n\t\t\t\t\t\t\t\t\t\t\t</items>\n\t\t\t\t\t\t\t\t\t\t</VBox>\n\t\t\t\t\t\t\t\t\t</layout:content>\n\t\t\t\t\t\t\t\t</layout:Grid>\n\t\t\t\t\t\t\t</suite:content>\n\t\t\t\t\t\t</suite:FacetOverview>\n\t\t\t\t\t</core:ExtensionPoint>\n\t\t\t\t\t<core:ExtensionPoint name="extAppointments">\n\t\t\t\t\t\t<suite:FacetOverview\n\t\t\t\t\t\t\ttitle="{i18n>APPOINTMENTS}"\n\t\t\t\t\t\t\tpress="navToAppointments"\n\t\t\t\t\t\t\twidth="100%"\n\t\t\t\t\t\t\tquantity="{path:\'AccountFactsheet/futureActivitiesCount\', parameters:{expand:\'AccountFactsheet\'}}"\n\t\t\t\t\t\t\theight="200px">\n\t\t\t\t\t\t\t<suite:content>\n\t\t\t\t\t\t\t\t<layout:Grid defaultSpan="L6 M6 S12" hSpacing="0">\n\t\t\t\t\t\t\t\t\t<layout:content>\n\t\t\t\t\t\t\t\t\t\t<VBox height="200px">\n\t\t\t\t\t\t\t\t\t\t\t<items>\n\t\t\t\t\t\t\t\t\t\t\t\t<Label text="{i18n>NEXT_APPOINTMENT}"></Label>\n\t\t\t\t\t\t\t\t\t\t\t\t<Text text="{parts:[{path:\'AccountFactsheet/nextContact/fromDate\'}, {path:\'AccountFactsheet/nextContact/toDate\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatMediumTimeInterval\' }"></Text>\n\t\t\t\t\t\t\t\t\t\t\t\t<Text text="{AccountFactsheet/nextContact/description}"></Text>\n\t\t\t\t\t\t\t\t\t\t\t\t<core:ExtensionPoint name="extAppointmentLeft"/>\n\t\t\t\t\t\t\t\t\t\t\t</items>\n\t\t\t\t\t\t\t\t\t\t</VBox>\n\t\t\t\t\t\t\t\t\t\t<VBox>\n\t\t\t\t\t\t\t\t\t\t\t<items>\n\t\t\t\t\t\t\t\t\t\t\t\t<Label text="{i18n>LAST_APPOINTMENT}"></Label>\n\t\t\t\t\t\t\t\t\t\t\t\t<Text text="{parts:[{path:\'AccountFactsheet/lastContact/fromDate\'}, {path:\'AccountFactsheet/lastContact/toDate\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatMediumTimeInterval\' }"></Text>\n\t\t\t\t\t\t\t\t\t\t\t\t<Text text="{AccountFactsheet/lastContact/description}"></Text>\n\t\t\t\t\t\t\t\t\t\t\t\t<core:ExtensionPoint name="extAppointmentRight"/>\n\t\t\t\t\t\t\t\t\t\t\t</items>\n\t\t\t\t\t\t\t\t\t\t</VBox>\n\t\t\t\t\t\t\t\t\t</layout:content>\n\t\t\t\t\t\t\t\t</layout:Grid>\n\t\t\t\t\t\t\t</suite:content>\n\t\t\t\t\t\t</suite:FacetOverview>\n\t\t\t\t\t</core:ExtensionPoint>\n\t\t\t\t\t<core:ExtensionPoint name="extLeads">\n\t\t\t\t\t\t<suite:FacetOverview\n\t\t\t\t\t\t\ttitle="{i18n>LEADS}"\n\t\t\t\t\t\t\tpress="navToLead"\n\t\t\t\t\t\t\twidth="100%"\n\t\t\t\t\t\t\tquantity="{path:\'AccountFactsheet/leadsCount\', parameters:{expand:\'AccountFactsheet\'}}"\n\t\t\t\t\t\t\theight="200px">\n\t\t\t\t\t\t\t<suite:content>\n\t\t\t\t\t\t\t\t<layout:Grid defaultSpan="L6 M6 S12"\n\t\t\t\t\t\t\t\t\t\t\thSpacing="0"\n\t\t\t\t\t\t\t\t\t\t\tcontent="{path:\'AccountFactsheet/Leads\'}" >\n\t\t\t\t\t\t\t\t\t<layout:content>\n\t\t\t\t\t\t\t\t\t\t<VBox height="200px">\n\t\t\t\t\t\t\t\t\t\t\t<items>\n\t\t\t\t\t\t\t\t\t\t\t\t<Label text="{parts:[{path:\'validFrom\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatStartDate\' }"></Label>\n\t\t\t\t\t\t\t\t\t\t\t\t<Text text="{description}"></Text>\n\t\t\t\t\t\t\t\t\t\t\t\t<Text text="{qualificationLevel}"></Text>\n\t\t\t\t\t\t\t\t\t\t\t\t<Text text="{statusText}"></Text>\n\t\t\t\t\t\t\t\t\t\t\t\t<Text text="{importanceText}"></Text>\n\t\t\t\t\t\t\t\t\t\t\t\t<core:ExtensionPoint name="extLeadInfo"/>\n\t\t\t\t\t\t\t\t\t\t\t</items>\n\t\t\t\t\t\t\t\t\t\t</VBox>\n\t\t\t\t\t\t\t\t\t</layout:content>\n\t\t\t\t\t\t\t\t</layout:Grid>\n\t\t\t\t\t\t\t</suite:content>\n\t\t\t\t\t\t</suite:FacetOverview>\n\t\t\t\t\t</core:ExtensionPoint>\n\t\t\t\t\t<core:ExtensionPoint name="extTasks">\n\t\t\t\t\t\t<suite:FacetOverview\n\t\t\t\t\t\t\ttitle="{i18n>TASKS}"\n\t\t\t\t\t\t\tpress="navToTask"\n\t\t\t\t\t\t\twidth="100%"\n\t\t\t\t\t\t\tquantity="{path:\'AccountFactsheet/tasksCount\', parameters:{expand:\'AccountFactsheet\'}}"\n\t\t\t\t\t\t\theight="200px">\n\t\t\t\t\t\t\t<suite:content>\n\t\t\t\t\t\t\t\t<layout:Grid defaultSpan="L6 M6 S12"\n\t\t\t\t\t\t\t\t\t\t\thSpacing="0"\n\t\t\t\t\t\t\t\t\t\t\tcontent="{path:\'AccountFactsheet/Tasks\'}" >\n\t\t\t\t\t\t\t\t\t<layout:content>\n\t\t\t\t\t\t\t\t\t\t<VBox height="200px">\n\t\t\t\t\t\t\t\t\t\t\t<items>\n\t\t\t\t\t\t\t\t\t\t\t\t<Label text="{parts:[{path:\'dueDate\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatDueDate\' }"></Label>\n\t\t\t\t\t\t\t\t\t\t\t\t<Text text="{description}"></Text>\n\t\t\t\t\t\t\t\t\t\t\t\t<core:ExtensionPoint name="extTaskInfo"/>\n\t\t\t\t\t\t\t\t\t\t\t</items>\n\t\t\t\t\t\t\t\t\t\t</VBox>\n\t\t\t\t\t\t\t\t\t</layout:content>\n\t\t\t\t\t\t\t\t</layout:Grid>\n\t\t\t\t\t\t\t</suite:content>\n\t\t\t\t\t\t</suite:FacetOverview>\n\t\t\t\t\t</core:ExtensionPoint>\n\t\t\t\t\t<core:ExtensionPoint name="extNotes">\n\t\t\t\t\t\t<suite:FacetOverview\n\t\t\t\t\t\t\ttitle="{i18n>NOTES}"\n\t\t\t\t\t\t\tpress="navToNote"\n\t\t\t\t\t\t\twidth="100%"\n\t\t\t\t\t\t\tquantity="{path:\'AccountFactsheet/notesCount\', parameters:{expand:\'AccountFactsheet\'}}"\n\t\t\t\t\t\t\theight="200px">\n\t\t\t\t\t\t\t<suite:content>\n\t\t\t\t\t\t\t\t<layout:Grid defaultSpan="L6 M6 S12"\n\t\t\t\t\t\t\t\t\t\t\thSpacing="0"\n\t\t\t\t\t\t\t\t\t\t\tcontent="{path:\'AccountFactsheet/Notes\'}" >\n\t\t\t\t\t\t\t\t\t<layout:content>\n\t\t\t\t\t\t\t\t\t\t<VBox height="200px">\n\t\t\t\t\t\t\t\t\t\t\t<items>\n\t\t\t\t\t\t\t\t\t\t\t\t<Label text="{parts:[{path:\'createdAt\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatMediumDate\' }"></Label>\n\t\t\t\t\t\t\t\t\t\t\t\t<Text text="{content}"></Text>\n\t\t\t\t\t\t\t\t\t\t\t\t<core:ExtensionPoint name="extNoteInfo"/>\n\t\t\t\t\t\t\t\t\t\t\t</items>\n\t\t\t\t\t\t\t\t\t\t</VBox>\n\t\t\t\t\t\t\t\t\t</layout:content>\n\t\t\t\t\t\t\t\t</layout:Grid>\n\t\t\t\t\t\t\t</suite:content>\n\t\t\t\t\t\t</suite:FacetOverview>\n\t\t\t\t\t</core:ExtensionPoint>\n\t\t\t\t\t<core:ExtensionPoint name="extAttachments">\n\t\t\t\t\t\t<suite:FacetOverview\n\t\t\t\t\t\t\ttitle="{i18n>ATTACHMENTS}"\n\t\t\t\t\t\t\tpress="navToAttachment"\n\t\t\t\t\t\t\twidth="100%"\n\t\t\t\t\t\t\tquantity="{path:\'AccountFactsheet/attachmentsCount\', parameters:{expand:\'AccountFactsheet\'}}"\n\t\t\t\t\t\t\theight="200px">\n\t\t\t\t\t\t\t<suite:content>\n\t\t\t\t\t\t\t\t<layout:Grid defaultSpan="L6 M6 S12"\n\t\t\t\t\t\t\t\t\t\t\thSpacing="0"\n\t\t\t\t\t\t\t\t\t\t\tcontent="{path:\'AccountFactsheet/Attachments\'}" >\n\t\t\t\t\t\t\t\t\t<layout:content>\n\t\t\t\t\t\t\t\t\t\t<VBox height="200px">\n\t\t\t\t\t\t\t\t\t\t\t<items>\n\t\t\t\t\t\t\t\t\t\t\t\t<Label text="{parts:[{path:\'createdAt\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatMediumDate\' }"></Label>\n\t\t\t\t\t\t\t\t\t\t\t\t<Text text="{name}"></Text>\n\t\t\t\t\t\t\t\t\t\t\t\t<core:ExtensionPoint name="extAttachmentInfo"/>\n\t\t\t\t\t\t\t\t\t\t\t</items>\n\t\t\t\t\t\t\t\t\t\t</VBox>\n\t\t\t\t\t\t\t\t\t</layout:content>\n\t\t\t\t\t\t\t\t</layout:Grid>\n\t\t\t\t\t\t\t</suite:content>\n\t\t\t\t\t\t</suite:FacetOverview>\n\t\t\t\t\t</core:ExtensionPoint>\n\t\t\t\t\t<core:ExtensionPoint name="extFacetOverview"/>\n\t\t\t\t</layout:content>\n\t\t\t</layout:Grid>\n\t\t</content>\n\t\t\t\t<footer>\n            <Bar id="detailFooter">\n                <contentRight>\n                    <Button icon="sap-icon://action" press="handleAction" />\n                </contentRight>\n            </Bar>\n        </footer>\n\t</Page>\n</core:View>\n',
	"cus/crm/myaccounts/view/S4Attachments.controller.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");
jQuery.sap.require("cus.crm.myaccounts.util.formatter");

sap.ca.scfld.md.controller.BaseFullscreenController.extend("cus.crm.myaccounts.view.S4Attachments", {

	onInit : function() {
		this.oRouter.attachRouteMatched(this.handleNavTo, this);

	},
	handleNavTo : function(oEvent){
		if (oEvent.getParameter("name") === "AccountAttachments") {	
			var oView = this.getView();
			var contextPath = oEvent.getParameter("arguments").contextPath;
//          Unused variable
//			var oPage = this.byId("page");
    		var oModel = this.getView().getModel();
    		var sPath = '/' + oEvent.getParameter("arguments").contextPath;
    		var context = new sap.ui.model.Context(oModel, '/' + oEvent.getParameter("arguments").contextPath);
    		var fnBindViewContext = function(){
    			oView.setBindingContext(context);
    		};
    		oModel.createBindingContext(sPath, "", {expand: 'Attachments'},fnBindViewContext,true);

			var that=this;

			if (oModel instanceof sap.ui.model.odata.ODataModel){
				oModel.read(contextPath+"/Attachments", null, null, true, function(oData){
					var attachments= JSON.parse(JSON.stringify(oData));
					var data = { Attachments : [] };
					$.each( attachments.results, function(index, value)
							{
						var o = {name : value.name,
								size : value.fileSize,
								url : cus.crm.myaccounts.util.formatter.getRelativePathFromURL(value.__metadata.media_src),
								uploadedDate :value.createdAt,
								contributor : value.createdBy,
								fileExtension : cus.crm.myaccounts.util.formatter.mimeTypeFormatter(value.mimeType),
								fileId : value.documentId
						};
						data.Attachments.push(o);
							}
					);
					that.byId('fileupload').setModel(new sap.ui.model.json.JSONModel(data));

				});
			}
		}

	},
	handleNavBack: function(){
		window.history.back();
	},

	_refresh : function(channelId, eventId, data) {

		var that = this;

		if (data && data.context) {

			this.getView().setBindingContext(data.context);

			var oModel = this.getView().getModel();			
			if (oModel instanceof sap.ui.model.odata.ODataModel){
				oModel.read(data.context.getPath()+"/Attachments", null, null, true, function(oData){   
					var attachments= JSON.parse(JSON.stringify(oData));
					var data = { Attachments : [] };
					$.each( attachments.results, function(index, value) 
							{
						var o = {name : value.name,
								size : value.fileSize,
								url : cus.crm.myaccounts.util.formatter.getRelativePathFromURL(value.__metadata.media_src),
								uploadedDate : cus.crm.mycontacts.formatter.ReleaseFormatter.dateFormatter(value.createdAt),
								contributor : value.createdBy,
								fileExtension : cus.crm.mycontacts.formatter.ReleaseFormatter.mimeTypeFormatter(value.mimeType),
								fileId : value.documentId
						};
						data.Attachments.push(o);								
							}
					);
					that.byId('fileupload').setModel(new sap.ui.model.json.JSONModel(data));
				});
			}
		}

	}

});
},
	"cus/crm/myaccounts/view/S4Attachments.view.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core" xmlns:ca="sap.ca.ui" xmlns:html="http://www.w3.org/1999/xhtml"\n\txmlns="sap.m" controllerName="cus.crm.myaccounts.view.S4Attachments">\n\n\n\t<Page id="page" title="{i18n>ATTACHMENTS}" showNavButton="true" navButtonPress="handleNavBack">\n\t\t<content>\n\t\t\t<ObjectHeader title="{i18n>ATTACHMENTS}">\n\t\t\t\t<attributes>\n\t\t\t\t\t<ObjectAttribute text="{parts:[{path: \'fullName\'},{path: \'name1\'}], formatter: \'cus.crm.myaccounts.util.formatter.AccountNameFormatter\'}"></ObjectAttribute>\n\t\t\t\t</attributes>\n\t\t\t</ObjectHeader>\n\t\t\t<html:div><html:hr ></html:hr></html:div>\n\t\t\t <ca:FileUpload\n\t\t\t \tclass="sapCaUiNotes"\n\t\t\t    id="fileupload"\n\t\t\t    items="/Attachments"\n\t\t\t    uploadUrl="name"\n\t\t\t    fileName="name"\n\t\t\t    size="size"\n\t\t\t    url="url"\n\t\t\t    uploadedDate="uploadedDate"\n\t\t\t    contributor="contributor"\n\t\t\t    fileExtension="fileExtension"\n\t\t\t    fileId="documentId"\t\n\t\t\t    editMode="false"\n\t\t\t    showNoData="true" \n\t\t\t    uploadEnabled = "false"/>\n\t\t</content>\n\t</Page>\n</core:View>',
	"cus/crm/myaccounts/view/S4Notes.controller.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");
jQuery.sap.require("cus.crm.myaccounts.util.formatter");

sap.ca.scfld.md.controller.BaseFullscreenController.extend("cus.crm.myaccounts.view.S4Notes", {

    onInit : function() {
    	this.oRouter.attachRouteMatched(this.handleNavTo, this);

    },
    handleNavTo : function(oEvent){
    	if (oEvent.getParameter("name") === "AccountNotes") {	
    		var oView = this.getView();
//           Unused variables
//			var contextPath = oEvent.getParameter("arguments").contextPath;
//			var oPage = this.byId("page");
    		var oModel = this.getView().getModel();
    		var sPath = '/' + oEvent.getParameter("arguments").contextPath;
    		var context = new sap.ui.model.Context(oModel, '/' + oEvent.getParameter("arguments").contextPath);
    		var fnBindViewContext = function(){
    			oView.setBindingContext(context);
    		};
    		oModel.createBindingContext(sPath, "", {expand: 'Notes'},fnBindViewContext,true);
    	}
    },
    handleNavBack: function(){
    	window.history.back();
   	
	}	
	
});
},
	"cus/crm/myaccounts/view/S4Notes.view.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core" xmlns:ca="sap.ca.ui" xmlns:html="http://www.w3.org/1999/xhtml"\n\txmlns="sap.m" controllerName="cus.crm.myaccounts.view.S4Notes">\n\n\n\t<Page id="page" title="{i18n>NOTES}" showNavButton="true" navButtonPress="handleNavBack">\n\t\t<content>\n\t\t\t<ObjectHeader title="{i18n>NOTES}">\n\t\t\t\t<attributes>\n\t\t\t\t\t<ObjectAttribute text="{parts:[{path: \'fullName\'},{path: \'name1\'}], formatter: \'cus.crm.myaccounts.util.formatter.AccountNameFormatter\'}"></ObjectAttribute>\n\t\t\t\t</attributes>\n\t\t\t</ObjectHeader>\n\t\t\t<html:div><html:hr ></html:hr></html:div>\n\t\t\t<ca:Notes growing="true" growingThreshold="4" showNoteInput="false" items="{Notes}">\n\t\t\t\t<ca:ExpansibleFeedListItem  senderActive="false" showIcon="false" text="{content}" sender="{creator}" timestamp="{parts:[{path:\'createdAt\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatMediumDateTime\' }" maxLines="3"></ca:ExpansibleFeedListItem>\n\t\t\t</ca:Notes>\n\t\t</content>\n\t</Page>\n</core:View>',
	"cus/crm/myaccounts/view/maintain/GeneralDataEdit.controller.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");
jQuery.sap.require("cus.crm.myaccounts.util.Util");
jQuery.sap.require("cus.crm.myaccounts.util.formatter");
jQuery.sap.require("cus.crm.myaccounts.util.Constants");
jQuery.sap.require("sap.m.MessageToast");
jQuery.sap.require("sap.m.MessageBox");

sap.ca.scfld.md.controller.BaseFullscreenController.extend("cus.crm.myaccounts.view.maintain.GeneralDataEdit", {

/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf view.maintain.GeneralDataEdit
*/
	onInit: function() {
		this.addressForm = "editFormAddress" + this.getDefaultAddressFormat();
		this.addressFragment = "addressFragment" + this.getDefaultAddressFormat();
		this.liveChangeTimer = 0;
		this.editMode = true;
		this.oDataModel = null;
		this.valueHelpEmployeeResponsible = null;
		this.valueHelpCountry = null;
		this.valueHelpRegion = null;
		this.countryIDUsedForRegion = undefined;
		this.countryIDUsedForRegionSuggestion = undefined;
		this.customizingModel = new sap.ui.model.json.JSONModel({TitleCustomizing: [], AcademicTitleCustomizing: [], RatingCustomizing: [], DefaultEmployeeResponsible: []});
		this.getView().setModel(this.customizingModel, "Customizing");
		
		if(!this.oDataModel)
			this.oDataModel = this.getView().getModel();
		
		var constants = new sap.ui.model.json.JSONModel(cus.crm.myaccounts.util.Constants);
		this.getView().setModel(constants, "constants");	
		this._readCustomizing(function(){this._refreshDropDownBoxes(); this._setDefaultEmployeeResponsible();});
		
		this.oRouter.attachRouteMatched(function (oEvent) {
			if (oEvent.getParameter("name") === "edit") {
				this.editMode = true;
				this._cleanUp();
				var oArguments = oEvent.getParameter("arguments");
				var oModel = this.oDataModel;
				this.getView().setModel(oModel);
				var contextPath = "/"+oArguments.contextPath;
				var oContext = oModel.getContext(contextPath);
				this.getView().setBindingContext(oContext);
				var countryID;
				var that = this;
				if(!oContext.getObject()){ //if context has no account object (if the view has been called directly with a link)
					oModel.createBindingContext(contextPath, "", {
						expand : this._getExpandForDataBinding()},
						function() {
							var oContext = that.getView().getBindingContext();
							var oModel = that.getView().getModel();
							countryID = oModel.getProperty(oContext.sPath+"/MainAddress/countryID");
							if (countryID && countryID !== ""){
								that._displayCountrySpecificAddressFormat(countryID);
								that._setAddressFieldsEnabled(true, false);
							}else{
								that._displayCountrySpecificAddressFormat(that.getDefaultAddressFormat());
								that._setAddressFieldsEnabled(false, false);
							}
						},
						true);
				}
				else{
					countryID = oModel.getProperty(oContext.sPath+"/MainAddress/countryID");
					this._displayCountrySpecificAddressFormat(countryID);
					this._toggleAddressFields();
				}
			}
			if (oEvent.getParameter("name") === "new") {
				this.editMode = false;
				this._cleanUp();
				var accountCategory = oEvent.getParameter("arguments").accountCategory;
				if( accountCategory !== cus.crm.myaccounts.util.Constants.accountCategoryPerson && accountCategory !== cus.crm.myaccounts.util.Constants.accountCategoryCompany && accountCategory !== cus.crm.myaccounts.util.Constants.accountCategoryGroup)
					accountCategory = cus.crm.myaccounts.util.Constants.accountCategoryCompany;
				this._setEmptyScreen(accountCategory);
				this._displayCountrySpecificAddressFormat(this.getDefaultAddressFormat());
				this._toggleAddressFields();
			}
		}, this);
	},

	getDefaultAddressFormat: function(){
		/** * @ControllerHook	extHookGetDefaultAddressFormat
		 * 						In the method extHookGetDefaultAddressFormat it is possible to define
		 * 						a default address format. The return value should be an existing country
		 * 						code e.g. US, JP.
		 * @callback cus.crm.myaccounts.view.maintain.GeneralDataEdit~extHookGetDefaultAddressFormat
		 * @return {string} */
		if(this.extHookGetDefaultAddressFormat)
			return this.extHookGetDefaultAddressFormat();
		else
			return "";
	},

	_displayCountrySpecificAddressFormat: function(countryID) {
		this.getView().byId(this.addressForm).setVisible(false);
		this._setAddressFragmentAndForm(countryID);
		this.getView().byId(this.addressForm).setVisible(true);
	},

	_setAddressFragmentAndForm: function(countryID) {
		this.addressFragment = "addressFragment" + countryID;
		this.addressForm = "editFormAddress" + countryID;

		//addressForm for countryID does not exist in xml - use default address form and fragment
		if(!this.getView().byId(this.addressForm)) {
			this.addressFragment = "addressFragment" + this.getDefaultAddressFormat();
			this.addressForm = "editFormAddress" + this.getDefaultAddressFormat();
		}
	},

	_setEmptyScreen: function(accountCategory){
		var oAccountTemplate = this._getTemplateForAccount(accountCategory);

		var aDependentRelations = this._getDependentRelations();
		for(var i in aDependentRelations){
			oAccountTemplate[aDependentRelations[i]] = this._getTemplateForDependentObject(aDependentRelations[i]);
		}

		var oNewAccountModel = new sap.ui.model.json.JSONModel({NewAccount: oAccountTemplate});
		oNewAccountModel.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay); //to be similar to oData model
		this.getView().setModel(oNewAccountModel);
		this.getView().setBindingContext(oNewAccountModel.getContext("/NewAccount"));
		this._setDefaultEmployeeResponsible();
	},

	_getExpandForDataBinding: function(){
		var expandString=null;
		var aDependentRelations = this._getDependentRelations();
		for(var i in aDependentRelations){
			if(!expandString)
				expandString = aDependentRelations[i];
			else
				expandString = expandString + "," + aDependentRelations[i];
		}
		return expandString;
	},

	_getDependentRelations: function(){
		var oDependentRelations = ["MainAddress", "Classification", "EmployeeResponsibleRel", "EmployeeResponsible"];
		var oDependentCustomRelations = [];
		/** * @ControllerHook extHookGetDependentCustomRelations
		 * The method extHookGetDependentCustomRelations should return an array
		 * with additional navigation properties for the AccountCollection, which should be considered in the create/update process 
		 * @callback cus.crm.myaccounts.view.maintain.GeneralDataEdit~extHookGetDependentCustomRelations
		 * @return {array} */
		if (this.extHookGetDependentCustomRelations)
			oDependentCustomRelations = this.extHookGetDependentCustomRelations();
		for(var i in oDependentCustomRelations){
			oDependentRelations.push(oDependentCustomRelations[i]);
		}

		return oDependentRelations;
	},

	_getTemplateForAccount: function(accountCategory){
		var oAccountTemplate = this._generateTemplateUsingMetadata("AccountCollection");
		oAccountTemplate.category = accountCategory;
		return oAccountTemplate;
	},

	_getTemplateForDependentObject: function(relationName){
		switch (relationName) {
		  	case "EmployeeResponsibleRel":{
		  		var oRel = this._generateTemplateUsingMetadata("AccountCollection/"+  relationName);
		        oRel.main = true;
		        oRel.relationshipCategory = 'BUR011';	//Relationship - Has the Employee Responsible
		        return oRel;
		    }
			default:
				return this._generateTemplateUsingMetadata("AccountCollection/"+relationName);
		}
	},

	_generateTemplateUsingMetadata: function(path){
		var oEntityMetadata = this.oDataModel.oMetadata._getEntityTypeByPath(path);
		var oTemplate={};
		for(var i in oEntityMetadata.property){
			switch(oEntityMetadata.property[i].type) {
				case "Edm.Boolean" : {
					oTemplate[oEntityMetadata.property[i].name] = false;
					break;
				}
				case "Edm.DateTime" : {
					oTemplate[oEntityMetadata.property[i].name] = null;
					break;
				}
				default:
					oTemplate[oEntityMetadata.property[i].name] = "";
			}
		}
		return oTemplate;
	},

	_objectKeyIsInitial: function(object, path){
		var oEntityMetadata = this.oDataModel.oMetadata._getEntityTypeByPath(path);
		for(var i in oEntityMetadata.key.propertyRef)
			if(object[oEntityMetadata.key.propertyRef[i].name] !== "")
				return false;

		return true;
	},

	_fillNewObject: function(sourceObject, targetObject, fieldPrefix, fragmentName){

		var changesExist = false;
		var inputFieldId = "";
		for (var key in sourceObject) {

			if(fragmentName)
				inputFieldId = this.getView().getId()+"--"+fragmentName+"--"+fieldPrefix+key+"Input";
			else
				inputFieldId = this.getView().getId()+"--"+fieldPrefix+key+"Input";

			if(typeof sourceObject[key] !== "object" || key === "birthDate")
				targetObject[key] = sourceObject[key];

			//get new value from input field
			var oInputField = this.byId(inputFieldId);
			if (oInputField){
				var newValue = "";
				if(oInputField.getDateValue){	//special logic for dates
					newValue = oInputField.getValue();
					newValue = cus.crm.myaccounts.util.formatter.convertDateStringToUTC( newValue );
				}
				else if (oInputField.getSelectedKey) //special logic for select field
					newValue = oInputField.getSelectedKey();
				else if (oInputField.getValue) 	//special logic for input field
					newValue = oInputField.getValue();
				else if (oInputField.getSelected)  //special logic for radio buttons and check boxes
					newValue = oInputField.getSelected();

				//check if the new value is different from the original value
				if (newValue && newValue.getTime){
					if(!targetObject[key] || newValue.getTime() !== targetObject[key].getTime()){
						changesExist = true;
						targetObject[key] = newValue;
					}
				}
				else if(targetObject[key] !== newValue){
					changesExist = true;
					targetObject[key] = newValue;
				}
			}
		}
		return changesExist;
	},

	_onAfterSave: function(responseObject, oError){
		this._setBusy(false);
		if(oError){
			if(this["_onAfterSaveHandleErrorCode_"+oError.statusCode])
				this["_onAfterSaveHandleErrorCode_"+oError.statusCode]();
			else
				sap.m.MessageBox.alert(oError.message.value);
			return;
		}

		if (this.editMode)
			window.history.back();
		else
			this.oRouter.navTo("detail", {
			    contextPath : "AccountCollection('"+responseObject.accountID+"')"
			}, true);
	},

	_onAfterSaveHandleErrorCode_412: function(){
		var that = this;
		sap.m.MessageBox.show(cus.crm.myaccounts.util.Util.geti18NText("MSG_CONFLICTING_DATA"), {
		    title: cus.crm.myaccounts.util.Util.geti18NText("CONFIRM_TITLE"),
		    actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
		    onClose: function (confirmed) {
				if(confirmed === sap.m.MessageBox.Action.YES){
					that._saveData(true);
				}
				else{
					var oRefreshUIObject = cus.crm.myaccounts.util.Util.getRefreshUIObject(that.getView().getModel(), that.getView().getBindingContext().sPath, that._getExpandForDataBinding());
					oRefreshUIObject.refresh();
				}
			}
		});
	},

	onSaveButtonPressed: function(){
		this._saveData(false);
	},

	_saveData: function(forceSave){

		var eTagString = null;
		if(forceSave)
			eTagString = "*";

		// In case no country has been entered, the address fields are emptied
		if(!this.byId(sap.ui.core.Fragment.createId(this.addressFragment,"MainAddress.countryIDInput")).getValue()) {
			this._setAddressFieldsEnabled(false, true);
		}

		if(!this._checkSavePossible())
			return;
		if(!this._checkSaveNeeded()){
			this.onCancelButtonPressed();
			return;
		}
		
		this._setBusy(true);
		var oModel = this.getView().getModel();
		var oAccountContext = this.getView().getBindingContext();
		var oAccount = oAccountContext.getObject();
		var oNewAccount = {};
		
		var changesInAccount=false, changesInAccountSpecificFields=false, changesForDependentRelations=false;
		
		changesInAccount = this._fillNewObject(oAccount, oNewAccount, "");
		if(oAccount.category === cus.crm.myaccounts.util.Constants.accountCategoryPerson)
			changesInAccountSpecificFields = this._fillNewObject(oNewAccount, oNewAccount, "", "personFragment");
		if(oAccount.category !== cus.crm.myaccounts.util.Constants.accountCategoryPerson)
			changesInAccountSpecificFields = this._fillNewObject(oNewAccount, oNewAccount, "", "companyFragment");
		if(changesInAccountSpecificFields)
			changesInAccount = changesInAccountSpecificFields;
		
		changesForDependentRelations = this._changesForDependentRelationsExists("saveMode");
		
		if(!changesInAccount && !changesForDependentRelations)
			return;	
		
		var oBatchOperation, sRequestURL;
		var aBatchOperation = [];
		var that = this;
		if(this.editMode){
			
			if (changesInAccount) {
				sRequestURL = oAccountContext.sPath;
				oBatchOperation = oModel.createBatchOperation(sRequestURL, "PUT", oNewAccount, {sETag: eTagString});
				aBatchOperation.push(oBatchOperation);
			}

			if(changesForDependentRelations) {
				this._createBatchOperationForDependentRelations(aBatchOperation, eTagString);
			}
			
			cus.crm.myaccounts.util.Util.sendBatchChangeOperations(this.oDataModel, aBatchOperation, 
					function(responseObject){
						var oRefreshUIObject = cus.crm.myaccounts.util.Util.getRefreshUIObject(oModel, oAccountContext.sPath, that._getExpandForDataBinding());
						oRefreshUIObject.refresh(); 
						sap.m.MessageToast.show(cus.crm.myaccounts.util.Util.geti18NText("MSG_UPDATE_SUCCESS"));
						that._onAfterSave(responseObject[0]);
					}, 
					function(oError){ 
						that._onAfterSave(null, oError);
					});
			
		}
		else {
	
			sRequestURL = "/AccountCollection";
			oBatchOperation = this.oDataModel.createBatchOperation(sRequestURL, "POST", oNewAccount);
			
			if(changesForDependentRelations){
				this._adaptAccountWithDependentRelationsBeforeCreate(oNewAccount);
			}
			
			aBatchOperation.push(oBatchOperation);
			cus.crm.myaccounts.util.Util.sendBatchChangeOperations(this.oDataModel, aBatchOperation,
					function(responseObject){
						sap.m.MessageToast.show(cus.crm.myaccounts.util.Util.geti18NText("MSG_CREATION_SUCCESS"));
						that._onAfterSave(responseObject[0]);
					},
					function(oError){
						that._onAfterSave(null, oError);
					});
		}
	},

	_adaptAccountWithDependentRelationsBeforeCreate: function(oNewAccount){

		var aDependentRelations = this._getDependentRelations();
		for(var i in aDependentRelations){
			var oDependentObject = this._getTemplateForDependentObject(aDependentRelations[i]);
			var oNewDependentObject = {};
			var fragmentName = null;
			if(aDependentRelations[i] === "MainAddress"){
				fragmentName = this.addressFragment;
			}
			var changesInDependentObject = this._fillNewObject(oDependentObject, oNewDependentObject, aDependentRelations[i]+".", fragmentName);
			if (changesInDependentObject)
				oNewAccount[aDependentRelations[i]] = oNewDependentObject;
		}
	},

	_createBatchOperationForDependentRelations: function(aBatchOperation, eTagString){
		var oModel = this.getView().getModel();
		var oAccountContext = this.getView().getBindingContext();
		var oAccount = oAccountContext.getObject();


		var aDependentRelations = this._getDependentRelations();
		for(var i in aDependentRelations){
			var oDependentObject = oModel.getProperty(oAccountContext+"/"+aDependentRelations[i]);
			var oDependentObjectContext = null;
			if (oDependentObject)
				oDependentObjectContext = oModel.getContext("/"+oAccount[aDependentRelations[i]]["__ref"]); 
			var oNewDependentObject = {};
			
			var changesInDependentObject=false;
			
			var dependentObjectToBeCreated = false;
			if(!oDependentObject || this._objectKeyIsInitial(oDependentObject, "AccountCollection/"+aDependentRelations[i])){	//odata contains initial address with no keys -> only if user comes from search result list
				dependentObjectToBeCreated = true;
				oDependentObject = this._getTemplateForDependentObject(aDependentRelations[i]);
				if(oDependentObject.accountID !== null && oDependentObject.accountID !== undefined)
					oDependentObject.accountID = oAccount.accountID;
			}
			var fragmentName = null;
			if(aDependentRelations[i] === "MainAddress"){
				fragmentName = this.addressFragment;
			}
			changesInDependentObject = this._fillNewObject(oDependentObject, oNewDependentObject, aDependentRelations[i]+".", fragmentName );
			
			var oBatchOperation, requestURL;
			if(changesInDependentObject){
				var httpMethod;
				if(dependentObjectToBeCreated){
					httpMethod = "POST";
					var oEntityMetadata = this.oDataModel.oMetadata._getEntityTypeByPath("AccountCollection/"+aDependentRelations[i]);
					requestURL = oEntityMetadata.name+"Collection";
				}
				else{
					httpMethod = "PUT";
					requestURL = oDependentObjectContext.sPath;
				}
				oBatchOperation = oModel.createBatchOperation(requestURL, httpMethod, oNewDependentObject, {sETag: eTagString});
				aBatchOperation.push(oBatchOperation);
			}
		}
	},

	_changesForDependentRelationsExists: function(saveMode){
		var oModel = this.oDataModel;
		var oAccountContext = this.getView().getBindingContext();
		var changesInDependentObject = false;
		var aDependentRelations = this._getDependentRelations();
		for(var i in aDependentRelations){
			var oDependentObject = oModel.getProperty(oAccountContext+"/"+aDependentRelations[i]);	//check if entity exists. In create case it will be always empty
			if(!saveMode)
				oDependentObject = oAccountContext.getProperty(aDependentRelations[i]);	//check if entity exists. In create case it will be always filled
			if(!oDependentObject)
				oDependentObject = this._getTemplateForDependentObject(aDependentRelations[i]);	//if the entity does not exist -> use template
			var oNewDependentObject = {};
			var fragmentName = null;
			if(aDependentRelations[i] === "MainAddress"){
				fragmentName = this.addressFragment;
			}
			changesInDependentObject = this._fillNewObject(oDependentObject, oNewDependentObject, aDependentRelations[i]+".", fragmentName);
			if(changesInDependentObject)
				return changesInDependentObject;
		}

		return changesInDependentObject;
	},

	onCancelButtonPressed: function(){
		
		if(!this._checkSaveNeeded()){
			window.history.back();
			return;
		}

		sap.m.MessageBox.confirm(
			cus.crm.myaccounts.util.Util.geti18NText("MSG_CONFIRM_CANCEL"),
			jQuery.proxy(function (confirmed) {
				if (confirmed === "OK") {
					window.history.back();
				}
			}, this)
		);
	},

	onBackButtonPressed: function(){

		if(!this._checkSaveNeeded()){
			window.history.back();
			return;
		}

		sap.m.MessageBox.confirm(
			cus.crm.myaccounts.util.Util.geti18NText("MSG_CONFIRM_CANCEL"),
			jQuery.proxy(function (confirmed) {
				if (confirmed === "OK") {
					window.history.back();
				}
			}, this)
		);
	},

	onInputFieldChanged:function () {
	},

	_checkSavePossible: function(){
		var inputField, countryID, country, regionID, region, employeeID, employee, url;

		inputField = this.byId(sap.ui.core.Fragment.createId(this.addressFragment,"MainAddress.countryIDInput"));
		if(inputField)
			countryID = inputField.getValue();

		inputField = this.byId(sap.ui.core.Fragment.createId(this.addressFragment,"MainAddress.countryInput"));
		if(inputField)
			country = inputField.getValue();
		
		if(country && !countryID){
			sap.m.MessageBox.alert( cus.crm.myaccounts.util.Util.geti18NText1("MSG_WRONG_COUNTRY_ERROR", country));
			return false;
		}
			
		inputField = this.byId(sap.ui.core.Fragment.createId(this.addressFragment,"MainAddress.regionIDInput"));
		if(inputField)
			regionID = inputField.getValue();
		
		inputField = this.byId(sap.ui.core.Fragment.createId(this.addressFragment,"MainAddress.regionInput"));
		if(inputField)
			region = inputField.getValue();
		
		if(region && !regionID){
			sap.m.MessageBox.alert( cus.crm.myaccounts.util.Util.geti18NText1("MSG_WRONG_REGION_ERROR", region));
			return false;
		}
		
		inputField = this.getView().byId("EmployeeResponsibleRel.account2IDInput");
		if(inputField)
			employeeID = inputField.getValue();
		
		inputField = this.getView().byId("EmployeeResponsibleRel.account2FullNameInput");
		if(inputField)
			employee = inputField.getValue();
		
		if(employee && !employeeID){
			sap.m.MessageBox.alert( cus.crm.myaccounts.util.Util.geti18NText1("MSG_WRONG_EMPLOYEE_ERROR", employee));
			return false;
		}
		
		inputField = this.byId(sap.ui.core.Fragment.createId(this.addressFragment,"MainAddress.websiteInput"));
		if(inputField){
			url = inputField.getValue();
			if(!jQuery.sap.validateUrl(url)){
				sap.m.MessageBox.alert( cus.crm.myaccounts.util.Util.geti18NText1("MSG_WRONG_URL_ERROR", url));
				return false;
			}

		}

		//Check if all mandatory fields are filled
		var isMandatoryFieldsFilled = true;
		var oAccount = this.getView().getBindingContext().getObject();
		if(oAccount.category === cus.crm.myaccounts.util.Constants.accountCategoryPerson){
			if (this.byId(sap.ui.core.Fragment.createId("personFragment","name1Input")).getValue().length === 0){
				this.byId(sap.ui.core.Fragment.createId("personFragment","name1Input")).setValueState(sap.ui.core.ValueState.Error);
				isMandatoryFieldsFilled = false;	
			}
		}
		else {
			if (this.byId(sap.ui.core.Fragment.createId("companyFragment","name1Input")).getValue().length === 0){
				this.byId(sap.ui.core.Fragment.createId("companyFragment","name1Input")).setValueState(sap.ui.core.ValueState.Error);
				isMandatoryFieldsFilled = false;
			}
		}
		
		if(!isMandatoryFieldsFilled)
			sap.m.MessageBox.alert( cus.crm.myaccounts.util.Util.geti18NText("MSG_MANDATORY_FIELDS"));
			
		return isMandatoryFieldsFilled;

	},
	
	_checkSaveNeeded: function(){
		var oAccountContext = this.getView().getBindingContext();
		var oAccount = oAccountContext.getObject();
		var oNewAccount = {};

		var changesInAccount=false, changesForDependentRelations=false;

		changesInAccount = this._fillNewObject(oAccount, oNewAccount, "");
		if(changesInAccount)
			return true;
		
		if(oAccount.category === cus.crm.myaccounts.util.Constants.accountCategoryPerson)
			changesInAccount = this._fillNewObject(oNewAccount, oNewAccount, "", "personFragment");
		if(oAccount.category !== cus.crm.myaccounts.util.Constants.accountCategoryPerson)
			changesInAccount = this._fillNewObject(oNewAccount, oNewAccount, "", "companyFragment");
		
		if(changesInAccount)
			return true;

		changesForDependentRelations = this._changesForDependentRelationsExists();
		if(!changesForDependentRelations)
			return false;
		else
			return true;
	},
	
	_cleanUp: function(){
		this.getView().setModel(null);
		this.setBtnEnabled("saveButton", true);
	},
	
	_setBusy: function(busy){
		if(!this.oBusyDialog)
			this.oBusyDialog = new sap.m.BusyDialog();			
		if(busy){
			this.setBtnEnabled("saveButton", !busy);
			this.setBtnEnabled("cancelButton", !busy);
			this.oBusyDialog.open();
		}
		else{
			this.setBtnEnabled("saveButton", !busy);
			this.setBtnEnabled("cancelButton", !busy);
			this.oBusyDialog.close();
		}
	},

	// ############################### address specific methods: ################################################################

	_setCountry: function(countryID, country){
		if(countryID)
			this._displayCountrySpecificAddressFormat(countryID);
				
		var countryInput = this.byId(sap.ui.core.Fragment.createId(this.addressFragment,"MainAddress.countryInput"));
		var countryIDInput = this.byId(sap.ui.core.Fragment.createId(this.addressFragment,"MainAddress.countryIDInput"));

    	var oldCountryID = countryIDInput.getValue();
    	if (oldCountryID !== countryID){
    		this._setRegion("", ""); //clear region
    	}
    	
    	if(countryInput)
    		countryInput.setValue(country);
    	if(countryIDInput)
    		countryIDInput.setValue(countryID);

    	//enable address input field
    	this._toggleAddressFields();
	},

	_readCountries: function(callbackCountryRead){
		var that = this;
		this.valueHelpCountry.setModel(new sap.ui.model.json.JSONModel({CountryCustomizing: []}));
		this.oDataModel.read("/CustomizingCountryCollection", null, undefined, true,
			function(oData){
				var countryCustomizing = jQuery.parseJSON(JSON.stringify(oData));
				that.valueHelpCountry.setModel(new sap.ui.model.json.JSONModel({CountryCustomizing: countryCustomizing.results}));
				if (callbackCountryRead)
					callbackCountryRead.call(that);
			},
			function(oError){
				jQuery.sap.log.error("Read failed in GeneralDateEdit->_readCountries:"+oError.response.body);
			}
		);
	},

	_setRegion: function(regionID, region){
		var regionInput = this.byId(sap.ui.core.Fragment.createId(this.addressFragment,"MainAddress.regionInput"));
		if(regionInput)
			regionInput.setValue(region);
		var regionIDInput = this.byId(sap.ui.core.Fragment.createId(this.addressFragment,"MainAddress.regionIDInput"));
		if(regionIDInput)
			regionIDInput.setValue(regionID);
	},

	_readRegions: function(callbackRegionRead){
		var that = this;
		var currentCountryID = this.byId(sap.ui.core.Fragment.createId(this.addressFragment,"MainAddress.countryIDInput")).getValue();
		
		if(!that.aRegionCallback)
			that.aRegionCallback = [];
		
		if(that.regionReadRunning && callbackRegionRead){
			that.aRegionCallback.push(callbackRegionRead);
			return;
		}

		if(this.countryIDUsedForRegion === currentCountryID){
			if (callbackRegionRead)
				callbackRegionRead.call(that);
			return;
		}
		
		if (callbackRegionRead)
			that.aRegionCallback.push(callbackRegionRead);
		that.regionReadRunning = true;

		this.countryIDUsedForRegion = currentCountryID;
		this.valueHelpRegion.setModel(new sap.ui.model.json.JSONModel({RegionCustomizing: []}));	
		this.oDataModel.read("/CustomizingRegionCollection", null,'$filter=countryID%20eq%20%27'+currentCountryID+'%27', true,
			function(oData){
				var regionCustomizing = jQuery.parseJSON(JSON.stringify(oData));
				that.valueHelpRegion.setModel(new sap.ui.model.json.JSONModel({RegionCustomizing: regionCustomizing.results}));
				that.regionReadRunning = false;
				
				for(var i in that.aRegionCallback)
					that.aRegionCallback[i].call(that);
		},
			function(oError){
				jQuery.sap.log.error("Read failed in GeneralDateEdit->_readRegions: "+oError.response.body);
				that.regionReadRunning = false;
			}
		);
	},

	_toggleAddressFields: function(){
		
		var countryID = this.byId(sap.ui.core.Fragment.createId(this.addressFragment,"MainAddress.countryIDInput")).getValue();

		if (countryID && countryID !== ""){
			this._setAddressFieldsEnabled(true, false);
		} else {
			this._setAddressFieldsEnabled(false, false);
		}
	},

	_setAddressFieldsEnabled:function (enabled, emptyFields){
		var oAddressContainer = this.getView().byId(this.addressForm);
		if(!oAddressContainer)
			return;
		var aFormElements = oAddressContainer.getFormElements();
		var viewId = this.getView().getId();
		for(var i in aFormElements){
			var aFields = aFormElements[i].getFields();
			for(var z in aFields){
				var regEx = new RegExp(viewId+"--"+this.addressFragment+"--MainAddress.[A-z0-9]+Input","g");
				var elementId = aFields[z].getId();
				if(elementId === viewId+"--"+this.addressFragment+"--MainAddress.countryInput")
					continue;
				if(regEx.test(elementId)) {
					aFields[z].setEnabled(enabled);
					if(emptyFields)
						aFields[z].setValue("");
				}
			}
		}
	},
	
	// ############################### employee responsible value help: ###################################################
	
	_setEmployeeResponsible: function(employeeID, employee){
		var employeeInput = this.getView().byId("EmployeeResponsibleRel.account2FullNameInput");
		if(employeeInput)
			employeeInput.setValue(employee);
		var employeeIDInput = this.getView().byId("EmployeeResponsibleRel.account2IDInput");
		if(employeeIDInput)
			employeeIDInput.setValue(employeeID);	
	},
	
	onEmployeeResponsibleValueHelpSelected: function(){
		
		if(!this.valueHelpEmployeeResponsible){
			this.valueHelpEmployeeResponsible = sap.ui.xmlfragment( "cus.crm.myaccounts.view.maintain.ValueHelpEmployeeResponsible", this);
			this.valueHelpEmployeeResponsible.setModel(this.getView().getModel("i18n"), "i18n");
			this.valueHelpEmployeeResponsible.setModel(this.oDataModel);
		}
		else{
			this.valueHelpEmployeeResponsible.setModel(this.oDataModel);
		}
		this.valueHelpEmployeeResponsible.open();
	},
	
	onEmployeeResponsibleValueHelpClose: function(oEvent){
		var oSelectedItem = oEvent.getParameter("selectedItem");
	    if (oSelectedItem) {
	    	var oSelectedObject = oSelectedItem.getBindingContext().getObject();
	    	this._setEmployeeResponsible(oSelectedObject.employeeID, oSelectedObject.fullName);
	    }
	    if(oEvent.getSource().getBinding("items").aFilters.length){
	    	oEvent.getSource().destroyItems();
		    this.valueHelpEmployeeResponsible.setModel(null);
	    }
	},
	
	onEmployeeResponsibleValueHelpSearch: function(oEvent){
		var searchValue = oEvent.getParameter("value");
	    var oFilter = new sap.ui.model.Filter("fullName", sap.ui.model.FilterOperator.Contains, searchValue);
	    oEvent.getSource().getBinding("items").filter([oFilter]);
	},
	
	onEmployeeResponsibleValueHelpCancel: function(oEvent){
		if(oEvent.getSource().getBinding("items").aFilters.length){
	    	oEvent.getSource().destroyItems();
		    this.valueHelpEmployeeResponsible.setModel(null);
	    }
	},
	
	// ############################### employee responsible suggestion: ###################################################
	onEmployeeResponsibleSuggestItemSelected:function(oEvent){

		var oItem = oEvent.getParameter("selectedItem");
		var employeeID = null;
		for(var i in oItem.getCustomData()){
			var oCustomData = oItem.getCustomData()[i];
			if (oCustomData.getKey() === "employeeID")
				employeeID = oCustomData.getValue();
		}
		this._setEmployeeResponsible(employeeID, oItem.getText());
	},
	
	onEmployeeResponsibleInputFieldChanged:function(oEvent){
		this.onInputFieldChanged();
		var account2FullNameInput = oEvent.getSource();
		this._setEmployeeResponsible("", account2FullNameInput.getValue());
		
		account2FullNameInput.setFilterSuggests(false);
		
		var fnCheckEmployeeResponsible = function(aEmployeeResponsibles){
			
			// recommended to do remove within the callback function due to duplicate 
			// entries appearing in search result list (msg: 706252)
			account2FullNameInput.removeAllSuggestionItems();

			for(var i=0; i<aEmployeeResponsibles.length; i++){
				var oEmployeeResponsible = aEmployeeResponsibles[i];
				if (oEmployeeResponsible.fullName.toUpperCase() === account2FullNameInput.getValue().toUpperCase()){
					this._setEmployeeResponsible(oEmployeeResponsible.employeeID, oEmployeeResponsible.fullName);
				}
				var oCustomData = new sap.ui.core.CustomData({key:"employeeID", value:oEmployeeResponsible.employeeID});
				var oItem = new sap.ui.core.Item({text:oEmployeeResponsible.fullName, customData:oCustomData});
				account2FullNameInput.addSuggestionItem(oItem);
			}
		};
		this._readEmployeeResponsible(account2FullNameInput.getValue(),fnCheckEmployeeResponsible);
	},
		
	_readEmployeeResponsible:function(searchString,callbackRead){
		var that = this;
		var delay = (searchString ? 500 : 0);
		window.clearTimeout(this.liveChangeTimer);
		if (delay) {
			this.liveChangeTimer = window.setTimeout(function () {
				that.oDataModel.read("/EmployeeCollection", null, '$top=10&$filter=substringof(%27'+encodeURIComponent(searchString)+'%27,fullName)', true,
						function(oData){
							var employeeResponsibleData = jQuery.parseJSON(JSON.stringify(oData));
							if (callbackRead)
								callbackRead.call(that,employeeResponsibleData.results);
						},
						function(oError){
							jQuery.sap.log.error("Read failed in GeneralDateEdit->_readEmployeeResponsible:"+oError.response.body);
						}
					);
			}, delay);
		}
	},
	
	// ############################### country value help: ################################################################

	onCountryValueHelpSelected: function(){
		if (!this.valueHelpCountry) {
			this._createValueHelpCountry();
		   // this.getView().addDependent(this.valueHelpCountry);
		    this._readCountries();
		}
	    this.valueHelpCountry.open();
	},

	_createValueHelpCountry: function(){
		if(!this.valueHelpCountry){
			this.valueHelpCountry = sap.ui.xmlfragment( "cus.crm.myaccounts.view.maintain.ValueHelpCountry", this);
			this.valueHelpCountry.setModel(this.getView().getModel("i18n"), "i18n");
		}
	},

	onCountryValueHelpSearch: function(oEvent){
		var searchValue = oEvent.getParameter("value");
	    var oFilter = new sap.ui.model.Filter("country", sap.ui.model.FilterOperator.Contains, searchValue);
	    oEvent.getSource().getBinding("items").filter([oFilter]);
	},

	onCountryValueHelpClose: function(oEvent){
		var oSelectedItem = oEvent.getParameter("selectedItem");
	    if (oSelectedItem) {
	    	var oSelectedObject = oSelectedItem.getBindingContext().getObject();
			this._setCountry(oSelectedObject.countryID, oSelectedObject.country);
	    }
	    oEvent.getSource().getBinding("items").filter([]);
	},
	
	onCountryValueHelpCancel: function(oEvent){
	    oEvent.getSource().getBinding("items").filter([]);
	},
	
	// ############################### region value help: ################################################################

	onRegionValueHelpSelected: function(){
		if (!this.valueHelpRegion) {
			this._createValueHelpRegion();
		    //this.getView().addDependent(this.valueHelpRegion);
		}
		this._readRegions();
	    this.valueHelpRegion.open();
	},

	_createValueHelpRegion: function(){
		if(!this.valueHelpRegion){
			this.valueHelpRegion = sap.ui.xmlfragment( "cus.crm.myaccounts.view.maintain.ValueHelpRegion", this);
			this.valueHelpRegion.setModel(this.getView().getModel("i18n"), "i18n");
		}
	},
	
	onRegionValueHelpSearch: function(oEvent){
		var searchValue = oEvent.getParameter("value");
	    var oFilter = new sap.ui.model.Filter("region", sap.ui.model.FilterOperator.Contains, searchValue);
	    oEvent.getSource().getBinding("items").filter([oFilter]);
	},
	
	onRegionValueHelpClose: function(oEvent){
		var oSelectedItem = oEvent.getParameter("selectedItem");
	    if (oSelectedItem) {
	    	var oSelectedObject = oSelectedItem.getBindingContext().getObject();
	    	this._setRegion(oSelectedObject.regionID, oSelectedObject.region);
	    }
	    oEvent.getSource().getBinding("items").filter([]);
	},

	onRegionValueHelpCancel: function(oEvent){
		oEvent.getSource().getBinding("items").filter([]);
	},
	
	
	// ############################### country suggestion: ################################################################
	
	onCountrySuggest: function(oEvent){
		var countryInput = oEvent.getSource();
		var fnDisplaySuggestion = function(){
			var oModel = this.valueHelpCountry.getModel();
			if(countryInput.getSuggestionItems().length > 0)
				return;
			var aCountries = oModel.getProperty("/CountryCustomizing");
			for(var i=0; i<aCountries.length; i++){
				var oCountry = aCountries[i];
				var oCustomData = new sap.ui.core.CustomData({key:"countryID", value:oCountry.countryID});
				var oItem = new sap.ui.core.Item({text: oCountry.country, customData:oCustomData});
				countryInput.addSuggestionItem(oItem);
			}
		};
		if (!this.valueHelpCountry) {
			this._createValueHelpCountry();
		    this._readCountries(fnDisplaySuggestion);
		}
		else{
			fnDisplaySuggestion.call(this);
		}
	},
	
	onCountrySuggestItemSelected: function(oEvent){
		var oItem = oEvent.getParameter("selectedItem");
		var countryID = null;
		for(var i in oItem.getCustomData()){
			var oCustomData = oItem.getCustomData()[i];
			if (oCustomData.getKey() === "countryID")
				countryID = oCustomData.getValue();
		}
		this._setCountry(countryID, oItem.getText());
	},

	onCountryInputFieldChanged:function (oEvent) {
		this.onInputFieldChanged();
		var countryInput = oEvent.getSource();
		this._setCountry("", countryInput.getValue());
		
		var fnCheckCountry = function(){
			var oModel = this.valueHelpCountry.getModel();
			var aCountries = oModel.getProperty("/CountryCustomizing");
			for(var i=0; i<aCountries.length; i++){
				var oCountry = aCountries[i];
				if (oCountry.country.toUpperCase() === countryInput.getValue().toUpperCase())
					this._setCountry(oCountry.countryID, countryInput.getValue());
			}
		};
		if (!this.valueHelpCountry) {
			this._createValueHelpCountry();
		    this._readCountries(fnCheckCountry);
		}
		else{
			fnCheckCountry.call(this);
		}
	},
	
	// ############################### region suggestion: ################################################################
	
	onRegionSuggest: function(oEvent){
		var regionInput = oEvent.getSource();
		var fnDisplaySuggestion = function(){
			if(this.countryIDUsedForRegionSuggestion === this.countryIDUsedForRegion)
				return;
			this.countryIDUsedForRegionSuggestion = this.countryIDUsedForRegion;
			var oModel = this.valueHelpRegion.getModel();
			var aRegions = oModel.getProperty("/RegionCustomizing");
			regionInput.removeAllSuggestionItems();
			for(var i=0; i<aRegions.length; i++){
				var oRegion = aRegions[i];
				var oCustomData = new sap.ui.core.CustomData({key:"regionID", value:oRegion.regionID});
				var oItem = new sap.ui.core.Item({text: oRegion.region, customData:oCustomData});
				regionInput.addSuggestionItem(oItem);
			}
		};
		if (!this.valueHelpRegion)
			this._createValueHelpRegion();
		
		this._readRegions(fnDisplaySuggestion);
		
	},

	onRegionSuggestItemSelected: function(oEvent){
		var oItem = oEvent.getParameter("selectedItem");
		var regionID = null;
		for(var i in oItem.getCustomData()){
			var oCustomData = oItem.getCustomData()[i];
			if (oCustomData.getKey() === "regionID")
				regionID = oCustomData.getValue();
		}
		this._setRegion(regionID, oItem.getText());
	},

	onRegionInputFieldChanged:function (oEvent) {
		this.onInputFieldChanged();
		var regionInput = oEvent.getSource();
		this._setRegion("", regionInput.getValue());
		
		var fnCheckRegion = function(){
			var oModel = this.valueHelpRegion.getModel();
			var aRegions = oModel.getProperty("/RegionCustomizing");
			for(var i=0; i<aRegions.length; i++){
				var oRegion = aRegions[i];
				if (oRegion.region.toUpperCase() === regionInput.getValue().toUpperCase()){
					this._setRegion(oRegion.regionID, regionInput.getValue());
				}
					
			}
		};
		if (!this.valueHelpRegion) {
			this._createValueHelpRegion();
		    this._readRegions(fnCheckRegion);
		}
		else{
			fnCheckRegion.call(this);
		}
	},
	
	// ############################### corpAccount: Name 1, indAccount: Last a ################################################################
	
	onName1InputFieldChanged: function() {
		var oAccount = this.getView().getBindingContext().getObject();
		if(oAccount.category === cus.crm.myaccounts.util.Constants.accountCategoryPerson)
			this.byId(sap.ui.core.Fragment.createId("personFragment","name1Input")).setValueState(sap.ui.core.ValueState.None);
		else
			this.byId(sap.ui.core.Fragment.createId("companyFragment","name1Input")).setValueState(sap.ui.core.ValueState.None);
	},
	
	// ############################### customizing for title, academic title, and rating: ################################################################
	_readCustomizing: function(callbackCustomizingRead){
		var that = this;
		var fnAfterRead = function(oResponses){
			
			var aAcademicTitles = oResponses["CustomizingAcademicTitleCollection"];
			if(aAcademicTitles){
				aAcademicTitles.unshift({title:"", titleDescription:""});
				that.customizingModel.setProperty("/AcademicTitleCustomizing", aAcademicTitles);
			}
			
			var aTitles = oResponses["CustomizingTitleCollection"];
			if (aTitles){
				aTitles.unshift({title:"", titleDescription:"", person:"X", organization:"X", group:"X"});
				that.customizingModel.setProperty("/TitleCustomizing", aTitles);
			}
			
			var aRatings = oResponses["CustomizingRatingCollection"];
			if(aRatings){
				aRatings.unshift({ratingID:"", ratingText:""});
				that.customizingModel.setProperty("/RatingCustomizing", aRatings);
			}
			
			var oDefaultEmployeeResponsible = oResponses["EmployeeCollection?$filter=isDefaultEmployee%20eq%20true"][0];
			if(oDefaultEmployeeResponsible)
				that.customizingModel.setProperty("/DefaultEmployeeResponsible", oDefaultEmployeeResponsible);
			else
				that.customizingModel.setProperty("/DefaultEmployeeResponsible", {fullName:"", employeeID:""});
				
			if (callbackCustomizingRead)
				callbackCustomizingRead.call(that);
			
		};
		
		cus.crm.myaccounts.util.Util.sendBatchReadRequests(this.oDataModel, ["CustomizingTitleCollection", "CustomizingAcademicTitleCollection", "CustomizingRatingCollection", "EmployeeCollection?$filter=isDefaultEmployee%20eq%20true"], fnAfterRead,fnAfterRead);

	},
	
	_refreshDropDownBoxes: function(){
		var aDropDownBoxesIDs = this._getIDForDropDownBoxes();
		for(var i in aDropDownBoxesIDs){
			var oDropDownBox = this.byId(this.getView().getId() + "--" + aDropDownBoxesIDs[i]);
			if (oDropDownBox){
				var oBinding = oDropDownBox.getBinding("selectedKey");
				if(oBinding){
					oDropDownBox.bindProperty("selectedKey", oBinding.sPath);
				}
			}
		}
	},
	
	_getIDForDropDownBoxes: function(){
		return ["personFragment--academicTitleIDInput", "personFragment--titleIDInput", "Classification.ratingIDInput"];
	},

	// ############################### redefinition of framework methods: ################################################################
	getHeaderFooterOptions: function(){
		var that = this;
		return {
			sI18NFullscreenTitle : "DETAIL_TITLE",
			buttonList : [
				{
					sI18nBtnTxt : "BUTTON_SAVE",
					sId : "saveButton",
					onBtnPressed : jQuery.proxy(this.onSaveButtonPressed, this),
					bDisabled : "true"
				},
				{
					sI18nBtnTxt : "BUTTON_CANCEL",
					sId : "cancelButton",
					onBtnPressed : jQuery.proxy(this.onCancelButtonPressed, this)
				}
			],
			onBack : function() {
				that.onBackButtonPressed();
			}
                             
		};
	},	
	
	_setDefaultEmployeeResponsible:function(){
		if (!this.editMode && this.customizingModel.getProperty('/DefaultEmployeeResponsible/employeeID')){
			var employeeID = this.customizingModel.getProperty('/DefaultEmployeeResponsible/employeeID');
        	var employeeFullName = this.customizingModel.getProperty('/DefaultEmployeeResponsible/fullName');
        	var oAccountContext = this.getView().getBindingContext();
        	var oModel = this.getView().getModel();
        	if(oAccountContext.getProperty("EmployeeResponsibleRel")){
        		oModel.setProperty(oAccountContext.sPath + "/EmployeeResponsibleRel/account2ID", employeeID);
        		oModel.setProperty(oAccountContext.sPath + "/EmployeeResponsibleRel/account2FullName", employeeFullName);
        	}
        	this._setEmployeeResponsible(employeeID, employeeFullName);
		}
	}

/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf view.maintain.GeneralDataEdit
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf view.maintain.GeneralDataEdit
*/
//	onAfterRendering: function() {
//
//	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf view.maintain.GeneralDataEdit
*/
//	onExit: function() {
//
//	}

});
},
	"cus/crm/myaccounts/view/maintain/GeneralDataEdit.view.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core" xmlns:mvc="sap.ui.core.mvc" xmlns="sap.m" xmlns:layout="sap.ui.layout" xmlns:form="sap.ui.layout.form"\n\t\t\tcontrollerName="cus.crm.myaccounts.view.maintain.GeneralDataEdit" xmlns:html="http://www.w3.org/1999/xhtml" id="editView">\n\t<Page showNavButton="true">\n\t\t<content>\n\t\t\t<layout:Grid defaultSpan="L12 M12 S12" width="auto">\n\t\t\t\t<layout:content>\n\t\t\t\t\t<!-- Extends the view by a form -->\n\t\t\t\t\t<core:ExtensionPoint name="extEditForm">\n\t\t\t\t\t\t<form:Form class="sapUiFormEdit sapUiFormEdit-CTX">\n\t\t\t\t\t\t\t<form:layout>\n\t\t\t\t\t\t\t\t<form:ResponsiveGridLayout xmlns:form="sap.ui.layout.form"\n\t\t\t\t\t\t\t\t\tlabelSpanL="4"\n\t\t\t\t\t\t\t\t\tlabelSpanM="4"\n\t\t\t\t\t\t\t\t\temptySpanL="3"\n\t\t\t\t\t\t\t\t\temptySpanM="2"\n\t\t\t\t\t\t\t\t\tcolumnsL="1"\n\t\t\t\t\t\t\t\t\tcolumnsM="1"\n\t\t\t\t\t\t\t\t\tclass="editableForm">\n\t\t\t\t\t\t\t\t</form:ResponsiveGridLayout>\n\t\t\t\t\t\t\t</form:layout>\n\t\t\t\t\t\t\t<form:formContainers>\n\t\t\t\t\t\t\t\t<form:FormContainer />\n\t\t\t\t\t\t\t\t<!-- Extends the form at the top -->\n\t\t\t\t\t\t\t\t<core:ExtensionPoint name="extEditFormTop"/>\n\t\t\t\t\t\t\t\t<form:FormContainer id="editFormCompany" title="{i18n>GENERAL_DATA}" visible="{parts:[\'category\', \'constants>/accountCategoryPerson\'], formatter: \'cus.crm.myaccounts.util.formatter.isUnequal\'}">\n\t\t\t\t\t\t\t\t\t<form:formElements >\n\t\t\t\t\t\t\t\t\t\t<core:Fragment id="companyFragment" fragmentName="cus.crm.myaccounts.view.maintain.GeneralDataEditCompany" type="XML" />\n\t\t\t\t\t\t\t\t\t</form:formElements>\n\t\t\t\t\t\t\t\t</form:FormContainer>\n\t\t\t\t\t\t\t\t<form:FormContainer id="editFormPerson" title="{i18n>GENERAL_DATA}" visible="{parts:[\'category\', \'constants>/accountCategoryPerson\'], formatter: \'cus.crm.myaccounts.util.formatter.isEqual\'}">\n\t\t\t\t\t\t\t\t\t<form:formElements >\n\t\t\t\t\t\t\t\t\t\t<core:Fragment id="personFragment" fragmentName="cus.crm.myaccounts.view.maintain.GeneralDataEditPerson" type="XML" />\n\t\t\t\t\t\t\t\t\t</form:formElements>\n\t\t\t\t\t\t\t\t</form:FormContainer>\n\n\t\t\t\t\t\t\t\t<form:FormContainer id="editFormRating">\n\t\t\t\t\t\t\t\t\t<form:formElements >\n\t\t\t\t\t\t\t\t\t\t<form:FormElement id="Classification.ratingID">\n\t\t\t\t\t\t\t\t\t\t\t<form:label>\n\t\t\t\t\t\t\t\t\t\t\t\t<Label text="{i18n>RATING}" id="Classification.ratingIDLabel" width="100%" />\n\t\t\t\t\t\t\t\t\t\t\t</form:label>\n\t\t\t\t\t\t\t\t\t\t\t<form:fields>\n\t\t\t\t\t\t\t\t\t\t\t\t<Select value="{Classification/ratingID}" maxLength="40" id="Classification.ratingIDInput" change="onInputFieldChanged" items="{Customizing>/RatingCustomizing}" selectedKey="{Classification/ratingID}">\n\t\t\t\t\t\t\t\t\t\t\t\t\t<core:Item key="{Customizing>ratingID}" text="{Customizing>ratingText}"/>\n\t\t\t\t\t\t\t\t\t\t\t\t</Select>\n\t\t\t\t\t\t\t\t\t\t\t</form:fields>\n\t\t\t\t\t\t\t\t\t\t</form:FormElement>\n\t\t\t\t\t\t\t\t\t</form:formElements>\n\t\t\t\t\t\t\t\t</form:FormContainer>\n\n\t\t\t\t\t\t\t\t<form:FormContainer id="editFormEmployee">\n\t\t\t\t\t\t\t\t\t<form:formElements>\n\t\t\t\t\t\t\t\t\t\t<form:FormElement id="EmployeeResponsibleRel.employee">\n\t\t\t\t\t\t\t\t\t\t\t<form:label>\n\t\t\t\t\t\t\t\t\t\t\t\t<Label text="{i18n>EMPLOYEE_RESPONSIBLE}" id="EmployeeResponsibleRel.employeeLabel"  width="100%" visible="true"/>\n\t\t\t\t\t\t\t\t\t\t\t</form:label>\n\t\t\t\t\t\t\t\t\t\t\t<form:fields>\n\t\t\t\t\t\t\t\t\t\t\t\t<Input\n\t\t\t\t\t\t\t\t\t\t\t\t\tid="EmployeeResponsibleRel.account2FullNameInput"\n\t\t\t\t\t\t\t\t\t\t\t\t\tvalue="{EmployeeResponsibleRel/account2FullName}"\n\t\t\t\t\t\t\t\t\t\t\t\t\ttype="Text"\n\t\t\t\t\t\t\t\t\t\t\t\t\tplaceholder=""\n\t\t\t\t\t\t\t\t\t\t\t\t\tenabled="true"\n\t\t\t\t\t\t\t\t\t\t\t\t\teditable="true"\n\t\t\t\t\t\t\t\t\t\t\t\t\tshowValueHelp="true"\n\t\t\t\t\t\t\t\t\t\t\t\t\tvalueHelpOnly="false"\n\t\t\t\t\t\t\t\t\t\t\t\t\tvalueHelpRequest="onEmployeeResponsibleValueHelpSelected"\n\t\t\t\t\t\t\t\t\t\t\t\t\tshowSuggestion = "true"\n\t\t\t\t\t\t\t\t\t\t\t\t\tsuggestionItemSelected = "onEmployeeResponsibleSuggestItemSelected"\n\t\t\t\t\t\t\t\t\t\t\t\t\tliveChange="onEmployeeResponsibleInputFieldChanged"\n\t\t\t\t\t\t\t\t\t\t\t\t\tvisible="true"/>\n\t\t\t\t\t\t\t\t\t\t\t</form:fields>\n\t\t\t\t\t\t\t\t\t\t</form:FormElement>\n\t\t\t\t\t\t\t\t\t\t<form:FormElement id="EmployeeResponsibleRel.account2ID">\n\t\t\t\t\t\t\t\t\t\t\t<form:fields>\n\t\t\t\t\t\t\t\t\t\t\t\t<Input id="EmployeeResponsibleRel.account2IDInput" value="{EmployeeResponsibleRel/account2ID}" type="Text" visible="false"/>\n\t\t\t\t\t\t\t\t\t\t\t</form:fields>\n\t\t\t\t\t\t\t\t\t\t</form:FormElement>\n\t\t\t\t\t\t\t\t\t</form:formElements>\n\t\t\t\t\t\t\t\t</form:FormContainer>\n\n\t\t\t\t\t\t\t\t<!-- Extends the form in the middle -->\n\t\t\t\t\t\t\t\t<core:ExtensionPoint name="extEditFormMiddle"/>\n\t\t\t\t\t\t\t</form:formContainers>\n\t\t\t\t\t\t</form:Form>\n\t\t\t\t\t\t<form:Form class="sapUiFormEdit sapUiFormEdit-CTX">\n\t\t\t\t\t\t\t<form:layout>\n\t\t\t\t\t\t\t\t<form:ResponsiveGridLayout xmlns:form="sap.ui.layout.form"\n\t\t\t\t\t\t\t\t\tlabelSpanL="4"\n\t\t\t\t\t\t\t\t\tlabelSpanM="4"\n\t\t\t\t\t\t\t\t\temptySpanL="3"\n\t\t\t\t\t\t\t\t\temptySpanM="2"\n\t\t\t\t\t\t\t\t\tcolumnsL="1"\n\t\t\t\t\t\t\t\t\tcolumnsM="1"\n\t\t\t\t\t\t\t\t\tclass="editableForm">\n\t\t\t\t\t\t\t\t</form:ResponsiveGridLayout>\n\t\t\t\t\t\t\t</form:layout>\n\t\t\t\t\t\t\t<form:formContainers>\n\t\t\t\t\t\t\t\t<form:FormContainer title="{i18n>ADDRESS}" id="editFormAddress" visible="false">\n\t\t\t\t\t\t\t\t\t<form:formElements>\n\t\t\t\t\t\t\t\t\t\t<core:Fragment id="addressFragment" fragmentName="cus.crm.myaccounts.view.maintain.address.DefaultAddress" type="XML" />\n\t\t\t\t\t\t\t\t\t\t<!-- Extends the address block in the form -->\n\t\t\t\t\t\t\t\t\t\t<core:ExtensionPoint name="extEditFormAddress"/>\n\t\t\t\t\t\t\t\t\t</form:formElements>\n\t\t\t\t\t\t\t\t</form:FormContainer>\n\n\t\t\t\t\t\t\t\t<form:FormContainer title="{i18n>ADDRESS}" id="editFormAddressUS" visible="false">\n\t\t\t\t\t\t\t\t\t<form:formElements>\n\t\t\t\t\t\t\t\t\t\t<core:Fragment id="addressFragmentUS" fragmentName="cus.crm.myaccounts.view.maintain.address.USAddress" type="XML" />\n\t\t\t\t\t\t\t\t\t</form:formElements>\n\t\t\t\t\t\t\t\t</form:FormContainer>\n\n\t\t\t\t\t\t\t\t<form:FormContainer title="{i18n>ADDRESS}" id="editFormAddressJP" visible="false">\n\t\t\t\t\t\t\t\t\t<form:formElements>\n\t\t\t\t\t\t\t\t\t\t<core:Fragment id="addressFragmentJP" fragmentName="cus.crm.myaccounts.view.maintain.address.JPAddress" type="XML" />\n\t\t\t\t\t\t\t\t\t</form:formElements>\n\t\t\t\t\t\t\t\t</form:FormContainer>\n\n\t\t\t\t\t\t\t\t<form:FormContainer title="{i18n>ADDRESS}" id="editFormAddressGB" visible="false">\n\t\t\t\t\t\t\t\t\t<form:formElements>\n\t\t\t\t\t\t\t\t\t\t<core:Fragment id="addressFragmentGB" fragmentName="cus.crm.myaccounts.view.maintain.address.GBAddress" type="XML" />\n\t\t\t\t\t\t\t\t\t</form:formElements>\n\t\t\t\t\t\t\t\t</form:FormContainer>\n\n\t\t\t\t\t\t\t\t<!-- Extends the form at the bottom -->\n\t\t\t\t\t\t\t\t<core:ExtensionPoint name="extEditFormBottom"/>\n\t\t\t\t\t\t\t</form:formContainers>\n\t\t\t\t\t\t</form:Form>\n\t\t\t\t\t</core:ExtensionPoint>\n\t\t\t\t</layout:content>\n\t\t\t</layout:Grid>\n\t\t</content>\n\t</Page>\n</core:View>\n',
	"cus/crm/myaccounts/view/maintain/GeneralDataEditCompany.fragment.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:FragmentDefinition\n  xmlns="sap.m"\n  xmlns:core="sap.ui.core"\n  xmlns:form="sap.ui.layout.form">\n\t\n\t<form:FormElement id="name1" visible="{parts:[\'category\', \'constants>/accountCategoryPerson\'], formatter: \'cus.crm.myaccounts.util.formatter.isUnequal\'}">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>COMPANY_NAME1}" id="name1Label" width="100%" required="true" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{name1}" maxLength="40" id="name1Input" liveChange="onName1InputFieldChanged"/>\n\t\t</form:fields>\n\t</form:FormElement>\n\t<form:FormElement id="name2" visible="{parts:[\'category\', \'constants>/accountCategoryPerson\'], formatter: \'cus.crm.myaccounts.util.formatter.isUnequal\'}">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>COMPANY_NAME2}" id="name2Label" width="100%"/>\n  \t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{name2}" maxLength="40" id="name2Input" liveChange="onInputFieldChanged"/>\n   \t\t</form:fields>\n\t</form:FormElement>\n\n\t<!-- Extends the form -->\n   \t<core:ExtensionPoint name="extEditFormCompany"/>\n   \n</core:FragmentDefinition>',
	"cus/crm/myaccounts/view/maintain/GeneralDataEditPerson.fragment.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:FragmentDefinition\n  xmlns="sap.m"\n  xmlns:core="sap.ui.core"\n  xmlns:layout="sap.ui.layout"\n  xmlns:form="sap.ui.layout.form">\n  \n\t<form:FormElement id="title" visible="{parts:[\'category\', \'constants>/accountCategoryPerson\'], formatter: \'cus.crm.myaccounts.util.formatter.isEqual\'}">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>TITLE}" id="titleLabel" width="100%" />\n   \t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Select \n\t\t\t\tvalue="{titleID}" \n\t\t\t\tmaxLength="40" \n\t\t\t\tid="titleIDInput" \n\t\t\t\tchange="onInputFieldChanged" \n\t\t\t\titems="{path:\'Customizing>/TitleCustomizing\', filters:[{path:\'person\', operator: \'EQ\', value1: \'X\' }] }" \n\t\t\t\tselectedKey="{titleID}">\n\t\t   \t\t<core:Item key="{Customizing>title}" text="{Customizing>titleDescription}"/>\n\t\t   \t</Select>\n   \t\t</form:fields>\n\t</form:FormElement>\n\t\n\t<form:FormElement id="academicTitle" visible="{parts:[\'category\', \'constants>/accountCategoryPerson\'], formatter: \'cus.crm.myaccounts.util.formatter.isEqual\'}">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>ACADEMIC_TITLE}" id="academicTitleLabel" width="100%"/>\n   \t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Select value="{academicTitleID}" maxLength="40" id="academicTitleIDInput" change="onInputFieldChanged" items="{Customizing>/AcademicTitleCustomizing}" selectedKey="{academicTitleID}">\n\t\t       \t<core:Item key="{Customizing>title}" text="{Customizing>titleDescription}"/>\n\t\t   \t</Select>\n   \t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="name2" visible="{parts:[\'category\', \'constants>/accountCategoryPerson\'], formatter: \'cus.crm.myaccounts.util.formatter.isEqual\'}">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>FIRST_NAME}" id="name2Label" width="100%" />\n   \t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{name2}" maxLength="40" id="name2Input" liveChange="onInputFieldChanged" />\n   \t\t</form:fields>\n\t</form:FormElement>  \n  \t\n\t<form:FormElement id="name1" visible="{parts:[\'category\', \'constants>/accountCategoryPerson\'], formatter: \'cus.crm.myaccounts.util.formatter.isEqual\'}">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>LAST_NAME}" id="name1Label" width="100%" required="true" />\n   \t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{name1}" maxLength="40" id="name1Input" liveChange="onName1InputFieldChanged" />\n   \t\t</form:fields>\n\t</form:FormElement>   \n\t\n\t<form:FormElement id="birthDate" visible="{parts:[\'category\', \'constants>/accountCategoryPerson\'], formatter: \'cus.crm.myaccounts.util.formatter.isEqual\'}">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>BIRTHDAY}" id="birthDateLabel" width="100%" />\n   \t\t</form:label>\n\t\t<form:fields>\n\t\t\t<DatePicker value="{path:\'birthDate\', type:\'sap.ui.model.type.Date\', formatOptions: { style: \'medium\'}}" id="birthDateInput" change="onInputFieldChanged" displayFormat="medium"/>\n   \t\t</form:fields>\n\t</form:FormElement> \t                     \t\n\n\t<!-- Extends the form -->\n   \t<core:ExtensionPoint name="extEditFormPerson"/>\n   \t\n</core:FragmentDefinition>',
	"cus/crm/myaccounts/view/maintain/ValueHelpCountry.fragment.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:FragmentDefinition\n  xmlns="sap.m"\n  xmlns:core="sap.ui.core"\n  xmlns:layout="sap.ui.layout">\n  \n  <SelectDialog\n  \ttitle="{i18n>COUNTRY}"\n    class="sapUiPopupWithPadding"\n    items="{/CountryCustomizing}"\n    liveChange="onCountryValueHelpSearch"\n    confirm="onCountryValueHelpClose"\n    cancel="onCountryValueHelpCancel">\n    <StandardListItem\n      title="{country}"\n      />\n  </SelectDialog>\n   \n</core:FragmentDefinition>',
	"cus/crm/myaccounts/view/maintain/ValueHelpEmployeeResponsible.fragment.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:FragmentDefinition\n  xmlns="sap.m"\n  xmlns:core="sap.ui.core"\n  xmlns:layout="sap.ui.layout">\n  \n  <SelectDialog\n  \ttitle="{i18n>EMPLOYEE_RESPONSIBLE}"\n    class="sapUiPopupWithPadding"\n    items="{/EmployeeCollection}"    \n    liveChange="onEmployeeResponsibleValueHelpSearch"\n    confirm="onEmployeeResponsibleValueHelpClose"\n    cancel="onEmployeeResponsibleValueHelpCancel">\n    <StandardListItem\n      title="{fullName}"\n      />\n  </SelectDialog>\n   \n</core:FragmentDefinition>',
	"cus/crm/myaccounts/view/maintain/ValueHelpMarketingAttribute.fragment.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:FragmentDefinition\n  xmlns="sap.m"\n  xmlns:core="sap.ui.core"\n  xmlns:layout="sap.ui.layout">\n  \n  <SelectDialog\n  \ttitle="{i18n>MARKETINGATTRIBUTES}"\n  \tnoDataText="{i18n>NO_DATA_TEXT}"\n    class="sapUiPopupWithPadding"\n    liveChange="onMarketingAttributeValueHelpSearch"\n    confirm="onMarketingAttributeValueHelpClose"\n    cancel="onMarketingAttributeValueHelpCancel">\n    <StandardListItem\n      title="{attribute}"\n    />\n  </SelectDialog>\n</core:FragmentDefinition>',
	"cus/crm/myaccounts/view/maintain/ValueHelpMarketingAttributeSet.fragment.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:FragmentDefinition\n  xmlns="sap.m"\n  xmlns:core="sap.ui.core"\n  xmlns:layout="sap.ui.layout">\n  \n  <SelectDialog\n  \ttitle="{i18n>ATTRIBUTESET}"\n  \tnoDataText="{i18n>NO_DATA_TEXT}"\n    class="sapUiPopupWithPadding"\n    liveChange="onMarketingAttributeSetValueHelpSearch"\n    confirm="onMarketingAttributeSetValueHelpClose"\n    cancel="onMarketingAttributeSetValueHelpCancel">\n    <StandardListItem\n \t\ttitle="{attributeSet}"\n    />\n  </SelectDialog>\n   \n</core:FragmentDefinition>',
	"cus/crm/myaccounts/view/maintain/ValueHelpRegion.fragment.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:FragmentDefinition\n  xmlns="sap.m"\n  xmlns:core="sap.ui.core"\n  xmlns:layout="sap.ui.layout">\n  \n  <SelectDialog\n  \ttitle="{i18n>REGION}"\n    class="sapUiPopupWithPadding"\n    items="{/RegionCustomizing}"\n    liveChange="onRegionValueHelpSearch"\n    confirm="onRegionValueHelpClose"\n    cancel="onRegionValueHelpCancel">\n    <StandardListItem\n      title="{region}"\n      />\n  </SelectDialog>\n   \n</core:FragmentDefinition>',
	"cus/crm/myaccounts/view/maintain/address/DefaultAddress.fragment.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:FragmentDefinition\n\txmlns="sap.m"\n\txmlns:core="sap.ui.core"\n\txmlns:form="sap.ui.layout.form"\n\txmlns:layout="sap.ui.layout">\n\n\t<form:FormElement id="MainAddress.country">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>COUNTRY}" id="MainAddress.countryLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input\n\t\t        id="MainAddress.countryInput"\n\t\t        value="{MainAddress/country}"\n\t\t        type="Text"\n\t\t        placeholder=""\n\t\t        enabled="true"\n\t\t        editable="true"\n\t\t        showValueHelp="true"\n\t\t        valueHelpOnly="false"\n\t\t        valueHelpRequest="onCountryValueHelpSelected"\n\t\t        showSuggestion = "true"\n\t\t        suggest="onCountrySuggest"\n\t\t\t    suggestionItemSelected = "onCountrySuggestItemSelected"\n\t\t\t    liveChange="onCountryInputFieldChanged"/>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.countryID">\n\t\t<form:fields>\n\t\t\t<Input id="MainAddress.countryIDInput" value="{MainAddress/countryID}" type="Text" visible="false"/>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.region">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>REGION}" id="MainAddress.regionLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input\n\t\t        id="MainAddress.regionInput"\n\t\t        value="{MainAddress/region}"\n\t\t        type="Text"\n\t\t        placeholder=""\n\t\t        editable="true"\n\t\t        showValueHelp="true"\n\t\t        valueHelpOnly="false"\n\t\t        valueHelpRequest="onRegionValueHelpSelected"\n\t\t        showSuggestion = "true"\n\t\t        suggest="onRegionSuggest"\n\t\t        suggestionItemSelected = "onRegionSuggestItemSelected"\n\t\t        liveChange="onRegionInputFieldChanged"/>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.regionID">\n\t\t<form:fields>\n\t\t\t<Input id="MainAddress.regionIDInput" value="{MainAddress/regionID}" type="Text" visible="false"/>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.street">\n\t\t<form:label>\n\t\t\t<Label text="{parts:[{path:\'i18n>STREET\'},{path:\'i18n>HOUSE_NUMBER\'}], formatter: \'cus.crm.myaccounts.util.formatter.sleshSeparator\'}" id="MainAddress.streetLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/street}" maxLength="40" id="MainAddress.streetInput" liveChange="onInputFieldChanged">\n\t\t\t\t<layoutData>\n\t\t\t\t\t<layout:GridData span="L4 M4 S9"/>\n\t\t\t\t</layoutData>\n\t\t\t</Input>\n\t\t\t<Input value="{MainAddress/houseNumber}" maxLength="40" id="MainAddress.houseNumberInput" liveChange="onInputFieldChanged">\n\t\t\t\t<layoutData>\n\t\t\t\t\t<layout:GridData span="L1 M2 S3"/>\n\t\t\t\t</layoutData>\n\t\t\t</Input>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.postcode">\n\t\t<form:label>\n\t\t\t<Label text="{parts:[{path:\'i18n>POSTAL_CODE\'},{path:\'i18n>CITY\'}], formatter: \'cus.crm.myaccounts.util.formatter.sleshSeparator\'}" id="MainAddress.postcodeLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/postcode}" maxLength="40" id="MainAddress.postcodeInput" liveChange="onInputFieldChanged">\n\t\t\t\t<layoutData>\n\t\t\t\t\t<layout:GridData span="L1 M2 S5"/>\n\t\t\t\t</layoutData>\n\t\t\t</Input>\n\t\t\t<Input value="{MainAddress/city}" maxLength="40" id="MainAddress.cityInput" liveChange="onInputFieldChanged">\n\t\t\t\t<layoutData>\n\t\t\t\t\t<layout:GridData span="L4 M4 S7"/>\n\t\t\t\t</layoutData>\n\t\t\t</Input>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.mobilePhone" visible="{parts:[\'category\', \'constants>/accountCategoryPerson\'], formatter: \'cus.crm.myaccounts.util.formatter.isEqual\'}">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>MOBILE}" id="MainAddress.mobilePhoneLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/mobilePhone}" maxLength="40" id="MainAddress.mobilePhoneInput" liveChange="onInputFieldChanged"/>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.phone">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>PHONE}" id="MainAddress.phoneLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/phone}" maxLength="40" id="MainAddress.phoneInput" liveChange="onInputFieldChanged" />\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.email">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>EMAIL}" id="MainAddress.emailLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/email}" maxLength="40" id="MainAddress.emailInput" liveChange="onInputFieldChanged" />\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.website">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>WEBSITE}" id="MainAddress.websiteLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/website}" maxLength="40" id="MainAddress.websiteInput" liveChange="onInputFieldChanged" />\n\t\t</form:fields>\n\t</form:FormElement>\n\n</core:FragmentDefinition>\n',
	"cus/crm/myaccounts/view/maintain/address/GBAddress.fragment.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:FragmentDefinition\n\txmlns="sap.m"\n\txmlns:core="sap.ui.core"\n\txmlns:form="sap.ui.layout.form"\n\txmlns:layout="sap.ui.layout">\n\n\t<form:FormElement id="MainAddress.country">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>COUNTRY}" id="MainAddress.countryLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input\n\t\t\t\tid="MainAddress.countryInput"\n\t\t\t\tvalue="{MainAddress/country}"\n\t\t\t\ttype="Text"\n\t\t\t\tplaceholder=""\n\t\t\t\tenabled="true"\n\t\t\t\teditable="true"\n\t\t\t\tshowValueHelp="true"\n\t\t\t\tvalueHelpOnly="false"\n\t\t\t\tvalueHelpRequest="onCountryValueHelpSelected"\n\t\t\t\tshowSuggestion = "true"\n\t\t\t\tsuggest="onCountrySuggest"\n\t\t\t\tsuggestionItemSelected = "onCountrySuggestItemSelected"\n\t\t\t\tliveChange="onCountryInputFieldChanged"/>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.countryID">\n\t\t<form:fields>\n\t\t\t<Input id="MainAddress.countryIDInput" value="{MainAddress/countryID}" type="Text" visible="false"/>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.street">\n\t\t<form:label>\n\t\t\t<Label text="{parts:[{path:\'i18n>HOUSE_NUMBER\'},{path:\'i18n>STREET\'}], formatter: \'cus.crm.myaccounts.util.formatter.sleshSeparator\'}" id="MainAddress.streetLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/houseNumber}" maxLength="40" id="MainAddress.houseNumberInput" liveChange="onInputFieldChanged">\n\t\t\t\t<layoutData>\n\t\t\t\t\t<layout:GridData span="L1 M2 S3"/>\n\t\t\t\t</layoutData>\n\t\t\t</Input>\n\t\t\t<Input value="{MainAddress/street}" maxLength="40" id="MainAddress.streetInput" liveChange="onInputFieldChanged">\n\t\t\t\t<layoutData>\n\t\t\t\t\t<layout:GridData span="L4 M4 S9"/>\n\t\t\t\t</layoutData>\n\t\t\t</Input>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.city">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>CITY}" id="MainAddress.cityLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/city}" maxLength="40" id="MainAddress.cityInput" liveChange="onInputFieldChanged">\n\t\t\t\t<layoutData>\n\t\t\t\t\t<layout:GridData span="L5 M5 S7"/>\n\t\t\t\t</layoutData>\n\t\t\t</Input>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.region">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>REGION}" id="MainAddress.regionLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input\n\t\t\t\tid="MainAddress.regionInput"\n\t\t\t\tvalue="{MainAddress/region}"\n\t\t\t\ttype="Text"\n\t\t\t\tplaceholder=""\n\t\t\t\teditable="true"\n\t\t\t\tshowValueHelp="true"\n\t\t\t\tvalueHelpOnly="false"\n\t\t\t\tvalueHelpRequest="onRegionValueHelpSelected"\n\t\t\t\tshowSuggestion = "true"\n\t\t\t\tsuggest="onRegionSuggest"\n\t\t\t\tsuggestionItemSelected = "onRegionSuggestItemSelected"\n\t\t\t\tliveChange="onRegionInputFieldChanged"/>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.regionID">\n\t\t<form:fields>\n\t\t\t<Input id="MainAddress.regionIDInput" value="{MainAddress/regionID}" type="Text" visible="false"/>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.postcode">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>POSTAL_CODE}" id="MainAddress.postcodeLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/postcode}" maxLength="40" id="MainAddress.postcodeInput" liveChange="onInputFieldChanged">\n\t\t\t\t<layoutData>\n\t\t\t\t\t<layout:GridData span="L5 M5 S5"/>\n\t\t\t\t</layoutData>\n\t\t\t</Input>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.mobilePhone" visible="{parts:[\'category\', \'constants>/accountCategoryPerson\'], formatter: \'cus.crm.myaccounts.util.formatter.isEqual\'}">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>MOBILE}" id="MainAddress.mobilePhoneLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/mobilePhone}" maxLength="40" id="MainAddress.mobilePhoneInput" liveChange="onInputFieldChanged"/>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.phone">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>PHONE}" id="MainAddress.phoneLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/phone}" maxLength="40" id="MainAddress.phoneInput" liveChange="onInputFieldChanged" />\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.email">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>EMAIL}" id="MainAddress.emailLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/email}" maxLength="40" id="MainAddress.emailInput" liveChange="onInputFieldChanged" />\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.website">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>WEBSITE}" id="MainAddress.websiteLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/website}" maxLength="40" id="MainAddress.websiteInput" liveChange="onInputFieldChanged" />\n\t\t</form:fields>\n\t</form:FormElement>\n\n</core:FragmentDefinition>',
	"cus/crm/myaccounts/view/maintain/address/JPAddress.fragment.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:FragmentDefinition\n\txmlns="sap.m"\n\txmlns:core="sap.ui.core"\n\txmlns:form="sap.ui.layout.form"\n\txmlns:layout="sap.ui.layout">\n\n\t<form:FormElement id="MainAddress.country">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>COUNTRY}" id="MainAddress.countryLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input\n\t\t\t\tid="MainAddress.countryInput"\n\t\t\t\tvalue="{MainAddress/country}"\n\t\t\t\ttype="Text"\n\t\t\t\tplaceholder=""\n\t\t\t\tenabled="true"\n\t\t\t\teditable="true"\n\t\t\t\tshowValueHelp="true"\n\t\t\t\tvalueHelpOnly="false"\n\t\t\t\tvalueHelpRequest="onCountryValueHelpSelected"\n\t\t\t\tshowSuggestion = "true"\n\t\t\t\tsuggest="onCountrySuggest"\n\t\t\t\tsuggestionItemSelected = "onCountrySuggestItemSelected"\n\t\t\t\tliveChange="onCountryInputFieldChanged"/>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement  id="MainAddress.countryID">\n\t\t<form:fields>\n\t\t\t<Input id="MainAddress.countryIDInput" value="{MainAddress/countryID}" type="Text" visible="false"/>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.street">\n\t\t<form:label>\n\t\t\t<Label text="{parts:[{path:\'i18n>HOUSE_NUMBER\'},{path:\'i18n>STREET\'}], formatter: \'cus.crm.myaccounts.util.formatter.sleshSeparator\'}" id="MainAddress.streetLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/houseNumber}" maxLength="40" id="MainAddress.houseNumberInput" liveChange="onInputFieldChanged">\n\t\t\t\t<layoutData>\n\t\t\t\t\t<layout:GridData span="L1 M2 S3"/>\n\t\t\t\t</layoutData>\n\t\t\t</Input>\n\t\t\t<Input value="{MainAddress/street}" maxLength="40" id="MainAddress.streetInput" liveChange="onInputFieldChanged">\n\t\t\t\t<layoutData>\n\t\t\t\t\t<layout:GridData span="L4 M4 S9"/>\n\t\t\t\t</layoutData>\n\t\t\t</Input>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.city">\n\t\t<form:label>\n\t\t\t<Label text="{parts:[{path:\'i18n>CITY\'},{path:\'i18n>REGION\'}], formatter: \'cus.crm.myaccounts.util.formatter.sleshSeparator\'}" id="MainAddress.cityLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/city}" maxLength="40" id="MainAddress.cityInput" liveChange="onInputFieldChanged">\n\t\t\t\t<layoutData>\n\t\t\t\t\t<layout:GridData span="L3 M3 S7"/>\n\t\t\t\t</layoutData>\n\t\t\t</Input>\n\t\t\t<Input\n\t\t\t\tid="MainAddress.regionInput"\n\t\t\t\tvalue="{MainAddress/region}"\n\t\t\t\ttype="Text"\n\t\t\t\tplaceholder=""\n\t\t\t\teditable="true"\n\t\t\t\tshowValueHelp="true"\n\t\t\t\tvalueHelpOnly="false"\n\t\t\t\tvalueHelpRequest="onRegionValueHelpSelected"\n\t\t\t\tshowSuggestion = "true"\n\t\t\t\tsuggest="onRegionSuggest"\n\t\t\t\tsuggestionItemSelected = "onRegionSuggestItemSelected"\n\t\t\t\tliveChange="onRegionInputFieldChanged"/>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.regionID">\n\t\t<form:fields>\n\t\t\t<Input id="MainAddress.regionIDInput" value="{MainAddress/regionID}" type="Text" visible="false"/>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.postcode">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>POSTAL_CODE}" id="MainAddress.postcodeLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/postcode}" maxLength="40" id="MainAddress.postcodeInput" liveChange="onInputFieldChanged">\n\t\t\t\t<layoutData>\n\t\t\t\t\t<layout:GridData span="L5 M5 S5"/>\n\t\t\t\t</layoutData>\n\t\t\t</Input>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.mobile" visible="{parts:[\'category\', \'constants>/accountCategoryPerson\'], formatter: \'cus.crm.myaccounts.util.formatter.isEqual\'}">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>MOBILE}" id="MainAddress.mobilePhoneLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/mobilePhone}" maxLength="40" id="MainAddress.mobilePhoneInput" liveChange="onInputFieldChanged"/>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.phone">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>PHONE}" id="MainAddress.phoneLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/phone}" maxLength="40" id="MainAddress.phoneInput" liveChange="onInputFieldChanged" />\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.email">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>EMAIL}" id="MainAddress.emailLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/email}" maxLength="40" id="MainAddress.emailInput" liveChange="onInputFieldChanged" />\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.website">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>WEBSITE}" id="MainAddress.websiteLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/website}" maxLength="40" id="MainAddress.websiteInput" liveChange="onInputFieldChanged" />\n\t\t</form:fields>\n\t</form:FormElement>\n\n</core:FragmentDefinition>\n',
	"cus/crm/myaccounts/view/maintain/address/USAddress.fragment.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:FragmentDefinition\n\txmlns="sap.m"\n\txmlns:core="sap.ui.core"\n\txmlns:form="sap.ui.layout.form"\n\txmlns:layout="sap.ui.layout">\n\n\t<form:FormElement id="MainAddress.country">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>COUNTRY}" id="MainAddress.countryLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input\n\t\t\t\tid="MainAddress.countryInput"\n\t\t\t\tvalue="{MainAddress/country}"\n\t\t\t\ttype="Text"\n\t\t\t\tplaceholder=""\n\t\t\t\tenabled="true"\n\t\t\t\teditable="true"\n\t\t\t\tshowValueHelp="true"\n\t\t\t\tvalueHelpOnly="false"\n\t\t\t\tvalueHelpRequest="onCountryValueHelpSelected"\n\t\t\t\tshowSuggestion = "true"\n\t\t\t\tsuggest="onCountrySuggest"\n\t\t\t\tsuggestionItemSelected = "onCountrySuggestItemSelected"\n\t\t\t\tliveChange="onCountryInputFieldChanged"/>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.countryID">\n\t\t<form:fields>\n\t\t\t<Input id="MainAddress.countryIDInput" value="{MainAddress/countryID}" type="Text" visible="false"/>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.street">\n\t\t<form:label>\n\t\t\t<Label text="{parts:[{path:\'i18n>HOUSE_NUMBER\'},{path:\'i18n>STREET\'}], formatter: \'cus.crm.myaccounts.util.formatter.sleshSeparator\'}" id="MainAddress.streetLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/houseNumber}" maxLength="40" id="MainAddress.houseNumberInput" liveChange="onInputFieldChanged">\n\t\t\t\t<layoutData>\n\t\t\t\t\t<layout:GridData span="L1 M2 S3"/>\n\t\t\t\t</layoutData>\n\t\t\t</Input>\n\t\t\t<Input value="{MainAddress/street}" maxLength="40" id="MainAddress.streetInput" liveChange="onInputFieldChanged">\n\t\t\t\t<layoutData>\n\t\t\t\t\t<layout:GridData span="L4 M4 S9"/>\n\t\t\t\t</layoutData>\n\t\t\t</Input>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.city">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>CITY}" id="MainAddress.cityLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/city}" maxLength="40" id="MainAddress.cityInput" liveChange="onInputFieldChanged">\n\t\t\t\t<layoutData>\n\t\t\t\t\t<layout:GridData span="L5 M5 S7"/>\n\t\t\t\t</layoutData>\n\t\t\t</Input>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.region">\n\t\t<form:label>\n\t\t\t<Label text="{parts:[{path:\'i18n>REGION\'},{path:\'i18n>POSTAL_CODE\'}], formatter: \'cus.crm.myaccounts.util.formatter.sleshSeparator\'}" id="MainAddress.postcodeLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input\n\t\t\t\tid="MainAddress.regionInput"\n\t\t\t\tvalue="{MainAddress/region}"\n\t\t\t\ttype="Text"\n\t\t\t\tplaceholder=""\n\t\t\t\teditable="true"\n\t\t\t\tshowValueHelp="true"\n\t\t\t\tvalueHelpOnly="false"\n\t\t\t\tvalueHelpRequest="onRegionValueHelpSelected"\n\t\t\t\tshowSuggestion = "true"\n\t\t\t\tsuggest="onRegionSuggest"\n\t\t\t\tsuggestionItemSelected = "onRegionSuggestItemSelected"\n\t\t\t\tliveChange="onRegionInputFieldChanged"/>\n\t\t\t<Input value="{MainAddress/postcode}" maxLength="40" id="MainAddress.postcodeInput" liveChange="onInputFieldChanged">\n\t\t\t\t<layoutData>\n\t\t\t\t\t<layout:GridData span="L1 M2 S5"/>\n\t\t\t\t</layoutData>\n\t\t\t</Input>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.regionID">\n\t\t<form:fields>\n\t\t\t<Input id="MainAddress.regionIDInput" value="{MainAddress/regionID}" type="Text" visible="false"/>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.mobilePhone" visible="{parts:[\'category\', \'constants>/accountCategoryPerson\'], formatter: \'cus.crm.myaccounts.util.formatter.isEqual\'}">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>MOBILE}" id="MainAddress.mobilePhoneLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/mobilePhone}" maxLength="40" id="MainAddress.mobilePhoneInput" liveChange="onInputFieldChanged"/>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.phone">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>PHONE}" id="MainAddress.phoneLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/phone}" maxLength="40" id="MainAddress.phoneInput" liveChange="onInputFieldChanged" />\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.email">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>EMAIL}" id="MainAddress.emailLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/email}" maxLength="40" id="MainAddress.emailInput" liveChange="onInputFieldChanged" />\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.website">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>WEBSITE}" id="MainAddress.websiteLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/website}" maxLength="40" id="MainAddress.websiteInput" liveChange="onInputFieldChanged" />\n\t\t</form:fields>\n\t</form:FormElement>\n\n</core:FragmentDefinition>\n',
	"cus/crm/myaccounts/view/overview/Appointments.controller.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("cus.crm.myaccounts.util.formatter");
jQuery.sap.require("cus.crm.myaccounts.util.Util");
sap.ui.controller("cus.crm.myaccounts.view.overview.Appointments", {

/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf view.overview.Appointments
*/
	onInit: function() {
		//add Filters and Sorters to the List
		var oAppointmentsList = this.byId("AppointmentsList");
		var oBindingInfo = oAppointmentsList.getBindingInfo("items");
		oBindingInfo.sorter = this._getListSorter();
		oBindingInfo.filters = [];
		oBindingInfo.groupHeaderFactory = this._getHeaderGroupHandler();
	},

	getList: function() {
		return this.byId("AppointmentsList");
	},

	onSubViewLiveSearch: function(searchString) {
		var oBinding = this.getList().getBinding("items");
		var aFilters = [];
		if(searchString !== "")
			aFilters.push(new sap.ui.model.Filter("Description", sap.ui.model.FilterOperator.Contains, searchString));
		if(oBinding)
			oBinding.filter(aFilters);
	},

	_navigateToAppointment: function(oEvent) {
		if(sap.ushell && sap.ushell.Container) {
			var fgetService = sap.ushell.Container.getService;
			if(fgetService) {
				var oCrossAppNavigator = fgetService("CrossApplicationNavigation");
				
				if(oCrossAppNavigator) {
					oCrossAppNavigator.toExternal({
						target : {
							semanticObject : "Appointment",
							action : "myAppointments&/appointment/"+oEvent.getSource().getBindingContext().getProperty("Guid")
						}
					});
				}
			}
		}
	},

	_getListSorter: function() {
		var that = this;
		return new sap.ui.model.Sorter("FromDate", false, function(oContext) {
			var date = new Date(oContext.getProperty("FromDate").getTime());
			var dateEnd = new Date(oContext.getProperty("ToDate").getTime());
			
			// Try All Day Stuff
			var allDayFlag = oContext.getProperty("AllDay");
			
			if (allDayFlag) {
				// If true, then adjust the startdate according to the offsets, because all day comes from back end
				// with datetime stamp at GMT				
				var fromDatetimeOffset = date.getTimezoneOffset();
				var toDatetimeOffset = dateEnd.getTimezoneOffset();
				
				date.setTime( date.getTime() + fromDatetimeOffset * 60 * 1000 );
				dateEnd.setTime( dateEnd.getTime() + toDatetimeOffset * 60 * 1000 );			
			}
			
			var oDateFormatter = sap.ui.core.format.DateFormat.getDateInstance({
				style : "full"
			});

			return {
				key : that.getDateString(date),
				text : oDateFormatter.format(date)
			};
		});
	},
	
	_getHeaderGroupHandler: function(){
		var that = this;
		return function(oGroup) {
			var oHeader = new sap.m.GroupHeaderListItem({
				title : oGroup.text
			});
			if (oGroup.key === that.getDateString(new Date())) {
				// add style for todays group header
				oHeader.addStyleClass("sapMLabelBold");
			}
			oHeader.setUpperCase(false);
			return oHeader;
		};
	},

	onStoreCurrentStateSupported: function(){
		return true;
	},
	
	onStoreCurrentState: function(storage){
		storage.contextPath = "";

		var oBus = sap.ui.getCore().getEventBus();

		// Listen to event that appointment has been changed and store
		// the context path of the appointment which has to be refreshed.
		storage.onRefreshContextPath = function(channelId, eventId, data){
			// In case no other event has happened before so that all appointments should
			// be refreshed, store the context path of the appointment which has to be refreshed.
			if(storage.action !== "refreshList") {
				storage.action = "refreshContextPath";
				storage.contextPath = data.contextPath.replace("/AppointmentSet", "AppointmentCollection");
			}
		};

		// Listen to events that appointment has been created directly or as follow up
		// and appointment has been deleted. In case such an event happens, refresh
		// the whole list of appointments.
		storage.onRefreshList = function(){
			storage.action = "refreshList";
		};

		oBus.subscribe("cus.crm.mycalendar", "appointmentChanged", storage.onRefreshContextPath, storage);
		oBus.subscribe("cus.crm.mycalendar", "followUpAppointmentCreated", storage.onRefreshList, storage);
		oBus.subscribe("cus.crm.mycalendar", "appointmentCreated", storage.onRefreshList, storage);
		oBus.subscribe("cus.crm.mycalendar", "appointmentDeleted", storage.onRefreshList, storage);

		// Remove all event listeners
		storage.onExit = function(){
			var oBus = sap.ui.getCore().getEventBus();
			oBus.unsubscribe("cus.crm.mycalendar", "appointmentChanged", storage.onRefreshContextPath, storage);
			oBus.unsubscribe("cus.crm.mycalendar", "followUpAppointmentCreated", storage.onRefreshList, storage);
			oBus.unsubscribe("cus.crm.mycalendar", "appointmentCreated", storage.onRefreshList, storage);
			oBus.unsubscribe("cus.crm.mycalendar", "appointmentDeleted", storage.onRefreshList, storage);
		};
	},

	onRestoreCurrentState: function(storage){
		if(storage.action === "refreshList") {
			this.getList().getBinding("items").refresh();
		} else if(storage.action === "refreshContextPath"){
			var oRefreshUIObject = cus.crm.myaccounts.util.Util.getRefreshUIObject(this.getView().getModel(), "/"+storage.contextPath);
			oRefreshUIObject.refresh();
		}
	},

	// ///////////////////////////////////////////////////////////////////////////////
	// conversion functions
	// ///////////////////////////////////////////////////////////////////////////////

	getDateString : function(d) {
		var sDay = d.getDate().toString();
		sDay = (sDay.length === 1) ? "0" + sDay : sDay;
		var sMonth = d.getMonth() + 1; // Months are zero based
		sMonth = sMonth.toString();
		sMonth = (sMonth.length === 1) ? "0" + sMonth : sMonth;
		var sYear = d.getFullYear();
		// Safari browser: The pattern yyyy-MM-dd isn't an officially supported format for Date constructor but yyyy/MM/dd
		var sDate = sYear + "/" + sMonth + "/" + sDay;
		return sDate;
	},

	// ///////////////////////////////////////////////////////////////////////////////
	// add appointment
	// ///////////////////////////////////////////////////////////////////////////////

	getFooterButtons: function(){
		var that = this;
		return [{
				sIcon: "sap-icon://add",
				sTooltip: cus.crm.myaccounts.util.Util.geti18NText("ADD_APPOINTMENT_TOOLTIP"),
				onBtnPressed: function () {
					that.onCreateAppointment();
				}
		}];
	},

	onCreateAppointment: function() {
		
		var oDataModel = this.getView().getModel();
		
		var that = this;
		var fnShowTransactionTypes = function(oResponses){
			
			var aProcessTypes;
			
			if(!that.processTypeModel) {
				aProcessTypes = oResponses["CustomizingAppointmentTypeCollection"];
				that.processTypeModel = new sap.ui.model.json.JSONModel();
				that.processTypeModel.setProperty("/TransactionTypeSet", aProcessTypes);
			} else {
				aProcessTypes = that.processTypeModel.getProperty("/TransactionTypeSet");
			}
	
			if (aProcessTypes.length === 1) {
				var processType = aProcessTypes[0].processTypeCode;
				that._navigateToCreationOfAppointment(processType);
			} else {
				that.oProcessTypeDialog = sap.ui.xmlfragment("cus.crm.myaccounts.view.overview.ProcessTypeDialog", that);
				that.oProcessTypeDialog.setModel(that.getView().getModel("i18n"), "i18n");
				that.oProcessTypeDialog.setModel(that.processTypeModel, "processTypes");
				that.oProcessTypeDialog.open();
			}
		};
		if(!that.processTypeModel)
			cus.crm.myaccounts.util.Util.sendBatchReadRequests(oDataModel, ["CustomizingAppointmentTypeCollection"], fnShowTransactionTypes);
		else
			fnShowTransactionTypes.call(that);
	},
		
		

	selectProcess: function(oEvent) {
		var processType = "";
		var oSelectedItem = oEvent.getParameter("selectedItem");
		if(oSelectedItem) {
			processType = oSelectedItem.data("ProcessTypeCode");
		}
		this._navigateToCreationOfAppointment(processType);
	},

	_navigateToCreationOfAppointment: function(processType) {
		if(sap.ushell && sap.ushell.Container) {
			var fgetService = sap.ushell.Container.getService;
			if(fgetService) {
				var oCrossAppNavigator = fgetService("CrossApplicationNavigation");
				if(oCrossAppNavigator) {
					var contextPath = this.getView().getBindingContext().sPath.substring(1);
					oCrossAppNavigator.toExternal({
						target: {
							semanticObject: "Appointment",
							action: "myAppointments&/newappointmentfromaccount/" + processType + "/" + contextPath
						}
					});
				}
			}
		}
	},

	searchProcess: function(oEvent) {
		var oItemsBinding = oEvent.getParameter("itemsBinding");
		var oItemsBindingFiltered;

		this.oProcessTypeDialog.setNoDataText(cus.crm.myaccounts.util.Util.geti18NText("LOADING_TEXT"));
		var searchString = oEvent.getParameter("value");
		if(searchString !== undefined) {
			// Apply the filter to the bound items, and the Select Dialog will update
			oItemsBindingFiltered = oItemsBinding.filter([new sap.ui.model.Filter("processTypeDescription", sap.ui.model.FilterOperator.Contains, searchString)]);

			if(oItemsBindingFiltered.getLength() === 0) {
				this.oProcessTypeDialog.setNoDataText(cus.crm.myaccounts.util.Util.geti18NText("NO_DATA_TEXT"));
			}
		}
	}

/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf view.overview.Appointments
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf view.overview.Appointments
*/
//	onAfterRendering: function() {
//
//	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf view.overview.Appointments
*/
//	onExit: function() {
//
//	}

});
},
	"cus/crm/myaccounts/view/overview/Appointments.view.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core" xmlns:mvc="sap.ui.core.mvc" xmlns="sap.m"\n\t\t\tcontrollerName="cus.crm.myaccounts.view.overview.Appointments" xmlns:html="http://www.w3.org/1999/xhtml"\n\t\t\txmlns:util="cus.crm.myaccounts.util">\n\t\t\t\n\t<List\n\t\titems="{Appointments}" \n\t\tid="AppointmentsList" \n        growing="true"\n        growingThreshold="10"\n        growingScrollToLoad="false">\n        \t<util:ApptListItem id="AppointmentsListItem" \n\t\t\t\ttitle="{Description}" \n\t\t\t\tpress="_navigateToAppointment" \n\t\t\t\tsubtitle="{parts:[ {path:\'Location\'}, {path:\'ContactTxt\'}], formatter: \'cus.crm.myaccounts.util.formatter.formatLocationContact\'}" \n\t\t\t\tlocation="{Location}" \n\t\t\t\ttime="{parts:[{path: \'FromDate\'},{path: \'AllDay\'}], formatter: \'cus.crm.myaccounts.util.formatter.formatTime\'}" \n\t\t\t\tduration="{parts:[ {path:\'FromDate\'}, {path:\'ToDate\'}], formatter: \'cus.crm.myaccounts.util.formatter.formatDuration\'}"\n\t\t\t\ttype="Inactive"  \n\t\t\t\tprivat="{PrivatFlag}"> \n\t\t\t\t\n\t\t\t\t<util:content>\n\t\t\t\t\t<ObjectStatus text="{StatusTxt}" state="{path:\'Status\', formatter:\'cus.crm.myaccounts.util.formatter.formatStatusText\'}"></ObjectStatus>\n\t\t\t\t</util:content>\n\t\t\t\t\n\t\t\t</util:ApptListItem>\n      </List>\n\n</core:View>\n',
	"cus/crm/myaccounts/view/overview/Attachments.controller.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.ui.message.message");
jQuery.sap.require("cus.crm.myaccounts.util.Util");
jQuery.sap.require("sap.m.MessageBox");

sap.ui.controller("cus.crm.myaccounts.view.overview.Attachments", {

	/**
	* @memberOf view.overview.Attachments
	*/
	onSubViewLiveSearch: function(searchString) {
		var oBinding = this.byId("fileupload").getBinding("items");
		if(oBinding) {
			var aFilters = [];
			if(searchString !== "") {
				aFilters.push(new sap.ui.model.Filter("name", sap.ui.model.FilterOperator.Contains, searchString));
			}
			oBinding.filter(aFilters);
		}
	},

	onChange: function(oEvent) {
		var oModel = this.getView().getModel();
		var oUploadCollection = oEvent.getSource();
		var filename = oEvent.getParameter("mParameters").files[0].name;
		var token = this.sToken || oModel.getSecurityToken();

		// Header Token
		var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({
			name : "x-csrf-token",
			value : token
		});
		oUploadCollection.addHeaderParameter(oCustomerHeaderToken);

		// Header Content-Disposition
		var oCustomerHeaderContentDisp = new sap.m.UploadCollectionParameter({
			name : "content-disposition",
			value : "inline; filename=\"" + encodeURIComponent(filename) + "\""
		});
		oUploadCollection.addHeaderParameter(oCustomerHeaderContentDisp);
	},

	onUploadFile: function() {
		this.byId("fileupload").getBinding("items").refresh();
	},

	onDeleteFile: function(oEvent) {
		var docID = oEvent.getParameter("documentId");
		var accountID = this.getView().getBindingContext().getObject().accountID;
		var contextPath = "AttachmentCollection(documentID='" + docID + "',documentClass='BDS_POC1',businessPartnerID='" + accountID + "')";
		var oModel = this.getView().getModel();
		var aBatchOperation = [oModel.createBatchOperation(contextPath, "DELETE", undefined, {sETag: "*"})];
		cus.crm.myaccounts.util.Util.sendBatchChangeOperations(oModel, aBatchOperation);
	},

	onRenameFile: function(oEvent) {
		var docID = oEvent.getParameter("documentId");
		var fileName = oEvent.getParameter("fileName");
		var accountID = this.getView().getBindingContext().getObject().accountID;
		var contextPath = "AttachmentCollection(documentID='" + docID + "',documentClass='BDS_POC1',businessPartnerID='" + accountID + "')";
		this._renameFile(contextPath, fileName, false);
	},

	_renameFile: function(contextPath, attachmentName, forceRename) {
		var eTagString = null;
		if(forceRename) {
			eTagString = "*";
		}
		var oModel = this.getView().getModel();
		var aBatchOperation = [oModel.createBatchOperation(contextPath, "PUT", {"name": attachmentName}, {sETag: eTagString})];
		var that = this;
		cus.crm.myaccounts.util.Util.sendBatchChangeOperations(oModel, aBatchOperation,
			function() {
				that._onAfterRename(contextPath);
			},
			function(oError) {
				oError.newAttachmentName = attachmentName;
				that._onAfterRename(contextPath, oError);
			}
		);
	},

	_onAfterRename: function(contextPath, oError) {
		if(oError) {
			if(this["_onAfterSaveHandleErrorCode_" + oError.statusCode]) {
				this["_onAfterSaveHandleErrorCode_" + oError.statusCode](contextPath, oError);
			} else {
				sap.m.MessageBox.alert(oError.message.value);
			}
		}
	},

	_onAfterSaveHandleErrorCode_412: function(contextPath, oError) {
		var that = this;
		sap.m.MessageBox.show(cus.crm.myaccounts.util.Util.geti18NText("MSG_CONFLICTING_FILE_NAME"), {
			title: cus.crm.myaccounts.util.Util.geti18NText("CONFIRM_TITLE"),
			actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
			onClose: function(confirmed) {
				if(confirmed === sap.m.MessageBox.Action.YES) {
					that._renameFile(contextPath, oError.newAttachmentName, true);
				} else {
					var oRefreshUIObject = cus.crm.myaccounts.util.Util.getRefreshUIObject(that.getView().getModel(), "/" + contextPath);
					oRefreshUIObject.refresh();
				}
			}
		});
	},

	onFilenameLengthExceed: function() {
		sap.m.MessageToast.show(cus.crm.myaccounts.util.Util.geti18NText("MSG_EXCEEDING_FILE_NAME_LENGTH"));
	}

});
},
	"cus/crm/myaccounts/view/overview/Attachments.view.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core" xmlns:mvc="sap.ui.core.mvc"\n\txmlns="sap.m" controllerName="cus.crm.myaccounts.view.overview.Attachments"\n\txmlns:html="http://www.w3.org/1999/xhtml">\n\n\t<UploadCollection\n\t\tid="fileupload"\n\t\tmaximumFilenameLength="40"\n\t\tmultiple="false"\n\t\titems="{Attachments}"\n\t\tshowSeparators="All"\n\t\tuploadUrl="{path: \'accountID\', formatter: \'cus.crm.myaccounts.util.formatter.uploadUrlFormatter\'}"\n\t\tchange="onChange"\n\t\tfileDeleted="onDeleteFile"\n\t\tfileRenamed="onRenameFile"\n\t\tuploadComplete="onUploadFile"\n\t\tfilenameLengthExceed="onFilenameLengthExceed">\n\t\t<UploadCollectionItem\n\t\t\tcontributor="{createdBy}"\n\t\t\tdocumentId="{documentID}"\n\t\t\tfileName="{name}"\n\t\t\tfileSize="{path: \'fileSize\', formatter: \'cus.crm.myaccounts.util.formatter.convertStringToFloat\'}"\n\t\t\tmimeType="{mimeType}"\n\t\t\tuploadedDate="{path: \'createdAt\', formatter: \'cus.crm.myaccounts.util.formatter.formatMediumDate\'}"\n\t\t\turl="{parts: [{path: \'URL\'}, {path: \'__metadata\'}], formatter: \'cus.crm.myaccounts.util.formatter.attachmentLinkFormatter\'}"\n\t\t\tthumbnailUrl="{URL}"\n\t\t\tenableEdit="true"\n\t\t\tenableDelete="true"/>\n\t</UploadCollection>\n\n</core:View>\n',
	"cus/crm/myaccounts/view/overview/Contacts.controller.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
// EXC_ALL_JSHINT_0211
jQuery.sap.require("cus.crm.myaccounts.util.Util");
jQuery.sap.require("sap.m.MessageBox");
jQuery.sap.require("cus.crm.myaccounts.util.Constants");

sap.ui.controller("cus.crm.myaccounts.view.overview.Contacts", {

	onContactLinkClicked:function (oEvent) {
		this._navToContact(oEvent);
	},

	onEditContactClicked:function (oEvent) {
		var contactContextPath = oEvent.getSource().getBindingContext().sPath.substr(1);
		var fgetService = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService;
		var oCrossAppNavigator = fgetService && fgetService("CrossApplicationNavigation");
		oCrossAppNavigator.toExternal({
			target : {
				semanticObject : "ContactPerson",
				action : "MyContacts&/edit/"+contactContextPath
			}
		});
	},

	onDeleteContactClicked: function(oEvent){
		var contactContextPath = oEvent.getSource().getBindingContext().sPath.substr(1);
		sap.m.MessageBox.confirm(
				cus.crm.myaccounts.util.Util.geti18NText("MSG_CONFIRM_DELETE_CONTACT"),
				jQuery.proxy(function (confirmed) {
					if (confirmed === "OK") {
						var oModel = this.getView().getModel();
						this.setBusy(true);
						var that = this;
				        var aBatchOperation = [];
						var oBatchOperation = oModel.createBatchOperation("/"+contactContextPath, "DELETE", undefined);
					    aBatchOperation.push(oBatchOperation);	
					    cus.crm.myaccounts.util.Util.sendBatchChangeOperations(oModel, aBatchOperation,  function(){
					    	that.setBusy(false);
					    }, function(){
					    	that.setBusy(false);
					    });
					}
				}, this)
		);
	},

	onPhoneClicked:function (oEvent) {
		sap.m.URLHelper.triggerTel(oEvent.getSource().getText());
	},

	onEmailClicked:function (oEvent) {
		sap.m.URLHelper.triggerEmail(oEvent.getSource().getText());
	},

	getList: function() {
		return this.byId("list");
	},

	onSubViewLiveSearch: function(searchString) {
		var oBinding = this.getList().getBinding("items");
		var aFilters = [];
		if(searchString !== "")
			aFilters.push(new sap.ui.model.Filter("lastName", sap.ui.model.FilterOperator.Contains, searchString));
		if(oBinding)
			oBinding.filter(aFilters);
	},

	_navToContact: function (oEvent) {
		var contactContextPath = oEvent.getSource().getBindingContext().sPath.substr(1);
		var fgetService = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService;
		var oCrossAppNavigator = fgetService && fgetService("CrossApplicationNavigation");
		oCrossAppNavigator.toExternal({
			target : {
				semanticObject : "ContactPerson",
				action : "MyContacts&/display/"+contactContextPath
			}
		});
	},

	onStoreCurrentStateSupported: function(){
		return true;
	},

	onStoreCurrentState: function(storage){
		storage.contextPath = "";

		var oBus = sap.ui.getCore().getEventBus();

		// Listen to event that contact has been changed and
		// store the context path of the contact which has to be refreshed
		storage.onRefreshContextPath = function(channelId, eventId, data){
			storage.action = "refreshContextPath";
			storage.contextPath = data.contextPath;
		};

		// Listen to event that contact has been created. In case this event
		// happens refresh the whole list of contacts.
		storage.onRefreshList = function(){
			storage.action = "refreshList";
		};

		oBus.subscribe("cus.crm.mycontacts", "contactChanged", storage.onRefreshContextPath, storage);
		oBus.subscribe("cus.crm.mycontacts", "contactCreated", storage.onRefreshList, storage);

		// Remove all event listeners
		storage.onExit = function(){
			var oBus = sap.ui.getCore().getEventBus();
			oBus.unsubscribe("cus.crm.mycontacts", "contactChanged", storage.onRefreshContextPath, storage);
			oBus.unsubscribe("cus.crm.mycontacts", "contactCreated", storage.onRefreshList, storage);
		};
	},

	onRestoreCurrentState: function(storage){
		if(storage.action === "refreshList") {
			this.getList().getBinding("items").refresh();
		} else if(storage.action === "refreshContextPath"){
			var oRefreshUIObject = cus.crm.myaccounts.util.Util.getRefreshUIObject(this.getView().getModel(), "/"+storage.contextPath, "Photo,WorkAddress");
			oRefreshUIObject.refresh();
		}
	},

	onInitPersonalization: function(){
		var oTable = this.getList();

		return{
			tablePersonalization: {
				table: oTable
			}
		};
	},

	setBusy: function(busy){
		if(!this.oBusyDialog)
			this.oBusyDialog = new sap.m.BusyDialog();
		if(busy)
			this.oBusyDialog.open();
		else
			this.oBusyDialog.close();
	},

	getFooterButtons: function(){
		var that = this;
		var oBindingContext = this.getView().getBindingContext();
		if (oBindingContext && oBindingContext.getProperty("category") === cus.crm.myaccounts.util.Constants.accountCategoryPerson)
			return;
	
		return [{
				sIcon:"sap-icon://add",
				sTooltip: cus.crm.myaccounts.util.Util.geti18NText("ADD_CONTACT_TOOLTIP"),
				onBtnPressed:function () {
					var fgetService = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService;
					var oCrossAppNavigator = fgetService && fgetService("CrossApplicationNavigation");
					oCrossAppNavigator.toExternal({
						target : {
							semanticObject : "ContactPerson",
							action : "MyContacts&/new/"+that.getView().getBindingContext().sPath.substr(1)
						}
					});
				}
			}];
	}

/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf view.overview.Contacts
*/	
//	onInit: function() {
//
//	},

/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf view.Contacts
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf view.Contacts
*/
//	onAfterRendering: function() {
//
//	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf view.Contacts
*/
//	onExit: function() {
//
//	}

});
},
	"cus/crm/myaccounts/view/overview/Contacts.view.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core" xmlns:mvc="sap.ui.core.mvc" xmlns="sap.m" xmlns:layout="sap.ui.layout"\n\t\t\tcontrollerName="cus.crm.myaccounts.view.overview.Contacts" xmlns:html="http://www.w3.org/1999/xhtml">\n\n\t<Table\n    \t\tid="list"\n\t\t\tmode="{device>/listMode}"\n\t\t\tgrowing="true"\n          \tgrowingThreshold="10"\n          \tgrowingScrollToLoad="false"\n          \titems="{path:\'Contacts\',\n          \t\t\tparameters: {expand: \'Photo,WorkAddress\'} }"> \n\t        <columns>\n\t          <Column id="fullName" width="16rem" minScreenWidth="Small" demandPopin="true"><Text text="{i18n>NAME}" /></Column>\n\t          <Column id="department" width="8rem" minScreenWidth="XXLarge" demandPopin="true"><Text text="{i18n>DEPARTMENT}" /></Column>\n\t          <Column id="mobilePhone" width="9rem" minScreenWidth="Small" demandPopin="true"><Text text="{i18n>MOBILE}" /></Column>\n\t          <Column id="phone" width="9rem" minScreenWidth="Large" demandPopin="true"><Text text="{i18n>PHONE}" /></Column>\n\t          <Column id="email" width="13rem" minScreenWidth="Medium" demandPopin="true"><Text text="{i18n>EMAIL}" /></Column>\n\t          <Column id="actions" width="3rem" minScreenWidth="Desktop" demandPopin="true"><Text text="{i18n>ACTIONS}" /></Column>\n\t        </columns>\n\t        <items>\n\t        \t<ColumnListItem id="columnListItem">\n\t            \t<cells>\n\n            \t\t\t<layout:Grid class="gridMarginTop" defaultSpan="L3 M3 S6" hSpacing="0" vSpacing="0">\n\t            \t\t\t<layout:content>\n\t\t\t\t\t\t\t\t<core:Icon\n\t\t\t\t\t\t\t\t\tsrc="{path:\'Photo/__metadata/media_src\', formatter: \'cus.crm.myaccounts.util.formatter.pictureUrlFormatter\'}"\n\t\t\t\t\t\t\t\t\tvisible="{parts:[{path:\'contactID\'}, {path:\'Photo/__metadata/media_src\'}], formatter:\'cus.crm.myaccounts.util.formatter.standardIconVisibilityFormatter\'}"\n\t            \t\t\t\t\tsize="2.5rem">\n\t\t\t\t\t\t\t     </core:Icon>\n\t\t\t\t\t\t\t     <Image\n\t\t\t\t\t\t\t\t\tsrc="{path:\'Photo/__metadata/media_src\', formatter:\'cus.crm.myaccounts.util.formatter.pictureUrlFormatter\'}"\n\t\t\t\t\t\t\t\t\tvisible="{path:\'Photo/__metadata/media_src\', formatter:\'cus.crm.myaccounts.util.formatter.logoVisibilityFormatter\'}"\n\t\t\t\t\t\t\t\t\theight="2.5rem"\n\t\t\t\t\t\t\t\t\twidth="2.5rem">\n\t\t\t\t\t\t\t\t</Image>\n\t\t\t\t\t\t\t\t<VBox>\n\t\t\t\t\t\t\t\t\t<items>\n\t            \t\t\t\t\t\t<Link id="fullNameLink" text="{fullName}" press="onContactLinkClicked"/>\n\t            \t\t\t\t\t\t<Label id="functionLabel" text="{function}" />\n\t            \t\t\t\t\t</items>\n\t            \t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t            <layout:GridData span="L8 M8 S8"/>\n\t\t\t\t\t\t\t        </layoutData>\n            \t\t\t\t\t</VBox>\t\t  \n\t            \t\t\t</layout:content>\n\t            \t\t</layout:Grid>\n\t\t\t\t\t\t<Text text="{department}"/>\n\t\t\t\t\t\t<Link text="{WorkAddress/mobilePhone}" press="onPhoneClicked"/>\n\t\t\t            <Link text="{WorkAddress/phone}" press="onPhoneClicked"/>\n\t\t\t            <Link text="{WorkAddress/email}" press="onEmailClicked"/>\n\t\t\t            <layout:HorizontalLayout>\n\t\t\t\t        \t<core:Icon id="editIcon" src="sap-icon://edit" size="1.3rem" press="onEditContactClicked"/>\n\t\t\t\t            <core:Icon id="deleteIcon" src="sap-icon://delete" size="1.3rem"  press="onDeleteContactClicked" class="cusMyAccountsPaddingLeft"/>\n\t\t\t            </layout:HorizontalLayout>\n\t\t\t            \n\t\t\t         </cells>\n\t        \t</ColumnListItem>\n\t    \t</items>\n    \t</Table>\n\n</core:View>',
	"cus/crm/myaccounts/view/overview/GeneralData.controller.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("cus.crm.myaccounts.util.formatter");
jQuery.sap.require("cus.crm.myaccounts.util.Constants");
jQuery.sap.require("cus.crm.myaccounts.util.Util");

sap.ui.controller("cus.crm.myaccounts.view.overview.GeneralData", {

/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf view.overview.GeneralData
*/
	onInit: function() {
		var constants = new sap.ui.model.json.JSONModel(cus.crm.myaccounts.util.Constants);
		this.getView().setModel(constants, "constants");
	},
	
	// method called from the OV-Page
	getExpandForBinding: function(){
		var dependentRelations = "EmployeeResponsible,MainAddress,Classification,EmployeeResponsibleRel";
		var aDependentCustomRelations = [];
		/** * @ControllerHook extHookGetDependentCustomRelations
		 * The method extHookGetDependentCustomRelations should return an array with additional
		 * navigation properties for the AccountCollection, which should be considered in the read process 
		 * @callback cus.crm.myaccounts.view.overview.GeneralData~extHookGetDependentCustomRelations
		 * @return {array} */
		if (this.extHookGetDependentCustomRelations)
			aDependentCustomRelations = this.extHookGetDependentCustomRelations();
		if(aDependentCustomRelations.length > 0)
			dependentRelations = dependentRelations + "," + aDependentCustomRelations.join();
		return dependentRelations;
	},
	
	onMapIconPressed: function () {
		sap.m.URLHelper.redirect("http"+"://"+"maps.apple.com/?q="+this.getView().getBindingContext().getProperty("MainAddress/address").replace(/\n/g, ' ').replace(/\r/g, ''), true);
	},

	onEmployeeResponsibleLinkPressed:function (oEvent) {
		this._showBusinessCard(oEvent);
	},

	/*
	 * handler for business card
	 */
	_showBusinessCard: function (oEvent) {
		var oContext = oEvent.getSource().getBindingContext();
		cus.crm.myaccounts.util.Util.openQuickoverview(
			cus.crm.myaccounts.util.Util.geti18NText("EMPLOYEE_TITLE"),
			oContext.getProperty("EmployeeResponsible/fullName"),
			oContext.getProperty("EmployeeResponsible/position"),
			cus.crm.myaccounts.util.formatter.pictureUrlFormatter(this.getView().getModel().getProperty(oContext.getPath() + "/EmployeeResponsible/Photo/__metadata/media_src")),
			oContext,
			"EmployeeResponsible",
			"WorkAddress",
			oContext,
			"MainAddress",
			oEvent.getSource()
		);			
	},

	onPhoneTaped:function (oEvent) {
		if(jQuery.device.is.ipad)
			sap.m.URLHelper.redirect("facetime://"+oEvent.getSource().getText().replace(/[()\s]/g, ''), false);
		else
			sap.m.URLHelper.triggerTel(oEvent.getSource().getText());
	},

	onEmailTaped:function (oEvent) {
		sap.m.URLHelper.triggerEmail(oEvent.getSource().getText());
	},

	// called from the Overview-Page
	getFooterButtons: function(){
		var that = this;
		return [{
				sI18nBtnTxt:"BUTTON_EDIT",
				sIcon:"",
				onBtnPressed:function () {
					var oParameter;
					oParameter = {
						contextPath:that.getView().getBindingContext().sPath.substr(1)
					};
					that.oRouter.navTo("edit", oParameter, false);
				}
			}];
	}

/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf view.overview.GeneralData
*/
//	onBeforeRendering: function() {
//
//		}
//	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf view.overview.GeneralData
*/
//	onAfterRendering: function() {
//
//	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf view.overview.GeneralData
*/
//	onExit: function() {
//
//	}

});
},
	"cus/crm/myaccounts/view/overview/GeneralData.view.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core" xmlns="sap.m" xmlns:mvc="sap.ui.core.mvc" xmlns:form="sap.ui.layout.form" xmlns:layout="sap.ui.layout"\n\t\t\tcontrollerName="cus.crm.myaccounts.view.overview.GeneralData" xmlns:html="http://www.w3.org/1999/xhtml">\n\n\t<Panel>\n    \t<content>\n\n\t\t    <layout:Grid defaultSpan="L12 M12 S12" width="auto">\n\t\t\t\t<layout:content>\n\t\t\t\t\t<!-- Extends the view by a form -->\n\t\t\t\t\t<core:ExtensionPoint name="extDisplayForm">\n\n\t\t\t\t\t\t<form:Form id="form" maxContainerCols="2" editable="false">\n\t\t\t\t\t\t\t<form:layout>\n\t\t\t\t\t\t\t\t<form:ResponsiveGridLayout\n\t\t\t\t\t\t\t\t\tlabelSpanL="4"\n\t\t\t\t\t\t\t\t\tlabelSpanM="4"\n\t\t\t\t\t\t\t\t\temptySpanL="3"\n\t\t\t\t\t\t\t\t\temptySpanM="2"\n\t\t\t\t\t\t\t\t\tcolumnsL="1"\n\t\t\t\t\t\t\t\t\tcolumnsM="1">\n\t\t\t\t\t\t\t\t</form:ResponsiveGridLayout>\n\t\t\t\t\t\t\t</form:layout>\n\t\t\t\t\t        <form:formContainers>\n\n\t\t\t\t\t\t\t\t<!-- Extends the form at the top -->\n\t\t\t\t\t        \t<core:ExtensionPoint name="extDisplayFormTop"/>\n\n\t\t\t\t\t        \t<form:FormContainer id="formCompany" visible="{parts:[\'category\', \'constants>/accountCategoryPerson\'], formatter: \'cus.crm.myaccounts.util.formatter.isUnequal\'}">\n\t\t\t\t\t\t\t\t\t<form:formElements >\n\t\t\t\t\t\t\t\t\t\t<core:Fragment id="companyFragment" fragmentName="cus.crm.myaccounts.view.overview.GeneralDataCompany" type="XML" />\n\t\t\t\t\t\t\t\t\t</form:formElements>\n\t\t\t\t\t\t\t\t</form:FormContainer>\n\n\t\t\t        \t\t\t<form:FormContainer id="formPerson" visible="{parts:[\'category\', \'constants>/accountCategoryPerson\'], formatter: \'cus.crm.myaccounts.util.formatter.isEqual\'}">\n\t\t\t\t\t\t\t\t\t<form:formElements >\n\t\t\t\t\t\t\t\t\t\t<core:Fragment id="personFragment" fragmentName="cus.crm.myaccounts.view.overview.GeneralDataPerson" type="XML" />\n\t\t\t\t\t\t\t\t\t</form:formElements>\n\t\t\t\t\t\t\t\t</form:FormContainer>\n\n\t\t\t\t\t\t\t\t<!-- Extends the form in the middle -->\n\t\t\t\t\t\t\t\t<core:ExtensionPoint name="extDisplayFormMiddle"/>\n\t\n\t\t\t\t\t        \t<form:FormContainer id="formAddress">\n\t\t\t\t\t        \t\t<form:formElements>\n\t\n\t\t\t\t\t        \t\t\t<!-- Address -->\n\t\n\t\t\t\t\t        \t\t\t<form:FormElement id="mobilePhone" visible="{parts:[\'category\', \'constants>/accountCategoryPerson\'], formatter: \'cus.crm.myaccounts.util.formatter.isEqual\'}">\n\t\t\t\t\t        \t\t\t\t<form:label>\n\t\t\t\t\t        \t\t\t\t\t<Label id="mobilePhoneLabel"\n\t\t\t\t\t\t\t\t\t\t\t\t       text="{i18n>MOBILE}"/>\n\t\t\t\t\t        \t\t\t\t</form:label>\n\t\t\t\t\t        \t\t\t\t<form:fields>\n\t\t\t\t\t        \t\t\t\t\t<Link id="mobilePhoneText"\n\t\t\t\t\t\t\t\t\t\t\t      \t  text="{MainAddress/mobilePhone}"\n\t\t\t\t\t\t\t\t\t\t\t      \t  press="onPhoneTaped"/>\n\t\t\t\t\t        \t\t\t\t</form:fields>\n\t\t\t\t\t        \t\t\t</form:FormElement>\n\t\n\t\t\t\t\t        \t\t\t<form:FormElement id="phone">\n\t\t\t\t\t        \t\t\t\t<form:label>\n\t\t\t\t\t        \t\t\t\t\t<Label id="phoneLabel"\n\t\t\t\t\t\t\t\t\t\t\t\t       text="{i18n>PHONE}"/>\n\t\t\t\t\t        \t\t\t\t</form:label>\n\t\t\t\t\t        \t\t\t\t<form:fields>\n\t\t\t\t\t        \t\t\t\t\t<Link id="phoneText"\n\t\t\t\t\t\t\t\t\t\t\t      \t  text="{MainAddress/phone}"\n\t\t\t\t\t\t\t\t\t\t\t      \t  press="onPhoneTaped"/>\n\t\t\t\t\t        \t\t\t\t</form:fields>\n\t\t\t\t\t        \t\t\t</form:FormElement>\n\t\n\t\t\t\t\t        \t\t\t<form:FormElement id="email">\n\t\t\t\t\t        \t\t\t\t<form:label>\n\t\t\t\t\t        \t\t\t\t\t<Label id="emailLabel"\n\t\t\t\t\t\t\t\t\t\t\t\t       text="{i18n>EMAIL}"/>\n\t\t\t\t\t        \t\t\t\t</form:label>\n\t\t\t\t\t        \t\t\t\t<form:fields>\n\t\t\t\t\t        \t\t\t\t\t<Link id="emailText"\n\t\t\t\t\t\t\t\t\t\t\t\t      text="{MainAddress/email}"\n\t\t\t\t\t\t\t\t\t\t\t      \t  press="onEmailTaped"/>\n\t\t\t\t\t        \t\t\t\t</form:fields>\n\t\t\t\t\t        \t\t\t</form:FormElement>\n\t\n\t\t\t\t\t        \t\t\t<form:FormElement id="webSite">\n\t\t\t\t\t        \t\t\t\t<form:label>\n\t\t\t\t\t        \t\t\t\t\t<Label id="webSiteLabel"\n\t\t\t\t\t\t\t\t\t\t\t\t       text="{i18n>WEBSITE}"/>\n\t\t\t\t\t        \t\t\t\t</form:label>\n\t\t\t\t\t        \t\t\t\t<form:fields>\n\t\t\t\t\t        \t\t\t\t\t<Link id="webSiteText"\n\t\t\t\t\t\t\t\t\t\t\t    \t  href="{path:\'MainAddress/website\', formatter:\'cus.crm.myaccounts.util.formatter.websiteURL\'}"\n\t\t\t\t\t\t\t\t\t\t\t    \t  target="_blank"\n\t\t\t\t\t\t\t\t\t\t\t\t      text="{MainAddress/website}"/>\n\t\t\t\t\t        \t\t\t\t</form:fields>\n\t\t\t\t\t        \t\t\t</form:FormElement>\n\t\n\t\t\t\t\t        \t\t\t<form:FormElement id="address">\n\t\t\t\t\t        \t\t\t\t<form:label>\n\t\t\t\t\t        \t\t\t\t\t<Label id="addressLabel"\n\t\t\t\t\t\t\t\t\t\t\t           text="{i18n>ADDRESS}"/>\n\t\t\t\t\t        \t\t\t\t</form:label>\n\t\t\t\t\t        \t\t\t\t<form:fields>\n\t\t\t\t\t        \t\t\t\t\t<layout:HorizontalLayout>\n\t\t\t\t\t\t        \t\t\t\t\t<Text id="addressText"\n\t\t\t\t\t\t\t\t\t\t\t\t     \t  text="{MainAddress/address}"/>\n\t\t\t\t\t\t\t\t\t\t\t\t    <layout:HorizontalLayout id="mapIcon" visible="false">\n\t\t\t\t\t\t\t\t\t\t\t\t    \t<core:Icon src="sap-icon://map" press="onMapIconPressed" size="1.2rem" class="cusMyAccountsPaddingLeft" visible="{parts:[\'MainAddress/address\'], formatter: \'cus.crm.myaccounts.util.formatter.isNotInitial\'}" />\n\t\t\t\t\t\t\t\t\t\t\t\t    </layout:HorizontalLayout>\n\t\t\t\t\t\t\t\t\t\t\t    </layout:HorizontalLayout>\n\t\t\t\t\t        \t\t\t\t</form:fields>\n\t\t\t\t\t        \t\t\t</form:FormElement>\n\t\t\t\t\t        \t\t\t\n\t\t\t\t\t        \t\t\t<!-- Extends the address block in the form -->\n\t\t\t\t\t        \t\t\t<core:ExtensionPoint name="extDisplayFormAddress"/>\n\t\n\t\t\t\t\t        \t\t\t<!-- Rating -->\n\t\n\t\t\t\t\t        \t\t\t<form:FormElement id="rating">\n\t\t\t\t\t        \t\t\t\t<form:label>\n\t\t\t\t\t        \t\t\t\t\t<Label id="ratingLabel"\n\t\t\t\t\t\t\t\t\t\t\t\t       text="{i18n>RATING}"/>\n\t\t\t\t\t        \t\t\t\t</form:label>\n\t\t\t\t\t        \t\t\t\t<form:fields>\n\t\t\t\t\t        \t\t\t\t\t<Text id="ratingText"\n\t\t\t\t\t\t\t\t\t        \t      text="{Classification/ratingText}"/>\n\t\t\t\t\t        \t\t\t\t</form:fields>\n\t\t\t\t\t        \t\t\t</form:FormElement>\n\t\n\t\t\t\t\t        \t\t\t<!-- Employee Responsible -->\n\t\n\t\t\t\t\t        \t\t\t<form:FormElement id="employee">\n\t\t\t\t\t        \t\t\t\t<form:label>\n\t\t\t\t\t        \t\t\t\t\t<Label id="employeeLabel"\n\t\t\t\t\t\t\t\t\t\t\t\t       text="{i18n>EMPLOYEE_RESPONSIBLE}"/>\n\t\t\t\t\t        \t\t\t\t</form:label>\n\t\t\t\t\t        \t\t\t\t<form:fields>\n\t\t\t\t\t        \t\t\t\t\t<Link id="employeeText"\n\t\t\t\t\t\t\t\t\t\t\t\t      text="{EmployeeResponsibleRel/account2FullName}"\n\t\t\t\t\t\t\t\t\t\t\t\t      press="onEmployeeResponsibleLinkPressed"/>\n\t\t\t\t\t        \t\t\t\t</form:fields>\n\t\t\t\t\t        \t\t\t</form:FormElement>\n\t\n\t\t\t\t\t        \t\t</form:formElements>\n\t\t\t\t\t        \t</form:FormContainer>\n\n\t\t\t\t\t\t\t\t<!-- Extends the form at the bottom -->\n\t\t\t\t\t        \t<core:ExtensionPoint name="extDisplayFormBottom"/>\n\n\t\t\t\t\t        </form:formContainers>\n\t\t\t\t\t    </form:Form>\n\n\t\t\t\t\t</core:ExtensionPoint>\n\t\t\t\t</layout:content>\n\t\t\t</layout:Grid>\n\n    \t</content>\n\t</Panel>\n\n</core:View>\n',
	"cus/crm/myaccounts/view/overview/GeneralDataCompany.fragment.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:FragmentDefinition\n  xmlns="sap.m"\n  xmlns:core="sap.ui.core"\n  xmlns:form="sap.ui.layout.form">\n\n\t<form:FormElement id="name1">\n       \t<form:label>\n       \t\t<Label id="name1Label"\n\t\t\t\t   text="{parts:[\'i18n>LAST_NAME\', \'i18n>COMPANY_NAME1\', \'i18n>COMPANY_NAME1\', \'category\'], formatter: \'cus.crm.myaccounts.util.formatter.AccountSpecificText\'}"/>\n       \t</form:label>\n       \t<form:fields>\n       \t\t<Text id="name1Input"\n\t\t          text="{name1}"/>\n       \t</form:fields>\n\t</form:FormElement>\n\n    <form:FormElement id="name2">\n       \t<form:label>\n       \t\t<Label id="name2Label"\n     \t\t\t   text="{parts:[\'i18n>FIRST_NAME\', \'i18n>COMPANY_NAME2\', \'i18n>COMPANY_NAME2\', \'category\'], formatter: \'cus.crm.myaccounts.util.formatter.AccountSpecificText\'}"/>\n       \t</form:label>\n       \t<form:fields>\n       \t\t<Text id="name2Input"\n   \t  \t\t\t  text="{name2}"/>\n       \t</form:fields>\n\t</form:FormElement>\n\n\t<!-- Extends the form -->\n\t<core:ExtensionPoint name="extDisplayFormCompany"/>\n\n</core:FragmentDefinition>',
	"cus/crm/myaccounts/view/overview/GeneralDataPerson.fragment.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:FragmentDefinition\n  xmlns="sap.m"\n  xmlns:core="sap.ui.core"\n  xmlns:form="sap.ui.layout.form">\n\n\t<form:FormElement id="title">\n\t\t<form:label>\n       \t\t<Label id="titleLabel"\n\t\t\t\t   text="{i18n>TITLE}"/>\n       \t</form:label>\n       \t<form:fields>\n       \t\t<Text id="titleInput"\n\t\t\t\t  text="{title}"/>\n    \t</form:fields>\n    </form:FormElement>\n\n    <form:FormElement id="academicTitle">\n       \t<form:label>\n       \t\t<Label id="academicTitleLabel"\n\t\t\t\t   text="{i18n>ACADEMIC_TITLE}"/>\n       \t</form:label>\n       \t<form:fields>\n       \t\t<Text id="academicTitleInput"\n\t\t\t      text="{academicTitle}"/>\n       \t</form:fields>\n\t</form:FormElement>\n\n    <form:FormElement id="name2">\n      \t<form:label>\n      \t\t<Label id="name2Label"\n     \t\t\t   text="{parts:[\'i18n>FIRST_NAME\', \'i18n>COMPANY_NAME2\', \'i18n>COMPANY_NAME2\', \'category\'], formatter: \'cus.crm.myaccounts.util.formatter.AccountSpecificText\'}"/>\n       \t</form:label>\n       \t<form:fields>\n       \t\t<Text id="name2Input"\n   \t  \t\t\t  text="{name2}"/>\n       \t</form:fields>\n\t</form:FormElement>\n\n    <form:FormElement id="lastName">\n       \t<form:label>\n       \t\t<Label id="lastNameLabel"\n\t\t\t\t   text="{parts:[\'i18n>LAST_NAME\', \'i18n>COMPANY_NAME1\', \'i18n>COMPANY_NAME1\', \'category\'], formatter: \'cus.crm.myaccounts.util.formatter.AccountSpecificText\'}"/>\n       \t</form:label>\n       \t<form:fields>\n       \t\t<Text id="lastNameInput"\n\t\t\t      text="{name1}"/>\n       \t</form:fields>\n\t</form:FormElement>\n\n    <form:FormElement id="birthDate">\n       \t<form:label>\n       \t\t<Label id="birthDateLabel"\n\t\t\t\t   text="{i18n>BIRTHDAY}"/>\n       \t</form:label>\n       \t<form:fields>\n       \t\t<Text id="birthDateInput"\n\t\t\t      text="{path:\'birthDate\', formatter:\'cus.crm.myaccounts.util.formatter.formatMediumDate\'}"/>\n       \t</form:fields>\n\t</form:FormElement>\n\n\t<!-- Extends the form -->\n\t<core:ExtensionPoint name="extDisplayFormPerson"/>\n\n</core:FragmentDefinition>',
	"cus/crm/myaccounts/view/overview/ItemsQuickoverview.fragment.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:FragmentDefinition\n\txmlns="sap.m"\n\txmlns:core="sap.ui.core"\n\txmlns:form="sap.ui.layout.form">\n\n\t<Popover\n\t    title="{i18n>PRODUCTS}"\n\t    class="sapUiPopupWithPadding"\n\t    placement="Right" >\n\t    <List\n\t\t\tgrowing="true" growingScrollToLoad="false" mode="None" growingThreshold="5" \n\t\t\titems="{ERP_BUPA_ODATA>Items}" >\n\t\t\t<StandardListItem\n\t\t\t\ttitle="{ERP_BUPA_ODATA>itemDescription}"\n\t\t\t\tdescription="{ERP_BUPA_ODATA>materialNumber}" />\n\t\t</List>\n\t</Popover>\n\n</core:FragmentDefinition>',
	"cus/crm/myaccounts/view/overview/Leads.controller.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
// EXC_ALL_JSHINT_0211
jQuery.sap.require("cus.crm.myaccounts.util.formatter");

//Used for Cross Navigation to Leads
cus.crm.myaccounts.NavigationHelper = {};

sap.ui.controller("cus.crm.myaccounts.view.overview.Leads", {

	/**
	* Called when a controller is instantiated and its View controls (if available) are already created.
	* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
	* @memberOf view.Leads
	*/
		onInit: function() {
			// Retrieve the application bundle
			this.resourceBundle = sap.ca.scfld.md.app.Application.getImpl().AppI18nModel.getResourceBundle();
		},
		
		getList: function() {
			return this.byId("list");
		},
		
		onSubViewLiveSearch: function(searchString) {
			var oBinding = this.getList().getBinding("items");
			var aFilters = [];
			if(searchString !== "")
				aFilters.push(new sap.ui.model.Filter("description", sap.ui.model.FilterOperator.Contains, searchString));
			if(oBinding)
				oBinding.filter(aFilters);
		},
		
		onInitPersonalization: function(){
			var oTable = this.getList();
			return{
				tablePersonalization: {
					table: oTable
				}
			};
		},
		
		onLeadDescriptionLinkClicked: function (oEvent) {
			this._navToLead(oEvent);
		},
		
		onEditLeadClicked:function (oEvent) {
			var guid = oEvent.getSource().getBindingContext().getObject().Guid;
			var fgetService = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService;
			var oCrossAppNavigator = fgetService && fgetService("CrossApplicationNavigation");
			oCrossAppNavigator.toExternal({
				target : {
					semanticObject : "Lead",
					action : "manageLead&/editFullScreen/Leads(guid'" + guid + "')"
				}
			});
		},
		
		onEmployeeResponsibleLinkClicked: function (oEvent) {
			this._showBusinessCard(oEvent);
		},
		
		_navToLead: function (oEvent) {
			var guid = oEvent.getSource().getBindingContext().getObject().Guid;
			
			// *XNav* (1) obtain cross app navigation interface
			var fgetService = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService;
			var oCrossAppNavigator = fgetService && fgetService("CrossApplicationNavigation");

			// *XNav (2) generate cross application link
			oCrossAppNavigator.toExternal({
				target : {
					semanticObject : "Lead",
					action : "manageLead&/display/Leads(guid'" + guid + "')"
				}
			});
		},
		
		/*
		 * handler for business card
		 */
		_showBusinessCard: function (oEvent) {
			var contextPath = oEvent.getSource().getBindingContext().sPath;
			var oModel = this.getView().getModel();
			cus.crm.myaccounts.util.Util.openQuickoverview(
					this.resourceBundle.getText("EMPLOYEE_TITLE"),
					oModel.getProperty(contextPath + "/EmployeeResponsible/fullName"),
					oModel.getProperty(contextPath + "/EmployeeResponsible/position"),
					cus.crm.myaccounts.util.formatter.pictureUrlFormatter(oModel.getProperty(contextPath + "/EmployeeResponsible/Photo/__metadata/media_src")),
					oEvent.getSource().getBindingContext(),
					"EmployeeResponsible",
					"WorkAddress",
					this.getView().getBindingContext(),
					"MainAddress",
					oEvent.getSource());
		},
		
		onStoreCurrentStateSupported: function(){
			return true;
		},
		
		onStoreCurrentState: function(storage){
			storage.contextPath = "";

			var oBus = sap.ui.getCore().getEventBus();

			// Listen to event that lead has been changed and
			// store the context path of the lead which has to be refreshed
			storage.onRefreshContextPath = function(channelId, eventId, data){
				storage.action = "refreshContextPath";
				storage.contextPath = data.contextPath.replace("Leads", "LeadCollection");
			};

			oBus.subscribe("cus.crm.leads", "leadChanged", storage.onRefreshContextPath, storage);

			// Remove all event listeners
			storage.onExit = function(){
				var oBus = sap.ui.getCore().getEventBus();
				oBus.unsubscribe("cus.crm.leads", "leadChanged", storage.onRefreshContextPath, storage);
			};
		},
		
		onRestoreCurrentState: function(storage){
			if(storage.action === "refreshContextPath"){
				var oRefreshUIObject = cus.crm.myaccounts.util.Util.getRefreshUIObject(this.getView().getModel(), "/"+storage.contextPath, "EmployeeResponsible,EmployeeResponsible/Photo,EmployeeResponsible/WorkAddress");
				oRefreshUIObject.refresh();
			}
		}

/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf view.Contacts
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf view.Contacts
*/
//	onAfterRendering: function() {
//
//	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf view.Contacts
*/
//	onExit: function() {
//
//	}

});
},
	"cus/crm/myaccounts/view/overview/Leads.view.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core" xmlns:mvc="sap.ui.core.mvc" xmlns="sap.m" xmlns:layout="sap.ui.layout"\n\t\t\tcontrollerName="cus.crm.myaccounts.view.overview.Leads" xmlns:html="http://www.w3.org/1999/xhtml">\n\n\t<Table\n   \t\tid="list"\n\t\tmode="{device>/listMode}"\n\t\tgrowing="true"\n         \tgrowingThreshold="10"\n         \tgrowingScrollToLoad="false"\n         \titems="{path:\'Leads\',\n         \t\t\tparameters: {expand: \'EmployeeResponsible,EmployeeResponsible/Photo,EmployeeResponsible/WorkAddress\'},\n         \t\t\tsorter: [{path: \'validTo\', descending: true}]}">\n        <columns>\n          <Column id="descriptionCol" width="16rem" minScreenWidth="Small" demandPopin="true"><Label text="{i18n>DESCRIPTION}" /></Column>\n          <Column id="assignedToCol" width="16rem" minScreenWidth="Medium" demandPopin="true"><Label text="{i18n>ASSIGNED_TO}" /></Column>\n          <Column id="closingDateCol" width="8rem" minScreenWidth="Large" demandPopin="true"><Label text="{i18n>END_DATE}" /></Column>\n          <Column id="qualificationCol" width="8rem" minScreenWidth="Large" demandPopin="true"><Label text="{i18n>QUALIFICATION}" /></Column>\n          <Column id="statusCol" width="12rem" minScreenWidth="Large" demandPopin="true"><Label text="{i18n>STATUS}" /></Column>\n          <!-- <Column id="actions" width="3rem" minScreenWidth="Desktop" demandPopin="true"><Text text="{i18n>ACTIONS}" /></Column>  -->\n        </columns>\n        <items>\n        \t<ColumnListItem id="columnListItem">\n            \t<cells>\n            \t\n\t\t\t\t\t<VBox>\n\t\t\t\t\t\t<items>\n          \t\t\t\t\t\t<Link text="{description}" press="onLeadDescriptionLinkClicked"/>\n          \t\t\t\t\t\t<Label text="{objectId}" />\n          \t\t\t\t\t</items>\n          \t\t\t\t\t<layoutData>\n\t\t\t\t            <layout:GridData span="L12 M12 S12"/>\n\t\t\t\t        </layoutData>\n         \t\t\t\t</VBox>\t\n            \n            \t\t<layout:Grid class="gridMarginTop" defaultSpan="L3 M3 S6" hSpacing="0" vSpacing="0">\n            \t\t\t<layout:content>\n\t\t\t\t\t\t\t<core:Icon \n\t\t\t\t\t\t\t\tsrc="{path:\'EmployeeResponsible/Photo/__metadata/media_src\', formatter: \'cus.crm.myaccounts.util.formatter.pictureUrlFormatter\'}"\n\t\t\t\t\t\t\t\tvisible="{parts:[{path:\'EmployeeResponsible/employeeID\'}, {path:\'EmployeeResponsible/Photo/__metadata/media_src\'}], formatter:\'cus.crm.myaccounts.util.formatter.standardIconVisibilityFormatter\'}"\n            \t\t\t\t\tsize="2.5rem">\n\t\t\t\t\t\t     </core:Icon>\n\t\t\t\t\t\t     <Image \n\t\t\t\t\t\t\t\tsrc="{path:\'EmployeeResponsible/Photo/__metadata/media_src\', formatter:\'cus.crm.myaccounts.util.formatter.pictureUrlFormatter\'}"\n\t\t\t\t\t\t\t\tvisible="{path:\'EmployeeResponsible/Photo/__metadata/media_src\', formatter:\'cus.crm.myaccounts.util.formatter.logoVisibilityFormatter\'}" \n\t\t\t\t\t\t\t\theight="2.5rem" \n\t\t\t\t\t\t\t\twidth="2.5rem">\n\t\t\t\t\t\t\t</Image>\n\t\t\t\t\t\t\t<VBox>\n\t\t\t\t\t\t\t\t<items>\n            \t\t\t\t\t\t<Link text="{EmployeeResponsible/fullName}" press="onEmployeeResponsibleLinkClicked"/>\n            \t\t\t\t\t\t<Label text="{EmployeeResponsible/position}" />\n            \t\t\t\t\t</items>\n            \t\t\t\t\t<layoutData>\n\t\t\t\t\t\t            <layout:GridData span="L8 M8 S8"/>\n\t\t\t\t\t\t        </layoutData>\n           \t\t\t\t\t</VBox>\t\t\t\t\t\t\t  \n            \t\t\t</layout:content>\n            \t\t</layout:Grid>\n                    \n                    <Text text="{parts:[{path:\'validTo\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatMediumDate\' }"/>\n                   \n\t\t            <Text text="{qualificationLevel}"/>\n\t\t              \n\t\t            <ObjectStatus text="{statusText}" state="{path:\'status\', formatter:\'cus.crm.myaccounts.util.formatter.formatStatusText\'}"/>\n\t\t            <!-- \n\t\t            <layout:HorizontalLayout>\n\t\t            \t<core:Icon src="sap-icon://edit" size="1.3rem" press="onEditLeadClicked"/>\n\t\t\t        </layout:HorizontalLayout>\n\t\t\t        -->\n                \n            \t</cells>\n        \t</ColumnListItem>\n    \t</items>\n   \t</Table>\n\n</core:View>\n',
	"cus/crm/myaccounts/view/overview/MarketingAttributes.controller.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("cus.crm.myaccounts.util.Constants");
jQuery.sap.require("cus.crm.myaccounts.util.Util");
jQuery.sap.require("sap.m.MessageBox");
sap.ui.controller("cus.crm.myaccounts.view.overview.MarketingAttributes", {

	/**
	* Called when a controller is instantiated and its View controls (if available) are already created.
	* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
	* @memberOf view.MarketingAttributes
	*/
	onInit: function() {
		this.aBatchOperations = [];
		
		var constants = new sap.ui.model.json.JSONModel(cus.crm.myaccounts.util.Constants);
		this.getView().setModel(constants, "constants");
	},

	onItemSelected: function() {
		jQuery.sap.log.debug("cus.crm.myaccounts.view.overview.MarketingAttributes - onItemSelected");
		this._bindMarketingAttributes();
	},

	_bindMarketingAttributes: function() {
		jQuery.sap.log.debug("cus.crm.myaccounts.view.overview.MarketingAttributes - _bindMarketingAttributes");
		var that = this;
		if(!this.getList().getModel("mktattr")){
			this.getList().setModel(new sap.ui.model.json.JSONModel(), "mktattr");
		}
		this.getList().getModel("mktattr").setProperty("/MarketingAttributes", []);
		this.getList().setBusy(true);
		cus.crm.myaccounts.util.Util.readODataObjects(that.getView().getBindingContext(), "MarketingAttributes", [], function (results) {
			// build json model
			if (results) {
				var aMarketingAttributes = that.getList().getModel("mktattr").getProperty("/MarketingAttributes");
				for(var i=0; i<results.length; i++) {
					var oMktAttr = jQuery.extend({}, that.getView().getModel().getProperty("/" + results[i]));
					oMktAttr.key = results[i];
					that._setAttributeValues(oMktAttr);
					that._setUIFieldType(oMktAttr);
					aMarketingAttributes.push(oMktAttr);
				}
				that.getList().getModel("mktattr").setProperty("/MarketingAttributes", aMarketingAttributes);				
				that.getList().setBusy(false);
			}
		});
	},

	// *** Search in view ************************************************
	onSubViewLiveSearch: function(searchString) {
		var oBinding = this.getList().getBinding("items");
		var aFilters = [];
		if(searchString !== "") {
			var aSearchFilters = [];
			aSearchFilters.push(new sap.ui.model.Filter("attribute", sap.ui.model.FilterOperator.Contains, searchString));
			aSearchFilters.push(new sap.ui.model.Filter("eTag", sap.ui.model.FilterOperator.EQ, ""));
			aFilters.push(new sap.ui.model.Filter(aSearchFilters,false)); //Filter: attribute contains searchString OR eTag is initial (new entity)
		}
		if(oBinding)
			oBinding.filter(aFilters);
	},

	// *** Personalization ***********************************************
	onInitPersonalization: function() {
		jQuery.sap.log.debug("cus.crm.myaccounts.view.overview.MarketingAttributes - onInitPersonalization");
		var oTable = this.getList();
		return {
			tablePersonalization: {
				table: oTable
			}
		};
	},

	_setAttributeValues: function(oMktAttribute, aMktAttrValues){
		//initialize mktAttrValues
		if(!oMktAttribute.mktAttrValues)
			oMktAttribute.mktAttrValues = [{valueID: oMktAttribute.valueID, value:oMktAttribute.value}];
		if(aMktAttrValues && aMktAttrValues.length > 0){
			// Get the array of attribute values
			var aNewValues = [];
			var oNewValue = {};
			var oDefaultValue = {};
			for(var i = 0; i < aMktAttrValues.length; i++) {
				oNewValue = this.getList().getModel().getProperty("/"+ aMktAttrValues[i]);
				oNewValue.value = cus.crm.myaccounts.util.formatter.formatMktAttrDisplayField(oNewValue.valueID, oNewValue.value, oMktAttribute.attributeDatatype, oMktAttribute.decimalPlaces, oMktAttribute.currency);
				aNewValues.push(oNewValue);
				if(!oDefaultValue.valueID){
					oDefaultValue = oNewValue;
				}
				if(oNewValue.isDefault) {
					oDefaultValue = oNewValue;
				}
			}
			oMktAttribute.mktAttrValues = aNewValues;
			// In case attribute has default value, set selected key
			// In case of edit valueID is available, don't set default value
			if(oDefaultValue && oDefaultValue.valueID && !oMktAttribute.valueID) {
				oMktAttribute.valueID = oDefaultValue.valueID;
				oMktAttribute.value = oDefaultValue.value;
				if (oMktAttribute.attributeDatatype === cus.crm.myaccounts.util.Constants.dataTypeDATE) {
					// update dateValue (if it is an interval, dateValue is set to null)
					oMktAttribute.dateValue = cus.crm.myaccounts.util.formatter.convertDateStringToUTC( oMktAttribute.value );
				}
			}
		}
	},

	_setUIFieldType: function(oMktAttribute){
		if (oMktAttribute.mode === cus.crm.myaccounts.util.Constants.modeEdit &&
				(oMktAttribute.hasChecktable || oMktAttribute.valueRestricted ||
				(oMktAttribute.mktAttrValues && oMktAttribute.mktAttrValues.length > 1))
			 )
			oMktAttribute.fieldType = cus.crm.myaccounts.util.Constants.fieldSelect;
		else if (oMktAttribute.attributeDatatype === cus.crm.myaccounts.util.Constants.dataTypeTIME){
			if (!oMktAttribute.valueID || oMktAttribute.valueID.length < 9)
				oMktAttribute.fieldType = cus.crm.myaccounts.util.Constants.fieldTime;
			else
				oMktAttribute.fieldType = cus.crm.myaccounts.util.Constants.fieldInput;
		}
		else if (oMktAttribute.attributeDatatype === cus.crm.myaccounts.util.Constants.dataTypeDATE){
			if (!oMktAttribute.value || oMktAttribute.valueID.length < 9)
				oMktAttribute.fieldType = cus.crm.myaccounts.util.Constants.fieldDate;
			else
				oMktAttribute.fieldType = cus.crm.myaccounts.util.Constants.fieldInput;
		}
		else if (oMktAttribute.attributeDatatype === cus.crm.myaccounts.util.Constants.dataTypeCURR ) {
			oMktAttribute.fieldType = cus.crm.myaccounts.util.Constants.fieldCurrency;
		}
		else
			oMktAttribute.fieldType = cus.crm.myaccounts.util.Constants.fieldInput;
	},

	getList: function() {
		return this.byId("list");
	},

	_generateTemplateForMarketingAttribute: function(oMktAttr) {
		var oNewMktAttribute = {};
		oNewMktAttribute.eTag = "";
		oNewMktAttribute.accountID = "";
		oNewMktAttribute.attributeSetID = "";
		oNewMktAttribute.attributeSet = "";
		oNewMktAttribute.attributeID = "";
		oNewMktAttribute.attribute = "";
		oNewMktAttribute.attributeDatatype = "";
		oNewMktAttribute.mktAttrValues = [{valueID: "", value: ""}];
		oNewMktAttribute.valueID = "";
		oNewMktAttribute.value = "";
		oNewMktAttribute.dateValue = null;
		oNewMktAttribute.fieldType = "";
		oNewMktAttribute.mode = "";
		oNewMktAttribute.errorExists = false;
		oNewMktAttribute.attributeLength = "";
		oNewMktAttribute.decimalPlaces = "";
		oNewMktAttribute.currency = "";

		if(oMktAttr){
			this._copyAttributesOfObject2ToObject1(oNewMktAttribute, oMktAttr);
		}
		return oNewMktAttribute;
	},

	_copyAttributesOfObject2ToObject1: function(object1, object2){
		if(!object2)
			return;
		for (var key in object1) {
			if(object2.hasOwnProperty(key))
				object1[key] = object2[key];
		}
	},

	// *** Actions - Edit, Delete, Save ******************************************************
	onAddMarketingAttributeClicked: function() {
		jQuery.sap.log.debug("cus.crm.myaccounts.view.overview.MarketingAttributes - onAddMarketingAttributeClicked");
		this._savePendingData();
		var oMktAttrModel = this.getList().getModel("mktattr");
		var aMktAttributes = oMktAttrModel.getProperty("/MarketingAttributes");
		if(aMktAttributes.length > 0 && !aMktAttributes[0].value && !aMktAttributes[0].attribute && !aMktAttributes[0].attributeSet)
			return; //return if an empty new line exists

		var oNewMktAttribute = this._generateTemplateForMarketingAttribute();
		oNewMktAttribute.mode = cus.crm.myaccounts.util.Constants.modeEdit;
		aMktAttributes.unshift(oNewMktAttribute);
		oMktAttrModel.setProperty("/MarketingAttributes", aMktAttributes);
	},

	onDeleteMarketingAttributeClicked: function(oEvent) {
		jQuery.sap.log.debug("cus.crm.myaccounts.view.overview.MarketingAttributes - onDeleteMarketingAttributeClicked - ContextPath: "+oEvent.getSource().getBindingContext("mktattr").sPath);	

		var oMktAttributeContext = oEvent.getSource().getBindingContext("mktattr");
		var oMktAttribute = oMktAttributeContext.getObject();
		var lineNumber = oMktAttributeContext.sPath.substring(21);
		if(!oMktAttribute.eTag) {
			// new attribute; not yet send to the backend
			this._removeLine(lineNumber);
		}
		else {
			var sRequestURL = oMktAttribute.key;
			var oBatchOperation = this.getView().getModel().createBatchOperation(sRequestURL, "DELETE");	
			this._collectBatchOperation(oBatchOperation, this._onAfterSave, this._onAfterSaveWithError, lineNumber );
			oMktAttribute.mode = cus.crm.myaccounts.util.Constants.modeEdit; //needed because _removeCoherentErrorFlags will not consider this line. Also a solution with another mode like "deleteMode" would work
		}
		this._savePendingData();	//save other changed lines and sent all operations together
	},

	_removeLine: function(lineNumber) {
		var oMktAttrModel = this.getList().getModel("mktattr");
		var aMktAttributes = oMktAttrModel.getProperty("/MarketingAttributes");
		aMktAttributes.splice(lineNumber, 1);
		oMktAttrModel.setProperty("/MarketingAttributes", aMktAttributes);
	},

	onSaveMarketingAttributeClicked: function(oEvent) {
		jQuery.sap.log.debug("cus.crm.myaccounts.view.overview.MarketingAttributes - onSaveMarketingAttributeClicked - ContextPath: "+oEvent.getSource().getBindingContext("mktattr").sPath);
		this._savePendingData();
	},

	_savePendingData: function() {
		var oMktAttrModel = this.getList().getModel("mktattr");
		var aMktAttributes = oMktAttrModel.getProperty("/MarketingAttributes");
		for (var i in aMktAttributes){
			var oMktAttribute = aMktAttributes[i];
			if(oMktAttribute.mode === cus.crm.myaccounts.util.Constants.modeEdit){
				this._removeCoherentErrorFlags(oMktAttribute); //required to save attributes which collides with each other

				if(this._checkSaveNeeded(oMktAttribute)){
					if(this._checkSavePossible(oMktAttribute)){
						var oBindingContext = this.getView().getBindingContext();
						var editMode = oMktAttribute.eTag ? true : false;
						var sRequestURL, oBatchOperation;

						if(editMode) {
							sRequestURL = oMktAttribute.key;
							oBatchOperation = oBindingContext.getModel().createBatchOperation(sRequestURL, "PUT", this._getStripedAttribute(oMktAttribute), {contextPath: "/MarketingAttributes/"+i});
						} else {
							sRequestURL = oBindingContext.sPath+"/MarketingAttributes";
							oBatchOperation = oBindingContext.getModel().createBatchOperation(sRequestURL, "POST", this._getStripedAttribute(oMktAttribute), {contextPath: "/MarketingAttributes/"+i});
						}

						this._collectBatchOperation(oBatchOperation, this._onAfterSave, this._onAfterSaveWithError, oMktAttribute);
					}
				}
				else{
					delete oMktAttribute.mode;
					oMktAttribute.errorExists = false;
					this._setUIFieldType(oMktAttribute);
				}
			}
		}
		this._sendBatchOperations();
	},

	_collectBatchOperation: function(oBatchOperation, callBackSuccess, callBackError, callbackArguments){
		if(this.requestURIIncludedInQueue(oBatchOperation.requestUri))
			return;
		var oBatch = {operation:oBatchOperation, callBackSuccess:callBackSuccess, callBackError:callBackError, callbackArguments:callbackArguments };
		if (oBatchOperation.method === 'DELETE') {
		//  process DELETE operations first --> add oBatch on index 0
			this.aBatchOperations.unshift(oBatch);
		}
		else {
			this.aBatchOperations.push(oBatch);
		}
	},

	requestURIIncludedInQueue: function(requestUri){
		for(var i in this.aBatchOperations)
			if(this.aBatchOperations[i].operation.requestUri === requestUri)
				return true;
		return false;
	},

	_sendBatchOperations: function(){
		//some operations can be combined but saving changes should be separate because in batch either everything or nothing is saved
		if (!this.aBatchOperations.length){
			this.refreshUI();	//if the queue is empty, refresh UI
			this._setBusy(false);
			return;
		}
		var aBatchOperationsForProcessing = [];
		var that = this;
		var continueProcessing = true;
		var batchMethod = this.aBatchOperations[0].operation.method;
		var aBatchOperation = [];
		while (continueProcessing && this.aBatchOperations.length) {
			if(batchMethod === this.aBatchOperations[0].operation.method){
				aBatchOperationsForProcessing.push(this.aBatchOperations[0]);
				aBatchOperation.push(this.aBatchOperations[0].operation);
				this.aBatchOperations.splice(0, 1);
			}
			else{
				continueProcessing = false;
			}
		}
		var backendBatchRequestFunction = cus.crm.myaccounts.util.Util.sendBatchChangeOperations;
		if(batchMethod === 'GET')
			backendBatchRequestFunction = cus.crm.myaccounts.util.Util.sendBatchReadOperations;

		backendBatchRequestFunction(
			this.getView().getModel(), aBatchOperation,
			function(_aResponseObjects) {
				var aResponseObjects = _aResponseObjects;
				if(batchMethod === 'GET'){ //read delivers the response in different format
					aResponseObjects = [];
					for(var key in _aResponseObjects)
						aResponseObjects.push(_aResponseObjects[key]);
				}
				for(var i in aBatchOperationsForProcessing){
					if(aBatchOperationsForProcessing[i].callBackSuccess){
						var arguments = [];
						var oResponseObject = null;
						if(aResponseObjects.length > i)
							oResponseObject = aResponseObjects[i];
						arguments.push(aBatchOperationsForProcessing[i].operation);
						arguments.push(oResponseObject);
						if (aBatchOperationsForProcessing[i].callbackArguments instanceof Array) {
							arguments = $.merge(arguments, aBatchOperationsForProcessing[i].callbackArguments);
						}
						else {
							arguments.push(aBatchOperationsForProcessing[i].callbackArguments);
						}
						aBatchOperationsForProcessing[i].callBackSuccess.apply(that,arguments);
					}
				}
				that._sendBatchOperations();
			},
			function(oError) {
				for(var i in aBatchOperationsForProcessing){
					if(aBatchOperationsForProcessing[i].callBackError){
						var arguments = [];
						arguments.push(aBatchOperationsForProcessing[i].operation);
						arguments.push(oError);
						if (aBatchOperationsForProcessing[i].callbackArguments instanceof Array) {
							arguments = $.merge(arguments, aBatchOperationsForProcessing[i].callbackArguments);
						}
						else {
							arguments.push(aBatchOperationsForProcessing[i].callbackArguments);
						}
						aBatchOperationsForProcessing[i].callBackError.apply(that, arguments);
					}
				}
				that.refreshUI();
			}
		);
	},

	_setBusy: function(busy) {
		if(!this.oBusyDialog)
			this.oBusyDialog = new sap.m.BusyDialog();
		if(busy)
			this.oBusyDialog.open();
		else
			this.oBusyDialog.close();
	},

	_getStripedAttribute: function(oMktAttr) {
	    var oMktAttribute = jQuery.extend({}, oMktAttr);
	    delete oMktAttribute.key;
		delete oMktAttribute.mode;
		delete oMktAttribute.mktAttrValues;
		delete oMktAttribute.fieldType;
		delete oMktAttribute.value;
		delete oMktAttribute.attribute;
		delete oMktAttribute.attributeSet;
		delete oMktAttribute.errorExists;
		return oMktAttribute;
	},

	_checkSavePossible: function(oMktAttribute) {
		return (oMktAttribute.attributeSetID && oMktAttribute.attributeID && oMktAttribute.valueID && !oMktAttribute.errorExists);
	},

	_checkSaveNeeded: function(oMktAttribute) {
		if(oMktAttribute.key) {
			// Key contains old values, therefore split key to get old marketing attribute values and compare with changed values
			var aMktAttributeIDs	= oMktAttribute.key.split("'");
			var oldAttributeSetID	= aMktAttributeIDs[3];
			var oldAttributeID		= aMktAttributeIDs[5];
			var oldValueID			= aMktAttributeIDs[7];
			// Decode old value instead of encoding of new value, because encodeURIComponent does not encode the characters *~!()'
			return (oMktAttribute.attributeSetID				!== oldAttributeSetID	||
					oMktAttribute.attributeID					!== oldAttributeID		||
					oMktAttribute.valueID						!== decodeURIComponent(oldValueID));
		} else { // empty line -> save needed
			return true;
		}
	},

	_onAfterSave: function(oBatchOperation, oResponseObject, callbackArgument) {
		switch(oBatchOperation.method) {
			case "DELETE":
				//after delete remove line in table
				var lineNumber = callbackArgument;
				this._removeLine(lineNumber);
				return;
			case "POST":
				//after create update the new attributes received from backend and update the key
				var oMktAttribute = callbackArgument;
				delete oMktAttribute.mode;
				this._setUIFieldType(oMktAttribute);
				this._copyAttributesOfObject2ToObject1(oMktAttribute, oResponseObject);
				oMktAttribute.key = "MarketingAttributeCollection(accountID='"+oMktAttribute.accountID+"',attributeSetID='"+oMktAttribute.attributeSetID+"',attributeID='"+oMktAttribute.attributeID+"',valueID='"+encodeURIComponent(oMktAttribute.valueID)+"')";
				if (oMktAttribute.mktAttrValues.length === 1){
					oMktAttribute.mktAttrValues = [{valueID: oMktAttribute.valueID, value:oMktAttribute.value}];   //update value ID
				}
				break;
			case "PUT":
				//after change reread the entity.
				var oMktAttribute = callbackArgument;
				delete oMktAttribute.mode;
				this._setUIFieldType(oMktAttribute);
				oMktAttribute.key = /(Marketing).+valueID='/gi.exec(oMktAttribute.key)[0]+encodeURIComponent(oMktAttribute.valueID)+"')"; //after every change the key is changed
				this.rereadMarketingAttribute(oMktAttribute);
				break;
		}
	},

	_onAfterSaveWithError: function(oBatchOperation, oError, oMktAttribute){
		switch(oBatchOperation.method) {
			case "DELETE":
				break;
			case "POST":
				oMktAttribute.errorExists = true;
				break;
			case "PUT":
				oMktAttribute.errorExists = true;
				break;
		}

		if(this["_onAfterSaveHandleErrorCode_"+oError.statusCode])
			this["_onAfterSaveHandleErrorCode_"+oError.statusCode](oError);
		else {
			sap.m.MessageBox.alert(oError.message.value);
		}
	},

	_onAfterSaveHandleErrorCode_400: function(oError) {
		for (var i in oError.innererror.errordetails){
			if (oError.innererror.errordetails[i].code === "CRM_BUPA_ODATA/026"){ //data has changes by other user
				sap.m.MessageBox.alert(cus.crm.myaccounts.util.Util.geti18NText("MSG_CONFLICTING_DATA_WITH_REFRESH"));
				return;
			}
		}
		sap.m.MessageBox.alert(oError.message.value);
	},

	// **** Suggestion for Marketing Attribute and  Marketing Attribute Set **********************************************
	onSuggestItem: function(oEvent) {
		jQuery.sap.log.debug("cus.crm.myaccounts.view.overview.MarketingAttributes - onSuggestItem");
		var oInputField = oEvent.getSource();
		var newSearchString = oEvent.getSource().getValue();
		if(!newSearchString)
			return;
		var oldSearchString = oInputField.usedSearchString ? oInputField.usedSearchString : "";
		var contextPath = oEvent.getSource().getBindingContext("mktattr").sPath;

		var oModel = this.getView().getModel();
		var oMktAttrModel = this.getList().getModel("mktattr");
		var attributeSetID = oMktAttrModel.getProperty(contextPath+"/attributeSetID");
		var accountCategory = oModel.getProperty(this.getView().getBindingContext().sPath+"/category");
		var attributeSetInputField = oInputField.getId().indexOf("attributeSetInput") === -1 ? false : true;

		//Do no search if the search string has been restricted
		if(oldSearchString.length && newSearchString.indexOf(oldSearchString) === 0)
			return;

		oInputField.removeAllSuggestionItems();
		var fnCheckMarketingAttribute = function(aCustMarketingAttributes, arguments){
			oInputField.removeAllSuggestionItems();
			oInputField.usedSearchString = arguments.newSearchString;
			for(var i=0; i<aCustMarketingAttributes.length; i++){
				var oCustMarketingAttribute = aCustMarketingAttributes[i];
				var compareString = attributeSetInputField ? oCustMarketingAttribute.attributeSet.toUpperCase() : oCustMarketingAttribute.attribute.toUpperCase();
				if (compareString === oInputField.usedSearchString.toUpperCase()){
					var oMarketingAttribute = oMktAttrModel.getProperty(contextPath);
					oMarketingAttribute.mktAttrValues = null;
					oMarketingAttribute.valueID = "";
					oMarketingAttribute.value = "";
					this._copyAttributesOfObject2ToObject1(oMarketingAttribute, oCustMarketingAttribute);
					this._readAttributeValuesForSelect(oMarketingAttribute);
				}
				var oItem;
				if(attributeSetInputField){
					oItem = new sap.ui.core.Item({text:oCustMarketingAttribute.attributeSet});
					oItem.addCustomData(new sap.ui.core.CustomData({key:"oMarketingAttributeSet", value:oCustMarketingAttribute}));
				}
				else{
					oItem = new sap.ui.core.Item({text:oCustMarketingAttribute.attribute});
					oItem.addCustomData(new sap.ui.core.CustomData({key:"oMarketingAttribute", value:oCustMarketingAttribute}));
				}
				oItem.addCustomData(new sap.ui.core.CustomData({key:"contextPath", value:contextPath}));
				oInputField.addSuggestionItem(oItem);
			}
		};
		var aFilters = [];
		if(attributeSetInputField){ //Filters for attributeSetInput
			if (accountCategory)
				aFilters.push(new sap.ui.model.Filter("category", sap.ui.model.FilterOperator.EQ, accountCategory));
			aFilters.push(new sap.ui.model.Filter("attributeSet", sap.ui.model.FilterOperator.StartsWith, encodeURIComponent(newSearchString)));
			this._readMarketingAttributeSet(aFilters,fnCheckMarketingAttribute, {newSearchString: newSearchString});
		}
		else{ //Filters for attributeInput
			if(attributeSetID && this.byId("attributeSetCol").getVisible())
				aFilters.push(new sap.ui.model.Filter("attributeSetID", sap.ui.model.FilterOperator.EQ, attributeSetID));
			else if (accountCategory)
				aFilters.push(new sap.ui.model.Filter("category", sap.ui.model.FilterOperator.EQ, accountCategory));
			aFilters.push(new sap.ui.model.Filter("attribute", sap.ui.model.FilterOperator.StartsWith, encodeURIComponent(newSearchString)));
			this._readMarketingAttributes(aFilters,fnCheckMarketingAttribute, {newSearchString: newSearchString});
		}
	},

	onSuggestItemSelected: function(oEvent){
		jQuery.sap.log.debug("cus.crm.myaccounts.view.overview.MarketingAttributes - onSuggestItemSelected");
		var oItem = oEvent.getParameter("selectedItem");
		var oCustMarketingAttribute = null;
		var oCustMarketingAttributeSet = null;
		var oMarketingAttribute = null;
		var contextPath = null;

		for(var i in oItem.getCustomData()){
			var oCustomData = oItem.getCustomData()[i];
			if (oCustomData.getKey() === "oMarketingAttribute")
				oCustMarketingAttribute = oCustomData.getValue();
			if (oCustomData.getKey() === "oMarketingAttributeSet")
				oCustMarketingAttributeSet = oCustomData.getValue();
			if (oCustomData.getKey() === "contextPath")
				contextPath = oCustomData.getValue();
		}

		oMarketingAttribute = this.getList().getModel("mktattr").getProperty(contextPath);
		if(oCustMarketingAttributeSet){
			oMarketingAttribute.attributeID = "";
			oMarketingAttribute.attribute = "";
			oMarketingAttribute.attributeDatatype = "";
		}
		oMarketingAttribute.mktAttrValues = null;
		oMarketingAttribute.valueID = "";
		oMarketingAttribute.value = "";
		this._copyAttributesOfObject2ToObject1(oMarketingAttribute, oCustMarketingAttribute);
		this._copyAttributesOfObject2ToObject1(oMarketingAttribute, oCustMarketingAttributeSet);
		if(oCustMarketingAttribute)
			this._readAttributeValuesForSelect(oMarketingAttribute);
	},

	_readMarketingAttributes: function(aFilters, callbackRead, callbackArguments) {
		var that = this;
		that.getList().getModel().read("/CustomizingMarketingAttributeCollection", {filters: aFilters, success:
			function(oData){
				var marketingAttributeData = jQuery.parseJSON(JSON.stringify(oData));
				if (callbackRead)
					callbackRead.apply(that,[marketingAttributeData.results, callbackArguments]);
			}, error:
			function(oError){
				jQuery.sap.log.error("Read failed in MarketingAttributes->_readMarketingAttribute:"+oError.response.body);
			}
		}
	);
	},

	_readMarketingAttributeSet: function(aFilters, callbackRead, callbackArguments) {
		var that = this;
		that.getList().getModel().read("/CustomizingMarketingAttrSetCollection", {filters: aFilters, success:
			function(oData){
				var marketingAttributeData = jQuery.parseJSON(JSON.stringify(oData));
				if (callbackRead)
					callbackRead.apply(that, [marketingAttributeData.results, callbackArguments]);
			}, error:
			function(oError){
				jQuery.sap.log.error("Read failed in MarketingAttributes->_readMarketingAttributeSet:"+oError.response.body);
			}
		}
		);
	},

	onEditMarketingAttributeClicked: function(oEvent) {
		jQuery.sap.log.debug("cus.crm.myaccounts.view.overview.MarketingAttributes - onEditMarketingAttributeClicked");

		this._savePendingData();

		var oMktAttrContext = oEvent.getSource().getBindingContext("mktattr");
		var oMktAttr = oMktAttrContext.getObject();
		oMktAttr.mode = cus.crm.myaccounts.util.Constants.modeEdit;

		if(oMktAttr.valueRestricted || oMktAttr.hasChecktable) {
			this._readAttributeValuesForSelect(oMktAttr);
		}else{
			this._setAttributeValues(oMktAttr);
			this._setUIFieldType(oMktAttr);
			this.refreshUI();
		}
	},

	_readAttributeValuesForSelect: function(oMktAttribute){
		var oCustomizingMktAttrContext = new sap.ui.model.Context(this.getList().getModel(), "/CustomizingMarketingAttributeCollection(attributeSetID='" + oMktAttribute.attributeSetID + "',attributeID='"+ oMktAttribute.attributeID +"')");
		var that = this;
		cus.crm.myaccounts.util.Util.readODataObjects(oCustomizingMktAttrContext, "MarketingAttributeValues", null,
			function(aValues) {
				that._setAttributeValues(oMktAttribute, aValues);
				that._setUIFieldType(oMktAttribute);
				that.refreshUI();
			}
		);
	},

	onInputFieldChanged: function(oEvent) {
		var oMktAttribute = oEvent.getSource().getBindingContext("mktattr").getObject();
		oMktAttribute.errorExists = false;
		oMktAttribute.value = oEvent.getSource().getValue();
		oMktAttribute.valueID = oEvent.getSource().getValue();
		oMktAttribute.mktAttrValues = [{valueID: oMktAttribute.valueID, value:oMktAttribute.value}];
	},

	onSelectValueChanged: function(oEvent) {
		var oMktAttribute = oEvent.getSource().getBindingContext("mktattr").getObject();
		oMktAttribute.errorExists = false;
		oMktAttribute.value = oEvent.getSource().getSelectedItem().getText();
		if (oMktAttribute.attributeDatatype === cus.crm.myaccounts.util.Constants.dataTypeDATE) {
			// update dateValue (if it is an interval, dateValue is set to null)
			oMktAttribute.dateValue = cus.crm.myaccounts.util.formatter.convertDateStringToUTC( oMktAttribute.value );
		}
	},

	onDateInputFieldChanged:function (oEvent) {
		var oMktAttribute = oEvent.getSource().getBindingContext("mktattr").getObject();
		oMktAttribute.errorExists = false;
		oMktAttribute.dateValue = cus.crm.myaccounts.util.formatter.convertDateToUTC( oMktAttribute.dateValue );
		if (oMktAttribute.dateValue){
			//fill VALUE ID with the value YYYYMMDD
			oMktAttribute.valueID = oMktAttribute.dateValue.toISOString().slice(0,10).replace(/-/g,"");
			oMktAttribute.mktAttrValues = [{valueID: oMktAttribute.valueID, value:oMktAttribute.value}];
		}
	},

	onTimeInputFieldChanged:function (oEvent) {
		var oMktAttribute = oEvent.getSource().getBindingContext("mktattr").getObject();
		oMktAttribute.errorExists = false;
		//Fill value ID with the value  hh:mm:ss
		var dateValue = oEvent.getSource().getDateValue();
		if (dateValue) {
			oMktAttribute.valueID = dateValue.toTimeString().slice(0,8);
			oMktAttribute.mktAttrValues = [{valueID: oMktAttribute.valueID, value:oMktAttribute.value}];
		}
	},

	_removeCoherentErrorFlags: function(oMktAttribute){
		var errorFlagRemoved = false;
		var aMktAttributes = this.getList().getModel("mktattr").getProperty("/MarketingAttributes");
		for(var i in aMktAttributes){
			if(aMktAttributes[i].mode === cus.crm.myaccounts.util.Constants.modeEdit && aMktAttributes[i].attributeID === oMktAttribute.attributeID && aMktAttributes[i] !== oMktAttribute){
				aMktAttributes[i].errorExists = false;
				errorFlagRemoved = true;
			}
		}
		if(errorFlagRemoved){
			oMktAttribute.errorExists = false;
		}
	},

	rereadMarketingAttribute: function(oMktAttribute){
		var that = this;
		if (oMktAttribute.hasChecktable || oMktAttribute.valueRestricted || (oMktAttribute.mktAttrValues && oMktAttribute.mktAttrValues.length > 1))
			return; //no need to reread DDLB
		if(oMktAttribute.attributeDatatype === cus.crm.myaccounts.util.Constants.dataTypeNUM ||
		   oMktAttribute.attributeDatatype === cus.crm.myaccounts.util.Constants.dataTypeCURR){
			var oBatchOperation = that.getView().getModel().createBatchOperation("/"+oMktAttribute.key, "GET");
			this._collectBatchOperation(oBatchOperation,
				function(oBatchOperation, oResponseObject, oMktAttribute) {
					that._copyAttributesOfObject2ToObject1(oMktAttribute, oResponseObject);
					oMktAttribute.key = /(Marketing).+valueID='/gi.exec(oMktAttribute.key)[0]+encodeURIComponent(oResponseObject.valueID)+"')";
					if (oMktAttribute.mktAttrValues.length === 1){
						oMktAttribute.mktAttrValues = [{valueID: oMktAttribute.valueID, value:oMktAttribute.value}];  //update value ID
					}
				},
				function() {

				},
				oMktAttribute
				);
		}
	},

	refreshUI: function(){
		var oMktAttrModel = this.getList().getModel("mktattr");
		var aMktAttributes = oMktAttrModel.getProperty("/MarketingAttributes");
		oMktAttrModel.setProperty("/MarketingAttributes", aMktAttributes);
	},

	// *** Value Help for Marketing Attribute ******************************************
	onMarketingAttributeValueHelpSelected: function(oEvent) {
		jQuery.sap.log.debug("cus.crm.myaccounts.view.overview.MarketingAttributes - onMarketingAttributeValueHelpSelected");
		var oModel = this.getView().getModel();
		var oBindingContext = this.getView().getBindingContext();
		var accountCategory = oModel.getProperty(oBindingContext.sPath).category;
		var oMktAttribute = oEvent.getSource().getBindingContext("mktattr").getObject();

		this.valueHelpMarketingAttribute = sap.ui.xmlfragment( "cus.crm.myaccounts.view.maintain.ValueHelpMarketingAttribute", this);
		this.valueHelpMarketingAttribute.oMktAttribute  = oMktAttribute ;

		var aFilters = [];
		// In case an attribute set ID is set and this is visible for the user,
		// i.e., the column for attribute set is visible, filter by the given
		// attribute set ID. Otherwise, filter by category of account.
		if(oMktAttribute.attributeSetID && this.byId("attributeSetCol").getVisible()) {
			aFilters.push(new sap.ui.model.Filter("attributeSetID", sap.ui.model.FilterOperator.EQ, oMktAttribute.attributeSetID));
		} else if (accountCategory) {
			aFilters.push(new sap.ui.model.Filter("category", sap.ui.model.FilterOperator.EQ, accountCategory));
		}

		this.valueHelpMarketingAttribute.bindAggregation("items", {
			path : '/CustomizingMarketingAttributeCollection',
			template : this.valueHelpMarketingAttribute.getItems()[0].clone(),
			filters : aFilters,
			sorter : new sap.ui.model.Sorter("attribute", false)
		});

		this.valueHelpMarketingAttribute.setModel(this.getList().getModel("i18n"), "i18n");
		this.valueHelpMarketingAttribute.setModel(this.getView().getModel());

		//Ux requirement : Display "Loading..." as no data text when searching
		this.getView().getModel().attachRequestSent(
				function() {
					if(this._list) {
						this._list.setNoDataText(cus.crm.myaccounts.util.Util.geti18NText("LOADING_TEXT"));
					}
				},
				this.valueHelpMarketingAttribute
		);
		this.getView().getModel().attachRequestCompleted(
				function() {
					if(this._list) {
						this._list.setNoDataText(cus.crm.myaccounts.util.Util.geti18NText("NO_DATA_TEXT"));
					}
				},
				this.valueHelpMarketingAttribute
		);

		this.valueHelpMarketingAttribute.open();
	},

	onMarketingAttributeValueHelpSearch: function(oEvent) {
		var searchValue = oEvent.getParameter("value");
		jQuery.sap.log.debug("cus.crm.myaccounts.view.overview.MarketingAttributes - onMarketingAttributeValueHelpSearch - Search value: " + searchValue);
	    var oFilter = new sap.ui.model.Filter("attribute", sap.ui.model.FilterOperator.Contains, searchValue);
	    oEvent.getSource().getBinding("items").filter([oFilter]);
	},

	onMarketingAttributeValueHelpClose: function(oEvent) {
		jQuery.sap.log.debug("cus.crm.myaccounts.view.overview.MarketingAttributes - onMarketingAttributeValueHelpClose");
		var oSelectedItem = oEvent.getParameter("selectedItem");
		if (oSelectedItem) {
			var oSelectedObject = oSelectedItem.getBindingContext().getObject();
			var oMktAttr = this.valueHelpMarketingAttribute.oMktAttribute;
			oMktAttr.mktAttrValues = null;
			oMktAttr.valueID = "";
			oMktAttr.value = "";
			this._copyAttributesOfObject2ToObject1(oMktAttr, oSelectedObject);
			this._readAttributeValuesForSelect(oMktAttr);
		}
	},

	onMarketingAttributeValueHelpCancel: function(oEvent) {
		jQuery.sap.log.debug("cus.crm.myaccounts.view.overview.MarketingAttributes - onMarketingAttributeValueHelpCancel");
    	if(oEvent.getSource().getBinding("items").aFilters.length) {
	    	oEvent.getSource().destroyItems();
	    }
	},

	// *** Value Help for Marketing Attribute Set ******************************************
	onMarketingAttributeSetValueHelpSelected: function(oEvent) {
		jQuery.sap.log.debug("cus.crm.myaccounts.view.overview.MarketingAttributes - onMarketingAttributeSetValueHelpSelected");
		var oModel = this.getView().getModel();
		var oBindingContext = this.getView().getBindingContext();
		var accountCategory = oModel.getProperty(oBindingContext.sPath).category;

		this.valueHelpMarketingAttributeSet = sap.ui.xmlfragment( "cus.crm.myaccounts.view.maintain.ValueHelpMarketingAttributeSet", this);
		this.valueHelpMarketingAttributeSet.mktAttrContextPath = oEvent.getSource().getBindingContext("mktattr").sPath;
		this.valueHelpMarketingAttributeSet.oMktAttribute = oEvent.getSource().getBindingContext("mktattr").getObject();

		var aFilters = [];
		if (accountCategory) {
			aFilters.push(new sap.ui.model.Filter("category", sap.ui.model.FilterOperator.EQ, accountCategory)); //"'"+ accountCategory +"'"
		}

		this.valueHelpMarketingAttributeSet.bindAggregation("items", {
			path : '/CustomizingMarketingAttrSetCollection',
			template : this.valueHelpMarketingAttributeSet.getItems()[0].clone(),
			filters : aFilters,
			sorter : new sap.ui.model.Sorter("attributeSet", false)
		});

		this.valueHelpMarketingAttributeSet.setModel(this.getList().getModel("i18n"), "i18n");
		this.valueHelpMarketingAttributeSet.setModel(this.getView().getModel());

		//Ux requirement : Display "Loading..." as no data text when searching
		this.getView().getModel().attachRequestSent(
				function() {
					if(this._list) {
						this._list.setNoDataText(cus.crm.myaccounts.util.Util.geti18NText("LOADING_TEXT"));
					}
				},
				this.valueHelpMarketingAttributeSet);
		this.getView().getModel().attachRequestCompleted(
				function() {
					if(this._list) {
						this._list.setNoDataText(cus.crm.myaccounts.util.Util.geti18NText("NO_DATA_TEXT"));
					}
				},
				this.valueHelpMarketingAttributeSet);

		this.valueHelpMarketingAttributeSet.open();
	},
	
	onMarketingAttributeSetValueHelpSearch: function(oEvent) {
		var searchValue = oEvent.getParameter("value");
		jQuery.sap.log.debug("cus.crm.myaccounts.view.overview.MarketingAttributes - onMarketingAttributeSetValueHelpSearch - Search value: " + searchValue);
	    var oFilter = new sap.ui.model.Filter("attributeSet", sap.ui.model.FilterOperator.Contains, searchValue);
	    oEvent.getSource().getBinding("items").filter([oFilter]);
	},

	onMarketingAttributeSetValueHelpClose: function(oEvent) {
		jQuery.sap.log.debug("cus.crm.myaccounts.view.overview.MarketingAttributes - onMarketingAttributeSetValueHelpClose");
		var oSelectedItem = oEvent.getParameter("selectedItem");
		if (oSelectedItem) {
			var oSelectedObject = this._generateTemplateForMarketingAttribute(oSelectedItem.getBindingContext().getObject());
			var oMktAttr = this.valueHelpMarketingAttributeSet.oMktAttribute;
			if(oSelectedObject.attributeSetID === oMktAttr.attributeSetID)
				return;
			this._copyAttributesOfObject2ToObject1(oMktAttr, oSelectedObject);
			oMktAttr.mode = cus.crm.myaccounts.util.Constants.modeEdit;
			this.refreshUI();
		}
	},

	onMarketingAttributeSetValueHelpCancel: function(oEvent) {
		jQuery.sap.log.debug("cus.crm.myaccounts.view.overview.MarketingAttributes - onMarketingAttributeSetValueHelpCancel");
    	if(oEvent.getSource().getBinding("items").aFilters.length) {
	    	oEvent.getSource().destroyItems();
	    }
	},
	
	// *** Footer buttons - add ******************************************
	getFooterButtons: function() {
		var that = this;
		return [{
			sIcon:"sap-icon://add",
			sTooltip: cus.crm.myaccounts.util.Util.geti18NText("ADD_MARKETING_ATTRIBUTE_TOOLTIP"),
			sId : "addButton",
			onBtnPressed:function () {
				that.onAddMarketingAttributeClicked();
			}
		}];
	},

	_unsavedDataExists: function() {
		var oMktAttrModel = this.getList().getModel("mktattr");
		var aMktAttributes = oMktAttrModel.getProperty("/MarketingAttributes");
		for (var i in aMktAttributes){
			var oMktAttr = aMktAttributes[i];
			if(this._checkSaveNeeded(oMktAttr)){
				return true;
			}
		}
		return false;
	},

	onBeforeClose: function(callBackFunction) {
		jQuery.sap.log.debug("cus.crm.myaccounts.view.overview.MarketingAttributes - onBeforeClose");
		var that = this;
		if (this._unsavedDataExists()){
			sap.m.MessageBox.confirm(
				cus.crm.myaccounts.util.Util.geti18NText("MSG_CONFIRM_CANCEL"),
				jQuery.proxy(function (confirmed) {
					if (confirmed === "OK") {
						that.getList().getModel("mktattr").setProperty("/MarketingAttributes", []);
						that.getView().setBindingContext(null);
						callBackFunction.call();
					}
				}, this)
			);
			return false;
		}
		return true;
	},

	onCleanUp: function() {
		jQuery.sap.log.debug("cus.crm.myaccounts.view.overview.MarketingAttributes - onCleanUp");
		this.aBatchOperations = [];
		//put all lines to display mode:
		var oMktAttrModel = this.getList().getModel("mktattr");
		if(!oMktAttrModel)
			return;
		var aMktAttributes = oMktAttrModel.getProperty("/MarketingAttributes");
		for (var i in aMktAttributes){
			var oMktAttribute = aMktAttributes[i];
			if(oMktAttribute.mode === cus.crm.myaccounts.util.Constants.modeEdit){
				if(this._checkSaveNeeded(oMktAttribute)){ //this happens only in case of browser back/forward navigation where no dataloss is triggered. In such case simply reset data
					this.getList().getModel("mktattr").setProperty("/MarketingAttributes", []);
					this.getView().setBindingContext(null);
					return;
				}
				else{
					delete oMktAttribute.mode;
					oMktAttribute.errorExists = false;
					this._setUIFieldType(oMktAttribute);
				}
			}
		}
		this.refreshUI();
	}

/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf view.MarketingAttributes
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf view.MarketingAttributes
*/
//	onAfterRendering: function() {
//
//	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf view.MarketingAttributes
*/
//	onExit: function() {
//
//	}

});
},
	"cus/crm/myaccounts/view/overview/MarketingAttributes.view.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core" xmlns:mvc="sap.ui.core.mvc" xmlns="sap.m" xmlns:layout="sap.ui.layout"\n\t\t\tcontrollerName="cus.crm.myaccounts.view.overview.MarketingAttributes" xmlns:html="http://www.w3.org/1999/xhtml">\n\n\t<Table\n\t\tid="list"\n\t\tgrowing="true"\n\t\tgrowingThreshold="10"\n\t\tgrowingScrollToLoad="false"\n\t\titems="{path: \'mktattr>/MarketingAttributes\'}">\n\t\t<columns>\n\t\t\t<Column id="attributeSetCol" width="16rem" minScreenWidth="Small" demandPopin="true" visible="false"><Label text="{i18n>ATTRIBUTESET}"/></Column>\n\t\t\t<Column id="attributeCol" width="16rem" minScreenWidth="Small" demandPopin="true"><Label text="{i18n>ATTRIBUTE}" /></Column>\n\t\t\t<Column id="valueCol" width="16rem" minScreenWidth="Medium" demandPopin="true"><Label text="{i18n>VALUE}" /></Column>\n\t\t\t<Column id="actions" width="3rem" minScreenWidth="XLarge" demandPopin="true"><Text text="{i18n>ACTIONS}" /></Column>\n\t\t</columns>\n\t\t<items>\n\t\t\t<ColumnListItem id="columnListItem">\n\t\t\t\t<cells>\n\t\t\t\t\t<Input value="{mktattr>attributeSet}"\n\t\t\t\t\t\tid="attributeSetInput"\n\t\t\t\t\t\teditable="{parts:[{path:\'mktattr>eTag\'}],formatter:\'cus.crm.myaccounts.util.formatter.isInitial\'}"\n\t\t\t\t\t\tshowValueHelp="true"\n\t\t\t\t\t\tvalueHelpOnly="false"\n\t\t\t\t\t\tvalueHelpRequest="onMarketingAttributeSetValueHelpSelected"\n\t\t\t\t\t\tshowSuggestion="true"\n\t\t\t\t\t\tsuggest="onSuggestItem"\n\t\t\t\t\t\tsuggestionItemSelected="onSuggestItemSelected"\n\t\t\t\t\t\twidth="75%"/>\n\t\t\t\t\t<Input value="{mktattr>attribute}"\n\t\t\t\t\t\tid="attributeInput"\n\t\t\t\t\t\teditable="{parts:[{path:\'mktattr>eTag\'}],formatter:\'cus.crm.myaccounts.util.formatter.isInitial\'}"\n\t\t\t\t\t\tshowValueHelp="true"\n\t\t\t\t\t\tvalueHelpOnly="false"\n\t\t\t\t\t\tvalueHelpRequest="onMarketingAttributeValueHelpSelected"\n\t\t\t\t\t\tshowSuggestion="true"\n\t\t\t\t\t\tsuggest="onSuggestItem"\n\t\t\t\t\t\tsuggestionItemSelected="onSuggestItemSelected"\n\t\t\t\t\t\twidth="75%"/>\n\n\t\t\t\t\t<layout:VerticalLayout width="100%">\n\t\t\t\t\t\t<!-- <core:Icon src="sap-icon://alert" color="#cc1919" size="1.3rem" visible="{parts:[{path:\'mktattr>errorExists\'}],formatter:\'cus.crm.myaccounts.util.formatter.isNotInitial\'}"/>  -->\n\t\t\t\t\t\t<Input value="{mktattr>valueID}"\n\t\t\t\t\t\t\tvisible="false"/>\n\n\t\t\t\t\t\t<!-- Default Input Field -->\n\t\t\t\t\t\t<Input id="valueInput"\n\t\t\t\t\t\t\tvalue="{parts:[{path:\'mktattr>valueID\'}, {path:\'mktattr>value\'}, {path:\'mktattr>attributeDatatype\'}, {path:\'mktattr>decimalPlaces\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatMktAttrDisplayField\'}"\n\t\t\t\t\t\t\teditable="{parts:[{path:\'mktattr>mode\'}, \'constants>/modeEdit\'],formatter:\'cus.crm.myaccounts.util.formatter.isEqual\'}"\n\t\t\t\t\t\t\tvisible="{parts:[{path:\'mktattr>fieldType\'}, \'constants>/fieldInput\'],formatter:\'cus.crm.myaccounts.util.formatter.isEqual\'}"\n\t\t\t\t\t\t\tliveChange="onInputFieldChanged"\n\t\t\t\t\t\t\tmaxLength="30"\n\t\t\t\t\t\t\twidth="75%"/>\n\n\t\t\t\t\t\t<!-- Date Field -->\n\t\t\t\t\t\t<DatePicker value="{path:\'mktattr>dateValue\', type:\'sap.ui.model.type.Date\', formatOptions: { style: \'medium\'}}"\n\t\t\t\t\t\t\tid="valueDATEInput"\n\t\t\t\t\t\t\teditable="{parts:[{path:\'mktattr>mode\'}, \'constants>/modeEdit\'],formatter:\'cus.crm.myaccounts.util.formatter.isEqual\'}"\n\t\t\t\t\t\t\tvisible="{parts:[{path:\'mktattr>fieldType\'}, \'constants>/fieldDate\'],formatter:\'cus.crm.myaccounts.util.formatter.isEqual\'}"\n\t\t\t\t\t\t\tchange="onDateInputFieldChanged"\n\t\t\t\t\t\t\tdisplayFormat="medium"\n\t\t\t\t\t\t\twidth="75%"/>\n\n\t\t\t\t\t\t<!-- Currency Field -->\n\t\t\t\t\t\t<Input id="valueCURRInput"\n\t\t\t\t\t\t\tvalue="{parts:[ {path:\'mktattr>valueID\'}, {path:\'mktattr>decimalPlaces\'}, {path:\'mktattr>currency\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatMktAttrAmountInterval\'}"\n\t\t\t\t\t\t\teditable="{parts:[{path:\'mktattr>mode\'}, \'constants>/modeEdit\'],formatter:\'cus.crm.myaccounts.util.formatter.isEqual\'}"\n\t\t\t\t\t\t\tvisible="{parts:[{path:\'mktattr>fieldType\'}, \'constants>/fieldCurrency\'],formatter:\'cus.crm.myaccounts.util.formatter.isEqual\'}"\n\t\t\t\t\t\t\tchange="onInputFieldChanged"\n\t\t\t\t\t\t\twidth="75%"/>\n\n\t\t\t\t\t\t<!-- Time Field -->\n\t\t\t\t\t\t<DateTimeInput type="Time"\n\t\t\t\t\t\t\tvalue="{parts:[ {path:\'mktattr>value\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatMktAttrTime\'}"\n\t\t\t\t\t\t\tid="valueTIMEInput"\n\t\t\t\t\t\t\teditable="{parts:[{path:\'mktattr>mode\'}, \'constants>/modeEdit\'],formatter:\'cus.crm.myaccounts.util.formatter.isEqual\'}"\n\t\t\t\t\t\t\tvisible="{parts:[{path:\'mktattr>fieldType\'}, \'constants>/fieldTime\'],formatter:\'cus.crm.myaccounts.util.formatter.isEqual\'}"\n\t\t\t\t\t\t\tchange="onTimeInputFieldChanged"\n\t\t\t\t\t\t\twidth="75%"/>\n\n\t\t\t\t\t\t<!-- Select for edit mode -->\n\t\t\t\t\t\t<!-- Used for CHAR, NUM, CURR, DATE, TIME, CHEC -->\n\t\t\t\t\t\t<Select id="select"\n\t\t\t\t\t\t\titems="{path:\'mktattr>mktAttrValues\'}"\n\t\t\t\t\t\t\tselectedKey="{mktattr>valueID}"\n\t\t\t\t\t\t\tenabled="true"\n\t\t\t\t\t\t\tchange="onSelectValueChanged"\n\t\t\t\t\t\t\tvisible="{parts:[{path:\'mktattr>fieldType\'}, \'constants>/fieldSelect\'],formatter:\'cus.crm.myaccounts.util.formatter.isEqual\'}"\n\t\t\t\t\t\t\twidth="75%">\n\t\t\t\t\t\t\t<core:Item \tkey="{mktattr>valueID}" \n\t\t\t\t\t\t\t\t\t\ttext="{mktattr>value}"/>\n\t\t\t\t\t\t</Select>\n\t\t\t\t\t</layout:VerticalLayout>\n\n\t\t\t\t\t<layout:HorizontalLayout>\n\t\t\t\t\t\t<core:Icon src="sap-icon://edit" id="actionEdit" size="1.3rem" press="onEditMarketingAttributeClicked" visible="{parts:[{path:\'mktattr>mode\'}, \'constants>/modeEdit\'],formatter:\'cus.crm.myaccounts.util.formatter.isUnequal\'}"/>\n\t\t\t\t\t\t<core:Icon src="sap-icon://save" id="actionSave" size="1.3rem" press="onSaveMarketingAttributeClicked" visible="{parts:[{path:\'mktattr>mode\'}, \'constants>/modeEdit\'],formatter:\'cus.crm.myaccounts.util.formatter.isEqual\'}"/>\n\t\t\t\t\t\t<layout:HorizontalLayout class="cusMyAccountsPaddingLeft" />\n\t\t\t\t\t\t<core:Icon src="sap-icon://delete" id="actionDelete" size="1.3rem"  press="onDeleteMarketingAttributeClicked" visible="true"/>\n\t\t\t\t\t</layout:HorizontalLayout>\n\n\t\t\t\t</cells>\n\t\t\t</ColumnListItem>\n\t\t</items>\n\t</Table>\n</core:View>\n',
	"cus/crm/myaccounts/view/overview/Notes.controller.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.ui.message.message");
sap.ui.controller("cus.crm.myaccounts.view.overview.Notes", {

	/**
	* Called when a controller is instantiated and its View controls (if available) are already created.
	* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
	* @memberOf view.Leads
	*/

	onInit: function() {
		// Execute method handleNavTo if app navigates to view.Leads
		// this.oRouter.attachRouteMatched(this.handleNavTo, this);
	},

	getList: function(){
		return this.byId("Notes");
	},

	onItemSelected: function() {
		// Empty input field for creation of note
		this.byId("noteInput").setValue("");
	},

	onSubViewLiveSearch: function(searchString) {
		var oBinding = this.getList().getBinding("items");
		var aFilters = [];
		if(searchString !== ""){
			var aSubStrings = searchString.split(" ");
			for (var i in aSubStrings)
				aFilters.push(new sap.ui.model.Filter("content", sap.ui.model.FilterOperator.Contains, aSubStrings[i]));
		}
		if(oBinding)
			oBinding.filter(aFilters);
	},

	onAddNote:function (oEvent) {
		var text, oView, oModel, accountID = "", oNote, oContext;

		// text is the string you entered in the textarea.
		text = oEvent.getParameter("value");
		
		//Trim text and do not create note if string is empty
		text = jQuery.trim(text);
		if(text.length === 0){
			return; 
		}

		oView = this.getView();
		oModel = this.getView().getModel();
		oNote = {
			"tdname":accountID, // must not be null, but
			"tdid":"",
			"tdspras":"",
			"content":text,
			"createdAt":null, // must be null (or set)
			"creator":""
		};
		oContext = oView.getBindingContext();

		var oNoteCreateError = jQuery.proxy(function (oError) {
			var sMessage = "";
			if (oError.response) {
				sMessage = jQuery.parseJSON(oError.response.body).error.message.value;
			}
			sap.ca.ui.message.showMessageBox({
				type:sap.ca.ui.message.Type.ERROR,
				message:sMessage
			});			
			
		}, this);

		oModel.create("Notes", oNote, oContext, undefined, oNoteCreateError);

		// In case the device is a phone or tablet, a keyboard is displayed to type
		// in the note's text. After pressing the button to add the note, the focus
		// is moved away from input field so that the keyboard disappears.
		// Hybrid devices can have the property to be both, desktop and tablet.
		if(sap.ui.Device.system.phone || (sap.ui.Device.system.tablet && !sap.ui.Device.system.desktop)) {
			var oList = this.getList();
			var oBinding = oList.getBinding("items");
			var fnReceivedHandler = null;
			fnReceivedHandler = jQuery.proxy(function () {
				oList.focus();
				oBinding.detachDataReceived(fnReceivedHandler);
			}, this);
			oBinding.attachDataReceived(fnReceivedHandler);
		}
	}

});
},
	"cus/crm/myaccounts/view/overview/Notes.view.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core" xmlns:mvc="sap.ui.core.mvc" xmlns="sap.m"\n\t\t\tcontrollerName="cus.crm.myaccounts.view.overview.Notes" xmlns:html="http://www.w3.org/1999/xhtml">\n\n\t<FeedInput \n\t    id="noteInput"\n\t    post="onAddNote"\n\t    showIcon="false"\n\t    maxLength="1000"\n\t    placeholder="{i18n>NEW_NOTE}" />\n\t<List id="Notes"\n\t\tgrowing="true"\n\t\tgrowingScrollToLoad="false"\n\t\tgrowingThreshold="10" \n\t\titems="{Notes}" >\n\t\t<FeedListItem\n\t\t\ttext="{content}"\n\t\t\tsender="{creator}"\n\t\t\ttimestamp="{path:\'createdAt\', formatter:\'cus.crm.myaccounts.util.formatter.formatMediumDateTime\'}"\n\t\t\tsenderActive="false"\n\t\t\ticonActive="false"\n\t\t\ticonDensityAware="false"\n\t\t\tshowIcon="false" />\n\t</List>\n\n</core:View>',
	"cus/crm/myaccounts/view/overview/Opportunities.controller.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
// EXC_ALL_JSHINT_0211
sap.ui.controller("cus.crm.myaccounts.view.overview.Opportunities", {

	/**
	* Called when a controller is instantiated and its View controls (if available) are already created.
	* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
	* @memberOf view.Leads
	*/
		onInit: function() {
			// Retrieve the application bundle
			this.resourceBundle = sap.ca.scfld.md.app.Application.getImpl().AppI18nModel.getResourceBundle();
		},

		onOpportunityDescriptionLinkClicked: function (oEvent) {
			this._navToOpportunity(oEvent);
		},

		onEditOpportunityClicked:function (oEvent) {
			var guid = oEvent.getSource().getBindingContext().getObject().Guid;
			var fgetService = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService;
			var oCrossAppNavigator = fgetService && fgetService("CrossApplicationNavigation");
			if (oCrossAppNavigator) {
				oCrossAppNavigator.toExternal({
					target : {
					semanticObject : "Opportunity",
					action : "manageOpportunity&/edit/Opportunities(guid'" + guid + "')"
				    }
			    });
		    }
		},
		
		onMainContactLinkClicked: function (oEvent) {
			this._showBusinessCard(oEvent);
		},

		_navToOpportunity: function (oEvent) {
			var guid = oEvent.getSource().getBindingContext().getObject().Guid;

			// *XNav* (1) obtain cross app navigation interface
			var fgetService = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService;
			var oCrossAppNavigator = fgetService && fgetService("CrossApplicationNavigation");

			// *XNav (2) generate cross application link
			if (oCrossAppNavigator) {
				oCrossAppNavigator.toExternal({
					target : {
					semanticObject : "Opportunity",
					action : "manageOpportunity&/display/Opportunities(guid'" + guid + "')"
				    }
			   });
	    	}
		},	

		/*
		 * handler for business card
		 */
		_showBusinessCard: function (oEvent) {
			var contextPath = oEvent.getSource().getBindingContext().sPath;
			var oModel = this.getView().getModel();
			var oContact = oModel.getProperty(contextPath + "/MainContact");
			var oAccount = this.getView().getBindingContext().getObject();
			var that = this;

			// oContact.accountID is either initial (Contact is not assigned to any account) or oContact.accountID contains
			// an arbitrary account that the contact is assigned to	or contact is assigned to the account of the opportunity
			// --> Navigate to contact details only in the latter case
			if(oContact.accountID === oAccount.accountID){
				cus.crm.myaccounts.util.Util.openQuickoverview(
						this.resourceBundle.getText("CONTACT_TITLE"),
						oModel.getProperty(contextPath + "/MainContact/fullName"),
						oModel.getProperty(contextPath + "/MainContact/function"),
						cus.crm.myaccounts.util.formatter.pictureUrlFormatter(oModel.getProperty(contextPath + "/MainContact/Photo/__metadata/media_src")),
						oEvent.getSource().getBindingContext(),
						"MainContact",
						"WorkAddress",
						this.getView().getBindingContext(),
						"MainAddress",
						oEvent.getSource(),
						function(){
							that._navToContact(oModel.getProperty(contextPath + "/MainContact"));
							});
			} else {
				sap.m.MessageToast.show(cus.crm.myaccounts.util.Util.geti18NText("MSG_NOT_IN_MAIN_CONTACT"));
			}
		},

		_navToContact:function (oContact) {
			var contactID = oContact.contactID;
			var accountID = oContact.accountID;

			// *XNav* (1) obtain cross app navigation interface
			var fgetService = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService;
			var oCrossAppNavigator = fgetService && fgetService("CrossApplicationNavigation");

			// *XNav (2) generate cross application link
			if (oCrossAppNavigator) {
				oCrossAppNavigator.toExternal({
					target : {
					semanticObject : "ContactPerson",
					action : "MyContacts&/display/ContactCollection(contactID='" + contactID + "',accountID='" + accountID + "')"
				    }
			    });
		    }
		},

		getList: function() {
			return this.byId("list");
		},

		onSubViewLiveSearch: function(searchString) {
			var oBinding = this.getList().getBinding("items");
			var aFilters = [];
			if(searchString !== "")
				aFilters.push(new sap.ui.model.Filter("description", sap.ui.model.FilterOperator.Contains, searchString));
			if(oBinding)
				oBinding.filter(aFilters);
		},

		onInitPersonalization: function(){
			var oTable = this.getList();
			return{
				tablePersonalization: {
					table: oTable
				}
			};
		},

		onStoreCurrentStateSupported: function(){
			return true;
		},

		onStoreCurrentState: function(storage){
			storage.contextPath = "";

			var oBus = sap.ui.getCore().getEventBus();

			// Listen to event that opportunity has been changed including main
			// contact of opportunity has been added or deleted and store
			// the context path of the opportunity which has to be refreshed.
			storage.onRefreshContextPath = function(channelId, eventId, data){
				// In case no other event has happened before so that all opportunities should
				// be refreshed, store the context path of the opportunity which has to be refreshed.
				if(storage.action !== "refreshList") {
					storage.action = "refreshContextPath";
					storage.contextPath = data.contextPath.replace("Opportunities", "OpportunityCollection");
				}
			};

			// Listen to event that opportunity has been created as follow up and
			// contact of opportunity has been changed. In case such an event happens,
			// refresh the whole list of opportunities.
			storage.onRefreshList = function(){
				storage.action = "refreshList";
			};

			oBus.subscribe("cus.crm.opportunity", "opportunityChanged", storage.onRefreshContextPath, storage);
			oBus.subscribe("cus.crm.opportunity", "followUpOpportunityCreated", storage.onRefreshList, storage);
			oBus.subscribe("cus.crm.opportunity", "contactAdded", storage.onRefreshContextPath, storage);
			oBus.subscribe("cus.crm.opportunity", "contactDeleted", storage.onRefreshContextPath, storage);
			oBus.subscribe("cus.crm.mycontacts", "contactChanged", storage.onRefreshList, storage);
			oBus.subscribe("cus.crm.opportunity", "opportunityCreated", storage.onRefreshList, storage);

			// Remove all event listeners
			storage.onExit = function(){
				var oBus = sap.ui.getCore().getEventBus();
				oBus.unsubscribe("cus.crm.opportunity", "opportunityChanged", storage.onRefreshContextPath, storage);
				oBus.unsubscribe("cus.crm.opportunity", "followUpOpportunityCreated", storage.onRefreshList, storage);
				oBus.unsubscribe("cus.crm.opportunity", "contactAdded", storage.onRefreshContextPath, storage);
				oBus.unsubscribe("cus.crm.opportunity", "contactDeleted", storage.onRefreshContextPath, storage);
				oBus.unsubscribe("cus.crm.mycontacts", "contactChanged", storage.onRefreshList, storage);
				oBus.unsubscribe("cus.crm.opportunity", "opportunityCreated", storage.onRefreshList, storage);
			};
		},

		onRestoreCurrentState: function(storage){
			if(storage.action === "refreshList")
				this.getView().getBindingContext().getModel().refresh();
			else if(storage.action === "refreshContextPath"){
				var oRefreshUIObject = cus.crm.myaccounts.util.Util.getRefreshUIObject(this.getView().getModel(), "/"+storage.contextPath, "MainContact,MainContact/Photo");
				oRefreshUIObject.refresh();
			}
		},
		// ///////////////////////////////////////////////////////////////////////////////
		// add opportunity
		// ///////////////////////////////////////////////////////////////////////////////

		getFooterButtons: function(){
			var that = this;
			return [{
					sIcon: "sap-icon://add",
					sTooltip: cus.crm.myaccounts.util.Util.geti18NText("ADD_OPPORTUNITY_TOOLTIP"),
					onBtnPressed: function () {
						that.onCreateOpportunity();
					}
			}];
		},
		
		onCreateOpportunity: function() {
			
			var oDataModel = this.getView().getModel();
			
			var that = this;
			var fnShowTransactionTypes = function(oResponses){
				
				var aProcessTypes;
				
				if(!that.processTypeModel) {
					aProcessTypes = oResponses["CustomizingOpportunityTypeCollection"];
					that.processTypeModel = new sap.ui.model.json.JSONModel();
					that.processTypeModel.setProperty("/TransactionTypeSet", aProcessTypes);
				} else {
					aProcessTypes = that.processTypeModel.getProperty("/TransactionTypeSet");
				}
		
				if (aProcessTypes.length === 1) {
					var processType = aProcessTypes[0].processTypeCode;
					that._navigateToCreationOfOpportunity(processType);
				} else {
					that.oProcessTypeDialog = sap.ui.xmlfragment("cus.crm.myaccounts.view.overview.ProcessTypeDialog", that);
					that.oProcessTypeDialog.setModel(that.getView().getModel("i18n"), "i18n");
					that.oProcessTypeDialog.setModel(that.processTypeModel, "processTypes");
					that.oProcessTypeDialog.open();
				}
			};
			var fnHandleError = function(oError){
				if (oError.code === "/IWFND/CM_BEC/026") {
					oError.message = cus.crm.myaccounts.util.Util.geti18NText("MSG_NO_OPPORTUNITY_TRANSACTION_TYPES");
					oError.details = "";
					sap.ca.ui.message.showMessageBox(oError);
				}
			};
			if(that.processTypeModel)
				fnShowTransactionTypes.call(that);
			else
				cus.crm.myaccounts.util.Util.sendBatchReadRequests(oDataModel, ["CustomizingOpportunityTypeCollection"], fnShowTransactionTypes, fnHandleError);
		},

		selectProcess: function(oEvent) {
			var processType = "";
			var oSelectedItem = oEvent.getParameter("selectedItem");
			if(oSelectedItem) {
				processType = oSelectedItem.data("ProcessTypeCode");
			}
			this._navigateToCreationOfOpportunity(processType);
		},

		_navigateToCreationOfOpportunity: function(processType) {
				var fgetService = sap.ushell.Container.getService;
					var oCrossAppNavigator = fgetService("CrossApplicationNavigation");
						var contextPath = this.getView().getBindingContext().sPath.substring(1);
						oCrossAppNavigator.toExternal({
							target: {
								semanticObject: "Opportunity",
								action: "manageOpportunity&/NewOpportunityFromAccount/" + processType + "/" + contextPath
							}
						});
		},

		searchProcess: function(oEvent) {
			var oItemsBinding = oEvent.getParameter("itemsBinding");
			var oItemsBindingFiltered;

			this.oProcessTypeDialog.setNoDataText(cus.crm.myaccounts.util.Util.geti18NText("LOADING_TEXT"));
			var searchString = oEvent.getParameter("value");
			if(searchString !== undefined) {
				// Apply the filter to the bound items, and the Select Dialog will update
				oItemsBindingFiltered = oItemsBinding.filter([new sap.ui.model.Filter("processTypeDescription", sap.ui.model.FilterOperator.Contains, searchString)]);

				if(oItemsBindingFiltered.getLength() === 0) {
					this.oProcessTypeDialog.setNoDataText(cus.crm.myaccounts.util.Util.geti18NText("NO_DATA_TEXT"));
				}
			}
		}

/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf view.Contacts
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf view.Contacts
*/
//	onAfterRendering: function() {
//
//	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf view.Contacts
*/
//	onExit: function() {
//
//	}

});
},
	"cus/crm/myaccounts/view/overview/Opportunities.view.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core" xmlns:mvc="sap.ui.core.mvc" xmlns="sap.m" xmlns:layout="sap.ui.layout"\n\t\t\tcontrollerName="cus.crm.myaccounts.view.overview.Opportunities" xmlns:html="http://www.w3.org/1999/xhtml">\n\n\t<Table\n   \t\tid="list"\n\t\tmode="{device>/listMode}"\n\t\tgrowing="true"\n         \tgrowingThreshold="10"\n         \tgrowingScrollToLoad="false"\n         \titems="{path:\'Opportunities\',\n         \t\t\tparameters: {expand: \'MainContact,MainContact/Photo\'}}"> \n        <columns>\n          <Column id="descriptionCol" width="16rem" minScreenWidth="Small" demandPopin="true"><Label text="{i18n>DESCRIPTION}" /></Column>\n          <Column id="mainContactCol" width="16rem" minScreenWidth="Medium" demandPopin="true"><Label text="{i18n>MAIN_CONTACT}" /></Column>\n          <Column id="volumeCol" width="8rem" minScreenWidth="Large" demandPopin="true"><Label text="{i18n>VOLUME}" /></Column>\n          <Column id="probabilityCol" width="8rem" minScreenWidth="Large" demandPopin="true"><Label text="{i18n>PROBABILITY}" /></Column>\n          <Column id="closingDate" width="12rem" minScreenWidth="XLarge" demandPopin="true"><Label text="{i18n>CLOSE_BY}" /></Column>\n          <Column id="statusCol" width="12rem" minScreenWidth="XXLarge" demandPopin="true"><Label text="{i18n>STATUS}" /></Column>\n          <!-- <Column id="actions" width="3rem" minScreenWidth="Desktop" demandPopin="true"><Text text="{i18n>ACTIONS}" /></Column> -->\n        </columns>\n        <items>\n        \t<ColumnListItem id="columnListItem">\n            \t<cells>\n            \t\n\t\t\t\t\t<VBox>\n\t\t\t\t\t\t<items>\n          \t\t\t\t\t\t<Link text="{description}" press="onOpportunityDescriptionLinkClicked"/>\n          \t\t\t\t\t\t<Label text="{objectId}" />\n          \t\t\t\t\t</items>\n          \t\t\t\t\t<layoutData>\n\t\t\t\t            <layout:GridData span="L12 M12 S12"/>\n\t\t\t\t        </layoutData>\n         \t\t\t\t</VBox>\n         \t\t\t\t\n         \t\t\t\t<layout:Grid class="gridMarginTop" defaultSpan="L3 M3 S6" hSpacing="0" vSpacing="0">\n            \t\t\t<layout:content>\n\t\t\t\t\t\t\t<core:Icon \n\t\t\t\t\t\t\t\tsrc="{path:\'MainContact/Photo/__metadata/media_src\', formatter: \'cus.crm.myaccounts.util.formatter.pictureUrlFormatter\'}"\n\t\t\t\t\t\t\t\tvisible="{parts:[{path:\'MainContact/contactID\'}, {path:\'MainContact/Photo/__metadata/media_src\'}], formatter:\'cus.crm.myaccounts.util.formatter.standardIconVisibilityFormatter\'}"\n            \t\t\t\t\tsize="2.5rem">\n\t\t\t\t\t\t     </core:Icon>\n\t\t\t\t\t\t     <Image \n\t\t\t\t\t\t\t\tsrc="{path:\'MainContact/Photo/__metadata/media_src\', formatter:\'cus.crm.myaccounts.util.formatter.pictureUrlFormatter\'}"\n\t\t\t\t\t\t\t\tvisible="{path:\'MainContact/Photo/__metadata/media_src\', formatter:\'cus.crm.myaccounts.util.formatter.logoVisibilityFormatter\'}" \n\t\t\t\t\t\t\t\theight="2.5rem" \n\t\t\t\t\t\t\t\twidth="2.5rem">\n\t\t\t\t\t\t\t</Image>\n\t\t\t\t\t\t\t<VBox>\n\t\t\t\t\t\t\t\t<items>\n            \t\t\t\t\t\t<Link text="{MainContact/fullName}" press="onMainContactLinkClicked"/>\n            \t\t\t\t\t\t<Label text="{MainContact/function}" />\n            \t\t\t\t\t</items>\n            \t\t\t\t\t<layoutData>\n\t\t\t\t\t\t            <layout:GridData span="L8 M8 S8"/>\n\t\t\t\t\t\t        </layoutData>\n           \t\t\t\t\t</VBox>\t\t\t\t\t\t\t  \n            \t\t\t</layout:content>\n            \t\t</layout:Grid>\n         \t\t\t\t\n         \t\t\t\t<Text text="{parts:[{path: \'expRevenue\'}, {path: \'currency\'}],  formatter:\'cus.crm.myaccounts.util.formatter.formatAmounts\'}"/>\n         \t\t\t\t\n         \t\t\t\t<Text text="{path: \'probability\', formatter: \'cus.crm.myaccounts.util.formatter.formatProbability\'}"/>\n         \t\t\t\t\n         \t\t\t\t<Text text="{parts:[{path:\'closingDate\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatMediumDate\' }"/>\n         \t\t\t\t\n         \t\t\t\t<ObjectStatus text="{statusText}" state="{path:\'status\', formatter:\'cus.crm.myaccounts.util.formatter.formatStatusText\'}"/>\n         \t\t\t\t<!--\n         \t\t\t\t<layout:HorizontalLayout>\n\t\t\t\t        \t<core:Icon src="sap-icon://edit" size="1.3rem" press="onEditOpportunityClicked"/>\n\t\t\t            </layout:HorizontalLayout>\n\t\t\t            -->\n\t\t              \n\t\t         </cells>\n        \t</ColumnListItem>\n    \t</items>\n   \t</Table>\n\n</core:View>',
	"cus/crm/myaccounts/view/overview/OverviewPage.controller.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");
jQuery.sap.require("cus.crm.myaccounts.util.formatter");
jQuery.sap.require("cus.crm.myaccounts.util.Util");
jQuery.sap.require("sap.collaboration.components.fiori.sharing.attachment.Attachment");
jQuery.sap.require("sap.ui.core.Item");
jQuery.sap.require("sap.ca.ui.utils.TablePersonalizer");
jQuery.sap.require("sap.m.TablePersoDialog");

sap.ca.scfld.md.controller.BaseFullscreenController.extend("cus.crm.myaccounts.view.overview.OverviewPage", {

	configurationMode: false,


	/**
	* Called when a controller is instantiated and its View controls (if available) are already created.
	* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
	* @memberOf view.OverviewPage
	*/
	onInit: function() {

		// Private attributes: =
		this.EHP2Backend = cus.crm.myaccounts.util.Util.getServiceSchemaVersion(this.getView().getModel(), "AccountCollection") < 1;
		this.liveChangeTimer = 0;
		this.oContext = null;
		this.oTabConfigurationModel = new sap.ui.model.json.JSONModel({"Tabs":[
			{
				"key": "general",
				"viewName": "cus.crm.myaccounts.view.overview.GeneralData",
				"name": cus.crm.myaccounts.util.Util.geti18NText("GENERAL_DATA"),
				"viewInstance": undefined,
				"searchString": undefined,
				"service": undefined,	// undefined means default
				"hidden": undefined,	//if true it will be not displayed
				"tablePersoController": undefined
			},
			{
				"key": "marketingattributes",
				"viewName": "cus.crm.myaccounts.view.overview.MarketingAttributes",
				"name": cus.crm.myaccounts.util.Util.geti18NText("MARKETINGATTRIBUTES")
			},
			{
				"key": "contacts",
				"viewName": "cus.crm.myaccounts.view.overview.Contacts",
				"name": cus.crm.myaccounts.util.Util.geti18NText("CONTACTS")
			},
			{
				"key": "appointments",
				"viewName": "cus.crm.myaccounts.view.overview.Appointments",
				"name": cus.crm.myaccounts.util.Util.geti18NText("APPOINTMENTS")
			},
			{
				"key": "tasks",
				"viewName": "cus.crm.myaccounts.view.overview.Tasks",
				"name": cus.crm.myaccounts.util.Util.geti18NText("TASKS")
			},
			{
				"key": "attachments",
				"viewName": "cus.crm.myaccounts.view.overview.Attachments",
				"name": cus.crm.myaccounts.util.Util.geti18NText("ATTACHMENTS")
			},
			{
				"key": "notes",
				"viewName": "cus.crm.myaccounts.view.overview.Notes",
				"name": cus.crm.myaccounts.util.Util.geti18NText("NOTES")
			},
			{
				"key": "leads",
				"viewName": "cus.crm.myaccounts.view.overview.Leads",
				"name": cus.crm.myaccounts.util.Util.geti18NText("LEADS")
			},
			{
				"key": "opportunities",
				"viewName": "cus.crm.myaccounts.view.overview.Opportunities",
				"name": cus.crm.myaccounts.util.Util.geti18NText("OPPORTUNITIES")
			},
			{
				"key": "quotations",
				"viewName": "cus.crm.myaccounts.view.overview.Quotations",
				"name": cus.crm.myaccounts.util.Util.geti18NText("QUOTATIONS"),
				"service": "ERP_BUPA_ODATA"
			},
			{
				"key": "salesorders",
				"viewName": "cus.crm.myaccounts.view.overview.SalesOrders",
				"name": cus.crm.myaccounts.util.Util.geti18NText("SALES_ORDERS"),
				"service": "ERP_BUPA_ODATA"
			}
		]});

		/** * @ControllerHook	extHookAdaptAvailableSubViews 
		 * 						In the method extHookAdaptAvailableSubViews it is possible to remove, 
		 * 						replace and add views, which should be displayed in the account overview page.
		 * 						The array should contain json object with following attributes: 
		 * 						"key" - unique string like "opportunities", 
		 * 						"name" - language dependent text, which will be displayed in the select box, 
		 * 						"viewName" - view definition, which should be loaded
		 * @callback cus.crm.myaccounts.view.overview.OverviewPage~extHookAdaptAvailableSubViews
		 * @param {array} aAvailableSubViews
		 * @return {void} */
		if (this.extHookAdaptAvailableSubViews)
			this.extHookAdaptAvailableSubViews(this.oTabConfigurationModel.getProperty("/Tabs"));

		//Current State:
		this._restoreCurrentState();

		//External Services like ERP
		this._initModelsForExternalServices();

		//Personalization:
		this.personalizationSaveRunning = false;
		this.oPersonalizationContainer = null;
		this.oTabPersonalization = null;
		this.oTabPersonalizationController = null;
		this.oTabPersonalizationDialog = null;
		this._initTabPersonalization();

		// error handling: remove connection manager handler and add own function
		var oModel = this.getView().getModel();
		oModel.mEventRegistry["requestFailed"] = [];
		oModel.attachRequestFailed(this._onRequestFailed);

		this.initializeMatchedRoute();
	},

	initializeMatchedRoute: function(){
		var oController = this;
		var oView = this.getView();
		var oModel = oView.getModel();

		oView.setModel(this.oTabConfigurationModel, "overviewConfig");

		this.oRouter.attachRouteMatched(function (oEvent) {
			// Fix for iphone. Scroll to top of overview page before leaving it
			// so that top of overview page is displayed when user navigates
			// the next time to overview page.
			if (jQuery.device.is.phone && (oEvent.getParameter("name") === "S2" || oEvent.getParameter("name") === "mainPage"))
				this.byId("page").scrollTo(0, 0);
			if (oEvent.getParameter("name") === "detail" || oEvent.getParameter("name") === "subdetail") {
				var oArguments = oEvent.getParameter("arguments");

				if(oController.EHP2Backend){
					oController.oRouter.navTo("s360", {
						contextPath: oArguments.contextPath
					}, true);
					return;
				}

				var contextPath = '/' + oArguments.contextPath;
				var oContext = new sap.ui.model.Context(oModel, contextPath);
				oController.oContext = oContext;

				// Set selected key and title for Select control
				var selectedKey = oArguments.selectedTab;
				this._fillTabSelect();
				if(this._isSelectionKeyHidden(selectedKey))
					selectedKey = this._getFirstSelectionKey();
				if(!selectedKey)
					selectedKey = this._getFirstSelectionKey();
				this._setSelectedKey(selectedKey);

				if(oContext.getObject()) { // if context has an account object (if navigated from search result page)
					this._readMissingObjects(selectedKey);
					var oHeaderArea = oView.byId("headerArea");	//bind only header to avoid cascading
					if(oHeaderArea.getBindingContext() && oHeaderArea.getBindingContext().getPath() !== oContext.getPath()) {
						oHeaderArea.setBindingContext(undefined);
						this._resetViews();
					}
					oHeaderArea.setBindingContext(oContext);
					oController._displaySubView(selectedKey);
				} else {	// if context has no account object (if the view has been called directly with a link)
					var oHeaderArea = oView.byId("headerArea");
					oHeaderArea.setBindingContext(undefined);
					oController._displaySubView(selectedKey);
					this._resetViews();

					oModel.createBindingContext(contextPath, "", {
						expand: this._getExpandForBinding(selectedKey)},
						function() {
							oHeaderArea.setBindingContext(oContext);
							oController._displaySubView(selectedKey);
						},
						true);
				}
			}
		}, this);
	},

	isInConfigurationMode: function() {
		return this.configurationMode;
	},

	toggleConfigurationMode: function() {
		this.configurationMode = !this.configurationMode;

		var oButton = this.byId("personalizationButton");
		oButton.setVisible(this.configurationMode);

		var oSubViewDefinition = this._getSubViewDefinition(this._getSelectedKey());
		if (oSubViewDefinition.viewInstance && oSubViewDefinition.viewInstance.getController().onInitPersonalization && this.oPersonalizationContainer){
			oButton = this.byId("subViewPersonalizationButton");
			oButton.setVisible(this.configurationMode);
		}

		this.setHeaderFooterOptions(this._getHeaderFooterOptions());
	},

	_getSelectedKey: function() {
		var oSelect = this.byId("tabSelect");
		return oSelect.getSelectedKey();
	},

	_setSelectedKey: function(selectedKey){
		this.byId("tabSelect").setSelectedKey(selectedKey);
	},

	_getFirstSelectionKey: function() {
		var oSelect = this.byId("tabSelect");
		var aItems = oSelect.getItems();
		if(aItems.length)
			return aItems[0].getKey();
		else
			return 'general';
	},

	_isSelectionKeyHidden: function(selectedKey) {
		if(this.oTabPersonalization && this.oTabPersonalization.aColumns){
			var aTabs = this.oTabPersonalization.aColumns;
			for(var i in aTabs){
				var id = this._getKeyTabFromPersonalizationColumn(aTabs[i]);
				if(id === selectedKey && aTabs[i].visible === false){
					return true;
				}
			}
		}
		return false;
	},

	_refreshTabSelect: function() {
		var selectedKey = this._getSelectedKey();
		this._fillTabSelect();
		this._setSelectedKey(selectedKey);

		if(this._getSelectedKey() === "" || this._isSelectionKeyHidden(this._getSelectedKey()))
			this.navigateTo(this._getFirstSelectionKey());
	},

	_fillTabSelect: function() {
		// Set the items of the Select control
		var oSelect = this.byId("tabSelect");
		oSelect.removeAllItems();
		if(this.oTabPersonalization && this.oTabPersonalization.aColumns) {
			var aTabs = this.oTabPersonalization.aColumns;
			for(var i in aTabs) {
				if(aTabs[i].visible) {
					var id = this._getKeyTabFromPersonalizationColumn(aTabs[i]);
					var oSubViewDefinition = this._getSubViewDefinition(id);
					if(oSubViewDefinition && !oSubViewDefinition.hidden)
						oSelect.addItem(new sap.ui.core.Item({text: oSubViewDefinition.name, key: oSubViewDefinition.key}));
				}
			}
		} else {
			var aTabs = this.oTabConfigurationModel.getProperty("/Tabs");
			for(var i in aTabs) {
				var oSubViewDefinition = aTabs[i];
				if(!oSubViewDefinition.hidden)
					oSelect.addItem(new sap.ui.core.Item({text: oSubViewDefinition.name, key: oSubViewDefinition.key}));
			}
		}
	},

	_readMissingObjects: function(tabConfigurationKey) {
		var oModel = this.getView().getModel();
		var oContext = this.oContext;

		var aExpandValues = this._getExpandForBinding(tabConfigurationKey).split(",");
		var aExpand = [];
		//only missing navigation properties should be read
		for(var i in aExpandValues) {
			var object = oModel.getProperty(oContext.sPath+"/"+aExpandValues[i]);
			if(!object)
				aExpand.push(aExpandValues[i]);
		}

		//special logic for Logo, because it's not required to reread it if we navigate from search (in case the account has no logo) -> this might change in future
		var indexLogo = aExpand.indexOf('Logo');
		if(indexLogo >= 0)
			aExpand.splice(indexLogo, 1);

		//special logic for AccountFactsheet, because not all values might be available
		if((!oModel.getProperty(oContext.sPath+"/AccountFactsheet")
		   || !oModel.getProperty(oContext.sPath+"/AccountFactsheet/revenueCurrentYear")
		   || !oModel.getProperty(oContext.sPath+"/AccountFactsheet/revenueLastYear"))
		   && $.inArray("AccountFactsheet", aExpand) === -1){
			aExpand.push("AccountFactsheet");
		}

		if(aExpand.length > 0)
			cus.crm.myaccounts.util.Util.readExpandedODataObjects(oContext, aExpand.toString(), null);
	},

	_getExpandForBinding: function(tabConfigurationKey) {
		var aExpand = ["Logo", "MainAddress", "AccountFactsheet", "ERPCustomer"];
		var oSubView = this._getSubView(tabConfigurationKey);
		if(oSubView && oSubView.getController().getExpandForBinding) {
			var aExpandElements = oSubView.getController().getExpandForBinding().split(",");
			for(var i in aExpandElements) {
				if($.inArray(aExpandElements[i], aExpand) === -1)
					aExpand.push(aExpandElements[i]);
			}
		}
		return aExpand.toString();
	},

	_onRequestFailed: function(oEvent) {
		var oResponse = jQuery.parseJSON(oEvent.getParameter("responseText"));
		var detailText = oResponse.error.innererror.Error_Resolution.SAP_Note;
		sap.ca.ui.message.showMessageBox({
			type: sap.ca.ui.message.Type.ERROR,
			message: oResponse.error.message.value,
			details: detailText
		});
	},

	_getSubView: function(tabConfigurationKey){
		var viewDefinition = this._getSubViewDefinition(tabConfigurationKey);
		if(!viewDefinition.viewInstance) {
			viewDefinition.viewInstance = sap.ui.view({ type: sap.ui.core.mvc.ViewType.XML,
				viewName: viewDefinition.viewName
			});
			viewDefinition.viewInstance.getController().oRouter = this.oRouter;
			viewDefinition.viewInstance.getController().oOverviewPage = this;
		}
		return viewDefinition.viewInstance;
	},

	_getSubViewDefinition: function(tabConfigurationKey) {
		var aTabs = this.oTabConfigurationModel.getProperty("/Tabs");
		var viewDefinition;
		for(var i in aTabs) {
			viewDefinition = aTabs[i];
			if(viewDefinition.key === tabConfigurationKey) {
				return viewDefinition;
			}
		}
	},

	_getSubViewDefinitionByViewName: function(viewName) {
		var aTabs = this.oTabConfigurationModel.getProperty("/Tabs");
		var viewDefinition;
		for(var i in aTabs) {
			viewDefinition = aTabs[i];
			if(viewDefinition.viewName === viewName) {
				return viewDefinition;
			}
		}
	},

	_resetViews: function() {
		var aTabs = this.oTabConfigurationModel.getProperty("/Tabs");
		var oViewDefinition;
		for(var i in aTabs){
			oViewDefinition = aTabs[i];
			if(oViewDefinition.viewInstance){
				oViewDefinition.viewInstance.setBindingContext(undefined);
				var oController = oViewDefinition.viewInstance.getController();

				//call Reset if the view needs to clean up
				if(oController.onReset)
					oController.onReset();

				//reset search
				oViewDefinition.searchString = "";

				//reset list to avoid displaying old data + reset filter
				if(oController.getList){
					var oList = oController.getList();
					if(oList){
						var oBinding = oList.getBinding("items");
						if(oBinding){
							oBinding.filter([]);
//							oList.destroyItems();
//							oList.removeAllItems();
//							oList.updateItems("change");
						}
					}
				}
			}
		}
	},

	_exitViews: function() {
		var aTabs = this.oTabConfigurationModel.getProperty("/Tabs");
		var oViewDefinition;
		for(var i in aTabs) {
			oViewDefinition = aTabs[i];
			if(oViewDefinition.viewInstance && oViewDefinition.viewInstance.getController().onExit)
				oViewDefinition.viewInstance.getController().onExit();
		}
	},

	_displaySubView: function(tabConfigurationKey) {
		var oSubViewDefinition = this._getSubViewDefinition(tabConfigurationKey);
		if(!oSubViewDefinition)
			return;

		var oSubView = oSubViewDefinition.viewInstance;
		if(!oSubView)
			oSubView = this._getSubView(tabConfigurationKey);

		var oDetailsViewContainer = this.getView().byId("detailsViewContainer");
		oDetailsViewContainer.removeAllContent();

		oDetailsViewContainer.addContent(oSubView);
		this._cleanUp(oSubView);
		this._bindView(oSubView);

		//display buttons in footer
		this.setHeaderFooterOptions(this._getHeaderFooterOptions());

		var oSearchField = this.byId("subViewSearchField");
		if(oSubView.getController().onSubViewLiveSearch || oSubView.getController().onSubViewSearch) {
			oSearchField.setVisible(true);
			if(oSubViewDefinition.searchString)
				oSearchField.setValue(oSubViewDefinition.searchString);
		else
			oSearchField.setValue("");
		}
		else {
			oSearchField.setVisible(false);
		}

		this._initPersonalizationForSubView(oSubViewDefinition);
	},

	_bindView:function(oView) {
		var itemBindingPath = "";
		if(oView.getBindingContext()) {
			itemBindingPath = oView.getBindingContext().getPath();
		}

		var oContext = this.byId("headerArea").getBindingContext();
		if(oContext && itemBindingPath !== oContext.getPath()) {
			oView.setBindingContext(oContext);
			var controller = oView.getController();
			if(controller.onItemSelected) {
				controller.onItemSelected();
			}
		}
	},

	onDetailsViewSelectionPressed: function(oEvent) {
		jQuery.sap.log.debug("cus.crm.myaccounts.view.overview.OverviewPage - onDetailsViewSelectionPressed");
		var selectedKey = oEvent.getParameters().selectedItem.getKey();
		oEvent.getSource().close();
		this._checkDataLossAndNavigate(selectedKey);
	},

	_checkDataLossAndNavigate: function(selectedKey) {
		jQuery.sap.log.debug("cus.crm.myaccounts.view.overview.OverviewPage - _checkDataLossAndNavigate");
		//current subview can interrupt switch to another view, e.g. data loss popup
		var oCurrentSubView = this.getView().byId("detailsViewContainer").getContent()[0];
		var that = this;
		this._checkDataLossForCurrentSubView(
				function() {
					//in case of no data loss popup, navigate as usual
					that.navigateTo(selectedKey);
				},
				function() {
					//in case data loss popup was raised, the selection must be reverted
					var oCurrentSubViewDefinition = that._getSubViewDefinitionByViewName(oCurrentSubView.sViewName);
					//remove the change event from select, set the selection key to the old one, add the change event
					var changeEvent = that.byId("tabSelect").mEventRegistry["change"];
					that.byId("tabSelect").mEventRegistry["change"] = null;
					that._setSelectedKey(oCurrentSubViewDefinition.key);
					window.setTimeout(function () {
						that.byId("tabSelect").mEventRegistry["change"] = changeEvent;
					}, 200);
				});
	},

	_checkDataLossForCurrentSubView: function(callbackNoDataLoss, callBackDataLossRaised) {
		var oCurrentSubView = this.getView().byId("detailsViewContainer").getContent()[0];
		if(oCurrentSubView && oCurrentSubView.getController().onBeforeClose) {
			var viewCanBeClosed = oCurrentSubView.getController().onBeforeClose(function() {
				callbackNoDataLoss.call();
			});
			if (!viewCanBeClosed) {
				if(callBackDataLossRaised)
					callBackDataLossRaised.call();
				return;
			}
		}
		callbackNoDataLoss.call();
	},

	navigateTo: function(selectedKey) {
		if(!this.oContext)
			return;
		var oParameter = {};
		oParameter.contextPath = this.oContext.getPath().replace("/", "");
		oParameter.selectedTab = selectedKey;
		this.oRouter.navTo("subdetail", oParameter, true);
	},

	onSubViewLiveSearch: function(oEvent) {
		if(jQuery.device.is.phone)
			return; //no liveSearch for phone

		var oSubViewDefinition = this._getSubViewDefinition(this._getSelectedKey());
		if(!oSubViewDefinition.viewInstance.getController().onSubViewLiveSearch)
			return;
		var delay = 300;
		var searchString = oEvent.getParameter("newValue");
		oSubViewDefinition.searchString = searchString;
		window.clearTimeout(this.liveChangeTimer);
		this.liveChangeTimer = window.setTimeout(function() {
			oSubViewDefinition.viewInstance.getController().onSubViewLiveSearch(searchString);
		}, delay);
	},

	onSubViewSearch: function(oEvent) {
		var oSubViewDefinition = this._getSubViewDefinition(this._getSelectedKey());
		var oSubViewController = oSubViewDefinition.viewInstance.getController();
		// In case the device is a phone or tablet, a keyboard is displayed to type
		// in the search string. After pressing the search button on the keyboard or
		// next to search field, the focus is moved away from the search field
		// so that the keyboard disappears.
		if((jQuery.device.is.phone || jQuery.device.is.tablet) && oSubViewController.getList)
			oSubViewController.getList().focus();

		var searchString = oEvent.getParameter("query");
		oSubViewDefinition.searchString = searchString;

		if(oSubViewController.onSubViewSearch)
			oSubViewController.onSubViewSearch(searchString);
		else if(jQuery.device.is.phone && oSubViewController.onSubViewLiveSearch)
			oSubViewController.onSubViewLiveSearch(searchString);
	},

	_getHeaderFooterOptions: function() {
		var that = this;
		var settingButtonsText = 'BUTTON_SHOW_PERSONALIZATION';
		if(this.configurationMode)
			settingButtonsText = 'BUTTON_HIDE_PERSONALIZATION';

		var oHeaderFooterOptions = {

			aAdditionalSettingButtons: 
				[
				 {
					 sI18nBtnTxt: settingButtonsText,
					 onBtnPressed: function(){that.toggleConfigurationMode();}
				 }
				],
			
			sI18NFullscreenTitle : "DETAIL_TITLE",
			
			onBack: function() {
				that.onBackButtonPressed();
			},

			oJamOptions: {
				fGetShareSettings : function() {
					return {
						object: {
							id: document.URL.replace(/&/g, "%26"),
							display: that._getShareDisplay(),
							share : that._getShareText()
						},
						externalObject: {
							appContext: "CRM",
							odataServicePath: that._getOdataServicePath(),
							collection: "AccountCollection",
							key: "'" + that.oContext.getProperty("accountID") + "'",
							name: that._getDiscussName(),
							summary: that._getShareText()
						}
					};
				},
				fGetDiscussSettings: function() {
					return {
						businessObject: {
							appContext:  "CRM",
							odataServicePath:  that._getOdataServicePath(),
							collection: "AccountCollection",
							key: "'" + that.oContext.getProperty("accountID") + "'",
							name: that._getDiscussName(),
							ui_url: window.location.href
						}
					};
				}
			}
		};

		var oSubView = this._getSubView(this._getSelectedKey());
		if(oSubView.getController().getFooterButtons) {
			oHeaderFooterOptions.buttonList = oSubView.getController().getFooterButtons();
			for(var i in oHeaderFooterOptions.buttonList) {
				oHeaderFooterOptions.buttonList[i].bDisabled = oSubView.getBindingContext() === null;
			}
		}
		return oHeaderFooterOptions;
	},

	onBackButtonPressed: function(){
		this._checkDataLossForCurrentSubView(function(){window.history.back();});
	},

	//methods for restoring the state
	_storeCurrentState: function() {
		cus.crm.myaccounts.view.overview.OverviewPage.storage = {};
		var storage = cus.crm.myaccounts.view.overview.OverviewPage.storage;

		//store oData Model , personalization and current subView to avoid reread from backend
		storage.oDataModel = this.getView().getModel();
		storage.tabPersonalization = this.oTabPersonalization ? this.oTabPersonalization : {};
		var subViewDefinition = this._getSubViewDefinition(this._getSelectedKey());
		if(subViewDefinition.viewInstance && subViewDefinition.viewInstance.getController().onStoreCurrentStateSupported && subViewDefinition.viewInstance.getController().onStoreCurrentStateSupported()) {
			storage.currentSubViewDefinition = subViewDefinition;
			storage.viewStorage = {};

			//subView can be called to implement additional logic and store information
			if(storage.currentSubViewDefinition.viewInstance.getController().onStoreCurrentState)
				storage.currentSubViewDefinition.viewInstance.getController().onStoreCurrentState(storage.viewStorage);
		}

		storage.onExit = function() {
			if(storage.viewStorage && storage.viewStorage.onExit)
				storage.viewStorage.onExit();
		};
	},

	_restoreCurrentState: function() {
		var storage = cus.crm.myaccounts.view.overview.OverviewPage.storage;
		if(!storage)
			return;

		//restore oData Model
		if(storage.oDataModel)
			this.getView().setModel(storage.oDataModel);

		//restore tab personalization
		if(storage.tabPersonalization)
			this.oTabPersonalization = storage.tabPersonalization;

		//restore the subView
		if(storage.currentSubViewDefinition) {

			storage.currentSubViewDefinition.viewInstance.setModel(this.getView().getModel());

			if(storage.currentSubViewDefinition.viewInstance.getController().onRestoreCurrentState)
				storage.currentSubViewDefinition.viewInstance.getController().onRestoreCurrentState(storage.viewStorage);

			var aTabs = this.oTabConfigurationModel.getProperty("/Tabs");
			for(var i in aTabs) {
				if(aTabs[i].viewName === storage.currentSubViewDefinition.viewInstance.getControllerName()) {
					aTabs[i] = storage.currentSubViewDefinition;
				}
			}
		}

		storage.onExit();
		cus.crm.myaccounts.view.overview.OverviewPage.storage = null;
	},

	//methods for Jam integration:
	_getShareText: function() {
		var oAccount = this.getView().getModel().getProperty(this.oContext.sPath);
		var text=cus.crm.myaccounts.util.formatter.AccountNameFormatter(oAccount.fullName, oAccount.name1) + "\n";

		var oMainAddress = this.getView().getModel().getProperty(this.oContext.sPath + "/MainAddress");
		if(oMainAddress)
			text += oMainAddress.address;

		return text;
	},

	_getShareDisplay: function() {
		var oAccount = this.getView().getModel().getProperty(this.oContext.sPath);
		var text=cus.crm.myaccounts.util.formatter.AccountNameFormatter(oAccount.fullName, oAccount.name1 );

		var oMainAddress = this.getView().getModel().getProperty(this.oContext.sPath + "/MainAddress");
		var text2 = "";
		if(oMainAddress)
			text2 = oMainAddress.address;

		return new sap.m.ObjectListItem({
			title: text,
			description: text2
		});
	},

	_getDiscussID: function() {
		return this._getOdataServicePath() + this.oContext.sPath;
	},

	_getDiscussType: function() {
		var url =  document.createElement('a');
		url.href = this.getView().getModel().sServiceUrl;
		return url.pathname + "/$metadata#AccountCollection";
	},

	_getDiscussName: function() {
		var oAccount = this.getView().getModel().getProperty(this.oContext.sPath);
		return cus.crm.myaccounts.util.formatter.AccountNameFormatter(oAccount.fullName, oAccount.name1 );
	},

	_getOdataServicePath: function() {
		var url =  document.createElement('a');
		url.href = this.getView().getModel().sServiceUrl;
		return url.pathname;
	},

	//method for External Backend Services
	_initModelsForExternalServices: function() {
		var aServiceConfig = cus.crm.myaccounts.util.Util.getExternalServiceConfiguration();

		for(var i in aServiceConfig) {
			// Personalization can be initialized after all relevant services have been initialized.
			this._addInitializationStep();
			var oServiceConfig = aServiceConfig[i];

			var fnMetadataLoaded = function(oEvt, oParams) {
				oParams.oOVPageController.getView().setModel(oParams.oModel, oParams.oServiceConfig.name);
				oParams.oOVPageController._removeInitializationStep();
				if(oParams.oOVPageController._isInitializationFinished())
					oParams.oOVPageController._buildTabPersonalization();
			};

			var fnMetadataFailed = function(oEvt, oParams) {
				var aTabs = oParams.oOVPageController.oTabConfigurationModel.getProperty("/Tabs");
				for(var z in aTabs) {
					if (aTabs[z].service === oParams.oServiceConfig.name)
						aTabs[z].hidden = true;
				}
				oParams.oOVPageController._refreshTabSelect();
				oParams.oOVPageController._removeInitializationStep();
				if(oParams.oOVPageController._isInitializationFinished())
					oParams.oOVPageController._buildTabPersonalization();
			};

			var oServiceData = sap.ui.model.odata.ODataModel.mServiceData[oServiceConfig.serviceUrl];
			var serviceAlreadyloaded= false, serviceFailed= false;

			if(oServiceData) { //model was already loaded
				serviceAlreadyloaded = true;
				if(oServiceData.oMetadata.oMetadata)
					serviceFailed = false;
				else
					serviceFailed = true;
			}

			var oModel = new sap.ui.model.odata.ODataModel(oServiceConfig.serviceUrl, {
				json: true,
				loadMetadataAsync: true,
				useBatch: oServiceConfig.useBatch
			});
			if (oServiceConfig.countSupported)
				oModel.setCountSupported(true);
			else
				oModel.setCountSupported(false);

			if(serviceAlreadyloaded) {
				if(serviceFailed)
					fnMetadataFailed(null, {oModel: oModel, oServiceConfig: oServiceConfig, oOVPageController: this});
				else
					fnMetadataLoaded(null, {oModel: oModel, oServiceConfig: oServiceConfig, oOVPageController: this});
			} else {
				oModel.attachMetadataLoaded({oModel: oModel, oServiceConfig: oServiceConfig, oOVPageController: this}, fnMetadataLoaded, this);
				oModel.attachMetadataFailed({oModel: oModel, oServiceConfig: oServiceConfig, oOVPageController: this}, fnMetadataFailed, this);
			}

		}
	},

	//	methods for the personalization
	onPersonalizationButtonPressed: function() {

		if(!this.oTabPersonalizationDialog) {
			this.oTabPersonalizationDialog = this.oTabPersonalizationController.getTablePersoDialog();
			this.oTabPersonalizationDialog._oDialog.setTitle(cus.crm.myaccounts.util.Util.geti18NText("VIEWS"));

			var that = this;
			this.oTabPersonalizationDialog.attachConfirm(function() {
				var oPersData = that.oTabPersonalizationDialog.retrievePersonalizations();
				that.oTabPersonalization = oPersData;

				//needed only if container is used
				that.oPersonalizationContainer.setItemValue("tabsPersonalization", oPersData);
				that._savePersonalization();

				that._refreshTabSelect();
			});
		}

		this.oTabPersonalizationController.openDialog();
	},

	_initTabPersonalization: function() {
		if(!this.oTabPersonalization) {
			var that = this;
			sap.ushell.Container.getService("Personalization").getContainer("cus.crm.myaccounts", { validity : Infinity })
				.fail(function() {
					that._refreshTabSelect();
				})
				.done(function(oContainer) {
					that.oPersonalizationContainer = oContainer;
					if(that._isInitializationFinished())
						that._buildTabPersonalization();
				});
		}
	},

	_buildTabPersonalization: function() {
		var aTabs = this.oTabConfigurationModel.getProperty("/Tabs");
		var aColumns = [];
		for(var i in aTabs) {
			if(!aTabs[i].hidden) {
				aColumns.push(new sap.m.Column(aTabs[i].key, { header: new sap.m.Label({ text: aTabs[i].name })}));
			}
		}
		var oTable = new sap.m.Table('tabsPersonalizationTable', {
			visible: false,
			columns: aColumns
		});

		var oPersonalizer = sap.ushell.Container.getService("Personalization").getTransientPersonalizer();

		this.oTabPersonalizationController = new sap.m.TablePersoController({
			table: oTable,
			persoService: oPersonalizer
		});

		// use the personalization data to configure the table accordingly
		this.oTabPersonalization = this.oPersonalizationContainer.getItemValue("tabsPersonalization");
		this._refreshTabSelect();
		oPersonalizer.setValue(this.oTabPersonalization);
		this.oTabPersonalizationController.activate();
		this.byId("headerArea").addContent(oTable);
		this._initPersonalizationForSubView();
	},

	_initPersonalizationForSubView: function(subViewDefinition) {
		var oPersonalizationButton = this.byId("subViewPersonalizationButton");
		var oSubViewDefinition = subViewDefinition;
		if(!oSubViewDefinition)
			oSubViewDefinition = this._getSubViewDefinition(this._getSelectedKey());
		if (oSubViewDefinition.viewInstance && oSubViewDefinition.viewInstance.getController().onInitPersonalization && this.oPersonalizationContainer) {

			var personalizationItemKey = oSubViewDefinition.key+"TablePersonalization";

			if(!oSubViewDefinition.tablePersoController) {
				var oPersonalisationDefinition = oSubViewDefinition.viewInstance.getController().onInitPersonalization();
				var oPersonalizer = sap.ushell.Container.getService("Personalization").getTransientPersonalizer();
				var oTablePersoController = new sap.m.TablePersoController({
					table: oPersonalisationDefinition.tablePersonalization.table,
					persoService: oPersonalizer
					});
				var oTabPersonalization = this.oPersonalizationContainer.getItemValue(personalizationItemKey);
				oPersonalizer.setValue(oTabPersonalization);
				oTablePersoController.activate();
				oSubViewDefinition.tablePersoController = oTablePersoController;
			}

			var that = this;
			var fnSaveData = function() {
				var oTabPersonalizationDialog = oSubViewDefinition.tablePersoController.getTablePersoDialog();
				oTabPersonalizationDialog.detachConfirm(fnSaveData);

				var oPersData = oTabPersonalizationDialog.retrievePersonalizations();
				that.oPersonalizationContainer.setItemValue(personalizationItemKey, oPersData);
				that._savePersonalization();
			};

			var fnOpenPersoDialog = function() {
				oSubViewDefinition.tablePersoController.openDialog();
				var oTabPersonalizationDialog = oSubViewDefinition.tablePersoController.getTablePersoDialog();
				oTabPersonalizationDialog.attachConfirm(fnSaveData);
			};

			oPersonalizationButton.setVisible(this.configurationMode);	//display only in configuration mode
			var aEvents = oPersonalizationButton.mEventRegistry["press"];
			for(var i in aEvents)
				oPersonalizationButton.detachPress(aEvents[i].fFunction);
			oPersonalizationButton.attachPress(fnOpenPersoDialog);
		} else {
			oPersonalizationButton.setVisible(false);
		}
	},

	_savePersonalization: function() {
		if(this.personalizationSaveRunning)
			return;
		var that = this;
		this.personalizationSaveRunning = true;
		this.oPersonalizationContainer.save()
			.fail(function() {
				that.personalizationSaveRunning = false;
			})
			.done(function() {
				// Before the next save is triggered the last one has to be finished.
				// Could be done by disabling the save button during the save.
				that.personalizationSaveRunning = false;
			});
	},

	_getKeyTabFromPersonalizationColumn: function(oColumn) {
		var key = oColumn.id.split("empty_component-tabsPersonalizationTable-")[1];
		if (!key)
			key = oColumn.id.split("cus.crm.myaccounts-tabsPersonalizationTable-")[1];

		return key;
	},

	_addInitializationStep: function() {
		if(this.remainingInitializationSteps === undefined)
			this.remainingInitializationSteps = 1;
		else
			this.remainingInitializationSteps++;
	},

	_removeInitializationStep: function() {
		this.remainingInitializationSteps--;
	},

	_isInitializationFinished: function() {
		return this.oPersonalizationContainer && this.remainingInitializationSteps == 0;
	},

	_cleanUp: function(oSubView) {
		if(oSubView.getController().onCleanUp)
			oSubView.getController().onCleanUp();
	},

/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf view.OverviewPage
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf view.OverviewPage
*/
//	onAfterRendering: function() {
//
//	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf view.OverviewPage
*/
	onExit: function() {
		this._storeCurrentState();
		this._exitViews();
		this.getView().byId("detailsViewContainer").removeAllContent();
	}

});
},
	"cus/crm/myaccounts/view/overview/OverviewPage.view.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core" xmlns:mvc="sap.ui.core.mvc" xmlns="sap.m" xmlns:suite="sap.suite.ui.commons" xmlns:layout="sap.ui.layout"\n           controllerName="cus.crm.myaccounts.view.overview.OverviewPage"\n\t\t   xmlns:html="http://www.w3.org/1999/xhtml">\n\n\t<Page id="page" title="{i18n>FULLSCREEN_TITLE}" showNavButton="true" enableScrolling="true">\n\n\t\t<content>\n\n\t\t\t<!-- Header: -->\n\t\t\t<layout:Grid\n\t\t\t\tclass ="sapSuiteUtiHeaderGrid sapSuiteUti"\n\t\t\t\tdefaultSpan="L6 M6 S12"\n\t\t\t\tvSpacing="0"\n\t\t\t\thSpacing="0"\n\t\t\t\tid="headerArea">\n\t\t\t\t<layout:content>\n\n\t\t\t\t\t<ObjectHeader\n\t\t\t\t\t\tid="companyHeaderTitle"\n\t\t\t\t        title= "{parts:[{path: \'fullName\'},{path: \'name1\'}],\n\t\t\t\t                formatter: \'cus.crm.myaccounts.util.formatter.AccountNameFormatter\'}" \n\t\t\t\t        titleActive="false"\n\t\t\t\t        icon="{parts:[{path:\'Logo/__metadata/media_src\'},{path: \'category\'}], formatter:\'cus.crm.myaccounts.util.formatter.logoUrlFormatter\'}" \t\t\t\t     \n\t        \t\t\ticonDensityAware="false">\n\t\t\t\t        <attributes>\n\t\t\t\t          <ObjectAttribute text="{accountID}"/> \n\t\t\t\t        </attributes>\n\t\t      \t\t</ObjectHeader>\n\n\t\t\t\t\t<!-- Extends the header area by KPI tiles -->\n\t\t\t\t\t<core:ExtensionPoint name="extKpiBox">\n\t\t\t\t\t\t<layout:HorizontalLayout class="cusMyAccountsPaddingTop cusMyAccountsFloatRight">\n\t\t\t\t\t\t\t<suite:KpiTile\n\t\t\t\t\t\t\t\tid="revenueCurrentYear"\n\t\t\t\t\t\t\t\tvalue="{parts:[{path:\'AccountFactsheet/revenueCurrentYear/amount\'},{path:\'AccountFactsheet/revenueCurrentYear/currency\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatShortAmounts\'}"\n\t\t\t\t\t\t\t\tdescription="{i18n>REVENUE_CURRENT}"\n\t\t\t\t\t\t\t\tdoubleFontSize="false"\n\t\t\t\t\t\t\t\ttooltip="{i18n>REVENUE_CURRENT_TOOLTIP}">\n\t\t\t\t\t\t\t</suite:KpiTile>\n\t\t\t\t\t\t\t<suite:KpiTile\n\t\t\t\t\t\t\t\tid="revenueLastYear"\n\t\t\t\t\t\t\t\tvalue="{parts:[{path:\'AccountFactsheet/revenueLastYear/amount\'},{path:\'AccountFactsheet/revenueLastYear/currency\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatShortAmounts\'}"\n\t\t\t\t\t\t\t\tdescription="{i18n>REVENUE_LAST}"\n\t\t\t\t\t\t\t\tdoubleFontSize="false"\n\t\t\t\t\t\t\t\ttooltip="{i18n>REVENUE_LAST_TOOLTIP}">\n\t\t\t\t\t\t\t</suite:KpiTile>\n\t\t\t\t\t\t\t<!-- Extends the KPI tiles -->\n\t\t\t\t\t\t\t<core:ExtensionPoint name="extKpiTile"/>\n\t\t\t\t\t\t</layout:HorizontalLayout>\n\t\t\t\t\t</core:ExtensionPoint>\n\n\t\t\t\t</layout:content>\n\t\t\t</layout:Grid>\n\n\t\t\t<!-- Header for Details Views: -->\n\t\t\t<layout:Grid\n\t\t\t\tdefaultSpan="L6 M6 S12"\n\t\t\t\tvSpacing="0"\n\t\t\t\thSpacing="0">\n\t\t\t\t<layout:content>\n\t\t\t\t\t<layout:HorizontalLayout class="cusMyAccountsPaddingLeft">\n\t\t\t\t\t\t<core:Icon id="personalizationButton" src="sap-icon://action-settings" press="onPersonalizationButtonPressed" visible="{path:\'/\', formatter:\'.isInConfigurationMode\'}" size="1.2rem" class="cusMyAccountsPaddingTop"/>\n\t\t           \t\t<Select\n\t\t           \t\t\tid="tabSelect"\n\t\t\t\t\t\t\tchange="onDetailsViewSelectionPressed">\n\t\t\t        \t</Select>\n\t\t        \t</layout:HorizontalLayout>\n\t\t\t\t\t<layout:HorizontalLayout class="cusMyAccountsFloatRight">\n\t\t\t        \t<SearchField id="subViewSearchField" liveChange="onSubViewLiveSearch" search="onSubViewSearch" visible="false"/>\n\t\t\t\t\t\t<core:Icon id="subViewPersonalizationButton" src="sap-icon://action-settings" size="1.2rem" visible="false" class="cusMyAccountsPaddingLeft cusMyAccountsPaddingTop cusMyAccountsPaddingRight"/>\n\t\t\t\t\t</layout:HorizontalLayout>\n\t\t\t\t</layout:content>\n\t\t\t</layout:Grid>\n\t\t\t\n\t\t\t<!-- Details Views: -->\n\t\t \t<layout:Grid id="detailsViewContainer" defaultSpan="L12 M12 S12" vSpacing="0" hSpacing="0">\n\t      \t\t<layout:content/>\n\t      \t</layout:Grid>\n\n\t\t</content>\n\t\t<footer>\n\t\t\t<Bar id="footer"/>\n\t\t</footer>\n\t</Page>\n</core:View>',
	"cus/crm/myaccounts/view/overview/ProcessTypeDialog.fragment.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<SelectDialog\n        xmlns="sap.m"\n        xmlns:core="sap.ui.core"\n        \n        title="{i18n>SELECT_TRANSACTION_TYPE}"\n       \n        multiSelect=""\n        items="{processTypes>/TransactionTypeSet}"\n       \tsearch="searchProcess"\n        confirm="selectProcess"\n        cancel="cancelProcess">\n    <StandardListItem title="{processTypes>processTypeDescription}" description="{processTypes>processTypeCode}">\n        <customData>\n            <core:CustomData key="ProcessTypeCode" value="{processTypes>processTypeCode}"/>\n            <core:CustomData key="ProcessTypeDescription" value="{processTypes>processTypeDescription}" />\n            <core:CustomData key="PrivateFlag" value="{processTypes>privateFlag}" />\n        </customData>\n    </StandardListItem>\n</SelectDialog>',
	"cus/crm/myaccounts/view/overview/Quickoverview.controller.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
/*global jQuery: false, sap: false, cus: false, console: false, window : false */
/*jslint plusplus: true */
jQuery.sap.require("cus.crm.myaccounts.util.Util");
(function () {
	'use strict';
	sap.ui.controller("cus.crm.myaccounts.view.overview.Quickoverview", {
		
		onInit: function(){
			var locale = new sap.ui.core.LocaleData(sap.ui.getCore().getConfiguration().getLocale());
			var i18nModel = new sap.ui.model.resource.ResourceModel({
				bundleName : "cus.crm.myaccounts.i18n.i18n",
				bundleLocale : locale
			});

			this.getView().setModel(i18nModel, "i18n");
		},

		onPhoneTaped:function (oEvent) {
			sap.m.URLHelper.triggerTel(oEvent.getSource().getText());
		},
		
		onEmailTaped:function (oEvent) {
			sap.m.URLHelper.triggerEmail(oEvent.getSource().getText());
		},
		
		onMapIconPressed: function () {
			sap.m.URLHelper.redirect("http"+"://"+"maps.apple.com/?q="+this.getView().getModel().getProperty("/Company/Address/address").split("\n").join(" "), !sap.ui.Device.system.phone);
		}
		
	});
}());
},
	"cus/crm/myaccounts/view/overview/Quickoverview.view.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View\n     xmlns:core="sap.ui.core"\n\t xmlns:mvc="sap.ui.core.mvc"\n\t xmlns:form="sap.ui.layout.form"\n\t xmlns="sap.m"\n\t xmlns:layout="sap.ui.layout"\n\t controllerName="cus.crm.myaccounts.view.overview.Quickoverview"\n     xmlns:html="http://www.w3.org/1999/xhtml"\n     resourceBundleName="sap.ca.ui.i18n.i18n" resourceBundleAlias="ca_i18n">\n     \n\t<form:SimpleForm id="quickOverviewForm1" class="bcUpperContainer" minWidth="1024" maxContainerCols="2">\n\t\t<form:content>\n\t\t\t<Label text="{ca_i18n>Quickoverview.company.maincontactmobile}"/>\n\t\t\t<Link text="{/Person/Address/mobilePhone}" press="onPhoneTaped"/>\n\t\t\t<Label text="{ca_i18n>Quickoverview.company.maincontactphone}"/>\n\t\t\t<Link text="{/Person/Address/phone}" press="onPhoneTaped"/>\n\t\t\t<Label text="{ca_i18n>Quickoverview.company.maincontactemail}"/>\n\t\t\t<Link text="{/Person/Address/email}" press="onEmailTaped"/>\n\t\t\t<Label text=""/>\n\t\t\t<Text text=""/>\n\t\t</form:content>\n\t</form:SimpleForm>\n\t\n\t<form:SimpleForm id="quickOverviewForm2" class="bcLowerContainer" minWidth="1024" maxContainerCols="2">\n\t\t<form:content>\n\t\t\t<core:Title text="{ca_i18n>Quickoverview.employee.companytitle}"/>\n\t\t\t<Label text="{i18n>COMPANY_NAME}"/>\n\t\t\t<Text text="{/Company/name}"/>\n\t\t\t<Label text="{ca_i18n>Quickoverview.company.address}"/>\n\t\t\t<layout:HorizontalLayout>\n\t\t\t\t<Text text="{/Company/Address/address}"/>\n\t\t\t\t<layout:HorizontalLayout id="mapIcon" visible="false">\n\t\t\t\t\t<core:Icon src="sap-icon://map" press="onMapIconPressed" size="1.2rem" class="cusMyAccountsPaddingLeft" visible="{parts:[\'/Company/Address/address\'], formatter: \'cus.crm.myaccounts.util.formatter.isNotInitial\'}" />\n\t\t\t\t</layout:HorizontalLayout>\n\t\t\t</layout:HorizontalLayout>\n\t\t</form:content>\n\t</form:SimpleForm>\n\t\n\t<Label id="bindingLabel" visible="false"></Label>\n</core:View>',
	"cus/crm/myaccounts/view/overview/Quotations.controller.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
sap.ui.controller("cus.crm.myaccounts.view.overview.Quotations", {

	/**
	* Called when a controller is instantiated and its View controls (if available) are already created.
	* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
	* @memberOf view.overview.Quotations
	*/
	onInit: function() {
		this.customizingModel = null;
	},
	
	onItemSelected: function(){
		this._readCustomizing();
		var oAccountContext = this.getView().getBindingContext();
		var oCustomer = oAccountContext.getProperty("ERPCustomer");
		if(oCustomer && oCustomer.customerNumber){
			var oModel = this.getView().getModel("ERP_BUPA_ODATA");
			var oCustomerContext = new sap.ui.model.Context(oModel, "CustomerCollection('"+oCustomer.customerNumber+"')");
			this.getView().setBindingContext(oCustomerContext, "ERP_BUPA_ODATA");
		}
		else{
			this.getList()._hideBusyIndicator();
		}
	},
	
	onReset: function(){
		this.getView().setBindingContext(undefined, "ERP_BUPA_ODATA");
		this.getList().removeAllItems();
	},
	
	getList: function ( ) {
		return this.byId("list");
	},
	
	onInitPersonalization: function(){
		var oTable = this.getList();
		
		return{
			tablePersonalization: {
				table: oTable
			}
		};
	},
	
	onQuotationLinkPressed: function(oEvent){
		clearTimeout(this.moseOverTimer);
		var quotationID = oEvent.getSource().getBindingContext("ERP_BUPA_ODATA").getObject().quotationID;
		this._navToQuotation(quotationID);
	},
	
	_navToQuotation: function(quotationID) {
		// *XNav* (1) obtain cross app navigation interface
		var fgetService = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService;
		var oCrossAppNavigator = fgetService && fgetService("CrossApplicationNavigation");

		// *XNav (2) generate cross application link
		oCrossAppNavigator.toExternal({
			target : {
				semanticObject : "SalesQuotation",
				action : "displayMyQuotations&/display/"+quotationID
			}
		});// EXC_JSHINT_021
	},
	
	onAmountLinkPressed: function(oEvent) {
		var oLink = oEvent.getSource();
		this._displayPopover(oLink);
	},

	_displayPopover: function(oLink) {
		
		if(this._oPopover)
			this._oPopover.destroy();

    	this._oPopover = sap.ui.xmlfragment("cus.crm.myaccounts.view.overview.ItemsQuickoverview", this);
    	this._oPopover.setBindingContext(oLink.getBindingContext("ERP_BUPA_ODATA"), "ERP_BUPA_ODATA");
    	this.getView().addDependent(this._oPopover);

	    // delay because addDependent will do an async rerendering and the actionSheet will immediately close without it.
	    jQuery.sap.delayedCall(0, this, function() {
	    	this._oPopover.openBy(oLink);
	    });
	},

	_readCustomizing: function(callbackCustomizingRead){
		
		if(this.customizingModel)
			return;
		
		this.customizingModel = new sap.ui.model.json.JSONModel({ApplicationCustomizing: {}});
		this.getView().setModel(this.customizingModel, "Customizing");
		
		var that = this;
		var fnAfterRead = function(oResponses){
			var oApplicationCustomizing = oResponses["ApplicationCustomizing"];
			that.customizingModel.setProperty("/ApplicationCustomizing", oApplicationCustomizing);
			if (callbackCustomizingRead)
				callbackCustomizingRead.call(that);
			};
		var oModel = this.getView().getModel("ERP_BUPA_ODATA");
		cus.crm.myaccounts.util.Util.sendBatchReadRequests(oModel, ["ApplicationCustomizing"], fnAfterRead,fnAfterRead);
	}

/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf view.overview.Quotations
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf view.overview.Quotations
*/
//	onAfterRendering: function() {
//
//	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf view.overview.Quotations
*/
//	onExit: function() {
//
//	}

});
},
	"cus/crm/myaccounts/view/overview/Quotations.view.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core" xmlns:mvc="sap.ui.core.mvc" xmlns="sap.m"\n\t\t\tcontrollerName="cus.crm.myaccounts.view.overview.Quotations" xmlns:html="http://www.w3.org/1999/xhtml">\n\t<Table\n   \t\tid="list"\n\t\tmode="{device>/listMode}"\n\t\tgrowing="true"\n       \tgrowingThreshold="10"\n       \tgrowingScrollToLoad="false"\n       \titems="{ERP_BUPA_ODATA>Quotations}">\n        <columns>\n          <Column id="idCol" minScreenWidth="Small" demandPopin="true"><Label text="{i18n>ID}" /></Column>\n          <Column id="amountCol" minScreenWidth="Small" demandPopin="true"><Label text="{i18n>AMOUNT}" /></Column>\n          <Column id="expirationDateCol" minScreenWidth="Small" demandPopin="true"><Label text="{i18n>EXPIRATION_DATE}" /></Column>\n          <Column id="statusCol" minScreenWidth="Small" demandPopin="true"><Label text="{i18n>STATUS}" /></Column>\n        </columns>\n        <items>\n        \t<ColumnListItem id="columnListItem">\n        \t\t<cells>\n\t\t            <Link text="{ERP_BUPA_ODATA>quotationID}" press="onQuotationLinkPressed"/>\n\t\t            <Link text="{parts:[{path: \'ERP_BUPA_ODATA>netValue\'}, {path: \'ERP_BUPA_ODATA>currency\'}],  formatter:\'cus.crm.myaccounts.util.formatter.formatAmounts\'}"\n\t\t            \t  press= "onAmountLinkPressed"/>\n\t\t            <Text text="{parts:[{path:\'ERP_BUPA_ODATA>validTo\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatMediumDate\' }"/>\n\t\t            <ObjectStatus text="{ERP_BUPA_ODATA>status}" state="{parts:[{path:\'ERP_BUPA_ODATA>validTo\'},{path:\'ERP_BUPA_ODATA>status\'}, {path:\'Customizing>/ApplicationCustomizing/redThreshold\'}], formatter:\'cus.crm.myaccounts.util.formatter.formatExpiryState\'}"/>\n            \t</cells>\n        \t</ColumnListItem>\n    \t</items>\n   \t</Table>\n    \t\n</core:View>\n',
	"cus/crm/myaccounts/view/overview/SalesOrders.controller.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
sap.ui.controller("cus.crm.myaccounts.view.overview.SalesOrders", {

	/**
	* @memberOf view.overview.SalesOrders
	*/
	onItemSelected: function() {
		var oAccountContext = this.getView().getBindingContext();
		var oCustomer = oAccountContext.getProperty("ERPCustomer");
		if(oCustomer && oCustomer.customerNumber) {
			var oModel = this.getView().getModel("ERP_BUPA_ODATA");
			var oCustomerContext = new sap.ui.model.Context(oModel, "CustomerCollection('"+oCustomer.customerNumber+"')");
			this.getView().setBindingContext(oCustomerContext, "ERP_BUPA_ODATA");
		}
		else {
			this.getList().setBusy(false);
		}
	},

	onReset: function() {
		this.getView().setBindingContext(undefined, "ERP_BUPA_ODATA");
		this.getList().removeAllItems();
	},

	getList: function( ) {
		return this.byId("list");
	},

	onInitPersonalization: function() {
		var oTable = this.getList();

		return {
			tablePersonalization: {
				table: oTable
			}
		};
	},

	onSalesOrderLinkPressed: function(oEvent) {
		var salesOrderID = oEvent.getSource().getBindingContext("ERP_BUPA_ODATA").getObject().salesOrderID;
		this._navToSalesOrder(salesOrderID);
	},

	_navToSalesOrder: function(salesOrderID) {
		// *XNav* (1) obtain cross app navigation interface
		var fgetService = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService;
		var oCrossAppNavigator = fgetService && fgetService("CrossApplicationNavigation");

		// *XNav (2) generate cross application link
		oCrossAppNavigator.toExternal({
			target : {
				semanticObject : "SalesOrder",
				action : "track&/display/SalesOrders('" + salesOrderID + "')"
			}
		});// EXC_JSHINT_021
	},

	onAmountLinkPressed: function(oEvent) {
		var oLink = oEvent.getSource();
		this._displayPopover(oLink);
	},

	_displayPopover: function(oLink) {
		if(this._oPopover)
			this._oPopover.destroy();

    	this._oPopover = sap.ui.xmlfragment("cus.crm.myaccounts.view.overview.ItemsQuickoverview", this);
    	this._oPopover.setBindingContext(oLink.getBindingContext("ERP_BUPA_ODATA"), "ERP_BUPA_ODATA");
    	this.getView().addDependent(this._oPopover);

	    // delay because addDependent will do an async rerendering and the actionSheet will immediately close without it.
	    jQuery.sap.delayedCall(0, this, function() {
	    	this._oPopover.openBy(oLink);
	    });
	}

/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf view.overview.SalesOrders
*/
//	onInit: function() {
//		
//	},

/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf view.overview.SalesOrders
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf view.overview.SalesOrders
*/
//	onAfterRendering: function() {
//
//	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf view.overview.SalesOrders
*/
//	onExit: function() {
//
//	}

});
},
	"cus/crm/myaccounts/view/overview/SalesOrders.view.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core" xmlns:mvc="sap.ui.core.mvc" xmlns="sap.m" xmlns:layout="sap.ui.layout"\n\t\t\tcontrollerName="cus.crm.myaccounts.view.overview.SalesOrders" xmlns:html="http://www.w3.org/1999/xhtml">\n\t<Table\n   \t\tid="list"\n\t\tmode="{device>/listMode}"\n\t\tgrowing="true"\n        growingThreshold="10"\n        growingScrollToLoad="false"\n        items="{path:\'ERP_BUPA_ODATA>SalesOrders\',\n         \t\tsorter:[{path:\'postingDate\'}]}">\n        <columns>\n          <Column id="idCol" minScreenWidth="Small" demandPopin="true"><Label text="{i18n>ID}" /></Column>\n          <Column id="salesEmployee" minScreenWidth="Small" demandPopin="true"><Label text="{i18n>SALES_EMPLOYEE}" /></Column>\n          <Column id="amountCol" minScreenWidth="Small" demandPopin="true"><Label text="{i18n>AMOUNT}" /></Column>\n          <Column id="deliveryDateCol" minScreenWidth="Small" demandPopin="true"><Label text="{i18n>DELIVERY_DATE}" /></Column>\n          <Column id="statusCol" minScreenWidth="Small" demandPopin="true"><Label text="{i18n>STATUS}" /></Column>\n        </columns>\n        <items>\n        \t<ColumnListItem id="columnListItem">\n            \t<cells>\n\t\t            <Link text="{ERP_BUPA_ODATA>salesOrderID}" press="onSalesOrderLinkPressed"/>\n            \t\t<Text text="{ERP_BUPA_ODATA>salesEmployeeName}"/>\n\t\t            <Link text="{parts:[{path: \'ERP_BUPA_ODATA>netValue\'}, {path: \'ERP_BUPA_ODATA>currency\'}],  formatter:\'cus.crm.myaccounts.util.formatter.formatAmounts\'}"\n\t\t            \t  press= "onAmountLinkPressed"/>\n\t\t            <Text text="{parts:[{path:\'ERP_BUPA_ODATA>postingDate\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatMediumDate\' }"/>\n\t\t            <ObjectStatus text="{ERP_BUPA_ODATA>status}" state="{path:\'ERP_BUPA_ODATA>statusID\', formatter:\'cus.crm.myaccounts.util.formatter.formatSalesOrderStatusText\'}"/>\n            \t</cells>\n        \t</ColumnListItem>\n    \t</items>\n   \t</Table>\n    \t\n</core:View>',
	"cus/crm/myaccounts/view/overview/Tasks.controller.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("cus.crm.myaccounts.util.Util");
jQuery.sap.require("sap.m.MessageBox");
jQuery.sap.require("sap.ca.ui.message.message");

sap.ui.controller("cus.crm.myaccounts.view.overview.Tasks", {

	getList: function() {
		return this.byId("taskList");
	},

	onSubViewLiveSearch: function(searchString) {
		var oBinding = this.getList().getBinding("items");
		var aFilters = [];
		if(searchString !== "")
			aFilters.push(new sap.ui.model.Filter("description", sap.ui.model.FilterOperator.Contains, searchString));
		if(oBinding)
			oBinding.filter(aFilters);
	},

	onItemSelected: function(){
		this._adaptItems();
	},

	onListItemPressed: function(oEvent){
		this._navigateToTask(oEvent.getSource().getBindingContext());
	},

	_adaptItems: function(){
		var oList = this.byId("taskList");

    	var fnUpdateFinishedHandler = null;
    	fnUpdateFinishedHandler = jQuery.proxy(function () {

    		var aItems = oList.getItems();
    		for(var i in aItems){
    			var oItem = aItems[i];
    			oItem.getModeControl().setProperty("editable", false);
    			if (oItem.isSelected())
    				this._greyOutItem(oItem);
    		}

    	}, this);

    	oList.attachUpdateFinished(fnUpdateFinishedHandler);
	},

	_navigateToTask: function(oTask){
		if(sap.ushell && sap.ushell.Container) {
			var fgetService =  sap.ushell.Container.getService;
			if(fgetService) {
				var oCrossAppNavigator = fgetService("CrossApplicationNavigation");
				if(oCrossAppNavigator){
					oCrossAppNavigator.toExternal({
						target : {
							semanticObject : "Task",
							action : "manageTasks"
						},
						params: {
							fromAccount: "X"
						},
						appSpecificRoute : "&/taskOverview/Tasks(guid'" + oTask.getProperty("Guid") + "')"
					});
				}
			}
		}
	},

	_greyOutItem : function(oItem) {
		var bgColor = sap.ui.core.theming.Parameters
				.get("sapUiExtraLightBG");
		oItem.$().css("background-color", bgColor);
		var txtColor = sap.ui.core.theming.Parameters
				.get("sapUiExtraLightText");
		oItem.$().find("span").css("color", txtColor);
		oItem.$().find("span").css("opacity", "0.8");
	},

	onStoreCurrentStateSupported: function(){
		return true;
	},

	onStoreCurrentState: function(storage){
		storage.contextPath = "";
		var oBus = sap.ui.getCore().getEventBus();

		// Listen to event that a task has been changed and store
		// the context path of the task which has to be refreshed.
		storage.onRefreshContextPath = function(channelId, eventId, data){
			// In case no other event has happened before so that all tasks should
			// be refreshed, store the context path of the task which has to be refreshed.
			if(storage.action !== "refreshList") {
				storage.action = "refreshContextPath";
				storage.contextPath = data.contextPath.replace("/Tasks", "TaskCollection");
			}
		};

		// Listen to events that a task has been created. In case
		// such an event happens, refresh the whole list of tasks.
		storage.onRefreshList = function() {
			storage.action = "refreshList";
		};
		oBus.subscribe("cus.crm.mytasks", "taskChanged", storage.onRefreshContextPath, storage);
		oBus.subscribe("cus.crm.mytasks", "followUpTaskCreated", storage.onRefreshList, storage);
		oBus.subscribe("cus.crm.mytasks", "taskCreated", storage.onRefreshList, storage);
		oBus.subscribe("cus.crm.mytasks", "taskDeleted", storage.onRefreshList, storage);

		// Remove all event listeners
		storage.onExit = function() {
			var oBus = sap.ui.getCore().getEventBus();
			oBus.unsubscribe("cus.crm.mytasks", "taskChanged", storage.onRefreshContextPath, storage);
			oBus.unsubscribe("cus.crm.mytasks", "followUpTaskCreated", storage.onRefreshList, storage);
			oBus.unsubscribe("cus.crm.mytasks", "taskCreated", storage.onRefreshList, storage);
			oBus.unsubscribe("cus.crm.mytasks", "taskDeleted", storage.onRefreshList, storage);
		};
	},

	onRestoreCurrentState: function(storage){
		if(storage.action === "refreshList") {
			this.getList().getBinding("items").refresh();
		} else if(storage.action === "refreshContextPath"){
			var oRefreshUIObject = cus.crm.myaccounts.util.Util.getRefreshUIObject(this.getView().getModel(), "/"+storage.contextPath);
			oRefreshUIObject.refresh();
		}
	},
	// ///////////////////////////////////////////////////////////////////////////////
	// add task
	// ///////////////////////////////////////////////////////////////////////////////

	getFooterButtons: function(){
		var that = this;
		return [{
				sIcon:"sap-icon://add",
				sTooltip: cus.crm.myaccounts.util.Util.geti18NText("ADD_TASK_TOOLTIP"),
				onBtnPressed:function () {
					that.onCreateTask();
				}
		}];
	},	

	onCreateTask : function() {

		var oDataModel = this.getView().getModel();
		
		var that = this;
		var fnShowTransactionTypes = function(oResponses){
			
			var aProcessTypes;
			
			if(!that.processTypeModel) {
				aProcessTypes = oResponses["CustomizingTaskTypeCollection"];
				that.processTypeModel = new sap.ui.model.json.JSONModel();
				that.processTypeModel.setProperty("/TransactionTypeSet", aProcessTypes);
			} else {
				aProcessTypes = that.processTypeModel.getProperty("/TransactionTypeSet");
			}
	
			if (aProcessTypes.length === 1) {
				var processType = aProcessTypes[0].processTypeCode;
				that._navigateToCreationOfTask(processType);
			} else {
				that.oProcessTypeDialog = sap.ui.xmlfragment("cus.crm.myaccounts.view.overview.ProcessTypeDialog", that);
				that.oProcessTypeDialog.setModel(that.getView().getModel("i18n"), "i18n");
				that.oProcessTypeDialog.setModel(that.processTypeModel, "processTypes");
				that.oProcessTypeDialog.open();
			}
		};
		if(!that.processTypeModel)
			cus.crm.myaccounts.util.Util.sendBatchReadRequests(oDataModel, ["CustomizingTaskTypeCollection"], fnShowTransactionTypes);
		else
			fnShowTransactionTypes.call(that);
	},

	selectProcess: function(oEvent) {
		var oSelectedItem = oEvent.getParameter("selectedItem");
		if(oSelectedItem) {
			this._navigateToCreationOfTask(oSelectedItem.data("ProcessTypeCode"));
		} 
	},

	_navigateToCreationOfTask: function(processType){
		if(sap.ushell && sap.ushell.Container) {
			var fgetService = sap.ushell.Container.getService;
			if (fgetService){
				var oCrossAppNavigator = fgetService("CrossApplicationNavigation");
				if(oCrossAppNavigator){
					var accountID = this.getView().getModel().getProperty(this.getView().getBindingContext().sPath).accountID;
					oCrossAppNavigator.toExternal({
						target : {
							semanticObject : "Task",
							action : "manageTasks"
						},
						params: {
							createFromAccount: "X",
							accountID : accountID
						},
						appSpecificRoute : "&/newTask/" + processType
					}); 
				}
			}
		}
	},

	searchProcess: function(oEvent) {
		
		var oItemsBinding = oEvent.getParameter("itemsBinding");
		var oItemsBindingFiltered;

		this.oProcessTypeDialog.setNoDataText(cus.crm.myaccounts.util.Util.geti18NText("LOADING_TEXT"));
		var searchString = oEvent.getParameter("value");
		if(searchString !== undefined) {
			// Apply the filter to the bound items, and the Select Dialog will update
			oItemsBindingFiltered = oItemsBinding.filter([new sap.ui.model.Filter("processTypeDescription", sap.ui.model.FilterOperator.Contains, searchString)]);

			if(oItemsBindingFiltered.getLength() === 0) {
				this.oProcessTypeDialog.setNoDataText(cus.crm.myaccounts.util.Util.geti18NText("NO_DATA_TEXT"));
			}
		}
	},

	onQuickCreationOfTask: function(oEvent) {
		this._setBusy(true);
		var taskDescription = oEvent.getSource().getValue();
		this._quickCreateTask(taskDescription);
	},

	_quickCreateTask: function(taskDescription) {
		var oModel = this.getView().getModel();
		var oContext = this.getView().getBindingContext();
		var contextPath = oContext.getPath();
		var oAccount = oContext.getObject();

		// Set properties of task
		var oTask = {
				"description" : taskDescription,
				"accountID" : oAccount ? oAccount.accountID : "",		
				"dueDate" : new Date()
		};

		// Send request for task creation to backend
		var that = this;
		cus.crm.myaccounts.util.Util.sendBatchChangeOperations(
				oModel, [oModel.createBatchOperation(contextPath + "/Tasks", "POST", oTask)],
				function() {
					that._setBusy(false);
					sap.m.MessageToast.show(cus.crm.myaccounts.util.Util.geti18NText("MSG_TASK_CREATION_SUCCESS"));
				},
				function(oError) {
					that._setBusy(false);
					sap.m.MessageBox.alert(oError.message.value);
				}
		);
	},

	_setBusy: function(busy) {
		var that = this;
		if(!this.oBusyDialog)
			this.oBusyDialog = new sap.m.BusyDialog();			
		if(busy) {
			this.liveChangeTimer = window.setTimeout(function() {
				that.oBusyDialog.open();
			},700);
			this.byId("taskInput").setEnabled(false);
		}
		else{
			window.clearTimeout(this.liveChangeTimer);
			this.oBusyDialog.close();
			this.byId("taskInput").setEnabled(true).setValue("");
		}
	},

	onCleanUp: function() {
		// Empty input field for quick create
		this.byId("taskInput").setValue("");
	}

/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf view.overview.Tasks
*/
//	onInit: function() {
//
//	},

/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf view.overview.Tasks
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf view.overview.Tasks
*/
//	onAfterRendering: function() {
//
//	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf view.overview.Tasks
*/
//	onExit: function() {
//
//	}

});
},
	"cus/crm/myaccounts/view/overview/Tasks.view.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core" xmlns:mvc="sap.ui.core.mvc" xmlns="sap.m"\n\t\t\tcontrollerName="cus.crm.myaccounts.view.overview.Tasks" xmlns:html="http://www.w3.org/1999/xhtml">\n\n\t<FeedInput \n\t    id="taskInput"\n\t    post="onQuickCreationOfTask"\n\t    showIcon="false"\n\t    placeholder="{i18n>NEW_TASK_INPUT_PLACEHOLDER}" />\n\t<List id="taskList"\n\t\tgrowing="true" growingScrollToLoad="false" mode="MultiSelect"\n\t\tselect="markTaskCompleted" growingThreshold="10" \n\t\titems="{path:\'Tasks\', sorter: [{path: \'dueDate\', descending: true}]}" >\n\t\t<ObjectListItem id="task"\n\t\t\ttype="Active"\n\t\t\tselected="{completed}"\n\t\t\ttitle="{description}"\n\t\t\tpress="onListItemPressed">\n\t\t\t\t<secondStatus>\n\t\t\t\t\t<ObjectStatus\n\t\t\t\t\t\tstate="None"\n\t\t\t\t\t\ttext="{path:\'dueDate\', formatter:\'cus.crm.myaccounts.util.formatter.formatMediumDate\'}" />\n\t\t\t\t</secondStatus>\n\t\t\t\t<attributes>\n\t\t\t\t\t<ObjectAttribute text="{note}" />\n\t\t\t\t\t<ObjectAttribute text="{contactName}" />\n\t\t\t\t</attributes>\n\n\t\t</ObjectListItem>\n\t</List>\n</core:View>\n',
	"cus/crm/myaccounts/view/search/SearchResult.controller.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");
jQuery.sap.require("cus.crm.myaccounts.util.Constants");
jQuery.sap.require("cus.crm.myaccounts.util.formatter");
jQuery.sap.require("cus.crm.myaccounts.util.Util");
jQuery.sap.require("sap.ca.ui.utils.TablePersonalizer");
jQuery.sap.require("sap.m.TablePersoDialog");
jQuery.sap.require("sap.m.TablePersoController");

sap.ca.scfld.md.controller.BaseFullscreenController.extend("cus.crm.myaccounts.view.search.SearchResult", {

	/**
	 * @memberOf view.search.SearchResult
	 */
	configurationMode: false,

	onInit: function() {
		if(cus.crm.myaccounts.view.overview && cus.crm.myaccounts.view.overview.OverviewPage.storage) {
			if(cus.crm.myaccounts.view.overview.OverviewPage.storage.onExit) {
				cus.crm.myaccounts.view.overview.OverviewPage.storage.onExit();
			}
			cus.crm.myaccounts.view.overview.OverviewPage.storage = null;
		}

		this.EHP2Backend = cus.crm.myaccounts.util.Util.getServiceSchemaVersion(this.getView().getModel(), "AccountCollection") < 1;
		
		this._initPersonalization();
		this.oRouter.attachRouteMatched(this._handleNavToWithFilter, this);
	},

	// #############################################################################################
	// Filtering
	// #############################################################################################

	getList: function() {
		return this.byId("list");
	},

	_handleNavToWithFilter: function(oEvent) {
		// In case of doing a cross-app navigation from MyAccounts to another app
		// and then doing a back navigation to the result list in MyAccounts,
		// the filter should be kept
		jQuery.sap.log.debug("cus.crm.myaccounts.view.search.SearchResult - handleNavTo");
		if(oEvent.getParameter("name") === "mainPage" || oEvent.getParameter("name") === "S2") {
			var filterState = oEvent.getParameter("arguments").filterState;
			if(filterState) {
				this.selectedKey = filterState;
			} else {
				this.selectedKey = cus.crm.myaccounts.util.Constants.filterMyAccounts;
			}
			this._bindTable();
			this.setHeaderFooterOptions(this._getHeaderFooterOptions());
		}
	},

	_bindTable: function(refreshBinding) {
		if(!this.personalizationLoadFinished || !this.selectedKey)
			return;
		var oList = this.getList();
		var oBindingParameters = this._getParametersFromPersonalization();
		if(oList && (!oList.getBinding("items") || refreshBinding)) {
			oList.bindAggregation("items", {
				path : '/AccountCollection',
				filters : this._getFilters(),
				parameters : oBindingParameters,
				template : oList.getItems()[0].clone()
			});
			oList.getBinding("items").attachChange(this._onBindingChange, this);
		}
	},

	_getPossibleAccountFilters: function() {
		if(this.EHP2Backend) {
			return [cus.crm.myaccounts.util.Constants.filterMyAccounts,
			        cus.crm.myaccounts.util.Constants.filterAllAccounts];
		}
		return [cus.crm.myaccounts.util.Constants.filterMyAccounts,
		        cus.crm.myaccounts.util.Constants.filterMyIndividualAccounts,
		        cus.crm.myaccounts.util.Constants.filterMyCorporateAccounts,
		        cus.crm.myaccounts.util.Constants.filterMyAccountGroups,
		        cus.crm.myaccounts.util.Constants.filterAllAccounts,
		        cus.crm.myaccounts.util.Constants.filterAllIndividualAccounts,
		        cus.crm.myaccounts.util.Constants.filterAllCorporateAccounts,
		        cus.crm.myaccounts.util.Constants.filterAllAccountGroups];
	},

	_getAccountFilterItems: function() {
		var aAccountFilters = this._getPossibleAccountFilters();
		var aAccountFilterItems = [];
		var i;
		for(i = 0; i < aAccountFilters.length; i++) {
			aAccountFilterItems.push({
				text: cus.crm.myaccounts.util.Util.geti18NText(aAccountFilters[i]),
				key: aAccountFilters[i]
			});
		}
		return aAccountFilterItems;
	},

	_getFilters: function() {
		var aFilters = [];

		// Add filter with search value
		var	searchValue = this.byId("mySearchField").getValue();
		if(searchValue && searchValue.length > 0) {
			aFilters.push(new sap.ui.model.Filter("fullName", sap.ui.model.FilterOperator.Contains, searchValue));
		}

		// Add filter for property "isMyAccount"
		var	isMyAccounts = this.selectedKey.indexOf("MY") >= 0;
		aFilters.push(new sap.ui.model.Filter("isMyAccount", sap.ui.model.FilterOperator.EQ, isMyAccounts));

		// Add filter with account category
		if(this.selectedKey.indexOf("INDIVIDUAL") >= 0) {
			aFilters.push(new sap.ui.model.Filter("category", sap.ui.model.FilterOperator.EQ, cus.crm.myaccounts.util.Constants.accountCategoryPerson));
		} else if(this.selectedKey.indexOf("CORPORATE") >= 0) {
			aFilters.push(new sap.ui.model.Filter("category", sap.ui.model.FilterOperator.EQ, cus.crm.myaccounts.util.Constants.accountCategoryCompany));
		} else if(this.selectedKey.indexOf("GROUP") >= 0) {
			aFilters.push(new sap.ui.model.Filter("category", sap.ui.model.FilterOperator.EQ, cus.crm.myaccounts.util.Constants.accountCategoryGroup));
		}

		return aFilters;
	},

	_applyFilter: function() {
		var oBinding = this.getList().getBinding("items");
		// When calling this method the first time, aApplicationFilters
		// contains custom filters. These filters have to be removed
		// in order to filter with the desired filters.
		oBinding.aApplicationFilters = [];
		// Apply the current filter to update master list binding
		oBinding.filter(this._getFilters());
	},

	_setFilterInURL:function () {
		this.oRouter.navTo("mainPage", {"filterState": this.selectedKey}, true);
	},

	_onBindingChange: function() {
		var title = "";
		switch(this.selectedKey) {
			case cus.crm.myaccounts.util.Constants.filterMyAccounts:
				title = "MY_ACCOUNT_TITLE";
				break;
			case cus.crm.myaccounts.util.Constants.filterMyIndividualAccounts:
				title = "MY_INDIVIDUAL_ACCOUNT_TITLE";
				break;
			case cus.crm.myaccounts.util.Constants.filterMyCorporateAccounts:
				title = "MY_CORPORATE_ACCOUNT_TITLE";
				break;
			case cus.crm.myaccounts.util.Constants.filterMyAccountGroups:
				title = "MY_ACCOUNT_GROUP_TITLE";
				break;
			case cus.crm.myaccounts.util.Constants.filterAllAccounts:
				title = "ALL_ACCOUNTS_TITLE";
				break;
			case cus.crm.myaccounts.util.Constants.filterAllIndividualAccounts:
				title = "ALL_INDIVIDUAL_ACCOUNTS_TITLE";
				break;
			case cus.crm.myaccounts.util.Constants.filterAllCorporateAccounts:
				title = "ALL_CORPORATE_ACCOUNTS_TITLE";
				break;
			case cus.crm.myaccounts.util.Constants.filterAllAccountGroups:
				title = "ALL_ACCOUNT_GROUPS_TITLE";
				break;
		}

		var count = 0;
		var oBinding = this.getList().getBinding("items");

		if(oBinding) {
			count = oBinding.getLength();
		}
		// Work around so that in the case there is a '0' count, the '0' is displayed properly in the title
		if(count > 0) {
			this._oControlStore.oTitle.setText(cus.crm.myaccounts.util.Util.geti18NText1(title, count));
		} else {
			this._oControlStore.oTitle.setText(cus.crm.myaccounts.util.Util.geti18NText1(title, "0"));
		}
	},

	// #############################################################################################
	// Search
	// #############################################################################################

	onSearchPressed: function() {
		this._applyFilter();
	},

	// #############################################################################################
	// Navigation to account details
	// #############################################################################################

	onAccountLinkClicked: function(oEvent) {
		this.oRouter.navTo("detail", {
			contextPath : oEvent.getSource().getBindingContext().getPath().replace('/', "")
		}, false);
	},

	// #############################################################################################
	// Add account
	// #############################################################################################

	_addAccount: function(oEvent) {
		if(!this.oCreateAccountActionSheet) {
			var that = this;
			var aButtons = [new sap.m.Button({
					text: cus.crm.myaccounts.util.Util.geti18NText("INDIVIDUAL_ACCOUNT"),
					id: "createIndividualAccountButton",
					press: function() {
						that._navigateToCreateScreen(cus.crm.myaccounts.util.Constants.accountCategoryPerson);
					}
				}),
				new sap.m.Button({
					text: cus.crm.myaccounts.util.Util.geti18NText("CORPORATE_ACCOUNT"),
					id: "createCorporateAccountButton",
					press: function() {
						 that._navigateToCreateScreen(cus.crm.myaccounts.util.Constants.accountCategoryCompany);
					}
				}),
				new sap.m.Button({
					text: cus.crm.myaccounts.util.Util.geti18NText("ACCOUNT_GROUP"),
					id: "createGroupAccountButton",
					press: function() {
						that._navigateToCreateScreen(cus.crm.myaccounts.util.Constants.accountCategoryGroup);
					}
				})
			];
			this.oCreateAccountActionSheet = new sap.m.ActionSheet("AddAccountActionSheet", {
				buttons: aButtons,
				placement: sap.m.PlacementType.Top
			});
		}
		this.oCreateAccountActionSheet.openBy(oEvent.getSource());
	},

	_navigateToCreateScreen: function(accountCategory) {
		this.oRouter.navTo("new", {"accountCategory": accountCategory}, false);
	},

	// #############################################################################################
	// Header and footer
	// #############################################################################################

	_getHeaderFooterOptions: function() {
		var that = this;
		var aButtonList = [];

		if(!this.EHP2Backend) {
			aButtonList.push({
				sIcon: "sap-icon://add",
				sTooltip: cus.crm.myaccounts.util.Util.geti18NText("ADD_ACCOUNT_TOOLTIP"),
				onBtnPressed: function (oEvent) {
					that._addAccount(oEvent);
			}});
		}

		// Set full-screen title with list-items count
		var fullscreenTitle = "";
		if(this._oControlStore && this._oControlStore.oTitle) {
			fullscreenTitle = this._oControlStore.oTitle.getText();
		}

		var settingButtonsText = 'BUTTON_SHOW_PERSONALIZATION';
		if(this.configurationMode){
			settingButtonsText = 'BUTTON_HIDE_PERSONALIZATION';
		}

		return {
			sFullscreenTitle: fullscreenTitle,
			aAdditionalSettingButtons:
				[
				 {
					 sI18nBtnTxt: settingButtonsText,
					 onBtnPressed: function(){that.toggleConfigurationMode();}
				 }
				],
			buttonList: aButtonList,
			oFilterOptions: {
				aFilterItems: this._getAccountFilterItems(),
				sSelectedItemKey: this.selectedKey,
				onFilterSelected: function(selectedKey) {
					jQuery.sap.log.debug("cus.crm.myaccounts.view.search.SearchResult - onFilterSelected - " + selectedKey + " has been selected");
					that.selectedKey = selectedKey;
					that._applyFilter();
					that._setFilterInURL();
				}
			},
			oAddBookmarkSettings: {
				icon : "sap-icon://Fiori2/F0002"
			}
		};
	},

	// #############################################################################################
	// Personalization
	// #############################################################################################

	_initPersonalization: function(){
		this.personalizationKey = "searchResultPersonalization";
		var oPersonalizer = sap.ushell.Container.getService("Personalization").getTransientPersonalizer();
		this.oTablePersoController= new sap.m.TablePersoController({
				table: this.getList(),
				persoService: oPersonalizer
			});

		var that = this;
		sap.ushell.Container.getService("Personalization").getContainer("cus.crm.myaccounts", { validity : Infinity })
			.fail(function() {
				that.personalizationLoadFinished = true;
				that._bindTable();
			})
			.done(function(oContainer) {
				that.oPersonalizationContainer = oContainer;
				var oPersonalizationData = oContainer.getItemValue(that.personalizationKey);
				oPersonalizer.setValue(oPersonalizationData);
				that.oTablePersoController.activate();
				that.personalizationLoadFinished = true;
				that._bindTable();
			});
	},

	isInConfigurationMode: function(){
		return this.configurationMode;
	},

	_savePersonalization: function(){
		this._bindTable(true);
		if(this.personalizationSaveRunning)
			return;
		var that = this;
		this.personalizationSaveRunning = true;
		this.oPersonalizationContainer.save()
		.fail(function() {
			that.personalizationSaveRunning = false;
		})
		.done(function() {
			// Before the next save is triggered the last one has to be finished.
			// Could be done by disabling the save button during the save.
			that.personalizationSaveRunning = false;
		});
	},

	_getParametersFromPersonalization: function(){
		var oPersonalizationData = this.oPersonalizationContainer.getItemValue(this.personalizationKey);
		var expand = "";
		var select = "*";
		var fnAddAttributeToExpandAndSelect = function(oDataAttribute){
			var aNameParts = oDataAttribute.split("/");
			//Add to the select 2 parts value, example: AccountFactsheet/opportunityVolume
			if (select.indexOf(oDataAttribute) < 0){
				if(select.length)
					select = select +",";
				select = select + oDataAttribute;
			}
			//Add to the expand the first part only, example: AccountFactsheet
			if(expand.indexOf(aNameParts[0]) < 0){
				if(expand.length)
					expand = expand +",";
				expand = expand + aNameParts[0];
			}
		};

		//Consider personalization:
		if(oPersonalizationData && oPersonalizationData.aColumns){
			for(var i in oPersonalizationData.aColumns){
				if(oPersonalizationData.aColumns[i].visible){
					var columnID = this._getColumnIDFromPersonalizationColumn(oPersonalizationData.aColumns[i]);
					var aOdataAttributes = this._getOdataAttributeFromColumn(columnID);
					for(var z in aOdataAttributes)
						fnAddAttributeToExpandAndSelect(aOdataAttributes[z], expand, select);
				}
			}
		}
		//if no personalization exists, take the columns from the view
		else{
			var aColumns = this.getList().getAggregation("columns");
			var viewID = this.getView().getId();
			for(var i in aColumns){
				if(aColumns[i].getVisible()){
					var columnID = aColumns[i].getId().replace(viewID+"--", "");
					var aOdataAttributes = this._getOdataAttributeFromColumn(columnID);
					for(var z in aOdataAttributes)
						fnAddAttributeToExpandAndSelect(aOdataAttributes[z], expand, select);
				}
			}
		}
		if(!expand.length)
			return null;

		return {
			expand : expand,
			select : select
		};
	},

	_getColumnIDFromPersonalizationColumn: function(oColumn){
		var key = oColumn.id.split("empty_component-list-")[1];
		if (!key)
			key = oColumn.id.split("cus.crm.myaccounts-list-")[1];
		return key;
	},

	_getOdataAttributeFromColumn: function(columnID){
		var oColumn = this.getView().byId(columnID);
		if(!oColumn)
			return;
		var aOdataAttributes = [];
		var aCustomData = oColumn.getCustomData();
		for(var i in aCustomData){
			var key = aCustomData[i].getKey();
			if(key === "odataAttribute")
				aOdataAttributes.push(aCustomData[i].getValue());
		}
		return aOdataAttributes;
	},

	onPersonalizationButtonPressed: function (oEvent){
		this.oTablePersoController.openDialog();
		if(!this.oTabPersonalizationDialog){
			this.oTabPersonalizationDialog = this.oTablePersoController.getTablePersoDialog();
			var that = this;
			this.oTabPersonalizationDialog.attachConfirm(
					function() {
						var oPersonalizationData = that.oTabPersonalizationDialog.retrievePersonalizations();
		    			that.oPersonalizationContainer.setItemValue(that.personalizationKey, oPersonalizationData);
		    			that._savePersonalization();
		    		}
			);
		}
	},

	toggleConfigurationMode: function(){
		this.configurationMode = !this.configurationMode;

		var oButton = this.byId("personalizationButton");
		oButton.setVisible(this.configurationMode);

		this.setHeaderFooterOptions(this._getHeaderFooterOptions());
	},

	// #############################################################################################
	// On exit
	// #############################################################################################

	destroy: function() {
		this.getList().getBinding("items").detachChange(this._onBindingChange, this);
	},

	onExit: function() {
		if(this.oCreateAccountActionSheet) {
			this.oCreateAccountActionSheet.destroy();
			this.oCreateAccountActionSheet = null;
		}
	}

});
},
	"cus/crm/myaccounts/view/search/SearchResult.view.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core" xmlns="sap.m" xmlns:layout="sap.ui.layout"\n\tcontrollerName="cus.crm.myaccounts.view.search.SearchResult">\n\t<Page id="page">\n\t\t<subHeader>\n\t\t\t<Toolbar>\n\t\t\t\t\t<SearchField id="mySearchField" search="onSearchPressed" showRefreshButton="{device>/isNoTouch}" placeholder="{i18n>SEARCH_ACCOUNTS}"/>\n\t\t\t\t\t<Button id="personalizationButton"\n\t\t\t\t\t\t\ticon="sap-icon://action-settings"\n\t\t\t\t\t\t\tvisible="{path:\'/\', formatter:\'.isInConfigurationMode\'}"\n\t\t\t\t\t\t\tpress="onPersonalizationButtonPressed"\n\t\t\t\t\t\t\tsize="1.2rem"/>\n\t\t\t</Toolbar>\n\t\t</subHeader>\n\t\t<content>\n\t\t\t<Table\n\t\t\t\tid="list"\n\t\t\t\tgrowing="true"\n\t\t\t\tgrowingThreshold="20"\n\t\t\t\tgrowingScrollToLoad="false">\n\t\t\t\t<columns>\n\t\t\t\t\t<Column id="imageColumn" width="3rem" testID="marcin" minScreenWidth="Small" demandPopin="true"><Text text="{i18n>IMAGE}"/>\n\t\t\t\t\t\t<customData><core:CustomData key="odataAttribute" value="Logo"/></customData></Column>\n\t\t\t\t\t<Column id="accountColumn" width="14rem" minScreenWidth="Small" demandPopin="true"><Text text="{i18n>NAME}" />\n\t\t\t\t\t\t<customData><core:CustomData key="odataAttribute" value="MainAddress"/></customData></Column>\n\t\t\t\t\t<Column id="ratingColumn" width="9rem" minScreenWidth="Small" demandPopin="true" visible="{device>/isNoPhone}"><Text text="{i18n>RATING}" />\n\t\t\t\t\t\t<customData><core:CustomData key="odataAttribute" value="Classification"/></customData></Column>\n\t\t\t\t\t<Column id="contactColumn" width="9rem" minScreenWidth="Medium" demandPopin="true" visible="{device>/isNoPhone}"><Text text="{i18n>CONTACT_TITLE}" />\n\t\t\t\t\t\t<customData><core:CustomData key="odataAttribute" value="MainContact"/></customData></Column>\n\t\t\t\t\t<Column id="opportunityVolumeColumn" width="7rem" minScreenWidth="Large" demandPopin="true" visible="{device>/isNoPhone}"><Text text="{i18n>OPPORTUNITIES}" />\n\t\t\t\t\t\t<customData><core:CustomData key="odataAttribute" value="AccountFactsheet/opportunityVolume"/></customData></Column>\n\t\t\t\t\t<Column id="revenueCurrentYearColumn" width="7rem" minScreenWidth="XLarge" demandPopin="true" visible="{device>/isNoPhone}"><Text text="{i18n>REVENUE_CURRENT}" />\n\t\t\t\t\t\t<customData><core:CustomData key="odataAttribute" value="AccountFactsheet/revenueCurrentYear"/></customData></Column>\n\t\t\t\t\t<Column id="lastContactColumn" width="7rem" minScreenWidth="XXLarge" demandPopin="true" visible="{device>/isNoPhone}"><Text text="{i18n>LAST_APPOINTMENT}" />\n\t\t\t\t\t\t<customData><core:CustomData key="odataAttribute" value="AccountFactsheet/lastContact"/></customData></Column>\n\t\t\t\t\t<Column id="nextContactColumn" width="7rem" minScreenWidth="XXLarge" demandPopin="true"><Text text="{i18n>NEXT_APPOINTMENT}" />\n\t\t\t\t\t    <customData><core:CustomData key="odataAttribute" value="AccountFactsheet/nextContact"/></customData></Column>\n\t\t\t\t\t<!-- Extends the Column -->\n\t\t\t\t\t<core:ExtensionPoint name="extResultListColumn"/>\n\t\t\t\t</columns>\n\t\t\t\t<items>\n\t\t\t\t\t<ColumnListItem id="columnListItem"\n\t\t\t\t\t\t\t\t \tpress="onAccountLinkClicked"\n\t\t\t\t\t\t\t\t\ttype="Active">\n\t\t\t\t\t\t<cells>\n\t\t\t\t\t\t\t<layout:VerticalLayout>\n\t\t\t\t\t\t\t\t<core:Icon\n\t\t\t\t\t\t\t\t\tsrc="{parts:[{path:\'Logo/__metadata/media_src\'},{path: \'category\'}], formatter:\'cus.crm.myaccounts.util.formatter.logoUrlFormatter\'}"\n\t\t\t\t\t\t\t\t\tvisible="{parts:[{path:\'accountID\'}, {path:\'Logo/__metadata/media_src\'}], formatter:\'cus.crm.myaccounts.util.formatter.standardIconVisibilityFormatter\'}"\n\t\t\t\t\t\t\t\t\tsize="2.5rem">\n\t\t\t\t\t\t\t\t</core:Icon>\n\t\t\t\t\t\t\t\t<Image\n\t\t\t\t\t\t\t\t\tsrc="{parts:[{path:\'Logo/__metadata/media_src\'},{path: \'category\'}], formatter:\'cus.crm.myaccounts.util.formatter.logoUrlFormatter\'}"\n\t\t\t\t\t\t\t\t\tvisible="{path:\'Logo/__metadata/media_src\', formatter:\'cus.crm.myaccounts.util.formatter.logoVisibilityFormatter\'}"\n\t\t\t\t\t\t\t\t\theight="2.5rem"\n\t\t\t\t\t\t\t\t\twidth="2.5rem">\n\t\t\t\t\t\t\t\t</Image>\n\t\t\t\t\t\t\t</layout:VerticalLayout>\n\t\t\t\t\t\t\t<VBox>\n\t\t\t\t\t\t\t\t<items>\n\t\t\t\t\t\t\t\t\t<Text id="fullNameText" text="{parts:[{path: \'fullName\'},{path: \'name1\'}], formatter: \'cus.crm.myaccounts.util.formatter.AccountNameFormatter\'}"/>\n\t\t\t\t\t\t\t\t\t<Text id="addressText" text="{parts:[{path:\'MainAddress/city\'}, {path:\'MainAddress/country\'}],formatter:\'cus.crm.myaccounts.util.formatter.locationFormatter\'}" />\n\t\t\t\t\t\t\t\t</items>\n\t\t\t\t\t\t\t</VBox>\n\t\t\t\t\t\t\t<Text text="{Classification/ratingText}" visible="{device>/isNoPhone}"/>\n\t\t\t\t\t\t\t<Text text="{MainContact/fullName}" visible="{device>/isNoPhone}"/>\n\t\t\t\t\t\t\t<Text text="{parts:[{path:\'AccountFactsheet/opportunityVolume/amount\'},{path:\'AccountFactsheet/opportunityVolume/currency\'}],\n\t\t\t\t\t\t\t\t\t\t formatter:\'cus.crm.myaccounts.util.formatter.formatShortAmounts\'}"\n\t\t\t\t\t\t\t\t  visible="{device>/isNoPhone}"/>\n\t\t\t\t\t\t\t<Text text="{parts:[{path:\'AccountFactsheet/revenueCurrentYear/amount\'},{path:\'AccountFactsheet/revenueCurrentYear/currency\'}],\n\t\t\t\t\t\t\t\t\t\t formatter:\'cus.crm.myaccounts.util.formatter.formatShortAmounts\'}"\n\t\t\t\t\t\t\t\t  visible="{device>/isNoPhone}"/>\n\t\t\t\t\t\t\t<Text text="{parts:[{path:\'AccountFactsheet/lastContact/toDate\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatMediumDate\'}"\n\t\t\t\t\t\t\t\t  visible="{device>/isNoPhone}"/>\n\t\t\t\t\t\t\t<Text text="{parts:[{path:\'AccountFactsheet/nextContact/fromDate\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatMediumDate\'}"/>\n\t\t\t\t\t\t\t<!-- Extends the Column -->\n\t\t\t\t\t\t\t<core:ExtensionPoint name="extResultListColumnContent"/>\n\t\t\t\t\t\t</cells>\n\t\t\t\t\t</ColumnListItem>\n\t\t\t\t</items>\n\t\t\t</Table>\n\n\t\t</content>\n\t</Page>\n</core:View>\n'
}});
