/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
cus.crm.myaccounts.util.Constants = {
		
		accountCategoryPerson: "1",
		accountCategoryCompany: "2",
		accountCategoryGroup: "3",

		filterMyAccounts: "MY_ACCOUNT",
		filterMyIndividualAccounts: "MY_INDIVIDUAL_ACCOUNTS",
		filterMyCorporateAccounts: "MY_CORPORATE_ACCOUNTS",
		filterMyAccountGroups: "MY_ACCOUNT_GROUPS",
		filterAllAccounts: "ALL_ACCOUNTS",
		filterAllIndividualAccounts: "ALL_INDIVIDUAL_ACCOUNTS",
		filterAllCorporateAccounts: "ALL_CORPORATE_ACCOUNTS",
		filterAllAccountGroups: "ALL_ACCOUNT_GROUPS",

		dataTypeDATE: "DATE",
		dataTypeCHAR: "CHAR",
		dataTypeCURR: "CURR",
		dataTypeNUM:  "NUM",
		dataTypeTIME: "TIME",
		dataTypeCHEC: "CHEC",
		
		modeEdit: "EDIT",
		modeDisplay: "DISPLAY",
		
		fieldDate: "FIELD_DATE",
		fieldTime: "FIELD_TIME",
		fieldInput: "FIELD_INPUT",
		fieldSelect: "FIELD_SELECT",
		fieldCurrency: "FIELD_CURR"
		
};