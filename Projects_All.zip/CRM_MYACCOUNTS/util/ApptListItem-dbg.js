/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("cus.crm.myaccounts.util.ApptListItem");
jQuery.sap.require("sap.m.ListItemBase");

sap.m.ListItemBase.extend("cus.crm.myaccounts.util.ApptListItem", {

	metadata : {
		// ---- control specific ----
		library : "cus.crm.myaccounts.util",
		defaultAggregation : "content",
		aggregations : {
			"content" : {
				type : "sap.ui.core.Control",
				multiple : true,
				singularName : "content",
				bindable : "bindable"
			}
		},

		properties : {
			"title" : {
				type : "string"
			},
			"subtitle" : {
				type : "string"
			},
			"account" : {
				type : "string"
			},
			"location" : {
				type : "string"
			},
			"time" : {
				type : "string"
			},
			"duration" : {
				type : "string"
			},
			"privat" : {
				type : "boolean"
			}
		},
		
		events : {
			"press" : {allowPreventDefault : true}
		}
	},

	renderer : {

		renderLIContent : function(oRm, oControl) {

			oRm.write("<div class='listItemCSS'");
			oRm.write(">");			

			oRm.write("<div ");
			oRm.addClass("cusMyApptLiOutter");
			oRm.writeClasses();
			oRm.write(">");
			
			// attachment needle first
			oRm.write("<div ");
			oRm.addClass("cusMyApptLiAttch");
			oRm.writeClasses();
			oRm.write(">");
			oRm.renderControl(oControl.getContent()[1]); 
			oRm.write("</div>");			
			
			// - left part of item
			oRm.write("<div ");
			oRm.addClass("cusMyApptLiLeft");
			if (sap.ui.Device.system.phone) {
				oRm.addClass("cusMyApptLiLeftPhone");// different width as no Duration is needed
			}
			oRm.addClass("cusMyApptLiPadding");
			oRm.writeClasses();
			oRm.write(">");
			// -- Time
			oRm.write("<div ");
			oRm.addClass("cusMyApptLiTime");
			oRm.addClass("cusMyApptLiEllipsis");
			oRm.addClass("sapMSLITitle");
			oRm.addClass("sapThemeText-asColor");
			oRm.writeClasses();
			oRm.write(">");
			if (oControl.getTime()) {
				oRm.writeEscaped(oControl.getTime());
			}
			oRm.write("</div>");

			// -- Duration
			if (!sap.ui.Device.system.phone) { // Duration is not shown in phone layout
				oRm.write("<div ");
				oRm.addClass("cusMyApptLiEllipsis");
				oRm.addClass("sapMSLIDescription");
				oRm.writeClasses();
				oRm.write(">");
				if (oControl.getDuration()) {
					oRm.writeEscaped(oControl.getDuration());
				}
				oRm.write("</div>");
			}
			oRm.write("</div>");

			// - middle part Item

			oRm.write("<div ");
			oRm.addClass("cusMyApptLiMiddle");
			oRm.addClass("cusMyApptLiPadding");
			if (sap.ui.Device.system.phone) {
				oRm.addClass("cusMyApptLiMiddlePhone");// different width as there is no right part
			}
			oRm.writeClasses();
			oRm.write(">");

			// -- Titel
			oRm.write("<div ");
			oRm.addClass("cusMyApptLiEllipsis");
			oRm.addClass("cusMyApptLiTitel");
			oRm.addClass("sapThemeFontSize");
			oRm.addClass("sapMSLITitle");
			oRm.writeClasses();
			oRm.write(">");
			oRm.write("<a href='javascript:void(0);' class='sapMLnk'>");
			if (oControl.getTitle()) {
				oRm.writeEscaped(oControl.getTitle());
			}
			oRm.write("</a> ");
			oRm.write("</div>");

			// -- Subtitle
			if (sap.ui.Device.system.phone) {
				// --- Phone--> Location only
				oRm.write("<div ");
				oRm.addClass("sapMSLIDescription");
				oRm.addClass("cusMyApptLiEllipsis");
				oRm.writeClasses();
				oRm.write(">");
				if (oControl.getLocation()) {
					oRm.writeEscaped(oControl.getLocation());
				}
				oRm.write("</div>");
			} else { // Desktop + Tablet
				oRm.write("<div ");
				oRm.addClass("sapMSLIDescription");
				oRm.addClass("cusMyApptLiEllipsis");
				oRm.writeClasses();
				oRm.write(">");
				if (oControl.getSubtitle()) {
					oRm.writeEscaped(oControl.getSubtitle());
				}
				oRm.write("</div>");
			}
			oRm.write("</div>");

			// - right part of item
			// is not relevant in phone layout
			if (!sap.ui.Device.system.phone) {
				oRm.write("<div ");
				oRm.addClass("cusMyApptLiRight");
				oRm.addClass("cusMyApptLiPadding");
				oRm.writeClasses();
				oRm.write(">");

				// Status
				oRm.write("<div ");
				oRm.addClass("cusMyApptLiEllipsis");
				oRm.addClass("cusMyApptLiStatus");
				oRm.addClass("sapMSLIDescription");
				oRm.writeClasses();
				oRm.write(">");
				if (oControl.getContent()[0]) {
					oRm.renderControl(oControl.getContent()[0]);
				}
				oRm.write("</div>");

				// private Icon
				oRm.write("<div ");
				oRm.addClass("cusMyApptLiEllipsis");
				oRm.addClass("sapMSLIDescription");
				oRm.writeClasses();
				oRm.write(">");
				if (oControl.getPrivat()) {
					oRm.writeEscaped(cus.crm.myaccounts.util.Util.geti18NText("PRIVATE"));
				}
				oRm.write("</div>");

				oRm.write("</div>");
			}

			oRm.write("</div>");
			oRm.write("</div>");
		}
	}

});

cus.crm.myaccounts.util.ApptListItem.M_EVENTS = {'press':'press'};

/**
 * Function is called when Link is triggered.
 *
 * @param {jQuery.Event} oEvent
 * @private
 */
cus.crm.myaccounts.util.ApptListItem.prototype._handlePress = function(oEvent) {
	if(oEvent.target.className === "sapMLnk"){
		if (!this.firePress()) { // fire event and check return value whether default action should be prevented
			oEvent.preventDefault();
		}	
	}
	else {
		oEvent.preventDefault(); // even prevent URLs from being triggered
	}
};

if (jQuery.support.touch) {
	cus.crm.myaccounts.util.ApptListItem.prototype.ontap = cus.crm.myaccounts.util.ApptListItem.prototype._handlePress;
} else {
	cus.crm.myaccounts.util.ApptListItem.prototype.onclick = cus.crm.myaccounts.util.ApptListItem.prototype._handlePress;
}


cus.crm.myaccounts.util.ApptListItem.prototype.ontouchstart = function(oEvent) {
	// for controls which need to know whether they should handle events bubbling from here
	oEvent.originalEvent._sapui_handledByControl = true;
};
