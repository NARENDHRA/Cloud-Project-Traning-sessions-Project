/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
/*global URI: false */
jQuery.sap.declare("cus.crm.myaccounts.util.formatter");
jQuery.sap.require("cus.crm.myaccounts.util.Util");
jQuery.sap.require("sap.ca.ui.model.format.DateFormat");
jQuery.sap.require("sap.ca.ui.model.format.NumberFormat");
jQuery.sap.require("sap.ca.ui.model.format.AmountFormat");

cus.crm.myaccounts.util.formatter = {};

cus.crm.myaccounts.util.formatter.formatMediumTimeInterval = function(fromDate, toDate){
	if(fromDate && toDate){
		if(fromDate.getYear() === toDate.getYear() && fromDate.getMonth() === toDate.getMonth() && fromDate.getDay() === toDate.getDay())
			return sap.ca.ui.model.format.DateFormat.getDateInstance({style: "medium"}).format(fromDate);
		else{
			return sap.ca.ui.model.format.DateFormat.getDateInstance({style: "medium"}).format(fromDate)
			+
			" - "
			+
			sap.ca.ui.model.format.DateFormat.getDateInstance({style: "medium"}).format(toDate);
		}
	}
	else {
		return "";
	}
};

cus.crm.myaccounts.util.formatter.formatMediumDateTime = function(oValue){
	if(oValue) {
		return sap.ca.ui.model.format.DateFormat.getDateTimeInstance({style: "medium"}).format(oValue);
	} else {
		return "";
	}
};

cus.crm.myaccounts.util.formatter.formatMediumDate = function(oValue){
	if(oValue){
		return sap.ca.ui.model.format.DateFormat.getDateInstance({style: "medium"}).format(oValue);
	}
	else {
		return "";
	}
};

cus.crm.myaccounts.util.formatter.formatLongDate = function(oValue){
	if(oValue){
		return sap.ca.ui.model.format.DateFormat.getDateInstance({style: "long"}).format(oValue);
	}
	else {
		return "";
	}
};

cus.crm.myaccounts.util.formatter.formatShortDate = function(oValue){
	if(oValue){
		return sap.ca.ui.model.format.DateFormat.getDateInstance({style: "short"}).format(oValue);
	}
	else {
		return "";
	}
};

cus.crm.myaccounts.util.formatter.patternShortDate = function(){
	return sap.ca.ui.model.format.DateFormat.getDateInstance({style: "short"}).innerFormat.oFormatOptions.pattern;
};

cus.crm.myaccounts.util.formatter.formatAmounts = function(sValue, sCurrency){
	if(sValue > 0 ){
        return sap.ca.ui.model.format.AmountFormat.FormatAmountStandardWithCurrency(sValue , sCurrency );
	}
	return "";
};

cus.crm.myaccounts.util.formatter.formatShortAmounts = function(sValue, sCurrency){
	if(sValue && sValue >= 0){
        return sap.ca.ui.model.format.AmountFormat.FormatAmountShortWithCurrency(sValue , sCurrency);
	}
	return "";
};


cus.crm.myaccounts.util.formatter.formatMktAttrAmountInterval = function( amount, decimalPlaces, currency){
	if ( amount && decimalPlaces && currency ){
		var aValues = amount.split(" - ");
		for(var j = 0; j < aValues.length; j++) {
			aValues[j] = cus.crm.myaccounts.util.formatter.formatMktAttrAmount(aValues[j], decimalPlaces, currency);	
		}
		return aValues.join(" - ");
	}
	return amount; //Display not converted value in case of errors
};

cus.crm.myaccounts.util.formatter.formatMktAttrAmount = function( amount, decimalPlaces, currency){
	if ( amount && decimalPlaces && currency ) {
		// format of sValueID depends on the backend personalization:
		//   it can be 123,456,789.00
		//   or        123.456.789,00
		// -> remove all thousand separators
		var sValue = amount;
		var fValue = null;
		var iDecimalPlaces = parseInt(decimalPlaces);

		if (iDecimalPlaces === 0){
			// number without decimals
			sValue = sValue.replace(/[.,]/g, ''); //remove all dots and comas
			fValue = parseFloat(sValue);
		}
		else if (amount.charAt(amount.length-iDecimalPlaces-1) === "." || amount.charAt(amount.length-iDecimalPlaces-1) === ",") {
			// there is a decimal pointer ',' or '.' on the right position
			sValue = sValue.replace(/[.,]/g, ''); //remove all dots and comas
			// set decimal pointer again
			sValue = sValue.substring(0, sValue.length-iDecimalPlaces) + "." + sValue.substring(sValue.length-iDecimalPlaces,sValue.length);	
			fValue = parseFloat(sValue);
		}
		if (fValue) {
			return sap.ca.ui.model.format.AmountFormat.FormatAmountStandardWithCurrency(fValue, currency, iDecimalPlaces );
		}
		return amount; //Display unconverted value in case of errors
	}
};

cus.crm.myaccounts.util.formatter.formatMktAttrTime = function(time){
	var aTimeParts = time.split(":");
	if(aTimeParts.length>1)
		return  aTimeParts[0]+":"+aTimeParts[1];
};

cus.crm.myaccounts.util.formatter.formatMktAttrDisplayField = function(valueID, value, attributeDatatype, decimalPlaces, currency){
	var aValues;
	switch (attributeDatatype) {
		case cus.crm.myaccounts.util.Constants.dataTypeDATE:
			aValues = valueID.split(" - ");
			for(var j = 0; j < aValues.length; j++)
				aValues[j] = cus.crm.myaccounts.util.formatter.convertStringToDate(aValues[j]);
			return aValues.join(" - ");

		case cus.crm.myaccounts.util.Constants.dataTypeTIME:
			var dateFormatter = sap.ui.core.format.DateFormat.getTimeInstance({style : "short"});
			aValues = valueID.split(" - ");
			var j;
			for(j = 0; j < aValues.length; j++) {
				aValues[j] = aValues[j].replace(":", "");
				var oDate = dateFormatter.parse(aValues[j]);
				if (oDate)
					aValues[j] = dateFormatter.format(oDate);
			}
			return aValues.join(" - ");

		case cus.crm.myaccounts.util.Constants.dataTypeCURR:
			return cus.crm.myaccounts.util.formatter.formatMktAttrAmountInterval(valueID, decimalPlaces, currency);
		default:
			return value;
	}
};

cus.crm.myaccounts.util.formatter.formatShortNumber = function(sValue, sCurrency){
	if(sValue >= 0 ){
        return sap.ca.ui.model.format.AmountFormat.FormatAmountShort(sValue , sCurrency );
	}
	return "";
};

cus.crm.myaccounts.util.formatter.formatProbability = function(sValue){
	if(sValue >= 0 ){
		return sap.ca.ui.model.format.AmountFormat.FormatAmountStandard(sValue, 3, 0) + " %";
	}
	return "";
};

cus.crm.myaccounts.util.formatter.formatEmployeeResponsible = function(sFunction){
       if(sFunction){return sFunction;}
       else{return  sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText("EMPLOYEE_RESPONSIBLE");}
};

cus.crm.myaccounts.util.formatter.formatMediumDateTime = function(oValue){
	if(oValue){
		return sap.ca.ui.model.format.DateFormat.getDateTimeInstance({style: "medium"}).format(oValue);
	}
	else {
		return "";
	}
};

cus.crm.myaccounts.util.formatter.formatStartDate = function(oValue){
	if(oValue){
		var date=sap.ca.ui.model.format.DateFormat.getDateInstance({style: "medium"}).format(oValue);
		return  sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText("STARTING",[date]);
	}
	else {
		return "";
	}
};

cus.crm.myaccounts.util.formatter.formatCloseDate = function(oValue){
	if(oValue){
		var date=sap.ca.ui.model.format.DateFormat.getDateInstance({style: "medium"}).format(oValue);
		return  sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText("CLOSING",[date]);
	}
	else {
		return "";
	}
};

cus.crm.myaccounts.util.formatter.formatDueDate = function(oValue){
	if(oValue){
		var date=sap.ca.ui.model.format.DateFormat.getDateInstance({style: "medium"}).format(oValue);
		return  sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText("DUE",[date]);
	}
	else {
		return "";
	}
};

cus.crm.myaccounts.util.formatter.mimeTypeFormatter = function(value) {

	switch (value)
	{
		case 'application/vnd.openxmlformats-officedocument.presentationml.presentation':
		case 'application/vnd.ms-powerpoint':			
			return 'pptx';
		case 'application/msword':
		case 'application/vnd.openxmlformats-officedocument.wordprocessingml.document':
			return 'doc';
		case 'application/vnd.ms-excel':
		case 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet':
			return 'xls';
		case 'image/jpeg':
		case 'image/png':
		case 'image/tiff':
		case 'image/gif':		
			return 'jpg';
		case 'application/pdf':	
			return 'pdf';
		case 'text/plain':	
			return 'txt';
		default:
			return 'unknown'; 	
	}
};

cus.crm.myaccounts.util.formatter.getRelativePathFromURL = function(absoluteURL){
	var url = document.createElement('a');
	url.href = absoluteURL;
	if(url.pathname.substring(0, 1) === "/")
		return url.pathname;
	else
		return "/" + url.pathname;
};

cus.crm.myaccounts.util.formatter.logoUrlFormatter= function (mediaUrl, category) {
	
	// Return Account Logo 
	if (mediaUrl) {
		// return relative URL
		return cus.crm.myaccounts.util.formatter.getRelativePathFromURL(mediaUrl);
	}	
	else {	
		// If not exists, return icons dependent on account category
	
		switch (category){ 
		case '1':	//individual accounts
		  	return "sap-icon://person-placeholder";
		case '2':	//corporate accounts
	      	return "sap-icon://factory";
		case '3':	//groups
	      	return "sap-icon://group";
		default:    //default behavior when category is initial
			return "sap-icon://factory";
		}
	}
};

cus.crm.myaccounts.util.formatter.uploadUrlFormatter = function(accountID) {
	if(accountID) {
		var oModel = this.getModel();
		var urlParams = oModel.sUrlParams;
		return oModel.sServiceUrl + "/AccountCollection('" + accountID + "')/Attachments" + (urlParams ? '?' + urlParams : '');
	}
	return "";
};

cus.crm.myaccounts.util.formatter.attachmentLinkFormatter = function(url, metadata) {
	// In case the attachment is a URL to a website, the property URL of
	// the attachment is filled. Return this URL.
	// Otherwise the attachment is a file
	if(url) {
		return url;
	}
	if(metadata) {
		return cus.crm.myaccounts.util.formatter.getRelativePathFromURL(metadata.media_src);
	}
};

cus.crm.myaccounts.util.formatter.logoVisibilityFormatter= function (mediaUrl) {
	return mediaUrl ? true : false;
};

cus.crm.myaccounts.util.formatter.standardIconVisibilityFormatter= function (accountId, mediaUrl) {
	return (accountId && !mediaUrl) ? true : false;
};

cus.crm.myaccounts.util.formatter.pictureUrlFormatter= function (mediaUrl) {
	return mediaUrl ? mediaUrl : "sap-icon://person-placeholder";
};

cus.crm.myaccounts.util.formatter.locationFormatter= function (oCity, oCountry) {
	if(!oCity){
		return oCountry;
	}
	else if(!oCountry){
		return oCity;
	}
	else{
		return  sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText("LOCATION",[oCity,oCountry]);
	}
};

cus.crm.myaccounts.util.formatter.leadDescriptionFormatter= function(description, id) {
	if(description) {
		if(id) {
			return description + "\n" + id;
		} else {
			return description;
		}
	} else {
		if(id) {
			return id;
		}
	}
	return "";
};

cus.crm.myaccounts.util.formatter.nameAddressFormatter= function(name, address) {
	if(name) {
		if(address) {
			return name + "\n" + address;
		} else {
			return name;
		}
	} else {
		if(address) {
			return address;
		}
	}
	return "";
};



//Formatters for Appointments
cus.crm.myaccounts.util.formatter.formatLocationContact = function(loc, contxt) {
	var sResult = "";
	sResult = loc;

	if (contxt) {
		if(sResult)
			sResult = sResult + " | " + contxt;
		else
			sResult = contxt;	
	}
	return sResult;
};

cus.crm.myaccounts.util.formatter.formatTime = function(datetime,bAllDay) {
	if(bAllDay) {
		// return string "All Day"
		return cus.crm.myaccounts.util.Util.geti18NText("ALL_DAY_EVENT");
	}
	else if (datetime) {
		if (typeof datetime === "string") {
			// mock data json now "FromDate": "/Date(1356998400000)/",

			datetime = datetime.replace("/Date(", "").replace(")/", "");
			datetime = parseInt(datetime); // number ms
			datetime = new Date(datetime);

		}
		
		//
		var locale = new sap.ui.core.LocaleData(sap.ui.getCore().getConfiguration().getLocale());
	    var pattern = locale.getTimePattern("short");
		var formatter = sap.ui.core.format.DateFormat.getDateTimeInstance({pattern: pattern });
		var sTime = formatter.format(datetime);
		return sTime;
	}
};


cus.crm.myaccounts.util.formatter.formatDuration = function(from, to) {
	
	if (from !== null && to !== null ) {
		var diffmin;
		var diffms;
	
		if (typeof from === "string") {
			from = cus.crm.myaccounts.util.formatter.getDatefromString(from);
		}

		if (typeof to === "string") {
			to = cus.crm.myaccounts.util.formatter.getDatefromString(to);
		}

		diffms = to.getTime() - from.getTime();

		// in minutes ->
		diffmin = Math.round(diffms / 60000);

		if (diffmin < 60) {
			var number = diffmin.toString();
			var min = cus.crm.myaccounts.util.Util.geti18NText1("DURATION_MINUTE", number);
			return min;
		} else {
		// rule for >= 1 Hour and < 24 hours
			if (diffmin < 1440 ) { 

				var diffHalfHours = Math.round(diffmin / 30 );
				var diffHours = diffHalfHours / 2;
				var numberFormatter = sap.ui.core.format.NumberFormat.getFloatInstance();
				var diffHoursLocal = numberFormatter.format(diffHours);
				number = diffHoursLocal.toString();
				var hour = cus.crm.myaccounts.util.Util.geti18NText1("DURATION_HOUR", number);
			
				return hour;
			}
			else {
		// rule for > 1 day
				var days = Math.ceil(diffmin / 1440 );
				number = days.toString();
				var day;
				if (days === "1") {
					day = cus.crm.myaccounts.util.Util.geti18NText1("DURATION_DAY", number);
				}
				else {
					day = cus.crm.myaccounts.util.Util.geti18NText1("DURATION_DAYS", number);						
				}
				return day;
			
			}
		}
	}
};

cus.crm.myaccounts.util.formatter.getDatefromString = function(datetime) {
	// mock data json now "FromDate": "/Date(1356998400000)/",
	datetime = datetime.replace("/Date(", "").replace(")/", "");
	datetime = parseInt(datetime); // number ms
	datetime = new Date(datetime);

	return datetime;
};

cus.crm.myaccounts.util.formatter.formatStatusText = function(oStatus) {
	switch(oStatus){
		case 'E0001':    // Status Open -> black
			return sap.ui.core.ValueState.Neutral;
		case 'E0002':    // Status In Process -> black
			return sap.ui.core.ValueState.Neutral;
		case 'E0003':    // Status Completed -> green
			             // Status Won -> green
			return sap.ui.core.ValueState.Success;	
		case 'E0004':    // Status Lost -> red
			return sap.ui.core.ValueState.Error;
		case 'E0007':    // Status Rejected -> red
			return sap.ui.core.ValueState.Error;	
		default:					// for other not specified status
			return sap.ui.core.ValueState.None;
	}
};

cus.crm.myaccounts.util.formatter.formatSalesOrderStatusText = function(status) {
	switch(status) {
	case 'A': case 'B':
		return sap.ui.core.ValueState.Warning;
	case 'C':
		return sap.ui.core.ValueState.Success;
	default:
		return sap.ui.core.ValueState.None;
	}
};

cus.crm.myaccounts.util.formatter.websiteURL = function (value) {
	if(!value)
		return "";
	var oUri = URI(value);
	if (!oUri.protocol())
		oUri.protocol("http");
	if(jQuery.sap.validateUrl(oUri.toString()))
		return oUri.toString();
	else
		return "";
};

cus.crm.myaccounts.util.formatter.comaSeparator = function (value1, value2) {
	var string = value1;
	if (value2)
		return string ? string + ", " + value2 : value2;
	
	return string;
};

cus.crm.myaccounts.util.formatter.sleshSeparator = function (value1, value2) {
	var string = value1;
	if (value2)
		return string ? string + " / " + value2 : value2;

	return string;
};


cus.crm.myaccounts.util.formatter.AccountNameFormatter = function (fullName, name1) {
	if (fullName) { return fullName; }
	else { return name1; }
};

cus.crm.myaccounts.util.formatter.isEqual = function (value1, value2) {
	if(typeof(value1)==="string" && typeof(value2)==="string"){
		return value1.valueOf() === value2.valueOf();}
	else{
		return value1 === value2;
	}
		
};

cus.crm.myaccounts.util.formatter.areEqual = function (value1, value2, value3, value4) {
    return (cus.crm.myaccounts.util.formatter.isEqual(value1, value2) && cus.crm.myaccounts.util.formatter.isEqual(value3, value4));        
};

cus.crm.myaccounts.util.formatter.isUnequal = function (value1, value2) {
	if(typeof(value1)==="string" && typeof(value2)==="string"){
		return value1.valueOf() !== value2.valueOf();}
	else{
		return value1 !== value2;
	}
		
};

cus.crm.myaccounts.util.formatter.isNotInitial = function (value) {
	if (value)
		return true;
	else
		return false;
};

cus.crm.myaccounts.util.formatter.isInitial = function (value) {
	if (!value)
		return true;
	else
		return false;
};

cus.crm.myaccounts.util.formatter.AccountSpecificText = function (textPerson, textCompany, textGroup, accountType) {
	switch (accountType) {
	case cus.crm.myaccounts.util.Constants.accountCategoryPerson:
		return textPerson;
	case cus.crm.myaccounts.util.Constants.accountCategoryCompany:
		return textCompany;
	case cus.crm.myaccounts.util.Constants.accountCategoryGroup:
		return textGroup;
	}
};

cus.crm.myaccounts.util.formatter.formatExpiryState = function(validTo, status, threshold) {
    if (status === "C") { // if status is "completed", no color is shown
      return "None";
    }

    if (validTo) {
      var dNow = new Date();

      var date = new Date(validTo.getUTCFullYear(), validTo.getUTCMonth(), validTo.getUTCDate());
      dNow = new Date(dNow.getUTCFullYear(), dNow.getUTCMonth(), dNow.getUTCDate());
      
      var dayDiff = parseInt((date - dNow) / (24 * 3600 * 1000), 10);

      if (dayDiff <= threshold) {
        return "Error";
      }
      return "Success";
    }
    return "None";
  };
  
  cus.crm.myaccounts.util.formatter.convertDateStringToUTC = function( value ) {
	  
	  var newValue;
	  
	  if(value === ""){
			newValue = null;
		}
		else{
			var dateFormatter = sap.ui.core.format.DateFormat.getDateInstance({style : "medium"});
			var oDate = dateFormatter.parse( value );
			if(oDate){
				newValue = cus.crm.myaccounts.util.formatter.convertDateToUTC(oDate);
			}
			else{
				newValue = null;
			}
		}
	  return newValue;
  };
  
  cus.crm.myaccounts.util.formatter.convertDateToUTC = function( oDate ){
	  var utcDate = null;
	  if(oDate){
		  var oNewDate = new Date();
		  oNewDate.setUTCFullYear(oDate.getFullYear());
		  oNewDate.setUTCMonth(oDate.getMonth());
		  oNewDate.setUTCDate(oDate.getDate());
		  oNewDate.setUTCHours(0);
		  oNewDate.setUTCMinutes(0);
		  oNewDate.setUTCSeconds(0);
		  oNewDate.setUTCMilliseconds(0);
		  utcDate = oNewDate;
	  }
			
	  return utcDate;
  };

  cus.crm.myaccounts.util.formatter.convertStringToDate = function( value ) {
	  
	  var newValue;
	  
	  if(value === ""){
			newValue = null;
	  }
	  else{
			var dateFormatter = sap.ui.core.format.DateFormat.getDateInstance({style : "medium"});
			var oDate = dateFormatter.parse( value );
			if(oDate){
				newValue = dateFormatter.format(oDate);
			}
			else{
				newValue = value;
			}
	  }
	  return newValue;
  };
  
  cus.crm.myaccounts.util.formatter.convertStringToFloat = function(string) {
	  if(string) {
		  return parseFloat(string);
	  }
	  return 0;
  };
