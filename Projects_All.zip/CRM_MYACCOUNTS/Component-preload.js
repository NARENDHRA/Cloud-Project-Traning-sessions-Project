jQuery.sap.registerPreloadedModules({
	"name": "cus/crm/myaccounts/Component-preload",
	"version": "2.0",
	"modules": {
		"cus/crm/myaccounts/Component.js": function() {
			/*
			 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
			 */
			jQuery.sap.declare("cus.crm.myaccounts.Component");
			jQuery.sap.require("sap.ca.scfld.md.ComponentBase");
			jQuery.sap.require("sap.ui.core.routing.HashChanger");
			jQuery.sap.require("cus.crm.myaccounts.util.Util");
			sap.ca.scfld.md.ComponentBase.extend("cus.crm.myaccounts.Component", {
				metadata: sap.ca.scfld.md.ComponentBase.createMetaData("FS", {
					"name": "My Accounts",
					"version": "1.6.5",
					"library": "cus.crm.myaccounts",
					"includes": ["css/app.css"],
					"dependencies": {
						"libs": ["sap.m", "sap.me"],
						"components": []
					},
					"config": {
						"resourceBundle": "i18n/i18n.properties",
						"titleResource": "FULLSCREEN_TITLE",
						"icon": "sap-icon://Fiori2/F0002",
						"favIcon": "./resources/sap/ca/ui/themes/base/img/favicon/F0002_My_Accounts.ico",
						"homeScreenIconPhone": "./resources/sap/ca/ui/themes/base/img/launchicon/F0002_My_Accounts/57_iPhone_Desktop_Launch.png",
						"homeScreenIconPhone@2": "./resources/sap/ca/ui/themes/base/img/launchicon/F0002_My_Accounts/114_iPhone-Retina_Web_Clip.png",
						"homeScreenIconTablet": "./resources/sap/ca/ui/themes/base/img/launchicon/F0002_My_Accounts/72_iPad_Desktop_Launch.png",
						"homeScreenIconTablet@2": "./resources/sap/ca/ui/themes/base/img/launchicon/F0002_My_Accounts/144_iPad_Retina_Web_Clip.png",
						"startupImage320x460": "./resources/sap/ca/ui/themes/base/img/splashscreen/320_x_460.png",
						"startupImage640x920": "./resources/sap/ca/ui/themes/base/img/splashscreen/640_x_920.png",
						"startupImage640x1096": "./resources/sap/ca/ui/themes/base/img/splashscreen/640_x_1096.png",
						"startupImage768x1004": "./resources/sap/ca/ui/themes/base/img/splashscreen/768_x_1004.png",
						"startupImage748x1024": "./resources/sap/ca/ui/themes/base/img/splashscreen/748_x_1024.png",
						"startupImage1536x2008": "./resources/sap/ca/ui/themes/base/img/splashscreen/1536_x_2008.png",
						"startupImage1496x2048": "./resources/sap/ca/ui/themes/base/img/splashscreen/1496_x_2048.png"
					},
					viewPath: "cus.crm.myaccounts.view",
					fullScreenPageRoutes: {
						"S2": {
							pattern: "",
							view: "search.SearchResult"
						},
						"mainPage": {
							pattern: "mainPage/{filterState}",
							view: "search.SearchResult"
						},
						"detail": {
							pattern: "detail/{contextPath}",
							view: "overview.OverviewPage"
						},
						"s360": {
							pattern: "s360/{contextPath}",
							view: "S360"
						},
						"subdetail": {
							pattern: "detail/{contextPath}/{selectedTab}",
							view: "overview.OverviewPage"
						},
						"edit": {
							pattern: "edit/{contextPath}",
							view: "maintain.GeneralDataEdit"
						},
						"new": {
							pattern: "new/{accountCategory}",
							view: "maintain.GeneralDataEdit"
						},
						"AccountNotes": {
							pattern: "AccountNotes/{contextPath}",
							view: "S4Notes"
						},
						"AccountAttachments": {
							pattern: "AccountAttachments/{contextPath}",
							view: "S4Attachments"
						}
					}
				}),
				createContent: function() {
					cus.crm.myaccounts.util.Util.setComponentConfiguration(this.getMetadata().getConfig());
					var v = {
						component: this
					};
					return sap.ui.view({
						viewName: "cus.crm.myaccounts.Main",
						type: sap.ui.core.mvc.ViewType.XML,
						viewData: v
					});
				}
			});
		},
		"cus/crm/myaccounts/Configuration.js": function() {
			jQuery.sap.declare("cus.crm.myaccounts.Configuration");
			jQuery.sap.require("sap.ca.scfld.md.app.Application");
			jQuery.sap.require("cus.crm.myaccounts.util.Util");
			sap.ca.scfld.md.ConfigurationBase.extend("cus.crm.myaccounts.Configuration", {
				oServiceParams: {
					serviceList: [{
						name: "CRM_BUPA_ODATA",
						serviceUrl: "/sap/opu/odata/sap/CRM_BUPA_ODATA",
						countSupported: true,
						isDefault: true,
						useBatch: true,
						noBusyIndicator: true,
						mockedDataSource: "model/metadata.xml"
					}],
					externalServiceList: [{
						name: "ERP_BUPA_ODATA",
						serviceUrl: "/sap/opu/odata/sap/ERP_BUPA_ODATA",
						countSupported: false,
						isDefault: true,
						useBatch: true,
						mockedDataSource: "model/metadata.xml"
					}]
				},
				getServiceList: function() {
					cus.crm.myaccounts.util.Util.setApplicationConfiguration(this);
					return this.oServiceParams.serviceList;
				},
				setApplicationFacade: function(a) {
					sap.ca.scfld.md.ConfigurationBase.prototype.setApplicationFacade.call(this, a);
					cus.crm.myaccounts.util.Util.setApplicationFacade(a);
				}
			});
		},
		"cus/crm/myaccounts/Main.controller.js": function() {
			sap.ui.controller("cus.crm.myaccounts.Main", {
				onInit: function() {
					jQuery.sap.require("sap.ca.scfld.md.Startup");
					sap.ca.scfld.md.Startup.init('cus.crm.myaccounts', this);
				},
				onExit: function() {}
			});
		},
		"cus/crm/myaccounts/Main.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core"\n\txmlns="sap.m" controllerName="cus.crm.myaccounts.Main" displayBlock="true"\n\theight="100%">\n\t<App id="fioriContent" class="cusCrmMyAccounts" showHeader="false">                                                              \t\n\t</App>  \n</core:View>',
		"cus/crm/myaccounts/controller/Base360Controller.js": function() {
			jQuery.sap.declare("cus.crm.myaccounts.controller.Base360Controller");
			jQuery.sap.require("sap.ui.core.mvc.Controller");
			jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");
			sap.ca.scfld.md.controller.BaseFullscreenController.extend("cus.crm.myaccounts.controller.Base360Controller", {
				getTargetAggregation: function() {
					return "content";
				},
				getControl: function() {},
				getTargetBinding: function() {
					var c = this.getControl();
					if (c) {
						return this.getControl().getBinding(this.getTargetAggregation());
					}
					return undefined;
				}
			});
		},
		"cus/crm/myaccounts/controller/SearchController.js": function() {
			sap.ui.base.Object.extend("cus.crm.myaccounts.controller.SearchController", {
				constructor: function() {},
				onInit: function() {}
			});
		},
		"cus/crm/myaccounts/i18n/i18n.properties": '#Fiori CRM My Accounts application\n# __ldi.translation.uuid=c54f52f0-2066-11e3-8224-0800200c9a66\n# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\n\n# Note: This file was created according to the conventions that can be found at \n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\n\n#XFLD, 30: Facet title for general Data\nGENERAL_DATA=General Information\n\n#XTIT, 40: this is the title for the fullscreen section\nFULLSCREEN_TITLE=My Accounts\n\n#XTIT, 40: this is the title for the detail screen\nDETAIL_TITLE=Account\n\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\nREVENUE_CURRENT=Revenue YTD\n\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\nREVENUE_CURRENT_TOOLTIP=Revenue to date current year\n\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\nREVENUE_LAST=Revenue Last Year\n\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\nREVENUE_LAST_TOOLTIP=Revenue to last year\n\n# XFLD, 30: Facet title for opportunities and label in facet general data\nOPPORTUNITIES=Opportunities\n\n#XFLD, 30: Facet title for leads\nLEADS=Leads\n\n#XFLD, 30: Facet title for tasks\nTASKS=Tasks\n\n#XFLD, 30: Facet title for appointments\nAPPOINTMENTS=Appointments\n\n#XFLD, 30: Facet title for quotations\nQUOTATIONS=Quotations\n\n#XFLD, 30: Facet title for sales orders\nSALES_ORDERS=Sales Orders\n\n#XFLD, 30: W7: Facet title for marketing attributes\nMARKETINGATTRIBUTES=Marketing Attributes\n\n#XFLD, 30: W6: Title for popup with products\nPRODUCTS=Products\n\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\nEMPLOYEE_RESPONSIBLE=Employee Responsible\n\n#XFLD, 30: Facet title for Attachments\nATTACHMENTS=Attachments\n\n#XFLD, 30: Facet title for Notes\nNOTES=Notes\n\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\nNEW_NOTE=New Note\n\n#XFLD, 30: Facet title for Contacts\nCONTACTS=Contacts\n\n#XFLD, 30: Label for Address in facet general data\nADDRESS=Address\n\n#XFLD, 30: Label for Opportunities in facet general data\nUNWEIGHTED_OPPORTUNITIES=Opportunities\n\n#XFLD, 30: Label for Rating in facet general data\nRATING=Rating\n\n# XFLD, 30: Label for Next contact in facet Appointments\nNEXT_APPOINTMENT=Next Appointment\n\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\nLAST_APPOINTMENT=Last Appointment\n\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\nIMAGE=Image\n\n#XBUT, 20: Button to show the create actionsheet\nCREATE= Create\n\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\nDISCUSS_ENTRY=Discuss in SAP Jam\n\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\nSHARE_ENTRY=Share on SAP Jam\n\n#XBUT, 20: Button to share the note\nDETAIL_BUTTON_SHARE=Share\n\n#XBUT, 20: Button to cancel sharing\nDETAIL_BUTTON_CANCEL=Cancel\n\n#XFLD,20: All accounts for filter\nALL_ACCOUNTS=All Accounts\n\n#XFLD,35: All individual accounts for filter\nALL_INDIVIDUAL_ACCOUNTS=All Individual Accounts\n\n#XFLD,35: All corporate accounts for filter\nALL_CORPORATE_ACCOUNTS=All Corporate Accounts\n\n#XFLD,35: All group accounts for filter\nALL_ACCOUNT_GROUPS=All Account Groups\n\n#XFLD,20: my account for filter\nMY_ACCOUNT=My Accounts\n\n#XFLD,35: my individual accounts for filter\nMY_INDIVIDUAL_ACCOUNTS=My Individual Accounts\n\n#XFLD,35: my corporate accounts for filter\nMY_CORPORATE_ACCOUNTS=My Corporate Accounts\n\n#XFLD,35: my group accounts for filter\nMY_ACCOUNT_GROUPS=My Account Groups\n\n#XFLD,30: Account type -> for the DDLB in case of create\nINDIVIDUAL_ACCOUNT=Individual Account\n\n#XFLD,30: Account type -> for the DDLB in case of create\nCORPORATE_ACCOUNT=Corporate Account\n\n#XFLD,30: Account type -> for the DDLB in case of create\nACCOUNT_GROUP=Account Group\n\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\nSTARTING=Starting {0}\n\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\nCLOSING=Closing {0}\n\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\nDUE=Due {0}\n\n#XFLD,20: All accounts for title\nALL_ACCOUNTS_TITLE=All Accounts ({0})\n\n#XFLD,35: All individual accounts for title\nALL_INDIVIDUAL_ACCOUNTS_TITLE=All Individual Accounts ({0})\n\n#XFLD,35: All corporate accounts for title\nALL_CORPORATE_ACCOUNTS_TITLE=All Corporate Accounts ({0})\n\n#XFLD,35: All group accounts for title\nALL_ACCOUNT_GROUPS_TITLE=All Account Groups ({0})\n\n#XFLD,20: my account for title\nMY_ACCOUNT_TITLE=My Accounts ({0})\n\n#XFLD,35: my individual account for title\nMY_INDIVIDUAL_ACCOUNT_TITLE=My Individual Accounts ({0})\n\n#XFLD,35: my corporate account for title.\nMY_CORPORATE_ACCOUNT_TITLE=My Corporate Accounts ({0})\n\n#XFLD,35: my group account for title\nMY_ACCOUNT_GROUP_TITLE=My Account Groups ({0})\n\n#XFLD,30: filtered by info\nFILTERED_BY=Filtered By: {0}\n\n#XFLD,30: label, search for accounts\nSEARCH_ACCOUNTS=Search\n\n#XFLD,30: comma separator for location\nLOCATION={0}, {1}\n\n#XFLD: W4: Label for All day text in Appointments\nALL_DAY_EVENT=All Day\n\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\nDURATION_MINUTE={0} min\n\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\nDURATION_HOUR={0} h\n\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\nDURATION_DAY={0} day\n\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\nDURATION_DAYS={0} days\n\n#XFLD: W4: Label for Private meeting\nPRIVATE=Private\n\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\nSELECT_TRANSACTION_TYPE=Select Transaction Type\n\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\nNEW_TASK_INPUT_PLACEHOLDER=New Task\n\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\nNO_DATA_TEXT=No Data\n\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\nLOADING_TEXT=Loading...\n\n#XFLD,25: W4: Column label for name of contact person in contacts\nNAME=Name\n\n#XFLD,25: W5: Column label for department of contact person in contacts\nDEPARTMENT=Department\n\n#XFLD,15: W6: Column label for actions of contact person in contacts\nACTIONS=Actions\n\n#XFLD,25: W4: Column label for description of lead in Leads\nDESCRIPTION=Description\n\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\nASSIGNED_TO=Assigned To\n\n#XFLD,15: W4: Column label for end date of lead in Leads\nEND_DATE=End Date\n\n#XFLD,15: W4: Column label for qualification level of lead in Leads\nQUALIFICATION=Qualification\n\n#XFLD,15: W4: Column label for status of lead in Leads\nSTATUS=Status\n\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\nMAIN_CONTACT=Main Contact\n\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\nVOLUME=Volume\n\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\nPROBABILITY=Probability\n\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\nCLOSE_BY=Close By\n\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \nVIEWS=Views\n\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\nCONTACT_TITLE=Contact\n\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\nEMPLOYEE_TITLE=Employee\n\n#XTIT,20: W7: Title of pop-up used in confirm popup\nCONFIRM_TITLE=Confirm\n\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\nCOMPANY_NAME=Name\n\n#XFLD,20: W4: Label for name 1 of a company used general data\nCOMPANY_NAME1=Name 1\n\n#XFLD,20: W4: Label for name 2 of a company used general data\nCOMPANY_NAME2=Name 2\n\n#XFLD,20: W4: Label for first name of a person used general data\nFIRST_NAME=First Name\n\n#XFLD,20: W4: Label for last name of a person used general data\nLAST_NAME=Last Name\n\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\nBIRTHDAY=Birthday\n\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\nTITLE=Title\n\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\nACADEMIC_TITLE=Academic Title\n\n#XFLD,20: W4: Label for mobile phone number used general data\nMOBILE=Mobile\n\n#XFLD,20: W4: Label for phone number used general data\nPHONE=Phone\n\n#XFLD,20: W4: Label for e-mail used general data\nEMAIL=E-Mail\n\n#XFLD,20: W4: Label for web site used general data\nWEBSITE=Web Site\n\n#XFLD,20: W4: Label for country used general data\nCOUNTRY=Country\n\n#XFLD,20: W4: Label for region used general data\nREGION=Region\n\n#XFLD,20: W4: Label for city used general data\nCITY=City\n\n#XFLD,20: W4: Label for postal code used general data\nPOSTAL_CODE=Postal Code\n\n#XFLD,20: W4: Label for street used general data\nSTREET=Street\n\n#XFLD,10: W4: Label for house number used general data\nHOUSE_NUMBER=House No.\n\n#XFLD,15: W6: Label for ID used in Quotations\nID=ID\n\n#XFLD,15: W6: Label for Amount used in Quotations\nAMOUNT=Amount\n\n#XFLD,20: W6: Label for Expiration Date used in Quotations\nEXPIRATION_DATE=Expiration Date\n\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\nDELIVERY_DATE=Delivery Date\n\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\nSALES_EMPLOYEE=Sales Employee\n\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\nATTRIBUTESET=Attribute Set\n\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\nATTRIBUTE=Attribute\n\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\nVALUE=Value\n\n#XBUT, 20: Button to create an Account\nBUTTON_ADD=Add\n\n#XBUT, 20: Button to edit an Account\nBUTTON_EDIT=Edit\n\n#XBUT, 20: Button to save changes\nBUTTON_SAVE=Save\n\n#XBUT, 20: Button to cancel changes\nBUTTON_CANCEL=Cancel\n\n#XBUT, 30: Button which shows the personalization buttons\nBUTTON_SHOW_PERSONALIZATION=Show Personalization\n\n#XBUT, 30: Button which hides the personalization buttons\nBUTTON_HIDE_PERSONALIZATION=Hide Personalization\n\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\nMSG_CONFIRM_CANCEL=Leave this page without saving the changes you may have made?\n\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\nMSG_CONFIRM_DELETE_CONTACT=The contact will be unassigned from the account. Do you want to continue?\n\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\nMSG_UPDATE_SUCCESS=Account updated.\n\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\nMSG_UPDATE_ERROR=Update failed\n\n# XMSG : Account update succeeded\nMSG_CREATION_SUCCESS=Account created\n\n# XMSG : Task creation succeeded\nMSG_TASK_CREATION_SUCCESS=Task created\n\n# XMSG : Contact creation failed\nMSG_CREATION_ERROR=Creation failed\n\n# XMSG: message that will be displayed, if the user has entered wrong country\nMSG_WRONG_COUNTRY_ERROR=Country "{0}" does not exist.\n\n# XMSG: message that will be displayed, if the user has entered wrong region\nMSG_WRONG_REGION_ERROR=Region "{0}" does not exist for the given country.\n\n# XMSG: message that will be displayed, if the user has entered wrong employee\nMSG_WRONG_EMPLOYEE_ERROR=Employee "{0}" does not exist.\n\n# XMSG: message that will be displayed, if the user has entered invalid website url\nMSG_WRONG_URL_ERROR=Entered URL "{0}" is not valid.\n\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\nMSG_MANDATORY_FIELDS=Not all mandatory fields are filled.\n\n# XMSG: message that will be displayed in case of conflicting data during account editing\nMSG_CONFLICTING_DATA=Data has been changed by another user. Do you want to overwrite the other user\'s changes with your own?\n\n# XMSG: message that will be displayed in case of conflicts during file renaming\nMSG_CONFLICTING_FILE_NAME=The file name has been changed by another user. Do you want to overwrite the other user\'s changes with your own?\n\n# XMSG: message that will be displayed in case of conflicting data during account editing\nMSG_CONFLICTING_DATA_WITH_REFRESH=Data has been changed by another user. Data will be refreshed.\n\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\nMSG_NOT_IN_MAIN_CONTACT=You can only view business cards of contacts that have been assigned to this account\n\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\nMSG_EXCEEDING_FILE_NAME_LENGTH=Your file name can have a maximum of 40 characters.\n\n# XTOL, 20: tooltip shown on search result list for button to add an account"\nADD_ACCOUNT_TOOLTIP=Add Account\n\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\nADD_MARKETING_ATTRIBUTE_TOOLTIP=Add Marketing Attribute\n\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\nADD_CONTACT_TOOLTIP=Add Contact\n\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\nADD_APPOINTMENT_TOOLTIP=Add Appointment\n\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\nADD_TASK_TOOLTIP=Add Task\n\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\nADD_OPPORTUNITY_TOOLTIP=Add Opportunity\n',
		"cus/crm/myaccounts/i18n/i18n_ar.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XFLD, 30: Facet title for general Data\r\nGENERAL_DATA=\\u0627\\u0644\\u0628\\u064A\\u0627\\u0646\\u0627\\u062A \\u0627\\u0644\\u0639\\u0627\\u0645\\u0629\r\n\r\n#XTIT, 40: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=\\u0639\\u0645\\u0644\\u0627\\u0626\\u064A\r\n\r\n#XTIT, 40: this is the title for the detail screen\r\nDETAIL_TITLE=\\u0627\\u0644\\u0639\\u0645\\u064A\\u0644\r\n\r\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\r\nREVENUE_CURRENT=\\u0625\\u064A\\u0631\\u0627\\u062F\\: \\u0633\\u0646\\u0629 \\u0644\\u062A\\u0627\\u0631\\u064A\\u062E\\u0647\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\r\nREVENUE_CURRENT_TOOLTIP=\\u0625\\u064A\\u0631\\u0627\\u062F\\u0627\\u062A \\u0627\\u0644\\u0633\\u0646\\u0629 \\u0627\\u0644\\u062D\\u0627\\u0644\\u064A\\u0629 \\u062D\\u062A\\u0649 \\u062A\\u0627\\u0631\\u064A\\u062E\\u0647\r\n\r\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\r\nREVENUE_LAST=\\u0625\\u064A\\u0631\\u0627\\u062F\\u0627\\u062A \\u0633\\u0646\\u0629 \\u0645\\u0627\\u0636\\u064A\\u0629\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\r\nREVENUE_LAST_TOOLTIP=\\u0627\\u0644\\u0625\\u064A\\u0631\\u0627\\u062F\\u0627\\u062A \\u0627\\u0644\\u0633\\u0646\\u0629 \\u0627\\u0644\\u0645\\u0627\\u0636\\u064A\\u0629\r\n\r\n# XFLD, 30: Facet title for opportunities and label in facet general data\r\nOPPORTUNITIES=\\u0627\\u0644\\u0641\\u0631\\u0635 \\u0627\\u0644\\u0628\\u064A\\u0639\\u064A\\u0629\r\n\r\n#XFLD, 30: Facet title for leads\r\nLEADS=\\u0641\\u0631\\u0635 \\u062A\\u0633\\u0648\\u064A\\u0642\\u064A\\u0629\r\n\r\n#XFLD, 30: Facet title for tasks\r\nTASKS=\\u0627\\u0644\\u0645\\u0647\\u0627\\u0645\r\n\r\n#XFLD, 30: Facet title for appointments\r\nAPPOINTMENTS=\\u0627\\u0644\\u0645\\u0648\\u0627\\u0639\\u064A\\u062F\r\n\r\n#XFLD, 30: Facet title for quotations\r\nQUOTATIONS=\\u0639\\u0631\\u0648\\u0636 \\u0627\\u0644\\u0623\\u0633\\u0639\\u0627\\u0631\r\n\r\n#XFLD, 30: Facet title for sales orders\r\nSALES_ORDERS=\\u0623\\u0648\\u0627\\u0645\\u0631 \\u0627\\u0644\\u0645\\u0628\\u064A\\u0639\\u0627\\u062A\r\n\r\n#XFLD, 30: W7: Facet title for marketing attributes\r\nMARKETINGATTRIBUTES=\\u0633\\u0645\\u0627\\u062A \\u0627\\u0644\\u062A\\u0633\\u0648\\u064A\\u0642\r\n\r\n#XFLD, 30: W6: Title for popup with products\r\nPRODUCTS=\\u0627\\u0644\\u0645\\u0646\\u062A\\u062C\\u0627\\u062A\r\n\r\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\r\nEMPLOYEE_RESPONSIBLE=\\u0627\\u0644\\u0645\\u0648\\u0638\\u0641 \\u0627\\u0644\\u0645\\u0633\\u0624\\u0648\\u0644\r\n\r\n#XFLD, 30: Facet title for Attachments\r\nATTACHMENTS=\\u0645\\u0631\\u0641\\u0642\\u0627\\u062A\r\n\r\n#XFLD, 30: Facet title for Notes\r\nNOTES=\\u0645\\u0644\\u0627\\u062D\\u0638\\u0627\\u062A\r\n\r\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\r\nNEW_NOTE=\\u0645\\u0644\\u0627\\u062D\\u0638\\u0629 \\u062C\\u062F\\u064A\\u062F\\u0629\r\n\r\n#XFLD, 30: Facet title for Contacts\r\nCONTACTS=\\u062C\\u0647\\u0627\\u062A \\u0627\\u0644\\u0627\\u062A\\u0635\\u0627\\u0644\r\n\r\n#XFLD, 30: Label for Address in facet general data\r\nADDRESS=\\u0627\\u0644\\u0639\\u0646\\u0648\\u0627\\u0646\r\n\r\n#XFLD, 30: Label for Opportunities in facet general data\r\nUNWEIGHTED_OPPORTUNITIES=\\u0627\\u0644\\u0641\\u0631\\u0635 \\u0627\\u0644\\u0628\\u064A\\u0639\\u064A\\u0629\r\n\r\n#XFLD, 30: Label for Rating in facet general data\r\nRATING=\\u0627\\u0644\\u062A\\u0635\\u0646\\u064A\\u0641\r\n\r\n# XFLD, 30: Label for Next contact in facet Appointments\r\nNEXT_APPOINTMENT=\\u0627\\u0644\\u0645\\u0648\\u0639\\u062F \\u0627\\u0644\\u062A\\u0627\\u0644\\u064A\r\n\r\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\r\nLAST_APPOINTMENT=\\u0622\\u062E\\u0631 \\u0645\\u0648\\u0639\\u062F\r\n\r\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\r\nIMAGE=\\u0627\\u0644\\u0635\\u0648\\u0631\\u0629\r\n\r\n#XBUT, 20: Button to show the create actionsheet\r\nCREATE=\\u0625\\u0646\\u0634\\u0627\\u0621\r\n\r\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\r\nDISCUSS_ENTRY=\\u0645\\u0646\\u0627\\u0642\\u0634\\u0629 \\u0641\\u064A SAP Jam\r\n\r\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\r\nSHARE_ENTRY=\\u0645\\u0634\\u0627\\u0631\\u0643\\u0629 \\u0639\\u0644\\u0649 SAP Jam\r\n\r\n#XBUT, 20: Button to share the note\r\nDETAIL_BUTTON_SHARE=\\u0645\\u0634\\u0627\\u0631\\u0643\\u0629\r\n\r\n#XBUT, 20: Button to cancel sharing\r\nDETAIL_BUTTON_CANCEL=\\u0625\\u0644\\u063A\\u0627\\u0621\r\n\r\n#XFLD,20: All accounts for filter\r\nALL_ACCOUNTS=\\u0643\\u0644 \\u0627\\u0644\\u062D\\u0633\\u0627\\u0628\\u0627\\u062A\r\n\r\n#XFLD,35: All individual accounts for filter\r\nALL_INDIVIDUAL_ACCOUNTS=\\u0643\\u0644 \\u0627\\u0644\\u0639\\u0645\\u0644\\u0627\\u0621 \\u0627\\u0644\\u0641\\u0631\\u062F\\u064A\\u064A\\u0646\r\n\r\n#XFLD,35: All corporate accounts for filter\r\nALL_CORPORATE_ACCOUNTS=\\u0643\\u0644 \\u0639\\u0645\\u0644\\u0627\\u0621 \\u0627\\u0644\\u0634\\u0631\\u0643\\u0629\r\n\r\n#XFLD,35: All group accounts for filter\r\nALL_ACCOUNT_GROUPS=\\u0643\\u0627\\u0641\\u0629 \\u0645\\u062C\\u0645\\u0648\\u0639\\u0627\\u062A \\u0627\\u0644\\u0639\\u0645\\u0644\\u0627\\u0621\r\n\r\n#XFLD,20: my account for filter\r\nMY_ACCOUNT=\\u0639\\u0645\\u0644\\u0627\\u0626\\u064A\r\n\r\n#XFLD,35: my individual accounts for filter\r\nMY_INDIVIDUAL_ACCOUNTS=\\u0639\\u0645\\u0644\\u0627\\u0626\\u064A \\u0627\\u0644\\u0641\\u0631\\u062F\\u064A\\u0648\\u0646\r\n\r\n#XFLD,35: my corporate accounts for filter\r\nMY_CORPORATE_ACCOUNTS=\\u0639\\u0645\\u0644\\u0627\\u0621 \\u0627\\u0644\\u0634\\u0631\\u0643\\u0629 \\u0627\\u0644\\u062A\\u0627\\u0628\\u0639\\u064A\\u0646 \\u0644\\u064A\r\n\r\n#XFLD,35: my group accounts for filter\r\nMY_ACCOUNT_GROUPS=\\u0645\\u062C\\u0645\\u0648\\u0639\\u0627\\u062A \\u0627\\u0644\\u0639\\u0645\\u0644\\u0627\\u0621 \\u0627\\u0644\\u062A\\u0627\\u0628\\u0639\\u0629 \\u0644\\u064A\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nINDIVIDUAL_ACCOUNT=\\u0639\\u0645\\u064A\\u0644 \\u0641\\u0631\\u062F\\u064A\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nCORPORATE_ACCOUNT=\\u0639\\u0645\\u064A\\u0644 \\u0634\\u0631\\u0643\\u0629\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nACCOUNT_GROUP=\\u0645\\u062C\\u0645\\u0648\\u0639\\u0629 \\u0639\\u0645\\u0644\\u0627\\u0621\r\n\r\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\r\nSTARTING=\\u062A\\u0627\\u0631\\u064A\\u062E \\u0627\\u0644\\u0628\\u062F\\u0627\\u064A\\u0629\\: {0}\r\n\r\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\r\nCLOSING=\\u062A\\u0627\\u0631\\u064A\\u062E \\u0627\\u0644\\u0625\\u063A\\u0644\\u0627\\u0642\\: {0}\r\n\r\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\r\nDUE=\\u062A\\u0627\\u0631\\u064A\\u062E \\u0627\\u0644\\u0627\\u0633\\u062A\\u062D\\u0642\\u0627\\u0642\\: {0}\r\n\r\n#XFLD,20: All accounts for title\r\nALL_ACCOUNTS_TITLE=\\u062C\\u0645\\u064A\\u0639 \\u0627\\u0644\\u0639\\u0645\\u0644\\u0627\\u0621 ({0})\r\n\r\n#XFLD,35: All individual accounts for title\r\nALL_INDIVIDUAL_ACCOUNTS_TITLE=\\u0643\\u0644 \\u0627\\u0644\\u0639\\u0645\\u0644\\u0627\\u0621 \\u0627\\u0644\\u0641\\u0631\\u062F\\u064A\\u064A\\u0646 ({0})\r\n\r\n#XFLD,35: All corporate accounts for title\r\nALL_CORPORATE_ACCOUNTS_TITLE=\\u062C\\u0645\\u064A\\u0639 \\u0639\\u0645\\u0644\\u0627\\u0621 \\u0627\\u0644\\u0634\\u0631\\u0643\\u0629 ({0})\r\n\r\n#XFLD,35: All group accounts for title\r\nALL_ACCOUNT_GROUPS_TITLE=\\u0643\\u0627\\u0641\\u0629 \\u0645\\u062C\\u0645\\u0648\\u0639\\u0627\\u062A \\u0627\\u0644\\u0639\\u0645\\u0644\\u0627\\u0621 ({0})\r\n\r\n#XFLD,20: my account for title\r\nMY_ACCOUNT_TITLE=\\u0639\\u0645\\u0644\\u0627\\u0626\\u064A ({0})\r\n\r\n#XFLD,35: my individual account for title\r\nMY_INDIVIDUAL_ACCOUNT_TITLE=\\u0627\\u0644\\u0639\\u0645\\u0644\\u0627\\u0621 \\u0627\\u0644\\u0641\\u0631\\u062F\\u064A\\u0648\\u0646 \\u0627\\u0644\\u062A\\u0627\\u0628\\u0639\\u064A\\u0646 \\u0644\\u064A ({0})\r\n\r\n#XFLD,35: my corporate account for title.\r\nMY_CORPORATE_ACCOUNT_TITLE=\\u0639\\u0645\\u0644\\u0627\\u0621 \\u0627\\u0644\\u0634\\u0631\\u0643\\u0629 \\u0627\\u0644\\u062A\\u0627\\u0628\\u0639\\u064A\\u0646 \\u0644\\u064A ({0})\r\n\r\n#XFLD,35: my group account for title\r\nMY_ACCOUNT_GROUP_TITLE=\\u0645\\u062C\\u0645\\u0648\\u0639\\u0627\\u062A \\u0627\\u0644\\u0639\\u0645\\u0644\\u0627\\u0621 \\u0627\\u0644\\u062A\\u0627\\u0628\\u0639\\u064A\\u0646 \\u0644\\u064A ({0})\r\n\r\n#XFLD,30: filtered by info\r\nFILTERED_BY=\\u062A\\u0645\\u062A \\u0627\\u0644\\u062A\\u0635\\u0641\\u064A\\u0629 \\u062D\\u0633\\u0628\\: {0}\r\n\r\n#XFLD,30: label, search for accounts\r\nSEARCH_ACCOUNTS=\\u0628\\u062D\\u062B\r\n\r\n#XFLD,30: comma separator for location\r\nLOCATION={0}, {1}\r\n\r\n#XFLD: W4: Label for All day text in Appointments\r\nALL_DAY_EVENT=\\u0637\\u0648\\u0627\\u0644 \\u0627\\u0644\\u064A\\u0648\\u0645\r\n\r\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\r\nDURATION_MINUTE={0} \\u062F\\u0642\\u064A\\u0642\\u0629 (\\u062F\\u0642\\u0627\\u0626\\u0642)\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\r\nDURATION_HOUR={0} \\u0633\\u0627\\u0639\\u0629 (\\u0633\\u0627\\u0639\\u0627\\u062A)\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\r\nDURATION_DAY={0} \\u064A\\u0648\\u0645 (\\u0623\\u064A\\u0627\\u0645)\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\r\nDURATION_DAYS={0} \\u064A\\u0648\\u0645 (\\u0623\\u064A\\u0627\\u0645)\r\n\r\n#XFLD: W4: Label for Private meeting\r\nPRIVATE=\\u062E\\u0627\\u0635\r\n\r\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\r\nSELECT_TRANSACTION_TYPE=\\u062A\\u062D\\u062F\\u064A\\u062F \\u0646\\u0648\\u0639 \\u0627\\u0644\\u0645\\u0639\\u0627\\u0645\\u0644\\u0629\r\n\r\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\r\nNEW_TASK_INPUT_PLACEHOLDER=\\u0645\\u0647\\u0645\\u0629 \\u062C\\u062F\\u064A\\u062F\\u0629\r\n\r\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nNO_DATA_TEXT=\\u0644\\u0627 \\u062A\\u0648\\u062C\\u062F \\u0628\\u064A\\u0627\\u0646\\u0627\\u062A\r\n\r\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nLOADING_TEXT=\\u062C\\u0627\\u0631\\u064D \\u0627\\u0644\\u062A\\u062D\\u0645\\u064A\\u0644...\r\n\r\n#XFLD,25: W4: Column label for name of contact person in contacts\r\nNAME=\\u0627\\u0644\\u0627\\u0633\\u0645\r\n\r\n#XFLD,25: W5: Column label for department of contact person in contacts\r\nDEPARTMENT=\\u0627\\u0644\\u0642\\u0633\\u0645\r\n\r\n#XFLD,15: W6: Column label for actions of contact person in contacts\r\nACTIONS=\\u0627\\u0644\\u0625\\u062C\\u0631\\u0627\\u0621\\u0627\\u062A\r\n\r\n#XFLD,25: W4: Column label for description of lead in Leads\r\nDESCRIPTION=\\u0627\\u0644\\u0648\\u0635\\u0641\r\n\r\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\r\nASSIGNED_TO=\\u062A\\u0645 \\u0627\\u0644\\u062A\\u0639\\u064A\\u064A\\u0646 \\u0625\\u0644\\u0649\r\n\r\n#XFLD,15: W4: Column label for end date of lead in Leads\r\nEND_DATE=\\u062A\\u0627\\u0631\\u064A\\u062E \\u0627\\u0644\\u0627\\u0646\\u062A\\u0647\\u0627\\u0621\r\n\r\n#XFLD,15: W4: Column label for qualification level of lead in Leads\r\nQUALIFICATION=\\u0627\\u0644\\u0645\\u0624\\u0647\\u0644\r\n\r\n#XFLD,15: W4: Column label for status of lead in Leads\r\nSTATUS=\\u0627\\u0644\\u062D\\u0627\\u0644\\u0629\r\n\r\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\r\nMAIN_CONTACT=\\u062C\\u0647\\u0629 \\u0627\\u0644\\u0627\\u062A\\u0635\\u0627\\u0644 \\u0627\\u0644\\u0631\\u0626\\u064A\\u0633\\u064A\\u0629\r\n\r\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\r\nVOLUME=\\u0627\\u0644\\u062D\\u062C\\u0645\r\n\r\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\r\nPROBABILITY=\\u0627\\u0644\\u0627\\u062D\\u062A\\u0645\\u0627\\u0644\\u064A\\u0629\r\n\r\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\r\nCLOSE_BY=\\u0625\\u063A\\u0644\\u0627\\u0642 \\u0628\\u0648\\u0627\\u0633\\u0637\\u0629\r\n\r\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \r\nVIEWS=\\u0627\\u0644\\u0639\\u0631\\u0648\\u0636\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\r\nCONTACT_TITLE=\\u062C\\u0647\\u0629 \\u0627\\u0644\\u0627\\u062A\\u0635\\u0627\\u0644\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\r\nEMPLOYEE_TITLE=\\u0627\\u0644\\u0645\\u0648\\u0638\\u0641\r\n\r\n#XTIT,20: W7: Title of pop-up used in confirm popup\r\nCONFIRM_TITLE=\\u062A\\u0623\\u0643\\u064A\\u062F\r\n\r\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\r\nCOMPANY_NAME=\\u0627\\u0644\\u0627\\u0633\\u0645\r\n\r\n#XFLD,20: W4: Label for name 1 of a company used general data\r\nCOMPANY_NAME1=\\u0627\\u0644\\u0627\\u0633\\u0645 1\r\n\r\n#XFLD,20: W4: Label for name 2 of a company used general data\r\nCOMPANY_NAME2=\\u0627\\u0644\\u0627\\u0633\\u0645 2\r\n\r\n#XFLD,20: W4: Label for first name of a person used general data\r\nFIRST_NAME=\\u0627\\u0644\\u0627\\u0633\\u0645 \\u0627\\u0644\\u0623\\u0648\\u0644\r\n\r\n#XFLD,20: W4: Label for last name of a person used general data\r\nLAST_NAME=\\u0627\\u0644\\u0627\\u0633\\u0645 \\u0627\\u0644\\u0623\\u062E\\u064A\\u0631\r\n\r\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nBIRTHDAY=\\u062A\\u0627\\u0631\\u064A\\u062E \\u0627\\u0644\\u0645\\u064A\\u0644\\u0627\\u062F\r\n\r\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nTITLE=\\u0627\\u0644\\u0639\\u0646\\u0648\\u0627\\u0646\r\n\r\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nACADEMIC_TITLE=\\u0644\\u0642\\u0628 \\u0623\\u0643\\u0627\\u062F\\u064A\\u0645\\u064A\r\n\r\n#XFLD,20: W4: Label for mobile phone number used general data\r\nMOBILE=\\u0627\\u0644\\u062C\\u0648\\u0627\\u0644\r\n\r\n#XFLD,20: W4: Label for phone number used general data\r\nPHONE=\\u0627\\u0644\\u0647\\u0627\\u062A\\u0641\r\n\r\n#XFLD,20: W4: Label for e-mail used general data\r\nEMAIL=\\u0627\\u0644\\u0628\\u0631\\u064A\\u062F \\u0627\\u0644\\u0625\\u0644\\u0643\\u062A\\u0631\\u0648\\u0646\\u064A\r\n\r\n#XFLD,20: W4: Label for web site used general data\r\nWEBSITE=\\u0645\\u0648\\u0642\\u0639 \\u0627\\u0644\\u0648\\u064A\\u0628\r\n\r\n#XFLD,20: W4: Label for country used general data\r\nCOUNTRY=\\u0627\\u0644\\u062F\\u0648\\u0644\\u0629\r\n\r\n#XFLD,20: W4: Label for region used general data\r\nREGION=\\u0627\\u0644\\u0645\\u0646\\u0637\\u0642\\u0629\r\n\r\n#XFLD,20: W4: Label for city used general data\r\nCITY=\\u0627\\u0644\\u0645\\u062F\\u064A\\u0646\\u0629\r\n\r\n#XFLD,20: W4: Label for postal code used general data\r\nPOSTAL_CODE=\\u0627\\u0644\\u0631\\u0645\\u0632 \\u0627\\u0644\\u0628\\u0631\\u064A\\u062F\\u064A\r\n\r\n#XFLD,20: W4: Label for street used general data\r\nSTREET=\\u0627\\u0644\\u0634\\u0627\\u0631\\u0639\r\n\r\n#XFLD,10: W4: Label for house number used general data\r\nHOUSE_NUMBER=\\u0631\\u0642\\u0645 \\u0627\\u0644\\u0645\\u0646\\u0632\\u0644\r\n\r\n#XFLD,15: W6: Label for ID used in Quotations\r\nID=\\u0627\\u0644\\u0645\\u0639\\u0631\\u0641\r\n\r\n#XFLD,15: W6: Label for Amount used in Quotations\r\nAMOUNT=\\u0627\\u0644\\u0645\\u0628\\u0644\\u063A\r\n\r\n#XFLD,20: W6: Label for Expiration Date used in Quotations\r\nEXPIRATION_DATE=\\u062A\\u0627\\u0631\\u064A\\u062E \\u0627\\u0646\\u062A\\u0647\\u0627\\u0621 \\u0635\\u0644\\u0627\\u062D\\u064A\\u0629\r\n\r\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\r\nDELIVERY_DATE=\\u062A\\u0627\\u0631\\u064A\\u062E \\u0627\\u0644\\u062A\\u0633\\u0644\\u064A\\u0645\r\n\r\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\r\nSALES_EMPLOYEE=\\u0645\\u0648\\u0638\\u0641 \\u0645\\u0628\\u064A\\u0639\\u0627\\u062A\r\n\r\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\r\nATTRIBUTESET=\\u0645\\u062C\\u0645\\u0648\\u0639\\u0629 \\u0627\\u0644\\u0633\\u0645\\u0627\\u062A\r\n\r\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\r\nATTRIBUTE=\\u0627\\u0644\\u0633\\u0645\\u0629\r\n\r\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\r\nVALUE=\\u0627\\u0644\\u0642\\u064A\\u0645\\u0629\r\n\r\n#XBUT, 20: Button to create an Account\r\nBUTTON_ADD=\\u0625\\u0636\\u0627\\u0641\\u0629\r\n\r\n#XBUT, 20: Button to edit an Account\r\nBUTTON_EDIT=\\u062A\\u062D\\u0631\\u064A\\u0631\r\n\r\n#XBUT, 20: Button to save changes\r\nBUTTON_SAVE=\\u062D\\u0641\\u0638\r\n\r\n#XBUT, 20: Button to cancel changes\r\nBUTTON_CANCEL=\\u0625\\u0644\\u063A\\u0627\\u0621\r\n\r\n#XBUT, 30: Button which shows the personalization buttons\r\nBUTTON_SHOW_PERSONALIZATION=\\u0625\\u0638\\u0647\\u0627\\u0631 \\u0627\\u0644\\u062A\\u062E\\u0635\\u064A\\u0635\r\n\r\n#XBUT, 30: Button which hides the personalization buttons\r\nBUTTON_HIDE_PERSONALIZATION=\\u0625\\u062E\\u0641\\u0627\\u0621 \\u0627\\u0644\\u062A\\u062E\\u0635\\u064A\\u0635\r\n\r\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_CONFIRM_CANCEL=\\u0633\\u064A\\u062A\\u0645 \\u0641\\u0642\\u062F\\u0627\\u0646 \\u0623\\u064A\\u0629 \\u062A\\u063A\\u064A\\u064A\\u0631\\u0627\\u062A \\u063A\\u064A\\u0631 \\u0645\\u062D\\u0641\\u0648\\u0638\\u0629. \\u0647\\u0644 \\u062A\\u0631\\u064A\\u062F \\u0627\\u0644\\u0645\\u062A\\u0627\\u0628\\u0639\\u0629\\u061F\r\n\r\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\r\nMSG_CONFIRM_DELETE_CONTACT=\\u0633\\u064A\\u062A\\u0645 \\u0625\\u0644\\u063A\\u0627\\u0621 \\u062A\\u0639\\u064A\\u064A\\u0646 \\u062C\\u0647\\u0629 \\u0627\\u0644\\u0627\\u062A\\u0635\\u0627\\u0644 \\u0645\\u0646 \\u0627\\u0644\\u062D\\u0633\\u0627\\u0628. \\u0647\\u0644 \\u062A\\u0631\\u064A\\u062F \\u0627\\u0644\\u0645\\u062A\\u0627\\u0628\\u0639\\u0629\\u061F\r\n\r\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_SUCCESS=\\u062A\\u0645 \\u062A\\u062D\\u062F\\u064A\\u062B \\u0628\\u064A\\u0627\\u0646\\u0627\\u062A \\u0627\\u0644\\u0639\\u0645\\u064A\\u0644\r\n\r\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_ERROR=\\u0641\\u0634\\u0644 \\u0627\\u0644\\u062A\\u062D\\u062F\\u064A\\u062B\r\n\r\n# XMSG : Account update succeeded\r\nMSG_CREATION_SUCCESS=\\u062A\\u0645 \\u0625\\u0646\\u0634\\u0627\\u0621 \\u0628\\u064A\\u0627\\u0646\\u0627\\u062A \\u0639\\u0645\\u064A\\u0644\r\n\r\n# XMSG : Task creation succeeded\r\nMSG_TASK_CREATION_SUCCESS=\\u062A\\u0645 \\u0625\\u0646\\u0634\\u0627\\u0621 \\u0627\\u0644\\u0645\\u0647\\u0645\\u0629\r\n\r\n# XMSG : Contact creation failed\r\nMSG_CREATION_ERROR=\\u0641\\u0634\\u0644 \\u0627\\u0644\\u0625\\u0646\\u0634\\u0627\\u0621\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong country\r\nMSG_WRONG_COUNTRY_ERROR=\\u0627\\u0644\\u062F\\u0648\\u0644\\u0629 "{0}" \\u063A\\u064A\\u0631 \\u0645\\u0648\\u062C\\u0648\\u062F\\u0629\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong region\r\nMSG_WRONG_REGION_ERROR=\\u0627\\u0644\\u0645\\u0646\\u0637\\u0642\\u0629 {0}" \\u063A\\u064A\\u0631 \\u0645\\u0648\\u062C\\u0648\\u062F\\u0629 \\u0644\\u0644\\u062F\\u0648\\u0644\\u0629\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong employee\r\nMSG_WRONG_EMPLOYEE_ERROR=\\u0627\\u0644\\u0645\\u0648\\u0638\\u0641 "{0}" \\u063A\\u064A\\u0631 \\u0645\\u0648\\u062C\\u0648\\u062F.\r\n\r\n# XMSG: message that will be displayed, if the user has entered invalid website url\r\nMSG_WRONG_URL_ERROR=\\u0639\\u0646\\u0648\\u0627\\u0646 \\u0645\\u062D\\u062F\\u062F \\u0645\\u0648\\u0627\\u0642\\u0639 \\u0627\\u0644\\u0645\\u0639\\u0644\\u0648\\u0645\\u0627\\u062A "{0}" \\u063A\\u064A\\u0631 \\u0635\\u0627\\u0644\\u062D.\r\n\r\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\r\nMSG_MANDATORY_FIELDS=\\u0644\\u0645 \\u064A\\u062A\\u0645 \\u0645\\u0644\\u0621 \\u062C\\u0645\\u064A\\u0639 \\u0627\\u0644\\u062D\\u0642\\u0648\\u0644 \\u0627\\u0644\\u0625\\u0644\\u0632\\u0627\\u0645\\u064A\\u0629\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA=\\u062A\\u0645 \\u062A\\u063A\\u064A\\u064A\\u0631 \\u0627\\u0644\\u0628\\u064A\\u0627\\u0646\\u0627\\u062A \\u0628\\u0648\\u0627\\u0633\\u0637\\u0629 \\u0645\\u0633\\u062A\\u062E\\u062F\\u0645 \\u0622\\u062E\\u0631. \\u0647\\u0644 \\u062A\\u0631\\u064A\\u062F \\u0627\\u0633\\u062A\\u0628\\u062F\\u0627\\u0644 \\u062A\\u063A\\u064A\\u064A\\u0631\\u0627\\u062A \\u0627\\u0644\\u0645\\u0633\\u062A\\u062E\\u062F\\u0645 \\u0627\\u0644\\u0622\\u062E\\u0631 \\u0628\\u0627\\u0644\\u062A\\u063A\\u064A\\u064A\\u0631\\u0627\\u062A \\u0627\\u0644\\u062E\\u0627\\u0635\\u0629 \\u0628\\u0643\\u061F\r\n\r\n# XMSG: message that will be displayed in case of conflicts during file renaming\r\nMSG_CONFLICTING_FILE_NAME=\\u062A\\u0645 \\u062A\\u063A\\u064A\\u064A\\u0631 \\u0627\\u0633\\u0645 \\u0627\\u0644\\u0645\\u0644\\u0641 \\u0628\\u0648\\u0627\\u0633\\u0637\\u0629 \\u0645\\u0633\\u062A\\u062E\\u062F\\u0645 \\u0622\\u062E\\u0631. \\u0647\\u0644 \\u062A\\u0631\\u064A\\u062F \\u0627\\u0633\\u062A\\u0628\\u062F\\u0627\\u0644 \\u062A\\u063A\\u064A\\u064A\\u0631\\u0627\\u062A \\u0627\\u0644\\u0645\\u0633\\u062A\\u062E\\u062F\\u0645 \\u0627\\u0644\\u0622\\u062E\\u0631 \\u0628\\u0627\\u0644\\u062A\\u063A\\u064A\\u064A\\u0631\\u0627\\u062A \\u0627\\u0644\\u062E\\u0627\\u0635\\u0629 \\u0628\\u0643\\u061F\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA_WITH_REFRESH=\\u0627\\u0644\\u0628\\u064A\\u0627\\u0646\\u0627\\u062A \\u0627\\u0644\\u062A\\u064A \\u062A\\u0645 \\u062A\\u063A\\u064A\\u064A\\u0631\\u0647\\u0627 \\u0628\\u0648\\u0627\\u0633\\u0637\\u0629 \\u0645\\u0633\\u062A\\u062E\\u062F\\u0645 \\u0622\\u062E\\u0631. \\u0633\\u062A\\u0638\\u0647\\u0631 \\u0647\\u0630\\u0647 \\u0627\\u0644\\u062A\\u063A\\u064A\\u064A\\u0631\\u0627\\u062A \\u0641\\u064A \\u0627\\u0644\\u062A\\u0637\\u0628\\u064A\\u0642.\r\n\r\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\r\nMSG_NOT_IN_MAIN_CONTACT=\\u0644\\u0627 \\u064A\\u0645\\u0643\\u0646\\u0643 \\u0625\\u0644\\u0627 \\u0639\\u0631\\u0636 \\u062A\\u0641\\u0627\\u0635\\u064A\\u0644 \\u0627\\u0644\\u0627\\u062A\\u0635\\u0627\\u0644\\u0627\\u062A \\u0627\\u0644\\u0645\\u0639\\u064A\\u0646\\u0629 \\u0644\\u0647\\u0630\\u0627 \\u0627\\u0644\\u062D\\u0633\\u0627\\u0628\r\n\r\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\r\nMSG_EXCEEDING_FILE_NAME_LENGTH=\\u064A\\u0645\\u0643\\u0646 \\u0623\\u0646 \\u064A\\u0643\\u0648\\u0646 \\u0637\\u0648\\u0644 \\u0627\\u0633\\u0645 \\u0627\\u0644\\u0645\\u0644\\u0641 40 \\u062D\\u0631\\u0641\\u064B\\u0627 \\u0643\\u062D\\u062F \\u0623\\u0642\\u0635\\u0649.\r\n\r\n# XTOL, 20: tooltip shown on search result list for button to add an account"\r\n\r\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\r\n\r\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\r\n\r\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\r\n\r\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\r\n\r\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\r\n',
		"cus/crm/myaccounts/i18n/i18n_bg.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XFLD, 30: Facet title for general Data\r\nGENERAL_DATA=\\u041E\\u0431\\u0449\\u0438 \\u0434\\u0430\\u043D\\u043D\\u0438\r\n\r\n#XTIT, 40: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=\\u041C\\u043E\\u0438\\u0442\\u0435 \\u0430\\u043A\\u0430\\u0443\\u043D\\u0442\\u0438\r\n\r\n#XTIT, 40: this is the title for the detail screen\r\nDETAIL_TITLE=\\u0410\\u043A\\u0430\\u0443\\u043D\\u0442\r\n\r\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\r\nREVENUE_CURRENT=\\u041F\\u0440\\u0438\\u0445\\u043E\\u0434\\u041D\\u0430\\u0447\\u0413\\u043E\\u0434\\u0414\\u043E\\u0414\\u0430\\u0442\\u0430\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\r\nREVENUE_CURRENT_TOOLTIP=\\u041F\\u0440\\u0438\\u0445\\u043E\\u0434 \\u0434\\u043E \\u0434\\u0430\\u0442\\u0430 \\u043E\\u0442 \\u0442\\u0435\\u043A\\u0443\\u0449\\u0430\\u0442\\u0430 \\u0433\\u043E\\u0434\\u0438\\u043D\\u0430\r\n\r\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\r\nREVENUE_LAST=\\u041F\\u0440\\u0438\\u0445\\u043E\\u0434 \\u043C\\u0438\\u043D.\\u0433\\u043E\\u0434\\u0438\\u043D\\u0430\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\r\nREVENUE_LAST_TOOLTIP=\\u041F\\u0440\\u0438\\u0445\\u043E\\u0434 \\u043C\\u0438\\u043D.\\u0433\\u043E\\u0434\\u0438\\u043D\\u0430\r\n\r\n# XFLD, 30: Facet title for opportunities and label in facet general data\r\nOPPORTUNITIES=\\u0412\\u044A\\u0437\\u043C\\u043E\\u0436\\u043D\\u043E\\u0441\\u0442\\u0438\r\n\r\n#XFLD, 30: Facet title for leads\r\nLEADS=\\u041F\\u043E\\u0442\\u0435\\u043D\\u0446\\u0438\\u0430\\u043B\\u043D\\u0438 \\u0432\\u044A\\u0437\\u043C\\u043E\\u0436\\u043D\\u043E\\u0441\\u0442\\u0438\r\n\r\n#XFLD, 30: Facet title for tasks\r\nTASKS=\\u0417\\u0430\\u0434\\u0430\\u043D\\u0438\\u044F\r\n\r\n#XFLD, 30: Facet title for appointments\r\nAPPOINTMENTS=\\u0421\\u0440\\u043E\\u043A\\u043E\\u0432\\u0435\r\n\r\n#XFLD, 30: Facet title for quotations\r\nQUOTATIONS=\\u041E\\u0444\\u0435\\u0440\\u0442\\u0438\r\n\r\n#XFLD, 30: Facet title for sales orders\r\nSALES_ORDERS=\\u041A\\u043B\\u0438\\u0435\\u043D\\u0442\\u0441\\u043A\\u0438 \\u043F\\u043E\\u0440\\u044A\\u0447\\u043A\\u0438\r\n\r\n#XFLD, 30: W7: Facet title for marketing attributes\r\nMARKETINGATTRIBUTES=\\u041C\\u0430\\u0440\\u043A\\u0435\\u0442\\u0438\\u043D\\u0433\\u043E\\u0432\\u0438 \\u0430\\u0442\\u0440\\u0438\\u0431\\u0443\\u0442\\u0438\r\n\r\n#XFLD, 30: W6: Title for popup with products\r\nPRODUCTS=\\u041F\\u0440\\u043E\\u0434\\u0443\\u043A\\u0442\\u0438\r\n\r\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\r\nEMPLOYEE_RESPONSIBLE=\\u041E\\u0442\\u0433\\u043E\\u0432\\u043E\\u0440\\u0435\\u043D \\u0441\\u043B\\u0443\\u0436\\u0438\\u0442\\u0435\\u043B\r\n\r\n#XFLD, 30: Facet title for Attachments\r\nATTACHMENTS=\\u041F\\u0440\\u0438\\u043B\\u043E\\u0436\\u0435\\u043D\\u0438\\u044F\r\n\r\n#XFLD, 30: Facet title for Notes\r\nNOTES=\\u0411\\u0435\\u043B\\u0435\\u0436\\u043A\\u0438\r\n\r\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\r\nNEW_NOTE=\\u041D\\u043E\\u0432\\u0430 \\u0431\\u0435\\u043B\\u0435\\u0436\\u043A\\u0430\r\n\r\n#XFLD, 30: Facet title for Contacts\r\nCONTACTS=\\u041A\\u043E\\u043D\\u0442\\u0430\\u043A\\u0442\\u0438\r\n\r\n#XFLD, 30: Label for Address in facet general data\r\nADDRESS=\\u0410\\u0434\\u0440\\u0435\\u0441\r\n\r\n#XFLD, 30: Label for Opportunities in facet general data\r\nUNWEIGHTED_OPPORTUNITIES=\\u0412\\u044A\\u0437\\u043C\\u043E\\u0436\\u043D\\u043E\\u0441\\u0442\\u0438\r\n\r\n#XFLD, 30: Label for Rating in facet general data\r\nRATING=\\u041E\\u0446\\u0435\\u043D\\u043A\\u0430\r\n\r\n# XFLD, 30: Label for Next contact in facet Appointments\r\nNEXT_APPOINTMENT=\\u0421\\u043B\\u0435\\u0434\\u0432\\u0430\\u0449 \\u0441\\u0440\\u043E\\u043A\r\n\r\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\r\nLAST_APPOINTMENT=\\u041F\\u043E\\u0441\\u043B\\u0435\\u0434\\u0435\\u043D \\u0441\\u0440\\u043E\\u043A\r\n\r\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\r\nIMAGE=\\u0418\\u0437\\u043E\\u0431\\u0440\\u0430\\u0436.\r\n\r\n#XBUT, 20: Button to show the create actionsheet\r\nCREATE=\\u0421\\u044A\\u0437\\u0434\\u0430\\u0432\\u0430\\u043D\\u0435\r\n\r\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\r\nDISCUSS_ENTRY=\\u041E\\u0431\\u0441\\u044A\\u0436\\u0434\\u0430\\u043D\\u0435 \\u0432 SAP Jam\r\n\r\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\r\nSHARE_ENTRY=\\u0421\\u043F\\u043E\\u0434\\u0435\\u043B\\u044F\\u043D\\u0435 \\u0432 SAP Jam\r\n\r\n#XBUT, 20: Button to share the note\r\nDETAIL_BUTTON_SHARE=\\u0421\\u043F\\u043E\\u0434\\u0435\\u043B\\u044F\\u043D\\u0435\r\n\r\n#XBUT, 20: Button to cancel sharing\r\nDETAIL_BUTTON_CANCEL=\\u041E\\u0442\\u043A\\u0430\\u0437\r\n\r\n#XFLD,20: All accounts for filter\r\nALL_ACCOUNTS=\\u0412\\u0441\\u0438\\u0447\\u043A\\u0438 \\u0430\\u043A\\u0430\\u0443\\u043D\\u0442\\u0438\r\n\r\n#XFLD,35: All individual accounts for filter\r\nALL_INDIVIDUAL_ACCOUNTS=\\u0412\\u0441\\u0438\\u0447\\u043A\\u0438 \\u0438\\u043D\\u0434\\u0438\\u0432\\u0438\\u0434\\u0443\\u0430\\u043B\\u043D\\u0438 \\u0430\\u043A\\u0430\\u0443\\u043D\\u0442\\u0438\r\n\r\n#XFLD,35: All corporate accounts for filter\r\nALL_CORPORATE_ACCOUNTS=\\u0412\\u0441\\u0438\\u0447\\u043A\\u0438 \\u043A\\u043E\\u0440\\u043F\\u043E\\u0440\\u0430\\u0442\\u0438\\u0432\\u043D\\u0438 \\u0430\\u043A\\u0430\\u0443\\u043D\\u0442\\u0438\r\n\r\n#XFLD,35: All group accounts for filter\r\nALL_ACCOUNT_GROUPS=\\u0412\\u0441\\u0438\\u0447\\u043A\\u0438 \\u0433\\u0440\\u0443\\u043F\\u0438 \\u0430\\u043A\\u0430\\u0443\\u043D\\u0442\\u0438\r\n\r\n#XFLD,20: my account for filter\r\nMY_ACCOUNT=\\u041C\\u043E\\u0438\\u0442\\u0435 \\u0430\\u043A\\u0430\\u0443\\u043D\\u0442\\u0438\r\n\r\n#XFLD,35: my individual accounts for filter\r\nMY_INDIVIDUAL_ACCOUNTS=\\u041C\\u043E\\u0438\\u0442\\u0435 \\u0438\\u043D\\u0434\\u0438\\u0432\\u0438\\u0434\\u0443\\u0430\\u043B\\u043D\\u0438 \\u0430\\u043A\\u0430\\u0443\\u043D\\u0442\\u0438\r\n\r\n#XFLD,35: my corporate accounts for filter\r\nMY_CORPORATE_ACCOUNTS=\\u041C\\u043E\\u0438\\u0442\\u0435 \\u043A\\u043E\\u0440\\u043F\\u043E\\u0440\\u0430\\u0442\\u0438\\u0432\\u043D\\u0438 \\u0430\\u043A\\u0430\\u0443\\u043D\\u0442\\u0438\r\n\r\n#XFLD,35: my group accounts for filter\r\nMY_ACCOUNT_GROUPS=\\u041C\\u043E\\u0438\\u0442\\u0435 \\u0433\\u0440\\u0443\\u043F\\u0438 \\u0430\\u043A\\u0430\\u0443\\u043D\\u0442\\u0438\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nINDIVIDUAL_ACCOUNT=\\u0418\\u043D\\u0434\\u0438\\u0432\\u0438\\u0434\\u0443\\u0430\\u043B\\u0435\\u043D \\u0430\\u043A\\u0430\\u0443\\u043D\\u0442\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nCORPORATE_ACCOUNT=\\u041A\\u043E\\u0440\\u043F\\u043E\\u0440\\u0430\\u0442\\u0438\\u0432\\u0435\\u043D \\u0430\\u043A\\u0430\\u0443\\u043D\\u0442\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nACCOUNT_GROUP=\\u0413\\u0440\\u0443\\u043F\\u0430 \\u0430\\u043A\\u0430\\u0443\\u043D\\u0442\\u0438\r\n\r\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\r\nSTARTING=\\u041D\\u0430\\u0447\\u0430\\u043B\\u043D\\u0430 \\u0434\\u0430\\u0442\\u0430\\: {0}\r\n\r\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\r\nCLOSING=\\u0414\\u0430\\u0442\\u0430 \\u043F\\u0440\\u0438\\u043A\\u043B\\u044E\\u0447\\u0432\\u0430\\u043D\\u0435\\: {0}\r\n\r\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\r\nDUE=\\u041A\\u0440\\u0430\\u0439\\u043D\\u0430 \\u0434\\u0430\\u0442\\u0430\\: {0}\r\n\r\n#XFLD,20: All accounts for title\r\nALL_ACCOUNTS_TITLE=\\u0412\\u0441\\u0438\\u0447\\u043A\\u0438 \\u0430\\u043A\\u0430\\u0443\\u043D\\u0442\\u0438 ({0})\r\n\r\n#XFLD,35: All individual accounts for title\r\nALL_INDIVIDUAL_ACCOUNTS_TITLE=\\u0412\\u0441\\u0438\\u0447\\u043A\\u0438 \\u0438\\u043D\\u0434\\u0438\\u0432\\u0438\\u0434\\u0443\\u0430\\u043B\\u043D\\u0438 \\u0430\\u043A\\u0430\\u0443\\u043D\\u0442\\u0438 ({0})\r\n\r\n#XFLD,35: All corporate accounts for title\r\nALL_CORPORATE_ACCOUNTS_TITLE=\\u0412\\u0441\\u0438\\u0447\\u043A\\u0438 \\u043A\\u043E\\u0440\\u043F\\u043E\\u0440\\u0430\\u0442\\u0438\\u0432\\u043D\\u0438 \\u0430\\u043A\\u0430\\u0443\\u043D\\u0442\\u0438 ({0})\r\n\r\n#XFLD,35: All group accounts for title\r\nALL_ACCOUNT_GROUPS_TITLE=\\u0412\\u0441\\u0438\\u0447\\u043A\\u0438 \\u0433\\u0440\\u0443\\u043F\\u0438 \\u0430\\u043A\\u0430\\u0443\\u043D\\u0442\\u0438 ({0})\r\n\r\n#XFLD,20: my account for title\r\nMY_ACCOUNT_TITLE=\\u041C\\u043E\\u0438\\u0442\\u0435 \\u0430\\u043A\\u0430\\u0443\\u043D\\u0442\\u0438 ({0})\r\n\r\n#XFLD,35: my individual account for title\r\nMY_INDIVIDUAL_ACCOUNT_TITLE=\\u041C\\u043E\\u0438\\u0442\\u0435 \\u0438\\u043D\\u0434\\u0438\\u0432\\u0438\\u0434\\u0443\\u0430\\u043B\\u043D\\u0438 \\u0430\\u043A\\u0430\\u0443\\u043D\\u0442\\u0438 ({0})\r\n\r\n#XFLD,35: my corporate account for title.\r\nMY_CORPORATE_ACCOUNT_TITLE=\\u041C\\u043E\\u0438\\u0442\\u0435 \\u043A\\u043E\\u0440\\u043F\\u043E\\u0440\\u0430\\u0442\\u0438\\u0432\\u043D\\u0438 \\u0430\\u043A\\u0430\\u0443\\u043D\\u0442\\u0438 ({0})\r\n\r\n#XFLD,35: my group account for title\r\nMY_ACCOUNT_GROUP_TITLE=\\u041C\\u043E\\u0438\\u0442\\u0435 \\u0433\\u0440\\u0443\\u043F\\u0438 \\u0430\\u043A\\u0430\\u0443\\u043D\\u0442\\u0438 ({0})\r\n\r\n#XFLD,30: filtered by info\r\nFILTERED_BY=\\u0424\\u0438\\u043B\\u0442\\u0440\\u0438\\u0440\\u0430\\u043D \\u043F\\u043E\\: {0}\r\n\r\n#XFLD,30: label, search for accounts\r\nSEARCH_ACCOUNTS=\\u0422\\u044A\\u0440\\u0441\\u0435\\u043D\\u0435\r\n\r\n#XFLD,30: comma separator for location\r\nLOCATION={0}, {1}\r\n\r\n#XFLD: W4: Label for All day text in Appointments\r\nALL_DAY_EVENT=\\u0426\\u044F\\u043B \\u0434\\u0435\\u043D\r\n\r\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\r\nDURATION_MINUTE={0} \\u043C\\u0438\\u043D\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\r\nDURATION_HOUR={0} \\u0447\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\r\nDURATION_DAY={0} \\u0434\\u0435\\u043D\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\r\nDURATION_DAYS={0} \\u0434\\u043D\\u0438\r\n\r\n#XFLD: W4: Label for Private meeting\r\nPRIVATE=\\u041B\\u0438\\u0447\\u0435\\u043D\r\n\r\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\r\nSELECT_TRANSACTION_TYPE=\\u0418\\u0437\\u0431\\u043E\\u0440 \\u043D\\u0430 \\u0432\\u0438\\u0434 \\u0442\\u0440\\u0430\\u043D\\u0437\\u0430\\u043A\\u0446\\u0438\\u044F\r\n\r\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\r\nNEW_TASK_INPUT_PLACEHOLDER=\\u041D\\u043E\\u0432\\u0430 \\u0437\\u0430\\u0434\\u0430\\u0447\\u0430\r\n\r\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nNO_DATA_TEXT=\\u041D\\u044F\\u043C\\u0430 \\u0434\\u0430\\u043D\\u043D\\u0438\r\n\r\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nLOADING_TEXT=\\u0417\\u0430\\u0440\\u0435\\u0436\\u0434\\u0430\\u043D\\u0435...\r\n\r\n#XFLD,25: W4: Column label for name of contact person in contacts\r\nNAME=\\u0418\\u043C\\u0435\r\n\r\n#XFLD,25: W5: Column label for department of contact person in contacts\r\nDEPARTMENT=\\u041E\\u0442\\u0434\\u0435\\u043B\r\n\r\n#XFLD,15: W6: Column label for actions of contact person in contacts\r\nACTIONS=\\u0414\\u0435\\u0439\\u0441\\u0442\\u0432\\u0438\\u044F\r\n\r\n#XFLD,25: W4: Column label for description of lead in Leads\r\nDESCRIPTION=\\u041E\\u043F\\u0438\\u0441\\u0430\\u043D\\u0438\\u0435\r\n\r\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\r\nASSIGNED_TO=\\u041F\\u0440\\u0438\\u0441\\u044A\\u0435\\u0434\\u0438\\u043D\\u0435\\u043D \\u043A\\u044A\\u043C\r\n\r\n#XFLD,15: W4: Column label for end date of lead in Leads\r\nEND_DATE=\\u041A\\u0440\\u0430\\u0439\\u043D\\u0430 \\u0434\\u0430\\u0442\\u0430\r\n\r\n#XFLD,15: W4: Column label for qualification level of lead in Leads\r\nQUALIFICATION=\\u041A\\u0432\\u0430\\u043B\\u0438\\u0444\\u0438\\u043A\\u0430\\u0446\\u0438\\u044F\r\n\r\n#XFLD,15: W4: Column label for status of lead in Leads\r\nSTATUS=\\u0421\\u0442\\u0430\\u0442\\u0443\\u0441\r\n\r\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\r\nMAIN_CONTACT=\\u041E\\u0441\\u043D\\u043E\\u0432\\u0435\\u043D \\u0434\\u043E\\u0433\\u043E\\u0432\\u043E\\u0440\r\n\r\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\r\nVOLUME=\\u041E\\u0431\\u0435\\u043C\r\n\r\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\r\nPROBABILITY=\\u0412\\u0435\\u0440\\u043E\\u044F\\u0442\\u043D\\u043E\\u0441\\u0442\r\n\r\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\r\nCLOSE_BY=\\u0417\\u0430\\u043A\\u0440\\u0438\\u0432\\u0430\\u043D\\u0435 \\u0434\\u043E\r\n\r\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \r\nVIEWS=\\u0410\\u0441\\u043F\\u0435\\u043A\\u0442\\u0438\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\r\nCONTACT_TITLE=\\u041A\\u043E\\u043D\\u0442\\u0430\\u043A\\u0442\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\r\nEMPLOYEE_TITLE=\\u0421\\u043B\\u0443\\u0436\\u0438\\u0442\\u0435\\u043B\r\n\r\n#XTIT,20: W7: Title of pop-up used in confirm popup\r\nCONFIRM_TITLE=\\u041F\\u043E\\u0442\\u0432\\u044A\\u0440\\u0436\\u0434\\u0435\\u043D\\u0438\\u0435\r\n\r\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\r\nCOMPANY_NAME=\\u0418\\u043C\\u0435\r\n\r\n#XFLD,20: W4: Label for name 1 of a company used general data\r\nCOMPANY_NAME1=\\u0418\\u043C\\u0435 1\r\n\r\n#XFLD,20: W4: Label for name 2 of a company used general data\r\nCOMPANY_NAME2=\\u0418\\u043C\\u0435 2\r\n\r\n#XFLD,20: W4: Label for first name of a person used general data\r\nFIRST_NAME=\\u0421\\u043E\\u0431\\u0441\\u0442\\u0432\\u0435\\u043D\\u043E \\u0438\\u043C\\u0435\r\n\r\n#XFLD,20: W4: Label for last name of a person used general data\r\nLAST_NAME=\\u0424\\u0430\\u043C\\u0438\\u043B\\u0438\\u044F\r\n\r\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nBIRTHDAY=\\u0414\\u0430\\u0442\\u0430 \\u043D\\u0430 \\u0440\\u0430\\u0436\\u0434\\u0430\\u043D\\u0435\r\n\r\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nTITLE=\\u0417\\u0430\\u0433\\u043B\\u0430\\u0432\\u0438\\u0435\r\n\r\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nACADEMIC_TITLE=\\u041D\\u0430\\u0443\\u0447\\u043D\\u0430 \\u0441\\u0442\\u0435\\u043F\\u0435\\u043D\r\n\r\n#XFLD,20: W4: Label for mobile phone number used general data\r\nMOBILE=\\u041C\\u043E\\u0431\\u0438\\u043B\\u0435\\u043D\r\n\r\n#XFLD,20: W4: Label for phone number used general data\r\nPHONE=\\u0422\\u0435\\u043B\\u0435\\u0444\\u043E\\u043D\r\n\r\n#XFLD,20: W4: Label for e-mail used general data\r\nEMAIL=\\u0418\\u043C\\u0435\\u0439\\u043B\r\n\r\n#XFLD,20: W4: Label for web site used general data\r\nWEBSITE=\\u0423\\u0435\\u0431\\u0441\\u0430\\u0439\\u0442\r\n\r\n#XFLD,20: W4: Label for country used general data\r\nCOUNTRY=\\u0414\\u044A\\u0440\\u0436\\u0430\\u0432\\u0430\r\n\r\n#XFLD,20: W4: Label for region used general data\r\nREGION=\\u0420\\u0435\\u0433\\u0438\\u043E\\u043D\r\n\r\n#XFLD,20: W4: Label for city used general data\r\nCITY=\\u0413\\u0440\\u0430\\u0434\r\n\r\n#XFLD,20: W4: Label for postal code used general data\r\nPOSTAL_CODE=\\u041F\\u043E\\u0449\\u0435\\u043D\\u0441\\u043A\\u0438 \\u041A\\u043E\\u0434\r\n\r\n#XFLD,20: W4: Label for street used general data\r\nSTREET=\\u0423\\u043B\\u0438\\u0446\\u0430\r\n\r\n#XFLD,10: W4: Label for house number used general data\r\nHOUSE_NUMBER=\\u041D\\u043E\\u043C\\u0435\\u0440 \\u043A\\u044A\\u0449\\u0430\r\n\r\n#XFLD,15: W6: Label for ID used in Quotations\r\nID=\\u0418\\u0414\r\n\r\n#XFLD,15: W6: Label for Amount used in Quotations\r\nAMOUNT=\\u0421\\u0443\\u043C\\u0430\r\n\r\n#XFLD,20: W6: Label for Expiration Date used in Quotations\r\nEXPIRATION_DATE=\\u0421\\u0440\\u043E\\u043A \\u043D\\u0430 \\u0432\\u0430\\u043B\\u0438\\u0434\\u043D\\u043E\\u0441\\u0442\r\n\r\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\r\nDELIVERY_DATE=\\u0414\\u0430\\u0442\\u0430 \\u043D\\u0430 \\u0434\\u043E\\u0441\\u0442\\u0430\\u0432\\u043A\\u0430\r\n\r\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\r\nSALES_EMPLOYEE=\\u0422\\u044A\\u0440\\u0433\\u043E\\u0432\\u0441\\u043A\\u0438 \\u0441\\u043B\\u0443\\u0436\\u0438\\u0442\\u0435\\u043B\r\n\r\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\r\nATTRIBUTESET=\\u041D\\u0430\\u0431\\u043E\\u0440 \\u0430\\u0442\\u0440\\u0438\\u0431\\u0443\\u0442\\u0438\r\n\r\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\r\nATTRIBUTE=\\u0410\\u0442\\u0440\\u0438\\u0431\\u0443\\u0442\r\n\r\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\r\nVALUE=\\u0421\\u0442\\u043E\\u0439\\u043D\\u043E\\u0441\\u0442\r\n\r\n#XBUT, 20: Button to create an Account\r\nBUTTON_ADD=\\u0414\\u043E\\u0431\\u0430\\u0432\\u044F\\u043D\\u0435\r\n\r\n#XBUT, 20: Button to edit an Account\r\nBUTTON_EDIT=\\u0420\\u0435\\u0434\\u0430\\u043A\\u0446\\u0438\\u044F\r\n\r\n#XBUT, 20: Button to save changes\r\nBUTTON_SAVE=\\u0417\\u0430\\u043F\\u0430\\u0437\\u0432\\u0430\\u043D\\u0435\r\n\r\n#XBUT, 20: Button to cancel changes\r\nBUTTON_CANCEL=\\u041E\\u0442\\u043A\\u0430\\u0437\r\n\r\n#XBUT, 30: Button which shows the personalization buttons\r\nBUTTON_SHOW_PERSONALIZATION=\\u041F\\u043E\\u043A\\u0430\\u0437\\u0432\\u0430\\u043D\\u0435 \\u043D\\u0430 \\u043F\\u0435\\u0440\\u0441\\u043E\\u043D\\u0430\\u043B\\u0438\\u0437\\u0430\\u0446\\u0438\\u044F\r\n\r\n#XBUT, 30: Button which hides the personalization buttons\r\nBUTTON_HIDE_PERSONALIZATION=\\u0421\\u043A\\u0440\\u0438\\u0432\\u0430\\u043D\\u0435 \\u043D\\u0430 \\u043F\\u0435\\u0440\\u0441\\u043E\\u043D\\u0430\\u043B\\u0438\\u0437\\u0430\\u0446\\u0438\\u044F\r\n\r\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_CONFIRM_CANCEL=\\u041D\\u0435\\u0437\\u0430\\u043F\\u0430\\u0437\\u0435\\u043D\\u0438\\u0442\\u0435 \\u043F\\u0440\\u043E\\u043C\\u0435\\u043D\\u0438 \\u0449\\u0435 \\u0431\\u044A\\u0434\\u0430\\u0442 \\u0438\\u0437\\u0433\\u0443\\u0431\\u0435\\u043D\\u0438. \\u0416\\u0435\\u043B\\u0430\\u0435\\u0442\\u0435 \\u043B\\u0438 \\u043F\\u0440\\u043E\\u0434\\u044A\\u043B\\u0436\\u0430\\u0432\\u0430\\u043D\\u0435?\r\n\r\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\r\nMSG_CONFIRM_DELETE_CONTACT=\\u041F\\u0440\\u0438\\u0441\\u044A\\u0435\\u0434\\u0438\\u043D\\u044F\\u0432\\u0430\\u043D\\u0435\\u0442\\u043E \\u043D\\u0430 \\u043A\\u043E\\u043D\\u0442\\u0430\\u043A\\u0442\\u0430 \\u0430\\u043A\\u0430\\u0443\\u043D\\u0442\\u0430 \\u0449\\u0435 \\u0431\\u044A\\u0434\\u0435 \\u043E\\u0442\\u043C\\u0435\\u043D\\u0435\\u043D\\u043E. \\u0416\\u0435\\u043B\\u0430\\u0435\\u0442\\u0435 \\u043B\\u0438 \\u0434\\u0430 \\u043F\\u0440\\u043E\\u0434\\u044A\\u043B\\u0436\\u0438\\u0442\\u0435?\r\n\r\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_SUCCESS=\\u0410\\u043A\\u0430\\u0443\\u043D\\u0442\\u044A\\u0442 \\u0435 \\u0430\\u043A\\u0442\\u0443\\u0430\\u043B\\u0438\\u0437\\u0438\\u0440\\u0430\\u043D\r\n\r\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_ERROR=\\u041D\\u0435\\u0443\\u0441\\u043F\\u0435\\u0448\\u043D\\u0430 \\u0430\\u043A\\u0442\\u0443\\u0430\\u043B\\u0438\\u0437\\u0430\\u0446\\u0438\\u044F\r\n\r\n# XMSG : Account update succeeded\r\nMSG_CREATION_SUCCESS=\\u0410\\u043A\\u0430\\u0443\\u043D\\u0442\\u044A\\u0442 \\u0435 \\u0441\\u044A\\u0437\\u0434\\u0430\\u0434\\u0435\\u043D\r\n\r\n# XMSG : Task creation succeeded\r\nMSG_TASK_CREATION_SUCCESS=\\u0417\\u0430\\u0434\\u0430\\u0447\\u0430\\u0442\\u0430 \\u0435 \\u0441\\u044A\\u0437\\u0434\\u0430\\u0434\\u0435\\u043D\\u0430\r\n\r\n# XMSG : Contact creation failed\r\nMSG_CREATION_ERROR=\\u041D\\u0435\\u0443\\u0441\\u043F\\u0435\\u0448\\u043D\\u043E \\u0441\\u044A\\u0437\\u0434\\u0430\\u0432\\u0430\\u043D\\u0435\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong country\r\nMSG_WRONG_COUNTRY_ERROR=\\u0414\\u044A\\u0440\\u0436\\u0430\\u0432\\u0430 "{0}" \\u043D\\u0435 \\u0441\\u044A\\u0449\\u0435\\u0441\\u0442\\u0432\\u0443\\u0432\\u0430\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong region\r\nMSG_WRONG_REGION_ERROR=\\u0420\\u0435\\u0433\\u0438\\u043E\\u043D "{0}" \\u043D\\u0435 \\u0441\\u044A\\u0449\\u0435\\u0441\\u0442\\u0432\\u0443\\u0432\\u0430 \\u0437\\u0430 \\u0434\\u044A\\u0440\\u0436\\u0430\\u0432\\u0430\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong employee\r\nMSG_WRONG_EMPLOYEE_ERROR=\\u0421\\u043B\\u0443\\u0436\\u0438\\u0442\\u0435\\u043B "{0}" \\u043D\\u0435 \\u0441\\u044A\\u0449\\u0435\\u0441\\u0442\\u0432\\u0443\\u0432\\u0430.\r\n\r\n# XMSG: message that will be displayed, if the user has entered invalid website url\r\nMSG_WRONG_URL_ERROR=\\u0412\\u044A\\u0432\\u0435\\u0434\\u0435\\u043D\\u0438\\u044F\\u0442 URL "{0}" \\u0435 \\u043D\\u0435\\u0432\\u0430\\u043B\\u0438\\u0434\\u0435\\u043D.\r\n\r\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\r\nMSG_MANDATORY_FIELDS=\\u041D\\u0435 \\u0441\\u0430 \\u043F\\u043E\\u043F\\u044A\\u043B\\u043D\\u0435\\u043D\\u0438 \\u0432\\u0441\\u0438\\u0447\\u043A\\u0438 \\u0437\\u0430\\u0434\\u044A\\u043B\\u0436\\u0438\\u0442\\u0435\\u043B\\u043D\\u0438 \\u043F\\u043E\\u043B\\u0435\\u0442\\u0430\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA=\\u0414\\u0430\\u043D\\u043D\\u0438\\u0442\\u0435 \\u0441\\u0430 \\u043F\\u0440\\u043E\\u043C\\u0435\\u043D\\u0435\\u043D\\u0438 \\u043E\\u0442 \\u0434\\u0440\\u0443\\u0433 \\u043F\\u043E\\u0442\\u0440\\u0435\\u0431\\u0438\\u0442\\u0435\\u043B. \\u0416\\u0435\\u043B\\u0430\\u0435\\u0442\\u0435 \\u043B\\u0438 \\u0434\\u0430 \\u043F\\u0440\\u0435\\u0437\\u0430\\u043F\\u0438\\u0448\\u0435\\u0442\\u0435 \\u043D\\u0435\\u0433\\u043E\\u0432\\u0438\\u0442\\u0435 \\u043F\\u0440\\u043E\\u043C\\u0435\\u043D\\u0438 \\u0441 \\u0432\\u0430\\u0448\\u0438\\u0442\\u0435?\r\n\r\n# XMSG: message that will be displayed in case of conflicts during file renaming\r\nMSG_CONFLICTING_FILE_NAME=\\u0418\\u043C\\u0435\\u0442\\u043E \\u043D\\u0430 \\u0444\\u0430\\u0439\\u043B\\u0430 \\u0435 \\u043F\\u0440\\u043E\\u043C\\u0435\\u043D\\u0435\\u043D\\u043E \\u043E\\u0442 \\u0434\\u0440\\u0443\\u0433 \\u043F\\u043E\\u0442\\u0440\\u0435\\u0431\\u0438\\u0442\\u0435\\u043B. \\u0416\\u0435\\u043B\\u0430\\u0435\\u0442\\u0435 \\u043B\\u0438 \\u0434\\u0430 \\u043F\\u0440\\u0435\\u0437\\u0430\\u043F\\u0438\\u0448\\u0435\\u0442\\u0435 \\u043D\\u0435\\u0433\\u043E\\u0432\\u0438\\u0442\\u0435 \\u043F\\u0440\\u043E\\u043C\\u0435\\u043D\\u0438 \\u0441 \\u0432\\u0430\\u0448\\u0438\\u0442\\u0435?\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA_WITH_REFRESH=\\u0414\\u0430\\u043D\\u043D\\u0438\\u0442\\u0435 \\u0441\\u0430 \\u043F\\u0440\\u043E\\u043C\\u0435\\u043D\\u0435\\u043D\\u0438 \\u043E\\u0442 \\u0434\\u0440\\u0443\\u0433 \\u043F\\u043E\\u0442\\u0440\\u0435\\u0431\\u0438\\u0442\\u0435\\u043B. \\u0422\\u0435\\u0437\\u0438 \\u043F\\u0440\\u043E\\u043C\\u0435\\u043D\\u0438 \\u0432\\u0435\\u0447\\u0435 \\u0449\\u0435 \\u0441\\u0435 \\u043F\\u043E\\u044F\\u0432\\u044F\\u0442 \\u0432 \\u043F\\u0440\\u0438\\u043B\\u043E\\u0436\\u0435\\u043D\\u0438\\u0435\\u0442\\u043E.\r\n\r\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\r\nMSG_NOT_IN_MAIN_CONTACT=\\u041C\\u043E\\u0436\\u0435\\u0442\\u0435 \\u0434\\u0430 \\u043F\\u0440\\u0435\\u0433\\u043B\\u0435\\u0434\\u0430\\u0442\\u0435 \\u0441\\u0430\\u043C\\u043E \\u043F\\u043E\\u0434\\u0440\\u043E\\u0431\\u043D\\u0438 \\u0434\\u0430\\u043D\\u043D\\u0438 \\u0437\\u0430 \\u043A\\u043E\\u043D\\u0442\\u0430\\u043A\\u0442\\u0438, \\u043A\\u043E\\u0438\\u0442\\u043E \\u0441\\u0430 \\u043F\\u0440\\u0438\\u0441\\u044A\\u0435\\u0434\\u0438\\u043D\\u0435\\u043D\\u0438 \\u043A\\u044A\\u043C \\u0442\\u043E\\u0437\\u0438 \\u0430\\u043A\\u0430\\u0443\\u043D\\u0442\r\n\r\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\r\nMSG_EXCEEDING_FILE_NAME_LENGTH=\\u0418\\u043C\\u0435\\u0442\\u043E \\u043D\\u0430 \\u0432\\u0430\\u0448\\u0438\\u044F \\u0444\\u0430\\u0439\\u043B \\u043C\\u043E\\u0436\\u0435 \\u0434\\u0430 \\u0438\\u043C\\u0430 \\u043C\\u0430\\u043A\\u0441\\u0438\\u043C\\u0443\\u043C 40 \\u0441\\u0438\\u043C\\u0432\\u043E\\u043B\\u0430.\r\n\r\n# XTOL, 20: tooltip shown on search result list for button to add an account"\r\n\r\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\r\n\r\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\r\n\r\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\r\n\r\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\r\n\r\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\r\n',
		"cus/crm/myaccounts/i18n/i18n_cs.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XFLD, 30: Facet title for general Data\r\nGENERAL_DATA=Obecn\\u00E1 data\r\n\r\n#XTIT, 40: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=Moji z\\u00E1kazn\\u00EDci\r\n\r\n#XTIT, 40: this is the title for the detail screen\r\nDETAIL_TITLE=Z\\u00E1kazn\\u00EDk\r\n\r\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\r\nREVENUE_CURRENT=V\\u00FDnos-aktRokDodnes\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\r\nREVENUE_CURRENT_TOOLTIP=V\\u00FDnosy do dne\\u0161ka - aktu\\u00E1ln\\u00ED rok\r\n\r\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\r\nREVENUE_LAST=V\\u00FDnos posledn\\u00ED rok\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\r\nREVENUE_LAST_TOOLTIP=V\\u00FDnosy posledn\\u00ED rok\r\n\r\n# XFLD, 30: Facet title for opportunities and label in facet general data\r\nOPPORTUNITIES=P\\u0159\\u00EDle\\u017Eitosti\r\n\r\n#XFLD, 30: Facet title for leads\r\nLEADS=Tipy\r\n\r\n#XFLD, 30: Facet title for tasks\r\nTASKS=\\u00DAlohy\r\n\r\n#XFLD, 30: Facet title for appointments\r\nAPPOINTMENTS=Sch\\u016Fzky\r\n\r\n#XFLD, 30: Facet title for quotations\r\nQUOTATIONS=Nab\\u00EDdky\r\n\r\n#XFLD, 30: Facet title for sales orders\r\nSALES_ORDERS=Zak\\u00E1zky odb\\u011Bratele\r\n\r\n#XFLD, 30: W7: Facet title for marketing attributes\r\nMARKETINGATTRIBUTES=Marketingov\\u00E9 atributy\r\n\r\n#XFLD, 30: W6: Title for popup with products\r\nPRODUCTS=Produkty\r\n\r\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\r\nEMPLOYEE_RESPONSIBLE=Odpov\\u011Bdn\\u00FD zam\\u011Bstnanec\r\n\r\n#XFLD, 30: Facet title for Attachments\r\nATTACHMENTS=P\\u0159\\u00EDlohy\r\n\r\n#XFLD, 30: Facet title for Notes\r\nNOTES=Pozn\\u00E1mky\r\n\r\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\r\nNEW_NOTE=Nov\\u00E1 pozn\\u00E1mka\r\n\r\n#XFLD, 30: Facet title for Contacts\r\nCONTACTS=Kontakty\r\n\r\n#XFLD, 30: Label for Address in facet general data\r\nADDRESS=Adresa\r\n\r\n#XFLD, 30: Label for Opportunities in facet general data\r\nUNWEIGHTED_OPPORTUNITIES=P\\u0159\\u00EDle\\u017Eitosti\r\n\r\n#XFLD, 30: Label for Rating in facet general data\r\nRATING=Rating\r\n\r\n# XFLD, 30: Label for Next contact in facet Appointments\r\nNEXT_APPOINTMENT=Dal\\u0161\\u00ED sch\\u016Fzka\r\n\r\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\r\nLAST_APPOINTMENT=Posledn\\u00ED sch\\u016Fzka\r\n\r\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\r\nIMAGE=Obr\\u00E1zek\r\n\r\n#XBUT, 20: Button to show the create actionsheet\r\nCREATE=Vytvo\\u0159it\r\n\r\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\r\nDISCUSS_ENTRY=Diskutovat v SAP Jam\r\n\r\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\r\nSHARE_ENTRY=Sd\\u00EDlet v SAP Jam\r\n\r\n#XBUT, 20: Button to share the note\r\nDETAIL_BUTTON_SHARE=Sd\\u00EDlet\r\n\r\n#XBUT, 20: Button to cancel sharing\r\nDETAIL_BUTTON_CANCEL=Zru\\u0161it\r\n\r\n#XFLD,20: All accounts for filter\r\nALL_ACCOUNTS=V\\u0161ichni z\\u00E1kazn\\u00EDci\r\n\r\n#XFLD,35: All individual accounts for filter\r\nALL_INDIVIDUAL_ACCOUNTS=V\\u0161ichni individu\\u00E1ln\\u00ED z\\u00E1kazn\\u00EDci\r\n\r\n#XFLD,35: All corporate accounts for filter\r\nALL_CORPORATE_ACCOUNTS=V\\u0161ichni podnikov\\u00ED z\\u00E1kazn\\u00EDci\r\n\r\n#XFLD,35: All group accounts for filter\r\nALL_ACCOUNT_GROUPS=V\\u0161echny skupiny z\\u00E1kazn\\u00EDk\\u016F\r\n\r\n#XFLD,20: my account for filter\r\nMY_ACCOUNT=Moji z\\u00E1kazn\\u00EDci\r\n\r\n#XFLD,35: my individual accounts for filter\r\nMY_INDIVIDUAL_ACCOUNTS=Moji individu\\u00E1ln\\u00ED z\\u00E1kazn\\u00EDci\r\n\r\n#XFLD,35: my corporate accounts for filter\r\nMY_CORPORATE_ACCOUNTS=Moji podnikov\\u00ED z\\u00E1kazn\\u00EDci\r\n\r\n#XFLD,35: my group accounts for filter\r\nMY_ACCOUNT_GROUPS=Moje skupiny z\\u00E1kazn\\u00EDk\\u016F\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nINDIVIDUAL_ACCOUNT=Individu\\u00E1ln\\u00ED z\\u00E1kazn\\u00EDk\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nCORPORATE_ACCOUNT=Podnikov\\u00FD z\\u00E1kazn\\u00EDk\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nACCOUNT_GROUP=\\u00DA\\u010Dtov\\u00E1 skupina\r\n\r\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\r\nSTARTING=Po\\u010D\\u00E1te\\u010Dn\\u00ED datum\\: {0}\r\n\r\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\r\nCLOSING=Datum uzav\\u0159en\\u00ED\\: {0}\r\n\r\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\r\nDUE=Term\\u00EDn\\: {0}\r\n\r\n#XFLD,20: All accounts for title\r\nALL_ACCOUNTS_TITLE=V\\u0161ichni z\\u00E1kazn\\u00EDci ({0})\r\n\r\n#XFLD,35: All individual accounts for title\r\nALL_INDIVIDUAL_ACCOUNTS_TITLE=V\\u0161ichni individu\\u00E1ln\\u00ED z\\u00E1kazn\\u00EDci ({0})\r\n\r\n#XFLD,35: All corporate accounts for title\r\nALL_CORPORATE_ACCOUNTS_TITLE=V\\u0161ichni podnikov\\u00ED z\\u00E1kazn\\u00EDci ({0})\r\n\r\n#XFLD,35: All group accounts for title\r\nALL_ACCOUNT_GROUPS_TITLE=V\\u0161echny skupiny z\\u00E1kazn\\u00EDk\\u016F ({0})\r\n\r\n#XFLD,20: my account for title\r\nMY_ACCOUNT_TITLE=Moji z\\u00E1kazn\\u00EDci ({0})\r\n\r\n#XFLD,35: my individual account for title\r\nMY_INDIVIDUAL_ACCOUNT_TITLE=Moji individu\\u00E1ln\\u00ED z\\u00E1kazn\\u00EDci ({0})\r\n\r\n#XFLD,35: my corporate account for title.\r\nMY_CORPORATE_ACCOUNT_TITLE=Moji podnikov\\u00ED z\\u00E1kazn\\u00EDci ({0})\r\n\r\n#XFLD,35: my group account for title\r\nMY_ACCOUNT_GROUP_TITLE=Moje skupiny z\\u00E1kazn\\u00EDk\\u016F ({0})\r\n\r\n#XFLD,30: filtered by info\r\nFILTERED_BY=Filtrov\\u00E1no podle\\: {0}\r\n\r\n#XFLD,30: label, search for accounts\r\nSEARCH_ACCOUNTS=Hledat\r\n\r\n#XFLD,30: comma separator for location\r\nLOCATION={0}, {1}\r\n\r\n#XFLD: W4: Label for All day text in Appointments\r\nALL_DAY_EVENT=Cel\\u00FD den\r\n\r\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\r\nDURATION_MINUTE={0} min.\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\r\nDURATION_HOUR={0} hod.\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\r\nDURATION_DAY={0} den\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\r\nDURATION_DAYS={0} dn\\u00ED\r\n\r\n#XFLD: W4: Label for Private meeting\r\nPRIVATE=Soukrom\\u00E9\r\n\r\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\r\nSELECT_TRANSACTION_TYPE=Vybrat typ transakce\r\n\r\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\r\nNEW_TASK_INPUT_PLACEHOLDER=Nov\\u00E1 \\u00FAloha\r\n\r\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nNO_DATA_TEXT=Chyb\\u00ED data\r\n\r\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nLOADING_TEXT=Zav\\u00E1d\\u00ED se...\r\n\r\n#XFLD,25: W4: Column label for name of contact person in contacts\r\nNAME=Jm\\u00E9no\r\n\r\n#XFLD,25: W5: Column label for department of contact person in contacts\r\nDEPARTMENT=Odd\\u011Blen\\u00ED\r\n\r\n#XFLD,15: W6: Column label for actions of contact person in contacts\r\nACTIONS=\\u010Cinnosti\r\n\r\n#XFLD,25: W4: Column label for description of lead in Leads\r\nDESCRIPTION=Popis\r\n\r\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\r\nASSIGNED_TO=P\\u0159i\\u0159azeno k\r\n\r\n#XFLD,15: W4: Column label for end date of lead in Leads\r\nEND_DATE=Koncov\\u00E9 datum\r\n\r\n#XFLD,15: W4: Column label for qualification level of lead in Leads\r\nQUALIFICATION=Kvalifikace\r\n\r\n#XFLD,15: W4: Column label for status of lead in Leads\r\nSTATUS=Status\r\n\r\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\r\nMAIN_CONTACT=Hlavn\\u00ED kontakt\r\n\r\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\r\nVOLUME=Objem\r\n\r\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\r\nPROBABILITY=Pravd\\u011Bpodobnost\r\n\r\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\r\nCLOSE_BY=Uzav\\u0159en\\u00ED do\r\n\r\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \r\nVIEWS=Zobrazen\\u00ED\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\r\nCONTACT_TITLE=Kontakt\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\r\nEMPLOYEE_TITLE=Zam\\u011Bstnanec\r\n\r\n#XTIT,20: W7: Title of pop-up used in confirm popup\r\nCONFIRM_TITLE=Potvrzen\\u00ED\r\n\r\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\r\nCOMPANY_NAME=N\\u00E1zev\r\n\r\n#XFLD,20: W4: Label for name 1 of a company used general data\r\nCOMPANY_NAME1=Jm\\u00E9no 1\r\n\r\n#XFLD,20: W4: Label for name 2 of a company used general data\r\nCOMPANY_NAME2=Jm\\u00E9no 2\r\n\r\n#XFLD,20: W4: Label for first name of a person used general data\r\nFIRST_NAME=K\\u0159estn\\u00ED jm\\u00E9no\r\n\r\n#XFLD,20: W4: Label for last name of a person used general data\r\nLAST_NAME=P\\u0159\\u00EDjmen\\u00ED\r\n\r\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nBIRTHDAY=Datum narozen\\u00ED\r\n\r\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nTITLE=Titul\r\n\r\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nACADEMIC_TITLE=Akademick\\u00FD titul\r\n\r\n#XFLD,20: W4: Label for mobile phone number used general data\r\nMOBILE=Mobiln\\u00ED telefon\r\n\r\n#XFLD,20: W4: Label for phone number used general data\r\nPHONE=Telefon\r\n\r\n#XFLD,20: W4: Label for e-mail used general data\r\nEMAIL=E-mail\r\n\r\n#XFLD,20: W4: Label for web site used general data\r\nWEBSITE=Webov\\u00E1 str\\u00E1nka\r\n\r\n#XFLD,20: W4: Label for country used general data\r\nCOUNTRY=St\\u00E1t\r\n\r\n#XFLD,20: W4: Label for region used general data\r\nREGION=Region\r\n\r\n#XFLD,20: W4: Label for city used general data\r\nCITY=M\\u011Bsto\r\n\r\n#XFLD,20: W4: Label for postal code used general data\r\nPOSTAL_CODE=PS\\u010C\r\n\r\n#XFLD,20: W4: Label for street used general data\r\nSTREET=Ulice\r\n\r\n#XFLD,10: W4: Label for house number used general data\r\nHOUSE_NUMBER=\\u010C. domu\r\n\r\n#XFLD,15: W6: Label for ID used in Quotations\r\nID=ID\r\n\r\n#XFLD,15: W6: Label for Amount used in Quotations\r\nAMOUNT=\\u010C\\u00E1stka\r\n\r\n#XFLD,20: W6: Label for Expiration Date used in Quotations\r\nEXPIRATION_DATE=Datum expirace\r\n\r\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\r\nDELIVERY_DATE=Datum dod\\u00E1vky\r\n\r\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\r\nSALES_EMPLOYEE=Pracovn\\u00EDk odbytu\r\n\r\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\r\nATTRIBUTESET=Sada atribut\\u016F\r\n\r\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\r\nATTRIBUTE=Atribut\r\n\r\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\r\nVALUE=Hodnota\r\n\r\n#XBUT, 20: Button to create an Account\r\nBUTTON_ADD=P\\u0159idat\r\n\r\n#XBUT, 20: Button to edit an Account\r\nBUTTON_EDIT=Upravit\r\n\r\n#XBUT, 20: Button to save changes\r\nBUTTON_SAVE=Ulo\\u017Eit\r\n\r\n#XBUT, 20: Button to cancel changes\r\nBUTTON_CANCEL=Zru\\u0161it\r\n\r\n#XBUT, 30: Button which shows the personalization buttons\r\nBUTTON_SHOW_PERSONALIZATION=Zobrazit personalizaci\r\n\r\n#XBUT, 30: Button which hides the personalization buttons\r\nBUTTON_HIDE_PERSONALIZATION=Skr\\u00FDt personalizaci\r\n\r\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_CONFIRM_CANCEL=V\\u0161echny neulo\\u017Een\\u00E9 zm\\u011Bny budou ztraceny. Chcete pokra\\u010Dovat?\r\n\r\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\r\nMSG_CONFIRM_DELETE_CONTACT=P\\u0159i\\u0159azen\\u00ED kontaktu k z\\u00E1kazn\\u00EDkovi bude zru\\u0161eno. Chcete pokra\\u010Dovat?\r\n\r\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_SUCCESS=Z\\u00E1kazn\\u00EDk aktualizov\\u00E1n\r\n\r\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_ERROR=Aktualizace se nezda\\u0159ila\r\n\r\n# XMSG : Account update succeeded\r\nMSG_CREATION_SUCCESS=Z\\u00E1kazn\\u00EDk vytvo\\u0159en\r\n\r\n# XMSG : Task creation succeeded\r\nMSG_TASK_CREATION_SUCCESS=\\u00DAloha vytvo\\u0159ena\r\n\r\n# XMSG : Contact creation failed\r\nMSG_CREATION_ERROR=Vytvo\\u0159en\\u00ED se nezda\\u0159ilo\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong country\r\nMSG_WRONG_COUNTRY_ERROR=St\\u00E1t \\u201E{0}\\u201C neexistuje\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong region\r\nMSG_WRONG_REGION_ERROR=Region \\u201E{0}\\u201C neexistuje pro st\\u00E1t\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong employee\r\nMSG_WRONG_EMPLOYEE_ERROR=Zam\\u011Bstnanec \\u201E{0}\\u201C neexistuje.\r\n\r\n# XMSG: message that will be displayed, if the user has entered invalid website url\r\nMSG_WRONG_URL_ERROR=Zadan\\u00E9 URL \\u201E{0}\\u201C nen\\u00ED platn\\u00E9.\r\n\r\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\r\nMSG_MANDATORY_FIELDS=V\\u0161echna povinn\\u00E1 pole nejsou vypln\\u011Bna.\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA=Data zm\\u011Bnil jin\\u00FD u\\u017Eivatel. Chcete p\\u0159epsat zm\\u011Bny jin\\u00E9ho u\\u017Eivatele vlastn\\u00EDmi?\r\n\r\n# XMSG: message that will be displayed in case of conflicts during file renaming\r\nMSG_CONFLICTING_FILE_NAME=N\\u00E1zev souboru zm\\u011Bnil jin\\u00FD u\\u017Eivatel. Chcete p\\u0159epsat zm\\u011Bny jin\\u00E9ho u\\u017Eivatele vlastn\\u00EDmi zm\\u011Bnami?\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA_WITH_REFRESH=Data zm\\u011Bnil jin\\u00FD u\\u017Eivatel. Tyto zm\\u011Bny se nyn\\u00ED zobraz\\u00ED v aplikaci.\r\n\r\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\r\nMSG_NOT_IN_MAIN_CONTACT=M\\u016F\\u017Eete zobrazit pouze detaily kontakt\\u016F, kter\\u00E9 jsou p\\u0159i\\u0159azen\\u00E9 tomuto z\\u00E1kazn\\u00EDkovi.\r\n\r\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\r\nMSG_EXCEEDING_FILE_NAME_LENGTH=N\\u00E1zev souboru m\\u016F\\u017Ee m\\u00EDt maxim\\u00E1ln\\u011B 40 znak\\u016F.\r\n\r\n# XTOL, 20: tooltip shown on search result list for button to add an account"\r\n\r\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\r\n\r\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\r\n\r\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\r\n\r\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\r\n\r\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\r\n',
		"cus/crm/myaccounts/i18n/i18n_de.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XFLD, 30: Facet title for general Data\r\nGENERAL_DATA=Allgemeine Daten\r\n\r\n#XTIT, 40: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=Meine Accounts\r\n\r\n#XTIT, 40: this is the title for the detail screen\r\nDETAIL_TITLE=Account\r\n\r\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\r\nREVENUE_CURRENT=Umsatz lauf. Jahr\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\r\nREVENUE_CURRENT_TOOLTIP=Umsatz bis heute (laufendes Jahr)\r\n\r\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\r\nREVENUE_LAST=Umsatz Vorjahr\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\r\nREVENUE_LAST_TOOLTIP=Umsatz Vorjahr\r\n\r\n# XFLD, 30: Facet title for opportunities and label in facet general data\r\nOPPORTUNITIES=Opportunitys\r\n\r\n#XFLD, 30: Facet title for leads\r\nLEADS=Leads\r\n\r\n#XFLD, 30: Facet title for tasks\r\nTASKS=Aufgaben\r\n\r\n#XFLD, 30: Facet title for appointments\r\nAPPOINTMENTS=Termine\r\n\r\n#XFLD, 30: Facet title for quotations\r\nQUOTATIONS=Angebote\r\n\r\n#XFLD, 30: Facet title for sales orders\r\nSALES_ORDERS=Kundenauftr\\u00E4ge\r\n\r\n#XFLD, 30: W7: Facet title for marketing attributes\r\nMARKETINGATTRIBUTES=Marketingattribute\r\n\r\n#XFLD, 30: W6: Title for popup with products\r\nPRODUCTS=Produkte\r\n\r\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\r\nEMPLOYEE_RESPONSIBLE=Zust\\u00E4ndiger Mitarbeiter\r\n\r\n#XFLD, 30: Facet title for Attachments\r\nATTACHMENTS=Anlagen\r\n\r\n#XFLD, 30: Facet title for Notes\r\nNOTES=Notizen\r\n\r\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\r\nNEW_NOTE=Neue Notiz\r\n\r\n#XFLD, 30: Facet title for Contacts\r\nCONTACTS=Ansprechpartner\r\n\r\n#XFLD, 30: Label for Address in facet general data\r\nADDRESS=Adresse\r\n\r\n#XFLD, 30: Label for Opportunities in facet general data\r\nUNWEIGHTED_OPPORTUNITIES=Opportunitys\r\n\r\n#XFLD, 30: Label for Rating in facet general data\r\nRATING=Bewertung\r\n\r\n# XFLD, 30: Label for Next contact in facet Appointments\r\nNEXT_APPOINTMENT=N\\u00E4chster Termin\r\n\r\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\r\nLAST_APPOINTMENT=Letzter Termin\r\n\r\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\r\nIMAGE=Bild\r\n\r\n#XBUT, 20: Button to show the create actionsheet\r\nCREATE=Anlegen\r\n\r\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\r\nDISCUSS_ENTRY=In SAP Jam diskutieren\r\n\r\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\r\nSHARE_ENTRY=In SAP Jam teilen\r\n\r\n#XBUT, 20: Button to share the note\r\nDETAIL_BUTTON_SHARE=Teilen\r\n\r\n#XBUT, 20: Button to cancel sharing\r\nDETAIL_BUTTON_CANCEL=Abbrechen\r\n\r\n#XFLD,20: All accounts for filter\r\nALL_ACCOUNTS=Alle Accounts\r\n\r\n#XFLD,35: All individual accounts for filter\r\nALL_INDIVIDUAL_ACCOUNTS=Alle Privat-Accounts\r\n\r\n#XFLD,35: All corporate accounts for filter\r\nALL_CORPORATE_ACCOUNTS=Alle Unternehmens-Accounts\r\n\r\n#XFLD,35: All group accounts for filter\r\nALL_ACCOUNT_GROUPS=Alle Account-Gruppen\r\n\r\n#XFLD,20: my account for filter\r\nMY_ACCOUNT=Meine Accounts\r\n\r\n#XFLD,35: my individual accounts for filter\r\nMY_INDIVIDUAL_ACCOUNTS=Meine Privat-Accounts\r\n\r\n#XFLD,35: my corporate accounts for filter\r\nMY_CORPORATE_ACCOUNTS=Meine Unternehmens-Accounts\r\n\r\n#XFLD,35: my group accounts for filter\r\nMY_ACCOUNT_GROUPS=Meine Account-Gruppen\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nINDIVIDUAL_ACCOUNT=Privat-Account\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nCORPORATE_ACCOUNT=Unternehmens-Account\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nACCOUNT_GROUP=Account-Gruppe\r\n\r\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\r\nSTARTING=Startdatum\\: {0}\r\n\r\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\r\nCLOSING=Abschlussdatum\\: {0}\r\n\r\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\r\nDUE=F\\u00E4lligkeitsdatum\\: {0}\r\n\r\n#XFLD,20: All accounts for title\r\nALL_ACCOUNTS_TITLE=Alle Accounts ({0})\r\n\r\n#XFLD,35: All individual accounts for title\r\nALL_INDIVIDUAL_ACCOUNTS_TITLE=Alle Privat-Accounts ({0})\r\n\r\n#XFLD,35: All corporate accounts for title\r\nALL_CORPORATE_ACCOUNTS_TITLE=Alle Unternehmens-Accounts ({0})\r\n\r\n#XFLD,35: All group accounts for title\r\nALL_ACCOUNT_GROUPS_TITLE=Alle Account-Gruppen ({0})\r\n\r\n#XFLD,20: my account for title\r\nMY_ACCOUNT_TITLE=Meine Accounts ({0})\r\n\r\n#XFLD,35: my individual account for title\r\nMY_INDIVIDUAL_ACCOUNT_TITLE=Meine Privat-Accounts ({0})\r\n\r\n#XFLD,35: my corporate account for title.\r\nMY_CORPORATE_ACCOUNT_TITLE=Meine Unternehmens-Accounts ({0})\r\n\r\n#XFLD,35: my group account for title\r\nMY_ACCOUNT_GROUP_TITLE=Meine Account-Gruppen ({0})\r\n\r\n#XFLD,30: filtered by info\r\nFILTERED_BY=Gefiltert nach\\: {0}\r\n\r\n#XFLD,30: label, search for accounts\r\nSEARCH_ACCOUNTS=Suchen\r\n\r\n#XFLD,30: comma separator for location\r\nLOCATION={0}, {1}\r\n\r\n#XFLD: W4: Label for All day text in Appointments\r\nALL_DAY_EVENT=Ganzt\\u00E4gig\r\n\r\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\r\nDURATION_MINUTE={0} Min\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\r\nDURATION_HOUR={0} Std\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\r\nDURATION_DAY={0} Tag\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\r\nDURATION_DAYS={0} Tage\r\n\r\n#XFLD: W4: Label for Private meeting\r\nPRIVATE=Privat\r\n\r\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\r\nSELECT_TRANSACTION_TYPE=Vorgangsart ausw\\u00E4hlen\r\n\r\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\r\nNEW_TASK_INPUT_PLACEHOLDER=Neue Aufgabe\r\n\r\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nNO_DATA_TEXT=Keine Daten\r\n\r\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nLOADING_TEXT=Ladevorgang l\\u00E4uft...\r\n\r\n#XFLD,25: W4: Column label for name of contact person in contacts\r\nNAME=Name\r\n\r\n#XFLD,25: W5: Column label for department of contact person in contacts\r\nDEPARTMENT=Abteilung\r\n\r\n#XFLD,15: W6: Column label for actions of contact person in contacts\r\nACTIONS=Aktionen\r\n\r\n#XFLD,25: W4: Column label for description of lead in Leads\r\nDESCRIPTION=Beschreibung\r\n\r\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\r\nASSIGNED_TO=Zugeordnet zu\r\n\r\n#XFLD,15: W4: Column label for end date of lead in Leads\r\nEND_DATE=Enddatum\r\n\r\n#XFLD,15: W4: Column label for qualification level of lead in Leads\r\nQUALIFICATION=Qualifizierung\r\n\r\n#XFLD,15: W4: Column label for status of lead in Leads\r\nSTATUS=Status\r\n\r\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\r\nMAIN_CONTACT=Hauptansprechpartner\r\n\r\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\r\nVOLUME=Volumen\r\n\r\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\r\nPROBABILITY=Wahrscheinlichkeit\r\n\r\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\r\nCLOSE_BY=Abschluss bis\r\n\r\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \r\nVIEWS=Sichten\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\r\nCONTACT_TITLE=Ansprechpartner\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\r\nEMPLOYEE_TITLE=Mitarbeiter\r\n\r\n#XTIT,20: W7: Title of pop-up used in confirm popup\r\nCONFIRM_TITLE=Best\\u00E4tigen\r\n\r\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\r\nCOMPANY_NAME=Name\r\n\r\n#XFLD,20: W4: Label for name 1 of a company used general data\r\nCOMPANY_NAME1=Name 1\r\n\r\n#XFLD,20: W4: Label for name 2 of a company used general data\r\nCOMPANY_NAME2=Name 2\r\n\r\n#XFLD,20: W4: Label for first name of a person used general data\r\nFIRST_NAME=Vorname\r\n\r\n#XFLD,20: W4: Label for last name of a person used general data\r\nLAST_NAME=Nachname\r\n\r\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nBIRTHDAY=Geburtsdatum\r\n\r\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nTITLE=Anrede\r\n\r\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nACADEMIC_TITLE=Akademischer Titel\r\n\r\n#XFLD,20: W4: Label for mobile phone number used general data\r\nMOBILE=Mobil\r\n\r\n#XFLD,20: W4: Label for phone number used general data\r\nPHONE=Telefon\r\n\r\n#XFLD,20: W4: Label for e-mail used general data\r\nEMAIL=E-Mail\r\n\r\n#XFLD,20: W4: Label for web site used general data\r\nWEBSITE=Webseite\r\n\r\n#XFLD,20: W4: Label for country used general data\r\nCOUNTRY=Land\r\n\r\n#XFLD,20: W4: Label for region used general data\r\nREGION=Region\r\n\r\n#XFLD,20: W4: Label for city used general data\r\nCITY=Ort\r\n\r\n#XFLD,20: W4: Label for postal code used general data\r\nPOSTAL_CODE=Postleitzahl\r\n\r\n#XFLD,20: W4: Label for street used general data\r\nSTREET=Stra\\u00DFe\r\n\r\n#XFLD,10: W4: Label for house number used general data\r\nHOUSE_NUMBER=Hausnummer\r\n\r\n#XFLD,15: W6: Label for ID used in Quotations\r\nID=ID\r\n\r\n#XFLD,15: W6: Label for Amount used in Quotations\r\nAMOUNT=Betrag\r\n\r\n#XFLD,20: W6: Label for Expiration Date used in Quotations\r\nEXPIRATION_DATE=Ablaufdatum\r\n\r\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\r\nDELIVERY_DATE=Lieferdatum\r\n\r\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\r\nSALES_EMPLOYEE=Vertriebsmitarbeiter\r\n\r\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\r\nATTRIBUTESET=Attributgruppe\r\n\r\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\r\nATTRIBUTE=Attribut\r\n\r\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\r\nVALUE=Wert\r\n\r\n#XBUT, 20: Button to create an Account\r\nBUTTON_ADD=Hinzuf\\u00FCgen\r\n\r\n#XBUT, 20: Button to edit an Account\r\nBUTTON_EDIT=Bearbeiten\r\n\r\n#XBUT, 20: Button to save changes\r\nBUTTON_SAVE=Sichern\r\n\r\n#XBUT, 20: Button to cancel changes\r\nBUTTON_CANCEL=Abbrechen\r\n\r\n#XBUT, 30: Button which shows the personalization buttons\r\nBUTTON_SHOW_PERSONALIZATION=Personalisierung ein\r\n\r\n#XBUT, 30: Button which hides the personalization buttons\r\nBUTTON_HIDE_PERSONALIZATION=Personalisierung aus\r\n\r\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_CONFIRM_CANCEL=Ungesicherte \\u00C4nderungen gehen verloren. M\\u00F6chten Sie fortfahren?\r\n\r\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\r\nMSG_CONFIRM_DELETE_CONTACT=Die Zuordnung des Ansprechpartners zum Account wird entfernt. M\\u00F6chten Sie fortfahren?\r\n\r\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_SUCCESS=Account aktualisiert\r\n\r\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_ERROR=Aktualisierung fehlgeschlagen\r\n\r\n# XMSG : Account update succeeded\r\nMSG_CREATION_SUCCESS=Account angelegt\r\n\r\n# XMSG : Task creation succeeded\r\nMSG_TASK_CREATION_SUCCESS=Aufgabe angelegt\r\n\r\n# XMSG : Contact creation failed\r\nMSG_CREATION_ERROR=Anlegen fehlgeschlagen\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong country\r\nMSG_WRONG_COUNTRY_ERROR=Land "{0}" ist nicht vorhanden\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong region\r\nMSG_WRONG_REGION_ERROR=Region "{0}" ist f\\u00FCr das angegebene Land nicht vorhanden\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong employee\r\nMSG_WRONG_EMPLOYEE_ERROR=Mitarbeiter "{0}" ist nicht vorhanden.\r\n\r\n# XMSG: message that will be displayed, if the user has entered invalid website url\r\nMSG_WRONG_URL_ERROR=Die eingegebene URL "{0}" ist nicht g\\u00FCltig.\r\n\r\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\r\nMSG_MANDATORY_FIELDS=Es sind nicht alle erforderlichen Felder gef\\u00FCllt\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA=Daten wurden von einem anderen Benutzer ge\\u00E4ndert. M\\u00F6chten Sie die \\u00C4nderungen des anderen Benutzers mit Ihren \\u00C4nderungen \\u00FCberschreiben?\r\n\r\n# XMSG: message that will be displayed in case of conflicts during file renaming\r\nMSG_CONFLICTING_FILE_NAME=Der Dateiname wurde von einem anderen Benutzer ge\\u00E4ndert. M\\u00F6chten Sie die \\u00C4nderungen des anderen Benutzers mit Ihren \\u00C4nderungen \\u00FCberschreiben?\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA_WITH_REFRESH=Daten wurden von einem anderen Benutzer ge\\u00E4ndert. Diese \\u00C4nderungen sind nun in der App sichtbar.\r\n\r\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\r\nMSG_NOT_IN_MAIN_CONTACT=Sie k\\u00F6nnen nur Details zu Ansprechpartnern anzeigen, die zu diesem Account zugeordnet sind\r\n\r\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\r\nMSG_EXCEEDING_FILE_NAME_LENGTH=Ihr Dateiname darf maximal 40 Zeichen enthalten.\r\n\r\n# XTOL, 20: tooltip shown on search result list for button to add an account"\r\n\r\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\r\n\r\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\r\n\r\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\r\n\r\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\r\n\r\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\r\n',
		"cus/crm/myaccounts/i18n/i18n_en.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XFLD, 30: Facet title for general Data\r\nGENERAL_DATA=General Data\r\n\r\n#XTIT, 40: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=My Accounts\r\n\r\n#XTIT, 40: this is the title for the detail screen\r\nDETAIL_TITLE=Account\r\n\r\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\r\nREVENUE_CURRENT=Revenue YTD\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\r\nREVENUE_CURRENT_TOOLTIP=Revenue to Date Current Year\r\n\r\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\r\nREVENUE_LAST=Revenue Last Year\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\r\nREVENUE_LAST_TOOLTIP=Revenue Last Year\r\n\r\n# XFLD, 30: Facet title for opportunities and label in facet general data\r\nOPPORTUNITIES=Opportunities\r\n\r\n#XFLD, 30: Facet title for leads\r\nLEADS=Leads\r\n\r\n#XFLD, 30: Facet title for tasks\r\nTASKS=Tasks\r\n\r\n#XFLD, 30: Facet title for appointments\r\nAPPOINTMENTS=Appointments\r\n\r\n#XFLD, 30: Facet title for quotations\r\nQUOTATIONS=Quotations\r\n\r\n#XFLD, 30: Facet title for sales orders\r\nSALES_ORDERS=Sales Orders\r\n\r\n#XFLD, 30: W7: Facet title for marketing attributes\r\nMARKETINGATTRIBUTES=Marketing Attributes\r\n\r\n#XFLD, 30: W6: Title for popup with products\r\nPRODUCTS=Products\r\n\r\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\r\nEMPLOYEE_RESPONSIBLE=Employee Responsible\r\n\r\n#XFLD, 30: Facet title for Attachments\r\nATTACHMENTS=Attachments\r\n\r\n#XFLD, 30: Facet title for Notes\r\nNOTES=Notes\r\n\r\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\r\nNEW_NOTE=New note\r\n\r\n#XFLD, 30: Facet title for Contacts\r\nCONTACTS=Contacts\r\n\r\n#XFLD, 30: Label for Address in facet general data\r\nADDRESS=Address\r\n\r\n#XFLD, 30: Label for Opportunities in facet general data\r\nUNWEIGHTED_OPPORTUNITIES=Opportunities\r\n\r\n#XFLD, 30: Label for Rating in facet general data\r\nRATING=Rating\r\n\r\n# XFLD, 30: Label for Next contact in facet Appointments\r\nNEXT_APPOINTMENT=Next Appointment\r\n\r\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\r\nLAST_APPOINTMENT=Last Appointment\r\n\r\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\r\nIMAGE=Image\r\n\r\n#XBUT, 20: Button to show the create actionsheet\r\nCREATE=Create\r\n\r\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\r\nDISCUSS_ENTRY=Discuss on SAP Jam\r\n\r\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\r\nSHARE_ENTRY=Share on SAP Jam\r\n\r\n#XBUT, 20: Button to share the note\r\nDETAIL_BUTTON_SHARE=Share\r\n\r\n#XBUT, 20: Button to cancel sharing\r\nDETAIL_BUTTON_CANCEL=Cancel\r\n\r\n#XFLD,20: All accounts for filter\r\nALL_ACCOUNTS=All Accounts\r\n\r\n#XFLD,35: All individual accounts for filter\r\nALL_INDIVIDUAL_ACCOUNTS=All Individual Accounts\r\n\r\n#XFLD,35: All corporate accounts for filter\r\nALL_CORPORATE_ACCOUNTS=All Corporate Accounts\r\n\r\n#XFLD,35: All group accounts for filter\r\nALL_ACCOUNT_GROUPS=All Account Groups\r\n\r\n#XFLD,20: my account for filter\r\nMY_ACCOUNT=My Accounts\r\n\r\n#XFLD,35: my individual accounts for filter\r\nMY_INDIVIDUAL_ACCOUNTS=My Individual Accounts\r\n\r\n#XFLD,35: my corporate accounts for filter\r\nMY_CORPORATE_ACCOUNTS=My Corporate Accounts\r\n\r\n#XFLD,35: my group accounts for filter\r\nMY_ACCOUNT_GROUPS=My Account Groups\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nINDIVIDUAL_ACCOUNT=Individual Account\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nCORPORATE_ACCOUNT=Corporate Account\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nACCOUNT_GROUP=Account Group\r\n\r\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\r\nSTARTING=Start Date\\: {0}\r\n\r\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\r\nCLOSING=Closing Date\\: {0}\r\n\r\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\r\nDUE=Due Date\\: {0}\r\n\r\n#XFLD,20: All accounts for title\r\nALL_ACCOUNTS_TITLE=All Accounts ({0})\r\n\r\n#XFLD,35: All individual accounts for title\r\nALL_INDIVIDUAL_ACCOUNTS_TITLE=All Individual Accounts ({0})\r\n\r\n#XFLD,35: All corporate accounts for title\r\nALL_CORPORATE_ACCOUNTS_TITLE=All Corporate Accounts ({0})\r\n\r\n#XFLD,35: All group accounts for title\r\nALL_ACCOUNT_GROUPS_TITLE=All Account Groups ({0})\r\n\r\n#XFLD,20: my account for title\r\nMY_ACCOUNT_TITLE=My Accounts ({0})\r\n\r\n#XFLD,35: my individual account for title\r\nMY_INDIVIDUAL_ACCOUNT_TITLE=My Individual Accounts ({0})\r\n\r\n#XFLD,35: my corporate account for title.\r\nMY_CORPORATE_ACCOUNT_TITLE=My Corporate Accounts ({0})\r\n\r\n#XFLD,35: my group account for title\r\nMY_ACCOUNT_GROUP_TITLE=My Account Groups ({0})\r\n\r\n#XFLD,30: filtered by info\r\nFILTERED_BY=Filtered By\\: {0}\r\n\r\n#XFLD,30: label, search for accounts\r\nSEARCH_ACCOUNTS=Search\r\n\r\n#XFLD,30: comma separator for location\r\nLOCATION={0}, {1}\r\n\r\n#XFLD: W4: Label for All day text in Appointments\r\nALL_DAY_EVENT=All Day\r\n\r\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\r\nDURATION_MINUTE={0} min\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\r\nDURATION_HOUR={0} h\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\r\nDURATION_DAY={0} day\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\r\nDURATION_DAYS={0} days\r\n\r\n#XFLD: W4: Label for Private meeting\r\nPRIVATE=Private\r\n\r\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\r\nSELECT_TRANSACTION_TYPE=Select Transaction Type\r\n\r\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\r\nNEW_TASK_INPUT_PLACEHOLDER=New task\r\n\r\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nNO_DATA_TEXT=No data\r\n\r\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nLOADING_TEXT=Loading...\r\n\r\n#XFLD,25: W4: Column label for name of contact person in contacts\r\nNAME=Name\r\n\r\n#XFLD,25: W5: Column label for department of contact person in contacts\r\nDEPARTMENT=Department\r\n\r\n#XFLD,15: W6: Column label for actions of contact person in contacts\r\nACTIONS=Actions\r\n\r\n#XFLD,25: W4: Column label for description of lead in Leads\r\nDESCRIPTION=Description\r\n\r\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\r\nASSIGNED_TO=Assigned To\r\n\r\n#XFLD,15: W4: Column label for end date of lead in Leads\r\nEND_DATE=End Date\r\n\r\n#XFLD,15: W4: Column label for qualification level of lead in Leads\r\nQUALIFICATION=Qualification\r\n\r\n#XFLD,15: W4: Column label for status of lead in Leads\r\nSTATUS=Status\r\n\r\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\r\nMAIN_CONTACT=Main Contact\r\n\r\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\r\nVOLUME=Volume\r\n\r\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\r\nPROBABILITY=Probability\r\n\r\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\r\nCLOSE_BY=Close By\r\n\r\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \r\nVIEWS=Views\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\r\nCONTACT_TITLE=Contact\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\r\nEMPLOYEE_TITLE=Employee\r\n\r\n#XTIT,20: W7: Title of pop-up used in confirm popup\r\nCONFIRM_TITLE=Confirm\r\n\r\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\r\nCOMPANY_NAME=Name\r\n\r\n#XFLD,20: W4: Label for name 1 of a company used general data\r\nCOMPANY_NAME1=Name 1\r\n\r\n#XFLD,20: W4: Label for name 2 of a company used general data\r\nCOMPANY_NAME2=Name 2\r\n\r\n#XFLD,20: W4: Label for first name of a person used general data\r\nFIRST_NAME=First Name\r\n\r\n#XFLD,20: W4: Label for last name of a person used general data\r\nLAST_NAME=Last Name\r\n\r\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nBIRTHDAY=Date of Birth\r\n\r\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nTITLE=Title\r\n\r\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nACADEMIC_TITLE=Academic Title\r\n\r\n#XFLD,20: W4: Label for mobile phone number used general data\r\nMOBILE=Mobile\r\n\r\n#XFLD,20: W4: Label for phone number used general data\r\nPHONE=Phone\r\n\r\n#XFLD,20: W4: Label for e-mail used general data\r\nEMAIL=Email\r\n\r\n#XFLD,20: W4: Label for web site used general data\r\nWEBSITE=Website\r\n\r\n#XFLD,20: W4: Label for country used general data\r\nCOUNTRY=Country\r\n\r\n#XFLD,20: W4: Label for region used general data\r\nREGION=Region\r\n\r\n#XFLD,20: W4: Label for city used general data\r\nCITY=City\r\n\r\n#XFLD,20: W4: Label for postal code used general data\r\nPOSTAL_CODE=Postal Code\r\n\r\n#XFLD,20: W4: Label for street used general data\r\nSTREET=Street\r\n\r\n#XFLD,10: W4: Label for house number used general data\r\nHOUSE_NUMBER=House No.\r\n\r\n#XFLD,15: W6: Label for ID used in Quotations\r\nID=ID\r\n\r\n#XFLD,15: W6: Label for Amount used in Quotations\r\nAMOUNT=Amount\r\n\r\n#XFLD,20: W6: Label for Expiration Date used in Quotations\r\nEXPIRATION_DATE=Expiration Date\r\n\r\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\r\nDELIVERY_DATE=Delivery Date\r\n\r\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\r\nSALES_EMPLOYEE=Sales Employee\r\n\r\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\r\nATTRIBUTESET=Attribute Set\r\n\r\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\r\nATTRIBUTE=Attribute\r\n\r\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\r\nVALUE=Value\r\n\r\n#XBUT, 20: Button to create an Account\r\nBUTTON_ADD=Add\r\n\r\n#XBUT, 20: Button to edit an Account\r\nBUTTON_EDIT=Edit\r\n\r\n#XBUT, 20: Button to save changes\r\nBUTTON_SAVE=Save\r\n\r\n#XBUT, 20: Button to cancel changes\r\nBUTTON_CANCEL=Cancel\r\n\r\n#XBUT, 30: Button which shows the personalization buttons\r\nBUTTON_SHOW_PERSONALIZATION=Show Personalization\r\n\r\n#XBUT, 30: Button which hides the personalization buttons\r\nBUTTON_HIDE_PERSONALIZATION=Hide Personalization\r\n\r\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_CONFIRM_CANCEL=Any unsaved changes will be lost. Do you want to continue?\r\n\r\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\r\nMSG_CONFIRM_DELETE_CONTACT=The contact will be unassigned from the account. Do you want to continue?\r\n\r\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_SUCCESS=Account updated\r\n\r\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_ERROR=Update failed\r\n\r\n# XMSG : Account update succeeded\r\nMSG_CREATION_SUCCESS=Account created\r\n\r\n# XMSG : Task creation succeeded\r\nMSG_TASK_CREATION_SUCCESS=Task created\r\n\r\n# XMSG : Contact creation failed\r\nMSG_CREATION_ERROR=Creation failed\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong country\r\nMSG_WRONG_COUNTRY_ERROR=Country "{0}" does not exist\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong region\r\nMSG_WRONG_REGION_ERROR=Region "{0}" does not exist for country\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong employee\r\nMSG_WRONG_EMPLOYEE_ERROR=Employee "{0}" does not exist.\r\n\r\n# XMSG: message that will be displayed, if the user has entered invalid website url\r\nMSG_WRONG_URL_ERROR=Entered URL "{0}" is not valid.\r\n\r\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\r\nMSG_MANDATORY_FIELDS=Not all mandatory fields are filled\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA=Data has been changed by another user. Do you want to overwrite the other user\'s changes with your own?\r\n\r\n# XMSG: message that will be displayed in case of conflicts during file renaming\r\nMSG_CONFLICTING_FILE_NAME=The file name has been changed by another user. Do you want to overwrite the other user\'s changes with your own?\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA_WITH_REFRESH=Data has been changed by another user. These changes will now appear in the app.\r\n\r\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\r\nMSG_NOT_IN_MAIN_CONTACT=You can only view the details of contacts that are assigned to this account\r\n\r\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\r\nMSG_EXCEEDING_FILE_NAME_LENGTH=Your file name can have a maximum of 40 characters.\r\n\r\n# XTOL, 20: tooltip shown on search result list for button to add an account"\r\nADD_ACCOUNT_TOOLTIP=Add Account\r\n\r\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\r\nADD_MARKETING_ATTRIBUTE_TOOLTIP=Add Marketing Attribute\r\n\r\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\r\nADD_CONTACT_TOOLTIP=Add Contact\r\n\r\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\r\nADD_APPOINTMENT_TOOLTIP=Add Appointment\r\n\r\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\r\nADD_TASK_TOOLTIP=Add Task\r\n\r\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\r\nADD_OPPORTUNITY_TOOLTIP=Add Opportunity\r\n',
		"cus/crm/myaccounts/i18n/i18n_en_US_sappsd.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XFLD, 30: Facet title for general Data\r\nGENERAL_DATA=[[[\\u0122\\u0113\\u014B\\u0113\\u0157\\u0105\\u013A \\u012C\\u014B\\u0192\\u014F\\u0157\\u0271\\u0105\\u0163\\u012F\\u014F\\u014B\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT, 40: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=[[[\\u039C\\u0177 \\u0100\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT, 40: this is the title for the detail screen\r\nDETAIL_TITLE=[[[\\u0100\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\r\nREVENUE_CURRENT=[[[\\u0158\\u0113\\u028B\\u0113\\u014B\\u0171\\u0113 \\u0176\\u0162\\u010E\\u2219]]]\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\r\nREVENUE_CURRENT_TOOLTIP=[[[\\u0158\\u0113\\u028B\\u0113\\u014B\\u0171\\u0113 \\u0163\\u014F \\u018C\\u0105\\u0163\\u0113 \\u010B\\u0171\\u0157\\u0157\\u0113\\u014B\\u0163 \\u0177\\u0113\\u0105\\u0157\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\r\nREVENUE_LAST=[[[\\!\\!\\!\\u0158\\u0113\\u028B\\u0113\\u014B\\u0171\\u0113 \\u013B\\u0105\\u015F\\u0163 \\u0176\\u0113\\u0105\\u0157]]]\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\r\nREVENUE_LAST_TOOLTIP=[[[\\u0158\\u0113\\u028B\\u0113\\u014B\\u0171\\u0113 \\u0163\\u014F \\u013A\\u0105\\u015F\\u0163 \\u0177\\u0113\\u0105\\u0157\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XFLD, 30: Facet title for opportunities and label in facet general data\r\nOPPORTUNITIES=[[[\\u014E\\u03C1\\u03C1\\u014F\\u0157\\u0163\\u0171\\u014B\\u012F\\u0163\\u012F\\u0113\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD, 30: Facet title for leads\r\nLEADS=[[[\\u013B\\u0113\\u0105\\u018C\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD, 30: Facet title for tasks\r\nTASKS=[[[\\u0162\\u0105\\u015F\\u0137\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD, 30: Facet title for appointments\r\nAPPOINTMENTS=[[[\\u0100\\u03C1\\u03C1\\u014F\\u012F\\u014B\\u0163\\u0271\\u0113\\u014B\\u0163\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD, 30: Facet title for quotations\r\nQUOTATIONS=[[[\\u01EC\\u0171\\u014F\\u0163\\u0105\\u0163\\u012F\\u014F\\u014B\\u015F\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD, 30: Facet title for sales orders\r\nSALES_ORDERS=[[[\\u015C\\u0105\\u013A\\u0113\\u015F \\u014E\\u0157\\u018C\\u0113\\u0157\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD, 30: W7: Facet title for marketing attributes\r\nMARKETINGATTRIBUTES=[[[\\u039C\\u0105\\u0157\\u0137\\u0113\\u0163\\u012F\\u014B\\u011F \\u0100\\u0163\\u0163\\u0157\\u012F\\u0183\\u0171\\u0163\\u0113\\u015F\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD, 30: W6: Title for popup with products\r\nPRODUCTS=[[[\\u01A4\\u0157\\u014F\\u018C\\u0171\\u010B\\u0163\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\r\nEMPLOYEE_RESPONSIBLE=[[[\\u0114\\u0271\\u03C1\\u013A\\u014F\\u0177\\u0113\\u0113 \\u0158\\u0113\\u015F\\u03C1\\u014F\\u014B\\u015F\\u012F\\u0183\\u013A\\u0113\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD, 30: Facet title for Attachments\r\nATTACHMENTS=[[[\\u0100\\u0163\\u0163\\u0105\\u010B\\u0125\\u0271\\u0113\\u014B\\u0163\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD, 30: Facet title for Notes\r\nNOTES=[[[\\u0143\\u014F\\u0163\\u0113\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\r\nNEW_NOTE=[[[\\u0143\\u0113\\u0175 \\u0143\\u014F\\u0163\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD, 30: Facet title for Contacts\r\nCONTACTS=[[[\\u0108\\u014F\\u014B\\u0163\\u0105\\u010B\\u0163\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD, 30: Label for Address in facet general data\r\nADDRESS=[[[\\u0100\\u018C\\u018C\\u0157\\u0113\\u015F\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD, 30: Label for Opportunities in facet general data\r\nUNWEIGHTED_OPPORTUNITIES=[[[\\u014E\\u03C1\\u03C1\\u014F\\u0157\\u0163\\u0171\\u014B\\u012F\\u0163\\u012F\\u0113\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD, 30: Label for Rating in facet general data\r\nRATING=[[[\\u0158\\u0105\\u0163\\u012F\\u014B\\u011F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XFLD, 30: Label for Next contact in facet Appointments\r\nNEXT_APPOINTMENT=[[[\\u0143\\u0113\\u03C7\\u0163 \\u0100\\u03C1\\u03C1\\u014F\\u012F\\u014B\\u0163\\u0271\\u0113\\u014B\\u0163\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\r\nLAST_APPOINTMENT=[[[\\u013B\\u0105\\u015F\\u0163 \\u0100\\u03C1\\u03C1\\u014F\\u012F\\u014B\\u0163\\u0271\\u0113\\u014B\\u0163\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\r\nIMAGE=[[[\\!\\!\\!\\u012C\\u0271\\u0105\\u011F\\u0113]]]\r\n\r\n#XBUT, 20: Button to show the create actionsheet\r\nCREATE=[[[\\u0108\\u0157\\u0113\\u0105\\u0163\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\r\nDISCUSS_ENTRY=[[[\\u010E\\u012F\\u015F\\u010B\\u0171\\u015F\\u015F \\u012F\\u014B \\u015C\\u0100\\u01A4 \\u0134\\u0105\\u0271\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\r\nSHARE_ENTRY=[[[\\u015C\\u0125\\u0105\\u0157\\u0113 \\u014F\\u014B \\u015C\\u0100\\u01A4 \\u0134\\u0105\\u0271\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XBUT, 20: Button to share the note\r\nDETAIL_BUTTON_SHARE=[[[\\u015C\\u0125\\u0105\\u0157\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XBUT, 20: Button to cancel sharing\r\nDETAIL_BUTTON_CANCEL=[[[\\u0108\\u0105\\u014B\\u010B\\u0113\\u013A\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,20: All accounts for filter\r\nALL_ACCOUNTS=[[[\\u0100\\u013A\\u013A \\u0100\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,35: All individual accounts for filter\r\nALL_INDIVIDUAL_ACCOUNTS=[[[\\u0100\\u013A\\u013A \\u012C\\u014B\\u018C\\u012F\\u028B\\u012F\\u018C\\u0171\\u0105\\u013A \\u0100\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,35: All corporate accounts for filter\r\nALL_CORPORATE_ACCOUNTS=[[[\\u0100\\u013A\\u013A \\u0108\\u014F\\u0157\\u03C1\\u014F\\u0157\\u0105\\u0163\\u0113 \\u0100\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,35: All group accounts for filter\r\nALL_ACCOUNT_GROUPS=[[[\\u0100\\u013A\\u013A \\u0100\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163 \\u0122\\u0157\\u014F\\u0171\\u03C1\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,20: my account for filter\r\nMY_ACCOUNT=[[[\\u039C\\u0177 \\u0100\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,35: my individual accounts for filter\r\nMY_INDIVIDUAL_ACCOUNTS=[[[\\u039C\\u0177 \\u012C\\u014B\\u018C\\u012F\\u028B\\u012F\\u018C\\u0171\\u0105\\u013A \\u0100\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,35: my corporate accounts for filter\r\nMY_CORPORATE_ACCOUNTS=[[[\\u039C\\u0177 \\u0108\\u014F\\u0157\\u03C1\\u014F\\u0157\\u0105\\u0163\\u0113 \\u0100\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,35: my group accounts for filter\r\nMY_ACCOUNT_GROUPS=[[[\\u039C\\u0177 \\u0100\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163 \\u0122\\u0157\\u014F\\u0171\\u03C1\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nINDIVIDUAL_ACCOUNT=[[[\\u012C\\u014B\\u018C\\u012F\\u028B\\u012F\\u018C\\u0171\\u0105\\u013A \\u0100\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nCORPORATE_ACCOUNT=[[[\\u0108\\u014F\\u0157\\u03C1\\u014F\\u0157\\u0105\\u0163\\u0113 \\u0100\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nACCOUNT_GROUP=[[[\\u0100\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163 \\u0122\\u0157\\u014F\\u0171\\u03C1\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\r\nSTARTING=[[[\\u015C\\u0163\\u0105\\u0157\\u0163\\u012F\\u014B\\u011F {0}]]]\r\n\r\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\r\nCLOSING=[[[\\u0108\\u013A\\u014F\\u015F\\u012F\\u014B\\u011F {0}]]]\r\n\r\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\r\nDUE=[[[\\u010E\\u0171\\u0113 {0}]]]\r\n\r\n#XFLD,20: All accounts for title\r\nALL_ACCOUNTS_TITLE=[[[\\u0100\\u013A\\u013A \\u0100\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163\\u015F ({0})]]]\r\n\r\n#XFLD,35: All individual accounts for title\r\nALL_INDIVIDUAL_ACCOUNTS_TITLE=[[[\\u0100\\u013A\\u013A \\u012C\\u014B\\u018C\\u012F\\u028B\\u012F\\u018C\\u0171\\u0105\\u013A \\u0100\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163\\u015F ({0})]]]\r\n\r\n#XFLD,35: All corporate accounts for title\r\nALL_CORPORATE_ACCOUNTS_TITLE=[[[\\u0100\\u013A\\u013A \\u0108\\u014F\\u0157\\u03C1\\u014F\\u0157\\u0105\\u0163\\u0113 \\u0100\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163\\u015F ({0})]]]\r\n\r\n#XFLD,35: All group accounts for title\r\nALL_ACCOUNT_GROUPS_TITLE=[[[\\u0100\\u013A\\u013A \\u0100\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163 \\u0122\\u0157\\u014F\\u0171\\u03C1\\u015F ({0})]]]\r\n\r\n#XFLD,20: my account for title\r\nMY_ACCOUNT_TITLE=[[[\\u039C\\u0177 \\u0100\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163\\u015F ({0})]]]\r\n\r\n#XFLD,35: my individual account for title\r\nMY_INDIVIDUAL_ACCOUNT_TITLE=[[[\\u039C\\u0177 \\u012C\\u014B\\u018C\\u012F\\u028B\\u012F\\u018C\\u0171\\u0105\\u013A \\u0100\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163\\u015F ({0})]]]\r\n\r\n#XFLD,35: my corporate account for title.\r\nMY_CORPORATE_ACCOUNT_TITLE=[[[\\u039C\\u0177 \\u0108\\u014F\\u0157\\u03C1\\u014F\\u0157\\u0105\\u0163\\u0113 \\u0100\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163\\u015F ({0})]]]\r\n\r\n#XFLD,35: my group account for title\r\nMY_ACCOUNT_GROUP_TITLE=[[[\\u039C\\u0177 \\u0100\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163 \\u0122\\u0157\\u014F\\u0171\\u03C1\\u015F ({0})]]]\r\n\r\n#XFLD,30: filtered by info\r\nFILTERED_BY=[[[\\u0191\\u012F\\u013A\\u0163\\u0113\\u0157\\u0113\\u018C \\u0181\\u0177\\: {0}]]]\r\n\r\n#XFLD,30: label, search for accounts\r\nSEARCH_ACCOUNTS=[[[\\u015C\\u0113\\u0105\\u0157\\u010B\\u0125\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,30: comma separator for location\r\nLOCATION=[[[{0}, {1}]]]\r\n\r\n#XFLD: W4: Label for All day text in Appointments\r\nALL_DAY_EVENT=[[[\\u0100\\u013A\\u013A \\u010E\\u0105\\u0177\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\r\nDURATION_MINUTE=[[[{0} \\u0271\\u012F\\u014B]]]\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\r\nDURATION_HOUR=[[[{0} \\u0125]]]\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\r\nDURATION_DAY=[[[{0} \\u018C\\u0105\\u0177]]]\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\r\nDURATION_DAYS=[[[{0} \\u018C\\u0105\\u0177\\u015F]]]\r\n\r\n#XFLD: W4: Label for Private meeting\r\nPRIVATE=[[[\\u01A4\\u0157\\u012F\\u028B\\u0105\\u0163\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\r\nSELECT_TRANSACTION_TYPE=[[[\\u015C\\u0113\\u013A\\u0113\\u010B\\u0163 \\u0162\\u0157\\u0105\\u014B\\u015F\\u0105\\u010B\\u0163\\u012F\\u014F\\u014B \\u0162\\u0177\\u03C1\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\r\nNEW_TASK_INPUT_PLACEHOLDER=[[[\\u0143\\u0113\\u0175 \\u0162\\u0105\\u015F\\u0137\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nNO_DATA_TEXT=[[[\\u0143\\u014F \\u010E\\u0105\\u0163\\u0105\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nLOADING_TEXT=[[[\\u013B\\u014F\\u0105\\u018C\\u012F\\u014B\\u011F...\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,25: W4: Column label for name of contact person in contacts\r\nNAME=[[[\\u0143\\u0105\\u0271\\u0113]]]\r\n\r\n#XFLD,25: W5: Column label for department of contact person in contacts\r\nDEPARTMENT=[[[\\u010E\\u0113\\u03C1\\u0105\\u0157\\u0163\\u0271\\u0113\\u014B\\u0163\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,15: W6: Column label for actions of contact person in contacts\r\nACTIONS=[[[\\u0100\\u010B\\u0163\\u012F\\u014F\\u014B\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,25: W4: Column label for description of lead in Leads\r\nDESCRIPTION=[[[\\u010E\\u0113\\u015F\\u010B\\u0157\\u012F\\u03C1\\u0163\\u012F\\u014F\\u014B\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\r\nASSIGNED_TO=[[[\\u0100\\u015F\\u015F\\u012F\\u011F\\u014B\\u0113\\u018C \\u0162\\u014F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,15: W4: Column label for end date of lead in Leads\r\nEND_DATE=[[[\\u0114\\u014B\\u018C \\u010E\\u0105\\u0163\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,15: W4: Column label for qualification level of lead in Leads\r\nQUALIFICATION=[[[\\!\\!\\!\\u01EC\\u0171\\u0105\\u013A\\u012F\\u0192\\u012F\\u010B\\u0105\\u0163\\u012F\\u014F\\u014B]]]\r\n\r\n#XFLD,15: W4: Column label for status of lead in Leads\r\nSTATUS=[[[\\u015C\\u0163\\u0105\\u0163\\u0171\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\r\nMAIN_CONTACT=[[[\\u039C\\u0105\\u012F\\u014B \\u0108\\u014F\\u014B\\u0163\\u0105\\u010B\\u0163\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\r\nVOLUME=[[[\\u01B2\\u014F\\u013A\\u0171\\u0271\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\r\nPROBABILITY=[[[\\u01A4\\u0157\\u014F\\u0183\\u0105\\u0183\\u012F\\u013A\\u012F\\u0163\\u0177\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\r\nCLOSE_BY=[[[\\u0108\\u013A\\u014F\\u015F\\u0113 \\u0181\\u0177\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \r\nVIEWS=[[[\\u01B2\\u012F\\u0113\\u0175\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\r\nCONTACT_TITLE=[[[\\u0108\\u014F\\u014B\\u0163\\u0105\\u010B\\u0163\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\r\nEMPLOYEE_TITLE=[[[\\u0114\\u0271\\u03C1\\u013A\\u014F\\u0177\\u0113\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT,20: W7: Title of pop-up used in confirm popup\r\nCONFIRM_TITLE=[[[\\u0108\\u014F\\u014B\\u0192\\u012F\\u0157\\u0271\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\r\nCOMPANY_NAME=[[[\\u0143\\u0105\\u0271\\u0113]]]\r\n\r\n#XFLD,20: W4: Label for name 1 of a company used general data\r\nCOMPANY_NAME1=[[[\\u0143\\u0105\\u0271\\u0113 1\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,20: W4: Label for name 2 of a company used general data\r\nCOMPANY_NAME2=[[[\\u0143\\u0105\\u0271\\u0113 2\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,20: W4: Label for first name of a person used general data\r\nFIRST_NAME=[[[\\u0191\\u012F\\u0157\\u015F\\u0163 \\u0143\\u0105\\u0271\\u0113\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,20: W4: Label for last name of a person used general data\r\nLAST_NAME=[[[\\u013B\\u0105\\u015F\\u0163 \\u0143\\u0105\\u0271\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nBIRTHDAY=[[[\\u0181\\u012F\\u0157\\u0163\\u0125\\u018C\\u0105\\u0177\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nTITLE=[[[\\u0162\\u012F\\u0163\\u013A\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nACADEMIC_TITLE=[[[\\u0100\\u010B\\u0105\\u018C\\u0113\\u0271\\u012F\\u010B \\u0162\\u012F\\u0163\\u013A\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,20: W4: Label for mobile phone number used general data\r\nMOBILE=[[[\\u039C\\u014F\\u0183\\u012F\\u013A\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,20: W4: Label for phone number used general data\r\nPHONE=[[[\\u01A4\\u0125\\u014F\\u014B\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,20: W4: Label for e-mail used general data\r\nEMAIL=[[[\\u0114-\\u039C\\u0105\\u012F\\u013A\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,20: W4: Label for web site used general data\r\nWEBSITE=[[[\\u0174\\u0113\\u0183 \\u015C\\u012F\\u0163\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,20: W4: Label for country used general data\r\nCOUNTRY=[[[\\u0108\\u014F\\u0171\\u014B\\u0163\\u0157\\u0177\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,20: W4: Label for region used general data\r\nREGION=[[[\\u0158\\u0113\\u011F\\u012F\\u014F\\u014B\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,20: W4: Label for city used general data\r\nCITY=[[[\\u0108\\u012F\\u0163\\u0177]]]\r\n\r\n#XFLD,20: W4: Label for postal code used general data\r\nPOSTAL_CODE=[[[\\u01A4\\u014F\\u015F\\u0163\\u0105\\u013A \\u0108\\u014F\\u018C\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,20: W4: Label for street used general data\r\nSTREET=[[[\\u015C\\u0163\\u0157\\u0113\\u0113\\u0163\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,10: W4: Label for house number used general data\r\nHOUSE_NUMBER=[[[\\!\\!\\!\\u0124\\u014F\\u0171\\u015F\\u0113 \\u0143\\u014F.]]]\r\n\r\n#XFLD,15: W6: Label for ID used in Quotations\r\nID=[[[\\u012C\\u010E\\u2219\\u2219]]]\r\n\r\n#XFLD,15: W6: Label for Amount used in Quotations\r\nAMOUNT=[[[\\u0100\\u0271\\u014F\\u0171\\u014B\\u0163\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,20: W6: Label for Expiration Date used in Quotations\r\nEXPIRATION_DATE=[[[\\!\\!\\!\\u0114\\u03C7\\u03C1\\u012F\\u0157\\u0105\\u0163\\u012F\\u014F\\u014B \\u010E\\u0105\\u0163\\u0113]]]\r\n\r\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\r\nDELIVERY_DATE=[[[\\u010E\\u0113\\u013A\\u012F\\u028B\\u0113\\u0157\\u0177 \\u010E\\u0105\\u0163\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\r\nSALES_EMPLOYEE=[[[\\u015C\\u0105\\u013A\\u0113\\u015F \\u0114\\u0271\\u03C1\\u013A\\u014F\\u0177\\u0113\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\r\nATTRIBUTESET=[[[\\u0100\\u0163\\u0163\\u0157\\u012F\\u0183\\u0171\\u0163\\u0113 \\u015C\\u0113\\u0163\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\r\nATTRIBUTE=[[[\\u0100\\u0163\\u0163\\u0157\\u012F\\u0183\\u0171\\u0163\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\r\nVALUE=[[[\\u01B2\\u0105\\u013A\\u0171\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XBUT, 20: Button to create an Account\r\nBUTTON_ADD=[[[\\u0100\\u018C\\u018C\\u2219]]]\r\n\r\n#XBUT, 20: Button to edit an Account\r\nBUTTON_EDIT=[[[\\u0114\\u018C\\u012F\\u0163]]]\r\n\r\n#XBUT, 20: Button to save changes\r\nBUTTON_SAVE=[[[\\u015C\\u0105\\u028B\\u0113]]]\r\n\r\n#XBUT, 20: Button to cancel changes\r\nBUTTON_CANCEL=[[[\\u0108\\u0105\\u014B\\u010B\\u0113\\u013A\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XBUT, 30: Button which shows the personalization buttons\r\nBUTTON_SHOW_PERSONALIZATION=[[[\\u015C\\u0125\\u014F\\u0175 \\u01A4\\u0113\\u0157\\u015F\\u014F\\u014B\\u0105\\u013A\\u012F\\u017E\\u0105\\u0163\\u012F\\u014F\\u014B\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XBUT, 30: Button which hides the personalization buttons\r\nBUTTON_HIDE_PERSONALIZATION=[[[\\u0124\\u012F\\u018C\\u0113 \\u01A4\\u0113\\u0157\\u015F\\u014F\\u014B\\u0105\\u013A\\u012F\\u017E\\u0105\\u0163\\u012F\\u014F\\u014B\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_CONFIRM_CANCEL=[[[\\u013B\\u0113\\u0105\\u028B\\u0113 \\u0163\\u0125\\u012F\\u015F \\u03C1\\u0105\\u011F\\u0113 \\u0175\\u012F\\u0163\\u0125\\u014F\\u0171\\u0163 \\u015F\\u0105\\u028B\\u012F\\u014B\\u011F \\u0163\\u0125\\u0113 \\u010B\\u0125\\u0105\\u014B\\u011F\\u0113\\u015F \\u0177\\u014F\\u0171 \\u0271\\u0105\\u0177 \\u0125\\u0105\\u028B\\u0113 \\u0271\\u0105\\u018C\\u0113?\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\r\nMSG_CONFIRM_DELETE_CONTACT=[[[\\u0162\\u0125\\u0113 \\u010B\\u014F\\u014B\\u0163\\u0105\\u010B\\u0163 \\u0175\\u012F\\u013A\\u013A \\u0183\\u0113 \\u0171\\u014B\\u0105\\u015F\\u015F\\u012F\\u011F\\u014B\\u0113\\u018C \\u0192\\u0157\\u014F\\u0271 \\u0163\\u0125\\u0113 \\u0105\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163. \\u010E\\u014F \\u0177\\u014F\\u0171 \\u0175\\u0105\\u014B\\u0163 \\u0163\\u014F \\u010B\\u014F\\u014B\\u0163\\u012F\\u014B\\u0171\\u0113?\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_SUCCESS=[[[\\u0100\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163 \\u0171\\u03C1\\u018C\\u0105\\u0163\\u0113\\u018C.\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_ERROR=[[[\\u016E\\u03C1\\u018C\\u0105\\u0163\\u0113 \\u0192\\u0105\\u012F\\u013A\\u0113\\u018C\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XMSG : Account update succeeded\r\nMSG_CREATION_SUCCESS=[[[\\u0100\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163 \\u010B\\u0157\\u0113\\u0105\\u0163\\u0113\\u018C\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XMSG : Task creation succeeded\r\nMSG_TASK_CREATION_SUCCESS=[[[\\u0162\\u0105\\u015F\\u0137 \\u010B\\u0157\\u0113\\u0105\\u0163\\u0113\\u018C\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XMSG : Contact creation failed\r\nMSG_CREATION_ERROR=[[[\\u0108\\u0157\\u0113\\u0105\\u0163\\u012F\\u014F\\u014B \\u0192\\u0105\\u012F\\u013A\\u0113\\u018C\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong country\r\nMSG_WRONG_COUNTRY_ERROR=[[[\\u0108\\u014F\\u0171\\u014B\\u0163\\u0157\\u0177 "{0}" \\u018C\\u014F\\u0113\\u015F \\u014B\\u014F\\u0163 \\u0113\\u03C7\\u012F\\u015F\\u0163.]]]\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong region\r\nMSG_WRONG_REGION_ERROR=[[[\\u0158\\u0113\\u011F\\u012F\\u014F\\u014B "{0}" \\u018C\\u014F\\u0113\\u015F \\u014B\\u014F\\u0163 \\u0113\\u03C7\\u012F\\u015F\\u0163 \\u0192\\u014F\\u0157 \\u0163\\u0125\\u0113 \\u011F\\u012F\\u028B\\u0113\\u014B \\u010B\\u014F\\u0171\\u014B\\u0163\\u0157\\u0177.]]]\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong employee\r\nMSG_WRONG_EMPLOYEE_ERROR=[[[\\u0114\\u0271\\u03C1\\u013A\\u014F\\u0177\\u0113\\u0113 "{0}" \\u018C\\u014F\\u0113\\u015F \\u014B\\u014F\\u0163 \\u0113\\u03C7\\u012F\\u015F\\u0163.]]]\r\n\r\n# XMSG: message that will be displayed, if the user has entered invalid website url\r\nMSG_WRONG_URL_ERROR=[[[\\u0114\\u014B\\u0163\\u0113\\u0157\\u0113\\u018C \\u016E\\u0158\\u013B "{0}" \\u012F\\u015F \\u014B\\u014F\\u0163 \\u028B\\u0105\\u013A\\u012F\\u018C.]]]\r\n\r\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\r\nMSG_MANDATORY_FIELDS=[[[\\u0143\\u014F\\u0163 \\u0105\\u013A\\u013A \\u0271\\u0105\\u014B\\u018C\\u0105\\u0163\\u014F\\u0157\\u0177 \\u0192\\u012F\\u0113\\u013A\\u018C\\u015F \\u0105\\u0157\\u0113 \\u0192\\u012F\\u013A\\u013A\\u0113\\u018C.\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA=[[[\\u010E\\u0105\\u0163\\u0105 \\u0125\\u0105\\u015F \\u0183\\u0113\\u0113\\u014B \\u010B\\u0125\\u0105\\u014B\\u011F\\u0113\\u018C \\u0183\\u0177 \\u0105\\u014B\\u014F\\u0163\\u0125\\u0113\\u0157 \\u0171\\u015F\\u0113\\u0157. \\u010E\\u014F \\u0177\\u014F\\u0171 \\u0175\\u0105\\u014B\\u0163 \\u0163\\u014F \\u014F\\u028B\\u0113\\u0157\\u0175\\u0157\\u012F\\u0163\\u0113 \\u0163\\u0125\\u0113 \\u014F\\u0163\\u0125\\u0113\\u0157 \\u0171\\u015F\\u0113\\u0157\'\\u015F \\u010B\\u0125\\u0105\\u014B\\u011F\\u0113\\u015F \\u0175\\u012F\\u0163\\u0125 \\u0177\\u014F\\u0171\\u0157 \\u014F\\u0175\\u014B?\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XMSG: message that will be displayed in case of conflicts during file renaming\r\nMSG_CONFLICTING_FILE_NAME=[[[\\u0162\\u0125\\u0113 \\u0192\\u012F\\u013A\\u0113 \\u014B\\u0105\\u0271\\u0113 \\u0125\\u0105\\u015F \\u0183\\u0113\\u0113\\u014B \\u010B\\u0125\\u0105\\u014B\\u011F\\u0113\\u018C \\u0183\\u0177 \\u0105\\u014B\\u014F\\u0163\\u0125\\u0113\\u0157 \\u0171\\u015F\\u0113\\u0157. \\u010E\\u014F \\u0177\\u014F\\u0171 \\u0175\\u0105\\u014B\\u0163 \\u0163\\u014F \\u014F\\u028B\\u0113\\u0157\\u0175\\u0157\\u012F\\u0163\\u0113 \\u0163\\u0125\\u0113 \\u014F\\u0163\\u0125\\u0113\\u0157 \\u0171\\u015F\\u0113\\u0157\'\\u015F \\u010B\\u0125\\u0105\\u014B\\u011F\\u0113\\u015F \\u0175\\u012F\\u0163\\u0125 \\u0177\\u014F\\u0171\\u0157 \\u014F\\u0175\\u014B?\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA_WITH_REFRESH=[[[\\u010E\\u0105\\u0163\\u0105 \\u0125\\u0105\\u015F \\u0183\\u0113\\u0113\\u014B \\u010B\\u0125\\u0105\\u014B\\u011F\\u0113\\u018C \\u0183\\u0177 \\u0105\\u014B\\u014F\\u0163\\u0125\\u0113\\u0157 \\u0171\\u015F\\u0113\\u0157. \\u010E\\u0105\\u0163\\u0105 \\u0175\\u012F\\u013A\\u013A \\u0183\\u0113 \\u0157\\u0113\\u0192\\u0157\\u0113\\u015F\\u0125\\u0113\\u018C.\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\r\nMSG_NOT_IN_MAIN_CONTACT=[[[\\u0176\\u014F\\u0171 \\u010B\\u0105\\u014B \\u014F\\u014B\\u013A\\u0177 \\u028B\\u012F\\u0113\\u0175 \\u0183\\u0171\\u015F\\u012F\\u014B\\u0113\\u015F\\u015F \\u010B\\u0105\\u0157\\u018C\\u015F \\u014F\\u0192 \\u010B\\u014F\\u014B\\u0163\\u0105\\u010B\\u0163\\u015F \\u0163\\u0125\\u0105\\u0163 \\u0125\\u0105\\u028B\\u0113 \\u0183\\u0113\\u0113\\u014B \\u0105\\u015F\\u015F\\u012F\\u011F\\u014B\\u0113\\u018C \\u0163\\u014F \\u0163\\u0125\\u012F\\u015F \\u0105\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\r\nMSG_EXCEEDING_FILE_NAME_LENGTH=[[[\\u0176\\u014F\\u0171\\u0157 \\u0192\\u012F\\u013A\\u0113 \\u014B\\u0105\\u0271\\u0113 \\u010B\\u0105\\u014B \\u0125\\u0105\\u028B\\u0113 \\u0105 \\u0271\\u0105\\u03C7\\u012F\\u0271\\u0171\\u0271 \\u014F\\u0192 40 \\u010B\\u0125\\u0105\\u0157\\u0105\\u010B\\u0163\\u0113\\u0157\\u015F.\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XTOL, 20: tooltip shown on search result list for button to add an account"\r\nADD_ACCOUNT_TOOLTIP=[[[\\u0100\\u018C\\u018C \\u0100\\u010B\\u010B\\u014F\\u0171\\u014B\\u0163\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\r\nADD_MARKETING_ATTRIBUTE_TOOLTIP=[[[\\u0100\\u018C\\u018C \\u039C\\u0105\\u0157\\u0137\\u0113\\u0163\\u012F\\u014B\\u011F \\u0100\\u0163\\u0163\\u0157\\u012F\\u0183\\u0171\\u0163\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\r\nADD_CONTACT_TOOLTIP=[[[\\u0100\\u018C\\u018C \\u0108\\u014F\\u014B\\u0163\\u0105\\u010B\\u0163\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\r\nADD_APPOINTMENT_TOOLTIP=[[[\\u0100\\u018C\\u018C \\u0100\\u03C1\\u03C1\\u014F\\u012F\\u014B\\u0163\\u0271\\u0113\\u014B\\u0163\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\r\nADD_TASK_TOOLTIP=[[[\\u0100\\u018C\\u018C \\u0162\\u0105\\u015F\\u0137\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\r\nADD_OPPORTUNITY_TOOLTIP=[[[\\u0100\\u018C\\u018C \\u014E\\u03C1\\u03C1\\u014F\\u0157\\u0163\\u0171\\u014B\\u012F\\u0163\\u0177\\u2219\\u2219\\u2219\\u2219]]]\r\n',
		"cus/crm/myaccounts/i18n/i18n_en_US_saptrc.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XFLD, 30: Facet title for general Data\r\nGENERAL_DATA=o1s2JNJQ54SwTJw8VYktOg_General Information\r\n\r\n#XTIT, 40: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=raMMwoe0U05Gax5C4S4KRA_My Accounts\r\n\r\n#XTIT, 40: this is the title for the detail screen\r\nDETAIL_TITLE=geCCXv1WyUERK7c5K7qArQ_Account\r\n\r\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\r\nREVENUE_CURRENT=k2YyuJfz/MbYnunZ/ie/CA_Revenue YTD\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\r\nREVENUE_CURRENT_TOOLTIP=iGse+H+EAxCZXm9Tz8krEA_Revenue to date current year\r\n\r\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\r\nREVENUE_LAST=1eRAMcXp9keY4ncvrmTfIg_Revenue Last Year\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\r\nREVENUE_LAST_TOOLTIP=NSOBnaduOcNpkvpB5tZwoA_Revenue to last year\r\n\r\n# XFLD, 30: Facet title for opportunities and label in facet general data\r\nOPPORTUNITIES=GXbNjB/zkYf3aRxRooxW1w_Opportunities\r\n\r\n#XFLD, 30: Facet title for leads\r\nLEADS=OTH7Hfvp2gRBXtuOQCrzOQ_Leads\r\n\r\n#XFLD, 30: Facet title for tasks\r\nTASKS=CYViBnlQf+NlOgUSkdxNPQ_Tasks\r\n\r\n#XFLD, 30: Facet title for appointments\r\nAPPOINTMENTS=Hhy0HkYB2JAXn9t20hlgMQ_Appointments\r\n\r\n#XFLD, 30: Facet title for quotations\r\nQUOTATIONS=cqqs8R+OOVzpzq3QWmu6Bg_Quotations\r\n\r\n#XFLD, 30: Facet title for sales orders\r\nSALES_ORDERS=eFVZK1kbHtW5jRXvVlp4Dg_Sales Orders\r\n\r\n#XFLD, 30: W7: Facet title for marketing attributes\r\nMARKETINGATTRIBUTES=wQ2JhtMbMJb4Qtv8HS+2wQ_Marketing Attributes\r\n\r\n#XFLD, 30: W6: Title for popup with products\r\nPRODUCTS=Ac1SclUr5vE38GJsGrpp7A_Products\r\n\r\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\r\nEMPLOYEE_RESPONSIBLE=R6LrlS5vLdm5TOCuaTZI/w_Employee Responsible\r\n\r\n#XFLD, 30: Facet title for Attachments\r\nATTACHMENTS=h3Kq6fq2wl0r4xwSpQ9s9g_Attachments\r\n\r\n#XFLD, 30: Facet title for Notes\r\nNOTES=YJEpjbfi1itt123DurKapA_Notes\r\n\r\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\r\nNEW_NOTE=sLXLZnHcx+3f2LCWTDW8uA_New Note\r\n\r\n#XFLD, 30: Facet title for Contacts\r\nCONTACTS=/3FpLsjR7pomnRbQldWyXg_Contacts\r\n\r\n#XFLD, 30: Label for Address in facet general data\r\nADDRESS=iMgg8PDXsKV7e6jPSPRn6Q_Address\r\n\r\n#XFLD, 30: Label for Opportunities in facet general data\r\nUNWEIGHTED_OPPORTUNITIES=uhvHQ/ITcU1XCXAZVHLdpA_Opportunities\r\n\r\n#XFLD, 30: Label for Rating in facet general data\r\nRATING=DRFdOpqCpbMAmIp16zKmUg_Rating\r\n\r\n# XFLD, 30: Label for Next contact in facet Appointments\r\nNEXT_APPOINTMENT=NfblvLBNTWkwK0WknwkUOg_Next Appointment\r\n\r\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\r\nLAST_APPOINTMENT=Px9RYx2HM1GutoNCR/UZvg_Last Appointment\r\n\r\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\r\nIMAGE=gAL4gzaWr5W6bPZ0FJwXsA_Image\r\n\r\n#XBUT, 20: Button to show the create actionsheet\r\nCREATE=jTXR83bEP3NYOT7EbUlGdQ_Create\r\n\r\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\r\nDISCUSS_ENTRY=Z1ILu3wctalBOpIm/B3o/A_Discuss in SAP Jam\r\n\r\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\r\nSHARE_ENTRY=iZyX6TxzLxlGmTHW74VNBA_Share on SAP Jam\r\n\r\n#XBUT, 20: Button to share the note\r\nDETAIL_BUTTON_SHARE=apJfOLVAMwjICUeSWLrcAw_Share\r\n\r\n#XBUT, 20: Button to cancel sharing\r\nDETAIL_BUTTON_CANCEL=X6T5myzA/mz2In6OrttQpQ_Cancel\r\n\r\n#XFLD,20: All accounts for filter\r\nALL_ACCOUNTS=XLtt9JR+S7RDD3/4NuWtjw_All Accounts\r\n\r\n#XFLD,35: All individual accounts for filter\r\nALL_INDIVIDUAL_ACCOUNTS=VUL6yO3BTzy9SF+xOydUkg_All Individual Accounts\r\n\r\n#XFLD,35: All corporate accounts for filter\r\nALL_CORPORATE_ACCOUNTS=Hume8s/Y4c44+7fpYozEaQ_All Corporate Accounts\r\n\r\n#XFLD,35: All group accounts for filter\r\nALL_ACCOUNT_GROUPS=RGiNFqm6HGHx1hU5uVlhwQ_All Account Groups\r\n\r\n#XFLD,20: my account for filter\r\nMY_ACCOUNT=YSPKDUFoKsyg3oYeL3rE/Q_My Accounts\r\n\r\n#XFLD,35: my individual accounts for filter\r\nMY_INDIVIDUAL_ACCOUNTS=P5GB7p7jN1SFfbJ9vkewuw_My Individual Accounts\r\n\r\n#XFLD,35: my corporate accounts for filter\r\nMY_CORPORATE_ACCOUNTS=3qOES1xpvc2qUUNp6oUwAA_My Corporate Accounts\r\n\r\n#XFLD,35: my group accounts for filter\r\nMY_ACCOUNT_GROUPS=+/9sLOpndKVAjQNjWOfIww_My Account Groups\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nINDIVIDUAL_ACCOUNT=ziuxDS0gQeHqZEpO6R6jow_Individual Account\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nCORPORATE_ACCOUNT=OLulWtRBsXuW2PuFVWn61g_Corporate Account\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nACCOUNT_GROUP=t+CG7y6axeXa1d5rglHafw_Account Group\r\n\r\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\r\nSTARTING=6Twrva4eeB9IfZSa+FWLwA_Starting {0}\r\n\r\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\r\nCLOSING=a4n7uEcIhfWZJhTobniDig_Closing {0}\r\n\r\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\r\nDUE=oAypZo8ctJPZ0dD5UM7iSA_Due {0}\r\n\r\n#XFLD,20: All accounts for title\r\nALL_ACCOUNTS_TITLE=njLJBWBQHtT+LS6Lqp+kUg_All Accounts ({0})\r\n\r\n#XFLD,35: All individual accounts for title\r\nALL_INDIVIDUAL_ACCOUNTS_TITLE=3pMQLffZcHUgFrAbidY4sg_All Individual Accounts ({0})\r\n\r\n#XFLD,35: All corporate accounts for title\r\nALL_CORPORATE_ACCOUNTS_TITLE=U6nksoKWhbmeFnAEdufOtw_All Corporate Accounts ({0})\r\n\r\n#XFLD,35: All group accounts for title\r\nALL_ACCOUNT_GROUPS_TITLE=njXWaoDXnuSpRfM/NTJJqw_All Account Groups ({0})\r\n\r\n#XFLD,20: my account for title\r\nMY_ACCOUNT_TITLE=54Wlleq3eZf2kWprDEZtYA_My Accounts ({0})\r\n\r\n#XFLD,35: my individual account for title\r\nMY_INDIVIDUAL_ACCOUNT_TITLE=igXFwcHXA+rnCnS3qSo+7g_My Individual Accounts ({0})\r\n\r\n#XFLD,35: my corporate account for title.\r\nMY_CORPORATE_ACCOUNT_TITLE=WM5doSsrr1jWVtTOq+x4wg_My Corporate Accounts ({0})\r\n\r\n#XFLD,35: my group account for title\r\nMY_ACCOUNT_GROUP_TITLE=8+3hvFTOqm1FwBW4FV88qA_My Account Groups ({0})\r\n\r\n#XFLD,30: filtered by info\r\nFILTERED_BY=LB+A/+NxyYNMtwBK4EXakw_Filtered By\\: {0}\r\n\r\n#XFLD,30: label, search for accounts\r\nSEARCH_ACCOUNTS=wTaPxEpjR2UWuKHIit41EA_Search\r\n\r\n#XFLD,30: comma separator for location\r\nLOCATION=QYO/nFxc996k5MzaJ9/u1A_{0}, {1}\r\n\r\n#XFLD: W4: Label for All day text in Appointments\r\nALL_DAY_EVENT=eAJ9VqtNsRHLSFnadY+HBw_All Day\r\n\r\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\r\nDURATION_MINUTE=lmnCpHP4ZFp9SikUix6yHQ_{0} min\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\r\nDURATION_HOUR=ANzEWHv3gw6GKP5xsh287A_{0} h\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\r\nDURATION_DAY=rCYXExQ10FxGyrf0mixWtg_{0} day\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\r\nDURATION_DAYS=Wu+9Q3ZOWBQLUoY6VysFNg_{0} days\r\n\r\n#XFLD: W4: Label for Private meeting\r\nPRIVATE=GhhGGdy829mJjmMov45YWg_Private\r\n\r\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\r\nSELECT_TRANSACTION_TYPE=y+pJCKFAXarFKFUbUWHWKQ_Select Transaction Type\r\n\r\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\r\nNEW_TASK_INPUT_PLACEHOLDER=FsrnNXcjtqpcdK4qyrpWGQ_New Task\r\n\r\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nNO_DATA_TEXT=QexTuVUNRhZ7U1XUHz1ELw_No Data\r\n\r\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nLOADING_TEXT=ZjZCQYk/lSw93k8gPot01A_Loading...\r\n\r\n#XFLD,25: W4: Column label for name of contact person in contacts\r\nNAME=ihjkI6IHm2dKp03SI+vvsQ_Name\r\n\r\n#XFLD,25: W5: Column label for department of contact person in contacts\r\nDEPARTMENT=olRuUPCymMvf4Fa/gfps2Q_Department\r\n\r\n#XFLD,15: W6: Column label for actions of contact person in contacts\r\nACTIONS=bL1P259Xy9GchsJnaDQm3g_Actions\r\n\r\n#XFLD,25: W4: Column label for description of lead in Leads\r\nDESCRIPTION=GVKTiLQSMkNvDN301AhyuQ_Description\r\n\r\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\r\nASSIGNED_TO=MSqO1ZZrRRiN7WkjTd5JHA_Assigned To\r\n\r\n#XFLD,15: W4: Column label for end date of lead in Leads\r\nEND_DATE=NoajQE1vm93KsqekrtpB8Q_End Date\r\n\r\n#XFLD,15: W4: Column label for qualification level of lead in Leads\r\nQUALIFICATION=CgMf989g8KKOeNCSRpqK5Q_Qualification\r\n\r\n#XFLD,15: W4: Column label for status of lead in Leads\r\nSTATUS=xhw2L1u3pnvqTDCkJrQ8/w_Status\r\n\r\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\r\nMAIN_CONTACT=Br0GXpnFkouA3o8EcYpgqw_Main Contact\r\n\r\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\r\nVOLUME=D/Os+vtxEyu8wl+anA4L1g_Volume\r\n\r\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\r\nPROBABILITY=oM8eb0MmRqJoJteVN/WkSA_Probability\r\n\r\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\r\nCLOSE_BY=X7GcDowdhOc/5t/JPPlpLQ_Close By\r\n\r\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \r\nVIEWS=LeeIYDnkmVM6F37bWrkt5g_Views\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\r\nCONTACT_TITLE=/2aZzT9FQW2ht8bKHT18QQ_Contact\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\r\nEMPLOYEE_TITLE=YXUMksaB88dvR3DuR+8jUA_Employee\r\n\r\n#XTIT,20: W7: Title of pop-up used in confirm popup\r\nCONFIRM_TITLE=U8gL20FO8qfpdUsAz1kdhA_Confirm\r\n\r\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\r\nCOMPANY_NAME=Gf+KwvsORENcSvuhT/EEUg_Name\r\n\r\n#XFLD,20: W4: Label for name 1 of a company used general data\r\nCOMPANY_NAME1=329N5O7mp/m8Fdnw2w0gVA_Name 1\r\n\r\n#XFLD,20: W4: Label for name 2 of a company used general data\r\nCOMPANY_NAME2=of6GApvM4xLfboq1UNrXIQ_Name 2\r\n\r\n#XFLD,20: W4: Label for first name of a person used general data\r\nFIRST_NAME=5PhFX5URLQFK4Huh0U3pfw_First Name\r\n\r\n#XFLD,20: W4: Label for last name of a person used general data\r\nLAST_NAME=rbX4rpME/kheMJdoMPJLQA_Last Name\r\n\r\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nBIRTHDAY=XGOTv1kOM7GgJVacDDpe6A_Birthday\r\n\r\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nTITLE=jdUydkdnfGFwn3/D1XaEpA_Title\r\n\r\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nACADEMIC_TITLE=3gxglfZVa/91cIqsAZGn5A_Academic Title\r\n\r\n#XFLD,20: W4: Label for mobile phone number used general data\r\nMOBILE=xAkt8SDQPeFLZ57DRopu/Q_Mobile\r\n\r\n#XFLD,20: W4: Label for phone number used general data\r\nPHONE=Zw9jAj9ZnAgZu9/HtCcsCg_Phone\r\n\r\n#XFLD,20: W4: Label for e-mail used general data\r\nEMAIL=YSWTIP6ZU/w2KG1RClQyiw_E-Mail\r\n\r\n#XFLD,20: W4: Label for web site used general data\r\nWEBSITE=UGszmm5+2iBSBRh8KYRyow_Web Site\r\n\r\n#XFLD,20: W4: Label for country used general data\r\nCOUNTRY=nZ5Qj9f9h141wPwcFRBlUg_Country\r\n\r\n#XFLD,20: W4: Label for region used general data\r\nREGION=hOMnYynO5XvjCY19p6OfNw_Region\r\n\r\n#XFLD,20: W4: Label for city used general data\r\nCITY=uzf1uNb8wSqbjOaAQme9Zw_City\r\n\r\n#XFLD,20: W4: Label for postal code used general data\r\nPOSTAL_CODE=h+3UwSihB9Sceuk/u/cFkA_Postal Code\r\n\r\n#XFLD,20: W4: Label for street used general data\r\nSTREET=xcY181ccXGL7cmkfv9WFuA_Street\r\n\r\n#XFLD,10: W4: Label for house number used general data\r\nHOUSE_NUMBER=Whej81WQLfdGhFsqUaAFmw_House No.\r\n\r\n#XFLD,15: W6: Label for ID used in Quotations\r\nID=QeH6yc1PXIPT5K0Ui2yhbg_ID\r\n\r\n#XFLD,15: W6: Label for Amount used in Quotations\r\nAMOUNT=NSg6gpahSW2Txrq3j+Qx9w_Amount\r\n\r\n#XFLD,20: W6: Label for Expiration Date used in Quotations\r\nEXPIRATION_DATE=2hKMvM5DYmecfzQsOs/EYA_Expiration Date\r\n\r\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\r\nDELIVERY_DATE=/g8NPv4Bmp/2XtwhMd0EAg_Delivery Date\r\n\r\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\r\nSALES_EMPLOYEE=LXoZdhiKLhYLr1LdQunNxA_Sales Employee\r\n\r\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\r\nATTRIBUTESET=QeYp2egsEO4NDCwIfeXLNQ_Attribute Set\r\n\r\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\r\nATTRIBUTE=DVIXXlmhfTRvcmPZsenDtw_Attribute\r\n\r\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\r\nVALUE=5YqZpPmW69NpwMxzpzGl4w_Value\r\n\r\n#XBUT, 20: Button to create an Account\r\nBUTTON_ADD=qT53Ygsk4lHX0y3Ctorj3g_Add\r\n\r\n#XBUT, 20: Button to edit an Account\r\nBUTTON_EDIT=vjynZ+mnCi+bvB7NUE2b7g_Edit\r\n\r\n#XBUT, 20: Button to save changes\r\nBUTTON_SAVE=Ewc6ltjmddK16kLuE50Ixw_Save\r\n\r\n#XBUT, 20: Button to cancel changes\r\nBUTTON_CANCEL=GtNfSPCsTTq0Y5DJQ1Et1w_Cancel\r\n\r\n#XBUT, 30: Button which shows the personalization buttons\r\nBUTTON_SHOW_PERSONALIZATION=Y6L+eeb+tvYx0SWXuwiqPg_Show Personalization\r\n\r\n#XBUT, 30: Button which hides the personalization buttons\r\nBUTTON_HIDE_PERSONALIZATION=3okcO0N/76yFVSqaAzcmtA_Hide Personalization\r\n\r\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_CONFIRM_CANCEL=TTj5LoLF6F3aYhWa13bcQw_Leave this page without saving the changes you may have made?\r\n\r\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\r\nMSG_CONFIRM_DELETE_CONTACT=KRu6jRkJHRBWNVbxGE0Vqg_The contact will be unassigned from the account. Do you want to continue?\r\n\r\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_SUCCESS=l9vc4ZNSi0q9WjigwDfmZA_Account updated.\r\n\r\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_ERROR=lGDGdq3P9Hguh72RVSCyPQ_Update failed\r\n\r\n# XMSG : Account update succeeded\r\nMSG_CREATION_SUCCESS=Uah80HnDooT1/lVrBDry4A_Account created\r\n\r\n# XMSG : Task creation succeeded\r\nMSG_TASK_CREATION_SUCCESS=q+L9UzmFfLdpTbxBz2mDoA_Task created\r\n\r\n# XMSG : Contact creation failed\r\nMSG_CREATION_ERROR=Owo/W8ORoW9vI+oMY/kc5g_Creation failed\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong country\r\nMSG_WRONG_COUNTRY_ERROR=K3vsu9GEAxYl4vkrGSIB5g_Country "{0}" does not exist.\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong region\r\nMSG_WRONG_REGION_ERROR=6OJRowX6ztunSVVb1ZQPlQ_Region "{0}" does not exist for the given country.\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong employee\r\nMSG_WRONG_EMPLOYEE_ERROR=wQCefhzXwRzijQKp6T+FqA_Employee "{0}" does not exist.\r\n\r\n# XMSG: message that will be displayed, if the user has entered invalid website url\r\nMSG_WRONG_URL_ERROR=ruBZPafqRHiuVMiblJwuKg_Entered URL "{0}" is not valid.\r\n\r\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\r\nMSG_MANDATORY_FIELDS=dyh1WLFrxqUSNtzrlRvXnw_Not all mandatory fields are filled.\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA=iwePxnrzRthfEfLZ0SI3ZQ_Data has been changed by another user. Do you want to overwrite the other user\'s changes with your own?\r\n\r\n# XMSG: message that will be displayed in case of conflicts during file renaming\r\nMSG_CONFLICTING_FILE_NAME=5XMCfnSB/I3Nv2k/xzNqgQ_The file name has been changed by another user. Do you want to overwrite the other user\'s changes with your own?\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA_WITH_REFRESH=3uSZPtoK49mTjd33XERZZQ_Data has been changed by another user. Data will be refreshed.\r\n\r\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\r\nMSG_NOT_IN_MAIN_CONTACT=Wj09DwcBUtdFN/SDZmxCew_You can only view business cards of contacts that have been assigned to this account\r\n\r\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\r\nMSG_EXCEEDING_FILE_NAME_LENGTH=fmgBqjQvaVFWXiEbAcq81g_Your file name can have a maximum of 40 characters.\r\n\r\n# XTOL, 20: tooltip shown on search result list for button to add an account"\r\nADD_ACCOUNT_TOOLTIP=Noc4L2mPCcjs2msz1KeBKw_Add Account\r\n\r\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\r\nADD_MARKETING_ATTRIBUTE_TOOLTIP=g8zK3sGkfUQyVkbVtKVIHQ_Add Marketing Attribute\r\n\r\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\r\nADD_CONTACT_TOOLTIP=yw+o/Jgrm7toxI3ZmNg3GA_Add Contact\r\n\r\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\r\nADD_APPOINTMENT_TOOLTIP=gZOOTQtQH4PyrKtvuh2Thg_Add Appointment\r\n\r\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\r\nADD_TASK_TOOLTIP=Mt3tzeDm+JWynXmqMOBTag_Add Task\r\n\r\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\r\nADD_OPPORTUNITY_TOOLTIP=Qh7vX6WixnGkiqvY6TuThw_Add Opportunity\r\n',
		"cus/crm/myaccounts/i18n/i18n_es.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XFLD, 30: Facet title for general Data\r\nGENERAL_DATA=Datos generales\r\n\r\n#XTIT, 40: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=Mis clientes\r\n\r\n#XTIT, 40: this is the title for the detail screen\r\nDETAIL_TITLE=Cliente\r\n\r\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\r\nREVENUE_CURRENT=Ingresos an.acum.\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\r\nREVENUE_CURRENT_TOOLTIP=Ingresos hasta el a\\u00F1o actual\r\n\r\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\r\nREVENUE_LAST=Ingresos a\\u00F1o pas.\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\r\nREVENUE_LAST_TOOLTIP=Ingresos hasta el a\\u00F1o pasado\r\n\r\n# XFLD, 30: Facet title for opportunities and label in facet general data\r\nOPPORTUNITIES=Oportunidades\r\n\r\n#XFLD, 30: Facet title for leads\r\nLEADS=Leads\r\n\r\n#XFLD, 30: Facet title for tasks\r\nTASKS=Tareas\r\n\r\n#XFLD, 30: Facet title for appointments\r\nAPPOINTMENTS=Citas\r\n\r\n#XFLD, 30: Facet title for quotations\r\nQUOTATIONS=Ofertas\r\n\r\n#XFLD, 30: Facet title for sales orders\r\nSALES_ORDERS=Pedidos de cliente\r\n\r\n#XFLD, 30: W7: Facet title for marketing attributes\r\nMARKETINGATTRIBUTES=Atributos de marketing\r\n\r\n#XFLD, 30: W6: Title for popup with products\r\nPRODUCTS=Productos\r\n\r\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\r\nEMPLOYEE_RESPONSIBLE=Empleado responsable\r\n\r\n#XFLD, 30: Facet title for Attachments\r\nATTACHMENTS=Anexos\r\n\r\n#XFLD, 30: Facet title for Notes\r\nNOTES=Notas\r\n\r\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\r\nNEW_NOTE=Nota nueva\r\n\r\n#XFLD, 30: Facet title for Contacts\r\nCONTACTS=Contactos\r\n\r\n#XFLD, 30: Label for Address in facet general data\r\nADDRESS=Direcci\\u00F3n\r\n\r\n#XFLD, 30: Label for Opportunities in facet general data\r\nUNWEIGHTED_OPPORTUNITIES=Oportunidades\r\n\r\n#XFLD, 30: Label for Rating in facet general data\r\nRATING=Clasificaci\\u00F3n\r\n\r\n# XFLD, 30: Label for Next contact in facet Appointments\r\nNEXT_APPOINTMENT=Siguiente cita\r\n\r\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\r\nLAST_APPOINTMENT=\\u00DAltima cita\r\n\r\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\r\nIMAGE=Imagen\r\n\r\n#XBUT, 20: Button to show the create actionsheet\r\nCREATE=Crear\r\n\r\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\r\nDISCUSS_ENTRY=Debatir SAP Jam\r\n\r\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\r\nSHARE_ENTRY=Compartir en SAP Jam\r\n\r\n#XBUT, 20: Button to share the note\r\nDETAIL_BUTTON_SHARE=Compartir\r\n\r\n#XBUT, 20: Button to cancel sharing\r\nDETAIL_BUTTON_CANCEL=Cancelar\r\n\r\n#XFLD,20: All accounts for filter\r\nALL_ACCOUNTS=Todos los clientes\r\n\r\n#XFLD,35: All individual accounts for filter\r\nALL_INDIVIDUAL_ACCOUNTS=Todos los clientes individuales\r\n\r\n#XFLD,35: All corporate accounts for filter\r\nALL_CORPORATE_ACCOUNTS=Todos los clientes empresariales\r\n\r\n#XFLD,35: All group accounts for filter\r\nALL_ACCOUNT_GROUPS=Todos los grupos de clientes\r\n\r\n#XFLD,20: my account for filter\r\nMY_ACCOUNT=Mis clientes\r\n\r\n#XFLD,35: my individual accounts for filter\r\nMY_INDIVIDUAL_ACCOUNTS=Mis clientes individuales\r\n\r\n#XFLD,35: my corporate accounts for filter\r\nMY_CORPORATE_ACCOUNTS=Mis clientes empresariales\r\n\r\n#XFLD,35: my group accounts for filter\r\nMY_ACCOUNT_GROUPS=Mis grupos de clientes\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nINDIVIDUAL_ACCOUNT=Cliente individual\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nCORPORATE_ACCOUNT=Ciente corporativo\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nACCOUNT_GROUP=Grupo de clientes\r\n\r\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\r\nSTARTING=Fecha de inicio\\: {0}\r\n\r\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\r\nCLOSING=Fecha de cierre\\: {0}\r\n\r\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\r\nDUE=Fecha de vencimiento\\: {0}\r\n\r\n#XFLD,20: All accounts for title\r\nALL_ACCOUNTS_TITLE=Todos los clientes ({0})\r\n\r\n#XFLD,35: All individual accounts for title\r\nALL_INDIVIDUAL_ACCOUNTS_TITLE=Todos los clientes individuales ({0})\r\n\r\n#XFLD,35: All corporate accounts for title\r\nALL_CORPORATE_ACCOUNTS_TITLE=Todos los clientes empresariales ({0})\r\n\r\n#XFLD,35: All group accounts for title\r\nALL_ACCOUNT_GROUPS_TITLE=Todos los grupos de clientes ({0})\r\n\r\n#XFLD,20: my account for title\r\nMY_ACCOUNT_TITLE=Mis clientes ({0})\r\n\r\n#XFLD,35: my individual account for title\r\nMY_INDIVIDUAL_ACCOUNT_TITLE=Mis clientes individuales ({0})\r\n\r\n#XFLD,35: my corporate account for title.\r\nMY_CORPORATE_ACCOUNT_TITLE=Mis clientes empresariales ({0})\r\n\r\n#XFLD,35: my group account for title\r\nMY_ACCOUNT_GROUP_TITLE=Todos mis grupos de clientes ({0})\r\n\r\n#XFLD,30: filtered by info\r\nFILTERED_BY=Filtrado por\\: {0}\r\n\r\n#XFLD,30: label, search for accounts\r\nSEARCH_ACCOUNTS=Buscar\r\n\r\n#XFLD,30: comma separator for location\r\nLOCATION={0}, {1}\r\n\r\n#XFLD: W4: Label for All day text in Appointments\r\nALL_DAY_EVENT=Todo el d\\u00EDa\r\n\r\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\r\nDURATION_MINUTE={0} min\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\r\nDURATION_HOUR={0} h\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\r\nDURATION_DAY={0} d\\u00EDa\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\r\nDURATION_DAYS={0} d\\u00EDas\r\n\r\n#XFLD: W4: Label for Private meeting\r\nPRIVATE=Privado\r\n\r\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\r\nSELECT_TRANSACTION_TYPE=Seleccionar tipo de transacci\\u00F3n\r\n\r\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\r\nNEW_TASK_INPUT_PLACEHOLDER=Nueva tarea\r\n\r\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nNO_DATA_TEXT=No hay datos\r\n\r\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nLOADING_TEXT=Cargando...\r\n\r\n#XFLD,25: W4: Column label for name of contact person in contacts\r\nNAME=Nombre\r\n\r\n#XFLD,25: W5: Column label for department of contact person in contacts\r\nDEPARTMENT=Departamento\r\n\r\n#XFLD,15: W6: Column label for actions of contact person in contacts\r\nACTIONS=Acciones\r\n\r\n#XFLD,25: W4: Column label for description of lead in Leads\r\nDESCRIPTION=Descripci\\u00F3n\r\n\r\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\r\nASSIGNED_TO=Asignado a\r\n\r\n#XFLD,15: W4: Column label for end date of lead in Leads\r\nEND_DATE=Fecha de fin\r\n\r\n#XFLD,15: W4: Column label for qualification level of lead in Leads\r\nQUALIFICATION=Calificaci\\u00F3n\r\n\r\n#XFLD,15: W4: Column label for status of lead in Leads\r\nSTATUS=Estado\r\n\r\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\r\nMAIN_CONTACT=Contacto principal\r\n\r\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\r\nVOLUME=Volumen\r\n\r\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\r\nPROBABILITY=Probabilidad\r\n\r\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\r\nCLOSE_BY=Cerrar el\r\n\r\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \r\nVIEWS=Vistas\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\r\nCONTACT_TITLE=Contacto\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\r\nEMPLOYEE_TITLE=Empleado\r\n\r\n#XTIT,20: W7: Title of pop-up used in confirm popup\r\nCONFIRM_TITLE=Confirmar\r\n\r\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\r\nCOMPANY_NAME=Nombre\r\n\r\n#XFLD,20: W4: Label for name 1 of a company used general data\r\nCOMPANY_NAME1=Nombre 1\r\n\r\n#XFLD,20: W4: Label for name 2 of a company used general data\r\nCOMPANY_NAME2=Nombre 2\r\n\r\n#XFLD,20: W4: Label for first name of a person used general data\r\nFIRST_NAME=Nombre\r\n\r\n#XFLD,20: W4: Label for last name of a person used general data\r\nLAST_NAME=Apellido\r\n\r\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nBIRTHDAY=Fecha de nacimiento\r\n\r\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nTITLE=T\\u00EDtulo\r\n\r\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nACADEMIC_TITLE=T\\u00EDtulo acad\\u00E9mico\r\n\r\n#XFLD,20: W4: Label for mobile phone number used general data\r\nMOBILE=Tel\\u00E9fono m\\u00F3vil\r\n\r\n#XFLD,20: W4: Label for phone number used general data\r\nPHONE=Tel\\u00E9fono\r\n\r\n#XFLD,20: W4: Label for e-mail used general data\r\nEMAIL=Correo electr\\u00F3nico\r\n\r\n#XFLD,20: W4: Label for web site used general data\r\nWEBSITE=Sitio Web\r\n\r\n#XFLD,20: W4: Label for country used general data\r\nCOUNTRY=Pa\\u00EDs\r\n\r\n#XFLD,20: W4: Label for region used general data\r\nREGION=Regi\\u00F3n\r\n\r\n#XFLD,20: W4: Label for city used general data\r\nCITY=Ciudad\r\n\r\n#XFLD,20: W4: Label for postal code used general data\r\nPOSTAL_CODE=C\\u00F3digo postal\r\n\r\n#XFLD,20: W4: Label for street used general data\r\nSTREET=Calle\r\n\r\n#XFLD,10: W4: Label for house number used general data\r\nHOUSE_NUMBER=N\\u00BA de casa\r\n\r\n#XFLD,15: W6: Label for ID used in Quotations\r\nID=ID\r\n\r\n#XFLD,15: W6: Label for Amount used in Quotations\r\nAMOUNT=Importe\r\n\r\n#XFLD,20: W6: Label for Expiration Date used in Quotations\r\nEXPIRATION_DATE=Fecha de vencimiento\r\n\r\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\r\nDELIVERY_DATE=Fecha de entrega\r\n\r\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\r\nSALES_EMPLOYEE=Representante vta.\r\n\r\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\r\nATTRIBUTESET=Grupo de atributos\r\n\r\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\r\nATTRIBUTE=Atributos\r\n\r\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\r\nVALUE=Valor\r\n\r\n#XBUT, 20: Button to create an Account\r\nBUTTON_ADD=A\\u00F1adir\r\n\r\n#XBUT, 20: Button to edit an Account\r\nBUTTON_EDIT=Editar\r\n\r\n#XBUT, 20: Button to save changes\r\nBUTTON_SAVE=Grabar\r\n\r\n#XBUT, 20: Button to cancel changes\r\nBUTTON_CANCEL=Cancelar\r\n\r\n#XBUT, 30: Button which shows the personalization buttons\r\nBUTTON_SHOW_PERSONALIZATION=Mostrar personalizaci\\u00F3n\r\n\r\n#XBUT, 30: Button which hides the personalization buttons\r\nBUTTON_HIDE_PERSONALIZATION=Ocultar personalizaci\\u00F3n\r\n\r\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_CONFIRM_CANCEL=Cualquier modificaci\\u00F3n que no haya guardado se perder\\u00E1. \\u00BFDesea continuar?\r\n\r\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\r\nMSG_CONFIRM_DELETE_CONTACT=Se cancelar\\u00E1 la asignaci\\u00F3n del contacto de la cuenta. \\u00BFDesea continuar?\r\n\r\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_SUCCESS=Cuenta actualizada\r\n\r\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_ERROR=Error de actualizaci\\u00F3n\r\n\r\n# XMSG : Account update succeeded\r\nMSG_CREATION_SUCCESS=Cuenta creada\r\n\r\n# XMSG : Task creation succeeded\r\nMSG_TASK_CREATION_SUCCESS=Tarea creada\r\n\r\n# XMSG : Contact creation failed\r\nMSG_CREATION_ERROR=Error de creaci\\u00F3n\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong country\r\nMSG_WRONG_COUNTRY_ERROR=El pa\\u00EDs "{0}" no existe\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong region\r\nMSG_WRONG_REGION_ERROR=No existe la regi\\u00F3n "{0}" para el pa\\u00EDs\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong employee\r\nMSG_WRONG_EMPLOYEE_ERROR=El empleado "{0}" no existe.\r\n\r\n# XMSG: message that will be displayed, if the user has entered invalid website url\r\nMSG_WRONG_URL_ERROR=La direcci\\u00F3n URL introducida "{0}" no es v\\u00E1lida.\r\n\r\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\r\nMSG_MANDATORY_FIELDS=No se han rellenado todos los campos obligatorios\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA=Otro usuario ha modificado los datos. \\u00BFDesea sobrescribir las modificaciones del otro usuario con sus propias modificaciones?\r\n\r\n# XMSG: message that will be displayed in case of conflicts during file renaming\r\nMSG_CONFLICTING_FILE_NAME=Otro usuario ha modificado el nombre del fichero. \\u00BFDesea sobrescribir las modificaciones del otro usuario con sus propias modificaciones?\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA_WITH_REFRESH=Otro usuario ha modificado los datos. Estas modificaciones ahora aparecer\\u00E1n en la aplicaci\\u00F3n.\r\n\r\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\r\nMSG_NOT_IN_MAIN_CONTACT=Solo puede ver los detalles de los contactos asignados a esta cuenta\r\n\r\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\r\nMSG_EXCEEDING_FILE_NAME_LENGTH=El nombre del archivo puede tener un m\\u00E1ximo de 40 caracteres.\r\n\r\n# XTOL, 20: tooltip shown on search result list for button to add an account"\r\n\r\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\r\n\r\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\r\n\r\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\r\n\r\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\r\n\r\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\r\n',
		"cus/crm/myaccounts/i18n/i18n_fr.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XFLD, 30: Facet title for general Data\r\nGENERAL_DATA=Donn\\u00E9es g\\u00E9n\\u00E9rales\r\n\r\n#XTIT, 40: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=Mes comptes\r\n\r\n#XTIT, 40: this is the title for the detail screen\r\nDETAIL_TITLE=Compte\r\n\r\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\r\nREVENUE_CURRENT=Produit ann\\u00E9e cum.\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\r\nREVENUE_CURRENT_TOOLTIP=Revenu \\u00E0 date ann\\u00E9e en cours\r\n\r\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\r\nREVENUE_LAST=ProduitAnn\\u00E9ePr\\u00E9c.\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\r\nREVENUE_LAST_TOOLTIP=Produit ann\\u00E9e pr\\u00E9c\\u00E9dente\r\n\r\n# XFLD, 30: Facet title for opportunities and label in facet general data\r\nOPPORTUNITIES=Opportunit\\u00E9s\r\n\r\n#XFLD, 30: Facet title for leads\r\nLEADS=Int\\u00E9r\\u00EAts potentiels\r\n\r\n#XFLD, 30: Facet title for tasks\r\nTASKS=T\\u00E2ches\r\n\r\n#XFLD, 30: Facet title for appointments\r\nAPPOINTMENTS=Rendez-vous\r\n\r\n#XFLD, 30: Facet title for quotations\r\nQUOTATIONS=Offres\r\n\r\n#XFLD, 30: Facet title for sales orders\r\nSALES_ORDERS=Commandes client\r\n\r\n#XFLD, 30: W7: Facet title for marketing attributes\r\nMARKETINGATTRIBUTES=Attributs marketing\r\n\r\n#XFLD, 30: W6: Title for popup with products\r\nPRODUCTS=Produits\r\n\r\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\r\nEMPLOYEE_RESPONSIBLE=Responsable\r\n\r\n#XFLD, 30: Facet title for Attachments\r\nATTACHMENTS=Pi\\u00E8ces jointes\r\n\r\n#XFLD, 30: Facet title for Notes\r\nNOTES=Notes\r\n\r\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\r\nNEW_NOTE=Nouvelle note\r\n\r\n#XFLD, 30: Facet title for Contacts\r\nCONTACTS=Contacts\r\n\r\n#XFLD, 30: Label for Address in facet general data\r\nADDRESS=Adresse\r\n\r\n#XFLD, 30: Label for Opportunities in facet general data\r\nUNWEIGHTED_OPPORTUNITIES=Opportunit\\u00E9s\r\n\r\n#XFLD, 30: Label for Rating in facet general data\r\nRATING=\\u00C9valuation\r\n\r\n# XFLD, 30: Label for Next contact in facet Appointments\r\nNEXT_APPOINTMENT=Prochain rendez-vous\r\n\r\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\r\nLAST_APPOINTMENT=Dernier rendez-vous\r\n\r\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\r\nIMAGE=Image\r\n\r\n#XBUT, 20: Button to show the create actionsheet\r\nCREATE=Cr\\u00E9er\r\n\r\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\r\nDISCUSS_ENTRY=En discuter sur SAP Jam\r\n\r\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\r\nSHARE_ENTRY=Partager via SAP JAM\r\n\r\n#XBUT, 20: Button to share the note\r\nDETAIL_BUTTON_SHARE=Partager\r\n\r\n#XBUT, 20: Button to cancel sharing\r\nDETAIL_BUTTON_CANCEL=Interrompre\r\n\r\n#XFLD,20: All accounts for filter\r\nALL_ACCOUNTS=Tous les comptes\r\n\r\n#XFLD,35: All individual accounts for filter\r\nALL_INDIVIDUAL_ACCOUNTS=Tous les comptes priv\\u00E9s\r\n\r\n#XFLD,35: All corporate accounts for filter\r\nALL_CORPORATE_ACCOUNTS=Tous les comptes d\'entreprise\r\n\r\n#XFLD,35: All group accounts for filter\r\nALL_ACCOUNT_GROUPS=Tous les groupes de comptes\r\n\r\n#XFLD,20: my account for filter\r\nMY_ACCOUNT=Mes comptes\r\n\r\n#XFLD,35: my individual accounts for filter\r\nMY_INDIVIDUAL_ACCOUNTS=Mes comptes priv\\u00E9s\r\n\r\n#XFLD,35: my corporate accounts for filter\r\nMY_CORPORATE_ACCOUNTS=Mes comptes d\'entreprise\r\n\r\n#XFLD,35: my group accounts for filter\r\nMY_ACCOUNT_GROUPS=Mes groupes de comptes\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nINDIVIDUAL_ACCOUNT=Compte priv\\u00E9\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nCORPORATE_ACCOUNT=Compte d\\u2019entreprise\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nACCOUNT_GROUP=Groupe de comptes\r\n\r\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\r\nSTARTING=Date de d\\u00E9but\\u00A0\\: {0}\r\n\r\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\r\nCLOSING=Date de cl\\u00F4ture\\u00A0\\: {0}\r\n\r\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\r\nDUE=Date d\'\'\\u00E9ch\\u00E9ance\\u00A0\\: {0}\r\n\r\n#XFLD,20: All accounts for title\r\nALL_ACCOUNTS_TITLE=Tous les comptes ({0})\r\n\r\n#XFLD,35: All individual accounts for title\r\nALL_INDIVIDUAL_ACCOUNTS_TITLE=Tous les comptes priv\\u00E9s ({0})\r\n\r\n#XFLD,35: All corporate accounts for title\r\nALL_CORPORATE_ACCOUNTS_TITLE=Tous les comptes d\'\'entreprise ({0})\r\n\r\n#XFLD,35: All group accounts for title\r\nALL_ACCOUNT_GROUPS_TITLE=Tous les groupes de comptes ({0})\r\n\r\n#XFLD,20: my account for title\r\nMY_ACCOUNT_TITLE=Mes comptes ({0})\r\n\r\n#XFLD,35: my individual account for title\r\nMY_INDIVIDUAL_ACCOUNT_TITLE=Mes comptes priv\\u00E9s ({0})\r\n\r\n#XFLD,35: my corporate account for title.\r\nMY_CORPORATE_ACCOUNT_TITLE=Mes comptes d\'\'entreprise ({0})\r\n\r\n#XFLD,35: my group account for title\r\nMY_ACCOUNT_GROUP_TITLE=Mes groupes de comptes ({0})\r\n\r\n#XFLD,30: filtered by info\r\nFILTERED_BY=Filtr\\u00E9 par\\u00A0\\: {0}\r\n\r\n#XFLD,30: label, search for accounts\r\nSEARCH_ACCOUNTS=Rechercher\r\n\r\n#XFLD,30: comma separator for location\r\nLOCATION={0}, {1}\r\n\r\n#XFLD: W4: Label for All day text in Appointments\r\nALL_DAY_EVENT=Toute la journ\\u00E9e\r\n\r\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\r\nDURATION_MINUTE={0} mn.\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\r\nDURATION_HOUR={0}\\u00A0h\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\r\nDURATION_DAY={0}\\u00A0jour\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\r\nDURATION_DAYS={0}\\u00A0jours\r\n\r\n#XFLD: W4: Label for Private meeting\r\nPRIVATE=Priv\\u00E9\r\n\r\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\r\nSELECT_TRANSACTION_TYPE=S\\u00E9lection du type d\'op\\u00E9ration\r\n\r\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\r\nNEW_TASK_INPUT_PLACEHOLDER=Nouvelle t\\u00E2che\r\n\r\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nNO_DATA_TEXT=Aucune donn\\u00E9e\r\n\r\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nLOADING_TEXT=Chargement...\r\n\r\n#XFLD,25: W4: Column label for name of contact person in contacts\r\nNAME=Nom\r\n\r\n#XFLD,25: W5: Column label for department of contact person in contacts\r\nDEPARTMENT=Service\r\n\r\n#XFLD,15: W6: Column label for actions of contact person in contacts\r\nACTIONS=Actions\r\n\r\n#XFLD,25: W4: Column label for description of lead in Leads\r\nDESCRIPTION=Description\r\n\r\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\r\nASSIGNED_TO=Affect\\u00E9 \\u00E0\r\n\r\n#XFLD,15: W4: Column label for end date of lead in Leads\r\nEND_DATE=Date de fin\r\n\r\n#XFLD,15: W4: Column label for qualification level of lead in Leads\r\nQUALIFICATION=Qualification\r\n\r\n#XFLD,15: W4: Column label for status of lead in Leads\r\nSTATUS=Statut\r\n\r\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\r\nMAIN_CONTACT=Contact principal\r\n\r\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\r\nVOLUME=Volume\r\n\r\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\r\nPROBABILITY=Probabilit\\u00E9\r\n\r\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\r\nCLOSE_BY=Cl\\u00F4turer avant\r\n\r\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \r\nVIEWS=Vues\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\r\nCONTACT_TITLE=Contact\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\r\nEMPLOYEE_TITLE=Salari\\u00E9\r\n\r\n#XTIT,20: W7: Title of pop-up used in confirm popup\r\nCONFIRM_TITLE=Confirmation\r\n\r\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\r\nCOMPANY_NAME=Nom\r\n\r\n#XFLD,20: W4: Label for name 1 of a company used general data\r\nCOMPANY_NAME1=Nom 1\r\n\r\n#XFLD,20: W4: Label for name 2 of a company used general data\r\nCOMPANY_NAME2=Nom 2\r\n\r\n#XFLD,20: W4: Label for first name of a person used general data\r\nFIRST_NAME=Pr\\u00E9nom\r\n\r\n#XFLD,20: W4: Label for last name of a person used general data\r\nLAST_NAME=Nom\r\n\r\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nBIRTHDAY=Date de naissance\r\n\r\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nTITLE=Titre\r\n\r\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nACADEMIC_TITLE=Titre universitaire\r\n\r\n#XFLD,20: W4: Label for mobile phone number used general data\r\nMOBILE=N\\u00B0 t\\u00E9l. portable\r\n\r\n#XFLD,20: W4: Label for phone number used general data\r\nPHONE=N\\u00B0 de t\\u00E9l\\u00E9phone\r\n\r\n#XFLD,20: W4: Label for e-mail used general data\r\nEMAIL=E-mail\r\n\r\n#XFLD,20: W4: Label for web site used general data\r\nWEBSITE=Site Web\r\n\r\n#XFLD,20: W4: Label for country used general data\r\nCOUNTRY=Pays\r\n\r\n#XFLD,20: W4: Label for region used general data\r\nREGION=R\\u00E9gion\r\n\r\n#XFLD,20: W4: Label for city used general data\r\nCITY=Ville\r\n\r\n#XFLD,20: W4: Label for postal code used general data\r\nPOSTAL_CODE=Code postal\r\n\r\n#XFLD,20: W4: Label for street used general data\r\nSTREET=Rue\r\n\r\n#XFLD,10: W4: Label for house number used general data\r\nHOUSE_NUMBER=N\\u00B0 de rue\r\n\r\n#XFLD,15: W6: Label for ID used in Quotations\r\nID=ID\r\n\r\n#XFLD,15: W6: Label for Amount used in Quotations\r\nAMOUNT=Montant\r\n\r\n#XFLD,20: W6: Label for Expiration Date used in Quotations\r\nEXPIRATION_DATE=Date d\'expiration\r\n\r\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\r\nDELIVERY_DATE=Date de livraison\r\n\r\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\r\nSALES_EMPLOYEE=Commercial\r\n\r\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\r\nATTRIBUTESET=Ensemble d\'attributs\r\n\r\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\r\nATTRIBUTE=Attribut\r\n\r\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\r\nVALUE=Valeur\r\n\r\n#XBUT, 20: Button to create an Account\r\nBUTTON_ADD=Ajouter\r\n\r\n#XBUT, 20: Button to edit an Account\r\nBUTTON_EDIT=Modifier\r\n\r\n#XBUT, 20: Button to save changes\r\nBUTTON_SAVE=Sauvegarder\r\n\r\n#XBUT, 20: Button to cancel changes\r\nBUTTON_CANCEL=Interrompre\r\n\r\n#XBUT, 30: Button which shows the personalization buttons\r\nBUTTON_SHOW_PERSONALIZATION=Aff. personnalisat.\r\n\r\n#XBUT, 30: Button which hides the personalization buttons\r\nBUTTON_HIDE_PERSONALIZATION=Masquer personnalis.\r\n\r\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_CONFIRM_CANCEL=Toutes les modifications non sauvegard\\u00E9es seront perdues. Voulez-vous continuer ?\r\n\r\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\r\nMSG_CONFIRM_DELETE_CONTACT=Le contact ne sera plus affect\\u00E9 au compte. Voulez-vous poursuivre ?\r\n\r\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_SUCCESS=Compte mis \\u00E0 jour\r\n\r\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_ERROR=\\u00C9chec de la mise \\u00E0 jour\r\n\r\n# XMSG : Account update succeeded\r\nMSG_CREATION_SUCCESS=Compte cr\\u00E9\\u00E9\r\n\r\n# XMSG : Task creation succeeded\r\nMSG_TASK_CREATION_SUCCESS=T\\u00E2che cr\\u00E9\\u00E9e\r\n\r\n# XMSG : Contact creation failed\r\nMSG_CREATION_ERROR=\\u00C9chec de la cr\\u00E9ation\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong country\r\nMSG_WRONG_COUNTRY_ERROR=Le pays "{0}" n\'\'existe pas.\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong region\r\nMSG_WRONG_REGION_ERROR=La r\\u00E9gion "{0}" n\'\'existe pas pour ce pays.\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong employee\r\nMSG_WRONG_EMPLOYEE_ERROR=Le salari\\u00E9 "{0}" n\'\'existe pas.\r\n\r\n# XMSG: message that will be displayed, if the user has entered invalid website url\r\nMSG_WRONG_URL_ERROR=L\'\'URL "{0}" saisi n\'\'est pas valide.\r\n\r\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\r\nMSG_MANDATORY_FIELDS=Certaines zones obligatoires ne sont pas renseign\\u00E9es.\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA=Les donn\\u00E9es ont \\u00E9t\\u00E9 modifi\\u00E9es par un autre utilisateur. Voulez-vous remplacer les modifications de l\'autre utilisateur par vos entr\\u00E9es ?\r\n\r\n# XMSG: message that will be displayed in case of conflicts during file renaming\r\nMSG_CONFLICTING_FILE_NAME=Le nom du fichier a \\u00E9t\\u00E9 modifi\\u00E9 par un autre utilisateur. Voulez-vous remplacer les modifications de l\'autre utilisateur par vos entr\\u00E9es ?\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA_WITH_REFRESH=Donn\\u00E9es modifi\\u00E9es par un autre utilisateur. Ces modifications seront d\\u00E9sormais visibles dans l\'application.\r\n\r\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\r\nMSG_NOT_IN_MAIN_CONTACT=Vous pouvez uniquement afficher les d\\u00E9tails des contacts affect\\u00E9s \\u00E0 ce compte.\r\n\r\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\r\nMSG_EXCEEDING_FILE_NAME_LENGTH=La longueur maximale du nom du fichier est de 40 caract\\u00E8res.\r\n\r\n# XTOL, 20: tooltip shown on search result list for button to add an account"\r\n\r\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\r\n\r\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\r\n\r\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\r\n\r\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\r\n\r\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\r\n',
		"cus/crm/myaccounts/i18n/i18n_hr.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XFLD, 30: Facet title for general Data\r\nGENERAL_DATA=Op\\u0107i podaci\r\n\r\n#XTIT, 40: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=Moja klijenti\r\n\r\n#XTIT, 40: this is the title for the detail screen\r\nDETAIL_TITLE=Klijent\r\n\r\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\r\nREVENUE_CURRENT=Prihod god. do dtm\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\r\nREVENUE_CURRENT_TOOLTIP=Prihodi do datuma teku\\u0107a godina\r\n\r\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\r\nREVENUE_LAST=Prihod pro\\u0161le god.\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\r\nREVENUE_LAST_TOOLTIP=Prihod pro\\u0161le godine\r\n\r\n# XFLD, 30: Facet title for opportunities and label in facet general data\r\nOPPORTUNITIES=Prilike\r\n\r\n#XFLD, 30: Facet title for leads\r\nLEADS=Leadovi\r\n\r\n#XFLD, 30: Facet title for tasks\r\nTASKS=Zadaci\r\n\r\n#XFLD, 30: Facet title for appointments\r\nAPPOINTMENTS=Sastanci\r\n\r\n#XFLD, 30: Facet title for quotations\r\nQUOTATIONS=Ponude\r\n\r\n#XFLD, 30: Facet title for sales orders\r\nSALES_ORDERS=Prodajni nalozi\r\n\r\n#XFLD, 30: W7: Facet title for marketing attributes\r\nMARKETINGATTRIBUTES=Marketin\\u0161ki atributi\r\n\r\n#XFLD, 30: W6: Title for popup with products\r\nPRODUCTS=Proizvodi\r\n\r\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\r\nEMPLOYEE_RESPONSIBLE=Odgovorni zaposlenik\r\n\r\n#XFLD, 30: Facet title for Attachments\r\nATTACHMENTS=Prilozi\r\n\r\n#XFLD, 30: Facet title for Notes\r\nNOTES=Bilje\\u0161ke\r\n\r\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\r\nNEW_NOTE=Nova bilje\\u0161ka\r\n\r\n#XFLD, 30: Facet title for Contacts\r\nCONTACTS=Kontakti\r\n\r\n#XFLD, 30: Label for Address in facet general data\r\nADDRESS=Adresa\r\n\r\n#XFLD, 30: Label for Opportunities in facet general data\r\nUNWEIGHTED_OPPORTUNITIES=Prilike\r\n\r\n#XFLD, 30: Label for Rating in facet general data\r\nRATING=Ocjenjivanje\r\n\r\n# XFLD, 30: Label for Next contact in facet Appointments\r\nNEXT_APPOINTMENT=Sljede\\u0107i sastanak\r\n\r\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\r\nLAST_APPOINTMENT=Zadnji sastanak\r\n\r\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\r\nIMAGE=Slika\r\n\r\n#XBUT, 20: Button to show the create actionsheet\r\nCREATE=Kreiraj\r\n\r\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\r\nDISCUSS_ENTRY=Rasprava u SAP Jamu\r\n\r\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\r\nSHARE_ENTRY=Podijeli u SAP Jamu\r\n\r\n#XBUT, 20: Button to share the note\r\nDETAIL_BUTTON_SHARE=Otpusti\r\n\r\n#XBUT, 20: Button to cancel sharing\r\nDETAIL_BUTTON_CANCEL=Otka\\u017Ei\r\n\r\n#XFLD,20: All accounts for filter\r\nALL_ACCOUNTS=Svi klijenti\r\n\r\n#XFLD,35: All individual accounts for filter\r\nALL_INDIVIDUAL_ACCOUNTS=Sva pojedina\\u010Dni klijenti\r\n\r\n#XFLD,35: All corporate accounts for filter\r\nALL_CORPORATE_ACCOUNTS=Svi klijenti poduze\\u0107a\r\n\r\n#XFLD,35: All group accounts for filter\r\nALL_ACCOUNT_GROUPS=Sve grupe klijenata\r\n\r\n#XFLD,20: my account for filter\r\nMY_ACCOUNT=Moja klijenti\r\n\r\n#XFLD,35: my individual accounts for filter\r\nMY_INDIVIDUAL_ACCOUNTS=Moji pojedina\\u010Dni klijenti\r\n\r\n#XFLD,35: my corporate accounts for filter\r\nMY_CORPORATE_ACCOUNTS=Moja klijenti poduze\\u0107a\r\n\r\n#XFLD,35: my group accounts for filter\r\nMY_ACCOUNT_GROUPS=Moje grupe klijenata\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nINDIVIDUAL_ACCOUNT=Pojedina\\u010Dni klijent\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nCORPORATE_ACCOUNT=Klijent poduze\\u0107a\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nACCOUNT_GROUP=Grupa klijenata\r\n\r\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\r\nSTARTING=Start Date\\: {0}\r\n\r\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\r\nCLOSING=Closing Date\\: {0}\r\n\r\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\r\nDUE=Due Date\\: {0}\r\n\r\n#XFLD,20: All accounts for title\r\nALL_ACCOUNTS_TITLE=All Accounts ({0})\r\n\r\n#XFLD,35: All individual accounts for title\r\nALL_INDIVIDUAL_ACCOUNTS_TITLE=All Individual Accounts ({0})\r\n\r\n#XFLD,35: All corporate accounts for title\r\nALL_CORPORATE_ACCOUNTS_TITLE=All Corporate Accounts ({0})\r\n\r\n#XFLD,35: All group accounts for title\r\nALL_ACCOUNT_GROUPS_TITLE=All Account Groups ({0})\r\n\r\n#XFLD,20: my account for title\r\nMY_ACCOUNT_TITLE=My Accounts ({0})\r\n\r\n#XFLD,35: my individual account for title\r\nMY_INDIVIDUAL_ACCOUNT_TITLE=My Individual Accounts ({0})\r\n\r\n#XFLD,35: my corporate account for title.\r\nMY_CORPORATE_ACCOUNT_TITLE=My Corporate Accounts ({0})\r\n\r\n#XFLD,35: my group account for title\r\nMY_ACCOUNT_GROUP_TITLE=My Account Groups ({0})\r\n\r\n#XFLD,30: filtered by info\r\nFILTERED_BY=Filtered By\\: {0}\r\n\r\n#XFLD,30: label, search for accounts\r\nSEARCH_ACCOUNTS=Tra\\u017Eenje\r\n\r\n#XFLD,30: comma separator for location\r\nLOCATION={0}, {1}\r\n\r\n#XFLD: W4: Label for All day text in Appointments\r\nALL_DAY_EVENT=Cijeli dan\r\n\r\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\r\nDURATION_MINUTE={0} min\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\r\nDURATION_HOUR={0} h\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\r\nDURATION_DAY={0} day\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\r\nDURATION_DAYS={0} days\r\n\r\n#XFLD: W4: Label for Private meeting\r\nPRIVATE=Osobno\r\n\r\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\r\nSELECT_TRANSACTION_TYPE=Odaberi tip transakcije\r\n\r\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\r\nNEW_TASK_INPUT_PLACEHOLDER=Novi zadatak\r\n\r\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nNO_DATA_TEXT=Nema podataka\r\n\r\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nLOADING_TEXT=U\\u010Ditavanje...\r\n\r\n#XFLD,25: W4: Column label for name of contact person in contacts\r\nNAME=Naziv\r\n\r\n#XFLD,25: W5: Column label for department of contact person in contacts\r\nDEPARTMENT=Odjel\r\n\r\n#XFLD,15: W6: Column label for actions of contact person in contacts\r\nACTIONS=Radnje\r\n\r\n#XFLD,25: W4: Column label for description of lead in Leads\r\nDESCRIPTION=Opis\r\n\r\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\r\nASSIGNED_TO=Dodijeljeno\r\n\r\n#XFLD,15: W4: Column label for end date of lead in Leads\r\nEND_DATE=Datum zavr\\u0161etka\r\n\r\n#XFLD,15: W4: Column label for qualification level of lead in Leads\r\nQUALIFICATION=Kvalifikacija\r\n\r\n#XFLD,15: W4: Column label for status of lead in Leads\r\nSTATUS=Status\r\n\r\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\r\nMAIN_CONTACT=Glavni kontakt\r\n\r\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\r\nVOLUME=Obujam\r\n\r\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\r\nPROBABILITY=Vjerojatnost\r\n\r\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\r\nCLOSE_BY=Zatvori do\r\n\r\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \r\nVIEWS=Pogledi\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\r\nCONTACT_TITLE=Kontakt\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\r\nEMPLOYEE_TITLE=Zaposlenik\r\n\r\n#XTIT,20: W7: Title of pop-up used in confirm popup\r\nCONFIRM_TITLE=Potvrdi\r\n\r\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\r\nCOMPANY_NAME=Naziv\r\n\r\n#XFLD,20: W4: Label for name 1 of a company used general data\r\nCOMPANY_NAME1=Naziv 1\r\n\r\n#XFLD,20: W4: Label for name 2 of a company used general data\r\nCOMPANY_NAME2=Naziv 2\r\n\r\n#XFLD,20: W4: Label for first name of a person used general data\r\nFIRST_NAME=Ime\r\n\r\n#XFLD,20: W4: Label for last name of a person used general data\r\nLAST_NAME=Prezime\r\n\r\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nBIRTHDAY=Datum ro\\u0111enja\r\n\r\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nTITLE=Naslov\r\n\r\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nACADEMIC_TITLE=Akademska titula\r\n\r\n#XFLD,20: W4: Label for mobile phone number used general data\r\nMOBILE=Mobilni telefon\r\n\r\n#XFLD,20: W4: Label for phone number used general data\r\nPHONE=Telefon\r\n\r\n#XFLD,20: W4: Label for e-mail used general data\r\nEMAIL=E-po\\u0161ta\r\n\r\n#XFLD,20: W4: Label for web site used general data\r\nWEBSITE=Web stranica\r\n\r\n#XFLD,20: W4: Label for country used general data\r\nCOUNTRY=Dr\\u017Eava\r\n\r\n#XFLD,20: W4: Label for region used general data\r\nREGION=Regija\r\n\r\n#XFLD,20: W4: Label for city used general data\r\nCITY=Grad\r\n\r\n#XFLD,20: W4: Label for postal code used general data\r\nPOSTAL_CODE=Po\\u0161tanski broj\r\n\r\n#XFLD,20: W4: Label for street used general data\r\nSTREET=Ulica\r\n\r\n#XFLD,10: W4: Label for house number used general data\r\nHOUSE_NUMBER=Ku\\u0107ni broj\r\n\r\n#XFLD,15: W6: Label for ID used in Quotations\r\nID=ID\r\n\r\n#XFLD,15: W6: Label for Amount used in Quotations\r\nAMOUNT=Iznos\r\n\r\n#XFLD,20: W6: Label for Expiration Date used in Quotations\r\nEXPIRATION_DATE=Datum isteka\r\n\r\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\r\nDELIVERY_DATE=Datum isporuke\r\n\r\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\r\nSALES_EMPLOYEE=Zaposlenik u prodaji\r\n\r\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\r\nATTRIBUTESET=Skup atributa\r\n\r\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\r\nATTRIBUTE=Atribut\r\n\r\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\r\nVALUE=Vrijednost\r\n\r\n#XBUT, 20: Button to create an Account\r\nBUTTON_ADD=Dodaj\r\n\r\n#XBUT, 20: Button to edit an Account\r\nBUTTON_EDIT=Uredi\r\n\r\n#XBUT, 20: Button to save changes\r\nBUTTON_SAVE=Snimi\r\n\r\n#XBUT, 20: Button to cancel changes\r\nBUTTON_CANCEL=Otka\\u017Ei\r\n\r\n#XBUT, 30: Button which shows the personalization buttons\r\nBUTTON_SHOW_PERSONALIZATION=Poka\\u017Ei personalizaciju\r\n\r\n#XBUT, 30: Button which hides the personalization buttons\r\nBUTTON_HIDE_PERSONALIZATION=Sakrij personalizaciju\r\n\r\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_CONFIRM_CANCEL=Nesnimljene promjene \\u0107e se izgubiti. \\u017Delite li nastaviti?\r\n\r\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\r\nMSG_CONFIRM_DELETE_CONTACT=Dodjela kontakta klijentu bit \\u0107e poni\\u0161tena. \\u017Delite li nastaviti?\r\n\r\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_SUCCESS=Klijent a\\u017Euriran\r\n\r\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_ERROR=A\\u017Euriranje nije uspjelo\r\n\r\n# XMSG : Account update succeeded\r\nMSG_CREATION_SUCCESS=Klijent kreiran\r\n\r\n# XMSG : Task creation succeeded\r\nMSG_TASK_CREATION_SUCCESS=Zadatak kreiran\r\n\r\n# XMSG : Contact creation failed\r\nMSG_CREATION_ERROR=Kreiranje nije uspjelo\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong country\r\nMSG_WRONG_COUNTRY_ERROR=Country "{0}" does not exist\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong region\r\nMSG_WRONG_REGION_ERROR=Region "{0}" does not exist for country\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong employee\r\nMSG_WRONG_EMPLOYEE_ERROR=Employee "{0}" does not exist.\r\n\r\n# XMSG: message that will be displayed, if the user has entered invalid website url\r\nMSG_WRONG_URL_ERROR=Entered URL "{0}" is not valid.\r\n\r\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\r\nMSG_MANDATORY_FIELDS=Sva polja obaveznog unosa nisu popunjena\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA=Podatke je promijenio drugi korisnik. \\u017Delite li pisati preko promjena drugog korisnika?\r\n\r\n# XMSG: message that will be displayed in case of conflicts during file renaming\r\nMSG_CONFLICTING_FILE_NAME=Naziv datoteke promijenio je drugi korisnik. \\u017Delite li pisati preko promjena drugog korisnika?\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA_WITH_REFRESH=Podatke je promijenio drugi korisnik. Ove promjene pojavit \\u0107e se sada u aplikaciji.\r\n\r\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\r\nMSG_NOT_IN_MAIN_CONTACT=Mo\\u017Eete pregledati samo detalje kontakata koji su dodijeljeni ovom klijentu\r\n\r\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\r\nMSG_EXCEEDING_FILE_NAME_LENGTH=Naziv datoteke mo\\u017Ee imati maksimalno 40 znakova.\r\n\r\n# XTOL, 20: tooltip shown on search result list for button to add an account"\r\n\r\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\r\n\r\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\r\n\r\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\r\n\r\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\r\n\r\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\r\n',
		"cus/crm/myaccounts/i18n/i18n_hu.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XFLD, 30: Facet title for general Data\r\nGENERAL_DATA=\\u00C1ltal\\u00E1nos adatok\r\n\r\n#XTIT, 40: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=Saj\\u00E1t fi\\u00F3kok\r\n\r\n#XTIT, 40: this is the title for the detail screen\r\nDETAIL_TITLE=Fi\\u00F3k\r\n\r\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\r\nREVENUE_CURRENT=Forgalom YTD\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\r\nREVENUE_CURRENT_TOOLTIP=Forgalom m\\u00E1ig (aktu\\u00E1lis \\u00E9v)\r\n\r\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\r\nREVENUE_LAST=Forg. el\\u0151z\\u0151 \\u00E9vben\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\r\nREVENUE_LAST_TOOLTIP=Forgalom az el\\u0151z\\u0151 \\u00E9vben\r\n\r\n# XFLD, 30: Facet title for opportunities and label in facet general data\r\nOPPORTUNITIES=Opportunityk\r\n\r\n#XFLD, 30: Facet title for leads\r\nLEADS=Leadek\r\n\r\n#XFLD, 30: Facet title for tasks\r\nTASKS=Feladatok\r\n\r\n#XFLD, 30: Facet title for appointments\r\nAPPOINTMENTS=Tal\\u00E1lkoz\\u00F3k\r\n\r\n#XFLD, 30: Facet title for quotations\r\nQUOTATIONS=Aj\\u00E1nlatok\r\n\r\n#XFLD, 30: Facet title for sales orders\r\nSALES_ORDERS=Vev\\u0151i rendel\\u00E9sek\r\n\r\n#XFLD, 30: W7: Facet title for marketing attributes\r\nMARKETINGATTRIBUTES=Marketingattrib\\u00FAtumok\r\n\r\n#XFLD, 30: W6: Title for popup with products\r\nPRODUCTS=Term\\u00E9kek\r\n\r\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\r\nEMPLOYEE_RESPONSIBLE=Illet\\u00E9kes dolgoz\\u00F3\r\n\r\n#XFLD, 30: Facet title for Attachments\r\nATTACHMENTS=Mell\\u00E9kletek\r\n\r\n#XFLD, 30: Facet title for Notes\r\nNOTES=Megjegyz\\u00E9sek\r\n\r\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\r\nNEW_NOTE=\\u00DAj jegyzet\r\n\r\n#XFLD, 30: Facet title for Contacts\r\nCONTACTS=Kapcsolatok\r\n\r\n#XFLD, 30: Label for Address in facet general data\r\nADDRESS=C\\u00EDm\r\n\r\n#XFLD, 30: Label for Opportunities in facet general data\r\nUNWEIGHTED_OPPORTUNITIES=Opportunityk\r\n\r\n#XFLD, 30: Label for Rating in facet general data\r\nRATING=Min\\u0151s\\u00EDt\\u00E9s\r\n\r\n# XFLD, 30: Label for Next contact in facet Appointments\r\nNEXT_APPOINTMENT=K\\u00F6vetkez\\u0151 tal\\u00E1lkoz\\u00F3\r\n\r\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\r\nLAST_APPOINTMENT=Utols\\u00F3 tal\\u00E1lkoz\\u00F3\r\n\r\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\r\nIMAGE=K\\u00E9p\r\n\r\n#XBUT, 20: Button to show the create actionsheet\r\nCREATE=L\\u00E9trehoz\\u00E1s\r\n\r\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\r\nDISCUSS_ENTRY=Vita itt\\: SAP Jam\r\n\r\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\r\nSHARE_ENTRY=Megoszt\\u00E1s itt\\: SAP Jam\r\n\r\n#XBUT, 20: Button to share the note\r\nDETAIL_BUTTON_SHARE=Megoszt\\u00E1s\r\n\r\n#XBUT, 20: Button to cancel sharing\r\nDETAIL_BUTTON_CANCEL=M\\u00E9gse\r\n\r\n#XFLD,20: All accounts for filter\r\nALL_ACCOUNTS=\\u00D6sszes \\u00FCgyf\\u00E9l\r\n\r\n#XFLD,35: All individual accounts for filter\r\nALL_INDIVIDUAL_ACCOUNTS=\\u00D6sszes mag\\u00E1n\\u00FCgyf\\u00E9l\r\n\r\n#XFLD,35: All corporate accounts for filter\r\nALL_CORPORATE_ACCOUNTS=\\u00D6sszes v\\u00E1llalati \\u00FCgyf\\u00E9l\r\n\r\n#XFLD,35: All group accounts for filter\r\nALL_ACCOUNT_GROUPS=\\u00D6sszes \\u00FCgyf\\u00E9lcsoport\r\n\r\n#XFLD,20: my account for filter\r\nMY_ACCOUNT=Saj\\u00E1t fi\\u00F3kok\r\n\r\n#XFLD,35: my individual accounts for filter\r\nMY_INDIVIDUAL_ACCOUNTS=Saj\\u00E1t mag\\u00E1n\\u00FCgyfelek\r\n\r\n#XFLD,35: my corporate accounts for filter\r\nMY_CORPORATE_ACCOUNTS=Saj\\u00E1t v\\u00E1llalati \\u00FCgyfelek\r\n\r\n#XFLD,35: my group accounts for filter\r\nMY_ACCOUNT_GROUPS=Saj\\u00E1t \\u00FCgyf\\u00E9lcsoportok\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nINDIVIDUAL_ACCOUNT=Mag\\u00E1nszem\\u00E9ly \\u00FCgyf\\u00E9l\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nCORPORATE_ACCOUNT=V\\u00E1llalati \\u00FCgyf\\u00E9l\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nACCOUNT_GROUP=Sz\\u00E1mlacsoport\r\n\r\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\r\nSTARTING=Ind\\u00EDt\\u00E1s d\\u00E1tuma\\: {0}\r\n\r\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\r\nCLOSING=Z\\u00E1r\\u00F3 d\\u00E1tum\\: {0}\r\n\r\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\r\nDUE=Esed\\u00E9kess\\u00E9gi d\\u00E1tum\\: {0}\r\n\r\n#XFLD,20: All accounts for title\r\nALL_ACCOUNTS_TITLE=\\u00D6sszes sz\\u00E1mla ({0})\r\n\r\n#XFLD,35: All individual accounts for title\r\nALL_INDIVIDUAL_ACCOUNTS_TITLE=\\u00D6sszes priv\\u00E1t \\u00FCgyf\\u00E9l ({0})\r\n\r\n#XFLD,35: All corporate accounts for title\r\nALL_CORPORATE_ACCOUNTS_TITLE=\\u00D6sszes v\\u00E1llalati \\u00FCgyf\\u00E9l ({0})\r\n\r\n#XFLD,35: All group accounts for title\r\nALL_ACCOUNT_GROUPS_TITLE=\\u00D6sszes \\u00FCgyf\\u00E9lcsoport ({0})\r\n\r\n#XFLD,20: my account for title\r\nMY_ACCOUNT_TITLE=Saj\\u00E1t sz\\u00E1ml\\u00E1k ({0})\r\n\r\n#XFLD,35: my individual account for title\r\nMY_INDIVIDUAL_ACCOUNT_TITLE=Saj\\u00E1t priv\\u00E1t \\u00FCgyfelek ({0})\r\n\r\n#XFLD,35: my corporate account for title.\r\nMY_CORPORATE_ACCOUNT_TITLE=Saj\\u00E1t v\\u00E1llalati \\u00FCgyfelek ({0})\r\n\r\n#XFLD,35: my group account for title\r\nMY_ACCOUNT_GROUP_TITLE=Saj\\u00E1t \\u00FCgyf\\u00E9lcsoportok ({0})\r\n\r\n#XFLD,30: filtered by info\r\nFILTERED_BY=Sz\\u0171r\\u00E9s a k\\u00F6vetkez\\u0151 szerint\\: {0}\r\n\r\n#XFLD,30: label, search for accounts\r\nSEARCH_ACCOUNTS=Keres\\u00E9s\r\n\r\n#XFLD,30: comma separator for location\r\nLOCATION={0}, {1}\r\n\r\n#XFLD: W4: Label for All day text in Appointments\r\nALL_DAY_EVENT=Eg\\u00E9sz nap\r\n\r\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\r\nDURATION_MINUTE={0} min\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\r\nDURATION_HOUR={0} h\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\r\nDURATION_DAY={0} nap\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\r\nDURATION_DAYS={0} nap\r\n\r\n#XFLD: W4: Label for Private meeting\r\nPRIVATE=Priv\\u00E1t\r\n\r\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\r\nSELECT_TRANSACTION_TYPE=Tranzakci\\u00F3fajta kiv\\u00E1laszt\\u00E1sa\r\n\r\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\r\nNEW_TASK_INPUT_PLACEHOLDER=\\u00DAj feladat\r\n\r\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nNO_DATA_TEXT=Nincs adat\r\n\r\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nLOADING_TEXT=Bet\\u00F6lt\\u00E9s...\r\n\r\n#XFLD,25: W4: Column label for name of contact person in contacts\r\nNAME=N\\u00E9v\r\n\r\n#XFLD,25: W5: Column label for department of contact person in contacts\r\nDEPARTMENT=Oszt\\u00E1ly\r\n\r\n#XFLD,15: W6: Column label for actions of contact person in contacts\r\nACTIONS=M\\u0171veletek\r\n\r\n#XFLD,25: W4: Column label for description of lead in Leads\r\nDESCRIPTION=Le\\u00EDr\\u00E1s\r\n\r\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\r\nASSIGNED_TO=Hozz\\u00E1rendelve -\r\n\r\n#XFLD,15: W4: Column label for end date of lead in Leads\r\nEND_DATE=Z\\u00E1r\\u00F3 d\\u00E1tum\r\n\r\n#XFLD,15: W4: Column label for qualification level of lead in Leads\r\nQUALIFICATION=Kvalifik\\u00E1ci\\u00F3\r\n\r\n#XFLD,15: W4: Column label for status of lead in Leads\r\nSTATUS=St\\u00E1tus\r\n\r\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\r\nMAIN_CONTACT=F\\u0151 t\\u00E1rgyal\\u00F3partner\r\n\r\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\r\nVOLUME=Mennyis\\u00E9g\r\n\r\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\r\nPROBABILITY=Val\\u00F3sz\\u00EDn\\u0171s\\u00E9g\r\n\r\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\r\nCLOSE_BY=Lez\\u00E1r\\u00E1s eddig\r\n\r\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \r\nVIEWS=N\\u00E9zetek\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\r\nCONTACT_TITLE=T\\u00E1rgyal\\u00F3partner\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\r\nEMPLOYEE_TITLE=Dolgoz\\u00F3\r\n\r\n#XTIT,20: W7: Title of pop-up used in confirm popup\r\nCONFIRM_TITLE=Visszaigazol\\u00E1s\r\n\r\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\r\nCOMPANY_NAME=N\\u00E9v\r\n\r\n#XFLD,20: W4: Label for name 1 of a company used general data\r\nCOMPANY_NAME1=1. n\\u00E9v\r\n\r\n#XFLD,20: W4: Label for name 2 of a company used general data\r\nCOMPANY_NAME2=2. n\\u00E9v\r\n\r\n#XFLD,20: W4: Label for first name of a person used general data\r\nFIRST_NAME=Ut\\u00F3n\\u00E9v\r\n\r\n#XFLD,20: W4: Label for last name of a person used general data\r\nLAST_NAME=Csal\\u00E1dn\\u00E9v\r\n\r\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nBIRTHDAY=Sz\\u00FClet\\u00E9si d\\u00E1tum\r\n\r\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nTITLE=C\\u00EDm\r\n\r\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nACADEMIC_TITLE=Tudom\\u00E1nyos fokozat\r\n\r\n#XFLD,20: W4: Label for mobile phone number used general data\r\nMOBILE=Mobil\r\n\r\n#XFLD,20: W4: Label for phone number used general data\r\nPHONE=Telefon\r\n\r\n#XFLD,20: W4: Label for e-mail used general data\r\nEMAIL=E-mail\r\n\r\n#XFLD,20: W4: Label for web site used general data\r\nWEBSITE=Webhely\r\n\r\n#XFLD,20: W4: Label for country used general data\r\nCOUNTRY=Orsz\\u00E1g\r\n\r\n#XFLD,20: W4: Label for region used general data\r\nREGION=R\\u00E9gi\\u00F3\r\n\r\n#XFLD,20: W4: Label for city used general data\r\nCITY=V\\u00E1ros\r\n\r\n#XFLD,20: W4: Label for postal code used general data\r\nPOSTAL_CODE=Ir\\u00E1ny\\u00EDt\\u00F3sz\\u00E1m\r\n\r\n#XFLD,20: W4: Label for street used general data\r\nSTREET=Utca\r\n\r\n#XFLD,10: W4: Label for house number used general data\r\nHOUSE_NUMBER=H\\u00E1zsz\\u00E1m\r\n\r\n#XFLD,15: W6: Label for ID used in Quotations\r\nID=Azonos\\u00EDt\\u00F3\r\n\r\n#XFLD,15: W6: Label for Amount used in Quotations\r\nAMOUNT=\\u00D6sszeg\r\n\r\n#XFLD,20: W6: Label for Expiration Date used in Quotations\r\nEXPIRATION_DATE=Lej\\u00E1rat d\\u00E1tuma\r\n\r\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\r\nDELIVERY_DATE=Sz\\u00E1ll\\u00EDt\\u00E1si d\\u00E1tum\r\n\r\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\r\nSALES_EMPLOYEE=\\u00C9rt\\u00E9kes\\u00EDt\\u0151\r\n\r\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\r\nATTRIBUTESET=Attrib\\u00FAtumcsoport\r\n\r\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\r\nATTRIBUTE=Attrib\\u00FAtumok\r\n\r\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\r\nVALUE=\\u00C9rt\\u00E9k\r\n\r\n#XBUT, 20: Button to create an Account\r\nBUTTON_ADD=Hozz\\u00E1ad\\u00E1s\r\n\r\n#XBUT, 20: Button to edit an Account\r\nBUTTON_EDIT=Feldolgoz\\u00E1s\r\n\r\n#XBUT, 20: Button to save changes\r\nBUTTON_SAVE=Ment\\u00E9s\r\n\r\n#XBUT, 20: Button to cancel changes\r\nBUTTON_CANCEL=M\\u00E9gse\r\n\r\n#XBUT, 30: Button which shows the personalization buttons\r\nBUTTON_SHOW_PERSONALIZATION=Szem\\u00E9lyre szab\\u00E1s megjelen\\u00EDt\\u00E9se\r\n\r\n#XBUT, 30: Button which hides the personalization buttons\r\nBUTTON_HIDE_PERSONALIZATION=Szem\\u00E9lyre szab\\u00E1s elrejt\\u00E9se\r\n\r\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_CONFIRM_CANCEL=Elv\\u00E9sz minden el nem mentett m\\u00F3dos\\u00EDt\\u00E1s. Szeretn\\u00E9 folytatni?\r\n\r\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\r\nMSG_CONFIRM_DELETE_CONTACT=A kapcsolattart\\u00F3 nem lesz hozz\\u00E1rendelve az \\u00FCgyf\\u00E9lhez. Folytatja?\r\n\r\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_SUCCESS=Fi\\u00F3k aktualiz\\u00E1lva\r\n\r\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_ERROR=Aktualiz\\u00E1l\\u00E1s sikertelen\r\n\r\n# XMSG : Account update succeeded\r\nMSG_CREATION_SUCCESS=Sz\\u00E1mla l\\u00E9trehozva\r\n\r\n# XMSG : Task creation succeeded\r\nMSG_TASK_CREATION_SUCCESS=Feladat l\\u00E9trej\\u00F6tt\r\n\r\n# XMSG : Contact creation failed\r\nMSG_CREATION_ERROR=L\\u00E9trehoz\\u00E1s sikertelen\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong country\r\nMSG_WRONG_COUNTRY_ERROR="{0}" orsz\\u00E1g nem l\\u00E9tezik\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong region\r\nMSG_WRONG_REGION_ERROR="{0}" r\\u00E9gi\\u00F3 nem l\\u00E9tezik az orsz\\u00E1gban\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong employee\r\nMSG_WRONG_EMPLOYEE_ERROR="{0}" dolgoz\\u00F3 nem l\\u00E9tezik.\r\n\r\n# XMSG: message that will be displayed, if the user has entered invalid website url\r\nMSG_WRONG_URL_ERROR=A megadott "{0}" URL \\u00E9rv\\u00E9nytelen.\r\n\r\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\r\nMSG_MANDATORY_FIELDS=Nincs kit\\u00F6ltve az \\u00F6sszes k\\u00F6telez\\u0151 mez\\u0151\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA=Az adatokat egy m\\u00E1sik felhaszn\\u00E1l\\u00F3 m\\u00F3dos\\u00EDtotta. Szeretn\\u00E9 fel\\u00FCl\\u00EDrni ezeket a m\\u00F3dos\\u00EDt\\u00E1sokat?\r\n\r\n# XMSG: message that will be displayed in case of conflicts during file renaming\r\nMSG_CONFLICTING_FILE_NAME=A f\\u00E1jl nev\\u00E9t egy m\\u00E1sik felhaszn\\u00E1l\\u00F3 m\\u00F3dos\\u00EDtotta. Szeretn\\u00E9 fel\\u00FCl\\u00EDrni ezt a m\\u00F3dos\\u00EDt\\u00E1st?\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA_WITH_REFRESH=Az adatokat egy m\\u00E1sik felhaszn\\u00E1l\\u00F3 m\\u00F3dos\\u00EDtotta. Ezek a m\\u00F3dos\\u00EDt\\u00E1sok most m\\u00E1r megjelennek az alkalmaz\\u00E1sban.\r\n\r\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\r\nMSG_NOT_IN_MAIN_CONTACT=Csak a fi\\u00F3khoz rendelt kapcsolattart\\u00F3k adatait l\\u00E1thatja\r\n\r\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\r\nMSG_EXCEEDING_FILE_NAME_LENGTH=A f\\u00E1jln\\u00E9v maximum 40 karaktert tartalmazhat.\r\n\r\n# XTOL, 20: tooltip shown on search result list for button to add an account"\r\nADD_ACCOUNT_TOOLTIP=Fi\\u00F3k hozz\\u00E1ad\\u00E1sa\r\n\r\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\r\nADD_MARKETING_ATTRIBUTE_TOOLTIP=Marketing attrib\\u00FAtum hozz\\u00E1ad\\u00E1sa\r\n\r\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\r\nADD_CONTACT_TOOLTIP=T\\u00E1rgyal\\u00F3partner hozz\\u00E1ad\\u00E1sa\r\n\r\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\r\nADD_APPOINTMENT_TOOLTIP=Id\\u0151pont hozz\\u00E1ad\\u00E1sa\r\n\r\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\r\nADD_TASK_TOOLTIP=Feladat hozz\\u00E1ad\\u00E1sa\r\n\r\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\r\nADD_OPPORTUNITY_TOOLTIP=Opportunity hozz\\u00E1ad\\u00E1sa\r\n',
		"cus/crm/myaccounts/i18n/i18n_it.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XFLD, 30: Facet title for general Data\r\nGENERAL_DATA=Dati generali\r\n\r\n#XTIT, 40: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=I miei clienti\r\n\r\n#XTIT, 40: this is the title for the detail screen\r\nDETAIL_TITLE=Cliente\r\n\r\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\r\nREVENUE_CURRENT=Ricavi ad oggi\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\r\nREVENUE_CURRENT_TOOLTIP=Ricavi fino ad oggi (anno in corso)\r\n\r\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\r\nREVENUE_LAST=Ricavi anno scorso\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\r\nREVENUE_LAST_TOOLTIP=Ricavi anno scorso\r\n\r\n# XFLD, 30: Facet title for opportunities and label in facet general data\r\nOPPORTUNITIES=Opportunit\\u00E0\r\n\r\n#XFLD, 30: Facet title for leads\r\nLEADS=Leads\r\n\r\n#XFLD, 30: Facet title for tasks\r\nTASKS=Tasks\r\n\r\n#XFLD, 30: Facet title for appointments\r\nAPPOINTMENTS=Appuntamenti\r\n\r\n#XFLD, 30: Facet title for quotations\r\nQUOTATIONS=Offerte\r\n\r\n#XFLD, 30: Facet title for sales orders\r\nSALES_ORDERS=Ordini di vendita\r\n\r\n#XFLD, 30: W7: Facet title for marketing attributes\r\nMARKETINGATTRIBUTES=Attributi di marketing\r\n\r\n#XFLD, 30: W6: Title for popup with products\r\nPRODUCTS=Prodotti\r\n\r\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\r\nEMPLOYEE_RESPONSIBLE=Dipendente responsabile\r\n\r\n#XFLD, 30: Facet title for Attachments\r\nATTACHMENTS=Allegati\r\n\r\n#XFLD, 30: Facet title for Notes\r\nNOTES=Note\r\n\r\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\r\nNEW_NOTE=Nuova nota\r\n\r\n#XFLD, 30: Facet title for Contacts\r\nCONTACTS=Contatti\r\n\r\n#XFLD, 30: Label for Address in facet general data\r\nADDRESS=Indirizzo\r\n\r\n#XFLD, 30: Label for Opportunities in facet general data\r\nUNWEIGHTED_OPPORTUNITIES=Opportunit\\u00E0\r\n\r\n#XFLD, 30: Label for Rating in facet general data\r\nRATING=Classificazione\r\n\r\n# XFLD, 30: Label for Next contact in facet Appointments\r\nNEXT_APPOINTMENT=Appuntamento successivo\r\n\r\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\r\nLAST_APPOINTMENT=Ultimo appuntamento\r\n\r\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\r\nIMAGE=Immagine\r\n\r\n#XBUT, 20: Button to show the create actionsheet\r\nCREATE=Crea\r\n\r\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\r\nDISCUSS_ENTRY=Discuti in SAP Jam\r\n\r\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\r\nSHARE_ENTRY=Condividi in SAP Jam\r\n\r\n#XBUT, 20: Button to share the note\r\nDETAIL_BUTTON_SHARE=Condividi\r\n\r\n#XBUT, 20: Button to cancel sharing\r\nDETAIL_BUTTON_CANCEL=Annulla\r\n\r\n#XFLD,20: All accounts for filter\r\nALL_ACCOUNTS=Tutti i clienti\r\n\r\n#XFLD,35: All individual accounts for filter\r\nALL_INDIVIDUAL_ACCOUNTS=Tutti i clienti individuali\r\n\r\n#XFLD,35: All corporate accounts for filter\r\nALL_CORPORATE_ACCOUNTS=Tutti i clienti aziendali\r\n\r\n#XFLD,35: All group accounts for filter\r\nALL_ACCOUNT_GROUPS=Tutti i gruppi di clienti\r\n\r\n#XFLD,20: my account for filter\r\nMY_ACCOUNT=I miei clienti\r\n\r\n#XFLD,35: my individual accounts for filter\r\nMY_INDIVIDUAL_ACCOUNTS=I miei clienti individuali\r\n\r\n#XFLD,35: my corporate accounts for filter\r\nMY_CORPORATE_ACCOUNTS=I miei clienti aziendali\r\n\r\n#XFLD,35: my group accounts for filter\r\nMY_ACCOUNT_GROUPS=I miei gruppi di clienti\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nINDIVIDUAL_ACCOUNT=Cliente privato\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nCORPORATE_ACCOUNT=Cliente organizzazione\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nACCOUNT_GROUP=Gruppo di clienti\r\n\r\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\r\nSTARTING=Data di inizio\\: {0}\r\n\r\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\r\nCLOSING=Data di chiusura\\: {0}\r\n\r\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\r\nDUE=Scadenza\\: {0}\r\n\r\n#XFLD,20: All accounts for title\r\nALL_ACCOUNTS_TITLE=Tutti i clienti ({0})\r\n\r\n#XFLD,35: All individual accounts for title\r\nALL_INDIVIDUAL_ACCOUNTS_TITLE=Tutti i clienti individuali ({0})\r\n\r\n#XFLD,35: All corporate accounts for title\r\nALL_CORPORATE_ACCOUNTS_TITLE=Tutti i clienti aziendali ({0})\r\n\r\n#XFLD,35: All group accounts for title\r\nALL_ACCOUNT_GROUPS_TITLE=Tutti i gruppi di clienti ({0})\r\n\r\n#XFLD,20: my account for title\r\nMY_ACCOUNT_TITLE=I miei clienti ({0})\r\n\r\n#XFLD,35: my individual account for title\r\nMY_INDIVIDUAL_ACCOUNT_TITLE=I miei clienti individuali ({0})\r\n\r\n#XFLD,35: my corporate account for title.\r\nMY_CORPORATE_ACCOUNT_TITLE=I miei clienti aziendali ({0})\r\n\r\n#XFLD,35: my group account for title\r\nMY_ACCOUNT_GROUP_TITLE=I miei gruppi di clienti ({0})\r\n\r\n#XFLD,30: filtered by info\r\nFILTERED_BY=Filtrato in base a\\: {0}\r\n\r\n#XFLD,30: label, search for accounts\r\nSEARCH_ACCOUNTS=Cerca\r\n\r\n#XFLD,30: comma separator for location\r\nLOCATION={0}, {1}\r\n\r\n#XFLD: W4: Label for All day text in Appointments\r\nALL_DAY_EVENT=Tutto il giorno\r\n\r\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\r\nDURATION_MINUTE={0} min\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\r\nDURATION_HOUR={0} h\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\r\nDURATION_DAY={0} giorno\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\r\nDURATION_DAYS={0} giorni\r\n\r\n#XFLD: W4: Label for Private meeting\r\nPRIVATE=Privato\r\n\r\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\r\nSELECT_TRANSACTION_TYPE=Seleziona tipo di transazione\r\n\r\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\r\nNEW_TASK_INPUT_PLACEHOLDER=Nuovo task\r\n\r\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nNO_DATA_TEXT=Nessun dato\r\n\r\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nLOADING_TEXT=In caricamento...\r\n\r\n#XFLD,25: W4: Column label for name of contact person in contacts\r\nNAME=Nome\r\n\r\n#XFLD,25: W5: Column label for department of contact person in contacts\r\nDEPARTMENT=Reparto\r\n\r\n#XFLD,15: W6: Column label for actions of contact person in contacts\r\nACTIONS=Azioni\r\n\r\n#XFLD,25: W4: Column label for description of lead in Leads\r\nDESCRIPTION=Descrizione\r\n\r\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\r\nASSIGNED_TO=Attribuito a\r\n\r\n#XFLD,15: W4: Column label for end date of lead in Leads\r\nEND_DATE=Data di fine\r\n\r\n#XFLD,15: W4: Column label for qualification level of lead in Leads\r\nQUALIFICATION=Qualificazione\r\n\r\n#XFLD,15: W4: Column label for status of lead in Leads\r\nSTATUS=Stato\r\n\r\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\r\nMAIN_CONTACT=Contatto principale\r\n\r\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\r\nVOLUME=Volume\r\n\r\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\r\nPROBABILITY=Probabilit\\u00E0\r\n\r\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\r\nCLOSE_BY=Chiusura per\r\n\r\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \r\nVIEWS=Views\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\r\nCONTACT_TITLE=Contatto\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\r\nEMPLOYEE_TITLE=Dipendente\r\n\r\n#XTIT,20: W7: Title of pop-up used in confirm popup\r\nCONFIRM_TITLE=Conferma\r\n\r\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\r\nCOMPANY_NAME=Nome\r\n\r\n#XFLD,20: W4: Label for name 1 of a company used general data\r\nCOMPANY_NAME1=Nome 1\r\n\r\n#XFLD,20: W4: Label for name 2 of a company used general data\r\nCOMPANY_NAME2=Nome 2\r\n\r\n#XFLD,20: W4: Label for first name of a person used general data\r\nFIRST_NAME=Nome\r\n\r\n#XFLD,20: W4: Label for last name of a person used general data\r\nLAST_NAME=Cognome\r\n\r\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nBIRTHDAY=Data di nascita\r\n\r\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nTITLE=Titolo\r\n\r\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nACADEMIC_TITLE=Titolo accademico\r\n\r\n#XFLD,20: W4: Label for mobile phone number used general data\r\nMOBILE=Cellulare\r\n\r\n#XFLD,20: W4: Label for phone number used general data\r\nPHONE=Telefono\r\n\r\n#XFLD,20: W4: Label for e-mail used general data\r\nEMAIL=E-mail\r\n\r\n#XFLD,20: W4: Label for web site used general data\r\nWEBSITE=Sito Web\r\n\r\n#XFLD,20: W4: Label for country used general data\r\nCOUNTRY=Paese\r\n\r\n#XFLD,20: W4: Label for region used general data\r\nREGION=Regione\r\n\r\n#XFLD,20: W4: Label for city used general data\r\nCITY=Citt\\u00E0\r\n\r\n#XFLD,20: W4: Label for postal code used general data\r\nPOSTAL_CODE=Codice postale\r\n\r\n#XFLD,20: W4: Label for street used general data\r\nSTREET=Via\r\n\r\n#XFLD,10: W4: Label for house number used general data\r\nHOUSE_NUMBER=N. civico\r\n\r\n#XFLD,15: W6: Label for ID used in Quotations\r\nID=ID\r\n\r\n#XFLD,15: W6: Label for Amount used in Quotations\r\nAMOUNT=Importo\r\n\r\n#XFLD,20: W6: Label for Expiration Date used in Quotations\r\nEXPIRATION_DATE=Data di scadenza\r\n\r\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\r\nDELIVERY_DATE=Data di consegna\r\n\r\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\r\nSALES_EMPLOYEE=Addetto alle vendite\r\n\r\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\r\nATTRIBUTESET=Set attributi\r\n\r\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\r\nATTRIBUTE=Attributo\r\n\r\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\r\nVALUE=Valore\r\n\r\n#XBUT, 20: Button to create an Account\r\nBUTTON_ADD=Aggiungi\r\n\r\n#XBUT, 20: Button to edit an Account\r\nBUTTON_EDIT=Elabora\r\n\r\n#XBUT, 20: Button to save changes\r\nBUTTON_SAVE=Salva\r\n\r\n#XBUT, 20: Button to cancel changes\r\nBUTTON_CANCEL=Annulla\r\n\r\n#XBUT, 30: Button which shows the personalization buttons\r\nBUTTON_SHOW_PERSONALIZATION=Visualizza personalizzazione\r\n\r\n#XBUT, 30: Button which hides the personalization buttons\r\nBUTTON_HIDE_PERSONALIZATION=Nascondi personalizzazione\r\n\r\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_CONFIRM_CANCEL=Le modifiche non salvate andranno perse. Continuare?\r\n\r\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\r\nMSG_CONFIRM_DELETE_CONTACT=L\'attribuzione del contatto con il cliente sar\\u00E0 annullata. Proseguire?\r\n\r\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_SUCCESS=Cliente aggiornato\r\n\r\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_ERROR=Aggiornamento non riuscito\r\n\r\n# XMSG : Account update succeeded\r\nMSG_CREATION_SUCCESS=Cliente creato\r\n\r\n# XMSG : Task creation succeeded\r\nMSG_TASK_CREATION_SUCCESS=Task creato\r\n\r\n# XMSG : Contact creation failed\r\nMSG_CREATION_ERROR=Creazione non riuscita\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong country\r\nMSG_WRONG_COUNTRY_ERROR=Il paese "{0}" non esiste\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong region\r\nMSG_WRONG_REGION_ERROR=La regione "{0}" non esiste per il paese\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong employee\r\nMSG_WRONG_EMPLOYEE_ERROR=Il dipendente "{0}" non esiste\r\n\r\n# XMSG: message that will be displayed, if the user has entered invalid website url\r\nMSG_WRONG_URL_ERROR=L\'\'URL "{0}" inserito non \\u00E8 valido.\r\n\r\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\r\nMSG_MANDATORY_FIELDS=Non tutti i campi obbligatori sono stati alimentati\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA=I dati sono stati modificati da un altro utente. Vuoi sovrascrivere le modifiche dell\'altro utente con le tue?\r\n\r\n# XMSG: message that will be displayed in case of conflicts during file renaming\r\nMSG_CONFLICTING_FILE_NAME=Il nome file \\u00E8 stato modificato da un altro utente. Vuoi sovrascrivere le modifiche dell\'altro utente con le tue?\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA_WITH_REFRESH=Dati modificati da un altro utente. Queste modifiche non compariranno nell\'app.\r\n\r\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\r\nMSG_NOT_IN_MAIN_CONTACT=Possibile visualizzare solo i dettagli dei contatti attribuiti a questo account\r\n\r\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\r\nMSG_EXCEEDING_FILE_NAME_LENGTH=Il tuo nome file non pu\\u00F2 superare i 40 caratteri.\r\n\r\n# XTOL, 20: tooltip shown on search result list for button to add an account"\r\n\r\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\r\n\r\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\r\n\r\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\r\n\r\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\r\n\r\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\r\n',
		"cus/crm/myaccounts/i18n/i18n_iw.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XFLD, 30: Facet title for general Data\r\nGENERAL_DATA=\\u05E0\\u05EA\\u05D5\\u05E0\\u05D9\\u05DD \\u05DB\\u05DC\\u05DC\\u05D9\\u05D9\\u05DD\r\n\r\n#XTIT, 40: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=\\u05D4\\u05DC\\u05E7\\u05D5\\u05D7\\u05D5\\u05EA \\u05E9\\u05DC\\u05D9\r\n\r\n#XTIT, 40: this is the title for the detail screen\r\nDETAIL_TITLE=\\u05DC\\u05E7\\u05D5\\u05D7\r\n\r\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\r\nREVENUE_CURRENT=\\u05D4\\u05DB.\\u05E2.\\u05D4\\u05D9\\u05D5\\u05DD \\u05D1.\\u05D4\\u05E0\\u05D5\\u05DB\\u05D7.\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\r\nREVENUE_CURRENT_TOOLTIP=\\u05D4\\u05DB\\u05E0\\u05E1\\u05D5\\u05EA \\u05E2\\u05D3 \\u05D4\\u05D9\\u05D5\\u05DD \\u05D1\\u05E9\\u05E0\\u05D4 \\u05D4\\u05E0\\u05D5\\u05DB\\u05D7\\u05D9\\u05EA\r\n\r\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\r\nREVENUE_LAST=\\u05D4\\u05DB\\u05E0\\u05E1\\u05D5\\u05EA \\u05D1\\u05E9\\u05E0\\u05D4 \\u05D4\\u05E7\\u05D5\\u05D3\\u05DE\\u05EA\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\r\nREVENUE_LAST_TOOLTIP=\\u05D4\\u05DB\\u05E0\\u05E1\\u05D5\\u05EA \\u05D1\\u05E9\\u05E0\\u05D4 \\u05D4\\u05E7\\u05D5\\u05D3\\u05DE\\u05EA\r\n\r\n# XFLD, 30: Facet title for opportunities and label in facet general data\r\nOPPORTUNITIES=\\u05D4\\u05D6\\u05D3\\u05DE\\u05E0\\u05D5\\u05D9\\u05D5\\u05EA\r\n\r\n#XFLD, 30: Facet title for leads\r\nLEADS=\\u05E4\\u05E8\\u05D9\\u05D8\\u05D9 Lead\r\n\r\n#XFLD, 30: Facet title for tasks\r\nTASKS=\\u05DE\\u05E9\\u05D9\\u05DE\\u05D5\\u05EA\r\n\r\n#XFLD, 30: Facet title for appointments\r\nAPPOINTMENTS=\\u05E4\\u05D2\\u05D9\\u05E9\\u05D5\\u05EA\r\n\r\n#XFLD, 30: Facet title for quotations\r\nQUOTATIONS=\\u05D4\\u05E6\\u05E2\\u05D5\\u05EA \\u05DE\\u05D7\\u05D9\\u05E8\r\n\r\n#XFLD, 30: Facet title for sales orders\r\nSALES_ORDERS=\\u05D4\\u05D6\\u05DE\\u05E0\\u05D5\\u05EA \\u05DC\\u05E7\\u05D5\\u05D7\r\n\r\n#XFLD, 30: W7: Facet title for marketing attributes\r\nMARKETINGATTRIBUTES=\\u05EA\\u05DB\\u05D5\\u05E0\\u05D5\\u05EA \\u05E9\\u05D9\\u05D5\\u05D5\\u05E7\r\n\r\n#XFLD, 30: W6: Title for popup with products\r\nPRODUCTS=\\u05DE\\u05D5\\u05E6\\u05E8\\u05D9\\u05DD\r\n\r\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\r\nEMPLOYEE_RESPONSIBLE=\\u05E2\\u05D5\\u05D1\\u05D3 \\u05D0\\u05D7\\u05E8\\u05D0\\u05D9\r\n\r\n#XFLD, 30: Facet title for Attachments\r\nATTACHMENTS=\\u05E7\\u05D1\\u05E6\\u05D9\\u05DD \\u05DE\\u05E6\\u05D5\\u05E8\\u05E4\\u05D9\\u05DD\r\n\r\n#XFLD, 30: Facet title for Notes\r\nNOTES=\\u05D4\\u05E2\\u05E8\\u05D5\\u05EA\r\n\r\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\r\nNEW_NOTE=\\u05D4\\u05E2\\u05E8\\u05D4 \\u05D7\\u05D3\\u05E9\\u05D4\r\n\r\n#XFLD, 30: Facet title for Contacts\r\nCONTACTS=\\u05D0\\u05E0\\u05E9\\u05D9 \\u05E7\\u05E9\\u05E8\r\n\r\n#XFLD, 30: Label for Address in facet general data\r\nADDRESS=\\u05DB\\u05EA\\u05D5\\u05D1\\u05EA\r\n\r\n#XFLD, 30: Label for Opportunities in facet general data\r\nUNWEIGHTED_OPPORTUNITIES=\\u05D4\\u05D6\\u05D3\\u05DE\\u05E0\\u05D5\\u05D9\\u05D5\\u05EA\r\n\r\n#XFLD, 30: Label for Rating in facet general data\r\nRATING=\\u05D3\\u05D9\\u05E8\\u05D5\\u05D2\r\n\r\n# XFLD, 30: Label for Next contact in facet Appointments\r\nNEXT_APPOINTMENT=\\u05D4\\u05E4\\u05D2\\u05D9\\u05E9\\u05D4 \\u05D4\\u05D1\\u05D0\\u05D4\r\n\r\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\r\nLAST_APPOINTMENT=\\u05E4\\u05D2\\u05D9\\u05E9\\u05D4 \\u05D0\\u05D7\\u05E8\\u05D5\\u05E0\\u05D4\r\n\r\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\r\nIMAGE=\\u05EA\\u05DE\\u05D5\\u05E0\\u05D4\r\n\r\n#XBUT, 20: Button to show the create actionsheet\r\nCREATE=\\u05E6\\u05D5\\u05E8\r\n\r\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\r\nDISCUSS_ENTRY=\\u05D3\\u05D5\\u05DF \\u05D1-SAP Jam\r\n\r\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\r\nSHARE_ENTRY=\\u05E9\\u05EA\\u05E3 \\u05D1-SAP Jam\r\n\r\n#XBUT, 20: Button to share the note\r\nDETAIL_BUTTON_SHARE=\\u05E9\\u05EA\\u05E3\r\n\r\n#XBUT, 20: Button to cancel sharing\r\nDETAIL_BUTTON_CANCEL=\\u05D1\\u05D8\\u05DC\r\n\r\n#XFLD,20: All accounts for filter\r\nALL_ACCOUNTS=\\u05DB\\u05DC \\u05D4\\u05DC\\u05E7\\u05D5\\u05D7\\u05D5\\u05EA\r\n\r\n#XFLD,35: All individual accounts for filter\r\nALL_INDIVIDUAL_ACCOUNTS=\\u05DB\\u05DC \\u05D4\\u05DC\\u05E7\\u05D5\\u05D7\\u05D5\\u05EA \\u05D4\\u05E4\\u05E8\\u05D8\\u05D9\\u05D9\\u05DD\r\n\r\n#XFLD,35: All corporate accounts for filter\r\nALL_CORPORATE_ACCOUNTS=\\u05DB\\u05DC \\u05D4\\u05DC\\u05E7\\u05D5\\u05D7\\u05D5\\u05EA \\u05D4\\u05E2\\u05E1\\u05E7\\u05D9\\u05D9\\u05DD\r\n\r\n#XFLD,35: All group accounts for filter\r\nALL_ACCOUNT_GROUPS=\\u05DB\\u05DC \\u05E7\\u05D1\\u05D5\\u05E6\\u05D5\\u05EA \\u05D4\\u05DC\\u05E7\\u05D5\\u05D7\\u05D5\\u05EA\r\n\r\n#XFLD,20: my account for filter\r\nMY_ACCOUNT=\\u05D4\\u05DC\\u05E7\\u05D5\\u05D7\\u05D5\\u05EA \\u05E9\\u05DC\\u05D9\r\n\r\n#XFLD,35: my individual accounts for filter\r\nMY_INDIVIDUAL_ACCOUNTS=\\u05D4\\u05DC\\u05E7\\u05D5\\u05D7\\u05D5\\u05EA \\u05D4\\u05E4\\u05E8\\u05D8\\u05D9\\u05D9\\u05DD \\u05E9\\u05DC\\u05D9\r\n\r\n#XFLD,35: my corporate accounts for filter\r\nMY_CORPORATE_ACCOUNTS=\\u05DB\\u05DC \\u05D4\\u05DC\\u05E7\\u05D5\\u05D7\\u05D5\\u05EA \\u05D4\\u05E2\\u05E1\\u05E7\\u05D9\\u05D9\\u05DD \\u05E9\\u05DC\\u05D9\r\n\r\n#XFLD,35: my group accounts for filter\r\nMY_ACCOUNT_GROUPS=\\u05DB\\u05DC \\u05E7\\u05D1\\u05D5\\u05E6\\u05D5\\u05EA \\u05D4\\u05DC\\u05E7\\u05D5\\u05D7\\u05D5\\u05EA \\u05E9\\u05DC\\u05D9\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nINDIVIDUAL_ACCOUNT=\\u05DC\\u05E7\\u05D5\\u05D7 \\u05E4\\u05E8\\u05D8\\u05D9\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nCORPORATE_ACCOUNT=\\u05DC\\u05E7\\u05D5\\u05D7 \\u05E2\\u05E1\\u05E7\\u05D9\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nACCOUNT_GROUP=\\u05E7\\u05D1\\u05D5\\u05E6\\u05EA \\u05DC\\u05E7\\u05D5\\u05D7\\u05D5\\u05EA\r\n\r\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\r\nSTARTING=\\u05EA\\u05D0\\u05E8\\u05D9\\u05DA \\u05D4\\u05EA\\u05D7\\u05DC\\u05D4\\: {0}\r\n\r\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\r\nCLOSING=\\u05EA\\u05D0\\u05E8\\u05D9\\u05DA \\u05E1\\u05D2\\u05D9\\u05E8\\u05D4\\: {0}\r\n\r\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\r\nDUE=\\u05EA\\u05D0\\u05E8\\u05D9\\u05DA \\u05D9\\u05E2\\u05D3\\: {0}\r\n\r\n#XFLD,20: All accounts for title\r\nALL_ACCOUNTS_TITLE=\\u05DB\\u05DC \\u05D4\\u05DC\\u05E7\\u05D5\\u05D7\\u05D5\\u05EA ({0})\r\n\r\n#XFLD,35: All individual accounts for title\r\nALL_INDIVIDUAL_ACCOUNTS_TITLE=\\u05DB\\u05DC \\u05D4\\u05DC\\u05E7\\u05D5\\u05D7\\u05D5\\u05EA \\u05D4\\u05E4\\u05E8\\u05D8\\u05D9\\u05D9\\u05DD ({0})\r\n\r\n#XFLD,35: All corporate accounts for title\r\nALL_CORPORATE_ACCOUNTS_TITLE=\\u05DB\\u05DC \\u05D4\\u05DC\\u05E7\\u05D5\\u05D7\\u05D5\\u05EA \\u05D4\\u05E2\\u05E1\\u05E7\\u05D9\\u05D9\\u05DD ({0})\r\n\r\n#XFLD,35: All group accounts for title\r\nALL_ACCOUNT_GROUPS_TITLE=\\u05DB\\u05DC \\u05E7\\u05D1\\u05D5\\u05E6\\u05D5\\u05EA \\u05D4\\u05DC\\u05E7\\u05D5\\u05D7\\u05D5\\u05EA ({0})\r\n\r\n#XFLD,20: my account for title\r\nMY_ACCOUNT_TITLE=\\u05D4\\u05DC\\u05E7\\u05D5\\u05D7\\u05D5\\u05EA \\u05E9\\u05DC\\u05D9 ({0})\r\n\r\n#XFLD,35: my individual account for title\r\nMY_INDIVIDUAL_ACCOUNT_TITLE=\\u05D4\\u05DC\\u05E7\\u05D5\\u05D7\\u05D5\\u05EA \\u05D4\\u05E4\\u05E8\\u05D8\\u05D9\\u05D9\\u05DD \\u05E9\\u05DC\\u05D9 ({0})\r\n\r\n#XFLD,35: my corporate account for title.\r\nMY_CORPORATE_ACCOUNT_TITLE=\\u05D4\\u05DC\\u05E7\\u05D5\\u05D7\\u05D5\\u05EA \\u05D4\\u05E2\\u05E1\\u05E7\\u05D9\\u05D9\\u05DD \\u05E9\\u05DC\\u05D9 ({0})\r\n\r\n#XFLD,35: my group account for title\r\nMY_ACCOUNT_GROUP_TITLE=\\u05DB\\u05DC \\u05E7\\u05D1\\u05D5\\u05E6\\u05D5\\u05EA \\u05D4\\u05DC\\u05E7\\u05D5\\u05D7\\u05D5\\u05EA \\u05E9\\u05DC\\u05D9 ({0})\r\n\r\n#XFLD,30: filtered by info\r\nFILTERED_BY=\\u05E1\\u05D5\\u05E0\\u05DF \\u05DC\\u05E4\\u05D9\\: {0}\r\n\r\n#XFLD,30: label, search for accounts\r\nSEARCH_ACCOUNTS=\\u05D7\\u05E4\\u05E9\r\n\r\n#XFLD,30: comma separator for location\r\nLOCATION={0}, {1}\r\n\r\n#XFLD: W4: Label for All day text in Appointments\r\nALL_DAY_EVENT=\\u05DB\\u05DC \\u05D4\\u05D9\\u05D5\\u05DD\r\n\r\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\r\nDURATION_MINUTE={0} \\u05D3\\u05E7\\u05D5\\u05EA\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\r\nDURATION_HOUR={0} \\u05E9\\u05E2\\u05D5\\u05EA\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\r\nDURATION_DAY=\\u05D9\\u05D5\\u05DD {0} \r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\r\nDURATION_DAYS={0} \\u05D9\\u05DE\\u05D9\\u05DD\r\n\r\n#XFLD: W4: Label for Private meeting\r\nPRIVATE=\\u05E4\\u05E8\\u05D8\\u05D9\r\n\r\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\r\nSELECT_TRANSACTION_TYPE=\\u05D1\\u05D7\\u05E8 \\u05E1\\u05D5\\u05D2 \\u05EA\\u05E0\\u05D5\\u05E2\\u05D4\r\n\r\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\r\nNEW_TASK_INPUT_PLACEHOLDER=\\u05DE\\u05E9\\u05D9\\u05DE\\u05D4 \\u05D7\\u05D3\\u05E9\\u05D4\r\n\r\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nNO_DATA_TEXT=\\u05D0\\u05D9\\u05DF \\u05E0\\u05EA\\u05D5\\u05E0\\u05D9\\u05DD\r\n\r\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nLOADING_TEXT=\\u05D8\\u05D5\\u05E2\\u05DF...\r\n\r\n#XFLD,25: W4: Column label for name of contact person in contacts\r\nNAME=\\u05E9\\u05DD\r\n\r\n#XFLD,25: W5: Column label for department of contact person in contacts\r\nDEPARTMENT=\\u05DE\\u05D7\\u05DC\\u05E7\\u05D4\r\n\r\n#XFLD,15: W6: Column label for actions of contact person in contacts\r\nACTIONS=\\u05E4\\u05E2\\u05D5\\u05DC\\u05D5\\u05EA\r\n\r\n#XFLD,25: W4: Column label for description of lead in Leads\r\nDESCRIPTION=\\u05EA\\u05D9\\u05D0\\u05D5\\u05E8\r\n\r\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\r\nASSIGNED_TO=\\u05DE\\u05D5\\u05E7\\u05E6\\u05D4 \\u05DC-\r\n\r\n#XFLD,15: W4: Column label for end date of lead in Leads\r\nEND_DATE=\\u05EA\\u05D0\\u05E8\\u05D9\\u05DA \\u05E1\\u05D9\\u05D5\\u05DD\r\n\r\n#XFLD,15: W4: Column label for qualification level of lead in Leads\r\nQUALIFICATION=\\u05D4\\u05E2\\u05E8\\u05DB\\u05D4\r\n\r\n#XFLD,15: W4: Column label for status of lead in Leads\r\nSTATUS=\\u05E1\\u05D8\\u05D0\\u05D8\\u05D5\\u05E1\r\n\r\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\r\nMAIN_CONTACT=\\u05D0\\u05D9\\u05E9 \\u05E7\\u05E9\\u05E8 \\u05E8\\u05D0\\u05E9\\u05D9\r\n\r\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\r\nVOLUME=\\u05E0\\u05E4\\u05D7\r\n\r\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\r\nPROBABILITY=\\u05D4\\u05E1\\u05EA\\u05D1\\u05E8\\u05D5\\u05EA\r\n\r\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\r\nCLOSE_BY=\\u05E1\\u05D2\\u05D5\\u05E8 \\u05E2\\u05D3\r\n\r\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \r\nVIEWS=\\u05EA\\u05E6\\u05D5\\u05D2\\u05D5\\u05EA\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\r\nCONTACT_TITLE=\\u05D0\\u05D9\\u05E9 \\u05E7\\u05E9\\u05E8\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\r\nEMPLOYEE_TITLE=\\u05E2\\u05D5\\u05D1\\u05D3\r\n\r\n#XTIT,20: W7: Title of pop-up used in confirm popup\r\nCONFIRM_TITLE=\\u05D0\\u05E9\\u05E8\r\n\r\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\r\nCOMPANY_NAME=\\u05E9\\u05DD\r\n\r\n#XFLD,20: W4: Label for name 1 of a company used general data\r\nCOMPANY_NAME1=\\u05E9\\u05DD 1\r\n\r\n#XFLD,20: W4: Label for name 2 of a company used general data\r\nCOMPANY_NAME2=\\u05E9\\u05DD 2\r\n\r\n#XFLD,20: W4: Label for first name of a person used general data\r\nFIRST_NAME=\\u05E9\\u05DD \\u05E4\\u05E8\\u05D8\\u05D9\r\n\r\n#XFLD,20: W4: Label for last name of a person used general data\r\nLAST_NAME=\\u05E9\\u05DD \\u05DE\\u05E9\\u05E4\\u05D7\\u05D4\r\n\r\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nBIRTHDAY=\\u05EA\\u05D0\\u05E8\\u05D9\\u05DA \\u05DC\\u05D9\\u05D3\\u05D4\r\n\r\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nTITLE=\\u05DB\\u05D5\\u05EA\\u05E8\\u05EA\r\n\r\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nACADEMIC_TITLE=\\u05EA\\u05D5\\u05D0\\u05E8 \\u05D0\\u05E7\\u05D3\\u05DE\\u05D9\r\n\r\n#XFLD,20: W4: Label for mobile phone number used general data\r\nMOBILE=\\u05D8\\u05DC\\u05E4\\u05D5\\u05DF \\u05E0\\u05D9\\u05D9\\u05D3\r\n\r\n#XFLD,20: W4: Label for phone number used general data\r\nPHONE=\\u05D8\\u05DC\\u05E4\\u05D5\\u05DF\r\n\r\n#XFLD,20: W4: Label for e-mail used general data\r\nEMAIL=\\u05D3\\u05D5\\u05D0"\\u05DC\r\n\r\n#XFLD,20: W4: Label for web site used general data\r\nWEBSITE=\\u05D0\\u05EA\\u05E8 \\u05D0\\u05D9\\u05E0\\u05D8\\u05E8\\u05E0\\u05D8\r\n\r\n#XFLD,20: W4: Label for country used general data\r\nCOUNTRY=\\u05DE\\u05D3\\u05D9\\u05E0\\u05D4\r\n\r\n#XFLD,20: W4: Label for region used general data\r\nREGION=\\u05D0\\u05D6\\u05D5\\u05E8\r\n\r\n#XFLD,20: W4: Label for city used general data\r\nCITY=\\u05E2\\u05D9\\u05E8\r\n\r\n#XFLD,20: W4: Label for postal code used general data\r\nPOSTAL_CODE=\\u05DE\\u05D9\\u05E7\\u05D5\\u05D3\r\n\r\n#XFLD,20: W4: Label for street used general data\r\nSTREET=\\u05E8\\u05D7\\u05D5\\u05D1\r\n\r\n#XFLD,10: W4: Label for house number used general data\r\nHOUSE_NUMBER=\\u05DE\\u05E1\\u05E4\\u05E8 \\u05D1\\u05D9\\u05EA\r\n\r\n#XFLD,15: W6: Label for ID used in Quotations\r\nID=\\u05D6\\u05D9\\u05D4\\u05D5\\u05D9\r\n\r\n#XFLD,15: W6: Label for Amount used in Quotations\r\nAMOUNT=\\u05E1\\u05DB\\u05D5\\u05DD\r\n\r\n#XFLD,20: W6: Label for Expiration Date used in Quotations\r\nEXPIRATION_DATE=\\u05EA\\u05D0\\u05E8\\u05D9\\u05DA \\u05EA\\u05E4\\u05D5\\u05D2\\u05D4\r\n\r\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\r\nDELIVERY_DATE=\\u05EA\\u05D0\\u05E8\\u05D9\\u05DA \\u05D0\\u05E1\\u05E4\\u05E7\\u05D4\r\n\r\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\r\nSALES_EMPLOYEE=\\u05E2\\u05D5\\u05D1\\u05D3 \\u05DE\\u05DB\\u05D9\\u05E8\\u05D5\\u05EA\r\n\r\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\r\nATTRIBUTESET=\\u05E1\\u05D8 \\u05EA\\u05DB\\u05D5\\u05E0\\u05D5\\u05EA\r\n\r\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\r\nATTRIBUTE=\\u05EA\\u05DB\\u05D5\\u05E0\\u05D4\r\n\r\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\r\nVALUE=\\u05E2\\u05E8\\u05DA\r\n\r\n#XBUT, 20: Button to create an Account\r\nBUTTON_ADD=\\u05D4\\u05D5\\u05E1\\u05E3\r\n\r\n#XBUT, 20: Button to edit an Account\r\nBUTTON_EDIT=\\u05E2\\u05E8\\u05D5\\u05DA\r\n\r\n#XBUT, 20: Button to save changes\r\nBUTTON_SAVE=\\u05E9\\u05DE\\u05D5\\u05E8\r\n\r\n#XBUT, 20: Button to cancel changes\r\nBUTTON_CANCEL=\\u05D1\\u05D8\\u05DC\r\n\r\n#XBUT, 30: Button which shows the personalization buttons\r\nBUTTON_SHOW_PERSONALIZATION=\\u05D4\\u05E6\\u05D2 \\u05D4\\u05EA\\u05D0\\u05DE\\u05D4 \\u05D0\\u05D9\\u05E9\\u05D9\\u05EA\r\n\r\n#XBUT, 30: Button which hides the personalization buttons\r\nBUTTON_HIDE_PERSONALIZATION=\\u05D4\\u05E1\\u05EA\\u05E8 \\u05D4\\u05EA\\u05D0\\u05DE\\u05D4 \\u05D0\\u05D9\\u05E9\\u05D9\\u05EA\r\n\r\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_CONFIRM_CANCEL=\\u05DB\\u05DC \\u05D4\\u05E9\\u05D9\\u05E0\\u05D5\\u05D9\\u05D9\\u05DD \\u05E9\\u05DC\\u05D0 \\u05E0\\u05E9\\u05DE\\u05E8\\u05D5 \\u05D9\\u05D0\\u05D1\\u05D3\\u05D5. \\u05D4\\u05D0\\u05DD \\u05D1\\u05E8\\u05E6\\u05D5\\u05E0\\u05DA \\u05DC\\u05D4\\u05DE\\u05E9\\u05D9\\u05DA?\r\n\r\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\r\nMSG_CONFIRM_DELETE_CONTACT=\\u05EA\\u05D5\\u05E1\\u05E8 \\u05D4\\u05E7\\u05E6\\u05D0\\u05EA \\u05D0\\u05D9\\u05E9 \\u05D4\\u05E7\\u05E9\\u05E8 \\u05DE\\u05D4\\u05DC\\u05E7\\u05D5\\u05D7. \\u05D4\\u05D0\\u05DD \\u05D1\\u05E8\\u05E6\\u05D5\\u05E0\\u05DA \\u05DC\\u05D4\\u05DE\\u05E9\\u05D9\\u05DA?\r\n\r\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_SUCCESS=\\u05D4\\u05DC\\u05E7\\u05D5\\u05D7 \\u05E2\\u05D5\\u05D3\\u05DB\\u05DF\r\n\r\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_ERROR=\\u05E2\\u05D3\\u05DB\\u05D5\\u05DF \\u05E0\\u05DB\\u05E9\\u05DC\r\n\r\n# XMSG : Account update succeeded\r\nMSG_CREATION_SUCCESS=\\u05D4\\u05DC\\u05E7\\u05D5\\u05D7 \\u05E0\\u05D5\\u05E6\\u05E8\r\n\r\n# XMSG : Task creation succeeded\r\nMSG_TASK_CREATION_SUCCESS=\\u05DE\\u05E9\\u05D9\\u05DE\\u05D4 \\u05E0\\u05D5\\u05E6\\u05E8\\u05D4\r\n\r\n# XMSG : Contact creation failed\r\nMSG_CREATION_ERROR=\\u05D9\\u05E6\\u05D9\\u05E8\\u05D4 \\u05E0\\u05DB\\u05E9\\u05DC\\u05D4\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong country\r\nMSG_WRONG_COUNTRY_ERROR=\\u05D4\\u05DE\\u05D3\\u05D9\\u05E0\\u05D4 "{0}" \\u05DC\\u05D0 \\u05E7\\u05D9\\u05D9\\u05DE\\u05EA\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong region\r\nMSG_WRONG_REGION_ERROR=\\u05D4\\u05D0\\u05D6\\u05D5\\u05E8 "{0}" \\u05DC\\u05D0 \\u05E7\\u05D9\\u05D9\\u05DD \\u05E2\\u05D1\\u05D5\\u05E8 \\u05D4\\u05DE\\u05D3\\u05D9\\u05E0\\u05D4\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong employee\r\nMSG_WRONG_EMPLOYEE_ERROR=\\u05D4\\u05E2\\u05D5\\u05D1\\u05D3 "{0}" \\u05DC\\u05D0 \\u05E7\\u05D9\\u05D9\\u05DD.\r\n\r\n# XMSG: message that will be displayed, if the user has entered invalid website url\r\nMSG_WRONG_URL_ERROR=\\u05DB\\u05EA\\u05D5\\u05D1\\u05EA \\u05D4-URL \\u05E9\\u05D4\\u05D5\\u05D6\\u05E0\\u05D4 "{0}" \\u05DC\\u05D0 \\u05D7\\u05D5\\u05E7\\u05D9\\u05EA.\r\n\r\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\r\nMSG_MANDATORY_FIELDS=\\u05DC\\u05D0 \\u05DB\\u05DC \\u05E9\\u05D3\\u05D5\\u05EA \\u05D4\\u05D7\\u05D5\\u05D1\\u05D4 \\u05DE\\u05D5\\u05DC\\u05D0\\u05D5\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA=\\u05D4\\u05E0\\u05EA\\u05D5\\u05E0\\u05D9\\u05DD \\u05E9\\u05D5\\u05E0\\u05D5 \\u05E2\\u05DC-\\u05D9\\u05D3\\u05D9 \\u05DE\\u05E9\\u05EA\\u05DE\\u05E9 \\u05D0\\u05D7\\u05E8. \\u05D4\\u05D0\\u05DD \\u05D1\\u05E8\\u05E6\\u05D5\\u05E0\\u05DA \\u05DC\\u05E9\\u05DB\\u05EA\\u05D1 \\u05D0\\u05EA \\u05D4\\u05E9\\u05D9\\u05E0\\u05D5\\u05D9\\u05D9\\u05DD \\u05E9\\u05DC \\u05D4\\u05DE\\u05E9\\u05EA\\u05DE\\u05E9 \\u05D5\\u05DC\\u05E8\\u05E9\\u05D5\\u05DD \\u05D0\\u05EA \\u05D4\\u05E9\\u05D9\\u05E0\\u05D5\\u05D9\\u05D9\\u05DD \\u05E9\\u05DC\\u05DA?\r\n\r\n# XMSG: message that will be displayed in case of conflicts during file renaming\r\nMSG_CONFLICTING_FILE_NAME=\\u05E9\\u05DD \\u05D4\\u05E7\\u05D5\\u05D1\\u05E5 \\u05E9\\u05D5\\u05E0\\u05D4 \\u05E2\\u05DC-\\u05D9\\u05D3\\u05D9 \\u05DE\\u05E9\\u05EA\\u05DE\\u05E9 \\u05D0\\u05D7\\u05E8. \\u05D4\\u05D0\\u05DD \\u05D1\\u05E8\\u05E6\\u05D5\\u05E0\\u05DA \\u05DC\\u05E9\\u05DB\\u05EA\\u05D1 \\u05D0\\u05EA \\u05D4\\u05E9\\u05D9\\u05E0\\u05D5\\u05D9\\u05D9\\u05DD \\u05E9\\u05DC \\u05D4\\u05DE\\u05E9\\u05EA\\u05DE\\u05E9 \\u05D5\\u05DC\\u05E8\\u05E9\\u05D5\\u05DD \\u05D0\\u05EA \\u05D4\\u05E9\\u05D9\\u05E0\\u05D5\\u05D9\\u05D9\\u05DD \\u05E9\\u05DC\\u05DA?\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA_WITH_REFRESH=\\u05D4\\u05E0\\u05EA\\u05D5\\u05E0\\u05D9\\u05DD \\u05E9\\u05D5\\u05E0\\u05D5 \\u05E2\\u05DC-\\u05D9\\u05D3\\u05D9 \\u05DE\\u05E9\\u05EA\\u05DE\\u05E9 \\u05D0\\u05D7\\u05E8. \\u05E9\\u05D9\\u05E0\\u05D5\\u05D9\\u05D9\\u05DD \\u05D0\\u05DC\\u05D4 \\u05DC\\u05D0 \\u05D5\\u05D9\\u05E4\\u05D9\\u05E2\\u05D5 \\u05D1\\u05D9\\u05D9\\u05E9\\u05D5\\u05DD\r\n\r\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\r\nMSG_NOT_IN_MAIN_CONTACT=\\u05EA\\u05D5\\u05DB\\u05DC \\u05DC\\u05D4\\u05E6\\u05D9\\u05D2 \\u05E8\\u05E7 \\u05D0\\u05EA \\u05D4\\u05E4\\u05E8\\u05D8\\u05D9\\u05DD \\u05E9\\u05DC \\u05D0\\u05E0\\u05E9\\u05D9 \\u05D4\\u05E7\\u05E9\\u05E8 \\u05D4\\u05DE\\u05D5\\u05E7\\u05E6\\u05D9\\u05DD \\u05DC\\u05DC\\u05E7\\u05D5\\u05D7 \\u05D6\\u05D4\r\n\r\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\r\nMSG_EXCEEDING_FILE_NAME_LENGTH=\\u05E9\\u05DD \\u05D4\\u05E7\\u05D5\\u05D1\\u05E5 \\u05E9\\u05DC\\u05DA \\u05D9\\u05DB\\u05D5\\u05DC \\u05DC\\u05D4\\u05DB\\u05D9\\u05DC \\u05E2\\u05D3 40 \\u05EA\\u05D5\\u05D5\\u05D9\\u05DD.\r\n\r\n# XTOL, 20: tooltip shown on search result list for button to add an account"\r\n\r\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\r\n\r\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\r\n\r\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\r\n\r\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\r\n\r\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\r\n',
		"cus/crm/myaccounts/i18n/i18n_ja.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XFLD, 30: Facet title for general Data\r\nGENERAL_DATA=\\u4E00\\u822C\\u30C7\\u30FC\\u30BF\r\n\r\n#XTIT, 40: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=\\u9867\\u5BA2\r\n\r\n#XTIT, 40: this is the title for the detail screen\r\nDETAIL_TITLE=\\u9867\\u5BA2\r\n\r\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\r\nREVENUE_CURRENT=\\u53CE\\u76CA (\\u5E74\\u521D\\u6765)\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\r\nREVENUE_CURRENT_TOOLTIP=\\u73FE\\u5728\\u307E\\u3067\\u306E\\u53CE\\u76CA (\\u5F53\\u5E74\\u5EA6)\r\n\r\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\r\nREVENUE_LAST=\\u53CE\\u76CA (\\u524D\\u5E74\\u5EA6)\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\r\nREVENUE_LAST_TOOLTIP=\\u53CE\\u76CA (\\u524D\\u5E74\\u5EA6)\r\n\r\n# XFLD, 30: Facet title for opportunities and label in facet general data\r\nOPPORTUNITIES=\\u6848\\u4EF6\r\n\r\n#XFLD, 30: Facet title for leads\r\nLEADS=\\u30EA\\u30FC\\u30C9\r\n\r\n#XFLD, 30: Facet title for tasks\r\nTASKS=\\u30BF\\u30B9\\u30AF\r\n\r\n#XFLD, 30: Facet title for appointments\r\nAPPOINTMENTS=\\u4E88\\u5B9A\r\n\r\n#XFLD, 30: Facet title for quotations\r\nQUOTATIONS=\\u898B\\u7A4D\r\n\r\n#XFLD, 30: Facet title for sales orders\r\nSALES_ORDERS=\\u53D7\\u6CE8\r\n\r\n#XFLD, 30: W7: Facet title for marketing attributes\r\nMARKETINGATTRIBUTES=\\u30DE\\u30FC\\u30B1\\u30C6\\u30A3\\u30F3\\u30B0\\u5C5E\\u6027\r\n\r\n#XFLD, 30: W6: Title for popup with products\r\nPRODUCTS=\\u88FD\\u54C1\r\n\r\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\r\nEMPLOYEE_RESPONSIBLE=\\u7BA1\\u7406\\u8CAC\\u4EFB\\u8005\r\n\r\n#XFLD, 30: Facet title for Attachments\r\nATTACHMENTS=\\u6DFB\\u4ED8\\u6587\\u66F8\r\n\r\n#XFLD, 30: Facet title for Notes\r\nNOTES=\\u30E1\\u30E2\r\n\r\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\r\nNEW_NOTE=\\u65B0\\u898F\\u30E1\\u30E2\r\n\r\n#XFLD, 30: Facet title for Contacts\r\nCONTACTS=\\u53D6\\u5F15\\u5148\\u62C5\\u5F53\\u8005\r\n\r\n#XFLD, 30: Label for Address in facet general data\r\nADDRESS=\\u30A2\\u30C9\\u30EC\\u30B9\r\n\r\n#XFLD, 30: Label for Opportunities in facet general data\r\nUNWEIGHTED_OPPORTUNITIES=\\u6848\\u4EF6\r\n\r\n#XFLD, 30: Label for Rating in facet general data\r\nRATING=\\u683C\\u4ED8\r\n\r\n# XFLD, 30: Label for Next contact in facet Appointments\r\nNEXT_APPOINTMENT=\\u6B21\\u56DE\\u306E\\u4E88\\u5B9A\r\n\r\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\r\nLAST_APPOINTMENT=\\u524D\\u56DE\\u306E\\u4E88\\u5B9A\r\n\r\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\r\nIMAGE=\\u30A4\\u30E1\\u30FC\\u30B8\r\n\r\n#XBUT, 20: Button to show the create actionsheet\r\nCREATE=\\u767B\\u9332\r\n\r\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\r\nDISCUSS_ENTRY=SAP Jam \\u3067\\u30C7\\u30A3\\u30B9\\u30AB\\u30C3\\u30B7\\u30E7\\u30F3\r\n\r\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\r\nSHARE_ENTRY=SAP Jam \\u3067\\u5171\\u6709\r\n\r\n#XBUT, 20: Button to share the note\r\nDETAIL_BUTTON_SHARE=\\u5171\\u6709\r\n\r\n#XBUT, 20: Button to cancel sharing\r\nDETAIL_BUTTON_CANCEL=\\u4E2D\\u6B62\r\n\r\n#XFLD,20: All accounts for filter\r\nALL_ACCOUNTS=\\u3059\\u3079\\u3066\\u306E\\u9867\\u5BA2\r\n\r\n#XFLD,35: All individual accounts for filter\r\nALL_INDIVIDUAL_ACCOUNTS=\\u3059\\u3079\\u3066\\u306E\\u500B\\u4EBA\\u9867\\u5BA2\r\n\r\n#XFLD,35: All corporate accounts for filter\r\nALL_CORPORATE_ACCOUNTS=\\u3059\\u3079\\u3066\\u306E\\u6CD5\\u4EBA\\u9867\\u5BA2\r\n\r\n#XFLD,35: All group accounts for filter\r\nALL_ACCOUNT_GROUPS=\\u3059\\u3079\\u3066\\u306E\\u9867\\u5BA2\\u30B0\\u30EB\\u30FC\\u30D7\r\n\r\n#XFLD,20: my account for filter\r\nMY_ACCOUNT=My \\u9867\\u5BA2\r\n\r\n#XFLD,35: my individual accounts for filter\r\nMY_INDIVIDUAL_ACCOUNTS=My \\u500B\\u4EBA\\u9867\\u5BA2\r\n\r\n#XFLD,35: my corporate accounts for filter\r\nMY_CORPORATE_ACCOUNTS=My \\u6CD5\\u4EBA\\u9867\\u5BA2\r\n\r\n#XFLD,35: my group accounts for filter\r\nMY_ACCOUNT_GROUPS=My \\u9867\\u5BA2\\u30B0\\u30EB\\u30FC\\u30D7\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nINDIVIDUAL_ACCOUNT=\\u500B\\u4EBA\\u9867\\u5BA2\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nCORPORATE_ACCOUNT=\\u6CD5\\u4EBA\\u9867\\u5BA2\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nACCOUNT_GROUP=\\u9867\\u5BA2\\u30B0\\u30EB\\u30FC\\u30D7\r\n\r\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\r\nSTARTING=\\u958B\\u59CB\\u65E5\\u4ED8\\:  {0}\r\n\r\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\r\nCLOSING=\\u898B\\u8FBC\\u6210\\u7D04\\u65E5\\:  {0}\r\n\r\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\r\nDUE=\\u671F\\u65E5\\:  {0}\r\n\r\n#XFLD,20: All accounts for title\r\nALL_ACCOUNTS_TITLE=\\u3059\\u3079\\u3066\\u306E\\u9867\\u5BA2 ({0})\r\n\r\n#XFLD,35: All individual accounts for title\r\nALL_INDIVIDUAL_ACCOUNTS_TITLE=\\u3059\\u3079\\u3066\\u306E\\u500B\\u4EBA\\u9867\\u5BA2 ({0})\r\n\r\n#XFLD,35: All corporate accounts for title\r\nALL_CORPORATE_ACCOUNTS_TITLE=\\u3059\\u3079\\u3066\\u306E\\u6CD5\\u4EBA\\u9867\\u5BA2 ({0})\r\n\r\n#XFLD,35: All group accounts for title\r\nALL_ACCOUNT_GROUPS_TITLE=\\u3059\\u3079\\u3066\\u306E\\u9867\\u5BA2\\u30B0\\u30EB\\u30FC\\u30D7 ({0})\r\n\r\n#XFLD,20: my account for title\r\nMY_ACCOUNT_TITLE=My \\u9867\\u5BA2 ({0})\r\n\r\n#XFLD,35: my individual account for title\r\nMY_INDIVIDUAL_ACCOUNT_TITLE=My \\u500B\\u4EBA\\u9867\\u5BA2 ({0})\r\n\r\n#XFLD,35: my corporate account for title.\r\nMY_CORPORATE_ACCOUNT_TITLE=My \\u6CD5\\u4EBA\\u9867\\u5BA2 ({0})\r\n\r\n#XFLD,35: my group account for title\r\nMY_ACCOUNT_GROUP_TITLE=My \\u9867\\u5BA2\\u30B0\\u30EB\\u30FC\\u30D7 ({0})\r\n\r\n#XFLD,30: filtered by info\r\nFILTERED_BY=\\u30D5\\u30A3\\u30EB\\u30BF\\u57FA\\u6E96\\:  {0}\r\n\r\n#XFLD,30: label, search for accounts\r\nSEARCH_ACCOUNTS=\\u691C\\u7D22\r\n\r\n#XFLD,30: comma separator for location\r\nLOCATION={0}, {1}\r\n\r\n#XFLD: W4: Label for All day text in Appointments\r\nALL_DAY_EVENT=\\u7D42\\u65E5\r\n\r\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\r\nDURATION_MINUTE={0} \\u5206\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\r\nDURATION_HOUR={0} \\u6642\\u9593\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\r\nDURATION_DAY={0} \\u65E5\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\r\nDURATION_DAYS={0} \\u65E5\r\n\r\n#XFLD: W4: Label for Private meeting\r\nPRIVATE=\\u975E\\u516C\\u958B\r\n\r\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\r\nSELECT_TRANSACTION_TYPE=\\u30C8\\u30E9\\u30F3\\u30B6\\u30AF\\u30B7\\u30E7\\u30F3\\u30BF\\u30A4\\u30D7\\u9078\\u629E\r\n\r\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\r\nNEW_TASK_INPUT_PLACEHOLDER=\\u65B0\\u898F\\u30BF\\u30B9\\u30AF\r\n\r\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nNO_DATA_TEXT=\\u30C7\\u30FC\\u30BF\\u306A\\u3057\r\n\r\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nLOADING_TEXT=\\u30ED\\u30FC\\u30C9\\u4E2D...\r\n\r\n#XFLD,25: W4: Column label for name of contact person in contacts\r\nNAME=\\u6C0F\\u540D\r\n\r\n#XFLD,25: W5: Column label for department of contact person in contacts\r\nDEPARTMENT=\\u90E8\\u9580\r\n\r\n#XFLD,15: W6: Column label for actions of contact person in contacts\r\nACTIONS=\\u30A2\\u30AF\\u30B7\\u30E7\\u30F3\r\n\r\n#XFLD,25: W4: Column label for description of lead in Leads\r\nDESCRIPTION=\\u30C6\\u30AD\\u30B9\\u30C8\r\n\r\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\r\nASSIGNED_TO=\\u5272\\u5F53\\u5148\r\n\r\n#XFLD,15: W4: Column label for end date of lead in Leads\r\nEND_DATE=\\u7D42\\u4E86\\u65E5\\u4ED8\r\n\r\n#XFLD,15: W4: Column label for qualification level of lead in Leads\r\nQUALIFICATION=\\u9078\\u5B9A\r\n\r\n#XFLD,15: W4: Column label for status of lead in Leads\r\nSTATUS=\\u30B9\\u30C6\\u30FC\\u30BF\\u30B9\r\n\r\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\r\nMAIN_CONTACT=\\u4E3B\\u8981\\u53D6\\u5F15\\u5148\\u62C5\\u5F53\\u8005\r\n\r\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\r\nVOLUME=\\u91D1\\u984D\r\n\r\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\r\nPROBABILITY=\\u53D7\\u6CE8\\u53EF\\u80FD\\u6027\r\n\r\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\r\nCLOSE_BY=\\u6210\\u7D04\\u671F\\u9650\r\n\r\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \r\nVIEWS=\\u30D3\\u30E5\\u30FC\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\r\nCONTACT_TITLE=\\u53D6\\u5F15\\u5148\\u62C5\\u5F53\\u8005\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\r\nEMPLOYEE_TITLE=\\u5F93\\u696D\\u54E1\r\n\r\n#XTIT,20: W7: Title of pop-up used in confirm popup\r\nCONFIRM_TITLE=\\u78BA\\u8A8D\r\n\r\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\r\nCOMPANY_NAME=\\u540D\\u79F0\r\n\r\n#XFLD,20: W4: Label for name 1 of a company used general data\r\nCOMPANY_NAME1=\\u540D\\u79F0 1\r\n\r\n#XFLD,20: W4: Label for name 2 of a company used general data\r\nCOMPANY_NAME2=\\u540D\\u79F0 2\r\n\r\n#XFLD,20: W4: Label for first name of a person used general data\r\nFIRST_NAME=\\u540D\r\n\r\n#XFLD,20: W4: Label for last name of a person used general data\r\nLAST_NAME=\\u59D3\r\n\r\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nBIRTHDAY=\\u751F\\u5E74\\u6708\\u65E5\r\n\r\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nTITLE=\\u8868\\u984C\r\n\r\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nACADEMIC_TITLE=\\u5B66\\u4F4D\\u79F0\\u53F7\r\n\r\n#XFLD,20: W4: Label for mobile phone number used general data\r\nMOBILE=\\u643A\\u5E2F\\u96FB\\u8A71\r\n\r\n#XFLD,20: W4: Label for phone number used general data\r\nPHONE=\\u96FB\\u8A71\r\n\r\n#XFLD,20: W4: Label for e-mail used general data\r\nEMAIL=\\u30E1\\u30FC\\u30EB\r\n\r\n#XFLD,20: W4: Label for web site used general data\r\nWEBSITE=Web \\u30B5\\u30A4\\u30C8\r\n\r\n#XFLD,20: W4: Label for country used general data\r\nCOUNTRY=\\u56FD\r\n\r\n#XFLD,20: W4: Label for region used general data\r\nREGION=\\u5730\\u57DF\r\n\r\n#XFLD,20: W4: Label for city used general data\r\nCITY=\\u5E02\\u533A\\u753A\\u6751\r\n\r\n#XFLD,20: W4: Label for postal code used general data\r\nPOSTAL_CODE=\\u90F5\\u4FBF\\u756A\\u53F7\r\n\r\n#XFLD,20: W4: Label for street used general data\r\nSTREET=\\u5730\\u540D\r\n\r\n#XFLD,10: W4: Label for house number used general data\r\nHOUSE_NUMBER=\\u756A\\u5730-\\u53F7\r\n\r\n#XFLD,15: W6: Label for ID used in Quotations\r\nID=ID\r\n\r\n#XFLD,15: W6: Label for Amount used in Quotations\r\nAMOUNT=\\u91D1\\u984D\r\n\r\n#XFLD,20: W6: Label for Expiration Date used in Quotations\r\nEXPIRATION_DATE=\\u6709\\u52B9\\u671F\\u9650\r\n\r\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\r\nDELIVERY_DATE=\\u7D0D\\u5165\\u65E5\\u4ED8\r\n\r\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\r\nSALES_EMPLOYEE=\\u55B6\\u696D\\u54E1\r\n\r\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\r\nATTRIBUTESET=\\u5C5E\\u6027\\u30BB\\u30C3\\u30C8\r\n\r\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\r\nATTRIBUTE=\\u5C5E\\u6027\r\n\r\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\r\nVALUE=\\u5024\r\n\r\n#XBUT, 20: Button to create an Account\r\nBUTTON_ADD=\\u8FFD\\u52A0\r\n\r\n#XBUT, 20: Button to edit an Account\r\nBUTTON_EDIT=\\u7DE8\\u96C6\r\n\r\n#XBUT, 20: Button to save changes\r\nBUTTON_SAVE=\\u4FDD\\u5B58\r\n\r\n#XBUT, 20: Button to cancel changes\r\nBUTTON_CANCEL=\\u4E2D\\u6B62\r\n\r\n#XBUT, 30: Button which shows the personalization buttons\r\nBUTTON_SHOW_PERSONALIZATION=\\u30D1\\u30FC\\u30BD\\u30CA\\u30E9\\u30A4\\u30BC\\u30FC\\u30B7\\u30E7\\u30F3\\u8868\\u793A\r\n\r\n#XBUT, 30: Button which hides the personalization buttons\r\nBUTTON_HIDE_PERSONALIZATION=\\u30D1\\u30FC\\u30BD\\u30CA\\u30E9\\u30A4\\u30BC\\u30FC\\u30B7\\u30E7\\u30F3\\u975E\\u8868\\u793A\r\n\r\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_CONFIRM_CANCEL=\\u672A\\u4FDD\\u5B58\\u306E\\u5909\\u66F4\\u306F\\u5931\\u308F\\u308C\\u307E\\u3059\\u3002\\u7D9A\\u884C\\u3057\\u307E\\u3059\\u304B\\u3002\r\n\r\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\r\nMSG_CONFIRM_DELETE_CONTACT=\\u53D6\\u5F15\\u5148\\u62C5\\u5F53\\u8005\\u304C\\u9867\\u5BA2\\u304B\\u3089\\u5272\\u5F53\\u89E3\\u9664\\u3055\\u308C\\u307E\\u3059\\u3002\\u7D9A\\u884C\\u3057\\u307E\\u3059\\u304B\\u3002\r\n\r\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_SUCCESS=\\u9867\\u5BA2\\u304C\\u66F4\\u65B0\\u3055\\u308C\\u307E\\u3057\\u305F\r\n\r\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_ERROR=\\u66F4\\u65B0\\u3067\\u304D\\u307E\\u305B\\u3093\\u3067\\u3057\\u305F\r\n\r\n# XMSG : Account update succeeded\r\nMSG_CREATION_SUCCESS=\\u9867\\u5BA2\\u304C\\u767B\\u9332\\u3055\\u308C\\u307E\\u3057\\u305F\r\n\r\n# XMSG : Task creation succeeded\r\nMSG_TASK_CREATION_SUCCESS=\\u30BF\\u30B9\\u30AF\\u304C\\u767B\\u9332\\u3055\\u308C\\u307E\\u3057\\u305F\r\n\r\n# XMSG : Contact creation failed\r\nMSG_CREATION_ERROR=\\u767B\\u9332\\u3067\\u304D\\u307E\\u305B\\u3093\\u3067\\u3057\\u305F\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong country\r\nMSG_WRONG_COUNTRY_ERROR=\\u56FD "{0}" \\u306F\\u5B58\\u5728\\u3057\\u307E\\u305B\\u3093\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong region\r\nMSG_WRONG_REGION_ERROR=\\u3053\\u306E\\u56FD\\u306B\\u5730\\u57DF "{0}" \\u306F\\u5B58\\u5728\\u3057\\u307E\\u305B\\u3093\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong employee\r\nMSG_WRONG_EMPLOYEE_ERROR=\\u5F93\\u696D\\u54E1 "{0}" \\u306F\\u5B58\\u5728\\u3057\\u307E\\u305B\\u3093\\u3002\r\n\r\n# XMSG: message that will be displayed, if the user has entered invalid website url\r\nMSG_WRONG_URL_ERROR=\\u5165\\u529B\\u3055\\u308C\\u305F URL "{0}" \\u306F\\u7121\\u52B9\\u3067\\u3059\\u3002\r\n\r\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\r\nMSG_MANDATORY_FIELDS=\\u4E00\\u90E8\\u306E\\u5165\\u529B\\u5FC5\\u9808\\u9805\\u76EE\\u304C\\u5165\\u529B\\u3055\\u308C\\u3066\\u3044\\u307E\\u305B\\u3093\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA=\\u30C7\\u30FC\\u30BF\\u306F\\u5225\\u306E\\u30E6\\u30FC\\u30B6\\u306B\\u3088\\u308A\\u5909\\u66F4\\u3055\\u308C\\u3066\\u3044\\u307E\\u3059\\u3002\\u3053\\u306E\\u30E6\\u30FC\\u30B6\\u306B\\u3088\\u308B\\u5909\\u66F4\\u3092\\u81EA\\u5206\\u306E\\u5909\\u66F4\\u3067\\u4E0A\\u66F8\\u304D\\u3057\\u307E\\u3059\\u304B\\u3002\r\n\r\n# XMSG: message that will be displayed in case of conflicts during file renaming\r\nMSG_CONFLICTING_FILE_NAME=\\u30D5\\u30A1\\u30A4\\u30EB\\u540D\\u306F\\u5225\\u306E\\u30E6\\u30FC\\u30B6\\u306B\\u3088\\u308A\\u5909\\u66F4\\u3055\\u308C\\u3066\\u3044\\u307E\\u3059\\u3002\\u3053\\u306E\\u30E6\\u30FC\\u30B6\\u306B\\u3088\\u308B\\u5909\\u66F4\\u3092\\u81EA\\u5206\\u306E\\u5909\\u66F4\\u3067\\u4E0A\\u66F8\\u304D\\u3057\\u307E\\u3059\\u304B\\u3002\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA_WITH_REFRESH=\\u30C7\\u30FC\\u30BF\\u306F\\u5225\\u306E\\u30E6\\u30FC\\u30B6\\u306B\\u3088\\u308A\\u5909\\u66F4\\u3055\\u308C\\u3066\\u3044\\u307E\\u3059\\u3002\\u3053\\u308C\\u3089\\u306E\\u5909\\u66F4\\u304C\\u30A2\\u30D7\\u30EA\\u306B\\u8868\\u793A\\u3055\\u308C\\u307E\\u3059\\u3002\r\n\r\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\r\nMSG_NOT_IN_MAIN_CONTACT=\\u3053\\u306E\\u9867\\u5BA2\\u306B\\u5272\\u308A\\u5F53\\u3066\\u3089\\u308C\\u3066\\u3044\\u308B\\u53D6\\u5F15\\u5148\\u62C5\\u5F53\\u8005\\u306E\\u8A73\\u7D30\\u306E\\u307F\\u7167\\u4F1A\\u3059\\u308B\\u3053\\u3068\\u304C\\u3067\\u304D\\u307E\\u3059\r\n\r\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\r\nMSG_EXCEEDING_FILE_NAME_LENGTH=\\u30D5\\u30A1\\u30A4\\u30EB\\u540D\\u306B\\u306F\\u6700\\u5927 40 \\u6587\\u5B57\\u8A2D\\u5B9A\\u3059\\u308B\\u3053\\u3068\\u304C\\u3067\\u304D\\u307E\\u3059\\u3002\r\n\r\n# XTOL, 20: tooltip shown on search result list for button to add an account"\r\n\r\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\r\n\r\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\r\n\r\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\r\n\r\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\r\n\r\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\r\n',
		"cus/crm/myaccounts/i18n/i18n_no.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XFLD, 30: Facet title for general Data\r\nGENERAL_DATA=Generelle data\r\n\r\n#XTIT, 40: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=Mine kunder\r\n\r\n#XTIT, 40: this is the title for the detail screen\r\nDETAIL_TITLE=Kunde\r\n\r\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\r\nREVENUE_CURRENT=Omsetn. dette \\u00E5ret\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\r\nREVENUE_CURRENT_TOOLTIP=Omsetning til dato innev\\u00E6rende \\u00E5r\r\n\r\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\r\nREVENUE_LAST=Omsetn. forrige \\u00E5r\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\r\nREVENUE_LAST_TOOLTIP=Omsetning forrige \\u00E5r\r\n\r\n# XFLD, 30: Facet title for opportunities and label in facet general data\r\nOPPORTUNITIES=Salgsmuligheter\r\n\r\n#XFLD, 30: Facet title for leads\r\nLEADS=Lead\r\n\r\n#XFLD, 30: Facet title for tasks\r\nTASKS=Oppgaver\r\n\r\n#XFLD, 30: Facet title for appointments\r\nAPPOINTMENTS=Avtaler\r\n\r\n#XFLD, 30: Facet title for quotations\r\nQUOTATIONS=Tilbud\r\n\r\n#XFLD, 30: Facet title for sales orders\r\nSALES_ORDERS=Kundeordrer\r\n\r\n#XFLD, 30: W7: Facet title for marketing attributes\r\nMARKETINGATTRIBUTES=Markedsf\\u00F8ringsattributter\r\n\r\n#XFLD, 30: W6: Title for popup with products\r\nPRODUCTS=Produkter\r\n\r\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\r\nEMPLOYEE_RESPONSIBLE=Ansvarlig medarbeider\r\n\r\n#XFLD, 30: Facet title for Attachments\r\nATTACHMENTS=Vedlegg\r\n\r\n#XFLD, 30: Facet title for Notes\r\nNOTES=Merknader\r\n\r\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\r\nNEW_NOTE=Ny merknad\r\n\r\n#XFLD, 30: Facet title for Contacts\r\nCONTACTS=Kontakter\r\n\r\n#XFLD, 30: Label for Address in facet general data\r\nADDRESS=Adresse\r\n\r\n#XFLD, 30: Label for Opportunities in facet general data\r\nUNWEIGHTED_OPPORTUNITIES=Salgsmuligheter\r\n\r\n#XFLD, 30: Label for Rating in facet general data\r\nRATING=Vurdering\r\n\r\n# XFLD, 30: Label for Next contact in facet Appointments\r\nNEXT_APPOINTMENT=Neste avtale\r\n\r\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\r\nLAST_APPOINTMENT=Siste avtale\r\n\r\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\r\nIMAGE=Bilde\r\n\r\n#XBUT, 20: Button to show the create actionsheet\r\nCREATE=Opprett\r\n\r\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\r\nDISCUSS_ENTRY=Diskuter p\\u00E5 SAP Jam\r\n\r\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\r\nSHARE_ENTRY=Del p\\u00E5 SAP Jam\r\n\r\n#XBUT, 20: Button to share the note\r\nDETAIL_BUTTON_SHARE=Del\r\n\r\n#XBUT, 20: Button to cancel sharing\r\nDETAIL_BUTTON_CANCEL=Avbryt\r\n\r\n#XFLD,20: All accounts for filter\r\nALL_ACCOUNTS=Alle kunder\r\n\r\n#XFLD,35: All individual accounts for filter\r\nALL_INDIVIDUAL_ACCOUNTS=Alle personkunder\r\n\r\n#XFLD,35: All corporate accounts for filter\r\nALL_CORPORATE_ACCOUNTS=Alle bedriftskunder\r\n\r\n#XFLD,35: All group accounts for filter\r\nALL_ACCOUNT_GROUPS=Alle kontogrupper\r\n\r\n#XFLD,20: my account for filter\r\nMY_ACCOUNT=Mine kunder\r\n\r\n#XFLD,35: my individual accounts for filter\r\nMY_INDIVIDUAL_ACCOUNTS=Mine personkunder\r\n\r\n#XFLD,35: my corporate accounts for filter\r\nMY_CORPORATE_ACCOUNTS=Mine bedriftskunder\r\n\r\n#XFLD,35: my group accounts for filter\r\nMY_ACCOUNT_GROUPS=Mine kontogrupper\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nINDIVIDUAL_ACCOUNT=Individuell konto\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nCORPORATE_ACCOUNT=Firmakonto\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nACCOUNT_GROUP=Kontogruppe\r\n\r\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\r\nSTARTING=Startdato\\: {0}\r\n\r\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\r\nCLOSING=Avslutningsdato\\: {0}\r\n\r\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\r\nDUE=Forfallsdato\\: {0}\r\n\r\n#XFLD,20: All accounts for title\r\nALL_ACCOUNTS_TITLE=Alle kunder ({0})\r\n\r\n#XFLD,35: All individual accounts for title\r\nALL_INDIVIDUAL_ACCOUNTS_TITLE=Alle personkunder ({0})\r\n\r\n#XFLD,35: All corporate accounts for title\r\nALL_CORPORATE_ACCOUNTS_TITLE=Alle bedriftskunder ({0})\r\n\r\n#XFLD,35: All group accounts for title\r\nALL_ACCOUNT_GROUPS_TITLE=Alle kontogrupper ({0})\r\n\r\n#XFLD,20: my account for title\r\nMY_ACCOUNT_TITLE=Mine kunder ({0})\r\n\r\n#XFLD,35: my individual account for title\r\nMY_INDIVIDUAL_ACCOUNT_TITLE=Mine personkunder ({0})\r\n\r\n#XFLD,35: my corporate account for title.\r\nMY_CORPORATE_ACCOUNT_TITLE=Mine bedriftskunder ({0})\r\n\r\n#XFLD,35: my group account for title\r\nMY_ACCOUNT_GROUP_TITLE=Mine kontogrupper ({0})\r\n\r\n#XFLD,30: filtered by info\r\nFILTERED_BY=Filtrert etter\\: {0}\r\n\r\n#XFLD,30: label, search for accounts\r\nSEARCH_ACCOUNTS=S\\u00F8k\r\n\r\n#XFLD,30: comma separator for location\r\nLOCATION={0}, {1}\r\n\r\n#XFLD: W4: Label for All day text in Appointments\r\nALL_DAY_EVENT=Hele dagen\r\n\r\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\r\nDURATION_MINUTE={0} min\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\r\nDURATION_HOUR={0} t\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\r\nDURATION_DAY={0} dag\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\r\nDURATION_DAYS={0} dager\r\n\r\n#XFLD: W4: Label for Private meeting\r\nPRIVATE=Privat\r\n\r\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\r\nSELECT_TRANSACTION_TYPE=Velg transaksjonstype\r\n\r\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\r\nNEW_TASK_INPUT_PLACEHOLDER=Ny oppgave\r\n\r\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nNO_DATA_TEXT=Ingen data\r\n\r\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nLOADING_TEXT=Laster ...\r\n\r\n#XFLD,25: W4: Column label for name of contact person in contacts\r\nNAME=Navn\r\n\r\n#XFLD,25: W5: Column label for department of contact person in contacts\r\nDEPARTMENT=Avdeling\r\n\r\n#XFLD,15: W6: Column label for actions of contact person in contacts\r\nACTIONS=Aktiviteter\r\n\r\n#XFLD,25: W4: Column label for description of lead in Leads\r\nDESCRIPTION=Beskrivelse\r\n\r\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\r\nASSIGNED_TO=Tilordnet til\r\n\r\n#XFLD,15: W4: Column label for end date of lead in Leads\r\nEND_DATE=Sluttdato\r\n\r\n#XFLD,15: W4: Column label for qualification level of lead in Leads\r\nQUALIFICATION=Kvalifisering\r\n\r\n#XFLD,15: W4: Column label for status of lead in Leads\r\nSTATUS=Status\r\n\r\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\r\nMAIN_CONTACT=Hovedkontakt\r\n\r\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\r\nVOLUME=Volum\r\n\r\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\r\nPROBABILITY=Sannsynlighet\r\n\r\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\r\nCLOSE_BY=Avslutning innen\r\n\r\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \r\nVIEWS=Visninger\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\r\nCONTACT_TITLE=Kontakt\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\r\nEMPLOYEE_TITLE=Medarbeider\r\n\r\n#XTIT,20: W7: Title of pop-up used in confirm popup\r\nCONFIRM_TITLE=Bekreft\r\n\r\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\r\nCOMPANY_NAME=Navn\r\n\r\n#XFLD,20: W4: Label for name 1 of a company used general data\r\nCOMPANY_NAME1=Navn 1\r\n\r\n#XFLD,20: W4: Label for name 2 of a company used general data\r\nCOMPANY_NAME2=Navn 2\r\n\r\n#XFLD,20: W4: Label for first name of a person used general data\r\nFIRST_NAME=Fornavn\r\n\r\n#XFLD,20: W4: Label for last name of a person used general data\r\nLAST_NAME=Etternavn\r\n\r\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nBIRTHDAY=F\\u00F8dselsdato\r\n\r\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nTITLE=Tittel\r\n\r\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nACADEMIC_TITLE=Akademisk tittel\r\n\r\n#XFLD,20: W4: Label for mobile phone number used general data\r\nMOBILE=Mobil\r\n\r\n#XFLD,20: W4: Label for phone number used general data\r\nPHONE=Telefon\r\n\r\n#XFLD,20: W4: Label for e-mail used general data\r\nEMAIL=E-post\r\n\r\n#XFLD,20: W4: Label for web site used general data\r\nWEBSITE=Nettsted\r\n\r\n#XFLD,20: W4: Label for country used general data\r\nCOUNTRY=Land\r\n\r\n#XFLD,20: W4: Label for region used general data\r\nREGION=Region\r\n\r\n#XFLD,20: W4: Label for city used general data\r\nCITY=Sted\r\n\r\n#XFLD,20: W4: Label for postal code used general data\r\nPOSTAL_CODE=Postnummer\r\n\r\n#XFLD,20: W4: Label for street used general data\r\nSTREET=Gate/vei\r\n\r\n#XFLD,10: W4: Label for house number used general data\r\nHOUSE_NUMBER=Husnr.\r\n\r\n#XFLD,15: W6: Label for ID used in Quotations\r\nID=ID\r\n\r\n#XFLD,15: W6: Label for Amount used in Quotations\r\nAMOUNT=Bel\\u00F8p\r\n\r\n#XFLD,20: W6: Label for Expiration Date used in Quotations\r\nEXPIRATION_DATE=Utl\\u00F8psdato\r\n\r\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\r\nDELIVERY_DATE=Leveringsdato\r\n\r\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\r\nSALES_EMPLOYEE=Salgsmedarbeider\r\n\r\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\r\nATTRIBUTESET=Attributtsett\r\n\r\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\r\nATTRIBUTE=Attributt\r\n\r\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\r\nVALUE=Verdi\r\n\r\n#XBUT, 20: Button to create an Account\r\nBUTTON_ADD=Tilf\\u00F8y\r\n\r\n#XBUT, 20: Button to edit an Account\r\nBUTTON_EDIT=Rediger\r\n\r\n#XBUT, 20: Button to save changes\r\nBUTTON_SAVE=Lagre\r\n\r\n#XBUT, 20: Button to cancel changes\r\nBUTTON_CANCEL=Avbryt\r\n\r\n#XBUT, 30: Button which shows the personalization buttons\r\nBUTTON_SHOW_PERSONALIZATION=Vis personlighetstilpasning\r\n\r\n#XBUT, 30: Button which hides the personalization buttons\r\nBUTTON_HIDE_PERSONALIZATION=Skjul personlighetstilpasning\r\n\r\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_CONFIRM_CANCEL=Ikke lagrede endringer vil g\\u00E5 tapt. Fortsette?\r\n\r\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\r\nMSG_CONFIRM_DELETE_CONTACT=Kontakten vil miste tilordning til konto. Fortsette?\r\n\r\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_SUCCESS=Konto oppdatert\r\n\r\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_ERROR=Oppdatering mislyktes\r\n\r\n# XMSG : Account update succeeded\r\nMSG_CREATION_SUCCESS=Konto opprettet\r\n\r\n# XMSG : Task creation succeeded\r\nMSG_TASK_CREATION_SUCCESS=Oppgave opprettet\r\n\r\n# XMSG : Contact creation failed\r\nMSG_CREATION_ERROR=Oppretting mislyktes\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong country\r\nMSG_WRONG_COUNTRY_ERROR=Land "{0}" finnes ikke\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong region\r\nMSG_WRONG_REGION_ERROR=Region "{0}" finnes ikke for land\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong employee\r\nMSG_WRONG_EMPLOYEE_ERROR=Medarbeider "{0}" finnes ikke\r\n\r\n# XMSG: message that will be displayed, if the user has entered invalid website url\r\nMSG_WRONG_URL_ERROR=Oppgitt URL "{0}" er ikke gyldig.\r\n\r\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\r\nMSG_MANDATORY_FIELDS=Alle obligatoriske felt er ikke utfylt\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA=En annen bruker har endret dataene. Vil du overskrive endringene til den andre brukeren med dine egne?\r\n\r\n# XMSG: message that will be displayed in case of conflicts during file renaming\r\nMSG_CONFLICTING_FILE_NAME=En annen bruker har endret filnavnet. Vil du overskrive endringene til den andre brukeren med dine egne?\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA_WITH_REFRESH=Data er endret av en annen bruker. Disse endringene vil n\\u00E5 synes i appen.\r\n\r\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\r\nMSG_NOT_IN_MAIN_CONTACT=Du kan bare vise detaljer for kontaktpersoner som er tilordnet til denne kunden\r\n\r\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\r\nMSG_EXCEEDING_FILE_NAME_LENGTH=Filnavnet ditt kan ha maksimalt 40 tegn\r\n\r\n# XTOL, 20: tooltip shown on search result list for button to add an account"\r\n\r\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\r\n\r\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\r\n\r\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\r\n\r\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\r\n\r\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\r\n',
		"cus/crm/myaccounts/i18n/i18n_pl.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XFLD, 30: Facet title for general Data\r\nGENERAL_DATA=Dane og\\u00F3lne\r\n\r\n#XTIT, 40: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=Moi klienci\r\n\r\n#XTIT, 40: this is the title for the detail screen\r\nDETAIL_TITLE=Klient\r\n\r\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\r\nREVENUE_CURRENT=Prz. od pocz. roku\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\r\nREVENUE_CURRENT_TOOLTIP=Przych\\u00F3d do dzi\\u015B bie\\u017C\\u0105cego roku\r\n\r\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\r\nREVENUE_LAST=Prz. w zesz\\u0142. roku\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\r\nREVENUE_LAST_TOOLTIP=Przych\\u00F3d w zesz\\u0142ym roku\r\n\r\n# XFLD, 30: Facet title for opportunities and label in facet general data\r\nOPPORTUNITIES=Szanse\r\n\r\n#XFLD, 30: Facet title for leads\r\nLEADS=Potencjalne szanse\r\n\r\n#XFLD, 30: Facet title for tasks\r\nTASKS=Zadania\r\n\r\n#XFLD, 30: Facet title for appointments\r\nAPPOINTMENTS=Spotkania\r\n\r\n#XFLD, 30: Facet title for quotations\r\nQUOTATIONS=Oferty\r\n\r\n#XFLD, 30: Facet title for sales orders\r\nSALES_ORDERS=Zlecenia klienta\r\n\r\n#XFLD, 30: W7: Facet title for marketing attributes\r\nMARKETINGATTRIBUTES=Atrybuty marketingowe\r\n\r\n#XFLD, 30: W6: Title for popup with products\r\nPRODUCTS=Produkty\r\n\r\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\r\nEMPLOYEE_RESPONSIBLE=Odpowiedzialny pracownik\r\n\r\n#XFLD, 30: Facet title for Attachments\r\nATTACHMENTS=Za\\u0142\\u0105czniki\r\n\r\n#XFLD, 30: Facet title for Notes\r\nNOTES=Notatki\r\n\r\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\r\nNEW_NOTE=Nowa notatka\r\n\r\n#XFLD, 30: Facet title for Contacts\r\nCONTACTS=Kontakty\r\n\r\n#XFLD, 30: Label for Address in facet general data\r\nADDRESS=Adres\r\n\r\n#XFLD, 30: Label for Opportunities in facet general data\r\nUNWEIGHTED_OPPORTUNITIES=Szanse\r\n\r\n#XFLD, 30: Label for Rating in facet general data\r\nRATING=Ocena\r\n\r\n# XFLD, 30: Label for Next contact in facet Appointments\r\nNEXT_APPOINTMENT=Nast\\u0119pne spotkanie\r\n\r\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\r\nLAST_APPOINTMENT=Ostatnie spotkanie\r\n\r\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\r\nIMAGE=Obraz\r\n\r\n#XBUT, 20: Button to show the create actionsheet\r\nCREATE=Utw\\u00F3rz\r\n\r\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\r\nDISCUSS_ENTRY=Om\\u00F3w za pomoc\\u0105 SAP Jam\r\n\r\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\r\nSHARE_ENTRY=Udost\\u0119pnij w SAP Jam\r\n\r\n#XBUT, 20: Button to share the note\r\nDETAIL_BUTTON_SHARE=Udost\\u0119pnij\r\n\r\n#XBUT, 20: Button to cancel sharing\r\nDETAIL_BUTTON_CANCEL=Anuluj\r\n\r\n#XFLD,20: All accounts for filter\r\nALL_ACCOUNTS=Wszyscy klienci\r\n\r\n#XFLD,35: All individual accounts for filter\r\nALL_INDIVIDUAL_ACCOUNTS=Wszyscy klienci indywidualni\r\n\r\n#XFLD,35: All corporate accounts for filter\r\nALL_CORPORATE_ACCOUNTS=Wszyscy klienci korporacyjni\r\n\r\n#XFLD,35: All group accounts for filter\r\nALL_ACCOUNT_GROUPS=Wszystkie grupy klient\\u00F3w\r\n\r\n#XFLD,20: my account for filter\r\nMY_ACCOUNT=Moi klienci\r\n\r\n#XFLD,35: my individual accounts for filter\r\nMY_INDIVIDUAL_ACCOUNTS=Moi klienci indywidualni\r\n\r\n#XFLD,35: my corporate accounts for filter\r\nMY_CORPORATE_ACCOUNTS=Moi klienci korporacyjni\r\n\r\n#XFLD,35: my group accounts for filter\r\nMY_ACCOUNT_GROUPS=Moje grupy klient\\u00F3w\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nINDIVIDUAL_ACCOUNT=Klient indywidualny\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nCORPORATE_ACCOUNT=Klient korporacyjny\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nACCOUNT_GROUP=Grupa kont\r\n\r\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\r\nSTARTING=Data rozpocz\\u0119cia\\: {0}\r\n\r\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\r\nCLOSING=Data zamkni\\u0119cia\\: {0}\r\n\r\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\r\nDUE=Termin\\: {0}\r\n\r\n#XFLD,20: All accounts for title\r\nALL_ACCOUNTS_TITLE=Wszyscy klienci ({0})\r\n\r\n#XFLD,35: All individual accounts for title\r\nALL_INDIVIDUAL_ACCOUNTS_TITLE=Wszyscy klienci indywidualni ({0})\r\n\r\n#XFLD,35: All corporate accounts for title\r\nALL_CORPORATE_ACCOUNTS_TITLE=Wszyscy klienci korporacyjni ({0})\r\n\r\n#XFLD,35: All group accounts for title\r\nALL_ACCOUNT_GROUPS_TITLE=Wszystkie grupy klient\\u00F3w ({0})\r\n\r\n#XFLD,20: my account for title\r\nMY_ACCOUNT_TITLE=Moi klienci ({0})\r\n\r\n#XFLD,35: my individual account for title\r\nMY_INDIVIDUAL_ACCOUNT_TITLE=Moi klienci indywidualni ({0})\r\n\r\n#XFLD,35: my corporate account for title.\r\nMY_CORPORATE_ACCOUNT_TITLE=Moi klienci korporacyjni ({0})\r\n\r\n#XFLD,35: my group account for title\r\nMY_ACCOUNT_GROUP_TITLE=Moje grupy klient\\u00F3w ({0})\r\n\r\n#XFLD,30: filtered by info\r\nFILTERED_BY=Przefiltrowane wed\\u0142ug\\: {0}\r\n\r\n#XFLD,30: label, search for accounts\r\nSEARCH_ACCOUNTS=Szukaj\r\n\r\n#XFLD,30: comma separator for location\r\nLOCATION={0}, {1}\r\n\r\n#XFLD: W4: Label for All day text in Appointments\r\nALL_DAY_EVENT=Ca\\u0142y dzie\\u0144\r\n\r\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\r\nDURATION_MINUTE={0} min\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\r\nDURATION_HOUR={0} godz.\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\r\nDURATION_DAY={0} dzie\\u0144\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\r\nDURATION_DAYS={0} dni\r\n\r\n#XFLD: W4: Label for Private meeting\r\nPRIVATE=Prywatne\r\n\r\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\r\nSELECT_TRANSACTION_TYPE=Wyb\\u00F3r typu transakcji\r\n\r\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\r\nNEW_TASK_INPUT_PLACEHOLDER=Nowe zadanie\r\n\r\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nNO_DATA_TEXT=Brak danych\r\n\r\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nLOADING_TEXT=Wczytywanie...\r\n\r\n#XFLD,25: W4: Column label for name of contact person in contacts\r\nNAME=Nazwa\r\n\r\n#XFLD,25: W5: Column label for department of contact person in contacts\r\nDEPARTMENT=Dzia\\u0142\r\n\r\n#XFLD,15: W6: Column label for actions of contact person in contacts\r\nACTIONS=Czynno\\u015Bci\r\n\r\n#XFLD,25: W4: Column label for description of lead in Leads\r\nDESCRIPTION=Opis\r\n\r\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\r\nASSIGNED_TO=Przypisane do\r\n\r\n#XFLD,15: W4: Column label for end date of lead in Leads\r\nEND_DATE=Data zako\\u0144.\r\n\r\n#XFLD,15: W4: Column label for qualification level of lead in Leads\r\nQUALIFICATION=Kwalifikacja\r\n\r\n#XFLD,15: W4: Column label for status of lead in Leads\r\nSTATUS=Status\r\n\r\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\r\nMAIN_CONTACT=G\\u0142\\u00F3wny kontakt\r\n\r\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\r\nVOLUME=Ilo\\u015B\\u0107\r\n\r\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\r\nPROBABILITY=Prawdopodobie\\u0144stwo\r\n\r\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\r\nCLOSE_BY=Zamkni\\u0119cie do\r\n\r\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \r\nVIEWS=Wgl\\u0105dy\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\r\nCONTACT_TITLE=Kontakt\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\r\nEMPLOYEE_TITLE=Pracownik\r\n\r\n#XTIT,20: W7: Title of pop-up used in confirm popup\r\nCONFIRM_TITLE=Potwierdzenie\r\n\r\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\r\nCOMPANY_NAME=Nazwa\r\n\r\n#XFLD,20: W4: Label for name 1 of a company used general data\r\nCOMPANY_NAME1=Nazwa 1\r\n\r\n#XFLD,20: W4: Label for name 2 of a company used general data\r\nCOMPANY_NAME2=Nazwa 2\r\n\r\n#XFLD,20: W4: Label for first name of a person used general data\r\nFIRST_NAME=Imi\\u0119\r\n\r\n#XFLD,20: W4: Label for last name of a person used general data\r\nLAST_NAME=Nazwisko\r\n\r\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nBIRTHDAY=Data urodzenia\r\n\r\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nTITLE=Tytu\\u0142\r\n\r\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nACADEMIC_TITLE=Tytu\\u0142 akademicki\r\n\r\n#XFLD,20: W4: Label for mobile phone number used general data\r\nMOBILE=Telefon kom\\u00F3rkowy\r\n\r\n#XFLD,20: W4: Label for phone number used general data\r\nPHONE=Telefon\r\n\r\n#XFLD,20: W4: Label for e-mail used general data\r\nEMAIL=E-mail\r\n\r\n#XFLD,20: W4: Label for web site used general data\r\nWEBSITE=Strona WWW\r\n\r\n#XFLD,20: W4: Label for country used general data\r\nCOUNTRY=Kraj\r\n\r\n#XFLD,20: W4: Label for region used general data\r\nREGION=Region\r\n\r\n#XFLD,20: W4: Label for city used general data\r\nCITY=Miejscowo\\u015B\\u0107\r\n\r\n#XFLD,20: W4: Label for postal code used general data\r\nPOSTAL_CODE=Kod pocztowy\r\n\r\n#XFLD,20: W4: Label for street used general data\r\nSTREET=Ulica\r\n\r\n#XFLD,10: W4: Label for house number used general data\r\nHOUSE_NUMBER=Numer domu\r\n\r\n#XFLD,15: W6: Label for ID used in Quotations\r\nID=ID\r\n\r\n#XFLD,15: W6: Label for Amount used in Quotations\r\nAMOUNT=Kwota\r\n\r\n#XFLD,20: W6: Label for Expiration Date used in Quotations\r\nEXPIRATION_DATE=Data wyga\\u015Bni\\u0119cia\r\n\r\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\r\nDELIVERY_DATE=Data dostawy\r\n\r\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\r\nSALES_EMPLOYEE=Pracownik dz. sprz.\r\n\r\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\r\nATTRIBUTESET=Zbi\\u00F3r atrybut\\u00F3w\r\n\r\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\r\nATTRIBUTE=Atrybut\r\n\r\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\r\nVALUE=Warto\\u015B\\u0107\r\n\r\n#XBUT, 20: Button to create an Account\r\nBUTTON_ADD=Dodaj\r\n\r\n#XBUT, 20: Button to edit an Account\r\nBUTTON_EDIT=Edytuj\r\n\r\n#XBUT, 20: Button to save changes\r\nBUTTON_SAVE=Zapisz\r\n\r\n#XBUT, 20: Button to cancel changes\r\nBUTTON_CANCEL=Anuluj\r\n\r\n#XBUT, 30: Button which shows the personalization buttons\r\nBUTTON_SHOW_PERSONALIZATION=Wy\\u015Bwietl personalizacj\\u0119\r\n\r\n#XBUT, 30: Button which hides the personalization buttons\r\nBUTTON_HIDE_PERSONALIZATION=Ukryj personalizacj\\u0119\r\n\r\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_CONFIRM_CANCEL=Niezapisane zmiany zostan\\u0105 utracone. Czy chcesz kontynuowa\\u0107?\r\n\r\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\r\nMSG_CONFIRM_DELETE_CONTACT=Przypisanie kontaktu do klienta zostanie anulowane. Czy chcesz kontynuowa\\u0107?\r\n\r\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_SUCCESS=Zaktualizowano klienta\r\n\r\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_ERROR=Aktualizacja nie powiod\\u0142a si\\u0119\r\n\r\n# XMSG : Account update succeeded\r\nMSG_CREATION_SUCCESS=Utworzono klienta\r\n\r\n# XMSG : Task creation succeeded\r\nMSG_TASK_CREATION_SUCCESS=Utworzono zadanie\r\n\r\n# XMSG : Contact creation failed\r\nMSG_CREATION_ERROR=Tworzenie nie powiod\\u0142o si\\u0119\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong country\r\nMSG_WRONG_COUNTRY_ERROR=Kraj "{0}" nie istnieje\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong region\r\nMSG_WRONG_REGION_ERROR=Region "{0}" nie istnieje dla kraju\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong employee\r\nMSG_WRONG_EMPLOYEE_ERROR=Pracownik "{0}" nie istnieje.\r\n\r\n# XMSG: message that will be displayed, if the user has entered invalid website url\r\nMSG_WRONG_URL_ERROR=Wprowadzony URL "{0}" jest nieprawid\\u0142owy.\r\n\r\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\r\nMSG_MANDATORY_FIELDS=Nie wszystkie pola obowi\\u0105zkowe s\\u0105 wype\\u0142nione\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA=Dane zosta\\u0142y zmienione przez innego u\\u017Cytkownika. Czy chcesz nadpisa\\u0107 zmiany innego u\\u017Cytkownika w\\u0142asnymi zmianami?\r\n\r\n# XMSG: message that will be displayed in case of conflicts during file renaming\r\nMSG_CONFLICTING_FILE_NAME=Nazwa pliku zosta\\u0142a zmieniona przez innego u\\u017Cytkownika. Czy chcesz nadpisa\\u0107 zmiany innego u\\u017Cytkownika w\\u0142asnymi zmianami?\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA_WITH_REFRESH=Dane zosta\\u0142y zmienione przez innego u\\u017Cytkownika. Te zmiany b\\u0119d\\u0105 teraz widoczne w aplikacji.\r\n\r\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\r\nMSG_NOT_IN_MAIN_CONTACT=Mo\\u017Cesz wy\\u015Bwietli\\u0107 tylko szczeg\\u00F3\\u0142y kontakt\\u00F3w przypisanych do tego konta\r\n\r\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\r\nMSG_EXCEEDING_FILE_NAME_LENGTH=Nazwa pliku mo\\u017Ce zawiera\\u0107 maksymalnie 40 znak\\u00F3w.\r\n\r\n# XTOL, 20: tooltip shown on search result list for button to add an account"\r\nADD_ACCOUNT_TOOLTIP=Dodaj klienta\r\n\r\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\r\nADD_MARKETING_ATTRIBUTE_TOOLTIP=Dodaj atrybut marketingowy\r\n\r\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\r\nADD_CONTACT_TOOLTIP=Dodaj kontakt\r\n\r\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\r\nADD_APPOINTMENT_TOOLTIP=Dodaj spotkanie\r\n\r\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\r\nADD_TASK_TOOLTIP=Dodaj zadanie\r\n\r\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\r\nADD_OPPORTUNITY_TOOLTIP=Dodaj szans\\u0119\r\n',
		"cus/crm/myaccounts/i18n/i18n_pt.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XFLD, 30: Facet title for general Data\r\nGENERAL_DATA=Dados gerais\r\n\r\n#XTIT, 40: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=Minhas contas\r\n\r\n#XTIT, 40: this is the title for the detail screen\r\nDETAIL_TITLE=Conta\r\n\r\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\r\nREVENUE_CURRENT=Receita acum.anual\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\r\nREVENUE_CURRENT_TOOLTIP=Receita at\\u00E9 o ano atual\r\n\r\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\r\nREVENUE_LAST=Rec.ano passado\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\r\nREVENUE_LAST_TOOLTIP=Receita ano passado\r\n\r\n# XFLD, 30: Facet title for opportunities and label in facet general data\r\nOPPORTUNITIES=Oportunidades\r\n\r\n#XFLD, 30: Facet title for leads\r\nLEADS=Leads\r\n\r\n#XFLD, 30: Facet title for tasks\r\nTASKS=Tarefas\r\n\r\n#XFLD, 30: Facet title for appointments\r\nAPPOINTMENTS=Compromissos\r\n\r\n#XFLD, 30: Facet title for quotations\r\nQUOTATIONS=Cota\\u00E7\\u00F5es\r\n\r\n#XFLD, 30: Facet title for sales orders\r\nSALES_ORDERS=Pedidos do cliente\r\n\r\n#XFLD, 30: W7: Facet title for marketing attributes\r\nMARKETINGATTRIBUTES=Atributos de marketing\r\n\r\n#XFLD, 30: W6: Title for popup with products\r\nPRODUCTS=Produtos\r\n\r\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\r\nEMPLOYEE_RESPONSIBLE=Funcion\\u00E1rio respons\\u00E1vel\r\n\r\n#XFLD, 30: Facet title for Attachments\r\nATTACHMENTS=Anexos\r\n\r\n#XFLD, 30: Facet title for Notes\r\nNOTES=Notas\r\n\r\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\r\nNEW_NOTE=Nova nota\r\n\r\n#XFLD, 30: Facet title for Contacts\r\nCONTACTS=Contatos\r\n\r\n#XFLD, 30: Label for Address in facet general data\r\nADDRESS=Endere\\u00E7o\r\n\r\n#XFLD, 30: Label for Opportunities in facet general data\r\nUNWEIGHTED_OPPORTUNITIES=Oportunidades\r\n\r\n#XFLD, 30: Label for Rating in facet general data\r\nRATING=Classifica\\u00E7\\u00E3o\r\n\r\n# XFLD, 30: Label for Next contact in facet Appointments\r\nNEXT_APPOINTMENT=Pr\\u00F3ximo compromisso\r\n\r\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\r\nLAST_APPOINTMENT=\\u00DAltimo compromisso\r\n\r\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\r\nIMAGE=Imagem\r\n\r\n#XBUT, 20: Button to show the create actionsheet\r\nCREATE=Criar\r\n\r\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\r\nDISCUSS_ENTRY=Discutir no SAP Jam\r\n\r\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\r\nSHARE_ENTRY=Compartilhar em SAP Jam\r\n\r\n#XBUT, 20: Button to share the note\r\nDETAIL_BUTTON_SHARE=Compartilhar\r\n\r\n#XBUT, 20: Button to cancel sharing\r\nDETAIL_BUTTON_CANCEL=Anular\r\n\r\n#XFLD,20: All accounts for filter\r\nALL_ACCOUNTS=Todas as contas\r\n\r\n#XFLD,35: All individual accounts for filter\r\nALL_INDIVIDUAL_ACCOUNTS=Todas as contas individuais\r\n\r\n#XFLD,35: All corporate accounts for filter\r\nALL_CORPORATE_ACCOUNTS=Todas as contas corporate\r\n\r\n#XFLD,35: All group accounts for filter\r\nALL_ACCOUNT_GROUPS=Todos os grupos de conta\r\n\r\n#XFLD,20: my account for filter\r\nMY_ACCOUNT=Minhas contas\r\n\r\n#XFLD,35: my individual accounts for filter\r\nMY_INDIVIDUAL_ACCOUNTS=Minhas contas individuais\r\n\r\n#XFLD,35: my corporate accounts for filter\r\nMY_CORPORATE_ACCOUNTS=Minhas contas corporate\r\n\r\n#XFLD,35: my group accounts for filter\r\nMY_ACCOUNT_GROUPS=Meus grupos de contas\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nINDIVIDUAL_ACCOUNT=Conta individual\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nCORPORATE_ACCOUNT=Conta corporate\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nACCOUNT_GROUP=Grupo de contas\r\n\r\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\r\nSTARTING=Data de in\\u00EDcio\\: {0}\r\n\r\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\r\nCLOSING=Data de encerramento\\: {0}\r\n\r\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\r\nDUE=Prazo\\: {0}\r\n\r\n#XFLD,20: All accounts for title\r\nALL_ACCOUNTS_TITLE=Todas as contas ({0})\r\n\r\n#XFLD,35: All individual accounts for title\r\nALL_INDIVIDUAL_ACCOUNTS_TITLE=Todas as contas individuais ({0})\r\n\r\n#XFLD,35: All corporate accounts for title\r\nALL_CORPORATE_ACCOUNTS_TITLE=Todas as contas corporate ({0})\r\n\r\n#XFLD,35: All group accounts for title\r\nALL_ACCOUNT_GROUPS_TITLE=Todos os grupos de conta ({0})\r\n\r\n#XFLD,20: my account for title\r\nMY_ACCOUNT_TITLE=Minhas contas ({0})\r\n\r\n#XFLD,35: my individual account for title\r\nMY_INDIVIDUAL_ACCOUNT_TITLE=Minhas contas individuais ({0})\r\n\r\n#XFLD,35: my corporate account for title.\r\nMY_CORPORATE_ACCOUNT_TITLE=Minhas contas corporate ({0})\r\n\r\n#XFLD,35: my group account for title\r\nMY_ACCOUNT_GROUP_TITLE=Meus grupos de conta ({0})\r\n\r\n#XFLD,30: filtered by info\r\nFILTERED_BY=Filtrado por\\: {0}\r\n\r\n#XFLD,30: label, search for accounts\r\nSEARCH_ACCOUNTS=Procurar\r\n\r\n#XFLD,30: comma separator for location\r\nLOCATION={0}, {1}\r\n\r\n#XFLD: W4: Label for All day text in Appointments\r\nALL_DAY_EVENT=O dia inteiro\r\n\r\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\r\nDURATION_MINUTE={0} min\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\r\nDURATION_HOUR={0} h\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\r\nDURATION_DAY={0} dia\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\r\nDURATION_DAYS={0} dias\r\n\r\n#XFLD: W4: Label for Private meeting\r\nPRIVATE=Privado\r\n\r\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\r\nSELECT_TRANSACTION_TYPE=Selecionar tipo de transa\\u00E7\\u00E3o\r\n\r\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\r\nNEW_TASK_INPUT_PLACEHOLDER=Nova tarefa\r\n\r\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nNO_DATA_TEXT=Sem dados\r\n\r\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nLOADING_TEXT=Carregando...\r\n\r\n#XFLD,25: W4: Column label for name of contact person in contacts\r\nNAME=Nome\r\n\r\n#XFLD,25: W5: Column label for department of contact person in contacts\r\nDEPARTMENT=Departamento\r\n\r\n#XFLD,15: W6: Column label for actions of contact person in contacts\r\nACTIONS=A\\u00E7\\u00F5es\r\n\r\n#XFLD,25: W4: Column label for description of lead in Leads\r\nDESCRIPTION=Descri\\u00E7\\u00E3o\r\n\r\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\r\nASSIGNED_TO=Atribu\\u00EDdo a\r\n\r\n#XFLD,15: W4: Column label for end date of lead in Leads\r\nEND_DATE=Data final\r\n\r\n#XFLD,15: W4: Column label for qualification level of lead in Leads\r\nQUALIFICATION=Qualifica\\u00E7\\u00E3o\r\n\r\n#XFLD,15: W4: Column label for status of lead in Leads\r\nSTATUS=Status\r\n\r\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\r\nMAIN_CONTACT=Contato principal\r\n\r\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\r\nVOLUME=Volume\r\n\r\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\r\nPROBABILITY=Probabilidade\r\n\r\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\r\nCLOSE_BY=Encerramento at\\u00E9\r\n\r\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \r\nVIEWS=Vis\\u00F5es\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\r\nCONTACT_TITLE=Contato\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\r\nEMPLOYEE_TITLE=Funcion\\u00E1rio\r\n\r\n#XTIT,20: W7: Title of pop-up used in confirm popup\r\nCONFIRM_TITLE=Confirmar\r\n\r\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\r\nCOMPANY_NAME=Nome\r\n\r\n#XFLD,20: W4: Label for name 1 of a company used general data\r\nCOMPANY_NAME1=Nome 1\r\n\r\n#XFLD,20: W4: Label for name 2 of a company used general data\r\nCOMPANY_NAME2=Nome 2\r\n\r\n#XFLD,20: W4: Label for first name of a person used general data\r\nFIRST_NAME=1\\u00BA nome\r\n\r\n#XFLD,20: W4: Label for last name of a person used general data\r\nLAST_NAME=Sobrenome\r\n\r\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nBIRTHDAY=Data de nascimento\r\n\r\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nTITLE=T\\u00EDtulo\r\n\r\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nACADEMIC_TITLE=T\\u00EDtulo acad\\u00EAmico\r\n\r\n#XFLD,20: W4: Label for mobile phone number used general data\r\nMOBILE=Celular\r\n\r\n#XFLD,20: W4: Label for phone number used general data\r\nPHONE=Telefone\r\n\r\n#XFLD,20: W4: Label for e-mail used general data\r\nEMAIL=E-mail\r\n\r\n#XFLD,20: W4: Label for web site used general data\r\nWEBSITE=Site da Web\r\n\r\n#XFLD,20: W4: Label for country used general data\r\nCOUNTRY=Pa\\u00EDs\r\n\r\n#XFLD,20: W4: Label for region used general data\r\nREGION=Regi\\u00E3o\r\n\r\n#XFLD,20: W4: Label for city used general data\r\nCITY=Cidade\r\n\r\n#XFLD,20: W4: Label for postal code used general data\r\nPOSTAL_CODE=C\\u00F3digo postal\r\n\r\n#XFLD,20: W4: Label for street used general data\r\nSTREET=Rua\r\n\r\n#XFLD,10: W4: Label for house number used general data\r\nHOUSE_NUMBER=N\\u00BA casa\r\n\r\n#XFLD,15: W6: Label for ID used in Quotations\r\nID=ID\r\n\r\n#XFLD,15: W6: Label for Amount used in Quotations\r\nAMOUNT=Montante\r\n\r\n#XFLD,20: W6: Label for Expiration Date used in Quotations\r\nEXPIRATION_DATE=Data de vencimento\r\n\r\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\r\nDELIVERY_DATE=Data do fornecimento\r\n\r\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\r\nSALES_EMPLOYEE=Representante vendas\r\n\r\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\r\nATTRIBUTESET=Set de atributos\r\n\r\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\r\nATTRIBUTE=Atributo\r\n\r\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\r\nVALUE=Valor\r\n\r\n#XBUT, 20: Button to create an Account\r\nBUTTON_ADD=Adicionar\r\n\r\n#XBUT, 20: Button to edit an Account\r\nBUTTON_EDIT=Editar\r\n\r\n#XBUT, 20: Button to save changes\r\nBUTTON_SAVE=Gravar\r\n\r\n#XBUT, 20: Button to cancel changes\r\nBUTTON_CANCEL=Cancelar\r\n\r\n#XBUT, 30: Button which shows the personalization buttons\r\nBUTTON_SHOW_PERSONALIZATION=Exibir personaliza\\u00E7\\u00E3o\r\n\r\n#XBUT, 30: Button which hides the personalization buttons\r\nBUTTON_HIDE_PERSONALIZATION=Ocultar personaliza\\u00E7\\u00E3o\r\n\r\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_CONFIRM_CANCEL=As modifica\\u00E7\\u00F5es n\\u00E3o gravadas se perder\\u00E3o. Continuar?\r\n\r\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\r\nMSG_CONFIRM_DELETE_CONTACT=A atribui\\u00E7\\u00E3o do contato \\u00E0 conta ser\\u00E1 eliminada. Continuar?\r\n\r\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_SUCCESS=Conta atualizada\r\n\r\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_ERROR=Falha ao atualizar\r\n\r\n# XMSG : Account update succeeded\r\nMSG_CREATION_SUCCESS=Conta criada\r\n\r\n# XMSG : Task creation succeeded\r\nMSG_TASK_CREATION_SUCCESS=Tarefa criada\r\n\r\n# XMSG : Contact creation failed\r\nMSG_CREATION_ERROR=Falha ao criar\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong country\r\nMSG_WRONG_COUNTRY_ERROR=O pa\\u00EDs "{0}" n\\u00E3o existe\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong region\r\nMSG_WRONG_REGION_ERROR=A regi\\u00E3o "{0}" n\\u00E3o existe para o pa\\u00EDs\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong employee\r\nMSG_WRONG_EMPLOYEE_ERROR=O funcion\\u00E1rio "{0}" n\\u00E3o existe.\r\n\r\n# XMSG: message that will be displayed, if the user has entered invalid website url\r\nMSG_WRONG_URL_ERROR=O URL inserido "{0}" n\\u00E3o \\u00E9 v\\u00E1lido.\r\n\r\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\r\nMSG_MANDATORY_FIELDS=Nem todos os campos obrigat\\u00F3rios foram preenchidos\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA=Os dados foram modificados por outro usu\\u00E1rio. Sobregravar as modifica\\u00E7\\u00F5es do outro usu\\u00E1rio com suas pr\\u00F3prias?\r\n\r\n# XMSG: message that will be displayed in case of conflicts during file renaming\r\nMSG_CONFLICTING_FILE_NAME=O nome do arquivo foi modificado por outro usu\\u00E1rio. Sobregravar as modifica\\u00E7\\u00F5es do outro usu\\u00E1rio com suas pr\\u00F3prias?\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA_WITH_REFRESH=Dados modificados por outro usu\\u00E1rio. Estas modifica\\u00E7\\u00F5es aparecer\\u00E3o agora no app.\r\n\r\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\r\nMSG_NOT_IN_MAIN_CONTACT=S\\u00F3 \\u00E9 poss\\u00EDvel exibir detalhes de contatos atribu\\u00EDdos a esta conta\r\n\r\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\r\nMSG_EXCEEDING_FILE_NAME_LENGTH=Seu nome de arquivo pode ter no m\\u00E1ximo 40 caracteres.\r\n\r\n# XTOL, 20: tooltip shown on search result list for button to add an account"\r\nADD_ACCOUNT_TOOLTIP=Adicionar conta\r\n\r\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\r\nADD_MARKETING_ATTRIBUTE_TOOLTIP=Adicionar atributo de marketing\r\n\r\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\r\nADD_CONTACT_TOOLTIP=Inserir contato\r\n\r\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\r\nADD_APPOINTMENT_TOOLTIP=Adicionar compromisso\r\n\r\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\r\nADD_TASK_TOOLTIP=Adicionar tarefa\r\n\r\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\r\nADD_OPPORTUNITY_TOOLTIP=Adicionar oportunidade\r\n',
		"cus/crm/myaccounts/i18n/i18n_ro.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XFLD, 30: Facet title for general Data\r\nGENERAL_DATA=Date generale\r\n\r\n#XTIT, 40: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=Conturile mele\r\n\r\n#XTIT, 40: this is the title for the detail screen\r\nDETAIL_TITLE=Cont\r\n\r\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\r\nREVENUE_CURRENT=VenitCumulatPnLaAn\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\r\nREVENUE_CURRENT_TOOLTIP=Venit cumulat pe an p\\u00E2n\\u0103 la dat\\u0103 curent\\u0103\r\n\r\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\r\nREVENUE_LAST=Venit anul trecut\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\r\nREVENUE_LAST_TOOLTIP=Venit anul trecut\r\n\r\n# XFLD, 30: Facet title for opportunities and label in facet general data\r\nOPPORTUNITIES=Oportunit\\u0103\\u0163i\r\n\r\n#XFLD, 30: Facet title for leads\r\nLEADS=Interese poten\\u0163iale\r\n\r\n#XFLD, 30: Facet title for tasks\r\nTASKS=Sarcini\r\n\r\n#XFLD, 30: Facet title for appointments\r\nAPPOINTMENTS=\\u00CEnt\\u00E2lniri fixate\r\n\r\n#XFLD, 30: Facet title for quotations\r\nQUOTATIONS=Oferte\r\n\r\n#XFLD, 30: Facet title for sales orders\r\nSALES_ORDERS=Comenzi de v\\u00E2nz\\u0103ri\r\n\r\n#XFLD, 30: W7: Facet title for marketing attributes\r\nMARKETINGATTRIBUTES=Atribute de marketing\r\n\r\n#XFLD, 30: W6: Title for popup with products\r\nPRODUCTS=Produse\r\n\r\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\r\nEMPLOYEE_RESPONSIBLE=Angajat responsabil\r\n\r\n#XFLD, 30: Facet title for Attachments\r\nATTACHMENTS=Anexe\r\n\r\n#XFLD, 30: Facet title for Notes\r\nNOTES=Note\r\n\r\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\r\nNEW_NOTE=Not\\u0103 nou\\u0103\r\n\r\n#XFLD, 30: Facet title for Contacts\r\nCONTACTS=Persoane de contact\r\n\r\n#XFLD, 30: Label for Address in facet general data\r\nADDRESS=Adres\\u0103\r\n\r\n#XFLD, 30: Label for Opportunities in facet general data\r\nUNWEIGHTED_OPPORTUNITIES=Oportunit\\u0103\\u0163i\r\n\r\n#XFLD, 30: Label for Rating in facet general data\r\nRATING=Evaluare\r\n\r\n# XFLD, 30: Label for Next contact in facet Appointments\r\nNEXT_APPOINTMENT=\\u00CEnt\\u00E2lnire fixat\\u0103 urm\\u0103toare\r\n\r\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\r\nLAST_APPOINTMENT=Ultima \\u00EEnt\\u00E2lnire fixat\\u0103\r\n\r\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\r\nIMAGE=Imagine\r\n\r\n#XBUT, 20: Button to show the create actionsheet\r\nCREATE=Creare\r\n\r\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\r\nDISCUSS_ENTRY=Discutare pe SAP Jam\r\n\r\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\r\nSHARE_ENTRY=Partajare pe SAP Jam\r\n\r\n#XBUT, 20: Button to share the note\r\nDETAIL_BUTTON_SHARE=Partajare\r\n\r\n#XBUT, 20: Button to cancel sharing\r\nDETAIL_BUTTON_CANCEL=Anulare\r\n\r\n#XFLD,20: All accounts for filter\r\nALL_ACCOUNTS=Toate conturile\r\n\r\n#XFLD,35: All individual accounts for filter\r\nALL_INDIVIDUAL_ACCOUNTS=Toate conturile individuale\r\n\r\n#XFLD,35: All corporate accounts for filter\r\nALL_CORPORATE_ACCOUNTS=Toate conturile de companie\r\n\r\n#XFLD,35: All group accounts for filter\r\nALL_ACCOUNT_GROUPS=Toate grupurile de conturi\r\n\r\n#XFLD,20: my account for filter\r\nMY_ACCOUNT=Conturile mele\r\n\r\n#XFLD,35: my individual accounts for filter\r\nMY_INDIVIDUAL_ACCOUNTS=Conturile mele individuale\r\n\r\n#XFLD,35: my corporate accounts for filter\r\nMY_CORPORATE_ACCOUNTS=Conturile mele de companie\r\n\r\n#XFLD,35: my group accounts for filter\r\nMY_ACCOUNT_GROUPS=Grupurile mele de conturi\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nINDIVIDUAL_ACCOUNT=Cont individual\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nCORPORATE_ACCOUNT=Cont de companie\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nACCOUNT_GROUP=Grup conturi\r\n\r\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\r\nSTARTING=Dat\\u0103 de \\u00EEnceput\\: {0}\r\n\r\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\r\nCLOSING=Dat\\u0103 de \\u00EEnchidere\\: {0}\r\n\r\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\r\nDUE=Dat\\u0103 scaden\\u0163\\u0103\\: {0}\r\n\r\n#XFLD,20: All accounts for title\r\nALL_ACCOUNTS_TITLE=Toate conturile ({0})\r\n\r\n#XFLD,35: All individual accounts for title\r\nALL_INDIVIDUAL_ACCOUNTS_TITLE=Toate conturile individuale ({0})\r\n\r\n#XFLD,35: All corporate accounts for title\r\nALL_CORPORATE_ACCOUNTS_TITLE=Toate conturile de companie ({0})\r\n\r\n#XFLD,35: All group accounts for title\r\nALL_ACCOUNT_GROUPS_TITLE=Toate grupurile de conturi ({0})\r\n\r\n#XFLD,20: my account for title\r\nMY_ACCOUNT_TITLE=Conturile mele ({0})\r\n\r\n#XFLD,35: my individual account for title\r\nMY_INDIVIDUAL_ACCOUNT_TITLE=Conturile mele individuale ({0})\r\n\r\n#XFLD,35: my corporate account for title.\r\nMY_CORPORATE_ACCOUNT_TITLE=Conturile mele de companie ({0})\r\n\r\n#XFLD,35: my group account for title\r\nMY_ACCOUNT_GROUP_TITLE=Grupurile mele de conturi ({0})\r\n\r\n#XFLD,30: filtered by info\r\nFILTERED_BY=Filtrat dup\\u0103\\: {0}\r\n\r\n#XFLD,30: label, search for accounts\r\nSEARCH_ACCOUNTS=C\\u0103utare\r\n\r\n#XFLD,30: comma separator for location\r\nLOCATION={0}, {1}\r\n\r\n#XFLD: W4: Label for All day text in Appointments\r\nALL_DAY_EVENT=Toat\\u0103 ziua\r\n\r\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\r\nDURATION_MINUTE={0} min\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\r\nDURATION_HOUR={0} h\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\r\nDURATION_DAY={0} zi\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\r\nDURATION_DAYS={0} zile\r\n\r\n#XFLD: W4: Label for Private meeting\r\nPRIVATE=Privat\r\n\r\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\r\nSELECT_TRANSACTION_TYPE=Selectare tip de opera\\u0163ie\r\n\r\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\r\nNEW_TASK_INPUT_PLACEHOLDER=Sarcin\\u0103 nou\\u0103\r\n\r\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nNO_DATA_TEXT=F\\u0103r\\u0103 date\r\n\r\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nLOADING_TEXT=\\u00CEnc\\u0103rcare ...\r\n\r\n#XFLD,25: W4: Column label for name of contact person in contacts\r\nNAME=Nume\r\n\r\n#XFLD,25: W5: Column label for department of contact person in contacts\r\nDEPARTMENT=Departament\r\n\r\n#XFLD,15: W6: Column label for actions of contact person in contacts\r\nACTIONS=Ac\\u0163iuni\r\n\r\n#XFLD,25: W4: Column label for description of lead in Leads\r\nDESCRIPTION=Descriere\r\n\r\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\r\nASSIGNED_TO=Alocat la\r\n\r\n#XFLD,15: W4: Column label for end date of lead in Leads\r\nEND_DATE=Dat\\u0103 de sf\\u00E2r\\u015Fit\r\n\r\n#XFLD,15: W4: Column label for qualification level of lead in Leads\r\nQUALIFICATION=Calificare\r\n\r\n#XFLD,15: W4: Column label for status of lead in Leads\r\nSTATUS=Stare\r\n\r\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\r\nMAIN_CONTACT=Persoan\\u0103 contact princip.\r\n\r\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\r\nVOLUME=Volum\r\n\r\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\r\nPROBABILITY=Probabilitate\r\n\r\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\r\nCLOSE_BY=\\u00CEnchidere p\\u00E2n\\u0103 la\r\n\r\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \r\nVIEWS=Imagini\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\r\nCONTACT_TITLE=Persoan\\u0103 de contact\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\r\nEMPLOYEE_TITLE=Angajat\r\n\r\n#XTIT,20: W7: Title of pop-up used in confirm popup\r\nCONFIRM_TITLE=Confirmare\r\n\r\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\r\nCOMPANY_NAME=Nume\r\n\r\n#XFLD,20: W4: Label for name 1 of a company used general data\r\nCOMPANY_NAME1=Nume 1\r\n\r\n#XFLD,20: W4: Label for name 2 of a company used general data\r\nCOMPANY_NAME2=Nume 2\r\n\r\n#XFLD,20: W4: Label for first name of a person used general data\r\nFIRST_NAME=Prenume\r\n\r\n#XFLD,20: W4: Label for last name of a person used general data\r\nLAST_NAME=Nume familie\r\n\r\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nBIRTHDAY=Dat\\u0103 de na\\u015Ftere\r\n\r\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nTITLE=Titlu\r\n\r\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nACADEMIC_TITLE=Titlu academic\r\n\r\n#XFLD,20: W4: Label for mobile phone number used general data\r\nMOBILE=Telefon mobil\r\n\r\n#XFLD,20: W4: Label for phone number used general data\r\nPHONE=Telefon\r\n\r\n#XFLD,20: W4: Label for e-mail used general data\r\nEMAIL=E-mail\r\n\r\n#XFLD,20: W4: Label for web site used general data\r\nWEBSITE=Site web\r\n\r\n#XFLD,20: W4: Label for country used general data\r\nCOUNTRY=\\u0162ar\\u0103\r\n\r\n#XFLD,20: W4: Label for region used general data\r\nREGION=Regiune\r\n\r\n#XFLD,20: W4: Label for city used general data\r\nCITY=Localitate\r\n\r\n#XFLD,20: W4: Label for postal code used general data\r\nPOSTAL_CODE=Cod po\\u015Ftal\r\n\r\n#XFLD,20: W4: Label for street used general data\r\nSTREET=Strad\\u0103\r\n\r\n#XFLD,10: W4: Label for house number used general data\r\nHOUSE_NUMBER=Nr.cas\\u0103\r\n\r\n#XFLD,15: W6: Label for ID used in Quotations\r\nID=ID\r\n\r\n#XFLD,15: W6: Label for Amount used in Quotations\r\nAMOUNT=Sum\\u0103\r\n\r\n#XFLD,20: W6: Label for Expiration Date used in Quotations\r\nEXPIRATION_DATE=Dat\\u0103 de expirare\r\n\r\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\r\nDELIVERY_DATE=Dat\\u0103 livrare\r\n\r\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\r\nSALES_EMPLOYEE=Angajat v\\u00E2nz\\u0103ri\r\n\r\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\r\nATTRIBUTESET=Set de atribute\r\n\r\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\r\nATTRIBUTE=Atribut\r\n\r\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\r\nVALUE=Valoare\r\n\r\n#XBUT, 20: Button to create an Account\r\nBUTTON_ADD=Ad\\u0103ugare\r\n\r\n#XBUT, 20: Button to edit an Account\r\nBUTTON_EDIT=Editare\r\n\r\n#XBUT, 20: Button to save changes\r\nBUTTON_SAVE=Salvare\r\n\r\n#XBUT, 20: Button to cancel changes\r\nBUTTON_CANCEL=Anulare\r\n\r\n#XBUT, 30: Button which shows the personalization buttons\r\nBUTTON_SHOW_PERSONALIZATION=Prezentare personalizare\r\n\r\n#XBUT, 30: Button which hides the personalization buttons\r\nBUTTON_HIDE_PERSONALIZATION=Mascare personalizare\r\n\r\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_CONFIRM_CANCEL=Orice modific\\u0103ri nesalvate vor fi pierdute. Dori\\u0163i s\\u0103 continua\\u0163i?\r\n\r\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\r\nMSG_CONFIRM_DELETE_CONTACT=Alocare persoan\\u0103 de contact la cont va fi anulat\\u0103. Dori\\u0163i s\\u0103 continua\\u0163i?\r\n\r\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_SUCCESS=Cont actualizat\r\n\r\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_ERROR=Actualizare nereu\\u015Fit\\u0103\r\n\r\n# XMSG : Account update succeeded\r\nMSG_CREATION_SUCCESS=Cont creat\r\n\r\n# XMSG : Task creation succeeded\r\nMSG_TASK_CREATION_SUCCESS=Sarcin\\u0103 creat\\u0103\r\n\r\n# XMSG : Contact creation failed\r\nMSG_CREATION_ERROR=Creare nereu\\u015Fit\\u0103\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong country\r\nMSG_WRONG_COUNTRY_ERROR=\\u0162ara "{0}" nu exist\\u0103\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong region\r\nMSG_WRONG_REGION_ERROR=Regiunea "{0}" nu exist\\u0103 pt. \\u0163ar\\u0103\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong employee\r\nMSG_WRONG_EMPLOYEE_ERROR=Angajatul "{0}" nu exist\\u0103.\r\n\r\n# XMSG: message that will be displayed, if the user has entered invalid website url\r\nMSG_WRONG_URL_ERROR=URL-ul introdus "{0}" nu este valabil.\r\n\r\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\r\nMSG_MANDATORY_FIELDS=Nu toate c\\u00E2mpurile de intrare obligatorie sunt completate\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA=Datele au fost modificate de alt utilizator. Dori\\u0163i s\\u0103 suprascrie\\u0163i modific\\u0103rile celuilalt utilizator cu ale dvs.?\r\n\r\n# XMSG: message that will be displayed in case of conflicts during file renaming\r\nMSG_CONFLICTING_FILE_NAME=Numele de fi\\u015Fier a fost modificat de alt utilizator. Dori\\u0163i s\\u0103 suprascrie\\u0163i modific\\u0103rile celuilalt utilizator cu ale dvs.?\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA_WITH_REFRESH=Datele au fost modificate de alt utilizator. Aceste modific\\u0103ri vor ap\\u0103rea acum \\u00EEn apl.\r\n\r\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\r\nMSG_NOT_IN_MAIN_CONTACT=Pute\\u0163i afi\\u015Fa doar detaliile despre persoanele de contact care sunt alocate la acest cont\r\n\r\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\r\nMSG_EXCEEDING_FILE_NAME_LENGTH=Numele dvs.de fi\\u015Fier poate avea maxim 40 de caractere.\r\n\r\n# XTOL, 20: tooltip shown on search result list for button to add an account"\r\n\r\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\r\n\r\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\r\n\r\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\r\n\r\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\r\n\r\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\r\n',
		"cus/crm/myaccounts/i18n/i18n_ru.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XFLD, 30: Facet title for general Data\r\nGENERAL_DATA=\\u041E\\u0431\\u0449\\u0438\\u0435 \\u0434\\u0430\\u043D\\u043D\\u044B\\u0435\r\n\r\n#XTIT, 40: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=\\u041C\\u043E\\u0438 \\u043A\\u043B\\u0438\\u0435\\u043D\\u0442\\u044B\r\n\r\n#XTIT, 40: this is the title for the detail screen\r\nDETAIL_TITLE=\\u041A\\u043B\\u0438\\u0435\\u043D\\u0442\r\n\r\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\r\nREVENUE_CURRENT=\\u0412\\u044B\\u0440\\u0443\\u0447\\u043A\\u0430 \\u043D\\u0430 \\u0434\\u0430\\u0442\\u0443\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\r\nREVENUE_CURRENT_TOOLTIP=\\u0412\\u044B\\u0440\\u0443\\u0447\\u043A\\u0430 \\u043D\\u0430 \\u0434\\u0430\\u0442\\u0443 \\u0442\\u0435\\u043A\\u0443\\u0449\\u0435\\u0433\\u043E \\u0433\\u043E\\u0434\\u0430\r\n\r\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\r\nREVENUE_LAST=\\u0412\\u044B\\u0440\\u0443\\u0447\\u043A\\u0430/\\u043F\\u043E\\u0441\\u043B. \\u0433\\u043E\\u0434\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\r\nREVENUE_LAST_TOOLTIP=\\u0412\\u044B\\u0440\\u0443\\u0447\\u043A\\u0430 \\u0437\\u0430 \\u043F\\u043E\\u0441\\u043B\\u0435\\u0434\\u043D\\u0438\\u0439 \\u0433\\u043E\\u0434\r\n\r\n# XFLD, 30: Facet title for opportunities and label in facet general data\r\nOPPORTUNITIES=\\u0412\\u043E\\u0437\\u043C\\u043E\\u0436\\u043D\\u043E\\u0441\\u0442\\u0438\r\n\r\n#XFLD, 30: Facet title for leads\r\nLEADS=\\u041F\\u043E\\u0442\\u0435\\u043D\\u0446\\u0438\\u0430\\u043B\\u044C\\u043D\\u044B\\u0435 \\u0432\\u043E\\u0437\\u043C\\u043E\\u0436\\u043D\\u043E\\u0441\\u0442\\u0438\r\n\r\n#XFLD, 30: Facet title for tasks\r\nTASKS=\\u0417\\u0430\\u0434\\u0430\\u0447\\u0438\r\n\r\n#XFLD, 30: Facet title for appointments\r\nAPPOINTMENTS=\\u0412\\u0441\\u0442\\u0440\\u0435\\u0447\\u0438\r\n\r\n#XFLD, 30: Facet title for quotations\r\nQUOTATIONS=\\u041F\\u0440\\u0435\\u0434\\u043B\\u043E\\u0436\\u0435\\u043D\\u0438\\u044F\r\n\r\n#XFLD, 30: Facet title for sales orders\r\nSALES_ORDERS=\\u0417\\u0430\\u043A\\u0430\\u0437\\u044B \\u043A\\u043B\\u0438\\u0435\\u043D\\u0442\\u0430\r\n\r\n#XFLD, 30: W7: Facet title for marketing attributes\r\nMARKETINGATTRIBUTES=\\u041C\\u0430\\u0440\\u043A\\u0435\\u0442\\u0438\\u043D\\u0433\\u043E\\u0432\\u044B\\u0435 \\u0430\\u0442\\u0440\\u0438\\u0431\\u0443\\u0442\\u044B\r\n\r\n#XFLD, 30: W6: Title for popup with products\r\nPRODUCTS=\\u041F\\u0440\\u043E\\u0434\\u0443\\u043A\\u0442\\u044B\r\n\r\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\r\nEMPLOYEE_RESPONSIBLE=\\u041E\\u0442\\u0432\\u0435\\u0442\\u0441\\u0442\\u0432\\u0435\\u043D\\u043D\\u044B\\u0439 \\u0441\\u043E\\u0442\\u0440\\u0443\\u0434\\u043D\\u0438\\u043A\r\n\r\n#XFLD, 30: Facet title for Attachments\r\nATTACHMENTS=\\u0412\\u043B\\u043E\\u0436\\u0435\\u043D\\u0438\\u044F\r\n\r\n#XFLD, 30: Facet title for Notes\r\nNOTES=\\u041F\\u0440\\u0438\\u043C\\u0435\\u0447\\u0430\\u043D\\u0438\\u044F\r\n\r\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\r\nNEW_NOTE=\\u041D\\u043E\\u0432\\u043E\\u0435 \\u043F\\u0440\\u0438\\u043C\\u0435\\u0447\\u0430\\u043D\\u0438\\u0435\r\n\r\n#XFLD, 30: Facet title for Contacts\r\nCONTACTS=\\u041A\\u043E\\u043D\\u0442\\u0430\\u043A\\u0442\\u044B\r\n\r\n#XFLD, 30: Label for Address in facet general data\r\nADDRESS=\\u0410\\u0434\\u0440\\u0435\\u0441\r\n\r\n#XFLD, 30: Label for Opportunities in facet general data\r\nUNWEIGHTED_OPPORTUNITIES=\\u0412\\u043E\\u0437\\u043C\\u043E\\u0436\\u043D\\u043E\\u0441\\u0442\\u0438\r\n\r\n#XFLD, 30: Label for Rating in facet general data\r\nRATING=\\u0420\\u0435\\u0439\\u0442\\u0438\\u043D\\u0433\r\n\r\n# XFLD, 30: Label for Next contact in facet Appointments\r\nNEXT_APPOINTMENT=\\u0421\\u043B\\u0435\\u0434\\u0443\\u044E\\u0449\\u0430\\u044F \\u0432\\u0441\\u0442\\u0440\\u0435\\u0447\\u0430\r\n\r\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\r\nLAST_APPOINTMENT=\\u041F\\u043E\\u0441\\u043B\\u0435\\u0434\\u043D\\u044F\\u044F \\u0432\\u0441\\u0442\\u0440\\u0435\\u0447\\u0430\r\n\r\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\r\nIMAGE=\\u0418\\u0437\\u043E\\u0431\\u0440\\u0430\\u0436.\r\n\r\n#XBUT, 20: Button to show the create actionsheet\r\nCREATE=\\u0421\\u043E\\u0437\\u0434\\u0430\\u0442\\u044C\r\n\r\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\r\nDISCUSS_ENTRY=\\u0414\\u0438\\u0441\\u043A\\u0443\\u0441\\u0441\\u0438\\u044F \\u0432 SAP Jam\r\n\r\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\r\nSHARE_ENTRY=\\u041E\\u043F\\u0443\\u0431\\u043B\\u0438\\u043A\\u043E\\u0432\\u0430\\u0442\\u044C \\u0432 SAP Jam\r\n\r\n#XBUT, 20: Button to share the note\r\nDETAIL_BUTTON_SHARE=\\u041F\\u043E\\u0434\\u0435\\u043B\\u0438\\u0442\\u044C\\u0441\\u044F\r\n\r\n#XBUT, 20: Button to cancel sharing\r\nDETAIL_BUTTON_CANCEL=\\u041E\\u0442\\u043C\\u0435\\u043D\\u0438\\u0442\\u044C\r\n\r\n#XFLD,20: All accounts for filter\r\nALL_ACCOUNTS=\\u0412\\u0441\\u0435 \\u043A\\u043B\\u0438\\u0435\\u043D\\u0442\\u044B\r\n\r\n#XFLD,35: All individual accounts for filter\r\nALL_INDIVIDUAL_ACCOUNTS=\\u0412\\u0441\\u0435 \\u0438\\u043D\\u0434\\u0438\\u0432\\u0438\\u0434\\u0443\\u0430\\u043B\\u044C\\u043D\\u044B\\u0435 \\u043A\\u043B\\u0438\\u0435\\u043D\\u0442\\u044B\r\n\r\n#XFLD,35: All corporate accounts for filter\r\nALL_CORPORATE_ACCOUNTS=\\u0412\\u0441\\u0435 \\u043A\\u043E\\u0440\\u043F\\u043E\\u0440\\u0430\\u0442\\u0438\\u0432\\u043D\\u044B\\u0435 \\u043A\\u043B\\u0438\\u0435\\u043D\\u0442\\u044B\r\n\r\n#XFLD,35: All group accounts for filter\r\nALL_ACCOUNT_GROUPS=\\u0412\\u0441\\u0435 \\u0433\\u0440\\u0443\\u043F\\u043F\\u044B \\u043A\\u043B\\u0438\\u0435\\u043D\\u0442\\u043E\\u0432\r\n\r\n#XFLD,20: my account for filter\r\nMY_ACCOUNT=\\u041C\\u043E\\u0438 \\u043A\\u043B\\u0438\\u0435\\u043D\\u0442\\u044B\r\n\r\n#XFLD,35: my individual accounts for filter\r\nMY_INDIVIDUAL_ACCOUNTS=\\u041C\\u043E\\u0438 \\u0438\\u043D\\u0434\\u0438\\u0432\\u0438\\u0434\\u0443\\u0430\\u043B\\u044C\\u043D\\u044B\\u0435 \\u043A\\u043B\\u0438\\u0435\\u043D\\u0442\\u044B\r\n\r\n#XFLD,35: my corporate accounts for filter\r\nMY_CORPORATE_ACCOUNTS=\\u041C\\u043E\\u0438 \\u043A\\u043E\\u0440\\u043F\\u043E\\u0440\\u0430\\u0442\\u0438\\u0432\\u043D\\u044B\\u0435 \\u043A\\u043B\\u0438\\u0435\\u043D\\u0442\\u044B\r\n\r\n#XFLD,35: my group accounts for filter\r\nMY_ACCOUNT_GROUPS=\\u041C\\u043E\\u0438 \\u0433\\u0440\\u0443\\u043F\\u043F\\u044B \\u043A\\u043B\\u0438\\u0435\\u043D\\u0442\\u043E\\u0432\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nINDIVIDUAL_ACCOUNT=\\u0418\\u043D\\u0434\\u0438\\u0432\\u0438\\u0434\\u0443\\u0430\\u043B\\u044C\\u043D\\u044B\\u0439 \\u043A\\u043B\\u0438\\u0435\\u043D\\u0442\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nCORPORATE_ACCOUNT=\\u041A\\u043E\\u0440\\u043F\\u043E\\u0440\\u0430\\u0442\\u0438\\u0432\\u043D\\u044B\\u0439 \\u043A\\u043B\\u0438\\u0435\\u043D\\u0442\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nACCOUNT_GROUP=\\u0413\\u0440\\u0443\\u043F\\u043F\\u0430 \\u043A\\u043B\\u0438\\u0435\\u043D\\u0442\\u043E\\u0432\r\n\r\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\r\nSTARTING=\\u0414\\u0430\\u0442\\u0430 \\u043D\\u0430\\u0447\\u0430\\u043B\\u0430\\: {0}\r\n\r\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\r\nCLOSING=\\u0414\\u0430\\u0442\\u0430 \\u0437\\u0430\\u043A\\u0440\\u044B\\u0442\\u0438\\u044F\\: {0}\r\n\r\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\r\nDUE=\\u0414\\u0430\\u0442\\u0430 \\u0438\\u0441\\u043F\\u043E\\u043B\\u043D\\u0435\\u043D\\u0438\\u044F\\: {0}\r\n\r\n#XFLD,20: All accounts for title\r\nALL_ACCOUNTS_TITLE=\\u0412\\u0441\\u0435 \\u043A\\u043B\\u0438\\u0435\\u043D\\u0442\\u044B ({0})\r\n\r\n#XFLD,35: All individual accounts for title\r\nALL_INDIVIDUAL_ACCOUNTS_TITLE=\\u0412\\u0441\\u0435 \\u0438\\u043D\\u0434\\u0438\\u0432\\u0438\\u0434\\u0443\\u0430\\u043B\\u044C\\u043D\\u044B\\u0435 \\u043A\\u043B\\u0438\\u0435\\u043D\\u0442\\u044B ({0})\r\n\r\n#XFLD,35: All corporate accounts for title\r\nALL_CORPORATE_ACCOUNTS_TITLE=\\u0412\\u0441\\u0435 \\u043A\\u043E\\u0440\\u043F\\u043E\\u0440\\u0430\\u0442\\u0438\\u0432\\u043D\\u044B\\u0435 \\u043A\\u043B\\u0438\\u0435\\u043D\\u0442\\u044B ({0})\r\n\r\n#XFLD,35: All group accounts for title\r\nALL_ACCOUNT_GROUPS_TITLE=\\u0412\\u0441\\u0435 \\u0433\\u0440\\u0443\\u043F\\u043F\\u044B \\u043A\\u043B\\u0438\\u0435\\u043D\\u0442\\u043E\\u0432 ({0})\r\n\r\n#XFLD,20: my account for title\r\nMY_ACCOUNT_TITLE=\\u041C\\u043E\\u0438 \\u043A\\u043B\\u0438\\u0435\\u043D\\u0442\\u044B ({0})\r\n\r\n#XFLD,35: my individual account for title\r\nMY_INDIVIDUAL_ACCOUNT_TITLE=\\u041C\\u043E\\u0438 \\u0438\\u043D\\u0434\\u0438\\u0432\\u0438\\u0434\\u0443\\u0430\\u043B\\u044C\\u043D\\u044B\\u0435 \\u043A\\u043B\\u0438\\u0435\\u043D\\u0442\\u044B ({0})\r\n\r\n#XFLD,35: my corporate account for title.\r\nMY_CORPORATE_ACCOUNT_TITLE=\\u041C\\u043E\\u0438 \\u043A\\u043E\\u0440\\u043F\\u043E\\u0440\\u0430\\u0442\\u0438\\u0432\\u043D\\u044B\\u0435 \\u043A\\u043B\\u0438\\u0435\\u043D\\u0442\\u044B ({0})\r\n\r\n#XFLD,35: my group account for title\r\nMY_ACCOUNT_GROUP_TITLE=\\u041C\\u043E\\u0438 \\u0433\\u0440\\u0443\\u043F\\u043F\\u044B \\u043A\\u043B\\u0438\\u0435\\u043D\\u0442\\u043E\\u0432 ({0})\r\n\r\n#XFLD,30: filtered by info\r\nFILTERED_BY=\\u041E\\u0442\\u0444\\u0438\\u043B\\u044C\\u0442\\u0440\\u043E\\u0432\\u0430\\u043D\\u043E \\u043F\\u043E\\: {0}\r\n\r\n#XFLD,30: label, search for accounts\r\nSEARCH_ACCOUNTS=\\u041F\\u043E\\u0438\\u0441\\u043A\r\n\r\n#XFLD,30: comma separator for location\r\nLOCATION={0}, {1}\r\n\r\n#XFLD: W4: Label for All day text in Appointments\r\nALL_DAY_EVENT=\\u0412\\u0435\\u0441\\u044C \\u0434\\u0435\\u043D\\u044C\r\n\r\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\r\nDURATION_MINUTE={0} \\u043C\\u0438\\u043D\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\r\nDURATION_HOUR={0} \\u0447\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\r\nDURATION_DAY={0} \\u0434\\u0435\\u043D\\u044C\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\r\nDURATION_DAYS={0} \\u0434.\r\n\r\n#XFLD: W4: Label for Private meeting\r\nPRIVATE=\\u041B\\u0438\\u0447\\u043D\\u0430\\u044F\r\n\r\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\r\nSELECT_TRANSACTION_TYPE=\\u0412\\u044B\\u0431\\u043E\\u0440 \\u0442\\u0438\\u043F\\u0430 \\u0442\\u0440\\u0430\\u043D\\u0437\\u0430\\u043A\\u0446\\u0438\\u0438\r\n\r\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\r\nNEW_TASK_INPUT_PLACEHOLDER=\\u041D\\u043E\\u0432\\u0430\\u044F \\u0437\\u0430\\u0434\\u0430\\u0447\\u0430\r\n\r\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nNO_DATA_TEXT=\\u041D\\u0435\\u0442 \\u0434\\u0430\\u043D\\u043D\\u044B\\u0445\r\n\r\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nLOADING_TEXT=\\u0417\\u0430\\u0433\\u0440\\u0443\\u0437\\u043A\\u0430...\r\n\r\n#XFLD,25: W4: Column label for name of contact person in contacts\r\nNAME=\\u0418\\u043C\\u044F\r\n\r\n#XFLD,25: W5: Column label for department of contact person in contacts\r\nDEPARTMENT=\\u041F\\u043E\\u0434\\u0440\\u0430\\u0437\\u0434\\u0435\\u043B\\u0435\\u043D\\u0438\\u0435\r\n\r\n#XFLD,15: W6: Column label for actions of contact person in contacts\r\nACTIONS=\\u041E\\u043F\\u0435\\u0440\\u0430\\u0446\\u0438\\u0438\r\n\r\n#XFLD,25: W4: Column label for description of lead in Leads\r\nDESCRIPTION=\\u041E\\u043F\\u0438\\u0441\\u0430\\u043D\\u0438\\u0435\r\n\r\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\r\nASSIGNED_TO=\\u041F\\u0440\\u0438\\u0441\\u0432\\u043E\\u0435\\u043D\\u043E\r\n\r\n#XFLD,15: W4: Column label for end date of lead in Leads\r\nEND_DATE=\\u041A\\u043E\\u043D\\u0435\\u0447\\u043D\\u0430\\u044F \\u0434\\u0430\\u0442\\u0430\r\n\r\n#XFLD,15: W4: Column label for qualification level of lead in Leads\r\nQUALIFICATION=\\u041A\\u0432\\u0430\\u043B\\u0438\\u0444\\u0438\\u043A\\u0430\\u0446\\u0438\\u044F\r\n\r\n#XFLD,15: W4: Column label for status of lead in Leads\r\nSTATUS=\\u0421\\u0442\\u0430\\u0442\\u0443\\u0441\r\n\r\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\r\nMAIN_CONTACT=\\u041E\\u0441\\u043D\\u043E\\u0432\\u043D\\u043E\\u0439 \\u043A\\u043E\\u043D\\u0442\\u0430\\u043A\\u0442\r\n\r\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\r\nVOLUME=\\u041A\\u043E\\u043B\\u0438\\u0447\\u0435\\u0441\\u0442\\u0432\\u043E\r\n\r\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\r\nPROBABILITY=\\u0412\\u0435\\u0440\\u043E\\u044F\\u0442\\u043D\\u043E\\u0441\\u0442\\u044C\r\n\r\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\r\nCLOSE_BY=\\u0414\\u0430\\u0442\\u0430 \\u0437\\u0430\\u043A\\u0440\\u044B\\u0442\\u0438\\u044F\r\n\r\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \r\nVIEWS=\\u0420\\u0430\\u043A\\u0443\\u0440\\u0441\\u044B\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\r\nCONTACT_TITLE=\\u041A\\u043E\\u043D\\u0442\\u0430\\u043A\\u0442\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\r\nEMPLOYEE_TITLE=\\u0421\\u043E\\u0442\\u0440\\u0443\\u0434\\u043D\\u0438\\u043A\r\n\r\n#XTIT,20: W7: Title of pop-up used in confirm popup\r\nCONFIRM_TITLE=\\u041F\\u043E\\u0434\\u0442\\u0432\\u0435\\u0440\\u0434\\u0438\\u0442\\u044C\r\n\r\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\r\nCOMPANY_NAME=\\u0418\\u043C\\u044F\r\n\r\n#XFLD,20: W4: Label for name 1 of a company used general data\r\nCOMPANY_NAME1=\\u0418\\u043C\\u044F 1\r\n\r\n#XFLD,20: W4: Label for name 2 of a company used general data\r\nCOMPANY_NAME2=\\u0418\\u043C\\u044F 2\r\n\r\n#XFLD,20: W4: Label for first name of a person used general data\r\nFIRST_NAME=\\u0418\\u043C\\u044F\r\n\r\n#XFLD,20: W4: Label for last name of a person used general data\r\nLAST_NAME=\\u0424\\u0430\\u043C\\u0438\\u043B\\u0438\\u044F\r\n\r\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nBIRTHDAY=\\u0414\\u0430\\u0442\\u0430 \\u0440\\u043E\\u0436\\u0434\\u0435\\u043D\\u0438\\u044F\r\n\r\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nTITLE=\\u041E\\u0431\\u0440\\u0430\\u0449\\u0435\\u043D\\u0438\\u0435\r\n\r\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nACADEMIC_TITLE=\\u0423\\u0447\\u0435\\u043D\\u0430\\u044F \\u0441\\u0442\\u0435\\u043F\\u0435\\u043D\\u044C\r\n\r\n#XFLD,20: W4: Label for mobile phone number used general data\r\nMOBILE=\\u041C\\u043E\\u0431\\u0438\\u043B\\u044C\\u043D\\u044B\\u0439\r\n\r\n#XFLD,20: W4: Label for phone number used general data\r\nPHONE=\\u0422\\u0435\\u043B\\u0435\\u0444\\u043E\\u043D\r\n\r\n#XFLD,20: W4: Label for e-mail used general data\r\nEMAIL=\\u042D\\u043B\\u0435\\u043A\\u0442\\u0440\\u043E\\u043D\\u043D\\u0430\\u044F \\u043F\\u043E\\u0447\\u0442\\u0430\r\n\r\n#XFLD,20: W4: Label for web site used general data\r\nWEBSITE=\\u0412\\u0435\\u0431-\\u0441\\u0430\\u0439\\u0442\r\n\r\n#XFLD,20: W4: Label for country used general data\r\nCOUNTRY=\\u0421\\u0442\\u0440\\u0430\\u043D\\u0430\r\n\r\n#XFLD,20: W4: Label for region used general data\r\nREGION=\\u0420\\u0435\\u0433\\u0438\\u043E\\u043D\r\n\r\n#XFLD,20: W4: Label for city used general data\r\nCITY=\\u0413\\u043E\\u0440\\u043E\\u0434\r\n\r\n#XFLD,20: W4: Label for postal code used general data\r\nPOSTAL_CODE=\\u041F\\u043E\\u0447\\u0442\\u043E\\u0432\\u044B\\u0439 \\u0438\\u043D\\u0434\\u0435\\u043A\\u0441\r\n\r\n#XFLD,20: W4: Label for street used general data\r\nSTREET=\\u0423\\u043B\\u0438\\u0446\\u0430\r\n\r\n#XFLD,10: W4: Label for house number used general data\r\nHOUSE_NUMBER=\\u2116 \\u0434\\u043E\\u043C\\u0430\r\n\r\n#XFLD,15: W6: Label for ID used in Quotations\r\nID=\\u0418\\u0434.\r\n\r\n#XFLD,15: W6: Label for Amount used in Quotations\r\nAMOUNT=\\u0421\\u0443\\u043C\\u043C\\u0430\r\n\r\n#XFLD,20: W6: Label for Expiration Date used in Quotations\r\nEXPIRATION_DATE=\\u0414\\u0430\\u0442\\u0430 \\u0438\\u0441\\u0442\\u0435\\u0447\\u0435\\u043D\\u0438\\u044F \\u0441\\u0440\\u043E\\u043A\\u0430\r\n\r\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\r\nDELIVERY_DATE=\\u0414\\u0430\\u0442\\u0430 \\u043F\\u043E\\u0441\\u0442\\u0430\\u0432\\u043A\\u0438\r\n\r\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\r\nSALES_EMPLOYEE=\\u041C\\u0435\\u043D\\u0435\\u0434\\u0436\\u0435\\u0440 \\u043F\\u0440\\u043E\\u0434\\u0430\\u0436\r\n\r\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\r\nATTRIBUTESET=\\u041D\\u0430\\u0431\\u043E\\u0440 \\u0430\\u0442\\u0440\\u0438\\u0431\\u0443\\u0442\\u043E\\u0432\r\n\r\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\r\nATTRIBUTE=\\u0410\\u0442\\u0440\\u0438\\u0431\\u0443\\u0442\r\n\r\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\r\nVALUE=\\u0417\\u043D\\u0430\\u0447\\u0435\\u043D\\u0438\\u0435\r\n\r\n#XBUT, 20: Button to create an Account\r\nBUTTON_ADD=\\u0414\\u043E\\u0431\\u0430\\u0432\\u0438\\u0442\\u044C\r\n\r\n#XBUT, 20: Button to edit an Account\r\nBUTTON_EDIT=\\u0420\\u0435\\u0434\\u0430\\u043A\\u0442\\u0438\\u0440\\u043E\\u0432\\u0430\\u0442\\u044C\r\n\r\n#XBUT, 20: Button to save changes\r\nBUTTON_SAVE=\\u0421\\u043E\\u0445\\u0440\\u0430\\u043D\\u0438\\u0442\\u044C\r\n\r\n#XBUT, 20: Button to cancel changes\r\nBUTTON_CANCEL=\\u041E\\u0442\\u043C\\u0435\\u043D\\u0438\\u0442\\u044C\r\n\r\n#XBUT, 30: Button which shows the personalization buttons\r\nBUTTON_SHOW_PERSONALIZATION=\\u041F\\u043E\\u043A\\u0430\\u0437\\u0430\\u0442\\u044C \\u043F\\u0435\\u0440\\u0441\\u043E\\u043D\\u0430\\u043B\\u0438\\u0437\\u0430\\u0446\\u0438\\u044E\r\n\r\n#XBUT, 30: Button which hides the personalization buttons\r\nBUTTON_HIDE_PERSONALIZATION=\\u0421\\u043A\\u0440\\u044B\\u0442\\u044C \\u043F\\u0435\\u0440\\u0441\\u043E\\u043D\\u0430\\u043B\\u0438\\u0437\\u0430\\u0446\\u0438\\u044E\r\n\r\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_CONFIRM_CANCEL=\\u0412\\u0441\\u0435 \\u043D\\u0435\\u0441\\u043E\\u0445\\u0440\\u0430\\u043D\\u0435\\u043D\\u043D\\u044B\\u0435 \\u0438\\u0437\\u043C\\u0435\\u043D\\u0435\\u043D\\u0438\\u044F \\u0431\\u0443\\u0434\\u0443\\u0442 \\u043F\\u043E\\u0442\\u0435\\u0440\\u044F\\u043D\\u044B. \\u041F\\u0440\\u043E\\u0434\\u043E\\u043B\\u0436\\u0438\\u0442\\u044C?\r\n\r\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\r\nMSG_CONFIRM_DELETE_CONTACT=\\u041F\\u0440\\u0438\\u0441\\u0432\\u043E\\u0435\\u043D\\u0438\\u0435 \\u043A\\u043E\\u043D\\u0442\\u0430\\u043A\\u0442\\u0430 \\u043A\\u043B\\u0438\\u0435\\u043D\\u0442\\u0443 \\u0431\\u0443\\u0434\\u0435\\u0442 \\u043E\\u0442\\u043C\\u0435\\u043D\\u0435\\u043D\\u043E. \\u041F\\u0440\\u043E\\u0434\\u043E\\u043B\\u0436\\u0438\\u0442\\u044C?\r\n\r\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_SUCCESS=\\u041A\\u043B\\u0438\\u0435\\u043D\\u0442 \\u043E\\u0431\\u043D\\u043E\\u0432\\u043B\\u0435\\u043D\r\n\r\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_ERROR=\\u0421\\u0431\\u043E\\u0439 \\u043E\\u0431\\u043D\\u043E\\u0432\\u043B\\u0435\\u043D\\u0438\\u044F\r\n\r\n# XMSG : Account update succeeded\r\nMSG_CREATION_SUCCESS=\\u041A\\u043B\\u0438\\u0435\\u043D\\u0442 \\u0441\\u043E\\u0437\\u0434\\u0430\\u043D\r\n\r\n# XMSG : Task creation succeeded\r\nMSG_TASK_CREATION_SUCCESS=\\u0417\\u0430\\u0434\\u0430\\u0447\\u0430 \\u0441\\u043E\\u0437\\u0434\\u0430\\u043D\\u0430\r\n\r\n# XMSG : Contact creation failed\r\nMSG_CREATION_ERROR=\\u041D\\u0435 \\u0443\\u0434\\u0430\\u043B\\u043E\\u0441\\u044C \\u0441\\u043E\\u0437\\u0434\\u0430\\u0442\\u044C\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong country\r\nMSG_WRONG_COUNTRY_ERROR=\\u0421\\u0442\\u0440\\u0430\\u043D\\u0430 "{0}" \\u043D\\u0435 \\u0441\\u0443\\u0449\\u0435\\u0441\\u0442\\u0432\\u0443\\u0435\\u0442\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong region\r\nMSG_WRONG_REGION_ERROR=\\u0420\\u0435\\u0433\\u0438\\u043E\\u043D "{0}" \\u043D\\u0435 \\u0441\\u0443\\u0449\\u0435\\u0441\\u0442\\u0432\\u0443\\u0435\\u0442 \\u0432 \\u044D\\u0442\\u043E\\u0439 \\u0441\\u0442\\u0440\\u0430\\u043D\\u0435\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong employee\r\nMSG_WRONG_EMPLOYEE_ERROR=\\u0421\\u043E\\u0442\\u0440\\u0443\\u0434\\u043D\\u0438\\u043A "{0}" \\u043D\\u0435 \\u0441\\u0443\\u0449\\u0435\\u0441\\u0442\\u0432\\u0443\\u0435\\u0442.\r\n\r\n# XMSG: message that will be displayed, if the user has entered invalid website url\r\nMSG_WRONG_URL_ERROR=\\u0412\\u0432\\u0435\\u0434\\u0435\\u043D\\u043D\\u044B\\u0439 URL "{0}" \\u043D\\u0435\\u0434\\u0435\\u0439\\u0441\\u0442\\u0432\\u0438\\u0442\\u0435\\u043B\\u0435\\u043D.\r\n\r\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\r\nMSG_MANDATORY_FIELDS=\\u041D\\u0435 \\u0432\\u0441\\u0435 \\u043E\\u0431\\u044F\\u0437\\u0430\\u0442\\u0435\\u043B\\u044C\\u043D\\u044B\\u0435 \\u043F\\u043E\\u043B\\u044F \\u0437\\u0430\\u043F\\u043E\\u043B\\u043D\\u0435\\u043D\\u044B\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA=\\u0414\\u0430\\u043D\\u043D\\u044B\\u0435 \\u0438\\u0437\\u043C\\u0435\\u043D\\u0435\\u043D\\u044B \\u0434\\u0440\\u0443\\u0433\\u0438\\u043C \\u043F\\u043E\\u043B\\u044C\\u0437\\u043E\\u0432\\u0430\\u0442\\u0435\\u043B\\u0435\\u043C. \\u041F\\u0435\\u0440\\u0435\\u0437\\u0430\\u043F\\u0438\\u0441\\u0430\\u0442\\u044C \\u0438\\u0437\\u043C\\u0435\\u043D\\u0435\\u043D\\u0438\\u044F \\u0434\\u0440\\u0443\\u0433\\u043E\\u0433\\u043E \\u043F\\u043E\\u043B\\u044C\\u0437\\u043E\\u0432\\u0430\\u0442\\u0435\\u043B\\u044F \\u0441\\u0432\\u043E\\u0438\\u043C\\u0438?\r\n\r\n# XMSG: message that will be displayed in case of conflicts during file renaming\r\nMSG_CONFLICTING_FILE_NAME=\\u0418\\u043C\\u044F \\u0444\\u0430\\u0439\\u043B\\u0430 \\u0438\\u0437\\u043C\\u0435\\u043D\\u0435\\u043D\\u043E \\u0434\\u0440\\u0443\\u0433\\u0438\\u043C \\u043F\\u043E\\u043B\\u044C\\u0437\\u043E\\u0432\\u0430\\u0442\\u0435\\u043B\\u0435\\u043C. \\u041F\\u0435\\u0440\\u0435\\u0437\\u0430\\u043F\\u0438\\u0441\\u0430\\u0442\\u044C \\u0438\\u0437\\u043C\\u0435\\u043D\\u0435\\u043D\\u0438\\u044F \\u0434\\u0440\\u0443\\u0433\\u043E\\u0433\\u043E \\u043F\\u043E\\u043B\\u044C\\u0437\\u043E\\u0432\\u0430\\u0442\\u0435\\u043B\\u044F \\u0441\\u0432\\u043E\\u0438\\u043C\\u0438?\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA_WITH_REFRESH=\\u0414\\u0430\\u043D\\u043D\\u044B\\u0435 \\u0438\\u0437\\u043C\\u0435\\u043D\\u0435\\u043D\\u044B \\u0434\\u0440\\u0443\\u0433\\u0438\\u043C \\u043F\\u043E\\u043B\\u044C\\u0437\\u043E\\u0432\\u0430\\u0442\\u0435\\u043B\\u0435\\u043C. \\u042D\\u0442\\u0438 \\u0438\\u0437\\u043C\\u0435\\u043D\\u0435\\u043D\\u0438\\u044F \\u0431\\u0443\\u0434\\u0443\\u0442 \\u043E\\u0442\\u043E\\u0431\\u0440\\u0430\\u0436\\u0435\\u043D\\u044B \\u0432 \\u043F\\u0440\\u0438\\u043B\\u043E\\u0436\\u0435\\u043D\\u0438\\u0438.\r\n\r\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\r\nMSG_NOT_IN_MAIN_CONTACT=\\u0412\\u044B \\u043C\\u043E\\u0436\\u0435\\u0442\\u0435 \\u043F\\u0440\\u043E\\u0441\\u043C\\u043E\\u0442\\u0440\\u0435\\u0442\\u044C \\u0442\\u043E\\u043B\\u044C\\u043A\\u043E \\u0441\\u0432\\u0435\\u0434\\u0435\\u043D\\u0438\\u044F \\u043E \\u043A\\u043E\\u043D\\u0442\\u0430\\u043A\\u0442\\u0430\\u0445, \\u043F\\u0440\\u0438\\u0441\\u0432\\u043E\\u0435\\u043D\\u043D\\u044B\\u0445 \\u044D\\u0442\\u043E\\u043C\\u0443 \\u043A\\u043B\\u0438\\u0435\\u043D\\u0442\\u0443\r\n\r\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\r\nMSG_EXCEEDING_FILE_NAME_LENGTH=\\u0414\\u043B\\u0438\\u043D\\u0430 \\u0438\\u043C\\u0435\\u043D\\u0438 \\u0444\\u0430\\u0439\\u043B\\u0430 \\u043D\\u0435 \\u0434\\u043E\\u043B\\u0436\\u043D\\u0430 \\u043F\\u0440\\u0435\\u0432\\u044B\\u0448\\u0430\\u0442\\u044C 40 \\u0441\\u0438\\u043C\\u0432\\u043E\\u043B\\u043E\\u0432\r\n\r\n# XTOL, 20: tooltip shown on search result list for button to add an account"\r\n\r\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\r\n\r\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\r\n\r\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\r\n\r\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\r\n\r\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\r\n',
		"cus/crm/myaccounts/i18n/i18n_sh.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XFLD, 30: Facet title for general Data\r\nGENERAL_DATA=Op\\u0161ti podaci\r\n\r\n#XTIT, 40: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=Moji klijenti\r\n\r\n#XTIT, 40: this is the title for the detail screen\r\nDETAIL_TITLE=Klijent\r\n\r\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\r\nREVENUE_CURRENT=Prih.-teku\\u0107a god.\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\r\nREVENUE_CURRENT_TOOLTIP=Prihod do dana\\u0161njeg datuma - teku\\u0107a god.\r\n\r\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\r\nREVENUE_LAST=Prihod - PG\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\r\nREVENUE_LAST_TOOLTIP=Prihod - pro\\u0161la godina\r\n\r\n# XFLD, 30: Facet title for opportunities and label in facet general data\r\nOPPORTUNITIES=Prilike\r\n\r\n#XFLD, 30: Facet title for leads\r\nLEADS=Potencijalni klijenti\r\n\r\n#XFLD, 30: Facet title for tasks\r\nTASKS=Zadaci\r\n\r\n#XFLD, 30: Facet title for appointments\r\nAPPOINTMENTS=Sastanci\r\n\r\n#XFLD, 30: Facet title for quotations\r\nQUOTATIONS=Ponude\r\n\r\n#XFLD, 30: Facet title for sales orders\r\nSALES_ORDERS=Prodajni nalozi\r\n\r\n#XFLD, 30: W7: Facet title for marketing attributes\r\nMARKETINGATTRIBUTES=Obele\\u017Eja marketinga\r\n\r\n#XFLD, 30: W6: Title for popup with products\r\nPRODUCTS=Proizvodi\r\n\r\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\r\nEMPLOYEE_RESPONSIBLE=Odgovorni zaposleni\r\n\r\n#XFLD, 30: Facet title for Attachments\r\nATTACHMENTS=Dodaci\r\n\r\n#XFLD, 30: Facet title for Notes\r\nNOTES=Bele\\u0161ke\r\n\r\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\r\nNEW_NOTE=Nova bele\\u0161ka\r\n\r\n#XFLD, 30: Facet title for Contacts\r\nCONTACTS=Kontakti\r\n\r\n#XFLD, 30: Label for Address in facet general data\r\nADDRESS=Adresa\r\n\r\n#XFLD, 30: Label for Opportunities in facet general data\r\nUNWEIGHTED_OPPORTUNITIES=Prilike\r\n\r\n#XFLD, 30: Label for Rating in facet general data\r\nRATING=Vrednovanje\r\n\r\n# XFLD, 30: Label for Next contact in facet Appointments\r\nNEXT_APPOINTMENT=Slede\\u0107i sastanak\r\n\r\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\r\nLAST_APPOINTMENT=Pro\\u0161li sastanak\r\n\r\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\r\nIMAGE=Slika\r\n\r\n#XBUT, 20: Button to show the create actionsheet\r\nCREATE=Kreiraj\r\n\r\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\r\nDISCUSS_ENTRY=Diskutuj na SAP Jam-u\r\n\r\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\r\nSHARE_ENTRY=Podeli na SAP Jam-u\r\n\r\n#XBUT, 20: Button to share the note\r\nDETAIL_BUTTON_SHARE=Podeli\r\n\r\n#XBUT, 20: Button to cancel sharing\r\nDETAIL_BUTTON_CANCEL=Odustani\r\n\r\n#XFLD,20: All accounts for filter\r\nALL_ACCOUNTS=Svi klijenti\r\n\r\n#XFLD,35: All individual accounts for filter\r\nALL_INDIVIDUAL_ACCOUNTS=Svi pojedina\\u010Dni klijenti\r\n\r\n#XFLD,35: All corporate accounts for filter\r\nALL_CORPORATE_ACCOUNTS=Svi korporativni klijenti\r\n\r\n#XFLD,35: All group accounts for filter\r\nALL_ACCOUNT_GROUPS=Sve grupe klijenata\r\n\r\n#XFLD,20: my account for filter\r\nMY_ACCOUNT=Moji klijenti\r\n\r\n#XFLD,35: my individual accounts for filter\r\nMY_INDIVIDUAL_ACCOUNTS=Moji pojedina\\u010Dni klijenti\r\n\r\n#XFLD,35: my corporate accounts for filter\r\nMY_CORPORATE_ACCOUNTS=Moji korporativni klijenti\r\n\r\n#XFLD,35: my group accounts for filter\r\nMY_ACCOUNT_GROUPS=Moje grupe klijenata\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nINDIVIDUAL_ACCOUNT=Pojedina\\u010Dni klijent\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nCORPORATE_ACCOUNT=Korporativni klijent\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nACCOUNT_GROUP=Grupa klijenata\r\n\r\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\r\nSTARTING=Datum po\\u010Detka\\: {0}\r\n\r\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\r\nCLOSING=Datum zatvaranja\\: {0}\r\n\r\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\r\nDUE=Datum dospe\\u0107a\\: {0}\r\n\r\n#XFLD,20: All accounts for title\r\nALL_ACCOUNTS_TITLE=Svi klijenti ({0})\r\n\r\n#XFLD,35: All individual accounts for title\r\nALL_INDIVIDUAL_ACCOUNTS_TITLE=Svi pojedina\\u010Dni klijenti ({0})\r\n\r\n#XFLD,35: All corporate accounts for title\r\nALL_CORPORATE_ACCOUNTS_TITLE=Svi korporativni klijenti ({0})\r\n\r\n#XFLD,35: All group accounts for title\r\nALL_ACCOUNT_GROUPS_TITLE=Sve grupe klijenata ({0})\r\n\r\n#XFLD,20: my account for title\r\nMY_ACCOUNT_TITLE=Moji klijenti ({0})\r\n\r\n#XFLD,35: my individual account for title\r\nMY_INDIVIDUAL_ACCOUNT_TITLE=Moji pojedina\\u010Dni klijenti ({0})\r\n\r\n#XFLD,35: my corporate account for title.\r\nMY_CORPORATE_ACCOUNT_TITLE=Moji korporativni klijenti ({0})\r\n\r\n#XFLD,35: my group account for title\r\nMY_ACCOUNT_GROUP_TITLE=Moje grupe klijenata ({0})\r\n\r\n#XFLD,30: filtered by info\r\nFILTERED_BY=Filtrirano po\\: {0}\r\n\r\n#XFLD,30: label, search for accounts\r\nSEARCH_ACCOUNTS=Tra\\u017Ei\r\n\r\n#XFLD,30: comma separator for location\r\nLOCATION={0}, {1}\r\n\r\n#XFLD: W4: Label for All day text in Appointments\r\nALL_DAY_EVENT=Ceo dan\r\n\r\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\r\nDURATION_MINUTE={0} min\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\r\nDURATION_HOUR={0} s\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\r\nDURATION_DAY={0} dan\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\r\nDURATION_DAYS={0} dana\r\n\r\n#XFLD: W4: Label for Private meeting\r\nPRIVATE=Privatno\r\n\r\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\r\nSELECT_TRANSACTION_TYPE=Odaberi tip transakcije\r\n\r\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\r\nNEW_TASK_INPUT_PLACEHOLDER=Novi zadatak\r\n\r\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nNO_DATA_TEXT=Nema podataka\r\n\r\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nLOADING_TEXT=U\\u010Ditavanje...\r\n\r\n#XFLD,25: W4: Column label for name of contact person in contacts\r\nNAME=Ime\r\n\r\n#XFLD,25: W5: Column label for department of contact person in contacts\r\nDEPARTMENT=Odeljak\r\n\r\n#XFLD,15: W6: Column label for actions of contact person in contacts\r\nACTIONS=Radnje\r\n\r\n#XFLD,25: W4: Column label for description of lead in Leads\r\nDESCRIPTION=Opis\r\n\r\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\r\nASSIGNED_TO=Dodeljeno\r\n\r\n#XFLD,15: W4: Column label for end date of lead in Leads\r\nEND_DATE=Datum zavr\\u0161etka\r\n\r\n#XFLD,15: W4: Column label for qualification level of lead in Leads\r\nQUALIFICATION=Kvalifikacija\r\n\r\n#XFLD,15: W4: Column label for status of lead in Leads\r\nSTATUS=Status\r\n\r\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\r\nMAIN_CONTACT=Glavni kontakt\r\n\r\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\r\nVOLUME=Zapremina\r\n\r\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\r\nPROBABILITY=Verovatno\\u0107a\r\n\r\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\r\nCLOSE_BY=Zatvori do\r\n\r\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \r\nVIEWS=Pogledi\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\r\nCONTACT_TITLE=Kontakt\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\r\nEMPLOYEE_TITLE=Zaposleni\r\n\r\n#XTIT,20: W7: Title of pop-up used in confirm popup\r\nCONFIRM_TITLE=Potvrdi\r\n\r\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\r\nCOMPANY_NAME=Naziv\r\n\r\n#XFLD,20: W4: Label for name 1 of a company used general data\r\nCOMPANY_NAME1=Ime 1\r\n\r\n#XFLD,20: W4: Label for name 2 of a company used general data\r\nCOMPANY_NAME2=Ime 2\r\n\r\n#XFLD,20: W4: Label for first name of a person used general data\r\nFIRST_NAME=Ime\r\n\r\n#XFLD,20: W4: Label for last name of a person used general data\r\nLAST_NAME=Prezime\r\n\r\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nBIRTHDAY=Datum ro\\u0111enja\r\n\r\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nTITLE=Naslov\r\n\r\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nACADEMIC_TITLE=Akademska titula\r\n\r\n#XFLD,20: W4: Label for mobile phone number used general data\r\nMOBILE=Mobilni telefon\r\n\r\n#XFLD,20: W4: Label for phone number used general data\r\nPHONE=Telefon\r\n\r\n#XFLD,20: W4: Label for e-mail used general data\r\nEMAIL=E-po\\u0161ta\r\n\r\n#XFLD,20: W4: Label for web site used general data\r\nWEBSITE=Web lokacija\r\n\r\n#XFLD,20: W4: Label for country used general data\r\nCOUNTRY=Zemlja\r\n\r\n#XFLD,20: W4: Label for region used general data\r\nREGION=Regija\r\n\r\n#XFLD,20: W4: Label for city used general data\r\nCITY=Grad\r\n\r\n#XFLD,20: W4: Label for postal code used general data\r\nPOSTAL_CODE=Po\\u0161tanski broj\r\n\r\n#XFLD,20: W4: Label for street used general data\r\nSTREET=Ulica\r\n\r\n#XFLD,10: W4: Label for house number used general data\r\nHOUSE_NUMBER=Ku\\u0107ni broj\r\n\r\n#XFLD,15: W6: Label for ID used in Quotations\r\nID=ID\r\n\r\n#XFLD,15: W6: Label for Amount used in Quotations\r\nAMOUNT=Iznos\r\n\r\n#XFLD,20: W6: Label for Expiration Date used in Quotations\r\nEXPIRATION_DATE=Datum isteka\r\n\r\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\r\nDELIVERY_DATE=Datum isporuke\r\n\r\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\r\nSALES_EMPLOYEE=Zaposleni u prodaji\r\n\r\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\r\nATTRIBUTESET=Skup obele\\u017Eja\r\n\r\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\r\nATTRIBUTE=Obele\\u017Eje\r\n\r\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\r\nVALUE=Vrednost\r\n\r\n#XBUT, 20: Button to create an Account\r\nBUTTON_ADD=Dodaj\r\n\r\n#XBUT, 20: Button to edit an Account\r\nBUTTON_EDIT=Uredi\r\n\r\n#XBUT, 20: Button to save changes\r\nBUTTON_SAVE=Sa\\u010Duvaj\r\n\r\n#XBUT, 20: Button to cancel changes\r\nBUTTON_CANCEL=Odustani\r\n\r\n#XBUT, 30: Button which shows the personalization buttons\r\nBUTTON_SHOW_PERSONALIZATION=Prika\\u017Ei personalizaciju\r\n\r\n#XBUT, 30: Button which hides the personalization buttons\r\nBUTTON_HIDE_PERSONALIZATION=Sakrij personalizaciju\r\n\r\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_CONFIRM_CANCEL=Sve nesa\\u010Duvane promene \\u0107e biti izgubljene. Da li \\u017Eelite da nastavite?\r\n\r\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\r\nMSG_CONFIRM_DELETE_CONTACT=Dodela kontakta klijentu \\u0107e biti poni\\u0161tena. Da li \\u017Eelite da nastavite?\r\n\r\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_SUCCESS=Klijent a\\u017Euriran\r\n\r\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_ERROR=A\\u017Euriranje nije uspelo\r\n\r\n# XMSG : Account update succeeded\r\nMSG_CREATION_SUCCESS=Klijent kreiran\r\n\r\n# XMSG : Task creation succeeded\r\nMSG_TASK_CREATION_SUCCESS=Zadatak kreiran\r\n\r\n# XMSG : Contact creation failed\r\nMSG_CREATION_ERROR=Kreiranje nije uspelo\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong country\r\nMSG_WRONG_COUNTRY_ERROR=Zemlja "{0}" ne postoji\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong region\r\nMSG_WRONG_REGION_ERROR=Regija "{0}" ne postoji za zemlju\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong employee\r\nMSG_WRONG_EMPLOYEE_ERROR=Zaposleni "{0}" ne postoji\r\n\r\n# XMSG: message that will be displayed, if the user has entered invalid website url\r\nMSG_WRONG_URL_ERROR=Uneti URL "{0}" nije va\\u017Ee\\u0107i.\r\n\r\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\r\nMSG_MANDATORY_FIELDS=Nisu popunjena sva obavezna polja\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA=Podatke je zamenio drugi korisnik. Da li \\u017Eelite da pi\\u0161ete sopstvene promene preko promena drugog korisnika?\r\n\r\n# XMSG: message that will be displayed in case of conflicts during file renaming\r\nMSG_CONFLICTING_FILE_NAME=Naziv fajla je promenio drugi korisnik. Da li \\u017Eelite da pi\\u0161ete sopstvene promene preko promena drugog korisnika?\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA_WITH_REFRESH=Podatke je promenio drugi korisnik. Ove promene \\u0107e se sada pojaviti u aplikaciji.\r\n\r\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\r\nMSG_NOT_IN_MAIN_CONTACT=Mo\\u017Eete pregledati samo detalje kontakata koji su dodeljeni ovom klijentu\r\n\r\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\r\nMSG_EXCEEDING_FILE_NAME_LENGTH=Va\\u0161 naziv fajla mo\\u017Ee imati maksimalno 40 znakova.\r\n\r\n# XTOL, 20: tooltip shown on search result list for button to add an account"\r\n\r\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\r\n\r\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\r\n\r\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\r\n\r\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\r\n\r\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\r\n',
		"cus/crm/myaccounts/i18n/i18n_sk.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XFLD, 30: Facet title for general Data\r\nGENERAL_DATA=V\\u0161eobecn\\u00E9 d\\u00E1ta\r\n\r\n#XTIT, 40: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=Moji z\\u00E1kazn\\u00EDci\r\n\r\n#XTIT, 40: this is the title for the detail screen\r\nDETAIL_TITLE=Z\\u00E1kazn\\u00EDk\r\n\r\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\r\nREVENUE_CURRENT=V\\u00FDnos-AktRokDodnes\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\r\nREVENUE_CURRENT_TOOLTIP=V\\u00FDnosy dodnes (aktu\\u00E1lny rok)\r\n\r\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\r\nREVENUE_LAST=V\\u00FDnos posledn\\u00FD rok\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\r\nREVENUE_LAST_TOOLTIP=V\\u00FDnosy posledn\\u00FD rok\r\n\r\n# XFLD, 30: Facet title for opportunities and label in facet general data\r\nOPPORTUNITIES=Pr\\u00EDle\\u017Eitosti\r\n\r\n#XFLD, 30: Facet title for leads\r\nLEADS=Tipy\r\n\r\n#XFLD, 30: Facet title for tasks\r\nTASKS=\\u00DAlohy\r\n\r\n#XFLD, 30: Facet title for appointments\r\nAPPOINTMENTS=Sch\\u00F4dzky\r\n\r\n#XFLD, 30: Facet title for quotations\r\nQUOTATIONS=Ponuky\r\n\r\n#XFLD, 30: Facet title for sales orders\r\nSALES_ORDERS=Z\\u00E1kazky odberate\\u013Ea\r\n\r\n#XFLD, 30: W7: Facet title for marketing attributes\r\nMARKETINGATTRIBUTES=Marketingov\\u00E9 atrib\\u00FAty\r\n\r\n#XFLD, 30: W6: Title for popup with products\r\nPRODUCTS=Produkty\r\n\r\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\r\nEMPLOYEE_RESPONSIBLE=Zodpovedn\\u00FD zamestnanec\r\n\r\n#XFLD, 30: Facet title for Attachments\r\nATTACHMENTS=Pr\\u00EDlohy\r\n\r\n#XFLD, 30: Facet title for Notes\r\nNOTES=Pozn\\u00E1mky\r\n\r\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\r\nNEW_NOTE=Nov\\u00E1 pozn\\u00E1mka\r\n\r\n#XFLD, 30: Facet title for Contacts\r\nCONTACTS=Kontakty\r\n\r\n#XFLD, 30: Label for Address in facet general data\r\nADDRESS=Adresa\r\n\r\n#XFLD, 30: Label for Opportunities in facet general data\r\nUNWEIGHTED_OPPORTUNITIES=Pr\\u00EDle\\u017Eitosti\r\n\r\n#XFLD, 30: Label for Rating in facet general data\r\nRATING=Hodnotenie\r\n\r\n# XFLD, 30: Label for Next contact in facet Appointments\r\nNEXT_APPOINTMENT=\\u010Eal\\u0161ia sch\\u00F4dzka\r\n\r\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\r\nLAST_APPOINTMENT=Posledn\\u00E1 sch\\u00F4dzka\r\n\r\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\r\nIMAGE=Obr\\u00E1zok\r\n\r\n#XBUT, 20: Button to show the create actionsheet\r\nCREATE=Vytvori\\u0165\r\n\r\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\r\nDISCUSS_ENTRY=Diskutova\\u0165 v SAP Jam\r\n\r\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\r\nSHARE_ENTRY=Zdie\\u013Ea\\u0165 v SAP Jam\r\n\r\n#XBUT, 20: Button to share the note\r\nDETAIL_BUTTON_SHARE=Zdie\\u013Ea\\u0165\r\n\r\n#XBUT, 20: Button to cancel sharing\r\nDETAIL_BUTTON_CANCEL=Zru\\u0161i\\u0165\r\n\r\n#XFLD,20: All accounts for filter\r\nALL_ACCOUNTS=V\\u0161etci z\\u00E1kazn\\u00EDci\r\n\r\n#XFLD,35: All individual accounts for filter\r\nALL_INDIVIDUAL_ACCOUNTS=V\\u0161etci jednotliv\\u00ED z\\u00E1kazn\\u00EDci\r\n\r\n#XFLD,35: All corporate accounts for filter\r\nALL_CORPORATE_ACCOUNTS=V\\u0161etci podnikov\\u00ED z\\u00E1kazn\\u00EDci\r\n\r\n#XFLD,35: All group accounts for filter\r\nALL_ACCOUNT_GROUPS=V\\u0161etky skupiny z\\u00E1kazn\\u00EDkov\r\n\r\n#XFLD,20: my account for filter\r\nMY_ACCOUNT=Moji z\\u00E1kazn\\u00EDci\r\n\r\n#XFLD,35: my individual accounts for filter\r\nMY_INDIVIDUAL_ACCOUNTS=Moji jednotliv\\u00ED z\\u00E1kazn\\u00EDci\r\n\r\n#XFLD,35: my corporate accounts for filter\r\nMY_CORPORATE_ACCOUNTS=Moji podnikov\\u00ED z\\u00E1kazn\\u00EDci\r\n\r\n#XFLD,35: my group accounts for filter\r\nMY_ACCOUNT_GROUPS=Moje skupiny z\\u00E1kazn\\u00EDkov\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nINDIVIDUAL_ACCOUNT=Jednotliv\\u00FD z\\u00E1kazn\\u00EDk\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nCORPORATE_ACCOUNT=Podnikov\\u00FD z\\u00E1kazn\\u00EDk\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nACCOUNT_GROUP=\\u00DA\\u010Dtov\\u00E1 skupina\r\n\r\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\r\nSTARTING=Po\\u010Diato\\u010Dn\\u00FD d\\u00E1tum\\: {0}\r\n\r\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\r\nCLOSING=D\\u00E1tum uzavretia\\: {0}\r\n\r\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\r\nDUE=Term\\u00EDn\\: {0}\r\n\r\n#XFLD,20: All accounts for title\r\nALL_ACCOUNTS_TITLE=V\\u0161etci z\\u00E1kazn\\u00EDci ({0})\r\n\r\n#XFLD,35: All individual accounts for title\r\nALL_INDIVIDUAL_ACCOUNTS_TITLE=V\\u0161etci jednotliv\\u00ED z\\u00E1kazn\\u00EDci ({0})\r\n\r\n#XFLD,35: All corporate accounts for title\r\nALL_CORPORATE_ACCOUNTS_TITLE=V\\u0161etci podnikov\\u00ED z\\u00E1kazn\\u00EDci ({0})\r\n\r\n#XFLD,35: All group accounts for title\r\nALL_ACCOUNT_GROUPS_TITLE=V\\u0161etky skupiny z\\u00E1kazn\\u00EDkov ({0})\r\n\r\n#XFLD,20: my account for title\r\nMY_ACCOUNT_TITLE=Moji z\\u00E1kazn\\u00EDci ({0})\r\n\r\n#XFLD,35: my individual account for title\r\nMY_INDIVIDUAL_ACCOUNT_TITLE=Moji jednotliv\\u00ED z\\u00E1kazn\\u00EDci ({0})\r\n\r\n#XFLD,35: my corporate account for title.\r\nMY_CORPORATE_ACCOUNT_TITLE=Moji podnikov\\u00ED z\\u00E1kazn\\u00EDci ({0})\r\n\r\n#XFLD,35: my group account for title\r\nMY_ACCOUNT_GROUP_TITLE=Moje skupiny z\\u00E1kazn\\u00EDkov ({0})\r\n\r\n#XFLD,30: filtered by info\r\nFILTERED_BY=Filtrovan\\u00E9 pod\\u013Ea\\: {0}\r\n\r\n#XFLD,30: label, search for accounts\r\nSEARCH_ACCOUNTS=H\\u013Eada\\u0165\r\n\r\n#XFLD,30: comma separator for location\r\nLOCATION={0}, {1}\r\n\r\n#XFLD: W4: Label for All day text in Appointments\r\nALL_DAY_EVENT=Cel\\u00FD de\\u0148\r\n\r\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\r\nDURATION_MINUTE={0} min\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\r\nDURATION_HOUR={0} hod\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\r\nDURATION_DAY={0} de\\u0148\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\r\nDURATION_DAYS={0} dn\\u00ED\r\n\r\n#XFLD: W4: Label for Private meeting\r\nPRIVATE=S\\u00FAkromn\\u00E9\r\n\r\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\r\nSELECT_TRANSACTION_TYPE=Vybra\\u0165 typ transakcie\r\n\r\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\r\nNEW_TASK_INPUT_PLACEHOLDER=Nov\\u00E1 \\u00FAloha\r\n\r\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nNO_DATA_TEXT=\\u017Diadne d\\u00E1ta\r\n\r\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nLOADING_TEXT=Na\\u010D\\u00EDtava sa...\r\n\r\n#XFLD,25: W4: Column label for name of contact person in contacts\r\nNAME=Meno\r\n\r\n#XFLD,25: W5: Column label for department of contact person in contacts\r\nDEPARTMENT=Oddelenie\r\n\r\n#XFLD,15: W6: Column label for actions of contact person in contacts\r\nACTIONS=Akcie\r\n\r\n#XFLD,25: W4: Column label for description of lead in Leads\r\nDESCRIPTION=Popis\r\n\r\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\r\nASSIGNED_TO=Priraden\\u00E9 k\r\n\r\n#XFLD,15: W4: Column label for end date of lead in Leads\r\nEND_DATE=Koncov\\u00FD d\\u00E1tum\r\n\r\n#XFLD,15: W4: Column label for qualification level of lead in Leads\r\nQUALIFICATION=Kvalifik\\u00E1cia\r\n\r\n#XFLD,15: W4: Column label for status of lead in Leads\r\nSTATUS=Stav\r\n\r\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\r\nMAIN_CONTACT=Hlavn\\u00FD kontakt\r\n\r\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\r\nVOLUME=Objem\r\n\r\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\r\nPROBABILITY=Pravdepodobnos\\u0165\r\n\r\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\r\nCLOSE_BY=Uzavretie do\r\n\r\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \r\nVIEWS=N\\u00E1h\\u013Eady\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\r\nCONTACT_TITLE=Kontakt\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\r\nEMPLOYEE_TITLE=Zamestnanec\r\n\r\n#XTIT,20: W7: Title of pop-up used in confirm popup\r\nCONFIRM_TITLE=Potvrdenie\r\n\r\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\r\nCOMPANY_NAME=N\\u00E1zov\r\n\r\n#XFLD,20: W4: Label for name 1 of a company used general data\r\nCOMPANY_NAME1=N\\u00E1zov 1\r\n\r\n#XFLD,20: W4: Label for name 2 of a company used general data\r\nCOMPANY_NAME2=N\\u00E1zov 2\r\n\r\n#XFLD,20: W4: Label for first name of a person used general data\r\nFIRST_NAME=Meno\r\n\r\n#XFLD,20: W4: Label for last name of a person used general data\r\nLAST_NAME=Priezvisko\r\n\r\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nBIRTHDAY=D\\u00E1tum narodenia\r\n\r\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nTITLE=Oslovenie\r\n\r\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nACADEMIC_TITLE=Akademick\\u00FD titul\r\n\r\n#XFLD,20: W4: Label for mobile phone number used general data\r\nMOBILE=Mobiln\\u00FD telef\\u00F3n\r\n\r\n#XFLD,20: W4: Label for phone number used general data\r\nPHONE=Telef\\u00F3n\r\n\r\n#XFLD,20: W4: Label for e-mail used general data\r\nEMAIL=E-mail\r\n\r\n#XFLD,20: W4: Label for web site used general data\r\nWEBSITE=Webov\\u00E1 lokalita\r\n\r\n#XFLD,20: W4: Label for country used general data\r\nCOUNTRY=\\u0160t\\u00E1t\r\n\r\n#XFLD,20: W4: Label for region used general data\r\nREGION=Regi\\u00F3n\r\n\r\n#XFLD,20: W4: Label for city used general data\r\nCITY=Mesto\r\n\r\n#XFLD,20: W4: Label for postal code used general data\r\nPOSTAL_CODE=PS\\u010C\r\n\r\n#XFLD,20: W4: Label for street used general data\r\nSTREET=Ulica\r\n\r\n#XFLD,10: W4: Label for house number used general data\r\nHOUSE_NUMBER=\\u010C.domu\r\n\r\n#XFLD,15: W6: Label for ID used in Quotations\r\nID=ID\r\n\r\n#XFLD,15: W6: Label for Amount used in Quotations\r\nAMOUNT=\\u010Ciastka\r\n\r\n#XFLD,20: W6: Label for Expiration Date used in Quotations\r\nEXPIRATION_DATE=D\\u00E1tum exspir\\u00E1cie\r\n\r\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\r\nDELIVERY_DATE=D\\u00E1tum dod\\u00E1vky\r\n\r\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\r\nSALES_EMPLOYEE=Pracovn\\u00EDk odbytu\r\n\r\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\r\nATTRIBUTESET=Skupina atrib\\u00FAtov\r\n\r\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\r\nATTRIBUTE=Atrib\\u00FAt\r\n\r\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\r\nVALUE=Hodnota\r\n\r\n#XBUT, 20: Button to create an Account\r\nBUTTON_ADD=Prida\\u0165\r\n\r\n#XBUT, 20: Button to edit an Account\r\nBUTTON_EDIT=Upravi\\u0165\r\n\r\n#XBUT, 20: Button to save changes\r\nBUTTON_SAVE=Ulo\\u017Ei\\u0165\r\n\r\n#XBUT, 20: Button to cancel changes\r\nBUTTON_CANCEL=Zru\\u0161i\\u0165\r\n\r\n#XBUT, 30: Button which shows the personalization buttons\r\nBUTTON_SHOW_PERSONALIZATION=Zobrazi\\u0165 personaliz\\u00E1ciu\r\n\r\n#XBUT, 30: Button which hides the personalization buttons\r\nBUTTON_HIDE_PERSONALIZATION=Skry\\u0165 personaliz\\u00E1ciu\r\n\r\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_CONFIRM_CANCEL=V\\u0161etky neulo\\u017Een\\u00E9 zmeny sa stratia. Chcete pokra\\u010Dova\\u0165?\r\n\r\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\r\nMSG_CONFIRM_DELETE_CONTACT=Priradenie kontaktu k z\\u00E1kazn\\u00EDkovi bude zru\\u0161en\\u00E9. Chcete pokra\\u010Dova\\u0165?\r\n\r\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_SUCCESS=Z\\u00E1kazn\\u00EDk aktualizovan\\u00FD\r\n\r\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_ERROR=Aktualiz\\u00E1cia sa nepodarila\r\n\r\n# XMSG : Account update succeeded\r\nMSG_CREATION_SUCCESS=Z\\u00E1kazn\\u00EDk vytvoren\\u00FD\r\n\r\n# XMSG : Task creation succeeded\r\nMSG_TASK_CREATION_SUCCESS=\\u00DAloha vytvoren\\u00E1\r\n\r\n# XMSG : Contact creation failed\r\nMSG_CREATION_ERROR=Vytvorenie sa nepodarilo\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong country\r\nMSG_WRONG_COUNTRY_ERROR=\\u0160t\\u00E1t "{0}" neexistuje\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong region\r\nMSG_WRONG_REGION_ERROR=Regi\\u00F3n "{0}" neexistuje pre \\u0161t\\u00E1t\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong employee\r\nMSG_WRONG_EMPLOYEE_ERROR=Zamestnanec "{0}" neexistuje.\r\n\r\n# XMSG: message that will be displayed, if the user has entered invalid website url\r\nMSG_WRONG_URL_ERROR=Zadan\\u00E1 adresa URL "{0}" nie je platn\\u00E1.\r\n\r\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\r\nMSG_MANDATORY_FIELDS=Nie s\\u00FA vyplnen\\u00E9 v\\u0161etky povinn\\u00E9 polia\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA=D\\u00E1ta zmenil in\\u00FD pou\\u017E\\u00EDvate\\u013E. Chcete zmeny in\\u00E9ho pou\\u017E\\u00EDvate\\u013Ea prep\\u00EDsa\\u0165 vlastn\\u00FDmi zmenami?\r\n\r\n# XMSG: message that will be displayed in case of conflicts during file renaming\r\nMSG_CONFLICTING_FILE_NAME=N\\u00E1zov s\\u00FAboru zmenil in\\u00FD pou\\u017E\\u00EDvate\\u013E. Chcete zmeny in\\u00E9ho pou\\u017E\\u00EDvate\\u013Ea prep\\u00EDsa\\u0165 vlastn\\u00FDmi zmenami?\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA_WITH_REFRESH=D\\u00E1ta zmenil in\\u00FD pou\\u017E\\u00EDvate\\u013E. Tieto zmeny sa teraz zobrazia v aplik\\u00E1cii.\r\n\r\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\r\nMSG_NOT_IN_MAIN_CONTACT=M\\u00F4\\u017Eete zobrazi\\u0165 len detaily kontaktov, ktor\\u00E9 s\\u00FA priraden\\u00E9 tomuto z\\u00E1kazn\\u00EDkovi\r\n\r\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\r\nMSG_EXCEEDING_FILE_NAME_LENGTH=N\\u00E1zov s\\u00FAboru m\\u00F4\\u017Ee ma\\u0165 maxim\\u00E1lne 40 znakov.\r\n\r\n# XTOL, 20: tooltip shown on search result list for button to add an account"\r\n\r\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\r\n\r\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\r\n\r\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\r\n\r\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\r\n\r\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\r\n',
		"cus/crm/myaccounts/i18n/i18n_sl.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XFLD, 30: Facet title for general Data\r\nGENERAL_DATA=Splo\\u0161ni podatki\r\n\r\n#XTIT, 40: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=Moje stranke\r\n\r\n#XTIT, 40: this is the title for the detail screen\r\nDETAIL_TITLE=Stranka\r\n\r\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\r\nREVENUE_CURRENT=Prihodki kumulir.\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\r\nREVENUE_CURRENT_TOOLTIP=Prihodki do datuma v trenutnem letu\r\n\r\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\r\nREVENUE_LAST=Prih.v zadn.letu\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\r\nREVENUE_LAST_TOOLTIP=Prihodki v zadnjem letu\r\n\r\n# XFLD, 30: Facet title for opportunities and label in facet general data\r\nOPPORTUNITIES=Prilo\\u017Enosti\r\n\r\n#XFLD, 30: Facet title for leads\r\nLEADS=Potencialne stranke\r\n\r\n#XFLD, 30: Facet title for tasks\r\nTASKS=Opravila\r\n\r\n#XFLD, 30: Facet title for appointments\r\nAPPOINTMENTS=Termini\r\n\r\n#XFLD, 30: Facet title for quotations\r\nQUOTATIONS=Ponudbe\r\n\r\n#XFLD, 30: Facet title for sales orders\r\nSALES_ORDERS=Prodajni nalogi\r\n\r\n#XFLD, 30: W7: Facet title for marketing attributes\r\nMARKETINGATTRIBUTES=Marketin\\u0161ki atributi\r\n\r\n#XFLD, 30: W6: Title for popup with products\r\nPRODUCTS=Proizvodi\r\n\r\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\r\nEMPLOYEE_RESPONSIBLE=Odgovorni zaposleni\r\n\r\n#XFLD, 30: Facet title for Attachments\r\nATTACHMENTS=Priloge\r\n\r\n#XFLD, 30: Facet title for Notes\r\nNOTES=Zabele\\u017Eke\r\n\r\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\r\nNEW_NOTE=Nova zabele\\u017Eka\r\n\r\n#XFLD, 30: Facet title for Contacts\r\nCONTACTS=Kontaktne osebe\r\n\r\n#XFLD, 30: Label for Address in facet general data\r\nADDRESS=Naslov\r\n\r\n#XFLD, 30: Label for Opportunities in facet general data\r\nUNWEIGHTED_OPPORTUNITIES=Prilo\\u017Enosti\r\n\r\n#XFLD, 30: Label for Rating in facet general data\r\nRATING=Vrednotenje\r\n\r\n# XFLD, 30: Label for Next contact in facet Appointments\r\nNEXT_APPOINTMENT=Naslednji termin\r\n\r\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\r\nLAST_APPOINTMENT=Zadnji termin\r\n\r\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\r\nIMAGE=Slika\r\n\r\n#XBUT, 20: Button to show the create actionsheet\r\nCREATE=Kreiranje\r\n\r\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\r\nDISCUSS_ENTRY=Razprava v SAP Jam\r\n\r\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\r\nSHARE_ENTRY=Skupna raba v SAP Jam\r\n\r\n#XBUT, 20: Button to share the note\r\nDETAIL_BUTTON_SHARE=Dele\\u017E\r\n\r\n#XBUT, 20: Button to cancel sharing\r\nDETAIL_BUTTON_CANCEL=Prekinitev\r\n\r\n#XFLD,20: All accounts for filter\r\nALL_ACCOUNTS=Vse stranke\r\n\r\n#XFLD,35: All individual accounts for filter\r\nALL_INDIVIDUAL_ACCOUNTS=Vse posamezne stranke\r\n\r\n#XFLD,35: All corporate accounts for filter\r\nALL_CORPORATE_ACCOUNTS=Vse pravne stranke\r\n\r\n#XFLD,35: All group accounts for filter\r\nALL_ACCOUNT_GROUPS=Vse skupine strank\r\n\r\n#XFLD,20: my account for filter\r\nMY_ACCOUNT=Moje stranke\r\n\r\n#XFLD,35: my individual accounts for filter\r\nMY_INDIVIDUAL_ACCOUNTS=Moje posamezne stranke\r\n\r\n#XFLD,35: my corporate accounts for filter\r\nMY_CORPORATE_ACCOUNTS=Moje pravne stranke\r\n\r\n#XFLD,35: my group accounts for filter\r\nMY_ACCOUNT_GROUPS=Moje skupine strank\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nINDIVIDUAL_ACCOUNT=Posamezna stranka\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nCORPORATE_ACCOUNT=Pravna stranka\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nACCOUNT_GROUP=Skupina ra\\u010Dunov\r\n\r\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\r\nSTARTING=Datum za\\u010Detka\\: {0}\r\n\r\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\r\nCLOSING=Datum zaklju\\u010Dka\\: {0}\r\n\r\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\r\nDUE=Datum zapadlosti\\: {0}\r\n\r\n#XFLD,20: All accounts for title\r\nALL_ACCOUNTS_TITLE=Vse stranke ({0})\r\n\r\n#XFLD,35: All individual accounts for title\r\nALL_INDIVIDUAL_ACCOUNTS_TITLE=Vse posamezne stranke ({0})\r\n\r\n#XFLD,35: All corporate accounts for title\r\nALL_CORPORATE_ACCOUNTS_TITLE=Vse pravne stranke ({0})\r\n\r\n#XFLD,35: All group accounts for title\r\nALL_ACCOUNT_GROUPS_TITLE=Vse skupine strank ({0})\r\n\r\n#XFLD,20: my account for title\r\nMY_ACCOUNT_TITLE=Moje stranke ({0})\r\n\r\n#XFLD,35: my individual account for title\r\nMY_INDIVIDUAL_ACCOUNT_TITLE=Moje posamezne stranke ({0})\r\n\r\n#XFLD,35: my corporate account for title.\r\nMY_CORPORATE_ACCOUNT_TITLE=Moje pravne stranke ({0})\r\n\r\n#XFLD,35: my group account for title\r\nMY_ACCOUNT_GROUP_TITLE=Moje skupine strank ({0})\r\n\r\n#XFLD,30: filtered by info\r\nFILTERED_BY=Filtrirano po\\: {0}\r\n\r\n#XFLD,30: label, search for accounts\r\nSEARCH_ACCOUNTS=Iskanje\r\n\r\n#XFLD,30: comma separator for location\r\nLOCATION={0}, {1}\r\n\r\n#XFLD: W4: Label for All day text in Appointments\r\nALL_DAY_EVENT=Ves dan\r\n\r\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\r\nDURATION_MINUTE={0} min\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\r\nDURATION_HOUR={0} h\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\r\nDURATION_DAY={0} dan\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\r\nDURATION_DAYS={0} dni\r\n\r\n#XFLD: W4: Label for Private meeting\r\nPRIVATE=Privatno\r\n\r\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\r\nSELECT_TRANSACTION_TYPE=Izberite tip transakcije\r\n\r\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\r\nNEW_TASK_INPUT_PLACEHOLDER=Nova naloga\r\n\r\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nNO_DATA_TEXT=Ni podatkov\r\n\r\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nLOADING_TEXT=Nalaganje ...\r\n\r\n#XFLD,25: W4: Column label for name of contact person in contacts\r\nNAME=Naziv\r\n\r\n#XFLD,25: W5: Column label for department of contact person in contacts\r\nDEPARTMENT=Oddelek\r\n\r\n#XFLD,15: W6: Column label for actions of contact person in contacts\r\nACTIONS=Akcije\r\n\r\n#XFLD,25: W4: Column label for description of lead in Leads\r\nDESCRIPTION=Opis\r\n\r\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\r\nASSIGNED_TO=Dodeljeno za\r\n\r\n#XFLD,15: W4: Column label for end date of lead in Leads\r\nEND_DATE=Datum konca\r\n\r\n#XFLD,15: W4: Column label for qualification level of lead in Leads\r\nQUALIFICATION=Kvalifikacija\r\n\r\n#XFLD,15: W4: Column label for status of lead in Leads\r\nSTATUS=Status\r\n\r\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\r\nMAIN_CONTACT=Glavna kontaktna oseba\r\n\r\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\r\nVOLUME=Glasnost\r\n\r\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\r\nPROBABILITY=Verjetnost\r\n\r\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\r\nCLOSE_BY=Zaklju\\u010Dek do\r\n\r\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \r\nVIEWS=Pogledi\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\r\nCONTACT_TITLE=Kontakt\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\r\nEMPLOYEE_TITLE=Zaposleni\r\n\r\n#XTIT,20: W7: Title of pop-up used in confirm popup\r\nCONFIRM_TITLE=Potrditev\r\n\r\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\r\nCOMPANY_NAME=Naziv\r\n\r\n#XFLD,20: W4: Label for name 1 of a company used general data\r\nCOMPANY_NAME1=Naziv 1\r\n\r\n#XFLD,20: W4: Label for name 2 of a company used general data\r\nCOMPANY_NAME2=Ime 2\r\n\r\n#XFLD,20: W4: Label for first name of a person used general data\r\nFIRST_NAME=Ime\r\n\r\n#XFLD,20: W4: Label for last name of a person used general data\r\nLAST_NAME=Priimek\r\n\r\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nBIRTHDAY=Datum rojstva\r\n\r\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nTITLE=Naslov\r\n\r\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nACADEMIC_TITLE=Akademski naslov\r\n\r\n#XFLD,20: W4: Label for mobile phone number used general data\r\nMOBILE=Mobilna naprava\r\n\r\n#XFLD,20: W4: Label for phone number used general data\r\nPHONE=Telefon\r\n\r\n#XFLD,20: W4: Label for e-mail used general data\r\nEMAIL=E-po\\u0161ta\r\n\r\n#XFLD,20: W4: Label for web site used general data\r\nWEBSITE=Spletna stran\r\n\r\n#XFLD,20: W4: Label for country used general data\r\nCOUNTRY=Dr\\u017Eava\r\n\r\n#XFLD,20: W4: Label for region used general data\r\nREGION=Podro\\u010Dje\r\n\r\n#XFLD,20: W4: Label for city used general data\r\nCITY=Mesto\r\n\r\n#XFLD,20: W4: Label for postal code used general data\r\nPOSTAL_CODE=Po\\u0161tna \\u0161tevilka\r\n\r\n#XFLD,20: W4: Label for street used general data\r\nSTREET=Ulica\r\n\r\n#XFLD,10: W4: Label for house number used general data\r\nHOUSE_NUMBER=Hi\\u0161na \\u0161t.\r\n\r\n#XFLD,15: W6: Label for ID used in Quotations\r\nID=ID\r\n\r\n#XFLD,15: W6: Label for Amount used in Quotations\r\nAMOUNT=Znesek\r\n\r\n#XFLD,20: W6: Label for Expiration Date used in Quotations\r\nEXPIRATION_DATE=Datum zapadlosti\r\n\r\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\r\nDELIVERY_DATE=Datum dobave\r\n\r\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\r\nSALES_EMPLOYEE=Prodajni referent\r\n\r\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\r\nATTRIBUTESET=Skupina karakteristik\r\n\r\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\r\nATTRIBUTE=Atribut\r\n\r\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\r\nVALUE=Vrednost\r\n\r\n#XBUT, 20: Button to create an Account\r\nBUTTON_ADD=Dodajanje\r\n\r\n#XBUT, 20: Button to edit an Account\r\nBUTTON_EDIT=Obdelava\r\n\r\n#XBUT, 20: Button to save changes\r\nBUTTON_SAVE=Shranjevanje\r\n\r\n#XBUT, 20: Button to cancel changes\r\nBUTTON_CANCEL=Prekinitev\r\n\r\n#XBUT, 30: Button which shows the personalization buttons\r\nBUTTON_SHOW_PERSONALIZATION=Prika\\u017Ei personalizacijo\r\n\r\n#XBUT, 30: Button which hides the personalization buttons\r\nBUTTON_HIDE_PERSONALIZATION=Skrij personalizacijo\r\n\r\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_CONFIRM_CANCEL=Vse neshranjene spremembe bodo izgubljene. \\u017Delite nadaljevati?\r\n\r\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\r\nMSG_CONFIRM_DELETE_CONTACT=Kontaktna oseba ne bo ve\\u010D dodeljena stranki. \\u017Delite nadaljevati?\r\n\r\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_SUCCESS=Stranka a\\u017Eurirana\r\n\r\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_ERROR=A\\u017Euriranje ni uspelo\r\n\r\n# XMSG : Account update succeeded\r\nMSG_CREATION_SUCCESS=Stranka kreirana\r\n\r\n# XMSG : Task creation succeeded\r\nMSG_TASK_CREATION_SUCCESS=Naloga kreirana\r\n\r\n# XMSG : Contact creation failed\r\nMSG_CREATION_ERROR=Kreiranje ni uspelo\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong country\r\nMSG_WRONG_COUNTRY_ERROR=Dr\\u017Eava "{0}" ne obstaja\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong region\r\nMSG_WRONG_REGION_ERROR=Regija "{0}" ne obstaja za dr\\u017Eavo\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong employee\r\nMSG_WRONG_EMPLOYEE_ERROR=Zaposleni "{0}" ne obstaja.\r\n\r\n# XMSG: message that will be displayed, if the user has entered invalid website url\r\nMSG_WRONG_URL_ERROR=Vneseni URL "{0}" ni veljaven.\r\n\r\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\r\nMSG_MANDATORY_FIELDS=Izpolnjena niso vsa obvezna polja\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA=Podatke je spremenil drug uporabnik. \\u017Delite prepisati spremembe drugega uporabnika s svojimi?\r\n\r\n# XMSG: message that will be displayed in case of conflicts during file renaming\r\nMSG_CONFLICTING_FILE_NAME=Naziv datoteke je spremenil drug uporabnik. \\u017Delite prepisati spremembe drugega uporabnika s svojimi?\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA_WITH_REFRESH=Podatke je spremenil drug uporabnik. Te spremembe bodo zdaj vidne v aplikaciji.\r\n\r\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\r\nMSG_NOT_IN_MAIN_CONTACT=Ogledate si lahko le detajle kontaktov, ki so dodeljeni tej stranki\r\n\r\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\r\nMSG_EXCEEDING_FILE_NAME_LENGTH=Va\\u0161 naziv datoteke ima lahko najve\\u010D 40 znakov.\r\n\r\n# XTOL, 20: tooltip shown on search result list for button to add an account"\r\n\r\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\r\n\r\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\r\n\r\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\r\n\r\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\r\n\r\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\r\n',
		"cus/crm/myaccounts/i18n/i18n_tr.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XFLD, 30: Facet title for general Data\r\nGENERAL_DATA=Genel veriler\r\n\r\n#XTIT, 40: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=M\\u00FC\\u015Fterilerim\r\n\r\n#XTIT, 40: this is the title for the detail screen\r\nDETAIL_TITLE=M\\u00FC\\u015Fteri\r\n\r\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\r\nREVENUE_CURRENT=Bug\\u00FCne kdr.gelir\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\r\nREVENUE_CURRENT_TOOLTIP=Bug\\u00FCne kadarki gelir (g\\u00FCncel y\\u0131l)\r\n\r\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\r\nREVENUE_LAST=Gelir (ge\\u00E7en y\\u0131l)\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\r\nREVENUE_LAST_TOOLTIP=Gelir (ge\\u00E7en y\\u0131l)\r\n\r\n# XFLD, 30: Facet title for opportunities and label in facet general data\r\nOPPORTUNITIES=F\\u0131rsatlar\r\n\r\n#XFLD, 30: Facet title for leads\r\nLEADS=Aday m\\u00FC\\u015Fteriler\r\n\r\n#XFLD, 30: Facet title for tasks\r\nTASKS=G\\u00F6revler\r\n\r\n#XFLD, 30: Facet title for appointments\r\nAPPOINTMENTS=Randevular\r\n\r\n#XFLD, 30: Facet title for quotations\r\nQUOTATIONS=Teklifler\r\n\r\n#XFLD, 30: Facet title for sales orders\r\nSALES_ORDERS=Sat\\u0131\\u015F sipari\\u015Fleri\r\n\r\n#XFLD, 30: W7: Facet title for marketing attributes\r\nMARKETINGATTRIBUTES=Pazarlama nitelikleri\r\n\r\n#XFLD, 30: W6: Title for popup with products\r\nPRODUCTS=\\u00DCr\\u00FCnler\r\n\r\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\r\nEMPLOYEE_RESPONSIBLE=Sorumlu \\u00E7al\\u0131\\u015Fan\r\n\r\n#XFLD, 30: Facet title for Attachments\r\nATTACHMENTS=Ekler\r\n\r\n#XFLD, 30: Facet title for Notes\r\nNOTES=Notlar\r\n\r\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\r\nNEW_NOTE=Yeni not\r\n\r\n#XFLD, 30: Facet title for Contacts\r\nCONTACTS=\\u0130lgili ki\\u015Filer\r\n\r\n#XFLD, 30: Label for Address in facet general data\r\nADDRESS=Adres\r\n\r\n#XFLD, 30: Label for Opportunities in facet general data\r\nUNWEIGHTED_OPPORTUNITIES=F\\u0131rsatlar\r\n\r\n#XFLD, 30: Label for Rating in facet general data\r\nRATING=Derecelendirme\r\n\r\n# XFLD, 30: Label for Next contact in facet Appointments\r\nNEXT_APPOINTMENT=Sonraki randevu\r\n\r\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\r\nLAST_APPOINTMENT=Son randevu\r\n\r\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\r\nIMAGE=G\\u00F6r\\u00FCnt\\u00FC\r\n\r\n#XBUT, 20: Button to show the create actionsheet\r\nCREATE=Olu\\u015Ftur\r\n\r\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\r\nDISCUSS_ENTRY=SAP Jam\'de tart\\u0131\\u015F\r\n\r\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\r\nSHARE_ENTRY=SAP Jam\'de payla\\u015F\r\n\r\n#XBUT, 20: Button to share the note\r\nDETAIL_BUTTON_SHARE=Payla\\u015F\r\n\r\n#XBUT, 20: Button to cancel sharing\r\nDETAIL_BUTTON_CANCEL=\\u0130ptal\r\n\r\n#XFLD,20: All accounts for filter\r\nALL_ACCOUNTS=T\\u00FCm m\\u00FC\\u015Fteriler\r\n\r\n#XFLD,35: All individual accounts for filter\r\nALL_INDIVIDUAL_ACCOUNTS=T\\u00FCm m\\u00FCnferit m\\u00FC\\u015Fteriler\r\n\r\n#XFLD,35: All corporate accounts for filter\r\nALL_CORPORATE_ACCOUNTS=T\\u00FCm kurumsal m\\u00FC\\u015Fteriler\r\n\r\n#XFLD,35: All group accounts for filter\r\nALL_ACCOUNT_GROUPS=T\\u00FCm m\\u00FC\\u015Fteri gruplar\\u0131\r\n\r\n#XFLD,20: my account for filter\r\nMY_ACCOUNT=M\\u00FC\\u015Fterilerim\r\n\r\n#XFLD,35: my individual accounts for filter\r\nMY_INDIVIDUAL_ACCOUNTS=M\\u00FCnferit m\\u00FC\\u015Fterilerim\r\n\r\n#XFLD,35: my corporate accounts for filter\r\nMY_CORPORATE_ACCOUNTS=Kurumsal m\\u00FC\\u015Fterilerim\r\n\r\n#XFLD,35: my group accounts for filter\r\nMY_ACCOUNT_GROUPS=M\\u00FC\\u015Fteri gruplar\\u0131m\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nINDIVIDUAL_ACCOUNT=Bireysel m\\u00FC\\u015Fteri\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nCORPORATE_ACCOUNT=Kurumsal m\\u00FC\\u015Fteri\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nACCOUNT_GROUP=M\\u00FC\\u015Fteri grubu\r\n\r\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\r\nSTARTING=Ba\\u015Flang\\u0131\\u00E7 tarihi\\: {0}\r\n\r\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\r\nCLOSING=Kapan\\u0131\\u015F tarihi\\: {0}\r\n\r\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\r\nDUE=Son tarih\\: {0}\r\n\r\n#XFLD,20: All accounts for title\r\nALL_ACCOUNTS_TITLE=T\\u00FCm m\\u00FC\\u015Fteriler ({0})\r\n\r\n#XFLD,35: All individual accounts for title\r\nALL_INDIVIDUAL_ACCOUNTS_TITLE=T\\u00FCm m\\u00FCnferit m\\u00FC\\u015Fteriler ({0})\r\n\r\n#XFLD,35: All corporate accounts for title\r\nALL_CORPORATE_ACCOUNTS_TITLE=T\\u00FCm kurumsal m\\u00FC\\u015Fteriler ({0})\r\n\r\n#XFLD,35: All group accounts for title\r\nALL_ACCOUNT_GROUPS_TITLE=T\\u00FCm m\\u00FC\\u015Fteri gruplar\\u0131 ({0})\r\n\r\n#XFLD,20: my account for title\r\nMY_ACCOUNT_TITLE=M\\u00FC\\u015Fterilerim ({0})\r\n\r\n#XFLD,35: my individual account for title\r\nMY_INDIVIDUAL_ACCOUNT_TITLE=M\\u00FCnferit m\\u00FC\\u015Fterilerim ({0})\r\n\r\n#XFLD,35: my corporate account for title.\r\nMY_CORPORATE_ACCOUNT_TITLE=Kurumsal m\\u00FC\\u015Fterilerim ({0})\r\n\r\n#XFLD,35: my group account for title\r\nMY_ACCOUNT_GROUP_TITLE=M\\u00FC\\u015Fteri gruplar\\u0131m ({0})\r\n\r\n#XFLD,30: filtered by info\r\nFILTERED_BY=Filtreleme \\u00F6l\\u00E7\\u00FCt\\u00FC\\: {0}\r\n\r\n#XFLD,30: label, search for accounts\r\nSEARCH_ACCOUNTS=Ara\r\n\r\n#XFLD,30: comma separator for location\r\nLOCATION={0}, {1}\r\n\r\n#XFLD: W4: Label for All day text in Appointments\r\nALL_DAY_EVENT=T\\u00FCm g\\u00FCn\r\n\r\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\r\nDURATION_MINUTE={0} dak\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\r\nDURATION_HOUR={0} s\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\r\nDURATION_DAY={0} g\\u00FCn\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\r\nDURATION_DAYS={0} g\\u00FCn\r\n\r\n#XFLD: W4: Label for Private meeting\r\nPRIVATE=Ki\\u015Fisel\r\n\r\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\r\nSELECT_TRANSACTION_TYPE=\\u0130\\u015Flem t\\u00FCr\\u00FC se\\u00E7\r\n\r\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\r\nNEW_TASK_INPUT_PLACEHOLDER=Yeni g\\u00F6rev\r\n\r\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nNO_DATA_TEXT=Veri mevcut de\\u011Fil\r\n\r\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nLOADING_TEXT=Y\\u00FCkleniyor...\r\n\r\n#XFLD,25: W4: Column label for name of contact person in contacts\r\nNAME=Ad\r\n\r\n#XFLD,25: W5: Column label for department of contact person in contacts\r\nDEPARTMENT=Departman\r\n\r\n#XFLD,15: W6: Column label for actions of contact person in contacts\r\nACTIONS=\\u0130\\u015Flemler\r\n\r\n#XFLD,25: W4: Column label for description of lead in Leads\r\nDESCRIPTION=Tan\\u0131m\r\n\r\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\r\nASSIGNED_TO=\\u015Euna tayin edildi\r\n\r\n#XFLD,15: W4: Column label for end date of lead in Leads\r\nEND_DATE=Biti\\u015F tarihi\r\n\r\n#XFLD,15: W4: Column label for qualification level of lead in Leads\r\nQUALIFICATION=Nitelik\r\n\r\n#XFLD,15: W4: Column label for status of lead in Leads\r\nSTATUS=Durum\r\n\r\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\r\nMAIN_CONTACT=Ana ilgili ki\\u015Fi\r\n\r\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\r\nVOLUME=Sat\\u0131\\u015F has\\u0131lat\\u0131\r\n\r\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\r\nPROBABILITY=Olas\\u0131l\\u0131k\r\n\r\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\r\nCLOSE_BY=Kapan\\u0131\\u015F tarihi\r\n\r\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \r\nVIEWS=G\\u00F6r\\u00FCn\\u00FCmler\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\r\nCONTACT_TITLE=\\u0130lgili ki\\u015Fi\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\r\nEMPLOYEE_TITLE=\\u00C7al\\u0131\\u015Fan\r\n\r\n#XTIT,20: W7: Title of pop-up used in confirm popup\r\nCONFIRM_TITLE=Teyit et\r\n\r\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\r\nCOMPANY_NAME=Ad\r\n\r\n#XFLD,20: W4: Label for name 1 of a company used general data\r\nCOMPANY_NAME1=Ad 1\r\n\r\n#XFLD,20: W4: Label for name 2 of a company used general data\r\nCOMPANY_NAME2=Ad 2\r\n\r\n#XFLD,20: W4: Label for first name of a person used general data\r\nFIRST_NAME=Ad\\u0131\r\n\r\n#XFLD,20: W4: Label for last name of a person used general data\r\nLAST_NAME=Soyad\\u0131\r\n\r\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nBIRTHDAY=Do\\u011Fum tarihi\r\n\r\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nTITLE=Ba\\u015Fl\\u0131k\r\n\r\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nACADEMIC_TITLE=Akademik unvan\r\n\r\n#XFLD,20: W4: Label for mobile phone number used general data\r\nMOBILE=Cep telefonu\r\n\r\n#XFLD,20: W4: Label for phone number used general data\r\nPHONE=Telefon\r\n\r\n#XFLD,20: W4: Label for e-mail used general data\r\nEMAIL=E-posta\r\n\r\n#XFLD,20: W4: Label for web site used general data\r\nWEBSITE=Web sitesi\r\n\r\n#XFLD,20: W4: Label for country used general data\r\nCOUNTRY=\\u00DClke\r\n\r\n#XFLD,20: W4: Label for region used general data\r\nREGION=B\\u00F6lge\r\n\r\n#XFLD,20: W4: Label for city used general data\r\nCITY=\\u015Eehir\r\n\r\n#XFLD,20: W4: Label for postal code used general data\r\nPOSTAL_CODE=Posta kodu\r\n\r\n#XFLD,20: W4: Label for street used general data\r\nSTREET=Sokak\r\n\r\n#XFLD,10: W4: Label for house number used general data\r\nHOUSE_NUMBER=Konut no.\r\n\r\n#XFLD,15: W6: Label for ID used in Quotations\r\nID=Tan\\u0131t\\u0131c\\u0131\r\n\r\n#XFLD,15: W6: Label for Amount used in Quotations\r\nAMOUNT=Tutar\r\n\r\n#XFLD,20: W6: Label for Expiration Date used in Quotations\r\nEXPIRATION_DATE=Ge\\u00E7erlilik sonu\r\n\r\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\r\nDELIVERY_DATE=Teslimat tarihi\r\n\r\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\r\nSALES_EMPLOYEE=Sat\\u0131\\u015F \\u00E7al\\u0131\\u015Fan\\u0131\r\n\r\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\r\nATTRIBUTESET=Nitelik k\\u00FCmesi\r\n\r\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\r\nATTRIBUTE=Nitelik\r\n\r\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\r\nVALUE=De\\u011Fer\r\n\r\n#XBUT, 20: Button to create an Account\r\nBUTTON_ADD=Ekle\r\n\r\n#XBUT, 20: Button to edit an Account\r\nBUTTON_EDIT=D\\u00FCzenle\r\n\r\n#XBUT, 20: Button to save changes\r\nBUTTON_SAVE=Kaydet\r\n\r\n#XBUT, 20: Button to cancel changes\r\nBUTTON_CANCEL=\\u0130ptal\r\n\r\n#XBUT, 30: Button which shows the personalization buttons\r\nBUTTON_SHOW_PERSONALIZATION=Ki\\u015Fisll\\u015Ft.g\\u00F6ster\r\n\r\n#XBUT, 30: Button which hides the personalization buttons\r\nBUTTON_HIDE_PERSONALIZATION=Ki\\u015Fisll\\u015Ft.gizle\r\n\r\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_CONFIRM_CANCEL=Kaydedilmeyen de\\u011Fi\\u015Fiklikler kaybolacak. Devam etmek istiyor musunuz?\r\n\r\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\r\nMSG_CONFIRM_DELETE_CONTACT=M\\u00FC\\u015Fteriden irtibat tayini kald\\u0131r\\u0131lacak. Devam etmek istiyor musunuz?\r\n\r\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_SUCCESS=Hesap g\\u00FCncellendi\r\n\r\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_ERROR=G\\u00FCncelleme ba\\u015Far\\u0131s\\u0131z\r\n\r\n# XMSG : Account update succeeded\r\nMSG_CREATION_SUCCESS=Hesap olu\\u015Fturuldu\r\n\r\n# XMSG : Task creation succeeded\r\nMSG_TASK_CREATION_SUCCESS=G\\u00F6rev olu\\u015Fturuldu\r\n\r\n# XMSG : Contact creation failed\r\nMSG_CREATION_ERROR=Olu\\u015Fturma ba\\u015Far\\u0131s\\u0131z oldu\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong country\r\nMSG_WRONG_COUNTRY_ERROR=\\u00DClke "{0}" mevcut de\\u011Fil\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong region\r\nMSG_WRONG_REGION_ERROR=B\\u00F6lge "{0}" \\u00FClke i\\u00E7in mevcut de\\u011Fil\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong employee\r\nMSG_WRONG_EMPLOYEE_ERROR=\\u00C7al\\u0131\\u015Fan "{0}" mevcut de\\u011Fil.\r\n\r\n# XMSG: message that will be displayed, if the user has entered invalid website url\r\nMSG_WRONG_URL_ERROR=Girilen URL "{0}" ge\\u00E7erli de\\u011Fil.\r\n\r\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\r\nMSG_MANDATORY_FIELDS=T\\u00FCm zorunlu alanlar doldurulmad\\u0131\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA=Veriler ba\\u015Fka kullan\\u0131c\\u0131 taraf\\u0131ndan de\\u011Fi\\u015Ftirildi. Di\\u011Fer kullan\\u0131c\\u0131n\\u0131n de\\u011Fi\\u015Fikliklerinin \\u00FCzerine kendikilerinizi yazmak istiyor musunuz?\r\n\r\n# XMSG: message that will be displayed in case of conflicts during file renaming\r\nMSG_CONFLICTING_FILE_NAME=Dosya ad\\u0131 ba\\u015Fka kullan\\u0131c\\u0131 taraf\\u0131ndan de\\u011Fi\\u015Ftirildi. Di\\u011Fer kullan\\u0131c\\u0131n\\u0131n de\\u011Fi\\u015Fikliklerinin \\u00FCzerine kendikilerinizi yazmak istiyor musunuz?\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA_WITH_REFRESH=Veri ba\\u015Fka bir kullan\\u0131c\\u0131 taraf\\u0131ndan de\\u011Fi\\u015Ftirildi. Bu de\\u011Fi\\u015Fiklikler \\u015Fimdi uygulamada g\\u00F6r\\u00FCnecek.\r\n\r\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\r\nMSG_NOT_IN_MAIN_CONTACT=Yaln\\u0131zca bu hesaba tayin edilen ilgili ki\\u015Finin ayr\\u0131nt\\u0131lar\\u0131n\\u0131 g\\u00F6r\\u00FCnt\\u00FCleyebilirsiniz\r\n\r\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\r\nMSG_EXCEEDING_FILE_NAME_LENGTH=Dosya ad\\u0131n\\u0131z azami 40 karakter i\\u00E7erebilir.\r\n\r\n# XTOL, 20: tooltip shown on search result list for button to add an account"\r\nADD_ACCOUNT_TOOLTIP=M\\u00FC\\u015Fteri ekle\r\n\r\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\r\nADD_MARKETING_ATTRIBUTE_TOOLTIP=Pazarlama niteli\\u011Fi ekle\r\n\r\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\r\nADD_CONTACT_TOOLTIP=\\u0130lgili ki\\u015Fi ekle\r\n\r\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\r\nADD_APPOINTMENT_TOOLTIP=Randevu ekle\r\n\r\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\r\nADD_TASK_TOOLTIP=G\\u00F6rev ekle\r\n\r\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\r\nADD_OPPORTUNITY_TOOLTIP=F\\u0131rsat ekle\r\n',
		"cus/crm/myaccounts/i18n/i18n_zh_CN.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XFLD, 30: Facet title for general Data\r\nGENERAL_DATA=\\u5E38\\u89C4\\u6570\\u636E\r\n\r\n#XTIT, 40: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=\\u6211\\u7684\\u5BA2\\u6237\r\n\r\n#XTIT, 40: this is the title for the detail screen\r\nDETAIL_TITLE=\\u5BA2\\u6237\r\n\r\n# XFLD, 18: short description for "revenue to date current year" shown in KPI tile\r\nREVENUE_CURRENT=\\u5F53\\u524D\\u5E74\\u5EA6\\u8FC4\\u4ECA\\u7684\\u6536\\u5165\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date current year"\r\nREVENUE_CURRENT_TOOLTIP=\\u5F53\\u524D\\u5E74\\u5EA6\\u8FC4\\u4ECA\\u7684\\u6536\\u5165\r\n\r\n# XFLD, 18: short description for "revenue to date last year" shown in KPI tile\r\nREVENUE_LAST=\\u53BB\\u5E74\\u7684\\u6536\\u5165\r\n\r\n# XTOL, 40: tooltip shown for KPI tile to give full description for "revenue to date last year"\r\nREVENUE_LAST_TOOLTIP=\\u53BB\\u5E74\\u7684\\u6536\\u5165\r\n\r\n# XFLD, 30: Facet title for opportunities and label in facet general data\r\nOPPORTUNITIES=\\u673A\\u4F1A\r\n\r\n#XFLD, 30: Facet title for leads\r\nLEADS=\\u7EBF\\u7D22\r\n\r\n#XFLD, 30: Facet title for tasks\r\nTASKS=\\u4EFB\\u52A1\r\n\r\n#XFLD, 30: Facet title for appointments\r\nAPPOINTMENTS=\\u9884\\u7EA6\r\n\r\n#XFLD, 30: Facet title for quotations\r\nQUOTATIONS=\\u62A5\\u4EF7\r\n\r\n#XFLD, 30: Facet title for sales orders\r\nSALES_ORDERS=\\u9500\\u552E\\u8BA2\\u5355\r\n\r\n#XFLD, 30: W7: Facet title for marketing attributes\r\nMARKETINGATTRIBUTES=\\u5E02\\u573A\\u8425\\u9500\\u5C5E\\u6027\r\n\r\n#XFLD, 30: W6: Title for popup with products\r\nPRODUCTS=\\u4EA7\\u54C1\r\n\r\n#XFLD, 30: Label for Employee Responsible in facet general data displayed if function of the responsible employee has no data\r\nEMPLOYEE_RESPONSIBLE=\\u8D1F\\u8D23\\u4EBA\r\n\r\n#XFLD, 30: Facet title for Attachments\r\nATTACHMENTS=\\u9644\\u4EF6\r\n\r\n#XFLD, 30: Facet title for Notes\r\nNOTES=\\u6CE8\\u91CA\r\n\r\n# XSEL,40: W8: Placeholder in text input field for creation of new note in Notes\r\nNEW_NOTE=\\u65B0\\u6CE8\\u91CA\r\n\r\n#XFLD, 30: Facet title for Contacts\r\nCONTACTS=\\u8054\\u7CFB\\u4EBA\r\n\r\n#XFLD, 30: Label for Address in facet general data\r\nADDRESS=\\u5730\\u5740\r\n\r\n#XFLD, 30: Label for Opportunities in facet general data\r\nUNWEIGHTED_OPPORTUNITIES=\\u673A\\u4F1A\r\n\r\n#XFLD, 30: Label for Rating in facet general data\r\nRATING=\\u8BC4\\u7EA7\r\n\r\n# XFLD, 30: Label for Next contact in facet Appointments\r\nNEXT_APPOINTMENT=\\u4E0B\\u4E2A\\u9884\\u7EA6\r\n\r\n# XFLD, 30: Label for Next contact in faceAppointmentsivities\r\nLAST_APPOINTMENT=\\u6700\\u540E\\u4E00\\u4E2A\\u9884\\u7EA6\r\n\r\n# XFLD, 8: Label for the image (Logo/Photo) of the account in the search result list\r\nIMAGE=\\u56FE\\u50CF\r\n\r\n#XBUT, 20: Button to show the create actionsheet\r\nCREATE=\\u521B\\u5EFA\r\n\r\n#YMSG, 30: SAP Jam discuss entry dialog ActionSheet menu\r\nDISCUSS_ENTRY=\\u5728 SAP Jam \\u4E0A\\u8BA8\\u8BBA\r\n\r\n#YMSG, 30: SAP Jam share entry dialog ActionSheet menu\r\nSHARE_ENTRY=\\u5728 SAP Jam \\u4E2D\\u5171\\u4EAB\r\n\r\n#XBUT, 20: Button to share the note\r\nDETAIL_BUTTON_SHARE=\\u5171\\u4EAB\r\n\r\n#XBUT, 20: Button to cancel sharing\r\nDETAIL_BUTTON_CANCEL=\\u53D6\\u6D88\r\n\r\n#XFLD,20: All accounts for filter\r\nALL_ACCOUNTS=\\u5168\\u90E8\\u5BA2\\u6237\r\n\r\n#XFLD,35: All individual accounts for filter\r\nALL_INDIVIDUAL_ACCOUNTS=\\u6240\\u6709\\u4E2A\\u4EBA\\u5BA2\\u6237\r\n\r\n#XFLD,35: All corporate accounts for filter\r\nALL_CORPORATE_ACCOUNTS=\\u6240\\u6709\\u516C\\u53F8\\u5BA2\\u6237\r\n\r\n#XFLD,35: All group accounts for filter\r\nALL_ACCOUNT_GROUPS=\\u6240\\u6709\\u5BA2\\u6237\\u7EC4\r\n\r\n#XFLD,20: my account for filter\r\nMY_ACCOUNT=\\u6211\\u7684\\u5BA2\\u6237\r\n\r\n#XFLD,35: my individual accounts for filter\r\nMY_INDIVIDUAL_ACCOUNTS=\\u6211\\u7684\\u4E2A\\u4EBA\\u5BA2\\u6237\r\n\r\n#XFLD,35: my corporate accounts for filter\r\nMY_CORPORATE_ACCOUNTS=\\u6211\\u7684\\u516C\\u53F8\\u5BA2\\u6237\r\n\r\n#XFLD,35: my group accounts for filter\r\nMY_ACCOUNT_GROUPS=\\u6211\\u7684\\u5BA2\\u6237\\u7EC4\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nINDIVIDUAL_ACCOUNT=\\u4E2A\\u4EBA\\u5BA2\\u6237\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nCORPORATE_ACCOUNT=\\u516C\\u53F8\\u5BA2\\u6237\r\n\r\n#XFLD,30: Account type -> for the DDLB in case of create\r\nACCOUNT_GROUP=\\u5BA2\\u6237\\u7EC4\r\n\r\n#XFLD,20: Starting label for the start date ,i.e."starting 31/10/1989"\r\nSTARTING=\\u5F00\\u59CB\\u65E5\\u671F\\uFF1A {0}\r\n\r\n#XFLD,20: Closing label for the close date ,i.e."Closing 31/10/1989"\r\nCLOSING=\\u7ED3\\u675F\\u65E5\\u671F\\uFF1A {0}\r\n\r\n#XFLD,20: Due label for the due date ,i.e."Due 31/10/1989"\r\nDUE=\\u5230\\u671F\\u65E5\\u671F\\uFF1A {0}\r\n\r\n#XFLD,20: All accounts for title\r\nALL_ACCOUNTS_TITLE=\\u6240\\u6709\\u5BA2\\u6237 ({0})\r\n\r\n#XFLD,35: All individual accounts for title\r\nALL_INDIVIDUAL_ACCOUNTS_TITLE=\\u6240\\u6709\\u4E2A\\u4EBA\\u5BA2\\u6237 ({0})\r\n\r\n#XFLD,35: All corporate accounts for title\r\nALL_CORPORATE_ACCOUNTS_TITLE=\\u6240\\u6709\\u516C\\u53F8\\u5BA2\\u6237 ({0})\r\n\r\n#XFLD,35: All group accounts for title\r\nALL_ACCOUNT_GROUPS_TITLE=\\u6240\\u6709\\u5BA2\\u6237\\u7EC4 ({0})\r\n\r\n#XFLD,20: my account for title\r\nMY_ACCOUNT_TITLE=\\u6211\\u7684\\u5BA2\\u6237 ({0})\r\n\r\n#XFLD,35: my individual account for title\r\nMY_INDIVIDUAL_ACCOUNT_TITLE=\\u6211\\u7684\\u4E2A\\u4EBA\\u5BA2\\u6237 ({0})\r\n\r\n#XFLD,35: my corporate account for title.\r\nMY_CORPORATE_ACCOUNT_TITLE=\\u6211\\u7684\\u516C\\u53F8\\u5BA2\\u6237 ({0})\r\n\r\n#XFLD,35: my group account for title\r\nMY_ACCOUNT_GROUP_TITLE=\\u6211\\u7684\\u5BA2\\u6237\\u7EC4 ({0})\r\n\r\n#XFLD,30: filtered by info\r\nFILTERED_BY=\\u8FC7\\u6EE4\\u6761\\u4EF6\\uFF1A {0}\r\n\r\n#XFLD,30: label, search for accounts\r\nSEARCH_ACCOUNTS=\\u641C\\u7D22\r\n\r\n#XFLD,30: comma separator for location\r\nLOCATION={0}, {1}\r\n\r\n#XFLD: W4: Label for All day text in Appointments\r\nALL_DAY_EVENT=\\u5168\\u5929\r\n\r\n#XFLD: W4: Abbreviation of minutes with placeholder for the number of minutes, eg. "30 min"\r\nDURATION_MINUTE={0} \\u5206\\u949F\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in hours, eg. "1 h"\r\nDURATION_HOUR={0} \\u5C0F\\u65F6\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "1 day"\r\nDURATION_DAY={0} \\u5929\r\n\r\n#XFLD: W4: Indicates the duration of an appointment in days only, eg. "2 days"\r\nDURATION_DAYS={0} \\u5929\r\n\r\n#XFLD: W4: Label for Private meeting\r\nPRIVATE=\\u79C1\\u4EBA\r\n\r\n#XTIT: W7: Title for Transaction type dialog in Appointments (Taken from My Appointments app)\r\nSELECT_TRANSACTION_TYPE=\\u9009\\u62E9\\u4E8B\\u52A1\\u7C7B\\u578B\r\n\r\n# XSEL,40: W7: Placeholder in text input field for quick creation of new task in Tasks\r\nNEW_TASK_INPUT_PLACEHOLDER=\\u65B0\\u5EFA\\u4EFB\\u52A1\r\n\r\n#XFLD: W4: No Data text after loading/searching list; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nNO_DATA_TEXT=\\u65E0\\u6570\\u636E\r\n\r\n#XFLD: W4: No Data text while loading/searching list; Used also in Fiori CRM My Contacts application while loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nLOADING_TEXT=\\u6B63\\u5728\\u52A0\\u8F7D...\r\n\r\n#XFLD,25: W4: Column label for name of contact person in contacts\r\nNAME=\\u59D3\\u540D\r\n\r\n#XFLD,25: W5: Column label for department of contact person in contacts\r\nDEPARTMENT=\\u90E8\\u95E8\r\n\r\n#XFLD,15: W6: Column label for actions of contact person in contacts\r\nACTIONS=\\u64CD\\u4F5C\r\n\r\n#XFLD,25: W4: Column label for description of lead in Leads\r\nDESCRIPTION=\\u63CF\\u8FF0\r\n\r\n#XFLD,25: W4: Column label for person responsible assigned to lead in Leads\r\nASSIGNED_TO=\\u5DF2\\u5206\\u914D\\u5230\r\n\r\n#XFLD,15: W4: Column label for end date of lead in Leads\r\nEND_DATE=\\u7ED3\\u675F\\u65E5\\u671F\r\n\r\n#XFLD,15: W4: Column label for qualification level of lead in Leads\r\nQUALIFICATION=\\u8D44\\u683C\\u5BA1\\u6838\r\n\r\n#XFLD,15: W4: Column label for status of lead in Leads\r\nSTATUS=\\u72B6\\u6001\r\n\r\n#XFLD,25: W4: Column label for main contact assigned to opportunity in Opportunities\r\nMAIN_CONTACT=\\u4E3B\\u8981\\u8054\\u7CFB\\u4EBA\r\n\r\n#XFLD,15: W4: Column label for volume of opportunity in Opportunities\r\nVOLUME=\\u9500\\u552E\\u989D\r\n\r\n#XFLD,20: W4: Column label for probability of opportunity in Opportunities\r\nPROBABILITY=\\u6982\\u7387\r\n\r\n#XFLD,20: W4: Column label for close date of opportunity in Opportunities\r\nCLOSE_BY=\\u5173\\u95ED\\u65E5\\u671F\r\n\r\n#XFLD,20: W4: Title on the pop-up for the personalization of the sub views \r\nVIEWS=\\u89C6\\u56FE\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for contact\r\nCONTACT_TITLE=\\u8054\\u7CFB\\u4EBA\r\n\r\n#XTIT,20: W4: Title of pop-up used in quickoverview for employee\r\nEMPLOYEE_TITLE=\\u5458\\u5DE5\r\n\r\n#XTIT,20: W7: Title of pop-up used in confirm popup\r\nCONFIRM_TITLE=\\u786E\\u8BA4\r\n\r\n#XFLD,20: W4: Label for name of company used in quickoverview for employee\r\nCOMPANY_NAME=\\u540D\\u79F0\r\n\r\n#XFLD,20: W4: Label for name 1 of a company used general data\r\nCOMPANY_NAME1=\\u540D\\u79F0 1\r\n\r\n#XFLD,20: W4: Label for name 2 of a company used general data\r\nCOMPANY_NAME2=\\u540D\\u79F0 2\r\n\r\n#XFLD,20: W4: Label for first name of a person used general data\r\nFIRST_NAME=\\u540D\r\n\r\n#XFLD,20: W4: Label for last name of a person used general data\r\nLAST_NAME=\\u59D3\r\n\r\n# XFLD,20: W4: Contact Detail field for Birthday; Used also in Fiori CRM My Contacts application with key CONTACT_BIRTHDAY; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nBIRTHDAY=\\u51FA\\u751F\\u65E5\\u671F\r\n\r\n# XFLD,20: W4: Account Detail field for Title; Used also in Fiori CRM My Contacts application with key CONTACT_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nTITLE=\\u5934\\u8854\r\n\r\n# XFLD,20: W4: Account Detail field for Academic Title; Used also in Fiori CRM My Contacts application with key CONTACT_ACADEMIC_TITLE; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nACADEMIC_TITLE=\\u804C\\u79F0\r\n\r\n#XFLD,20: W4: Label for mobile phone number used general data\r\nMOBILE=\\u624B\\u673A\r\n\r\n#XFLD,20: W4: Label for phone number used general data\r\nPHONE=\\u7535\\u8BDD\r\n\r\n#XFLD,20: W4: Label for e-mail used general data\r\nEMAIL=\\u7535\\u5B50\\u90AE\\u4EF6\r\n\r\n#XFLD,20: W4: Label for web site used general data\r\nWEBSITE=\\u7F51\\u7AD9\r\n\r\n#XFLD,20: W4: Label for country used general data\r\nCOUNTRY=\\u56FD\\u5BB6\r\n\r\n#XFLD,20: W4: Label for region used general data\r\nREGION=\\u5730\\u533A\r\n\r\n#XFLD,20: W4: Label for city used general data\r\nCITY=\\u57CE\\u5E02\r\n\r\n#XFLD,20: W4: Label for postal code used general data\r\nPOSTAL_CODE=\\u90AE\\u653F\\u7F16\\u7801\r\n\r\n#XFLD,20: W4: Label for street used general data\r\nSTREET=\\u8857\\u9053\r\n\r\n#XFLD,10: W4: Label for house number used general data\r\nHOUSE_NUMBER=\\u95E8\\u724C\\u53F7\r\n\r\n#XFLD,15: W6: Label for ID used in Quotations\r\nID=\\u6807\\u8BC6\r\n\r\n#XFLD,15: W6: Label for Amount used in Quotations\r\nAMOUNT=\\u91D1\\u989D\r\n\r\n#XFLD,20: W6: Label for Expiration Date used in Quotations\r\nEXPIRATION_DATE=\\u5230\\u671F\\u65E5\\u671F\r\n\r\n#XFLD,20: W6: Label for Delivery Date used in Sales Orders\r\nDELIVERY_DATE=\\u4EA4\\u8D27\\u65E5\\u671F\r\n\r\n#XFLD,20: W6: Label for Sales Employee used in Sales Orders\r\nSALES_EMPLOYEE=\\u9500\\u552E\\u5458\r\n\r\n#XFLD,25: W7: Column label for Attribute Set of marketing attribute in Marketing Attributes\r\nATTRIBUTESET=\\u5C5E\\u6027\\u96C6\r\n\r\n#XFLD,25: W7: Column label for Attribute of marketing attribute in Marketing Attributes\r\nATTRIBUTE=\\u5C5E\\u6027\r\n\r\n#XFLD,25: W7: Column label for Value of marketing attribute in Marketing Attributes\r\nVALUE=\\u503C\r\n\r\n#XBUT, 20: Button to create an Account\r\nBUTTON_ADD=\\u6DFB\\u52A0\r\n\r\n#XBUT, 20: Button to edit an Account\r\nBUTTON_EDIT=\\u7F16\\u8F91\r\n\r\n#XBUT, 20: Button to save changes\r\nBUTTON_SAVE=\\u4FDD\\u5B58\r\n\r\n#XBUT, 20: Button to cancel changes\r\nBUTTON_CANCEL=\\u53D6\\u6D88\r\n\r\n#XBUT, 30: Button which shows the personalization buttons\r\nBUTTON_SHOW_PERSONALIZATION=\\u663E\\u793A\\u4E2A\\u6027\\u5316\\u8BBE\\u7F6E\r\n\r\n#XBUT, 30: Button which hides the personalization buttons\r\nBUTTON_HIDE_PERSONALIZATION=\\u9690\\u85CF\\u4E2A\\u6027\\u5316\\u8BBE\\u7F6E\r\n\r\n# XMSG: Cancel confirmation; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_CONFIRM_CANCEL=\\u6240\\u6709\\u672A\\u4FDD\\u5B58\\u7684\\u66F4\\u6539\\u5C06\\u4E22\\u5931\\u3002\\u662F\\u5426\\u7EE7\\u7EED\\uFF1F\r\n\r\n# XMSG: Delete confirmation message. It will be displayed if user want to delete the Contact Person relationship of the current Account;\r\nMSG_CONFIRM_DELETE_CONTACT=\\u5C06\\u53D6\\u6D88\\u8054\\u7CFB\\u4EBA\\u4E0E\\u5BA2\\u6237\\u7684\\u5173\\u7CFB\\u3002\\u662F\\u5426\\u7EE7\\u7EED\\uFF1F\r\n\r\n# XMSG : Account update succeeded; Very similar text to the Fiori CRM My Contacts; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_SUCCESS=\\u5BA2\\u6237\\u5DF2\\u66F4\\u65B0\r\n\r\n# XMSG : Contact creation failed; Used also in Fiori CRM My Contacts application after loading list of contacts in master view; translation uuid is 47e50220-1ea3-11e3-8224-0800200c9a66\r\nMSG_UPDATE_ERROR=\\u66F4\\u65B0\\u5931\\u8D25\r\n\r\n# XMSG : Account update succeeded\r\nMSG_CREATION_SUCCESS=\\u5BA2\\u6237\\u5DF2\\u521B\\u5EFA\r\n\r\n# XMSG : Task creation succeeded\r\nMSG_TASK_CREATION_SUCCESS=\\u4EFB\\u52A1\\u5DF2\\u521B\\u5EFA\r\n\r\n# XMSG : Contact creation failed\r\nMSG_CREATION_ERROR=\\u521B\\u5EFA\\u5931\\u8D25\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong country\r\nMSG_WRONG_COUNTRY_ERROR=\\u56FD\\u5BB6 "{0}" \\u4E0D\\u5B58\\u5728\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong region\r\nMSG_WRONG_REGION_ERROR=\\u56FD\\u5BB6\\u7684\\u5730\\u533A "{0}" \\u4E0D\\u5B58\\u5728\r\n\r\n# XMSG: message that will be displayed, if the user has entered wrong employee\r\nMSG_WRONG_EMPLOYEE_ERROR=\\u5458\\u5DE5 "{0}" \\u4E0D\\u5B58\\u5728\\u3002\r\n\r\n# XMSG: message that will be displayed, if the user has entered invalid website url\r\nMSG_WRONG_URL_ERROR=\\u8F93\\u5165\\u7684 URL "{0}" \\u65E0\\u6548\\u3002\r\n\r\n# XMSG: message that will be displayed, if not all mandatory fields are not filled\r\nMSG_MANDATORY_FIELDS=\\u672A\\u586B\\u5199\\u90E8\\u5206\\u5FC5\\u586B\\u5B57\\u6BB5\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA=\\u6570\\u636E\\u5DF2\\u88AB\\u5176\\u4ED6\\u7528\\u6237\\u66F4\\u6539\\u3002\\u662F\\u5426\\u4F7F\\u7528\\u60A8\\u81EA\\u5DF1\\u7684\\u66F4\\u6539\\u8986\\u76D6\\u5176\\u4ED6\\u7528\\u6237\\u7684\\u66F4\\u6539\\uFF1F\r\n\r\n# XMSG: message that will be displayed in case of conflicts during file renaming\r\nMSG_CONFLICTING_FILE_NAME=\\u6587\\u4EF6\\u540D\\u5DF2\\u88AB\\u5176\\u4ED6\\u7528\\u6237\\u66F4\\u6539\\u3002\\u662F\\u5426\\u4F7F\\u7528\\u60A8\\u81EA\\u5DF1\\u7684\\u66F4\\u6539\\u8986\\u76D6\\u5176\\u4ED6\\u7528\\u6237\\u7684\\u66F4\\u6539\\uFF1F\r\n\r\n# XMSG: message that will be displayed in case of conflicting data during account editing\r\nMSG_CONFLICTING_DATA_WITH_REFRESH=\\u5176\\u4ED6\\u7528\\u6237\\u5DF2\\u66F4\\u6539\\u6570\\u636E\\u3002\\u5E94\\u7528\\u4E2D\\u5C06\\u663E\\u793A\\u8FD9\\u4E9B\\u66F4\\u6539\\u3002\r\n\r\n# XMSG: contact not assigned to this account (Taken from My Opportunities app)\r\nMSG_NOT_IN_MAIN_CONTACT=\\u53EA\\u80FD\\u67E5\\u770B\\u5206\\u914D\\u7ED9\\u6B64\\u5BA2\\u6237\\u7684\\u8054\\u7CFB\\u4EBA\\u7684\\u8BE6\\u7EC6\\u4FE1\\u606F\r\n\r\n# XMSG: message that will be displayed in case the file name exceeds the allowed file-name length\r\nMSG_EXCEEDING_FILE_NAME_LENGTH=\\u6587\\u4EF6\\u540D\\u6700\\u591A\\u53EF\\u5305\\u542B 40 \\u4E2A\\u5B57\\u7B26\\u3002\r\n\r\n# XTOL, 20: tooltip shown on search result list for button to add an account"\r\nADD_ACCOUNT_TOOLTIP=\\u6DFB\\u52A0\\u5BA2\\u6237\r\n\r\n# XTOL, 40: tooltip shown on marketing attributes view for button to add a marketing attribute"\r\nADD_MARKETING_ATTRIBUTE_TOOLTIP=\\u6DFB\\u52A0\\u5E02\\u573A\\u8425\\u9500\\u5C5E\\u6027\r\n\r\n# XTOL, 30: tooltip shown on contacts view for button to add a contact"\r\nADD_CONTACT_TOOLTIP=\\u6DFB\\u52A0\\u8054\\u7CFB\\u4EBA\r\n\r\n# XTOL, 30: tooltip shown on appointments view for button to add an appointment"\r\nADD_APPOINTMENT_TOOLTIP=\\u6DFB\\u52A0\\u9884\\u7EA6\r\n\r\n# XTOL, 30: tooltip shown on tasks view for button to add a task"\r\nADD_TASK_TOOLTIP=\\u6DFB\\u52A0\\u4EFB\\u52A1\r\n\r\n# XTOL, 30: tooltip shown on opportunities view for button to add an opportunity"\r\nADD_OPPORTUNITY_TOOLTIP=\\u6DFB\\u52A0\\u673A\\u4F1A\r\n',
		"cus/crm/myaccounts/util/ApptListItem.js": function() {
			jQuery.sap.declare("cus.crm.myaccounts.util.ApptListItem");
			jQuery.sap.require("sap.m.ListItemBase");
			sap.m.ListItemBase.extend("cus.crm.myaccounts.util.ApptListItem", {
				metadata: {
					library: "cus.crm.myaccounts.util",
					defaultAggregation: "content",
					aggregations: {
						"content": {
							type: "sap.ui.core.Control",
							multiple: true,
							singularName: "content",
							bindable: "bindable"
						}
					},
					properties: {
						"title": {
							type: "string"
						},
						"subtitle": {
							type: "string"
						},
						"account": {
							type: "string"
						},
						"location": {
							type: "string"
						},
						"time": {
							type: "string"
						},
						"duration": {
							type: "string"
						},
						"privat": {
							type: "boolean"
						}
					},
					events: {
						"press": {
							allowPreventDefault: true
						}
					}
				},
				renderer: {
					renderLIContent: function(r, c) {
						r.write("<div class='listItemCSS'");
						r.write(">");
						r.write("<div ");
						r.addClass("cusMyApptLiOutter");
						r.writeClasses();
						r.write(">");
						r.write("<div ");
						r.addClass("cusMyApptLiAttch");
						r.writeClasses();
						r.write(">");
						r.renderControl(c.getContent()[1]);
						r.write("</div>");
						r.write("<div ");
						r.addClass("cusMyApptLiLeft");
						if (sap.ui.Device.system.phone) {
							r.addClass("cusMyApptLiLeftPhone");
						}
						r.addClass("cusMyApptLiPadding");
						r.writeClasses();
						r.write(">");
						r.write("<div ");
						r.addClass("cusMyApptLiTime");
						r.addClass("cusMyApptLiEllipsis");
						r.addClass("sapMSLITitle");
						r.addClass("sapThemeText-asColor");
						r.writeClasses();
						r.write(">");
						if (c.getTime()) {
							r.writeEscaped(c.getTime());
						}
						r.write("</div>");
						if (!sap.ui.Device.system.phone) {
							r.write("<div ");
							r.addClass("cusMyApptLiEllipsis");
							r.addClass("sapMSLIDescription");
							r.writeClasses();
							r.write(">");
							if (c.getDuration()) {
								r.writeEscaped(c.getDuration());
							}
							r.write("</div>");
						}
						r.write("</div>");
						r.write("<div ");
						r.addClass("cusMyApptLiMiddle");
						r.addClass("cusMyApptLiPadding");
						if (sap.ui.Device.system.phone) {
							r.addClass("cusMyApptLiMiddlePhone");
						}
						r.writeClasses();
						r.write(">");
						r.write("<div ");
						r.addClass("cusMyApptLiEllipsis");
						r.addClass("cusMyApptLiTitel");
						r.addClass("sapThemeFontSize");
						r.addClass("sapMSLITitle");
						r.writeClasses();
						r.write(">");
						r.write("<a href='javascript:void(0);' class='sapMLnk'>");
						if (c.getTitle()) {
							r.writeEscaped(c.getTitle());
						}
						r.write("</a> ");
						r.write("</div>");
						if (sap.ui.Device.system.phone) {
							r.write("<div ");
							r.addClass("sapMSLIDescription");
							r.addClass("cusMyApptLiEllipsis");
							r.writeClasses();
							r.write(">");
							if (c.getLocation()) {
								r.writeEscaped(c.getLocation());
							}
							r.write("</div>");
						} else {
							r.write("<div ");
							r.addClass("sapMSLIDescription");
							r.addClass("cusMyApptLiEllipsis");
							r.writeClasses();
							r.write(">");
							if (c.getSubtitle()) {
								r.writeEscaped(c.getSubtitle());
							}
							r.write("</div>");
						}
						r.write("</div>");
						if (!sap.ui.Device.system.phone) {
							r.write("<div ");
							r.addClass("cusMyApptLiRight");
							r.addClass("cusMyApptLiPadding");
							r.writeClasses();
							r.write(">");
							r.write("<div ");
							r.addClass("cusMyApptLiEllipsis");
							r.addClass("cusMyApptLiStatus");
							r.addClass("sapMSLIDescription");
							r.writeClasses();
							r.write(">");
							if (c.getContent()[0]) {
								r.renderControl(c.getContent()[0]);
							}
							r.write("</div>");
							r.write("<div ");
							r.addClass("cusMyApptLiEllipsis");
							r.addClass("sapMSLIDescription");
							r.writeClasses();
							r.write(">");
							if (c.getPrivat()) {
								r.writeEscaped(cus.crm.myaccounts.util.Util.geti18NText("PRIVATE"));
							}
							r.write("</div>");
							r.write("</div>");
						}
						r.write("</div>");
						r.write("</div>");
					}
				}
			});
			cus.crm.myaccounts.util.ApptListItem.M_EVENTS = {
				'press': 'press'
			};
			cus.crm.myaccounts.util.ApptListItem.prototype._handlePress = function(e) {
				if (e.target.className === "sapMLnk") {
					if (!this.firePress()) {
						e.preventDefault();
					}
				} else {
					e.preventDefault();
				}
			};
			if (jQuery.support.touch) {
				cus.crm.myaccounts.util.ApptListItem.prototype.ontap = cus.crm.myaccounts.util.ApptListItem.prototype._handlePress;
			} else {
				cus.crm.myaccounts.util.ApptListItem.prototype.onclick = cus.crm.myaccounts.util.ApptListItem.prototype._handlePress;
			}
			cus.crm.myaccounts.util.ApptListItem.prototype.ontouchstart = function(e) {
				e.originalEvent._sapui_handledByControl = true;
			};
		},
		"cus/crm/myaccounts/util/Constants.js": function() {
			cus.crm.myaccounts.util.Constants = {
				accountCategoryPerson: "1",
				accountCategoryCompany: "2",
				accountCategoryGroup: "3",
				filterMyAccounts: "MY_ACCOUNT",
				filterMyIndividualAccounts: "MY_INDIVIDUAL_ACCOUNTS",
				filterMyCorporateAccounts: "MY_CORPORATE_ACCOUNTS",
				filterMyAccountGroups: "MY_ACCOUNT_GROUPS",
				filterAllAccounts: "ALL_ACCOUNTS",
				filterAllIndividualAccounts: "ALL_INDIVIDUAL_ACCOUNTS",
				filterAllCorporateAccounts: "ALL_CORPORATE_ACCOUNTS",
				filterAllAccountGroups: "ALL_ACCOUNT_GROUPS",
				dataTypeDATE: "DATE",
				dataTypeCHAR: "CHAR",
				dataTypeCURR: "CURR",
				dataTypeNUM: "NUM",
				dataTypeTIME: "TIME",
				dataTypeCHEC: "CHEC",
				modeEdit: "EDIT",
				modeDisplay: "DISPLAY",
				fieldDate: "FIELD_DATE",
				fieldTime: "FIELD_TIME",
				fieldInput: "FIELD_INPUT",
				fieldSelect: "FIELD_SELECT",
				fieldCurrency: "FIELD_CURR"
			};
		},
		"cus/crm/myaccounts/util/Util.js": function() {
			jQuery.sap.declare("cus.crm.myaccounts.util.Util");
			jQuery.sap.require("sap.ca.ui.quickoverview.Quickoverview");
			cus.crm.myaccounts.util.Util = {
				setComponentConfiguration: function(c) {
					this.oComponentConfiguration = c;
				},
				setApplicationConfiguration: function(a) {
					this.oApplicationConfiguration = a;
				},
				getExternalServiceConfiguration: function() {
					if (this.oComponentConfiguration["cus.crm.myaccounts.externalServiceList"]) return this.oApplicationConfiguration.oServiceParams.externalServiceList
						.concat(this.oComponentConfiguration["cus.crm.myaccounts.externalServiceList"]);
					else return this.oApplicationConfiguration.oServiceParams.externalServiceList;
				},
				setApplicationFacade: function(a) {
					this.oApplicationFacade = a;
				},
				geti18NResourceBundle: function() {
					if (this.oApplicationFacade) {
						return this.oApplicationFacade.getResourceBundle();
					} else {
						return null;
					}
				},
				geti18NText: function(k) {
					if (this.geti18NResourceBundle()) {
						return this.geti18NResourceBundle().getText(k);
					} else {
						return null;
					}
				},
				geti18NText1: function(k, r) {
					if (this.geti18NResourceBundle()) {
						return this.geti18NResourceBundle().getText(k, r);
					} else {
						return null;
					}
				},
				openQuickoverview: function(p, t, s, a, c, b, d, C, e, f, n) {
					var g = c.getPath();
					var m = c.getModel();
					var h = C.getPath();
					var M = C.getModel();
					var o = {};
					o.Company = {};
					o.Company.Address = M.getProperty(h + "/" + e);
					o.Company.name = cus.crm.myaccounts.util.formatter.AccountNameFormatter(M.getProperty(h).fullName, M.getProperty(h).name1);
					o.Person = m.getProperty(g + "/" + b);
					var j = "";
					if (o.Person && d) {
						j = m.getProperty(g + "/" + b + "/" + d);
						o.Person.Address = j;
					}
					var B = new sap.ui.model.json.JSONModel();
					B.setData(o);
					var k, l;
					if (a) {
						k = false;
						l = a;
					} else {
						k = true;
						l = "";
					}
					var q = {
						popoverHeight: "32rem",
						title: p,
						headerNoIcon: k,
						headerImgURL: l,
						headerTitle: t,
						headerSubTitle: s,
						subViewName: "cus.crm.myaccounts.view.overview.Quickoverview",
						oModel: B,
						beforeExtNav: n
					};
					var r = new sap.ca.ui.quickoverview.Quickoverview(q);
					r.openBy(f);
					if (!o.Person || !j) {
						m.read(b, c, ["$expand=" + d], true, function(D) {
							var P = jQuery.parseJSON(JSON.stringify(D));
							o.Person = P;
							o.Person.Address = P[d];
							var u = sap.ui.getCore().byId("cus.crm.myaccounts.view.overview.Quickoverview").byId("quickOverviewForm1");
							var v;
							for (var i in u.getContent()) {
								v = sap.ui.getCore().byId(u.getContent()[i].getId());
								var w = v.getBindingInfo("text");
								if (w) w.binding.refresh();
							}
						}, function(E) {
							jQuery.sap.log.error("Read failed in Util.js:" + E.response.body);
						});
					}
					if (!o.Company.Address) {
						this.readODataObject(C, e, function() {});
					}
				},
				readODataObjects: function(c, r, f, a) {
					if (c.getModel().getProperty(c.sPath + "/" + r)) {
						a(c.getModel().getProperty(c.sPath + "/" + r));
						return;
					}
					var i = new sap.m.StandardListItem({
						text: ""
					});
					var l = new sap.m.List({
						items: {
							path: r,
							template: i,
							filters: f
						}
					});
					l.setModel(c.getModel());
					l.setBindingContext(c);
					var b = l.getBinding("items");
					var R = null;
					R = jQuery.proxy(function(d) {
						b.detachDataReceived(R);
						l.destroy();
						a(d.getSource().aKeys);
					}, this);
					b.attachDataReceived(R);
				},
				readODataObject: function(c, r, a) {
					var C = c.getModel().getProperty(c.sPath);
					if (c.getModel().getProperty(c.sPath + "/" + r)) {
						a(c.getModel().getProperty(c.sPath + "/" + r));
						return;
					}
					var l = new sap.m.List();
					l.bindElement(c.sPath + "/" + r);
					l.setModel(c.getModel());
					l.setBindingContext(c);
					var b = l.getElementBinding();
					var R = null;
					R = jQuery.proxy(function(d) {
						if (d.getSource().getBoundContext()) C[r] = {
							__ref: d.getSource().getBoundContext().sPath.substr(1)
						};
						else C[r] = null;
						b.detachDataReceived(R);
						l.destroy();
						a(c.getModel().getProperty(c.sPath + "/" + r));
					}, this);
					b.attachDataReceived(R);
				},
				readExpandedODataObjects: function(c, e, a) {
					var l = new sap.m.List();
					l.bindElement(c.sPath, {
						expand: e
					});
					l.setModel(c.getModel());
					l.setBindingContext(c);
					var b = l.getElementBinding();
					var r = null;
					r = jQuery.proxy(function() {
						b.detachDataReceived(r);
						l.destroy();
						if (a) a(c.getModel().getProperty(c.sPath));
					}, this);
					b.attachDataReceived(r);
				},
				sendBatchReadRequests: function(m, r, c, a) {
					var b = [];
					for (var i in r) {
						var R = m.createBatchOperation(r[i], "GET");
						b.push(R);
					}
					cus.crm.myaccounts.util.Util.sendBatchReadOperations(m, b, c, a);
				},
				sendBatchReadOperations: function(m, b, c, a) {
					m.clearBatch();
					m.addBatchReadOperations(b);
					m.submitBatch(function(d) {
						var e = null;
						var B = d.__batchResponses;
						var r = {};
						for (var i = 0; i < B.length; i++) {
							if (B[i].statusCode === "200") {
								var k = b[i].requestUri;
								if (B[i].data.results) {
									r[k] = B[i].data.results;
								} else if (B[i].data.__metadata) {
									if (!r[k]) {
										r[k] = B[i].data;
									} else if (r[k] instanceof Array) {
										r[k].push(B[i].data);
									} else {
										var o = r[k];
										r[k] = [o];
										r[k].push(B[i].data);
									}
								} else r[k] = B[i].data[Object.keys(B[i].data)[0]];
							} else {
								var R = jQuery.parseJSON(B[i].response.body);
								e = {
									type: sap.ca.ui.message.Type.ERROR,
									code: R.error.code,
									message: R.error.message.value,
									details: R.error.innererror.Error_Resolution.SAP_Note
								};
							}
						}
						if (e) {
							if (a) a(e);
							else sap.ca.ui.message.showMessageBox(e);
						} else {
							c(r);
						}
					}, function(e) {
						if (a) {
							e.response.body = jQuery.parseJSON(e.response.body);
							e = {
								type: sap.ca.ui.message.Type.ERROR,
								code: e.response.body.error.code,
								message: e.response.body.error.message.value,
								details: e.response.body.error.innererror.Error_Resolution.SAP_Note
							};
							a(e);
						} else {
							jQuery.sap.log.error("Read failed in Util.js->sendBatchReadOperations");
						}
					}, true);
				},
				sendBatchChangeOperations: function(m, b, c, a) {
					m.clearBatch();
					m.addBatchChangeOperations(b);
					var t = this;
					m.submitBatch(jQuery.proxy(function(d) {
						var e = {};
						var B = d.__batchResponses;
						var r = [];
						for (var i = 0; i < B.length; i++) {
							if (B[i].response) {
								e = jQuery.parseJSON(B[i].response.body).error;
								e.statusCode = B[i].response.statusCode;
								e.statusText = B[i].response.statusText;
							}
							if (B[i].__changeResponses && B[i].__changeResponses.length > 0 && B[i].__changeResponses[0].statusCode === "201") {
								r.push(B[i].__changeResponses[0].data);
							}
						}
						if (!e.message) {
							if (c) c.call(t, r);
						} else {
							if (a) a.call(t, e);
							else sap.m.MessageBox.alert(e.message.value);
						}
					}, this), true);
				},
				getRefreshUIObject: function(m, c, e) {
					if (!this.refreshList) this.refreshList = new sap.m.List();
					else {
						this.refreshList.unbindElement();
						this.refreshList.setModel(null);
					}
					var l = this.refreshList;
					if (e) l.bindElement(c, {
						expand: e
					});
					else l.bindElement(c);
					l.setModel(m);
					var b = l.getElementBinding();
					var C = null;
					C = jQuery.proxy(function() {
						if (b) b.detachDataRequested(C);
						b = null;
					}, this);
					b.attachDataRequested(C);
					var r = {
						refresh: function(d) {
							if (d) b.attachDataReceived(d);
							if (b) b.refresh();
						},
						destroy: function() {
							C();
						}
					};
					return r;
				},
				getServiceSchemaVersion: function(m, e) {
					var v = 0;
					var E = m.oMetadata._getEntityTypeByPath(e);
					for (var i in E.extensions) {
						if (E.extensions[i].name === "service-schema-version") v = E.extensions[i].value;
					}
					return v;
				}
			};
		},
		"cus/crm/myaccounts/util/formatter.js": function() {
			jQuery.sap.declare("cus.crm.myaccounts.util.formatter");
			jQuery.sap.require("cus.crm.myaccounts.util.Util");
			jQuery.sap.require("sap.ca.ui.model.format.DateFormat");
			jQuery.sap.require("sap.ca.ui.model.format.NumberFormat");
			jQuery.sap.require("sap.ca.ui.model.format.AmountFormat");
			cus.crm.myaccounts.util.formatter = {};
			cus.crm.myaccounts.util.formatter.formatMediumTimeInterval = function(f, t) {
				if (f && t) {
					if (f.getYear() === t.getYear() && f.getMonth() === t.getMonth() && f.getDay() === t.getDay()) return sap.ca.ui.model.format.DateFormat
						.getDateInstance({
							style: "medium"
						}).format(f);
					else {
						return sap.ca.ui.model.format.DateFormat.getDateInstance({
							style: "medium"
						}).format(f) + " - " + sap.ca.ui.model.format.DateFormat.getDateInstance({
							style: "medium"
						}).format(t);
					}
				} else {
					return "";
				}
			};
			cus.crm.myaccounts.util.formatter.formatMediumDateTime = function(v) {
				if (v) {
					return sap.ca.ui.model.format.DateFormat.getDateTimeInstance({
						style: "medium"
					}).format(v);
				} else {
					return "";
				}
			};
			cus.crm.myaccounts.util.formatter.formatMediumDate = function(v) {
				if (v) {
					return sap.ca.ui.model.format.DateFormat.getDateInstance({
						style: "medium"
					}).format(v);
				} else {
					return "";
				}
			};
			cus.crm.myaccounts.util.formatter.formatLongDate = function(v) {
				if (v) {
					return sap.ca.ui.model.format.DateFormat.getDateInstance({
						style: "long"
					}).format(v);
				} else {
					return "";
				}
			};
			cus.crm.myaccounts.util.formatter.formatShortDate = function(v) {
				if (v) {
					return sap.ca.ui.model.format.DateFormat.getDateInstance({
						style: "short"
					}).format(v);
				} else {
					return "";
				}
			};
			cus.crm.myaccounts.util.formatter.patternShortDate = function() {
				return sap.ca.ui.model.format.DateFormat.getDateInstance({
					style: "short"
				}).innerFormat.oFormatOptions.pattern;
			};
			cus.crm.myaccounts.util.formatter.formatAmounts = function(v, c) {
				if (v > 0) {
					return sap.ca.ui.model.format.AmountFormat.FormatAmountStandardWithCurrency(v, c);
				}
				return "";
			};
			cus.crm.myaccounts.util.formatter.formatShortAmounts = function(v, c) {
				if (v && v >= 0) {
					return sap.ca.ui.model.format.AmountFormat.FormatAmountShortWithCurrency(v, c);
				}
				return "";
			};
			cus.crm.myaccounts.util.formatter.formatMktAttrAmountInterval = function(a, d, c) {
				if (a && d && c) {
					var v = a.split(" - ");
					for (var j = 0; j < v.length; j++) {
						v[j] = cus.crm.myaccounts.util.formatter.formatMktAttrAmount(v[j], d, c);
					}
					return v.join(" - ");
				}
				return a;
			};
			cus.crm.myaccounts.util.formatter.formatMktAttrAmount = function(a, d, c) {
				if (a && d && c) {
					var v = a;
					var V = null;
					var D = parseInt(d);
					if (D === 0) {
						v = v.replace(/[.,]/g, '');
						V = parseFloat(v);
					} else if (a.charAt(a.length - D - 1) === "." || a.charAt(a.length - D - 1) === ",") {
						v = v.replace(/[.,]/g, '');
						v = v.substring(0, v.length - D) + "." + v.substring(v.length - D, v.length);
						V = parseFloat(v);
					}
					if (V) {
						return sap.ca.ui.model.format.AmountFormat.FormatAmountStandardWithCurrency(V, c, D);
					}
					return a;
				}
			};
			cus.crm.myaccounts.util.formatter.formatMktAttrTime = function(t) {
				var T = t.split(":");
				if (T.length > 1) return T[0] + ":" + T[1];
			};
			cus.crm.myaccounts.util.formatter.formatMktAttrDisplayField = function(v, a, b, d, c) {
				var V;
				switch (b) {
					case cus.crm.myaccounts.util.Constants.dataTypeDATE:
						V = v.split(" - ");
						for (var j = 0; j < V.length; j++) V[j] = cus.crm.myaccounts.util.formatter.convertStringToDate(V[j]);
						return V.join(" - ");
					case cus.crm.myaccounts.util.Constants.dataTypeTIME:
						var e = sap.ui.core.format.DateFormat.getTimeInstance({
							style: "short"
						});
						V = v.split(" - ");
						var j;
						for (j = 0; j < V.length; j++) {
							V[j] = V[j].replace(":", "");
							var D = e.parse(V[j]);
							if (D) V[j] = e.format(D);
						}
						return V.join(" - ");
					case cus.crm.myaccounts.util.Constants.dataTypeCURR:
						return cus.crm.myaccounts.util.formatter.formatMktAttrAmountInterval(v, d, c);
					default:
						return a;
				}
			};
			cus.crm.myaccounts.util.formatter.formatShortNumber = function(v, c) {
				if (v >= 0) {
					return sap.ca.ui.model.format.AmountFormat.FormatAmountShort(v, c);
				}
				return "";
			};
			cus.crm.myaccounts.util.formatter.formatProbability = function(v) {
				if (v >= 0) {
					return sap.ca.ui.model.format.AmountFormat.FormatAmountStandard(v, 3, 0) + " %";
				}
				return "";
			};
			cus.crm.myaccounts.util.formatter.formatEmployeeResponsible = function(f) {
				if (f) {
					return f;
				} else {
					return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText("EMPLOYEE_RESPONSIBLE");
				}
			};
			cus.crm.myaccounts.util.formatter.formatMediumDateTime = function(v) {
				if (v) {
					return sap.ca.ui.model.format.DateFormat.getDateTimeInstance({
						style: "medium"
					}).format(v);
				} else {
					return "";
				}
			};
			cus.crm.myaccounts.util.formatter.formatStartDate = function(v) {
				if (v) {
					var d = sap.ca.ui.model.format.DateFormat.getDateInstance({
						style: "medium"
					}).format(v);
					return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText("STARTING", [d]);
				} else {
					return "";
				}
			};
			cus.crm.myaccounts.util.formatter.formatCloseDate = function(v) {
				if (v) {
					var d = sap.ca.ui.model.format.DateFormat.getDateInstance({
						style: "medium"
					}).format(v);
					return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText("CLOSING", [d]);
				} else {
					return "";
				}
			};
			cus.crm.myaccounts.util.formatter.formatDueDate = function(v) {
				if (v) {
					var d = sap.ca.ui.model.format.DateFormat.getDateInstance({
						style: "medium"
					}).format(v);
					return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText("DUE", [d]);
				} else {
					return "";
				}
			};
			cus.crm.myaccounts.util.formatter.mimeTypeFormatter = function(v) {
				switch (v) {
					case 'application/vnd.openxmlformats-officedocument.presentationml.presentation':
					case 'application/vnd.ms-powerpoint':
						return 'pptx';
					case 'application/msword':
					case 'application/vnd.openxmlformats-officedocument.wordprocessingml.document':
						return 'doc';
					case 'application/vnd.ms-excel':
					case 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet':
						return 'xls';
					case 'image/jpeg':
					case 'image/png':
					case 'image/tiff':
					case 'image/gif':
						return 'jpg';
					case 'application/pdf':
						return 'pdf';
					case 'text/plain':
						return 'txt';
					default:
						return 'unknown';
				}
			};
			cus.crm.myaccounts.util.formatter.getRelativePathFromURL = function(a) {
				var u = document.createElement('a');
				u.href = a;
				if (u.pathname.substring(0, 1) === "/") return u.pathname;
				else return "/" + u.pathname;
			};
			cus.crm.myaccounts.util.formatter.logoUrlFormatter = function(m, c) {
				if (m) {
					return cus.crm.myaccounts.util.formatter.getRelativePathFromURL(m);
				} else {
					switch (c) {
						case '1':
							return "sap-icon://person-placeholder";
						case '2':
							return "sap-icon://factory";
						case '3':
							return "sap-icon://group";
						default:
							return "sap-icon://factory";
					}
				}
			};
			cus.crm.myaccounts.util.formatter.uploadUrlFormatter = function(a) {
				if (a) {
					var m = this.getModel();
					var u = m.sUrlParams;
					return m.sServiceUrl + "/AccountCollection('" + a + "')/Attachments" + (u ? '?' + u : '');
				}
				return "";
			};
			cus.crm.myaccounts.util.formatter.attachmentLinkFormatter = function(u, m) {
				if (u) {
					return u;
				}
				if (m) {
					return cus.crm.myaccounts.util.formatter.getRelativePathFromURL(m.media_src);
				}
			};
			cus.crm.myaccounts.util.formatter.logoVisibilityFormatter = function(m) {
				return m ? true : false;
			};
			cus.crm.myaccounts.util.formatter.standardIconVisibilityFormatter = function(a, m) {
				return (a && !m) ? true : false;
			};
			cus.crm.myaccounts.util.formatter.pictureUrlFormatter = function(m) {
				return m ? m : "sap-icon://person-placeholder";
			};
			cus.crm.myaccounts.util.formatter.locationFormatter = function(c, C) {
				if (!c) {
					return C;
				} else if (!C) {
					return c;
				} else {
					return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText("LOCATION", [c, C]);
				}
			};
			cus.crm.myaccounts.util.formatter.leadDescriptionFormatter = function(d, i) {
				if (d) {
					if (i) {
						return d + "\n" + i;
					} else {
						return d;
					}
				} else {
					if (i) {
						return i;
					}
				}
				return "";
			};
			cus.crm.myaccounts.util.formatter.nameAddressFormatter = function(n, a) {
				if (n) {
					if (a) {
						return n + "\n" + a;
					} else {
						return n;
					}
				} else {
					if (a) {
						return a;
					}
				}
				return "";
			};
			cus.crm.myaccounts.util.formatter.formatLocationContact = function(l, c) {
				var r = "";
				r = l;
				if (c) {
					if (r) r = r + " | " + c;
					else r = c;
				}
				return r;
			};
			cus.crm.myaccounts.util.formatter.formatTime = function(d, a) {
				if (a) {
					return cus.crm.myaccounts.util.Util.geti18NText("ALL_DAY_EVENT");
				} else if (d) {
					if (typeof d === "string") {
						d = d.replace("/Date(", "").replace(")/", "");
						d = parseInt(d);
						d = new Date(d);
					}
					var l = new sap.ui.core.LocaleData(sap.ui.getCore().getConfiguration().getLocale());
					var p = l.getTimePattern("short");
					var f = sap.ui.core.format.DateFormat.getDateTimeInstance({
						pattern: p
					});
					var t = f.format(d);
					return t;
				}
			};
			cus.crm.myaccounts.util.formatter.formatDuration = function(f, t) {
				if (f !== null && t !== null) {
					var d;
					var a;
					if (typeof f === "string") {
						f = cus.crm.myaccounts.util.formatter.getDatefromString(f);
					}
					if (typeof t === "string") {
						t = cus.crm.myaccounts.util.formatter.getDatefromString(t);
					}
					a = t.getTime() - f.getTime();
					d = Math.round(a / 60000);
					if (d < 60) {
						var n = d.toString();
						var m = cus.crm.myaccounts.util.Util.geti18NText1("DURATION_MINUTE", n);
						return m;
					} else {
						if (d < 1440) {
							var b = Math.round(d / 30);
							var c = b / 2;
							var e = sap.ui.core.format.NumberFormat.getFloatInstance();
							var g = e.format(c);
							n = g.toString();
							var h = cus.crm.myaccounts.util.Util.geti18NText1("DURATION_HOUR", n);
							return h;
						} else {
							var i = Math.ceil(d / 1440);
							n = i.toString();
							var j;
							if (i === "1") {
								j = cus.crm.myaccounts.util.Util.geti18NText1("DURATION_DAY", n);
							} else {
								j = cus.crm.myaccounts.util.Util.geti18NText1("DURATION_DAYS", n);
							}
							return j;
						}
					}
				}
			};
			cus.crm.myaccounts.util.formatter.getDatefromString = function(d) {
				d = d.replace("/Date(", "").replace(")/", "");
				d = parseInt(d);
				d = new Date(d);
				return d;
			};
			cus.crm.myaccounts.util.formatter.formatStatusText = function(s) {
				switch (s) {
					case 'E0001':
						return sap.ui.core.ValueState.Neutral;
					case 'E0002':
						return sap.ui.core.ValueState.Neutral;
					case 'E0003':
						return sap.ui.core.ValueState.Success;
					case 'E0004':
						return sap.ui.core.ValueState.Error;
					case 'E0007':
						return sap.ui.core.ValueState.Error;
					default:
						return sap.ui.core.ValueState.None;
				}
			};
			cus.crm.myaccounts.util.formatter.formatSalesOrderStatusText = function(s) {
				switch (s) {
					case 'A':
					case 'B':
						return sap.ui.core.ValueState.Warning;
					case 'C':
						return sap.ui.core.ValueState.Success;
					default:
						return sap.ui.core.ValueState.None;
				}
			};
			cus.crm.myaccounts.util.formatter.websiteURL = function(v) {
				if (!v) return "";
				var u = URI(v);
				if (!u.protocol()) u.protocol("http");
				if (jQuery.sap.validateUrl(u.toString())) return u.toString();
				else return "";
			};
			cus.crm.myaccounts.util.formatter.comaSeparator = function(v, a) {
				var s = v;
				if (a) return s ? s + ", " + a : a;
				return s;
			};
			cus.crm.myaccounts.util.formatter.sleshSeparator = function(v, a) {
				var s = v;
				if (a) return s ? s + " / " + a : a;
				return s;
			};
			cus.crm.myaccounts.util.formatter.AccountNameFormatter = function(f, n) {
				if (f) {
					return f;
				} else {
					return n;
				}
			};
			cus.crm.myaccounts.util.formatter.isEqual = function(v, a) {
				if (typeof(v) === "string" && typeof(a) === "string") {
					return v.valueOf() === a.valueOf();
				} else {
					return v === a;
				}
			};
			cus.crm.myaccounts.util.formatter.areEqual = function(v, a, b, c) {
				return (cus.crm.myaccounts.util.formatter.isEqual(v, a) && cus.crm.myaccounts.util.formatter.isEqual(b, c));
			};
			cus.crm.myaccounts.util.formatter.isUnequal = function(v, a) {
				if (typeof(v) === "string" && typeof(a) === "string") {
					return v.valueOf() !== a.valueOf();
				} else {
					return v !== a;
				}
			};
			cus.crm.myaccounts.util.formatter.isNotInitial = function(v) {
				if (v) return true;
				else return false;
			};
			cus.crm.myaccounts.util.formatter.isInitial = function(v) {
				if (!v) return true;
				else return false;
			};
			cus.crm.myaccounts.util.formatter.AccountSpecificText = function(t, a, b, c) {
				switch (c) {
					case cus.crm.myaccounts.util.Constants.accountCategoryPerson:
						return t;
					case cus.crm.myaccounts.util.Constants.accountCategoryCompany:
						return a;
					case cus.crm.myaccounts.util.Constants.accountCategoryGroup:
						return b;
				}
			};
			cus.crm.myaccounts.util.formatter.formatExpiryState = function(v, s, t) {
				if (s === "C") {
					return "None";
				}
				if (v) {
					var n = new Date();
					var d = new Date(v.getUTCFullYear(), v.getUTCMonth(), v.getUTCDate());
					n = new Date(n.getUTCFullYear(), n.getUTCMonth(), n.getUTCDate());
					var a = parseInt((d - n) / (24 * 3600 * 1000), 10);
					if (a <= t) {
						return "Error";
					}
					return "Success";
				}
				return "None";
			};
			cus.crm.myaccounts.util.formatter.convertDateStringToUTC = function(v) {
				var n;
				if (v === "") {
					n = null;
				} else {
					var d = sap.ui.core.format.DateFormat.getDateInstance({
						style: "medium"
					});
					var D = d.parse(v);
					if (D) {
						n = cus.crm.myaccounts.util.formatter.convertDateToUTC(D);
					} else {
						n = null;
					}
				}
				return n;
			};
			cus.crm.myaccounts.util.formatter.convertDateToUTC = function(d) {
				var u = null;
				if (d) {
					var n = new Date();
					n.setUTCFullYear(d.getFullYear());
					n.setUTCMonth(d.getMonth());
					n.setUTCDate(d.getDate());
					n.setUTCHours(0);
					n.setUTCMinutes(0);
					n.setUTCSeconds(0);
					n.setUTCMilliseconds(0);
					u = n;
				}
				return u;
			};
			cus.crm.myaccounts.util.formatter.convertStringToDate = function(v) {
				var n;
				if (v === "") {
					n = null;
				} else {
					var d = sap.ui.core.format.DateFormat.getDateInstance({
						style: "medium"
					});
					var D = d.parse(v);
					if (D) {
						n = d.format(D);
					} else {
						n = v;
					}
				}
				return n;
			};
			cus.crm.myaccounts.util.formatter.convertStringToFloat = function(s) {
				if (s) {
					return parseFloat(s);
				}
				return 0;
			};
		},
		"cus/crm/myaccounts/view/S2.controller.js": function() {
			jQuery.sap.require("cus.crm.myaccounts.controller.Base360Controller");
			jQuery.sap.require("sap.ca.ui.quickoverview.EmployeeLaunch");
			jQuery.sap.require("cus.crm.myaccounts.util.formatter");
			jQuery.sap.require("sap.ca.ui.model.format.AmountFormat");
			jQuery.sap.require("cus.crm.myaccounts.util.Constants");
			jQuery.sap.require("cus.crm.myaccounts.util.Util");
			cus.crm.myaccounts.controller.Base360Controller.extend("cus.crm.myaccounts.view.S2", {
				onInit: function() {
					if (cus.crm.myaccounts.view.overview && cus.crm.myaccounts.view.overview.OverviewPage.storage) {
						if (cus.crm.myaccounts.view.overview.OverviewPage.storage.onExit) cus.crm.myaccounts.view.overview.OverviewPage.storage.onExit();
						cus.crm.myaccounts.view.overview.OverviewPage.storage = null;
					}
					cus.crm.myaccounts.controller.Base360Controller.prototype.onInit.call(this);
					this.resourceBundle = this.oApplicationFacade.getResourceBundle();
					var m = this.getView().getModel();
					m.forceNoCache(true);
					this.EHP2Backend = cus.crm.myaccounts.util.Util.getServiceSchemaVersion(m, "AccountCollection") < 1;
					var M = [];
					if (this.EHP2Backend) {
						M = [{
							text: this.resourceBundle.getText("MY_ACCOUNT"),
							key: "MyAccount"
						}, {
							text: this.resourceBundle.getText("ALL_ACCOUNTS"),
							key: "All"
						}];
					} else {
						M = [{
							text: this.resourceBundle.getText("MY_ACCOUNT"),
							key: "MyAccount"
						}, {
							text: this.resourceBundle.getText("MY_INDIVIDUAL_ACCOUNTS"),
							key: "MyIndividual"
						}, {
							text: this.resourceBundle.getText("MY_CORPORATE_ACCOUNTS"),
							key: "MyCorporate"
						}, {
							text: this.resourceBundle.getText("MY_ACCOUNT_GROUPS"),
							key: "MyGroup"
						}, {
							text: this.resourceBundle.getText("ALL_ACCOUNTS"),
							key: "All"
						}, {
							text: this.resourceBundle.getText("ALL_INDIVIDUAL_ACCOUNTS"),
							key: "AllIndividual"
						}, {
							text: this.resourceBundle.getText("ALL_CORPORATE_ACCOUNTS"),
							key: "AllCorporate"
						}, {
							text: this.resourceBundle.getText("ALL_ACCOUNT_GROUPS"),
							key: "AllGroup"
						}];
					}
					var o = new sap.ui.model.json.JSONModel({
						isRefreshing: false,
						searchValue: "",
						selectedKey: "MyAccount",
						threshold: this.getThreshold(),
						items: M
					});
					this.getView().setModel(o, "config");
					this.oRouter.attachRouteMatched(this.handleNavTo, this);
				},
				onExit: function() {
					if (this.oCreateAccountActionSheet) {
						this.oCreateAccountActionSheet.destroy();
						this.oCreateAccountActionSheet = null;
					}
				},
				destroy: function() {
					var b = this.getTargetBinding();
					b.detachChange(this._fnOnBindingChange);
				},
				handleNavTo: function(e) {
					if (e.getParameter("name") === "mainPage") {
						var a = e.getParameter("arguments");
						this.getView().getModel('config').setProperty("/selectedKey", a.filterState);
					}
					if (e.getParameter("name") === "S2" || e.getParameter("name") === "mainPage") {
						jQuery.sap.log.info("My accounts nav to " + e.getParameter("name"));
						jQuery.sap.delayedCall(2000, this, function() {
							this.byId("myPullToRefresh").hide();
						});
						this._bindGrowingTileContainer();
						this.setHeaderFooterOptions(this._getHeaderFooterOptions());
					}
				},
				_bindGrowingTileContainer: function() {
					if (!this.getView().byId("myOverviewTile")) return;
					var g = this.getControl(),
						b;
					if (!this.getTargetBinding()) {
						g.setGrowingThreshold(this.getThreshold()).setGrowing(true);
						g.bindAggregation("content", {
							path: '/AccountCollection',
							filters: this._getFilters(),
							parameters: {
								expand: 'MainContact,Classification,MainAddress,Logo,AccountFactsheet',
								select: '*,MainContact,Classification,MainAddress,Logo,AccountFactsheet/opportunityVolume,AccountFactsheet/revenueCurrentYear,AccountFactsheet/lastContact,AccountFactsheet/nextContact'
							},
							template: this.getView().byId("myOverviewTile").clone()
						});
						this._fnOnBindingChange = jQuery.proxy(this.onBindingChange, this);
						b = this.getTargetBinding();
						b.attachChange(this._fnOnBindingChange);
					}
				},
				getControl: function() {
					return this._getTileContainer();
				},
				getTargetAggregation: function() {
					return "content";
				},
				_getTileContainer: function() {
					return this.byId("tileContainer");
				},
				_isMyAccount: function() {
					var k = this.getView().getModel('config').getProperty("/selectedKey");
					return ((k === "MyAccount") || (k === "MyIndividual") || (k === "MyCorporate") || (k === "MyGroup")) ? true : false;
				},
				isBackendSearch: function() {
					return true;
				},
				applyBackendSearchPattern: function(f, b) {
					var a = this._getFilters(),
						b = this.getControl().getBinding(this.getTargetAggregation());
					b.aApplicationFilters = [];
					b.filter(a);
				},
				onTileTap: function(e) {
					this.oRouter.navTo("detail", {
						contextPath: e.getSource().getBindingContext().sPath.replace('/', "")
					});
				},
				openBusinessCard: function(e) {
					var E = {};
					if (e) {
						var s = e.getSource();
						if (s) {
							var c = s.getBindingContext();
							if (c) {
								E = {
									name: c.getProperty("MainContact/fullName"),
									imgurl: this.photoUrlFormatter(c.getProperty("MainContact/Photo/__metadata/media_src")),
									department: c.getProperty("MainContact/department"),
									mobilephone: c.getProperty("MainContact/WorkAddress/mobilePhone"),
									officephone: c.getProperty("MainContact/WorkAddress/phone"),
									email: c.getProperty("MainContact/WorkAddress/email"),
									companyname: c.getProperty("MainContact/company"),
									companyaddress: c.getProperty("MainContact/WorkAddress/address")
								};
								var o = new sap.ca.ui.quickoverview.EmployeeLaunch(E);
								o.openBy(e.getParameters());
							}
						}
					}
				},
				photoUrlFormatter: function(m) {
					if (m) {
						return cus.crm.myaccounts.util.formatter.getRelativePathFromURL(m);
					} else {
						return "sap-icon://person-placeholder";
					}
				},
				_getHeaderFooterOptions: function() {
					var c = this;
					var b = [];
					if (!this.EHP2Backend) {
						b.push({
							sIcon: "sap-icon://add",
							onBtnPressed: function(e) {
								c._addAccount(e);
							}
						});
					}
					var f = "";
					if (this._oControlStore && this._oControlStore.oTitle) {
						f = this._oControlStore.oTitle.getText();
					}
					return {
						sFullscreenTitle: f,
						aAdditionalSettingButtons: [],
						buttonList: b,
						oFilterOptions: {
							aFilterItems: this.getView().getModel('config').getProperty("/items"),
							sSelectedItemKey: this.getView().getModel('config').getProperty("/selectedKey"),
							onFilterSelected: function(s) {
								jQuery.sap.log.info(s + " has been selected");
								c.getView().getModel('config').setProperty("/selectedKey", s);
								c.handleFilter();
							}
						},
						oAddBookmarkSettings: {
							icon: "sap-icon://Fiori2/F0002"
						}
					};
				},
				_addAccount: function(e) {
					var t = this;
					var c = this._getPossibleAccountCategories();
					var b = [];
					for (var i in c) {
						switch (c[i]) {
							case cus.crm.myaccounts.util.Constants.accountCategoryCompany:
								b.push(new sap.m.Button({
									text: this.resourceBundle.getText("CORPORATE_ACCOUNT"),
									press: function() {
										t._navigateToCreateScreen(cus.crm.myaccounts.util.Constants.accountCategoryCompany);
									}
								}));
								break;
							case cus.crm.myaccounts.util.Constants.accountCategoryPerson:
								b.push(new sap.m.Button({
									text: this.resourceBundle.getText("INDIVIDUAL_ACCOUNT"),
									press: function() {
										t._navigateToCreateScreen(cus.crm.myaccounts.util.Constants.accountCategoryPerson);
									}
								}));
								break;
							case cus.crm.myaccounts.util.Constants.accountCategoryGroup:
								b.push(new sap.m.Button({
									text: this.resourceBundle.getText("ACCOUNT_GROUP"),
									press: function() {
										t._navigateToCreateScreen(cus.crm.myaccounts.util.Constants.accountCategoryGroup);
									}
								}));
								break;
						}
					}
					if (!this.oCreateAccountActionSheet) {
						this.oCreateAccountActionSheet = new sap.m.ActionSheet("AddAccountActionSheet", {
							buttons: b,
							placement: sap.m.PlacementType.Top
						});
					}
					this.oCreateAccountActionSheet.openBy(e.getSource());
				},
				_getPossibleAccountCategories: function() {
					return [cus.crm.myaccounts.util.Constants.accountCategoryCompany, cus.crm.myaccounts.util.Constants.accountCategoryPerson, cus.crm
						.myaccounts.util.Constants.accountCategoryGroup
					];
				},
				_navigateToCreateScreen: function(a) {
					var p;
					p = {
						accountCategory: a
					};
					this.oRouter.navTo("new", p, false);
				},
				handleFilter: function() {
					var f = this._getFilters(),
						l = this.getTargetBinding();
					l.aApplicationFilters = [];
					l.filter(f);
					this._setFilterInURL();
				},
				_setFilterInURL: function() {
					var p = {};
					p.filterState = this.getView().getModel('config').getProperty("/selectedKey");
					this.oRouter.navTo("mainPage", p, true);
				},
				_getFilters: function() {
					var f = [],
						v = this.getView().getModel("config").getProperty("/searchValue"),
						i = this._isMyAccount(),
						s = this.getView().getModel("config").getProperty("/selectedKey");
					if (v && v.length > 0) {
						f.push(new sap.ui.model.Filter("fullName", sap.ui.model.FilterOperator.Contains, v));
					}
					f.push(new sap.ui.model.Filter("isMyAccount", sap.ui.model.FilterOperator.EQ, i));
					switch (s) {
						case "MyIndividual":
						case "AllIndividual":
							f.push(new sap.ui.model.Filter("category", sap.ui.model.FilterOperator.EQ, '1'));
							break;
						case "MyCorporate":
						case "AllCorporate":
							f.push(new sap.ui.model.Filter("category", sap.ui.model.FilterOperator.EQ, '2'));
							break;
						case "MyGroup":
						case "AllGroup":
							f.push(new sap.ui.model.Filter("category", sap.ui.model.FilterOperator.EQ, '3'));
							break;
					}
					return f;
				},
				refreshList: function() {
					jQuery.sap.delayedCall(2000, this, function() {
						this.byId("myPullToRefresh").hide();
					});
					var c = this.getControl(),
						i = this.getView().getModel("config").getProperty("/isRefreshing"),
						b = c.getBinding(this.getTargetAggregation()),
						r = jQuery.proxy(function() {
							this.getView().getModel("config").setProperty("/isRefreshing", false);
							b.detachDataReceived(r);
							sap.ca.ui.utils.busydialog.releaseBusyDialog();
						}, this),
						R = jQuery.proxy(function() {
							this.getView().getModel("config").setProperty("/isRefreshing", true);
							sap.ca.ui.utils.busydialog.requireBusyDialog();
							b.detachDataRequested(R);
						}, this),
						v;
					b.attachDataRequested(R);
					b.attachDataReceived(r);
					if (this.isBackendSearch() && !i) {
						v = this.getView().getModel("config").getProperty("/searchValue");
						this.applyBackendSearchPattern(v, b);
					}
				},
				onBindingChange: function() {
					var t = undefined,
						s = this.getView().getModel("config").getProperty("/selectedKey");
					switch (s) {
						case "MyAccount":
							t = "MY_ACCOUNT_TITLE";
							break;
						case "MyIndividual":
							t = "MY_INDIVIDUAL_ACCOUNT_TITLE";
							break;
						case "MyCorporate":
							t = "MY_CORPORATE_ACCOUNT_TITLE";
							break;
						case "MyGroup":
							t = "MY_ACCOUNT_GROUP_TITLE";
							break;
						case "All":
							t = "ALL_ACCOUNTS_TITLE";
							break;
						case "AllIndividual":
							t = "ALL_INDIVIDUAL_ACCOUNTS_TITLE";
							break;
						case "AllCorporate":
							t = "ALL_CORPORATE_ACCOUNTS_TITLE";
							break;
						case "AllGroup":
							t = "ALL_ACCOUNT_GROUPS_TITLE";
							break;
					}
					var i = t,
						c = 0,
						b = this.getTargetBinding();
					if (b) {
						c = b.getLength();
					}
					if (c > 0) this._oControlStore.oTitle.setText(this.resourceBundle.getText(i, c));
					else this._oControlStore.oTitle.setText(this.resourceBundle.getText(i, "0"));
				},
				getThreshold: function() {
					if (sap.ui.Device.os.Android) return 7;
					if (sap.ui.Device.system.phone) {
						return 3;
					} else {
						return 10;
					}
				}
			});
		},
		"cus/crm/myaccounts/view/S2.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core" xmlns="sap.m" xmlns:ca="sap.ca.ui"\n\txmlns:layout="sap.ui.layout" controllerName="cus.crm.myaccounts.view.S2"\n\tdisplayBlock="true" height="100%">\n\t<Page id="page">\n\t\t<subHeader>\n\t\t\t<Bar>\n\t\t\t\t<contentMiddle>\n\t\t\t\t\t<SearchField id="mySearchField" value="{config>/searchValue}"\n\t\t\t\t\t\tsearch="refreshList" showRefreshButton="{device>/isNoTouch}" placeholder="{i18n>SEARCH_ACCOUNTS}">\n\t\t\t\t\t</SearchField>\n\t\t\t\t</contentMiddle>\n\t\t\t</Bar>\n\t\t</subHeader>\n\t\t<content>\n\t\t\t<PullToRefresh id="myPullToRefresh" visible="{device>/isTouch}" refresh="refreshList"></PullToRefresh>\n\t\t\t<!-- Replace with required full screen control -->\n\n\t\t\t<ca:GrowingTileContainer id="tileContainer"\tvertical="true" horizontal="false" growingScrollToLoad="true">\n\n\t\t\t\t<!-- Extends the overview tile -->\n\t\t\t\t<core:ExtensionPoint name="extOverviewTile">\n\t\t\t\t\t<ca:OverviewTile id="myOverviewTile" contact="{path:\'MainContact/fullName\'}"\n\t\t\t\t\t\ticon="{parts:[{path:\'Logo/__metadata/media_src\'},{path: \'category\'}], formatter:\'cus.crm.myaccounts.util.formatter.logoUrlFormatter\'}"\n\t\t\t\t\t\taddress="{parts:[{path:\'MainAddress/city\'}, {path:\'MainAddress/country\'}],formatter:\'cus.crm.myaccounts.util.formatter.locationFormatter\'}"\n\t\t\t\t\t\ttitle= "{parts:[{path: \'fullName\'},{path: \'name1\'}],\n\t\t\t                formatter: \'cus.crm.myaccounts.util.formatter.AccountNameFormatter\'}" \t\t\t\t\t\t\n\t\t\t\t\t\trating="{Classification/ratingText}"\n\t\t\t\t\t\topportunities="{parts:[{path:\'AccountFactsheet/opportunityVolume/amount\'}, {path:\'AccountFactsheet/opportunityVolume/currency\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatShortAmounts\'}"\n\t\t\t\t\t\trevenue="{parts:[{path:\'AccountFactsheet/revenueCurrentYear/amount\'}, {path:\'AccountFactsheet/revenueCurrentYear/currency\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatShortAmounts\'}"\n\t\t\t\t\t\tlastContact="{parts:[{path:\'AccountFactsheet/lastContact/toDate\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatMediumDate\' }"\n\t\t\t\t\t\tnextContact="{parts:[{path:\'AccountFactsheet/nextContact/fromDate\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatMediumDate\' }"\n\t\t\t\t\t\tpress="onTileTap" contactPress="openBusinessCard">\n\t\t\t\t\t\t<ca:layoutData>\n\t\t\t\t\t\t\t<layout:GridData span="L4 M6 S12"></layout:GridData>\n\t\t\t\t\t\t</ca:layoutData>\n\t\t\t\t\t</ca:OverviewTile>\n\t\t\t\t</core:ExtensionPoint>\n\t\t\t\t\n\t\t\t</ca:GrowingTileContainer>\n\t\t</content>\n\t</Page>\n</core:View>\n',
		"cus/crm/myaccounts/view/S360.controller.js": function() {
			jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");
			jQuery.sap.require("cus.crm.myaccounts.util.formatter");
			jQuery.sap.require("cus.crm.myaccounts.util.Util");
			cus.crm.myaccounts.NavigationHelper = {};
			sap.ca.scfld.md.controller.BaseFullscreenController.extend("cus.crm.myaccounts.view.S360", {
				onInit: function() {
					this.oRouter.attachRouteMatched(this.handleNavTo, this);
					this.backendSupportsEdit = cus.crm.myaccounts.util.Util.getServiceSchemaVersion(this.getView().getModel(), "AccountCollection") >
						0;
				},
				onAfterRendering: function() {
					$('.sapCRMmyAccountsHeader .sapMFlexItem').attr("style", "float:left");
				},
				handleNavTo: function(e) {
					if (e.getParameter("name") === "s360") {
						var c = this,
							v = this.getView(),
							m = v.getModel(),
							p = '/' + e.getParameter("arguments").contextPath,
							a = new sap.ui.model.Context(m, '/' + e.getParameter("arguments").contextPath),
							b = function() {
								v.setBindingContext(a);
								var o = c._getHeaderFooterOptions();
								c.setHeaderFooterOptions(o);
							};
						v.setBindingContext(undefined);
						m.createBindingContext(p, "", {
							expand: this._getExpandForDataBinding()
						}, b, true);
					}
				},
				_getExpandForDataBinding: function() {
					return 'AccountFactsheet,AccountFactsheet/Attachments,Logo,AccountFactsheet/Opportunities,AccountFactsheet/Notes,AccountFactsheet/Contacts,AccountFactsheet/Contacts/WorkAddress,AccountFactsheet/Leads,AccountFactsheet/Tasks,Classification,MainAddress,EmployeeResponsible,EmployeeResponsible/WorkAddress';
				},
				_getSelectedText: function() {
					var a = this.getView().getModel().getProperty(this.getView().getBindingContext().sPath);
					var t = cus.crm.myaccounts.util.formatter.AccountNameFormatter(a.fullName, a.name1) + "\n";
					var m = this.getView().getModel().getProperty(this.getView().getBindingContext().sPath + "/MainAddress");
					if (m) t += m.address;
					return t;
				},
				_getShareDisplay: function() {
					var a = this.getView().getModel().getProperty(this.getView().getBindingContext().sPath);
					var t = cus.crm.myaccounts.util.formatter.AccountNameFormatter(a.fullName, a.name1);
					var m = this.getView().getModel().getProperty(this.getView().getBindingContext().sPath + "/MainAddress");
					var b = "";
					if (m) b = m.address;
					return new sap.m.StandardListItem({
						title: t,
						description: b
					});
				},
				_getDiscussID: function() {
					var u = document.createElement('a');
					u.href = this.getView().getModel().sServiceUrl;
					return u.pathname + this.getView().getBindingContext().sPath;
				},
				_getDiscussType: function() {
					var u = document.createElement('a');
					u.href = this.getView().getModel().sServiceUrl;
					return u.pathname + "/$metadata#AccountCollection";
				},
				_getDiscussName: function() {
					var a = this.getView().getModel().getProperty(this.getView().getBindingContext().sPath);
					return cus.crm.myaccounts.util.formatter.AccountNameFormatter(a.fullName, a.name1);
				},
				_getHeaderFooterOptions: function() {
					var t = this;
					var b = [];
					if (this.backendSupportsEdit) {
						b.push({
							sI18nBtnTxt: "BUTTON_EDIT",
							onBtnPressed: function() {
								var p;
								p = {
									contextPath: t.getView().getBindingContext().sPath.substr(1)
								};
								t.oRouter.navTo("edit", p, false);
							}
						});
					}
					return {
						buttonList: b,
						sI18NFullscreenTitle: "DETAIL_TITLE",
						onBack: function() {
							window.history.back();
						},
						oJamOptions: {
							oShareSettings: {
								oDataServiceUrl: "/sap/opu/odata/sap/SM_INTEGRATION_SRV/",
								object: {
									id: document.URL.replace(/&/g, "%26"),
									display: t._getShareDisplay(),
									share: t._getSelectedText()
								}
							},
							oDiscussSettings: {
								oDataServiceUrl: "/sap/opu/odata/sap/SM_INTEGRATION_SRV/",
								feedType: "object",
								object: {
									id: t._getDiscussID(),
									type: t._getDiscussType(),
									name: t._getDiscussName(),
									ui_url: document.URL
								}
							}
						},
						oAddBookmarkSettings: {
							icon: "sap-icon://Fiori2/F0002"
						}
					};
				},
				navToOpportunity: function() {
					var Q = this.getView().getModel().getProperty(this.getView().getBindingContext().sPath + "/AccountFactsheet/opportunitiesCount");
					this.navToOtherApplication("Opportunity", "manageOpportunity", this.getView().getModel().getProperty(this.getView().getBindingContext()
						.sPath).accountID, Q, this.getView().getModel().getProperty(this.getView().getBindingContext().sPath).name1);
				},
				navToLead: function() {
					var Q = this.getView().getModel().getProperty(this.getView().getBindingContext().sPath + "/AccountFactsheet/leadsCount");
					this.navToOtherApplication("Lead", "manageLead", this.getView().getModel().getProperty(this.getView().getBindingContext().sPath)
						.accountID, Q, this.getView().getModel().getProperty(this.getView().getBindingContext().sPath).name1);
				},
				navToAppointments: function() {
					var a = this.getView().getModel().getProperty(this.getView().getBindingContext().sPath).accountID;
					var n = this.getView().getBindingContext().sPath + "/AccountFactsheet/nextContact/fromDate";
					var b = this.getView().getModel().getProperty(n);
					var Q = this.getView().getModel().getProperty(this.getView().getBindingContext().sPath +
						"/AccountFactsheet/futureActivitiesCount");
					var f = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService;
					this.oCrossAppNavigator = f && f("CrossApplicationNavigation");
					if (null === b) {
						b = new Date();
					}
					var c = this.getDateParameterfromDate(b);
					cus.crm.myaccounts.NavigationHelper.qty = Q;
					cus.crm.myaccounts.NavigationHelper.accountName = this.getView().getModel().getProperty(this.getView().getBindingContext().sPath)
						.name1;
					this.oRouter.detachRouteMatched(this.handleNavTo, this, this);
					if (this.oCrossAppNavigator) this.oCrossAppNavigator.toExternal({
						target: {
							semanticObject: "Appointment",
							action: "myAppointments"
						},
						params: {
							"accountID": [a],
							"Date": [c]
						}
					});
				},
				getDateParameterfromDate: function(d) {
					var D = d.getDate().toString();
					D = (D.length === 1) ? "0" + D : D;
					var m = d.getMonth() + 1;
					m = m.toString();
					m = (m.length === 1) ? "0" + m : m;
					var y = d.getFullYear();
					var s = "" + y + m + D;
					return s;
				},
				navToTask: function() {
					var Q = this.getView().getModel().getProperty(this.getView().getBindingContext().sPath + "/AccountFactsheet/tasksCount");
					this.navToOtherApplication("Task", "manageTasks", this.getView().getModel().getProperty(this.getView().getBindingContext().sPath)
						.accountID, Q, this.getView().getModel().getProperty(this.getView().getBindingContext().sPath).name1);
				},
				navToNote: function(e) {
					this.oRouter.navTo("AccountNotes", {
						contextPath: e.getSource().getBindingContext().sPath.replace('/', "")
					});
				},
				navToContact: function() {
					var Q = this.getView().getModel().getProperty(this.getView().getBindingContext().sPath + "/AccountFactsheet/contactsCount");
					this.navToOtherApplication("ContactPerson", "MyContacts", this.getView().getModel().getProperty(this.getView().getBindingContext()
						.sPath).accountID, Q, this.getView().getModel().getProperty(this.getView().getBindingContext().sPath).name1);
				},
				navToOtherApplication: function(t, a, b, q, c) {
					var f = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService;
					this.oCrossAppNavigator = f && f("CrossApplicationNavigation");
					cus.crm.myaccounts.NavigationHelper.qty = q;
					cus.crm.myaccounts.NavigationHelper.accountName = c;
					this.oRouter.detachRouteMatched(this.handleNavTo, this, this);
					if (this.oCrossAppNavigator) this.oCrossAppNavigator.toExternal({
						target: {
							semanticObject: t,
							action: a
						},
						params: {
							"accountID": [b]
						}
					});
				},
				navToAttachment: function(e) {
					this.oRouter.navTo("AccountAttachments", {
						contextPath: e.getSource().getBindingContext().sPath.replace('/', "")
					});
				}
			});
		},
		"cus/crm/myaccounts/view/S360.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core" xmlns:ui="sap.ca.ui" xmlns:suite="sap.suite.ui.commons" xmlns:layout="sap.ui.layout" xmlns:html="http://www.w3.org/1999/xhtml"\n\txmlns="sap.m" controllerName="cus.crm.myaccounts.view.S360">\n\n\n\t<Page id="page" title="{i18n>DETAIL_TITLE}" showNavButton="true">\n\t\t<content>\n\t\t\t<layout:Grid class ="sapSuiteUtiHeaderGrid sapSuiteUti sapCRMmyAccountsHeader" defaultSpan="L6 M6 S12" vSpacing="0" >\n\t\t\t\t<layout:content>\n\t\t\t\t\t<HBox>\n\t\t\t\t\t\t<Image src="{parts:[{path:\'Logo/__metadata/media_src\'},{path: \'category\'}], formatter:\'cus.crm.myaccounts.util.formatter.logoUrlFormatter\'}" \t\t\n\t\t\t\t\t\t\theight="5rem" \n\t\t\t\t\t\t\twidth="5rem"\n\t\t\t\t\t\t\tvisible="{path:\'Logo/__metadata/media_src\', formatter:\'cus.crm.myaccounts.util.formatter.logoVisibilityFormatter\'}" >\n\t\t\t\t\t\t</Image>\n\t\t\t\t\t\t<ObjectHeader title="{parts:[{path: \'fullName\'},{path: \'name1\'}], formatter: \'cus.crm.myaccounts.util.formatter.AccountNameFormatter\'}"\n\t\t\t\t\t\t\tclass="sapSuiteUtiHeader">\n\t\t\t\t\t\t\t<attributes>\n\t\t\t\t\t\t\t\t<ObjectAttribute text="{accountID}"></ObjectAttribute>\n\t\t\t\t\t\t\t</attributes>\n\t\t\t\t\t\t</ObjectHeader>\n\t\t\t\t\t</HBox>\n\t\t\t\t\t\n\t\t\t\t\t<core:ExtensionPoint name="extKpiBox">\n\t\t\t\t\t\t<HBox class="sapSuiteUtiKpiBox">\n\t\t\t\t\t\t\t<suite:KpiTile \n\t\t\t\t\t\t\t\tvalue="{parts:[{path:\'AccountFactsheet/revenueCurrentYear/amount\'},{path:\'AccountFactsheet/revenueCurrentYear/currency\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatShortNumber\'}"\n\t\t\t\t\t\t\t\tvalueUnit="{parts:[{path:\'AccountFactsheet/revenueCurrentYear/currency\'}]}"\n\t\t\t\t\t\t\t\tdescription="{i18n>REVENUE_CURRENT}"\n\t\t\t\t\t\t\t\tdoubleFontSize="true"\n\t\t\t\t\t\t\t\t>\n\t\t\t\t\t\t\t</suite:KpiTile>\n\t\t\t\t\t\t\t<suite:KpiTile \n\t\t\t\t\t\t\t\tvalue="{parts:[{path:\'AccountFactsheet/revenueLastYear/amount\'},{path:\'AccountFactsheet/revenueLastYear/currency\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatShortNumber\'}"\n\t\t\t\t\t\t\t\tvalueUnit="{parts:[{path:\'AccountFactsheet/revenueLastYear/currency\'}]}"\n\t\t\t\t\t\t\t\tdescription="{i18n>REVENUE_LAST}"\n\t\t\t\t\t\t\t\tdoubleFontSize="true"\n\t\t\t\t\t\t\t\t>\n\t\t\t\t\t\t\t</suite:KpiTile>\n\t\t\t\t\t\t\t<core:ExtensionPoint name="extKpiTile"/>\n\t\t\t\t\t\t</HBox>\n\t\t\t\t\t</core:ExtensionPoint>\n\t\t\t\t</layout:content>\n\t\t\t</layout:Grid>\n\t\t\t<layout:Grid defaultSpan="L6 M12 S12">\n\t\t\t\t<layout:content>\n\t\t\t\t\t<core:ExtensionPoint name="extGeneralInfo">\n\t\t\t\t\t\t<suite:FacetOverview\n\t\t\t\t\t\t\ttitle="{i18n>GENERAL_DATA}" width="100%" height="200px">\n\t\t\t\t\t\t\t<suite:content>\n\t\t\t\t\t\t\t\t<layout:Grid defaultSpan="L6 M6 S6" hSpacing="0">\n\t\t\t\t\t\t\t\t\t<layout:content>\n\t\t\t\t\t\t\t\t\t\t<VBox height="200px">\n\t\t\t\t\t\t\t\t\t\t\t<items>\n\t\t\t\t\t\t\t\t\t\t\t\t<Label text="{i18n>ADDRESS}"></Label>\n\t\t\t\t\t\t\t\t\t\t\t\t<Text text="{MainAddress/address}"></Text>\n\t\t\t\t\t\t\t\t\t\t\t\t<Text></Text>\n\t\t\t\t\t\t\t\t\t\t\t\t<Label text="{i18n>UNWEIGHTED_OPPORTUNITIES}"></Label>\n\t\t\t\t\t\t\t\t\t\t\t\t<Text text="{parts:[{path:\'AccountFactsheet/opportunityVolume/amount\'}, {path:\'AccountFactsheet/opportunityVolume/currency\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatShortAmounts\'}"></Text>\n\t\t\t\t\t\t\t\t\t\t\t\t<core:ExtensionPoint name="extGeneralInfoLeft"/>\n\t\t\t\t\t\t\t\t\t\t\t</items>\n\t\t\t\t\t\t\t\t\t\t</VBox>\n\t\t\t\t\t\t\t\t\t\t<VBox>\n\t\t\t\t\t\t\t\t\t\t\t<items>\n\t\t\t\t\t\t\t\t\t\t\t\t<Label text="{i18n>RATING}"></Label>\n\t\t\t\t\t\t\t\t\t\t\t\t<Text text="{Classification/ratingText}"></Text>\n\t\t\t\t\t\t\t\t\t\t\t\t<Text></Text>\n\t\t\t\t\t\t\t\t\t\t\t\t<Label text="{parts:[{path:\'EmployeeResponsible/WorkAddress/function\'}], formatter:\'cus.crm.myaccounts.util.formatter.formatEmployeeResponsible\'}"></Label>\n\t\t\t\t\t\t\t\t\t\t\t\t<Text text="{EmployeeResponsible/fullName}"></Text>\n\t\t\t\t\t\t\t\t\t\t\t\t<core:ExtensionPoint name="extGeneralInfoRight"/>\n\t\t\t\t\t\t\t\t\t\t\t</items>\n\t\t\t\t\t\t\t\t\t\t</VBox>\n\t\t\t\t\t\t\t\t\t</layout:content>\n\t\t\t\t\t\t\t\t</layout:Grid>\n\t\t\t\t\t\t\t</suite:content>\n\t\t\t\t\t\t</suite:FacetOverview>\n\t\t\t\t\t</core:ExtensionPoint>\n\t\t\t\t\t<core:ExtensionPoint name="extContacts">\n\t\t\t\t\t\t<suite:FacetOverview\n\t\t\t\t\t\t\ttitle="{i18n>CONTACTS}"\n\t\t\t\t\t\t\twidth="100%"\n\t\t\t\t\t\t\tpress="navToContact"\n\t\t\t\t\t\t\tquantity="{path:\'AccountFactsheet/contactsCount\'}"\n\t\t\t\t\t\t\theight="200px">\n\t\t\t\t\t\t\t<suite:content>\n\t\t\t\t\t\t\t\t<layout:Grid defaultSpan="L6 M6 S12"\n\t\t\t\t\t\t\t\t\t\t\thSpacing="0" \n\t\t\t\t\t\t\t\t\t\t\tcontent="{path:\'AccountFactsheet/Contacts\'}" >\n\t\t\t\t\t\t\t\t\t<layout:content>\n\t\t\t\t\t\t\t\t\t\t<VBox height="200px">\n\t\t\t\t\t\t\t\t\t\t\t<items>\n\t\t\t\t\t\t\t\t\t\t\t\t<Label text="{function}"></Label>\n\t\t\t\t\t\t\t\t\t\t\t\t<Text text="{fullName}"></Text>\n\t\t\t\t\t\t\t\t\t\t\t\t<Text text="{WorkAddress/mobilePhone}"></Text>\n\t\t\t\t\t\t\t\t\t\t\t\t<Text text="{WorkAddress/email}"></Text>\n\t\t\t\t\t\t\t\t\t\t\t\t<core:ExtensionPoint name="extContactsInfo"/>\n\t\t\t\t\t\t\t\t\t\t\t</items>\n\t\t\t\t\t\t\t\t\t\t</VBox>\n\t\t\t\t\t\t\t\t\t</layout:content>\n\t\t\t\t\t\t\t\t</layout:Grid>\n\t\t\t\t\t\t\t</suite:content>\n\t\t\t\t\t\t</suite:FacetOverview>\n\t\t\t\t\t</core:ExtensionPoint>\n\t\t\t\t\t<core:ExtensionPoint name="extOpportunities">\n\t\t\t\t\t\t<suite:FacetOverview\n\t\t\t\t\t\t\ttitle="{i18n>OPPORTUNITIES}"\n\t\t\t\t\t\t\tpress="navToOpportunity"\n\t\t\t\t\t\t\twidth="100%"\n\t\t\t\t\t\t\tquantity="{path:\'AccountFactsheet/opportunitiesCount\', parameters:{expand:\'AccountFactsheet\'}}"\n\t\t\t\t\t\t\theight="200px">\n\t\t\t\t\t\t\t<suite:content>\n\t\t\t\t\t\t\t\t<layout:Grid defaultSpan="L6 M6 S12"\n\t\t\t\t\t\t\t\t\t\t\thSpacing="0"\n\t\t\t\t\t\t\t\t\t\t\tcontent="{path:\'AccountFactsheet/Opportunities\'}" >\n\t\t\t\t\t\t\t\t\t<layout:content>\n\t\t\t\t\t\t\t\t\t\t<VBox height="200px">\n\t\t\t\t\t\t\t\t\t\t\t<items>\n\t\t\t\t\t\t\t\t\t\t\t\t<Label text="{parts:[{path:\'closingDate\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatCloseDate\' }"></Label>\n\t\t\t\t\t\t\t\t\t\t\t\t<Text text="{description}"></Text>\n\t\t\t\t\t\t\t\t\t\t\t\t<Text text="{parts:[{path : \'expRevenue\'},{path : \'currency\'}], formatter:\'cus.crm.myaccounts.util.formatter.formatAmounts\'}"></Text>\n\t\t\t\t\t\t\t\t\t\t\t\t<Text text="{currPhaseText}"></Text>\n\t\t\t\t\t\t\t\t\t\t\t\t<core:ExtensionPoint name="extOpportunityInfo"/>\n\t\t\t\t\t\t\t\t\t\t\t</items>\n\t\t\t\t\t\t\t\t\t\t</VBox>\n\t\t\t\t\t\t\t\t\t</layout:content>\n\t\t\t\t\t\t\t\t</layout:Grid>\n\t\t\t\t\t\t\t</suite:content>\n\t\t\t\t\t\t</suite:FacetOverview>\n\t\t\t\t\t</core:ExtensionPoint>\n\t\t\t\t\t<core:ExtensionPoint name="extAppointments">\n\t\t\t\t\t\t<suite:FacetOverview\n\t\t\t\t\t\t\ttitle="{i18n>APPOINTMENTS}"\n\t\t\t\t\t\t\tpress="navToAppointments"\n\t\t\t\t\t\t\twidth="100%"\n\t\t\t\t\t\t\tquantity="{path:\'AccountFactsheet/futureActivitiesCount\', parameters:{expand:\'AccountFactsheet\'}}"\n\t\t\t\t\t\t\theight="200px">\n\t\t\t\t\t\t\t<suite:content>\n\t\t\t\t\t\t\t\t<layout:Grid defaultSpan="L6 M6 S12" hSpacing="0">\n\t\t\t\t\t\t\t\t\t<layout:content>\n\t\t\t\t\t\t\t\t\t\t<VBox height="200px">\n\t\t\t\t\t\t\t\t\t\t\t<items>\n\t\t\t\t\t\t\t\t\t\t\t\t<Label text="{i18n>NEXT_APPOINTMENT}"></Label>\n\t\t\t\t\t\t\t\t\t\t\t\t<Text text="{parts:[{path:\'AccountFactsheet/nextContact/fromDate\'}, {path:\'AccountFactsheet/nextContact/toDate\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatMediumTimeInterval\' }"></Text>\n\t\t\t\t\t\t\t\t\t\t\t\t<Text text="{AccountFactsheet/nextContact/description}"></Text>\n\t\t\t\t\t\t\t\t\t\t\t\t<core:ExtensionPoint name="extAppointmentLeft"/>\n\t\t\t\t\t\t\t\t\t\t\t</items>\n\t\t\t\t\t\t\t\t\t\t</VBox>\n\t\t\t\t\t\t\t\t\t\t<VBox>\n\t\t\t\t\t\t\t\t\t\t\t<items>\n\t\t\t\t\t\t\t\t\t\t\t\t<Label text="{i18n>LAST_APPOINTMENT}"></Label>\n\t\t\t\t\t\t\t\t\t\t\t\t<Text text="{parts:[{path:\'AccountFactsheet/lastContact/fromDate\'}, {path:\'AccountFactsheet/lastContact/toDate\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatMediumTimeInterval\' }"></Text>\n\t\t\t\t\t\t\t\t\t\t\t\t<Text text="{AccountFactsheet/lastContact/description}"></Text>\n\t\t\t\t\t\t\t\t\t\t\t\t<core:ExtensionPoint name="extAppointmentRight"/>\n\t\t\t\t\t\t\t\t\t\t\t</items>\n\t\t\t\t\t\t\t\t\t\t</VBox>\n\t\t\t\t\t\t\t\t\t</layout:content>\n\t\t\t\t\t\t\t\t</layout:Grid>\n\t\t\t\t\t\t\t</suite:content>\n\t\t\t\t\t\t</suite:FacetOverview>\n\t\t\t\t\t</core:ExtensionPoint>\n\t\t\t\t\t<core:ExtensionPoint name="extLeads">\n\t\t\t\t\t\t<suite:FacetOverview\n\t\t\t\t\t\t\ttitle="{i18n>LEADS}"\n\t\t\t\t\t\t\tpress="navToLead"\n\t\t\t\t\t\t\twidth="100%"\n\t\t\t\t\t\t\tquantity="{path:\'AccountFactsheet/leadsCount\', parameters:{expand:\'AccountFactsheet\'}}"\n\t\t\t\t\t\t\theight="200px">\n\t\t\t\t\t\t\t<suite:content>\n\t\t\t\t\t\t\t\t<layout:Grid defaultSpan="L6 M6 S12"\n\t\t\t\t\t\t\t\t\t\t\thSpacing="0"\n\t\t\t\t\t\t\t\t\t\t\tcontent="{path:\'AccountFactsheet/Leads\'}" >\n\t\t\t\t\t\t\t\t\t<layout:content>\n\t\t\t\t\t\t\t\t\t\t<VBox height="200px">\n\t\t\t\t\t\t\t\t\t\t\t<items>\n\t\t\t\t\t\t\t\t\t\t\t\t<Label text="{parts:[{path:\'validFrom\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatStartDate\' }"></Label>\n\t\t\t\t\t\t\t\t\t\t\t\t<Text text="{description}"></Text>\n\t\t\t\t\t\t\t\t\t\t\t\t<Text text="{qualificationLevel}"></Text>\n\t\t\t\t\t\t\t\t\t\t\t\t<Text text="{statusText}"></Text>\n\t\t\t\t\t\t\t\t\t\t\t\t<Text text="{importanceText}"></Text>\n\t\t\t\t\t\t\t\t\t\t\t\t<core:ExtensionPoint name="extLeadInfo"/>\n\t\t\t\t\t\t\t\t\t\t\t</items>\n\t\t\t\t\t\t\t\t\t\t</VBox>\n\t\t\t\t\t\t\t\t\t</layout:content>\n\t\t\t\t\t\t\t\t</layout:Grid>\n\t\t\t\t\t\t\t</suite:content>\n\t\t\t\t\t\t</suite:FacetOverview>\n\t\t\t\t\t</core:ExtensionPoint>\n\t\t\t\t\t<core:ExtensionPoint name="extTasks">\n\t\t\t\t\t\t<suite:FacetOverview\n\t\t\t\t\t\t\ttitle="{i18n>TASKS}"\n\t\t\t\t\t\t\tpress="navToTask"\n\t\t\t\t\t\t\twidth="100%"\n\t\t\t\t\t\t\tquantity="{path:\'AccountFactsheet/tasksCount\', parameters:{expand:\'AccountFactsheet\'}}"\n\t\t\t\t\t\t\theight="200px">\n\t\t\t\t\t\t\t<suite:content>\n\t\t\t\t\t\t\t\t<layout:Grid defaultSpan="L6 M6 S12"\n\t\t\t\t\t\t\t\t\t\t\thSpacing="0"\n\t\t\t\t\t\t\t\t\t\t\tcontent="{path:\'AccountFactsheet/Tasks\'}" >\n\t\t\t\t\t\t\t\t\t<layout:content>\n\t\t\t\t\t\t\t\t\t\t<VBox height="200px">\n\t\t\t\t\t\t\t\t\t\t\t<items>\n\t\t\t\t\t\t\t\t\t\t\t\t<Label text="{parts:[{path:\'dueDate\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatDueDate\' }"></Label>\n\t\t\t\t\t\t\t\t\t\t\t\t<Text text="{description}"></Text>\n\t\t\t\t\t\t\t\t\t\t\t\t<core:ExtensionPoint name="extTaskInfo"/>\n\t\t\t\t\t\t\t\t\t\t\t</items>\n\t\t\t\t\t\t\t\t\t\t</VBox>\n\t\t\t\t\t\t\t\t\t</layout:content>\n\t\t\t\t\t\t\t\t</layout:Grid>\n\t\t\t\t\t\t\t</suite:content>\n\t\t\t\t\t\t</suite:FacetOverview>\n\t\t\t\t\t</core:ExtensionPoint>\n\t\t\t\t\t<core:ExtensionPoint name="extNotes">\n\t\t\t\t\t\t<suite:FacetOverview\n\t\t\t\t\t\t\ttitle="{i18n>NOTES}"\n\t\t\t\t\t\t\tpress="navToNote"\n\t\t\t\t\t\t\twidth="100%"\n\t\t\t\t\t\t\tquantity="{path:\'AccountFactsheet/notesCount\', parameters:{expand:\'AccountFactsheet\'}}"\n\t\t\t\t\t\t\theight="200px">\n\t\t\t\t\t\t\t<suite:content>\n\t\t\t\t\t\t\t\t<layout:Grid defaultSpan="L6 M6 S12"\n\t\t\t\t\t\t\t\t\t\t\thSpacing="0"\n\t\t\t\t\t\t\t\t\t\t\tcontent="{path:\'AccountFactsheet/Notes\'}" >\n\t\t\t\t\t\t\t\t\t<layout:content>\n\t\t\t\t\t\t\t\t\t\t<VBox height="200px">\n\t\t\t\t\t\t\t\t\t\t\t<items>\n\t\t\t\t\t\t\t\t\t\t\t\t<Label text="{parts:[{path:\'createdAt\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatMediumDate\' }"></Label>\n\t\t\t\t\t\t\t\t\t\t\t\t<Text text="{content}"></Text>\n\t\t\t\t\t\t\t\t\t\t\t\t<core:ExtensionPoint name="extNoteInfo"/>\n\t\t\t\t\t\t\t\t\t\t\t</items>\n\t\t\t\t\t\t\t\t\t\t</VBox>\n\t\t\t\t\t\t\t\t\t</layout:content>\n\t\t\t\t\t\t\t\t</layout:Grid>\n\t\t\t\t\t\t\t</suite:content>\n\t\t\t\t\t\t</suite:FacetOverview>\n\t\t\t\t\t</core:ExtensionPoint>\n\t\t\t\t\t<core:ExtensionPoint name="extAttachments">\n\t\t\t\t\t\t<suite:FacetOverview\n\t\t\t\t\t\t\ttitle="{i18n>ATTACHMENTS}"\n\t\t\t\t\t\t\tpress="navToAttachment"\n\t\t\t\t\t\t\twidth="100%"\n\t\t\t\t\t\t\tquantity="{path:\'AccountFactsheet/attachmentsCount\', parameters:{expand:\'AccountFactsheet\'}}"\n\t\t\t\t\t\t\theight="200px">\n\t\t\t\t\t\t\t<suite:content>\n\t\t\t\t\t\t\t\t<layout:Grid defaultSpan="L6 M6 S12"\n\t\t\t\t\t\t\t\t\t\t\thSpacing="0"\n\t\t\t\t\t\t\t\t\t\t\tcontent="{path:\'AccountFactsheet/Attachments\'}" >\n\t\t\t\t\t\t\t\t\t<layout:content>\n\t\t\t\t\t\t\t\t\t\t<VBox height="200px">\n\t\t\t\t\t\t\t\t\t\t\t<items>\n\t\t\t\t\t\t\t\t\t\t\t\t<Label text="{parts:[{path:\'createdAt\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatMediumDate\' }"></Label>\n\t\t\t\t\t\t\t\t\t\t\t\t<Text text="{name}"></Text>\n\t\t\t\t\t\t\t\t\t\t\t\t<core:ExtensionPoint name="extAttachmentInfo"/>\n\t\t\t\t\t\t\t\t\t\t\t</items>\n\t\t\t\t\t\t\t\t\t\t</VBox>\n\t\t\t\t\t\t\t\t\t</layout:content>\n\t\t\t\t\t\t\t\t</layout:Grid>\n\t\t\t\t\t\t\t</suite:content>\n\t\t\t\t\t\t</suite:FacetOverview>\n\t\t\t\t\t</core:ExtensionPoint>\n\t\t\t\t\t<core:ExtensionPoint name="extFacetOverview"/>\n\t\t\t\t</layout:content>\n\t\t\t</layout:Grid>\n\t\t</content>\n\t\t\t\t<footer>\n            <Bar id="detailFooter">\n                <contentRight>\n                    <Button icon="sap-icon://action" press="handleAction" />\n                </contentRight>\n            </Bar>\n        </footer>\n\t</Page>\n</core:View>\n',
		"cus/crm/myaccounts/view/S4Attachments.controller.js": function() {
			jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");
			jQuery.sap.require("cus.crm.myaccounts.util.formatter");
			sap.ca.scfld.md.controller.BaseFullscreenController.extend("cus.crm.myaccounts.view.S4Attachments", {
				onInit: function() {
					this.oRouter.attachRouteMatched(this.handleNavTo, this);
				},
				handleNavTo: function(e) {
					if (e.getParameter("name") === "AccountAttachments") {
						var v = this.getView();
						var c = e.getParameter("arguments").contextPath;
						var m = this.getView().getModel();
						var p = '/' + e.getParameter("arguments").contextPath;
						var a = new sap.ui.model.Context(m, '/' + e.getParameter("arguments").contextPath);
						var b = function() {
							v.setBindingContext(a);
						};
						m.createBindingContext(p, "", {
							expand: 'Attachments'
						}, b, true);
						var t = this;
						if (m instanceof sap.ui.model.odata.ODataModel) {
							m.read(c + "/Attachments", null, null, true, function(d) {
								var f = JSON.parse(JSON.stringify(d));
								var g = {
									Attachments: []
								};
								$.each(f.results, function(i, h) {
									var o = {
										name: h.name,
										size: h.fileSize,
										url: cus.crm.myaccounts.util.formatter.getRelativePathFromURL(h.__metadata.media_src),
										uploadedDate: h.createdAt,
										contributor: h.createdBy,
										fileExtension: cus.crm.myaccounts.util.formatter.mimeTypeFormatter(h.mimeType),
										fileId: h.documentId
									};
									g.Attachments.push(o);
								});
								t.byId('fileupload').setModel(new sap.ui.model.json.JSONModel(g));
							});
						}
					}
				},
				handleNavBack: function() {
					window.history.back();
				},
				_refresh: function(c, e, d) {
					var t = this;
					if (d && d.context) {
						this.getView().setBindingContext(d.context);
						var m = this.getView().getModel();
						if (m instanceof sap.ui.model.odata.ODataModel) {
							m.read(d.context.getPath() + "/Attachments", null, null, true, function(D) {
								var a = JSON.parse(JSON.stringify(D));
								var d = {
									Attachments: []
								};
								$.each(a.results, function(i, v) {
									var o = {
										name: v.name,
										size: v.fileSize,
										url: cus.crm.myaccounts.util.formatter.getRelativePathFromURL(v.__metadata.media_src),
										uploadedDate: cus.crm.mycontacts.formatter.ReleaseFormatter.dateFormatter(v.createdAt),
										contributor: v.createdBy,
										fileExtension: cus.crm.mycontacts.formatter.ReleaseFormatter.mimeTypeFormatter(v.mimeType),
										fileId: v.documentId
									};
									d.Attachments.push(o);
								});
								t.byId('fileupload').setModel(new sap.ui.model.json.JSONModel(d));
							});
						}
					}
				}
			});
		},
		"cus/crm/myaccounts/view/S4Attachments.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core" xmlns:ca="sap.ca.ui" xmlns:html="http://www.w3.org/1999/xhtml"\n\txmlns="sap.m" controllerName="cus.crm.myaccounts.view.S4Attachments">\n\n\n\t<Page id="page" title="{i18n>ATTACHMENTS}" showNavButton="true" navButtonPress="handleNavBack">\n\t\t<content>\n\t\t\t<ObjectHeader title="{i18n>ATTACHMENTS}">\n\t\t\t\t<attributes>\n\t\t\t\t\t<ObjectAttribute text="{parts:[{path: \'fullName\'},{path: \'name1\'}], formatter: \'cus.crm.myaccounts.util.formatter.AccountNameFormatter\'}"></ObjectAttribute>\n\t\t\t\t</attributes>\n\t\t\t</ObjectHeader>\n\t\t\t<html:div><html:hr ></html:hr></html:div>\n\t\t\t <ca:FileUpload\n\t\t\t \tclass="sapCaUiNotes"\n\t\t\t    id="fileupload"\n\t\t\t    items="/Attachments"\n\t\t\t    uploadUrl="name"\n\t\t\t    fileName="name"\n\t\t\t    size="size"\n\t\t\t    url="url"\n\t\t\t    uploadedDate="uploadedDate"\n\t\t\t    contributor="contributor"\n\t\t\t    fileExtension="fileExtension"\n\t\t\t    fileId="documentId"\t\n\t\t\t    editMode="false"\n\t\t\t    showNoData="true" \n\t\t\t    uploadEnabled = "false"/>\n\t\t</content>\n\t</Page>\n</core:View>',
		"cus/crm/myaccounts/view/S4Notes.controller.js": function() {
			jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");
			jQuery.sap.require("cus.crm.myaccounts.util.formatter");
			sap.ca.scfld.md.controller.BaseFullscreenController.extend("cus.crm.myaccounts.view.S4Notes", {
				onInit: function() {
					this.oRouter.attachRouteMatched(this.handleNavTo, this);
				},
				handleNavTo: function(e) {
					if (e.getParameter("name") === "AccountNotes") {
						var v = this.getView();
						var m = this.getView().getModel();
						var p = '/' + e.getParameter("arguments").contextPath;
						var c = new sap.ui.model.Context(m, '/' + e.getParameter("arguments").contextPath);
						var b = function() {
							v.setBindingContext(c);
						};
						m.createBindingContext(p, "", {
							expand: 'Notes'
						}, b, true);
					}
				},
				handleNavBack: function() {
					window.history.back();
				}
			});
		},
		"cus/crm/myaccounts/view/S4Notes.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core" xmlns:ca="sap.ca.ui" xmlns:html="http://www.w3.org/1999/xhtml"\n\txmlns="sap.m" controllerName="cus.crm.myaccounts.view.S4Notes">\n\n\n\t<Page id="page" title="{i18n>NOTES}" showNavButton="true" navButtonPress="handleNavBack">\n\t\t<content>\n\t\t\t<ObjectHeader title="{i18n>NOTES}">\n\t\t\t\t<attributes>\n\t\t\t\t\t<ObjectAttribute text="{parts:[{path: \'fullName\'},{path: \'name1\'}], formatter: \'cus.crm.myaccounts.util.formatter.AccountNameFormatter\'}"></ObjectAttribute>\n\t\t\t\t</attributes>\n\t\t\t</ObjectHeader>\n\t\t\t<html:div><html:hr ></html:hr></html:div>\n\t\t\t<ca:Notes growing="true" growingThreshold="4" showNoteInput="false" items="{Notes}">\n\t\t\t\t<ca:ExpansibleFeedListItem  senderActive="false" showIcon="false" text="{content}" sender="{creator}" timestamp="{parts:[{path:\'createdAt\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatMediumDateTime\' }" maxLines="3"></ca:ExpansibleFeedListItem>\n\t\t\t</ca:Notes>\n\t\t</content>\n\t</Page>\n</core:View>',
		"cus/crm/myaccounts/view/maintain/GeneralDataEdit.controller.js": function() {
			jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");
			jQuery.sap.require("cus.crm.myaccounts.util.Util");
			jQuery.sap.require("cus.crm.myaccounts.util.formatter");
			jQuery.sap.require("cus.crm.myaccounts.util.Constants");
			jQuery.sap.require("sap.m.MessageToast");
			jQuery.sap.require("sap.m.MessageBox");
			sap.ca.scfld.md.controller.BaseFullscreenController.extend("cus.crm.myaccounts.view.maintain.GeneralDataEdit", {
				onInit: function() {
					this.addressForm = "editFormAddress" + this.getDefaultAddressFormat();
					this.addressFragment = "addressFragment" + this.getDefaultAddressFormat();
					this.liveChangeTimer = 0;
					this.editMode = true;
					this.oDataModel = null;
					this.valueHelpEmployeeResponsible = null;
					this.valueHelpCountry = null;
					this.valueHelpRegion = null;
					this.countryIDUsedForRegion = undefined;
					this.countryIDUsedForRegionSuggestion = undefined;
					this.customizingModel = new sap.ui.model.json.JSONModel({
						TitleCustomizing: [],
						AcademicTitleCustomizing: [],
						RatingCustomizing: [],
						DefaultEmployeeResponsible: []
					});
					this.getView().setModel(this.customizingModel, "Customizing");
					if (!this.oDataModel) this.oDataModel = this.getView().getModel();
					var c = new sap.ui.model.json.JSONModel(cus.crm.myaccounts.util.Constants);
					this.getView().setModel(c, "constants");
					this._readCustomizing(function() {
						this._refreshDropDownBoxes();
						this._setDefaultEmployeeResponsible();
					});
					this.oRouter.attachRouteMatched(function(e) {
						if (e.getParameter("name") === "edit") {
							this.editMode = true;
							this._cleanUp();
							var a = e.getParameter("arguments");
							var m = this.oDataModel;
							this.getView().setModel(m);
							var b = "/" + a.contextPath;
							var C = m.getContext(b);
							this.getView().setBindingContext(C);
							var d;
							var t = this;
							if (!C.getObject()) {
								m.createBindingContext(b, "", {
									expand: this._getExpandForDataBinding()
								}, function() {
									var C = t.getView().getBindingContext();
									var m = t.getView().getModel();
									d = m.getProperty(C.sPath + "/MainAddress/countryID");
									if (d && d !== "") {
										t._displayCountrySpecificAddressFormat(d);
										t._setAddressFieldsEnabled(true, false);
									} else {
										t._displayCountrySpecificAddressFormat(t.getDefaultAddressFormat());
										t._setAddressFieldsEnabled(false, false);
									}
								}, true);
							} else {
								d = m.getProperty(C.sPath + "/MainAddress/countryID");
								this._displayCountrySpecificAddressFormat(d);
								this._toggleAddressFields();
							}
						}
						if (e.getParameter("name") === "new") {
							this.editMode = false;
							this._cleanUp();
							var f = e.getParameter("arguments").accountCategory;
							if (f !== cus.crm.myaccounts.util.Constants.accountCategoryPerson && f !== cus.crm.myaccounts.util.Constants.accountCategoryCompany &&
								f !== cus.crm.myaccounts.util.Constants.accountCategoryGroup) f = cus.crm.myaccounts.util.Constants.accountCategoryCompany;
							this._setEmptyScreen(f);
							this._displayCountrySpecificAddressFormat(this.getDefaultAddressFormat());
							this._toggleAddressFields();
						}
					}, this);
				},
				getDefaultAddressFormat: function() {
					if (this.extHookGetDefaultAddressFormat) return this.extHookGetDefaultAddressFormat();
					else return "";
				},
				_displayCountrySpecificAddressFormat: function(c) {
					this.getView().byId(this.addressForm).setVisible(false);
					this._setAddressFragmentAndForm(c);
					this.getView().byId(this.addressForm).setVisible(true);
				},
				_setAddressFragmentAndForm: function(c) {
					this.addressFragment = "addressFragment" + c;
					this.addressForm = "editFormAddress" + c;
					if (!this.getView().byId(this.addressForm)) {
						this.addressFragment = "addressFragment" + this.getDefaultAddressFormat();
						this.addressForm = "editFormAddress" + this.getDefaultAddressFormat();
					}
				},
				_setEmptyScreen: function(a) {
					var A = this._getTemplateForAccount(a);
					var d = this._getDependentRelations();
					for (var i in d) {
						A[d[i]] = this._getTemplateForDependentObject(d[i]);
					}
					var n = new sap.ui.model.json.JSONModel({
						NewAccount: A
					});
					n.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
					this.getView().setModel(n);
					this.getView().setBindingContext(n.getContext("/NewAccount"));
					this._setDefaultEmployeeResponsible();
				},
				_getExpandForDataBinding: function() {
					var e = null;
					var d = this._getDependentRelations();
					for (var i in d) {
						if (!e) e = d[i];
						else e = e + "," + d[i];
					}
					return e;
				},
				_getDependentRelations: function() {
					var d = ["MainAddress", "Classification", "EmployeeResponsibleRel", "EmployeeResponsible"];
					var D = [];
					if (this.extHookGetDependentCustomRelations) D = this.extHookGetDependentCustomRelations();
					for (var i in D) {
						d.push(D[i]);
					}
					return d;
				},
				_getTemplateForAccount: function(a) {
					var A = this._generateTemplateUsingMetadata("AccountCollection");
					A.category = a;
					return A;
				},
				_getTemplateForDependentObject: function(r) {
					switch (r) {
						case "EmployeeResponsibleRel":
							{
								var R = this._generateTemplateUsingMetadata("AccountCollection/" + r);R.main = true;R.relationshipCategory = 'BUR011';
								return R;
							}
						default:
							return this._generateTemplateUsingMetadata("AccountCollection/" + r);
					}
				},
				_generateTemplateUsingMetadata: function(p) {
					var e = this.oDataModel.oMetadata._getEntityTypeByPath(p);
					var t = {};
					for (var i in e.property) {
						switch (e.property[i].type) {
							case "Edm.Boolean":
								{
									t[e.property[i].name] = false;
									break;
								}
							case "Edm.DateTime":
								{
									t[e.property[i].name] = null;
									break;
								}
							default:
								t[e.property[i].name] = "";
						}
					}
					return t;
				},
				_objectKeyIsInitial: function(o, p) {
					var e = this.oDataModel.oMetadata._getEntityTypeByPath(p);
					for (var i in e.key.propertyRef)
						if (o[e.key.propertyRef[i].name] !== "") return false;
					return true;
				},
				_fillNewObject: function(s, t, f, a) {
					var c = false;
					var i = "";
					for (var k in s) {
						if (a) i = this.getView().getId() + "--" + a + "--" + f + k + "Input";
						else i = this.getView().getId() + "--" + f + k + "Input";
						if (typeof s[k] !== "object" || k === "birthDate") t[k] = s[k];
						var I = this.byId(i);
						if (I) {
							var n = "";
							if (I.getDateValue) {
								n = I.getValue();
								n = cus.crm.myaccounts.util.formatter.convertDateStringToUTC(n);
							} else if (I.getSelectedKey) n = I.getSelectedKey();
							else if (I.getValue) n = I.getValue();
							else if (I.getSelected) n = I.getSelected();
							if (n && n.getTime) {
								if (!t[k] || n.getTime() !== t[k].getTime()) {
									c = true;
									t[k] = n;
								}
							} else if (t[k] !== n) {
								c = true;
								t[k] = n;
							}
						}
					}
					return c;
				},
				_onAfterSave: function(r, e) {
					this._setBusy(false);
					if (e) {
						if (this["_onAfterSaveHandleErrorCode_" + e.statusCode]) this["_onAfterSaveHandleErrorCode_" + e.statusCode]();
						else sap.m.MessageBox.alert(e.message.value);
						return;
					}
					if (this.editMode) window.history.back();
					else this.oRouter.navTo("detail", {
						contextPath: "AccountCollection('" + r.accountID + "')"
					}, true);
				},
				_onAfterSaveHandleErrorCode_412: function() {
					var t = this;
					sap.m.MessageBox.show(cus.crm.myaccounts.util.Util.geti18NText("MSG_CONFLICTING_DATA"), {
						title: cus.crm.myaccounts.util.Util.geti18NText("CONFIRM_TITLE"),
						actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
						onClose: function(c) {
							if (c === sap.m.MessageBox.Action.YES) {
								t._saveData(true);
							} else {
								var r = cus.crm.myaccounts.util.Util.getRefreshUIObject(t.getView().getModel(), t.getView().getBindingContext().sPath, t._getExpandForDataBinding());
								r.refresh();
							}
						}
					});
				},
				onSaveButtonPressed: function() {
					this._saveData(false);
				},
				_saveData: function(f) {
					var e = null;
					if (f) e = "*";
					if (!this.byId(sap.ui.core.Fragment.createId(this.addressFragment, "MainAddress.countryIDInput")).getValue()) {
						this._setAddressFieldsEnabled(false, true);
					}
					if (!this._checkSavePossible()) return;
					if (!this._checkSaveNeeded()) {
						this.onCancelButtonPressed();
						return;
					}
					this._setBusy(true);
					var m = this.getView().getModel();
					var a = this.getView().getBindingContext();
					var A = a.getObject();
					var n = {};
					var c = false,
						b = false,
						d = false;
					c = this._fillNewObject(A, n, "");
					if (A.category === cus.crm.myaccounts.util.Constants.accountCategoryPerson) b = this._fillNewObject(n, n, "", "personFragment");
					if (A.category !== cus.crm.myaccounts.util.Constants.accountCategoryPerson) b = this._fillNewObject(n, n, "", "companyFragment");
					if (b) c = b;
					d = this._changesForDependentRelationsExists("saveMode");
					if (!c && !d) return;
					var B, r;
					var g = [];
					var t = this;
					if (this.editMode) {
						if (c) {
							r = a.sPath;
							B = m.createBatchOperation(r, "PUT", n, {
								sETag: e
							});
							g.push(B);
						}
						if (d) {
							this._createBatchOperationForDependentRelations(g, e);
						}
						cus.crm.myaccounts.util.Util.sendBatchChangeOperations(this.oDataModel, g, function(h) {
							var R = cus.crm.myaccounts.util.Util.getRefreshUIObject(m, a.sPath, t._getExpandForDataBinding());
							R.refresh();
							sap.m.MessageToast.show(cus.crm.myaccounts.util.Util.geti18NText("MSG_UPDATE_SUCCESS"));
							t._onAfterSave(h[0]);
						}, function(E) {
							t._onAfterSave(null, E);
						});
					} else {
						r = "/AccountCollection";
						B = this.oDataModel.createBatchOperation(r, "POST", n);
						if (d) {
							this._adaptAccountWithDependentRelationsBeforeCreate(n);
						}
						g.push(B);
						cus.crm.myaccounts.util.Util.sendBatchChangeOperations(this.oDataModel, g, function(h) {
							sap.m.MessageToast.show(cus.crm.myaccounts.util.Util.geti18NText("MSG_CREATION_SUCCESS"));
							t._onAfterSave(h[0]);
						}, function(E) {
							t._onAfterSave(null, E);
						});
					}
				},
				_adaptAccountWithDependentRelationsBeforeCreate: function(n) {
					var d = this._getDependentRelations();
					for (var i in d) {
						var D = this._getTemplateForDependentObject(d[i]);
						var N = {};
						var f = null;
						if (d[i] === "MainAddress") {
							f = this.addressFragment;
						}
						var c = this._fillNewObject(D, N, d[i] + ".", f);
						if (c) n[d[i]] = N;
					}
				},
				_createBatchOperationForDependentRelations: function(b, e) {
					var m = this.getView().getModel();
					var a = this.getView().getBindingContext();
					var A = a.getObject();
					var d = this._getDependentRelations();
					for (var i in d) {
						var D = m.getProperty(a + "/" + d[i]);
						var o = null;
						if (D) o = m.getContext("/" + A[d[i]]["__ref"]);
						var n = {};
						var c = false;
						var f = false;
						if (!D || this._objectKeyIsInitial(D, "AccountCollection/" + d[i])) {
							f = true;
							D = this._getTemplateForDependentObject(d[i]);
							if (D.accountID !== null && D.accountID !== undefined) D.accountID = A.accountID;
						}
						var g = null;
						if (d[i] === "MainAddress") {
							g = this.addressFragment;
						}
						c = this._fillNewObject(D, n, d[i] + ".", g);
						var B, r;
						if (c) {
							var h;
							if (f) {
								h = "POST";
								var E = this.oDataModel.oMetadata._getEntityTypeByPath("AccountCollection/" + d[i]);
								r = E.name + "Collection";
							} else {
								h = "PUT";
								r = o.sPath;
							}
							B = m.createBatchOperation(r, h, n, {
								sETag: e
							});
							b.push(B);
						}
					}
				},
				_changesForDependentRelationsExists: function(s) {
					var m = this.oDataModel;
					var a = this.getView().getBindingContext();
					var c = false;
					var d = this._getDependentRelations();
					for (var i in d) {
						var D = m.getProperty(a + "/" + d[i]);
						if (!s) D = a.getProperty(d[i]);
						if (!D) D = this._getTemplateForDependentObject(d[i]);
						var n = {};
						var f = null;
						if (d[i] === "MainAddress") {
							f = this.addressFragment;
						}
						c = this._fillNewObject(D, n, d[i] + ".", f);
						if (c) return c;
					}
					return c;
				},
				onCancelButtonPressed: function() {
					if (!this._checkSaveNeeded()) {
						window.history.back();
						return;
					}
					sap.m.MessageBox.confirm(cus.crm.myaccounts.util.Util.geti18NText("MSG_CONFIRM_CANCEL"), jQuery.proxy(function(c) {
						if (c === "OK") {
							window.history.back();
						}
					}, this));
				},
				onBackButtonPressed: function() {
					if (!this._checkSaveNeeded()) {
						window.history.back();
						return;
					}
					sap.m.MessageBox.confirm(cus.crm.myaccounts.util.Util.geti18NText("MSG_CONFIRM_CANCEL"), jQuery.proxy(function(c) {
						if (c === "OK") {
							window.history.back();
						}
					}, this));
				},
				onInputFieldChanged: function() {},
				_checkSavePossible: function() {
					var i, c, a, r, b, e, d, u;
					i = this.byId(sap.ui.core.Fragment.createId(this.addressFragment, "MainAddress.countryIDInput"));
					if (i) c = i.getValue();
					i = this.byId(sap.ui.core.Fragment.createId(this.addressFragment, "MainAddress.countryInput"));
					if (i) a = i.getValue();
					if (a && !c) {
						sap.m.MessageBox.alert(cus.crm.myaccounts.util.Util.geti18NText1("MSG_WRONG_COUNTRY_ERROR", a));
						return false;
					}
					i = this.byId(sap.ui.core.Fragment.createId(this.addressFragment, "MainAddress.regionIDInput"));
					if (i) r = i.getValue();
					i = this.byId(sap.ui.core.Fragment.createId(this.addressFragment, "MainAddress.regionInput"));
					if (i) b = i.getValue();
					if (b && !r) {
						sap.m.MessageBox.alert(cus.crm.myaccounts.util.Util.geti18NText1("MSG_WRONG_REGION_ERROR", b));
						return false;
					}
					i = this.getView().byId("EmployeeResponsibleRel.account2IDInput");
					if (i) e = i.getValue();
					i = this.getView().byId("EmployeeResponsibleRel.account2FullNameInput");
					if (i) d = i.getValue();
					if (d && !e) {
						sap.m.MessageBox.alert(cus.crm.myaccounts.util.Util.geti18NText1("MSG_WRONG_EMPLOYEE_ERROR", d));
						return false;
					}
					i = this.byId(sap.ui.core.Fragment.createId(this.addressFragment, "MainAddress.websiteInput"));
					if (i) {
						u = i.getValue();
						if (!jQuery.sap.validateUrl(u)) {
							sap.m.MessageBox.alert(cus.crm.myaccounts.util.Util.geti18NText1("MSG_WRONG_URL_ERROR", u));
							return false;
						}
					}
					var f = true;
					var A = this.getView().getBindingContext().getObject();
					if (A.category === cus.crm.myaccounts.util.Constants.accountCategoryPerson) {
						if (this.byId(sap.ui.core.Fragment.createId("personFragment", "name1Input")).getValue().length === 0) {
							this.byId(sap.ui.core.Fragment.createId("personFragment", "name1Input")).setValueState(sap.ui.core.ValueState.Error);
							f = false;
						}
					} else {
						if (this.byId(sap.ui.core.Fragment.createId("companyFragment", "name1Input")).getValue().length === 0) {
							this.byId(sap.ui.core.Fragment.createId("companyFragment", "name1Input")).setValueState(sap.ui.core.ValueState.Error);
							f = false;
						}
					}
					if (!f) sap.m.MessageBox.alert(cus.crm.myaccounts.util.Util.geti18NText("MSG_MANDATORY_FIELDS"));
					return f;
				},
				_checkSaveNeeded: function() {
					var a = this.getView().getBindingContext();
					var A = a.getObject();
					var n = {};
					var c = false,
						b = false;
					c = this._fillNewObject(A, n, "");
					if (c) return true;
					if (A.category === cus.crm.myaccounts.util.Constants.accountCategoryPerson) c = this._fillNewObject(n, n, "", "personFragment");
					if (A.category !== cus.crm.myaccounts.util.Constants.accountCategoryPerson) c = this._fillNewObject(n, n, "", "companyFragment");
					if (c) return true;
					b = this._changesForDependentRelationsExists();
					if (!b) return false;
					else return true;
				},
				_cleanUp: function() {
					this.getView().setModel(null);
					this.setBtnEnabled("saveButton", true);
				},
				_setBusy: function(b) {
					if (!this.oBusyDialog) this.oBusyDialog = new sap.m.BusyDialog();
					if (b) {
						this.setBtnEnabled("saveButton", !b);
						this.setBtnEnabled("cancelButton", !b);
						this.oBusyDialog.open();
					} else {
						this.setBtnEnabled("saveButton", !b);
						this.setBtnEnabled("cancelButton", !b);
						this.oBusyDialog.close();
					}
				},
				_setCountry: function(c, a) {
					if (c) this._displayCountrySpecificAddressFormat(c);
					var b = this.byId(sap.ui.core.Fragment.createId(this.addressFragment, "MainAddress.countryInput"));
					var d = this.byId(sap.ui.core.Fragment.createId(this.addressFragment, "MainAddress.countryIDInput"));
					var o = d.getValue();
					if (o !== c) {
						this._setRegion("", "");
					}
					if (b) b.setValue(a);
					if (d) d.setValue(c);
					this._toggleAddressFields();
				},
				_readCountries: function(c) {
					var t = this;
					this.valueHelpCountry.setModel(new sap.ui.model.json.JSONModel({
						CountryCustomizing: []
					}));
					this.oDataModel.read("/CustomizingCountryCollection", null, undefined, true, function(d) {
						var a = jQuery.parseJSON(JSON.stringify(d));
						t.valueHelpCountry.setModel(new sap.ui.model.json.JSONModel({
							CountryCustomizing: a.results
						}));
						if (c) c.call(t);
					}, function(e) {
						jQuery.sap.log.error("Read failed in GeneralDateEdit->_readCountries:" + e.response.body);
					});
				},
				_setRegion: function(r, a) {
					var b = this.byId(sap.ui.core.Fragment.createId(this.addressFragment, "MainAddress.regionInput"));
					if (b) b.setValue(a);
					var c = this.byId(sap.ui.core.Fragment.createId(this.addressFragment, "MainAddress.regionIDInput"));
					if (c) c.setValue(r);
				},
				_readRegions: function(c) {
					var t = this;
					var a = this.byId(sap.ui.core.Fragment.createId(this.addressFragment, "MainAddress.countryIDInput")).getValue();
					if (!t.aRegionCallback) t.aRegionCallback = [];
					if (t.regionReadRunning && c) {
						t.aRegionCallback.push(c);
						return;
					}
					if (this.countryIDUsedForRegion === a) {
						if (c) c.call(t);
						return;
					}
					if (c) t.aRegionCallback.push(c);
					t.regionReadRunning = true;
					this.countryIDUsedForRegion = a;
					this.valueHelpRegion.setModel(new sap.ui.model.json.JSONModel({
						RegionCustomizing: []
					}));
					this.oDataModel.read("/CustomizingRegionCollection", null, '$filter=countryID%20eq%20%27' + a + '%27', true, function(d) {
						var r = jQuery.parseJSON(JSON.stringify(d));
						t.valueHelpRegion.setModel(new sap.ui.model.json.JSONModel({
							RegionCustomizing: r.results
						}));
						t.regionReadRunning = false;
						for (var i in t.aRegionCallback) t.aRegionCallback[i].call(t);
					}, function(e) {
						jQuery.sap.log.error("Read failed in GeneralDateEdit->_readRegions: " + e.response.body);
						t.regionReadRunning = false;
					});
				},
				_toggleAddressFields: function() {
					var c = this.byId(sap.ui.core.Fragment.createId(this.addressFragment, "MainAddress.countryIDInput")).getValue();
					if (c && c !== "") {
						this._setAddressFieldsEnabled(true, false);
					} else {
						this._setAddressFieldsEnabled(false, false);
					}
				},
				_setAddressFieldsEnabled: function(e, a) {
					var A = this.getView().byId(this.addressForm);
					if (!A) return;
					var f = A.getFormElements();
					var v = this.getView().getId();
					for (var i in f) {
						var F = f[i].getFields();
						for (var z in F) {
							var r = new RegExp(v + "--" + this.addressFragment + "--MainAddress.[A-z0-9]+Input", "g");
							var b = F[z].getId();
							if (b === v + "--" + this.addressFragment + "--MainAddress.countryInput") continue;
							if (r.test(b)) {
								F[z].setEnabled(e);
								if (a) F[z].setValue("");
							}
						}
					}
				},
				_setEmployeeResponsible: function(e, a) {
					var b = this.getView().byId("EmployeeResponsibleRel.account2FullNameInput");
					if (b) b.setValue(a);
					var c = this.getView().byId("EmployeeResponsibleRel.account2IDInput");
					if (c) c.setValue(e);
				},
				onEmployeeResponsibleValueHelpSelected: function() {
					if (!this.valueHelpEmployeeResponsible) {
						this.valueHelpEmployeeResponsible = sap.ui.xmlfragment("cus.crm.myaccounts.view.maintain.ValueHelpEmployeeResponsible", this);
						this.valueHelpEmployeeResponsible.setModel(this.getView().getModel("i18n"), "i18n");
						this.valueHelpEmployeeResponsible.setModel(this.oDataModel);
					} else {
						this.valueHelpEmployeeResponsible.setModel(this.oDataModel);
					}
					this.valueHelpEmployeeResponsible.open();
				},
				onEmployeeResponsibleValueHelpClose: function(e) {
					var s = e.getParameter("selectedItem");
					if (s) {
						var S = s.getBindingContext().getObject();
						this._setEmployeeResponsible(S.employeeID, S.fullName);
					}
					if (e.getSource().getBinding("items").aFilters.length) {
						e.getSource().destroyItems();
						this.valueHelpEmployeeResponsible.setModel(null);
					}
				},
				onEmployeeResponsibleValueHelpSearch: function(e) {
					var s = e.getParameter("value");
					var f = new sap.ui.model.Filter("fullName", sap.ui.model.FilterOperator.Contains, s);
					e.getSource().getBinding("items").filter([f]);
				},
				onEmployeeResponsibleValueHelpCancel: function(e) {
					if (e.getSource().getBinding("items").aFilters.length) {
						e.getSource().destroyItems();
						this.valueHelpEmployeeResponsible.setModel(null);
					}
				},
				onEmployeeResponsibleSuggestItemSelected: function(e) {
					var I = e.getParameter("selectedItem");
					var a = null;
					for (var i in I.getCustomData()) {
						var c = I.getCustomData()[i];
						if (c.getKey() === "employeeID") a = c.getValue();
					}
					this._setEmployeeResponsible(a, I.getText());
				},
				onEmployeeResponsibleInputFieldChanged: function(e) {
					this.onInputFieldChanged();
					var a = e.getSource();
					this._setEmployeeResponsible("", a.getValue());
					a.setFilterSuggests(false);
					var c = function(E) {
						a.removeAllSuggestionItems();
						for (var i = 0; i < E.length; i++) {
							var o = E[i];
							if (o.fullName.toUpperCase() === a.getValue().toUpperCase()) {
								this._setEmployeeResponsible(o.employeeID, o.fullName);
							}
							var C = new sap.ui.core.CustomData({
								key: "employeeID",
								value: o.employeeID
							});
							var I = new sap.ui.core.Item({
								text: o.fullName,
								customData: C
							});
							a.addSuggestionItem(I);
						}
					};
					this._readEmployeeResponsible(a.getValue(), c);
				},
				_readEmployeeResponsible: function(s, c) {
					var t = this;
					var d = (s ? 500 : 0);
					window.clearTimeout(this.liveChangeTimer);
					if (d) {
						this.liveChangeTimer = window.setTimeout(function() {
							t.oDataModel.read("/EmployeeCollection", null, '$top=10&$filter=substringof(%27' + encodeURIComponent(s) + '%27,fullName)',
								true,
								function(D) {
									var e = jQuery.parseJSON(JSON.stringify(D));
									if (c) c.call(t, e.results);
								},
								function(e) {
									jQuery.sap.log.error("Read failed in GeneralDateEdit->_readEmployeeResponsible:" + e.response.body);
								});
						}, d);
					}
				},
				onCountryValueHelpSelected: function() {
					if (!this.valueHelpCountry) {
						this._createValueHelpCountry();
						this._readCountries();
					}
					this.valueHelpCountry.open();
				},
				_createValueHelpCountry: function() {
					if (!this.valueHelpCountry) {
						this.valueHelpCountry = sap.ui.xmlfragment("cus.crm.myaccounts.view.maintain.ValueHelpCountry", this);
						this.valueHelpCountry.setModel(this.getView().getModel("i18n"), "i18n");
					}
				},
				onCountryValueHelpSearch: function(e) {
					var s = e.getParameter("value");
					var f = new sap.ui.model.Filter("country", sap.ui.model.FilterOperator.Contains, s);
					e.getSource().getBinding("items").filter([f]);
				},
				onCountryValueHelpClose: function(e) {
					var s = e.getParameter("selectedItem");
					if (s) {
						var S = s.getBindingContext().getObject();
						this._setCountry(S.countryID, S.country);
					}
					e.getSource().getBinding("items").filter([]);
				},
				onCountryValueHelpCancel: function(e) {
					e.getSource().getBinding("items").filter([]);
				},
				onRegionValueHelpSelected: function() {
					if (!this.valueHelpRegion) {
						this._createValueHelpRegion();
					}
					this._readRegions();
					this.valueHelpRegion.open();
				},
				_createValueHelpRegion: function() {
					if (!this.valueHelpRegion) {
						this.valueHelpRegion = sap.ui.xmlfragment("cus.crm.myaccounts.view.maintain.ValueHelpRegion", this);
						this.valueHelpRegion.setModel(this.getView().getModel("i18n"), "i18n");
					}
				},
				onRegionValueHelpSearch: function(e) {
					var s = e.getParameter("value");
					var f = new sap.ui.model.Filter("region", sap.ui.model.FilterOperator.Contains, s);
					e.getSource().getBinding("items").filter([f]);
				},
				onRegionValueHelpClose: function(e) {
					var s = e.getParameter("selectedItem");
					if (s) {
						var S = s.getBindingContext().getObject();
						this._setRegion(S.regionID, S.region);
					}
					e.getSource().getBinding("items").filter([]);
				},
				onRegionValueHelpCancel: function(e) {
					e.getSource().getBinding("items").filter([]);
				},
				onCountrySuggest: function(e) {
					var c = e.getSource();
					var d = function() {
						var m = this.valueHelpCountry.getModel();
						if (c.getSuggestionItems().length > 0) return;
						var C = m.getProperty("/CountryCustomizing");
						for (var i = 0; i < C.length; i++) {
							var o = C[i];
							var a = new sap.ui.core.CustomData({
								key: "countryID",
								value: o.countryID
							});
							var I = new sap.ui.core.Item({
								text: o.country,
								customData: a
							});
							c.addSuggestionItem(I);
						}
					};
					if (!this.valueHelpCountry) {
						this._createValueHelpCountry();
						this._readCountries(d);
					} else {
						d.call(this);
					}
				},
				onCountrySuggestItemSelected: function(e) {
					var I = e.getParameter("selectedItem");
					var c = null;
					for (var i in I.getCustomData()) {
						var C = I.getCustomData()[i];
						if (C.getKey() === "countryID") c = C.getValue();
					}
					this._setCountry(c, I.getText());
				},
				onCountryInputFieldChanged: function(e) {
					this.onInputFieldChanged();
					var c = e.getSource();
					this._setCountry("", c.getValue());
					var C = function() {
						var m = this.valueHelpCountry.getModel();
						var a = m.getProperty("/CountryCustomizing");
						for (var i = 0; i < a.length; i++) {
							var o = a[i];
							if (o.country.toUpperCase() === c.getValue().toUpperCase()) this._setCountry(o.countryID, c.getValue());
						}
					};
					if (!this.valueHelpCountry) {
						this._createValueHelpCountry();
						this._readCountries(C);
					} else {
						C.call(this);
					}
				},
				onRegionSuggest: function(e) {
					var r = e.getSource();
					var d = function() {
						if (this.countryIDUsedForRegionSuggestion === this.countryIDUsedForRegion) return;
						this.countryIDUsedForRegionSuggestion = this.countryIDUsedForRegion;
						var m = this.valueHelpRegion.getModel();
						var R = m.getProperty("/RegionCustomizing");
						r.removeAllSuggestionItems();
						for (var i = 0; i < R.length; i++) {
							var o = R[i];
							var c = new sap.ui.core.CustomData({
								key: "regionID",
								value: o.regionID
							});
							var I = new sap.ui.core.Item({
								text: o.region,
								customData: c
							});
							r.addSuggestionItem(I);
						}
					};
					if (!this.valueHelpRegion) this._createValueHelpRegion();
					this._readRegions(d);
				},
				onRegionSuggestItemSelected: function(e) {
					var I = e.getParameter("selectedItem");
					var r = null;
					for (var i in I.getCustomData()) {
						var c = I.getCustomData()[i];
						if (c.getKey() === "regionID") r = c.getValue();
					}
					this._setRegion(r, I.getText());
				},
				onRegionInputFieldChanged: function(e) {
					this.onInputFieldChanged();
					var r = e.getSource();
					this._setRegion("", r.getValue());
					var c = function() {
						var m = this.valueHelpRegion.getModel();
						var R = m.getProperty("/RegionCustomizing");
						for (var i = 0; i < R.length; i++) {
							var o = R[i];
							if (o.region.toUpperCase() === r.getValue().toUpperCase()) {
								this._setRegion(o.regionID, r.getValue());
							}
						}
					};
					if (!this.valueHelpRegion) {
						this._createValueHelpRegion();
						this._readRegions(c);
					} else {
						c.call(this);
					}
				},
				onName1InputFieldChanged: function() {
					var a = this.getView().getBindingContext().getObject();
					if (a.category === cus.crm.myaccounts.util.Constants.accountCategoryPerson) this.byId(sap.ui.core.Fragment.createId(
						"personFragment", "name1Input")).setValueState(sap.ui.core.ValueState.None);
					else this.byId(sap.ui.core.Fragment.createId("companyFragment", "name1Input")).setValueState(sap.ui.core.ValueState.None);
				},
				_readCustomizing: function(c) {
					var t = this;
					var a = function(r) {
						var A = r["CustomizingAcademicTitleCollection"];
						if (A) {
							A.unshift({
								title: "",
								titleDescription: ""
							});
							t.customizingModel.setProperty("/AcademicTitleCustomizing", A);
						}
						var T = r["CustomizingTitleCollection"];
						if (T) {
							T.unshift({
								title: "",
								titleDescription: "",
								person: "X",
								organization: "X",
								group: "X"
							});
							t.customizingModel.setProperty("/TitleCustomizing", T);
						}
						var R = r["CustomizingRatingCollection"];
						if (R) {
							R.unshift({
								ratingID: "",
								ratingText: ""
							});
							t.customizingModel.setProperty("/RatingCustomizing", R);
						}
						var d = r["EmployeeCollection?$filter=isDefaultEmployee%20eq%20true"][0];
						if (d) t.customizingModel.setProperty("/DefaultEmployeeResponsible", d);
						else t.customizingModel.setProperty("/DefaultEmployeeResponsible", {
							fullName: "",
							employeeID: ""
						});
						if (c) c.call(t);
					};
					cus.crm.myaccounts.util.Util.sendBatchReadRequests(this.oDataModel, ["CustomizingTitleCollection",
						"CustomizingAcademicTitleCollection", "CustomizingRatingCollection",
						"EmployeeCollection?$filter=isDefaultEmployee%20eq%20true"
					], a, a);
				},
				_refreshDropDownBoxes: function() {
					var d = this._getIDForDropDownBoxes();
					for (var i in d) {
						var D = this.byId(this.getView().getId() + "--" + d[i]);
						if (D) {
							var b = D.getBinding("selectedKey");
							if (b) {
								D.bindProperty("selectedKey", b.sPath);
							}
						}
					}
				},
				_getIDForDropDownBoxes: function() {
					return ["personFragment--academicTitleIDInput", "personFragment--titleIDInput", "Classification.ratingIDInput"];
				},
				getHeaderFooterOptions: function() {
					var t = this;
					return {
						sI18NFullscreenTitle: "DETAIL_TITLE",
						buttonList: [{
							sI18nBtnTxt: "BUTTON_SAVE",
							sId: "saveButton",
							onBtnPressed: jQuery.proxy(this.onSaveButtonPressed, this),
							bDisabled: "true"
						}, {
							sI18nBtnTxt: "BUTTON_CANCEL",
							sId: "cancelButton",
							onBtnPressed: jQuery.proxy(this.onCancelButtonPressed, this)
						}],
						onBack: function() {
							t.onBackButtonPressed();
						}
					};
				},
				_setDefaultEmployeeResponsible: function() {
					if (!this.editMode && this.customizingModel.getProperty('/DefaultEmployeeResponsible/employeeID')) {
						var e = this.customizingModel.getProperty('/DefaultEmployeeResponsible/employeeID');
						var a = this.customizingModel.getProperty('/DefaultEmployeeResponsible/fullName');
						var A = this.getView().getBindingContext();
						var m = this.getView().getModel();
						if (A.getProperty("EmployeeResponsibleRel")) {
							m.setProperty(A.sPath + "/EmployeeResponsibleRel/account2ID", e);
							m.setProperty(A.sPath + "/EmployeeResponsibleRel/account2FullName", a);
						}
						this._setEmployeeResponsible(e, a);
					}
				}
			});
		},
		"cus/crm/myaccounts/view/maintain/GeneralDataEdit.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core" xmlns:mvc="sap.ui.core.mvc" xmlns="sap.m" xmlns:layout="sap.ui.layout" xmlns:form="sap.ui.layout.form"\n\t\t\tcontrollerName="cus.crm.myaccounts.view.maintain.GeneralDataEdit" xmlns:html="http://www.w3.org/1999/xhtml" id="editView">\n\t<Page showNavButton="true">\n\t\t<content>\n\t\t\t<layout:Grid defaultSpan="L12 M12 S12" width="auto">\n\t\t\t\t<layout:content>\n\t\t\t\t\t<!-- Extends the view by a form -->\n\t\t\t\t\t<core:ExtensionPoint name="extEditForm">\n\t\t\t\t\t\t<form:Form class="sapUiFormEdit sapUiFormEdit-CTX">\n\t\t\t\t\t\t\t<form:layout>\n\t\t\t\t\t\t\t\t<form:ResponsiveGridLayout xmlns:form="sap.ui.layout.form"\n\t\t\t\t\t\t\t\t\tlabelSpanL="4"\n\t\t\t\t\t\t\t\t\tlabelSpanM="4"\n\t\t\t\t\t\t\t\t\temptySpanL="3"\n\t\t\t\t\t\t\t\t\temptySpanM="2"\n\t\t\t\t\t\t\t\t\tcolumnsL="1"\n\t\t\t\t\t\t\t\t\tcolumnsM="1"\n\t\t\t\t\t\t\t\t\tclass="editableForm">\n\t\t\t\t\t\t\t\t</form:ResponsiveGridLayout>\n\t\t\t\t\t\t\t</form:layout>\n\t\t\t\t\t\t\t<form:formContainers>\n\t\t\t\t\t\t\t\t<form:FormContainer />\n\t\t\t\t\t\t\t\t<!-- Extends the form at the top -->\n\t\t\t\t\t\t\t\t<core:ExtensionPoint name="extEditFormTop"/>\n\t\t\t\t\t\t\t\t<form:FormContainer id="editFormCompany" title="{i18n>GENERAL_DATA}" visible="{parts:[\'category\', \'constants>/accountCategoryPerson\'], formatter: \'cus.crm.myaccounts.util.formatter.isUnequal\'}">\n\t\t\t\t\t\t\t\t\t<form:formElements >\n\t\t\t\t\t\t\t\t\t\t<core:Fragment id="companyFragment" fragmentName="cus.crm.myaccounts.view.maintain.GeneralDataEditCompany" type="XML" />\n\t\t\t\t\t\t\t\t\t</form:formElements>\n\t\t\t\t\t\t\t\t</form:FormContainer>\n\t\t\t\t\t\t\t\t<form:FormContainer id="editFormPerson" title="{i18n>GENERAL_DATA}" visible="{parts:[\'category\', \'constants>/accountCategoryPerson\'], formatter: \'cus.crm.myaccounts.util.formatter.isEqual\'}">\n\t\t\t\t\t\t\t\t\t<form:formElements >\n\t\t\t\t\t\t\t\t\t\t<core:Fragment id="personFragment" fragmentName="cus.crm.myaccounts.view.maintain.GeneralDataEditPerson" type="XML" />\n\t\t\t\t\t\t\t\t\t</form:formElements>\n\t\t\t\t\t\t\t\t</form:FormContainer>\n\n\t\t\t\t\t\t\t\t<form:FormContainer id="editFormRating">\n\t\t\t\t\t\t\t\t\t<form:formElements >\n\t\t\t\t\t\t\t\t\t\t<form:FormElement id="Classification.ratingID">\n\t\t\t\t\t\t\t\t\t\t\t<form:label>\n\t\t\t\t\t\t\t\t\t\t\t\t<Label text="{i18n>RATING}" id="Classification.ratingIDLabel" width="100%" />\n\t\t\t\t\t\t\t\t\t\t\t</form:label>\n\t\t\t\t\t\t\t\t\t\t\t<form:fields>\n\t\t\t\t\t\t\t\t\t\t\t\t<Select value="{Classification/ratingID}" maxLength="40" id="Classification.ratingIDInput" change="onInputFieldChanged" items="{Customizing>/RatingCustomizing}" selectedKey="{Classification/ratingID}">\n\t\t\t\t\t\t\t\t\t\t\t\t\t<core:Item key="{Customizing>ratingID}" text="{Customizing>ratingText}"/>\n\t\t\t\t\t\t\t\t\t\t\t\t</Select>\n\t\t\t\t\t\t\t\t\t\t\t</form:fields>\n\t\t\t\t\t\t\t\t\t\t</form:FormElement>\n\t\t\t\t\t\t\t\t\t</form:formElements>\n\t\t\t\t\t\t\t\t</form:FormContainer>\n\n\t\t\t\t\t\t\t\t<form:FormContainer id="editFormEmployee">\n\t\t\t\t\t\t\t\t\t<form:formElements>\n\t\t\t\t\t\t\t\t\t\t<form:FormElement id="EmployeeResponsibleRel.employee">\n\t\t\t\t\t\t\t\t\t\t\t<form:label>\n\t\t\t\t\t\t\t\t\t\t\t\t<Label text="{i18n>EMPLOYEE_RESPONSIBLE}" id="EmployeeResponsibleRel.employeeLabel"  width="100%" visible="true"/>\n\t\t\t\t\t\t\t\t\t\t\t</form:label>\n\t\t\t\t\t\t\t\t\t\t\t<form:fields>\n\t\t\t\t\t\t\t\t\t\t\t\t<Input\n\t\t\t\t\t\t\t\t\t\t\t\t\tid="EmployeeResponsibleRel.account2FullNameInput"\n\t\t\t\t\t\t\t\t\t\t\t\t\tvalue="{EmployeeResponsibleRel/account2FullName}"\n\t\t\t\t\t\t\t\t\t\t\t\t\ttype="Text"\n\t\t\t\t\t\t\t\t\t\t\t\t\tplaceholder=""\n\t\t\t\t\t\t\t\t\t\t\t\t\tenabled="true"\n\t\t\t\t\t\t\t\t\t\t\t\t\teditable="true"\n\t\t\t\t\t\t\t\t\t\t\t\t\tshowValueHelp="true"\n\t\t\t\t\t\t\t\t\t\t\t\t\tvalueHelpOnly="false"\n\t\t\t\t\t\t\t\t\t\t\t\t\tvalueHelpRequest="onEmployeeResponsibleValueHelpSelected"\n\t\t\t\t\t\t\t\t\t\t\t\t\tshowSuggestion = "true"\n\t\t\t\t\t\t\t\t\t\t\t\t\tsuggestionItemSelected = "onEmployeeResponsibleSuggestItemSelected"\n\t\t\t\t\t\t\t\t\t\t\t\t\tliveChange="onEmployeeResponsibleInputFieldChanged"\n\t\t\t\t\t\t\t\t\t\t\t\t\tvisible="true"/>\n\t\t\t\t\t\t\t\t\t\t\t</form:fields>\n\t\t\t\t\t\t\t\t\t\t</form:FormElement>\n\t\t\t\t\t\t\t\t\t\t<form:FormElement id="EmployeeResponsibleRel.account2ID">\n\t\t\t\t\t\t\t\t\t\t\t<form:fields>\n\t\t\t\t\t\t\t\t\t\t\t\t<Input id="EmployeeResponsibleRel.account2IDInput" value="{EmployeeResponsibleRel/account2ID}" type="Text" visible="false"/>\n\t\t\t\t\t\t\t\t\t\t\t</form:fields>\n\t\t\t\t\t\t\t\t\t\t</form:FormElement>\n\t\t\t\t\t\t\t\t\t</form:formElements>\n\t\t\t\t\t\t\t\t</form:FormContainer>\n\n\t\t\t\t\t\t\t\t<!-- Extends the form in the middle -->\n\t\t\t\t\t\t\t\t<core:ExtensionPoint name="extEditFormMiddle"/>\n\t\t\t\t\t\t\t</form:formContainers>\n\t\t\t\t\t\t</form:Form>\n\t\t\t\t\t\t<form:Form class="sapUiFormEdit sapUiFormEdit-CTX">\n\t\t\t\t\t\t\t<form:layout>\n\t\t\t\t\t\t\t\t<form:ResponsiveGridLayout xmlns:form="sap.ui.layout.form"\n\t\t\t\t\t\t\t\t\tlabelSpanL="4"\n\t\t\t\t\t\t\t\t\tlabelSpanM="4"\n\t\t\t\t\t\t\t\t\temptySpanL="3"\n\t\t\t\t\t\t\t\t\temptySpanM="2"\n\t\t\t\t\t\t\t\t\tcolumnsL="1"\n\t\t\t\t\t\t\t\t\tcolumnsM="1"\n\t\t\t\t\t\t\t\t\tclass="editableForm">\n\t\t\t\t\t\t\t\t</form:ResponsiveGridLayout>\n\t\t\t\t\t\t\t</form:layout>\n\t\t\t\t\t\t\t<form:formContainers>\n\t\t\t\t\t\t\t\t<form:FormContainer title="{i18n>ADDRESS}" id="editFormAddress" visible="false">\n\t\t\t\t\t\t\t\t\t<form:formElements>\n\t\t\t\t\t\t\t\t\t\t<core:Fragment id="addressFragment" fragmentName="cus.crm.myaccounts.view.maintain.address.DefaultAddress" type="XML" />\n\t\t\t\t\t\t\t\t\t\t<!-- Extends the address block in the form -->\n\t\t\t\t\t\t\t\t\t\t<core:ExtensionPoint name="extEditFormAddress"/>\n\t\t\t\t\t\t\t\t\t</form:formElements>\n\t\t\t\t\t\t\t\t</form:FormContainer>\n\n\t\t\t\t\t\t\t\t<form:FormContainer title="{i18n>ADDRESS}" id="editFormAddressUS" visible="false">\n\t\t\t\t\t\t\t\t\t<form:formElements>\n\t\t\t\t\t\t\t\t\t\t<core:Fragment id="addressFragmentUS" fragmentName="cus.crm.myaccounts.view.maintain.address.USAddress" type="XML" />\n\t\t\t\t\t\t\t\t\t</form:formElements>\n\t\t\t\t\t\t\t\t</form:FormContainer>\n\n\t\t\t\t\t\t\t\t<form:FormContainer title="{i18n>ADDRESS}" id="editFormAddressJP" visible="false">\n\t\t\t\t\t\t\t\t\t<form:formElements>\n\t\t\t\t\t\t\t\t\t\t<core:Fragment id="addressFragmentJP" fragmentName="cus.crm.myaccounts.view.maintain.address.JPAddress" type="XML" />\n\t\t\t\t\t\t\t\t\t</form:formElements>\n\t\t\t\t\t\t\t\t</form:FormContainer>\n\n\t\t\t\t\t\t\t\t<form:FormContainer title="{i18n>ADDRESS}" id="editFormAddressGB" visible="false">\n\t\t\t\t\t\t\t\t\t<form:formElements>\n\t\t\t\t\t\t\t\t\t\t<core:Fragment id="addressFragmentGB" fragmentName="cus.crm.myaccounts.view.maintain.address.GBAddress" type="XML" />\n\t\t\t\t\t\t\t\t\t</form:formElements>\n\t\t\t\t\t\t\t\t</form:FormContainer>\n\n\t\t\t\t\t\t\t\t<!-- Extends the form at the bottom -->\n\t\t\t\t\t\t\t\t<core:ExtensionPoint name="extEditFormBottom"/>\n\t\t\t\t\t\t\t</form:formContainers>\n\t\t\t\t\t\t</form:Form>\n\t\t\t\t\t</core:ExtensionPoint>\n\t\t\t\t</layout:content>\n\t\t\t</layout:Grid>\n\t\t</content>\n\t</Page>\n</core:View>\n',
		"cus/crm/myaccounts/view/maintain/GeneralDataEditCompany.fragment.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:FragmentDefinition\n  xmlns="sap.m"\n  xmlns:core="sap.ui.core"\n  xmlns:form="sap.ui.layout.form">\n\t\n\t<form:FormElement id="name1" visible="{parts:[\'category\', \'constants>/accountCategoryPerson\'], formatter: \'cus.crm.myaccounts.util.formatter.isUnequal\'}">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>COMPANY_NAME1}" id="name1Label" width="100%" required="true" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{name1}" maxLength="40" id="name1Input" liveChange="onName1InputFieldChanged"/>\n\t\t</form:fields>\n\t</form:FormElement>\n\t<form:FormElement id="name2" visible="{parts:[\'category\', \'constants>/accountCategoryPerson\'], formatter: \'cus.crm.myaccounts.util.formatter.isUnequal\'}">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>COMPANY_NAME2}" id="name2Label" width="100%"/>\n  \t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{name2}" maxLength="40" id="name2Input" liveChange="onInputFieldChanged"/>\n   \t\t</form:fields>\n\t</form:FormElement>\n\n\t<!-- Extends the form -->\n   \t<core:ExtensionPoint name="extEditFormCompany"/>\n   \n</core:FragmentDefinition>',
		"cus/crm/myaccounts/view/maintain/GeneralDataEditPerson.fragment.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:FragmentDefinition\n  xmlns="sap.m"\n  xmlns:core="sap.ui.core"\n  xmlns:layout="sap.ui.layout"\n  xmlns:form="sap.ui.layout.form">\n  \n\t<form:FormElement id="title" visible="{parts:[\'category\', \'constants>/accountCategoryPerson\'], formatter: \'cus.crm.myaccounts.util.formatter.isEqual\'}">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>TITLE}" id="titleLabel" width="100%" />\n   \t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Select \n\t\t\t\tvalue="{titleID}" \n\t\t\t\tmaxLength="40" \n\t\t\t\tid="titleIDInput" \n\t\t\t\tchange="onInputFieldChanged" \n\t\t\t\titems="{path:\'Customizing>/TitleCustomizing\', filters:[{path:\'person\', operator: \'EQ\', value1: \'X\' }] }" \n\t\t\t\tselectedKey="{titleID}">\n\t\t   \t\t<core:Item key="{Customizing>title}" text="{Customizing>titleDescription}"/>\n\t\t   \t</Select>\n   \t\t</form:fields>\n\t</form:FormElement>\n\t\n\t<form:FormElement id="academicTitle" visible="{parts:[\'category\', \'constants>/accountCategoryPerson\'], formatter: \'cus.crm.myaccounts.util.formatter.isEqual\'}">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>ACADEMIC_TITLE}" id="academicTitleLabel" width="100%"/>\n   \t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Select value="{academicTitleID}" maxLength="40" id="academicTitleIDInput" change="onInputFieldChanged" items="{Customizing>/AcademicTitleCustomizing}" selectedKey="{academicTitleID}">\n\t\t       \t<core:Item key="{Customizing>title}" text="{Customizing>titleDescription}"/>\n\t\t   \t</Select>\n   \t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="name2" visible="{parts:[\'category\', \'constants>/accountCategoryPerson\'], formatter: \'cus.crm.myaccounts.util.formatter.isEqual\'}">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>FIRST_NAME}" id="name2Label" width="100%" />\n   \t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{name2}" maxLength="40" id="name2Input" liveChange="onInputFieldChanged" />\n   \t\t</form:fields>\n\t</form:FormElement>  \n  \t\n\t<form:FormElement id="name1" visible="{parts:[\'category\', \'constants>/accountCategoryPerson\'], formatter: \'cus.crm.myaccounts.util.formatter.isEqual\'}">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>LAST_NAME}" id="name1Label" width="100%" required="true" />\n   \t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{name1}" maxLength="40" id="name1Input" liveChange="onName1InputFieldChanged" />\n   \t\t</form:fields>\n\t</form:FormElement>   \n\t\n\t<form:FormElement id="birthDate" visible="{parts:[\'category\', \'constants>/accountCategoryPerson\'], formatter: \'cus.crm.myaccounts.util.formatter.isEqual\'}">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>BIRTHDAY}" id="birthDateLabel" width="100%" />\n   \t\t</form:label>\n\t\t<form:fields>\n\t\t\t<DatePicker value="{path:\'birthDate\', type:\'sap.ui.model.type.Date\', formatOptions: { style: \'medium\'}}" id="birthDateInput" change="onInputFieldChanged" displayFormat="medium"/>\n   \t\t</form:fields>\n\t</form:FormElement> \t                     \t\n\n\t<!-- Extends the form -->\n   \t<core:ExtensionPoint name="extEditFormPerson"/>\n   \t\n</core:FragmentDefinition>',
		"cus/crm/myaccounts/view/maintain/ValueHelpCountry.fragment.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:FragmentDefinition\n  xmlns="sap.m"\n  xmlns:core="sap.ui.core"\n  xmlns:layout="sap.ui.layout">\n  \n  <SelectDialog\n  \ttitle="{i18n>COUNTRY}"\n    class="sapUiPopupWithPadding"\n    items="{/CountryCustomizing}"\n    liveChange="onCountryValueHelpSearch"\n    confirm="onCountryValueHelpClose"\n    cancel="onCountryValueHelpCancel">\n    <StandardListItem\n      title="{country}"\n      />\n  </SelectDialog>\n   \n</core:FragmentDefinition>',
		"cus/crm/myaccounts/view/maintain/ValueHelpEmployeeResponsible.fragment.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:FragmentDefinition\n  xmlns="sap.m"\n  xmlns:core="sap.ui.core"\n  xmlns:layout="sap.ui.layout">\n  \n  <SelectDialog\n  \ttitle="{i18n>EMPLOYEE_RESPONSIBLE}"\n    class="sapUiPopupWithPadding"\n    items="{/EmployeeCollection}"    \n    liveChange="onEmployeeResponsibleValueHelpSearch"\n    confirm="onEmployeeResponsibleValueHelpClose"\n    cancel="onEmployeeResponsibleValueHelpCancel">\n    <StandardListItem\n      title="{fullName}"\n      />\n  </SelectDialog>\n   \n</core:FragmentDefinition>',
		"cus/crm/myaccounts/view/maintain/ValueHelpMarketingAttribute.fragment.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:FragmentDefinition\n  xmlns="sap.m"\n  xmlns:core="sap.ui.core"\n  xmlns:layout="sap.ui.layout">\n  \n  <SelectDialog\n  \ttitle="{i18n>MARKETINGATTRIBUTES}"\n  \tnoDataText="{i18n>NO_DATA_TEXT}"\n    class="sapUiPopupWithPadding"\n    liveChange="onMarketingAttributeValueHelpSearch"\n    confirm="onMarketingAttributeValueHelpClose"\n    cancel="onMarketingAttributeValueHelpCancel">\n    <StandardListItem\n      title="{attribute}"\n    />\n  </SelectDialog>\n</core:FragmentDefinition>',
		"cus/crm/myaccounts/view/maintain/ValueHelpMarketingAttributeSet.fragment.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:FragmentDefinition\n  xmlns="sap.m"\n  xmlns:core="sap.ui.core"\n  xmlns:layout="sap.ui.layout">\n  \n  <SelectDialog\n  \ttitle="{i18n>ATTRIBUTESET}"\n  \tnoDataText="{i18n>NO_DATA_TEXT}"\n    class="sapUiPopupWithPadding"\n    liveChange="onMarketingAttributeSetValueHelpSearch"\n    confirm="onMarketingAttributeSetValueHelpClose"\n    cancel="onMarketingAttributeSetValueHelpCancel">\n    <StandardListItem\n \t\ttitle="{attributeSet}"\n    />\n  </SelectDialog>\n   \n</core:FragmentDefinition>',
		"cus/crm/myaccounts/view/maintain/ValueHelpRegion.fragment.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:FragmentDefinition\n  xmlns="sap.m"\n  xmlns:core="sap.ui.core"\n  xmlns:layout="sap.ui.layout">\n  \n  <SelectDialog\n  \ttitle="{i18n>REGION}"\n    class="sapUiPopupWithPadding"\n    items="{/RegionCustomizing}"\n    liveChange="onRegionValueHelpSearch"\n    confirm="onRegionValueHelpClose"\n    cancel="onRegionValueHelpCancel">\n    <StandardListItem\n      title="{region}"\n      />\n  </SelectDialog>\n   \n</core:FragmentDefinition>',
		"cus/crm/myaccounts/view/maintain/address/DefaultAddress.fragment.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:FragmentDefinition\n\txmlns="sap.m"\n\txmlns:core="sap.ui.core"\n\txmlns:form="sap.ui.layout.form"\n\txmlns:layout="sap.ui.layout">\n\n\t<form:FormElement id="MainAddress.country">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>COUNTRY}" id="MainAddress.countryLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input\n\t\t        id="MainAddress.countryInput"\n\t\t        value="{MainAddress/country}"\n\t\t        type="Text"\n\t\t        placeholder=""\n\t\t        enabled="true"\n\t\t        editable="true"\n\t\t        showValueHelp="true"\n\t\t        valueHelpOnly="false"\n\t\t        valueHelpRequest="onCountryValueHelpSelected"\n\t\t        showSuggestion = "true"\n\t\t        suggest="onCountrySuggest"\n\t\t\t    suggestionItemSelected = "onCountrySuggestItemSelected"\n\t\t\t    liveChange="onCountryInputFieldChanged"/>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.countryID">\n\t\t<form:fields>\n\t\t\t<Input id="MainAddress.countryIDInput" value="{MainAddress/countryID}" type="Text" visible="false"/>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.region">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>REGION}" id="MainAddress.regionLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input\n\t\t        id="MainAddress.regionInput"\n\t\t        value="{MainAddress/region}"\n\t\t        type="Text"\n\t\t        placeholder=""\n\t\t        editable="true"\n\t\t        showValueHelp="true"\n\t\t        valueHelpOnly="false"\n\t\t        valueHelpRequest="onRegionValueHelpSelected"\n\t\t        showSuggestion = "true"\n\t\t        suggest="onRegionSuggest"\n\t\t        suggestionItemSelected = "onRegionSuggestItemSelected"\n\t\t        liveChange="onRegionInputFieldChanged"/>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.regionID">\n\t\t<form:fields>\n\t\t\t<Input id="MainAddress.regionIDInput" value="{MainAddress/regionID}" type="Text" visible="false"/>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.street">\n\t\t<form:label>\n\t\t\t<Label text="{parts:[{path:\'i18n>STREET\'},{path:\'i18n>HOUSE_NUMBER\'}], formatter: \'cus.crm.myaccounts.util.formatter.sleshSeparator\'}" id="MainAddress.streetLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/street}" maxLength="40" id="MainAddress.streetInput" liveChange="onInputFieldChanged">\n\t\t\t\t<layoutData>\n\t\t\t\t\t<layout:GridData span="L4 M4 S9"/>\n\t\t\t\t</layoutData>\n\t\t\t</Input>\n\t\t\t<Input value="{MainAddress/houseNumber}" maxLength="40" id="MainAddress.houseNumberInput" liveChange="onInputFieldChanged">\n\t\t\t\t<layoutData>\n\t\t\t\t\t<layout:GridData span="L1 M2 S3"/>\n\t\t\t\t</layoutData>\n\t\t\t</Input>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.postcode">\n\t\t<form:label>\n\t\t\t<Label text="{parts:[{path:\'i18n>POSTAL_CODE\'},{path:\'i18n>CITY\'}], formatter: \'cus.crm.myaccounts.util.formatter.sleshSeparator\'}" id="MainAddress.postcodeLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/postcode}" maxLength="40" id="MainAddress.postcodeInput" liveChange="onInputFieldChanged">\n\t\t\t\t<layoutData>\n\t\t\t\t\t<layout:GridData span="L1 M2 S5"/>\n\t\t\t\t</layoutData>\n\t\t\t</Input>\n\t\t\t<Input value="{MainAddress/city}" maxLength="40" id="MainAddress.cityInput" liveChange="onInputFieldChanged">\n\t\t\t\t<layoutData>\n\t\t\t\t\t<layout:GridData span="L4 M4 S7"/>\n\t\t\t\t</layoutData>\n\t\t\t</Input>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.mobilePhone" visible="{parts:[\'category\', \'constants>/accountCategoryPerson\'], formatter: \'cus.crm.myaccounts.util.formatter.isEqual\'}">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>MOBILE}" id="MainAddress.mobilePhoneLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/mobilePhone}" maxLength="40" id="MainAddress.mobilePhoneInput" liveChange="onInputFieldChanged"/>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.phone">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>PHONE}" id="MainAddress.phoneLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/phone}" maxLength="40" id="MainAddress.phoneInput" liveChange="onInputFieldChanged" />\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.email">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>EMAIL}" id="MainAddress.emailLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/email}" maxLength="40" id="MainAddress.emailInput" liveChange="onInputFieldChanged" />\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.website">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>WEBSITE}" id="MainAddress.websiteLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/website}" maxLength="40" id="MainAddress.websiteInput" liveChange="onInputFieldChanged" />\n\t\t</form:fields>\n\t</form:FormElement>\n\n</core:FragmentDefinition>\n',
		"cus/crm/myaccounts/view/maintain/address/GBAddress.fragment.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:FragmentDefinition\n\txmlns="sap.m"\n\txmlns:core="sap.ui.core"\n\txmlns:form="sap.ui.layout.form"\n\txmlns:layout="sap.ui.layout">\n\n\t<form:FormElement id="MainAddress.country">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>COUNTRY}" id="MainAddress.countryLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input\n\t\t\t\tid="MainAddress.countryInput"\n\t\t\t\tvalue="{MainAddress/country}"\n\t\t\t\ttype="Text"\n\t\t\t\tplaceholder=""\n\t\t\t\tenabled="true"\n\t\t\t\teditable="true"\n\t\t\t\tshowValueHelp="true"\n\t\t\t\tvalueHelpOnly="false"\n\t\t\t\tvalueHelpRequest="onCountryValueHelpSelected"\n\t\t\t\tshowSuggestion = "true"\n\t\t\t\tsuggest="onCountrySuggest"\n\t\t\t\tsuggestionItemSelected = "onCountrySuggestItemSelected"\n\t\t\t\tliveChange="onCountryInputFieldChanged"/>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.countryID">\n\t\t<form:fields>\n\t\t\t<Input id="MainAddress.countryIDInput" value="{MainAddress/countryID}" type="Text" visible="false"/>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.street">\n\t\t<form:label>\n\t\t\t<Label text="{parts:[{path:\'i18n>HOUSE_NUMBER\'},{path:\'i18n>STREET\'}], formatter: \'cus.crm.myaccounts.util.formatter.sleshSeparator\'}" id="MainAddress.streetLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/houseNumber}" maxLength="40" id="MainAddress.houseNumberInput" liveChange="onInputFieldChanged">\n\t\t\t\t<layoutData>\n\t\t\t\t\t<layout:GridData span="L1 M2 S3"/>\n\t\t\t\t</layoutData>\n\t\t\t</Input>\n\t\t\t<Input value="{MainAddress/street}" maxLength="40" id="MainAddress.streetInput" liveChange="onInputFieldChanged">\n\t\t\t\t<layoutData>\n\t\t\t\t\t<layout:GridData span="L4 M4 S9"/>\n\t\t\t\t</layoutData>\n\t\t\t</Input>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.city">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>CITY}" id="MainAddress.cityLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/city}" maxLength="40" id="MainAddress.cityInput" liveChange="onInputFieldChanged">\n\t\t\t\t<layoutData>\n\t\t\t\t\t<layout:GridData span="L5 M5 S7"/>\n\t\t\t\t</layoutData>\n\t\t\t</Input>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.region">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>REGION}" id="MainAddress.regionLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input\n\t\t\t\tid="MainAddress.regionInput"\n\t\t\t\tvalue="{MainAddress/region}"\n\t\t\t\ttype="Text"\n\t\t\t\tplaceholder=""\n\t\t\t\teditable="true"\n\t\t\t\tshowValueHelp="true"\n\t\t\t\tvalueHelpOnly="false"\n\t\t\t\tvalueHelpRequest="onRegionValueHelpSelected"\n\t\t\t\tshowSuggestion = "true"\n\t\t\t\tsuggest="onRegionSuggest"\n\t\t\t\tsuggestionItemSelected = "onRegionSuggestItemSelected"\n\t\t\t\tliveChange="onRegionInputFieldChanged"/>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.regionID">\n\t\t<form:fields>\n\t\t\t<Input id="MainAddress.regionIDInput" value="{MainAddress/regionID}" type="Text" visible="false"/>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.postcode">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>POSTAL_CODE}" id="MainAddress.postcodeLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/postcode}" maxLength="40" id="MainAddress.postcodeInput" liveChange="onInputFieldChanged">\n\t\t\t\t<layoutData>\n\t\t\t\t\t<layout:GridData span="L5 M5 S5"/>\n\t\t\t\t</layoutData>\n\t\t\t</Input>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.mobilePhone" visible="{parts:[\'category\', \'constants>/accountCategoryPerson\'], formatter: \'cus.crm.myaccounts.util.formatter.isEqual\'}">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>MOBILE}" id="MainAddress.mobilePhoneLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/mobilePhone}" maxLength="40" id="MainAddress.mobilePhoneInput" liveChange="onInputFieldChanged"/>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.phone">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>PHONE}" id="MainAddress.phoneLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/phone}" maxLength="40" id="MainAddress.phoneInput" liveChange="onInputFieldChanged" />\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.email">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>EMAIL}" id="MainAddress.emailLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/email}" maxLength="40" id="MainAddress.emailInput" liveChange="onInputFieldChanged" />\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.website">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>WEBSITE}" id="MainAddress.websiteLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/website}" maxLength="40" id="MainAddress.websiteInput" liveChange="onInputFieldChanged" />\n\t\t</form:fields>\n\t</form:FormElement>\n\n</core:FragmentDefinition>',
		"cus/crm/myaccounts/view/maintain/address/JPAddress.fragment.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:FragmentDefinition\n\txmlns="sap.m"\n\txmlns:core="sap.ui.core"\n\txmlns:form="sap.ui.layout.form"\n\txmlns:layout="sap.ui.layout">\n\n\t<form:FormElement id="MainAddress.country">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>COUNTRY}" id="MainAddress.countryLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input\n\t\t\t\tid="MainAddress.countryInput"\n\t\t\t\tvalue="{MainAddress/country}"\n\t\t\t\ttype="Text"\n\t\t\t\tplaceholder=""\n\t\t\t\tenabled="true"\n\t\t\t\teditable="true"\n\t\t\t\tshowValueHelp="true"\n\t\t\t\tvalueHelpOnly="false"\n\t\t\t\tvalueHelpRequest="onCountryValueHelpSelected"\n\t\t\t\tshowSuggestion = "true"\n\t\t\t\tsuggest="onCountrySuggest"\n\t\t\t\tsuggestionItemSelected = "onCountrySuggestItemSelected"\n\t\t\t\tliveChange="onCountryInputFieldChanged"/>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement  id="MainAddress.countryID">\n\t\t<form:fields>\n\t\t\t<Input id="MainAddress.countryIDInput" value="{MainAddress/countryID}" type="Text" visible="false"/>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.street">\n\t\t<form:label>\n\t\t\t<Label text="{parts:[{path:\'i18n>HOUSE_NUMBER\'},{path:\'i18n>STREET\'}], formatter: \'cus.crm.myaccounts.util.formatter.sleshSeparator\'}" id="MainAddress.streetLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/houseNumber}" maxLength="40" id="MainAddress.houseNumberInput" liveChange="onInputFieldChanged">\n\t\t\t\t<layoutData>\n\t\t\t\t\t<layout:GridData span="L1 M2 S3"/>\n\t\t\t\t</layoutData>\n\t\t\t</Input>\n\t\t\t<Input value="{MainAddress/street}" maxLength="40" id="MainAddress.streetInput" liveChange="onInputFieldChanged">\n\t\t\t\t<layoutData>\n\t\t\t\t\t<layout:GridData span="L4 M4 S9"/>\n\t\t\t\t</layoutData>\n\t\t\t</Input>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.city">\n\t\t<form:label>\n\t\t\t<Label text="{parts:[{path:\'i18n>CITY\'},{path:\'i18n>REGION\'}], formatter: \'cus.crm.myaccounts.util.formatter.sleshSeparator\'}" id="MainAddress.cityLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/city}" maxLength="40" id="MainAddress.cityInput" liveChange="onInputFieldChanged">\n\t\t\t\t<layoutData>\n\t\t\t\t\t<layout:GridData span="L3 M3 S7"/>\n\t\t\t\t</layoutData>\n\t\t\t</Input>\n\t\t\t<Input\n\t\t\t\tid="MainAddress.regionInput"\n\t\t\t\tvalue="{MainAddress/region}"\n\t\t\t\ttype="Text"\n\t\t\t\tplaceholder=""\n\t\t\t\teditable="true"\n\t\t\t\tshowValueHelp="true"\n\t\t\t\tvalueHelpOnly="false"\n\t\t\t\tvalueHelpRequest="onRegionValueHelpSelected"\n\t\t\t\tshowSuggestion = "true"\n\t\t\t\tsuggest="onRegionSuggest"\n\t\t\t\tsuggestionItemSelected = "onRegionSuggestItemSelected"\n\t\t\t\tliveChange="onRegionInputFieldChanged"/>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.regionID">\n\t\t<form:fields>\n\t\t\t<Input id="MainAddress.regionIDInput" value="{MainAddress/regionID}" type="Text" visible="false"/>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.postcode">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>POSTAL_CODE}" id="MainAddress.postcodeLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/postcode}" maxLength="40" id="MainAddress.postcodeInput" liveChange="onInputFieldChanged">\n\t\t\t\t<layoutData>\n\t\t\t\t\t<layout:GridData span="L5 M5 S5"/>\n\t\t\t\t</layoutData>\n\t\t\t</Input>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.mobile" visible="{parts:[\'category\', \'constants>/accountCategoryPerson\'], formatter: \'cus.crm.myaccounts.util.formatter.isEqual\'}">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>MOBILE}" id="MainAddress.mobilePhoneLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/mobilePhone}" maxLength="40" id="MainAddress.mobilePhoneInput" liveChange="onInputFieldChanged"/>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.phone">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>PHONE}" id="MainAddress.phoneLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/phone}" maxLength="40" id="MainAddress.phoneInput" liveChange="onInputFieldChanged" />\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.email">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>EMAIL}" id="MainAddress.emailLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/email}" maxLength="40" id="MainAddress.emailInput" liveChange="onInputFieldChanged" />\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.website">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>WEBSITE}" id="MainAddress.websiteLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/website}" maxLength="40" id="MainAddress.websiteInput" liveChange="onInputFieldChanged" />\n\t\t</form:fields>\n\t</form:FormElement>\n\n</core:FragmentDefinition>\n',
		"cus/crm/myaccounts/view/maintain/address/USAddress.fragment.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:FragmentDefinition\n\txmlns="sap.m"\n\txmlns:core="sap.ui.core"\n\txmlns:form="sap.ui.layout.form"\n\txmlns:layout="sap.ui.layout">\n\n\t<form:FormElement id="MainAddress.country">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>COUNTRY}" id="MainAddress.countryLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input\n\t\t\t\tid="MainAddress.countryInput"\n\t\t\t\tvalue="{MainAddress/country}"\n\t\t\t\ttype="Text"\n\t\t\t\tplaceholder=""\n\t\t\t\tenabled="true"\n\t\t\t\teditable="true"\n\t\t\t\tshowValueHelp="true"\n\t\t\t\tvalueHelpOnly="false"\n\t\t\t\tvalueHelpRequest="onCountryValueHelpSelected"\n\t\t\t\tshowSuggestion = "true"\n\t\t\t\tsuggest="onCountrySuggest"\n\t\t\t\tsuggestionItemSelected = "onCountrySuggestItemSelected"\n\t\t\t\tliveChange="onCountryInputFieldChanged"/>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.countryID">\n\t\t<form:fields>\n\t\t\t<Input id="MainAddress.countryIDInput" value="{MainAddress/countryID}" type="Text" visible="false"/>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.street">\n\t\t<form:label>\n\t\t\t<Label text="{parts:[{path:\'i18n>HOUSE_NUMBER\'},{path:\'i18n>STREET\'}], formatter: \'cus.crm.myaccounts.util.formatter.sleshSeparator\'}" id="MainAddress.streetLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/houseNumber}" maxLength="40" id="MainAddress.houseNumberInput" liveChange="onInputFieldChanged">\n\t\t\t\t<layoutData>\n\t\t\t\t\t<layout:GridData span="L1 M2 S3"/>\n\t\t\t\t</layoutData>\n\t\t\t</Input>\n\t\t\t<Input value="{MainAddress/street}" maxLength="40" id="MainAddress.streetInput" liveChange="onInputFieldChanged">\n\t\t\t\t<layoutData>\n\t\t\t\t\t<layout:GridData span="L4 M4 S9"/>\n\t\t\t\t</layoutData>\n\t\t\t</Input>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.city">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>CITY}" id="MainAddress.cityLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/city}" maxLength="40" id="MainAddress.cityInput" liveChange="onInputFieldChanged">\n\t\t\t\t<layoutData>\n\t\t\t\t\t<layout:GridData span="L5 M5 S7"/>\n\t\t\t\t</layoutData>\n\t\t\t</Input>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.region">\n\t\t<form:label>\n\t\t\t<Label text="{parts:[{path:\'i18n>REGION\'},{path:\'i18n>POSTAL_CODE\'}], formatter: \'cus.crm.myaccounts.util.formatter.sleshSeparator\'}" id="MainAddress.postcodeLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input\n\t\t\t\tid="MainAddress.regionInput"\n\t\t\t\tvalue="{MainAddress/region}"\n\t\t\t\ttype="Text"\n\t\t\t\tplaceholder=""\n\t\t\t\teditable="true"\n\t\t\t\tshowValueHelp="true"\n\t\t\t\tvalueHelpOnly="false"\n\t\t\t\tvalueHelpRequest="onRegionValueHelpSelected"\n\t\t\t\tshowSuggestion = "true"\n\t\t\t\tsuggest="onRegionSuggest"\n\t\t\t\tsuggestionItemSelected = "onRegionSuggestItemSelected"\n\t\t\t\tliveChange="onRegionInputFieldChanged"/>\n\t\t\t<Input value="{MainAddress/postcode}" maxLength="40" id="MainAddress.postcodeInput" liveChange="onInputFieldChanged">\n\t\t\t\t<layoutData>\n\t\t\t\t\t<layout:GridData span="L1 M2 S5"/>\n\t\t\t\t</layoutData>\n\t\t\t</Input>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.regionID">\n\t\t<form:fields>\n\t\t\t<Input id="MainAddress.regionIDInput" value="{MainAddress/regionID}" type="Text" visible="false"/>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.mobilePhone" visible="{parts:[\'category\', \'constants>/accountCategoryPerson\'], formatter: \'cus.crm.myaccounts.util.formatter.isEqual\'}">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>MOBILE}" id="MainAddress.mobilePhoneLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/mobilePhone}" maxLength="40" id="MainAddress.mobilePhoneInput" liveChange="onInputFieldChanged"/>\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.phone">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>PHONE}" id="MainAddress.phoneLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/phone}" maxLength="40" id="MainAddress.phoneInput" liveChange="onInputFieldChanged" />\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.email">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>EMAIL}" id="MainAddress.emailLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/email}" maxLength="40" id="MainAddress.emailInput" liveChange="onInputFieldChanged" />\n\t\t</form:fields>\n\t</form:FormElement>\n\n\t<form:FormElement id="MainAddress.website">\n\t\t<form:label>\n\t\t\t<Label text="{i18n>WEBSITE}" id="MainAddress.websiteLabel" width="100%" />\n\t\t</form:label>\n\t\t<form:fields>\n\t\t\t<Input value="{MainAddress/website}" maxLength="40" id="MainAddress.websiteInput" liveChange="onInputFieldChanged" />\n\t\t</form:fields>\n\t</form:FormElement>\n\n</core:FragmentDefinition>\n',
		"cus/crm/myaccounts/view/overview/Appointments.controller.js": function() {
			jQuery.sap.require("cus.crm.myaccounts.util.formatter");
			jQuery.sap.require("cus.crm.myaccounts.util.Util");
			sap.ui.controller("cus.crm.myaccounts.view.overview.Appointments", {
				onInit: function() {
					var a = this.byId("AppointmentsList");
					var b = a.getBindingInfo("items");
					b.sorter = this._getListSorter();
					b.filters = [];
					b.groupHeaderFactory = this._getHeaderGroupHandler();
				},
				getList: function() {
					return this.byId("AppointmentsList");
				},
				onSubViewLiveSearch: function(s) {
					var b = this.getList().getBinding("items");
					var f = [];
					if (s !== "") f.push(new sap.ui.model.Filter("Description", sap.ui.model.FilterOperator.Contains, s));
					if (b) b.filter(f);
				},
				_navigateToAppointment: function(e) {
					if (sap.ushell && sap.ushell.Container) {
						var f = sap.ushell.Container.getService;
						if (f) {
							var c = f("CrossApplicationNavigation");
							if (c) {
								c.toExternal({
									target: {
										semanticObject: "Appointment",
										action: "myAppointments&/appointment/" + e.getSource().getBindingContext().getProperty("Guid")
									}
								});
							}
						}
					}
				},
				_getListSorter: function() {
					var t = this;
					return new sap.ui.model.Sorter("FromDate", false, function(c) {
						var d = new Date(c.getProperty("FromDate").getTime());
						var a = new Date(c.getProperty("ToDate").getTime());
						var b = c.getProperty("AllDay");
						if (b) {
							var f = d.getTimezoneOffset();
							var e = a.getTimezoneOffset();
							d.setTime(d.getTime() + f * 60 * 1000);
							a.setTime(a.getTime() + e * 60 * 1000);
						}
						var D = sap.ui.core.format.DateFormat.getDateInstance({
							style: "full"
						});
						return {
							key: t.getDateString(d),
							text: D.format(d)
						};
					});
				},
				_getHeaderGroupHandler: function() {
					var t = this;
					return function(g) {
						var h = new sap.m.GroupHeaderListItem({
							title: g.text
						});
						if (g.key === t.getDateString(new Date())) {
							h.addStyleClass("sapMLabelBold");
						}
						h.setUpperCase(false);
						return h;
					};
				},
				onStoreCurrentStateSupported: function() {
					return true;
				},
				onStoreCurrentState: function(s) {
					s.contextPath = "";
					var b = sap.ui.getCore().getEventBus();
					s.onRefreshContextPath = function(c, e, d) {
						if (s.action !== "refreshList") {
							s.action = "refreshContextPath";
							s.contextPath = d.contextPath.replace("/AppointmentSet", "AppointmentCollection");
						}
					};
					s.onRefreshList = function() {
						s.action = "refreshList";
					};
					b.subscribe("cus.crm.mycalendar", "appointmentChanged", s.onRefreshContextPath, s);
					b.subscribe("cus.crm.mycalendar", "followUpAppointmentCreated", s.onRefreshList, s);
					b.subscribe("cus.crm.mycalendar", "appointmentCreated", s.onRefreshList, s);
					b.subscribe("cus.crm.mycalendar", "appointmentDeleted", s.onRefreshList, s);
					s.onExit = function() {
						var b = sap.ui.getCore().getEventBus();
						b.unsubscribe("cus.crm.mycalendar", "appointmentChanged", s.onRefreshContextPath, s);
						b.unsubscribe("cus.crm.mycalendar", "followUpAppointmentCreated", s.onRefreshList, s);
						b.unsubscribe("cus.crm.mycalendar", "appointmentCreated", s.onRefreshList, s);
						b.unsubscribe("cus.crm.mycalendar", "appointmentDeleted", s.onRefreshList, s);
					};
				},
				onRestoreCurrentState: function(s) {
					if (s.action === "refreshList") {
						this.getList().getBinding("items").refresh();
					} else if (s.action === "refreshContextPath") {
						var r = cus.crm.myaccounts.util.Util.getRefreshUIObject(this.getView().getModel(), "/" + s.contextPath);
						r.refresh();
					}
				},
				getDateString: function(d) {
					var D = d.getDate().toString();
					D = (D.length === 1) ? "0" + D : D;
					var m = d.getMonth() + 1;
					m = m.toString();
					m = (m.length === 1) ? "0" + m : m;
					var y = d.getFullYear();
					var s = y + "/" + m + "/" + D;
					return s;
				},
				getFooterButtons: function() {
					var t = this;
					return [{
						sIcon: "sap-icon://add",
						sTooltip: cus.crm.myaccounts.util.Util.geti18NText("ADD_APPOINTMENT_TOOLTIP"),
						onBtnPressed: function() {
							t.onCreateAppointment();
						}
					}];
				},
				onCreateAppointment: function() {
					var d = this.getView().getModel();
					var t = this;
					var s = function(r) {
						var p;
						if (!t.processTypeModel) {
							p = r["CustomizingAppointmentTypeCollection"];
							t.processTypeModel = new sap.ui.model.json.JSONModel();
							t.processTypeModel.setProperty("/TransactionTypeSet", p);
						} else {
							p = t.processTypeModel.getProperty("/TransactionTypeSet");
						}
						if (p.length === 1) {
							var a = p[0].processTypeCode;
							t._navigateToCreationOfAppointment(a);
						} else {
							t.oProcessTypeDialog = sap.ui.xmlfragment("cus.crm.myaccounts.view.overview.ProcessTypeDialog", t);
							t.oProcessTypeDialog.setModel(t.getView().getModel("i18n"), "i18n");
							t.oProcessTypeDialog.setModel(t.processTypeModel, "processTypes");
							t.oProcessTypeDialog.open();
						}
					};
					if (!t.processTypeModel) cus.crm.myaccounts.util.Util.sendBatchReadRequests(d, ["CustomizingAppointmentTypeCollection"], s);
					else s.call(t);
				},
				selectProcess: function(e) {
					var p = "";
					var s = e.getParameter("selectedItem");
					if (s) {
						p = s.data("ProcessTypeCode");
					}
					this._navigateToCreationOfAppointment(p);
				},
				_navigateToCreationOfAppointment: function(p) {
					if (sap.ushell && sap.ushell.Container) {
						var f = sap.ushell.Container.getService;
						if (f) {
							var c = f("CrossApplicationNavigation");
							if (c) {
								var a = this.getView().getBindingContext().sPath.substring(1);
								c.toExternal({
									target: {
										semanticObject: "Appointment",
										action: "myAppointments&/newappointmentfromaccount/" + p + "/" + a
									}
								});
							}
						}
					}
				},
				searchProcess: function(e) {
					var i = e.getParameter("itemsBinding");
					var I;
					this.oProcessTypeDialog.setNoDataText(cus.crm.myaccounts.util.Util.geti18NText("LOADING_TEXT"));
					var s = e.getParameter("value");
					if (s !== undefined) {
						I = i.filter([new sap.ui.model.Filter("processTypeDescription", sap.ui.model.FilterOperator.Contains, s)]);
						if (I.getLength() === 0) {
							this.oProcessTypeDialog.setNoDataText(cus.crm.myaccounts.util.Util.geti18NText("NO_DATA_TEXT"));
						}
					}
				}
			});
		},
		"cus/crm/myaccounts/view/overview/Appointments.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core" xmlns:mvc="sap.ui.core.mvc" xmlns="sap.m"\n\t\t\tcontrollerName="cus.crm.myaccounts.view.overview.Appointments" xmlns:html="http://www.w3.org/1999/xhtml"\n\t\t\txmlns:util="cus.crm.myaccounts.util">\n\t\t\t\n\t<List\n\t\titems="{Appointments}" \n\t\tid="AppointmentsList" \n        growing="true"\n        growingThreshold="10"\n        growingScrollToLoad="false">\n        \t<util:ApptListItem id="AppointmentsListItem" \n\t\t\t\ttitle="{Description}" \n\t\t\t\tpress="_navigateToAppointment" \n\t\t\t\tsubtitle="{parts:[ {path:\'Location\'}, {path:\'ContactTxt\'}], formatter: \'cus.crm.myaccounts.util.formatter.formatLocationContact\'}" \n\t\t\t\tlocation="{Location}" \n\t\t\t\ttime="{parts:[{path: \'FromDate\'},{path: \'AllDay\'}], formatter: \'cus.crm.myaccounts.util.formatter.formatTime\'}" \n\t\t\t\tduration="{parts:[ {path:\'FromDate\'}, {path:\'ToDate\'}], formatter: \'cus.crm.myaccounts.util.formatter.formatDuration\'}"\n\t\t\t\ttype="Inactive"  \n\t\t\t\tprivat="{PrivatFlag}"> \n\t\t\t\t\n\t\t\t\t<util:content>\n\t\t\t\t\t<ObjectStatus text="{StatusTxt}" state="{path:\'Status\', formatter:\'cus.crm.myaccounts.util.formatter.formatStatusText\'}"></ObjectStatus>\n\t\t\t\t</util:content>\n\t\t\t\t\n\t\t\t</util:ApptListItem>\n      </List>\n\n</core:View>\n',
		"cus/crm/myaccounts/view/overview/Attachments.controller.js": function() {
			jQuery.sap.require("sap.ca.ui.message.message");
			jQuery.sap.require("cus.crm.myaccounts.util.Util");
			jQuery.sap.require("sap.m.MessageBox");
			sap.ui.controller("cus.crm.myaccounts.view.overview.Attachments", {
				onSubViewLiveSearch: function(s) {
					var b = this.byId("fileupload").getBinding("items");
					if (b) {
						var f = [];
						if (s !== "") {
							f.push(new sap.ui.model.Filter("name", sap.ui.model.FilterOperator.Contains, s));
						}
						b.filter(f);
					}
				},
				onChange: function(e) {
					var m = this.getView().getModel();
					var u = e.getSource();
					var f = e.getParameter("mParameters").files[0].name;
					var t = this.sToken || m.getSecurityToken();
					var c = new sap.m.UploadCollectionParameter({
						name: "x-csrf-token",
						value: t
					});
					u.addHeaderParameter(c);
					var C = new sap.m.UploadCollectionParameter({
						name: "content-disposition",
						value: "inline; filename=\"" + encodeURIComponent(f) + "\""
					});
					u.addHeaderParameter(C);
				},
				onUploadFile: function() {
					this.byId("fileupload").getBinding("items").refresh();
				},
				onDeleteFile: function(e) {
					var d = e.getParameter("documentId");
					var a = this.getView().getBindingContext().getObject().accountID;
					var c = "AttachmentCollection(documentID='" + d + "',documentClass='BDS_POC1',businessPartnerID='" + a + "')";
					var m = this.getView().getModel();
					var b = [m.createBatchOperation(c, "DELETE", undefined, {
						sETag: "*"
					})];
					cus.crm.myaccounts.util.Util.sendBatchChangeOperations(m, b);
				},
				onRenameFile: function(e) {
					var d = e.getParameter("documentId");
					var f = e.getParameter("fileName");
					var a = this.getView().getBindingContext().getObject().accountID;
					var c = "AttachmentCollection(documentID='" + d + "',documentClass='BDS_POC1',businessPartnerID='" + a + "')";
					this._renameFile(c, f, false);
				},
				_renameFile: function(c, a, f) {
					var e = null;
					if (f) {
						e = "*";
					}
					var m = this.getView().getModel();
					var b = [m.createBatchOperation(c, "PUT", {
						"name": a
					}, {
						sETag: e
					})];
					var t = this;
					cus.crm.myaccounts.util.Util.sendBatchChangeOperations(m, b, function() {
						t._onAfterRename(c);
					}, function(E) {
						E.newAttachmentName = a;
						t._onAfterRename(c, E);
					});
				},
				_onAfterRename: function(c, e) {
					if (e) {
						if (this["_onAfterSaveHandleErrorCode_" + e.statusCode]) {
							this["_onAfterSaveHandleErrorCode_" + e.statusCode](c, e);
						} else {
							sap.m.MessageBox.alert(e.message.value);
						}
					}
				},
				_onAfterSaveHandleErrorCode_412: function(c, e) {
					var t = this;
					sap.m.MessageBox.show(cus.crm.myaccounts.util.Util.geti18NText("MSG_CONFLICTING_FILE_NAME"), {
						title: cus.crm.myaccounts.util.Util.geti18NText("CONFIRM_TITLE"),
						actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
						onClose: function(a) {
							if (a === sap.m.MessageBox.Action.YES) {
								t._renameFile(c, e.newAttachmentName, true);
							} else {
								var r = cus.crm.myaccounts.util.Util.getRefreshUIObject(t.getView().getModel(), "/" + c);
								r.refresh();
							}
						}
					});
				},
				onFilenameLengthExceed: function() {
					sap.m.MessageToast.show(cus.crm.myaccounts.util.Util.geti18NText("MSG_EXCEEDING_FILE_NAME_LENGTH"));
				}
			});
		},
		"cus/crm/myaccounts/view/overview/Attachments.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core" xmlns:mvc="sap.ui.core.mvc"\n\txmlns="sap.m" controllerName="cus.crm.myaccounts.view.overview.Attachments"\n\txmlns:html="http://www.w3.org/1999/xhtml">\n\n\t<UploadCollection\n\t\tid="fileupload"\n\t\tmaximumFilenameLength="40"\n\t\tmultiple="false"\n\t\titems="{Attachments}"\n\t\tshowSeparators="All"\n\t\tuploadUrl="{path: \'accountID\', formatter: \'cus.crm.myaccounts.util.formatter.uploadUrlFormatter\'}"\n\t\tchange="onChange"\n\t\tfileDeleted="onDeleteFile"\n\t\tfileRenamed="onRenameFile"\n\t\tuploadComplete="onUploadFile"\n\t\tfilenameLengthExceed="onFilenameLengthExceed">\n\t\t<UploadCollectionItem\n\t\t\tcontributor="{createdBy}"\n\t\t\tdocumentId="{documentID}"\n\t\t\tfileName="{name}"\n\t\t\tfileSize="{path: \'fileSize\', formatter: \'cus.crm.myaccounts.util.formatter.convertStringToFloat\'}"\n\t\t\tmimeType="{mimeType}"\n\t\t\tuploadedDate="{path: \'createdAt\', formatter: \'cus.crm.myaccounts.util.formatter.formatMediumDate\'}"\n\t\t\turl="{parts: [{path: \'URL\'}, {path: \'__metadata\'}], formatter: \'cus.crm.myaccounts.util.formatter.attachmentLinkFormatter\'}"\n\t\t\tthumbnailUrl="{URL}"\n\t\t\tenableEdit="true"\n\t\t\tenableDelete="true"/>\n\t</UploadCollection>\n\n</core:View>\n',
		"cus/crm/myaccounts/view/overview/Contacts.controller.js": function() {
			jQuery.sap.require("cus.crm.myaccounts.util.Util");
			jQuery.sap.require("sap.m.MessageBox");
			jQuery.sap.require("cus.crm.myaccounts.util.Constants");
			sap.ui.controller("cus.crm.myaccounts.view.overview.Contacts", {
				onContactLinkClicked: function(e) {
					this._navToContact(e);
				},
				onEditContactClicked: function(e) {
					var c = e.getSource().getBindingContext().sPath.substr(1);
					var f = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService;
					var C = f && f("CrossApplicationNavigation");
					C.toExternal({
						target: {
							semanticObject: "ContactPerson",
							action: "MyContacts&/edit/" + c
						}
					});
				},
				onDeleteContactClicked: function(e) {
					var c = e.getSource().getBindingContext().sPath.substr(1);
					sap.m.MessageBox.confirm(cus.crm.myaccounts.util.Util.geti18NText("MSG_CONFIRM_DELETE_CONTACT"), jQuery.proxy(function(a) {
						if (a === "OK") {
							var m = this.getView().getModel();
							this.setBusy(true);
							var t = this;
							var b = [];
							var B = m.createBatchOperation("/" + c, "DELETE", undefined);
							b.push(B);
							cus.crm.myaccounts.util.Util.sendBatchChangeOperations(m, b, function() {
								t.setBusy(false);
							}, function() {
								t.setBusy(false);
							});
						}
					}, this));
				},
				onPhoneClicked: function(e) {
					sap.m.URLHelper.triggerTel(e.getSource().getText());
				},
				onEmailClicked: function(e) {
					sap.m.URLHelper.triggerEmail(e.getSource().getText());
				},
				getList: function() {
					return this.byId("list");
				},
				onSubViewLiveSearch: function(s) {
					var b = this.getList().getBinding("items");
					var f = [];
					if (s !== "") f.push(new sap.ui.model.Filter("lastName", sap.ui.model.FilterOperator.Contains, s));
					if (b) b.filter(f);
				},
				_navToContact: function(e) {
					var c = e.getSource().getBindingContext().sPath.substr(1);
					var f = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService;
					var C = f && f("CrossApplicationNavigation");
					C.toExternal({
						target: {
							semanticObject: "ContactPerson",
							action: "MyContacts&/display/" + c
						}
					});
				},
				onStoreCurrentStateSupported: function() {
					return true;
				},
				onStoreCurrentState: function(s) {
					s.contextPath = "";
					var b = sap.ui.getCore().getEventBus();
					s.onRefreshContextPath = function(c, e, d) {
						s.action = "refreshContextPath";
						s.contextPath = d.contextPath;
					};
					s.onRefreshList = function() {
						s.action = "refreshList";
					};
					b.subscribe("cus.crm.mycontacts", "contactChanged", s.onRefreshContextPath, s);
					b.subscribe("cus.crm.mycontacts", "contactCreated", s.onRefreshList, s);
					s.onExit = function() {
						var b = sap.ui.getCore().getEventBus();
						b.unsubscribe("cus.crm.mycontacts", "contactChanged", s.onRefreshContextPath, s);
						b.unsubscribe("cus.crm.mycontacts", "contactCreated", s.onRefreshList, s);
					};
				},
				onRestoreCurrentState: function(s) {
					if (s.action === "refreshList") {
						this.getList().getBinding("items").refresh();
					} else if (s.action === "refreshContextPath") {
						var r = cus.crm.myaccounts.util.Util.getRefreshUIObject(this.getView().getModel(), "/" + s.contextPath, "Photo,WorkAddress");
						r.refresh();
					}
				},
				onInitPersonalization: function() {
					var t = this.getList();
					return {
						tablePersonalization: {
							table: t
						}
					};
				},
				setBusy: function(b) {
					if (!this.oBusyDialog) this.oBusyDialog = new sap.m.BusyDialog();
					if (b) this.oBusyDialog.open();
					else this.oBusyDialog.close();
				},
				getFooterButtons: function() {
					var t = this;
					var b = this.getView().getBindingContext();
					if (b && b.getProperty("category") === cus.crm.myaccounts.util.Constants.accountCategoryPerson) return;
					return [{
						sIcon: "sap-icon://add",
						sTooltip: cus.crm.myaccounts.util.Util.geti18NText("ADD_CONTACT_TOOLTIP"),
						onBtnPressed: function() {
							var f = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService;
							var c = f && f("CrossApplicationNavigation");
							c.toExternal({
								target: {
									semanticObject: "ContactPerson",
									action: "MyContacts&/new/" + t.getView().getBindingContext().sPath.substr(1)
								}
							});
						}
					}];
				}
			});
		},
		"cus/crm/myaccounts/view/overview/Contacts.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core" xmlns:mvc="sap.ui.core.mvc" xmlns="sap.m" xmlns:layout="sap.ui.layout"\n\t\t\tcontrollerName="cus.crm.myaccounts.view.overview.Contacts" xmlns:html="http://www.w3.org/1999/xhtml">\n\n\t<Table\n    \t\tid="list"\n\t\t\tmode="{device>/listMode}"\n\t\t\tgrowing="true"\n          \tgrowingThreshold="10"\n          \tgrowingScrollToLoad="false"\n          \titems="{path:\'Contacts\',\n          \t\t\tparameters: {expand: \'Photo,WorkAddress\'} }"> \n\t        <columns>\n\t          <Column id="fullName" width="16rem" minScreenWidth="Small" demandPopin="true"><Text text="{i18n>NAME}" /></Column>\n\t          <Column id="department" width="8rem" minScreenWidth="XXLarge" demandPopin="true"><Text text="{i18n>DEPARTMENT}" /></Column>\n\t          <Column id="mobilePhone" width="9rem" minScreenWidth="Small" demandPopin="true"><Text text="{i18n>MOBILE}" /></Column>\n\t          <Column id="phone" width="9rem" minScreenWidth="Large" demandPopin="true"><Text text="{i18n>PHONE}" /></Column>\n\t          <Column id="email" width="13rem" minScreenWidth="Medium" demandPopin="true"><Text text="{i18n>EMAIL}" /></Column>\n\t          <Column id="actions" width="3rem" minScreenWidth="Desktop" demandPopin="true"><Text text="{i18n>ACTIONS}" /></Column>\n\t        </columns>\n\t        <items>\n\t        \t<ColumnListItem id="columnListItem">\n\t            \t<cells>\n\n            \t\t\t<layout:Grid class="gridMarginTop" defaultSpan="L3 M3 S6" hSpacing="0" vSpacing="0">\n\t            \t\t\t<layout:content>\n\t\t\t\t\t\t\t\t<core:Icon\n\t\t\t\t\t\t\t\t\tsrc="{path:\'Photo/__metadata/media_src\', formatter: \'cus.crm.myaccounts.util.formatter.pictureUrlFormatter\'}"\n\t\t\t\t\t\t\t\t\tvisible="{parts:[{path:\'contactID\'}, {path:\'Photo/__metadata/media_src\'}], formatter:\'cus.crm.myaccounts.util.formatter.standardIconVisibilityFormatter\'}"\n\t            \t\t\t\t\tsize="2.5rem">\n\t\t\t\t\t\t\t     </core:Icon>\n\t\t\t\t\t\t\t     <Image\n\t\t\t\t\t\t\t\t\tsrc="{path:\'Photo/__metadata/media_src\', formatter:\'cus.crm.myaccounts.util.formatter.pictureUrlFormatter\'}"\n\t\t\t\t\t\t\t\t\tvisible="{path:\'Photo/__metadata/media_src\', formatter:\'cus.crm.myaccounts.util.formatter.logoVisibilityFormatter\'}"\n\t\t\t\t\t\t\t\t\theight="2.5rem"\n\t\t\t\t\t\t\t\t\twidth="2.5rem">\n\t\t\t\t\t\t\t\t</Image>\n\t\t\t\t\t\t\t\t<VBox>\n\t\t\t\t\t\t\t\t\t<items>\n\t            \t\t\t\t\t\t<Link id="fullNameLink" text="{fullName}" press="onContactLinkClicked"/>\n\t            \t\t\t\t\t\t<Label id="functionLabel" text="{function}" />\n\t            \t\t\t\t\t</items>\n\t            \t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t            <layout:GridData span="L8 M8 S8"/>\n\t\t\t\t\t\t\t        </layoutData>\n            \t\t\t\t\t</VBox>\t\t  \n\t            \t\t\t</layout:content>\n\t            \t\t</layout:Grid>\n\t\t\t\t\t\t<Text text="{department}"/>\n\t\t\t\t\t\t<Link text="{WorkAddress/mobilePhone}" press="onPhoneClicked"/>\n\t\t\t            <Link text="{WorkAddress/phone}" press="onPhoneClicked"/>\n\t\t\t            <Link text="{WorkAddress/email}" press="onEmailClicked"/>\n\t\t\t            <layout:HorizontalLayout>\n\t\t\t\t        \t<core:Icon id="editIcon" src="sap-icon://edit" size="1.3rem" press="onEditContactClicked"/>\n\t\t\t\t            <core:Icon id="deleteIcon" src="sap-icon://delete" size="1.3rem"  press="onDeleteContactClicked" class="cusMyAccountsPaddingLeft"/>\n\t\t\t            </layout:HorizontalLayout>\n\t\t\t            \n\t\t\t         </cells>\n\t        \t</ColumnListItem>\n\t    \t</items>\n    \t</Table>\n\n</core:View>',
		"cus/crm/myaccounts/view/overview/GeneralData.controller.js": function() {
			jQuery.sap.require("cus.crm.myaccounts.util.formatter");
			jQuery.sap.require("cus.crm.myaccounts.util.Constants");
			jQuery.sap.require("cus.crm.myaccounts.util.Util");
			sap.ui.controller("cus.crm.myaccounts.view.overview.GeneralData", {
				onInit: function() {
					var c = new sap.ui.model.json.JSONModel(cus.crm.myaccounts.util.Constants);
					this.getView().setModel(c, "constants");
				},
				getExpandForBinding: function() {
					var d = "EmployeeResponsible,MainAddress,Classification,EmployeeResponsibleRel";
					var D = [];
					if (this.extHookGetDependentCustomRelations) D = this.extHookGetDependentCustomRelations();
					if (D.length > 0) d = d + "," + D.join();
					return d;
				},
				onMapIconPressed: function() {
					sap.m.URLHelper.redirect("http" + "://" + "maps.apple.com/?q=" + this.getView().getBindingContext().getProperty(
						"MainAddress/address").replace(/\n/g, ' ').replace(/\r/g, ''), true);
				},
				onEmployeeResponsibleLinkPressed: function(e) {
					this._showBusinessCard(e);
				},
				_showBusinessCard: function(e) {
					var c = e.getSource().getBindingContext();
					cus.crm.myaccounts.util.Util.openQuickoverview(cus.crm.myaccounts.util.Util.geti18NText("EMPLOYEE_TITLE"), c.getProperty(
							"EmployeeResponsible/fullName"), c.getProperty("EmployeeResponsible/position"), cus.crm.myaccounts.util.formatter.pictureUrlFormatter(
							this.getView().getModel().getProperty(c.getPath() + "/EmployeeResponsible/Photo/__metadata/media_src")), c,
						"EmployeeResponsible", "WorkAddress", c, "MainAddress", e.getSource());
				},
				onPhoneTaped: function(e) {
					if (jQuery.device.is.ipad) sap.m.URLHelper.redirect("facetime://" + e.getSource().getText().replace(/[()\s]/g, ''), false);
					else sap.m.URLHelper.triggerTel(e.getSource().getText());
				},
				onEmailTaped: function(e) {
					sap.m.URLHelper.triggerEmail(e.getSource().getText());
				},
				getFooterButtons: function() {
					var t = this;
					return [{
						sI18nBtnTxt: "BUTTON_EDIT",
						sIcon: "",
						onBtnPressed: function() {
							var p;
							p = {
								contextPath: t.getView().getBindingContext().sPath.substr(1)
							};
							t.oRouter.navTo("edit", p, false);
						}
					}];
				}
			});
		},
		"cus/crm/myaccounts/view/overview/GeneralData.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core" xmlns="sap.m" xmlns:mvc="sap.ui.core.mvc" xmlns:form="sap.ui.layout.form" xmlns:layout="sap.ui.layout"\n\t\t\tcontrollerName="cus.crm.myaccounts.view.overview.GeneralData" xmlns:html="http://www.w3.org/1999/xhtml">\n\n\t<Panel>\n    \t<content>\n\n\t\t    <layout:Grid defaultSpan="L12 M12 S12" width="auto">\n\t\t\t\t<layout:content>\n\t\t\t\t\t<!-- Extends the view by a form -->\n\t\t\t\t\t<core:ExtensionPoint name="extDisplayForm">\n\n\t\t\t\t\t\t<form:Form id="form" maxContainerCols="2" editable="false">\n\t\t\t\t\t\t\t<form:layout>\n\t\t\t\t\t\t\t\t<form:ResponsiveGridLayout\n\t\t\t\t\t\t\t\t\tlabelSpanL="4"\n\t\t\t\t\t\t\t\t\tlabelSpanM="4"\n\t\t\t\t\t\t\t\t\temptySpanL="3"\n\t\t\t\t\t\t\t\t\temptySpanM="2"\n\t\t\t\t\t\t\t\t\tcolumnsL="1"\n\t\t\t\t\t\t\t\t\tcolumnsM="1">\n\t\t\t\t\t\t\t\t</form:ResponsiveGridLayout>\n\t\t\t\t\t\t\t</form:layout>\n\t\t\t\t\t        <form:formContainers>\n\n\t\t\t\t\t\t\t\t<!-- Extends the form at the top -->\n\t\t\t\t\t        \t<core:ExtensionPoint name="extDisplayFormTop"/>\n\n\t\t\t\t\t        \t<form:FormContainer id="formCompany" visible="{parts:[\'category\', \'constants>/accountCategoryPerson\'], formatter: \'cus.crm.myaccounts.util.formatter.isUnequal\'}">\n\t\t\t\t\t\t\t\t\t<form:formElements >\n\t\t\t\t\t\t\t\t\t\t<core:Fragment id="companyFragment" fragmentName="cus.crm.myaccounts.view.overview.GeneralDataCompany" type="XML" />\n\t\t\t\t\t\t\t\t\t</form:formElements>\n\t\t\t\t\t\t\t\t</form:FormContainer>\n\n\t\t\t        \t\t\t<form:FormContainer id="formPerson" visible="{parts:[\'category\', \'constants>/accountCategoryPerson\'], formatter: \'cus.crm.myaccounts.util.formatter.isEqual\'}">\n\t\t\t\t\t\t\t\t\t<form:formElements >\n\t\t\t\t\t\t\t\t\t\t<core:Fragment id="personFragment" fragmentName="cus.crm.myaccounts.view.overview.GeneralDataPerson" type="XML" />\n\t\t\t\t\t\t\t\t\t</form:formElements>\n\t\t\t\t\t\t\t\t</form:FormContainer>\n\n\t\t\t\t\t\t\t\t<!-- Extends the form in the middle -->\n\t\t\t\t\t\t\t\t<core:ExtensionPoint name="extDisplayFormMiddle"/>\n\t\n\t\t\t\t\t        \t<form:FormContainer id="formAddress">\n\t\t\t\t\t        \t\t<form:formElements>\n\t\n\t\t\t\t\t        \t\t\t<!-- Address -->\n\t\n\t\t\t\t\t        \t\t\t<form:FormElement id="mobilePhone" visible="{parts:[\'category\', \'constants>/accountCategoryPerson\'], formatter: \'cus.crm.myaccounts.util.formatter.isEqual\'}">\n\t\t\t\t\t        \t\t\t\t<form:label>\n\t\t\t\t\t        \t\t\t\t\t<Label id="mobilePhoneLabel"\n\t\t\t\t\t\t\t\t\t\t\t\t       text="{i18n>MOBILE}"/>\n\t\t\t\t\t        \t\t\t\t</form:label>\n\t\t\t\t\t        \t\t\t\t<form:fields>\n\t\t\t\t\t        \t\t\t\t\t<Link id="mobilePhoneText"\n\t\t\t\t\t\t\t\t\t\t\t      \t  text="{MainAddress/mobilePhone}"\n\t\t\t\t\t\t\t\t\t\t\t      \t  press="onPhoneTaped"/>\n\t\t\t\t\t        \t\t\t\t</form:fields>\n\t\t\t\t\t        \t\t\t</form:FormElement>\n\t\n\t\t\t\t\t        \t\t\t<form:FormElement id="phone">\n\t\t\t\t\t        \t\t\t\t<form:label>\n\t\t\t\t\t        \t\t\t\t\t<Label id="phoneLabel"\n\t\t\t\t\t\t\t\t\t\t\t\t       text="{i18n>PHONE}"/>\n\t\t\t\t\t        \t\t\t\t</form:label>\n\t\t\t\t\t        \t\t\t\t<form:fields>\n\t\t\t\t\t        \t\t\t\t\t<Link id="phoneText"\n\t\t\t\t\t\t\t\t\t\t\t      \t  text="{MainAddress/phone}"\n\t\t\t\t\t\t\t\t\t\t\t      \t  press="onPhoneTaped"/>\n\t\t\t\t\t        \t\t\t\t</form:fields>\n\t\t\t\t\t        \t\t\t</form:FormElement>\n\t\n\t\t\t\t\t        \t\t\t<form:FormElement id="email">\n\t\t\t\t\t        \t\t\t\t<form:label>\n\t\t\t\t\t        \t\t\t\t\t<Label id="emailLabel"\n\t\t\t\t\t\t\t\t\t\t\t\t       text="{i18n>EMAIL}"/>\n\t\t\t\t\t        \t\t\t\t</form:label>\n\t\t\t\t\t        \t\t\t\t<form:fields>\n\t\t\t\t\t        \t\t\t\t\t<Link id="emailText"\n\t\t\t\t\t\t\t\t\t\t\t\t      text="{MainAddress/email}"\n\t\t\t\t\t\t\t\t\t\t\t      \t  press="onEmailTaped"/>\n\t\t\t\t\t        \t\t\t\t</form:fields>\n\t\t\t\t\t        \t\t\t</form:FormElement>\n\t\n\t\t\t\t\t        \t\t\t<form:FormElement id="webSite">\n\t\t\t\t\t        \t\t\t\t<form:label>\n\t\t\t\t\t        \t\t\t\t\t<Label id="webSiteLabel"\n\t\t\t\t\t\t\t\t\t\t\t\t       text="{i18n>WEBSITE}"/>\n\t\t\t\t\t        \t\t\t\t</form:label>\n\t\t\t\t\t        \t\t\t\t<form:fields>\n\t\t\t\t\t        \t\t\t\t\t<Link id="webSiteText"\n\t\t\t\t\t\t\t\t\t\t\t    \t  href="{path:\'MainAddress/website\', formatter:\'cus.crm.myaccounts.util.formatter.websiteURL\'}"\n\t\t\t\t\t\t\t\t\t\t\t    \t  target="_blank"\n\t\t\t\t\t\t\t\t\t\t\t\t      text="{MainAddress/website}"/>\n\t\t\t\t\t        \t\t\t\t</form:fields>\n\t\t\t\t\t        \t\t\t</form:FormElement>\n\t\n\t\t\t\t\t        \t\t\t<form:FormElement id="address">\n\t\t\t\t\t        \t\t\t\t<form:label>\n\t\t\t\t\t        \t\t\t\t\t<Label id="addressLabel"\n\t\t\t\t\t\t\t\t\t\t\t           text="{i18n>ADDRESS}"/>\n\t\t\t\t\t        \t\t\t\t</form:label>\n\t\t\t\t\t        \t\t\t\t<form:fields>\n\t\t\t\t\t        \t\t\t\t\t<layout:HorizontalLayout>\n\t\t\t\t\t\t        \t\t\t\t\t<Text id="addressText"\n\t\t\t\t\t\t\t\t\t\t\t\t     \t  text="{MainAddress/address}"/>\n\t\t\t\t\t\t\t\t\t\t\t\t    <layout:HorizontalLayout id="mapIcon" visible="false">\n\t\t\t\t\t\t\t\t\t\t\t\t    \t<core:Icon src="sap-icon://map" press="onMapIconPressed" size="1.2rem" class="cusMyAccountsPaddingLeft" visible="{parts:[\'MainAddress/address\'], formatter: \'cus.crm.myaccounts.util.formatter.isNotInitial\'}" />\n\t\t\t\t\t\t\t\t\t\t\t\t    </layout:HorizontalLayout>\n\t\t\t\t\t\t\t\t\t\t\t    </layout:HorizontalLayout>\n\t\t\t\t\t        \t\t\t\t</form:fields>\n\t\t\t\t\t        \t\t\t</form:FormElement>\n\t\t\t\t\t        \t\t\t\n\t\t\t\t\t        \t\t\t<!-- Extends the address block in the form -->\n\t\t\t\t\t        \t\t\t<core:ExtensionPoint name="extDisplayFormAddress"/>\n\t\n\t\t\t\t\t        \t\t\t<!-- Rating -->\n\t\n\t\t\t\t\t        \t\t\t<form:FormElement id="rating">\n\t\t\t\t\t        \t\t\t\t<form:label>\n\t\t\t\t\t        \t\t\t\t\t<Label id="ratingLabel"\n\t\t\t\t\t\t\t\t\t\t\t\t       text="{i18n>RATING}"/>\n\t\t\t\t\t        \t\t\t\t</form:label>\n\t\t\t\t\t        \t\t\t\t<form:fields>\n\t\t\t\t\t        \t\t\t\t\t<Text id="ratingText"\n\t\t\t\t\t\t\t\t\t        \t      text="{Classification/ratingText}"/>\n\t\t\t\t\t        \t\t\t\t</form:fields>\n\t\t\t\t\t        \t\t\t</form:FormElement>\n\t\n\t\t\t\t\t        \t\t\t<!-- Employee Responsible -->\n\t\n\t\t\t\t\t        \t\t\t<form:FormElement id="employee">\n\t\t\t\t\t        \t\t\t\t<form:label>\n\t\t\t\t\t        \t\t\t\t\t<Label id="employeeLabel"\n\t\t\t\t\t\t\t\t\t\t\t\t       text="{i18n>EMPLOYEE_RESPONSIBLE}"/>\n\t\t\t\t\t        \t\t\t\t</form:label>\n\t\t\t\t\t        \t\t\t\t<form:fields>\n\t\t\t\t\t        \t\t\t\t\t<Link id="employeeText"\n\t\t\t\t\t\t\t\t\t\t\t\t      text="{EmployeeResponsibleRel/account2FullName}"\n\t\t\t\t\t\t\t\t\t\t\t\t      press="onEmployeeResponsibleLinkPressed"/>\n\t\t\t\t\t        \t\t\t\t</form:fields>\n\t\t\t\t\t        \t\t\t</form:FormElement>\n\t\n\t\t\t\t\t        \t\t</form:formElements>\n\t\t\t\t\t        \t</form:FormContainer>\n\n\t\t\t\t\t\t\t\t<!-- Extends the form at the bottom -->\n\t\t\t\t\t        \t<core:ExtensionPoint name="extDisplayFormBottom"/>\n\n\t\t\t\t\t        </form:formContainers>\n\t\t\t\t\t    </form:Form>\n\n\t\t\t\t\t</core:ExtensionPoint>\n\t\t\t\t</layout:content>\n\t\t\t</layout:Grid>\n\n    \t</content>\n\t</Panel>\n\n</core:View>\n',
		"cus/crm/myaccounts/view/overview/GeneralDataCompany.fragment.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:FragmentDefinition\n  xmlns="sap.m"\n  xmlns:core="sap.ui.core"\n  xmlns:form="sap.ui.layout.form">\n\n\t<form:FormElement id="name1">\n       \t<form:label>\n       \t\t<Label id="name1Label"\n\t\t\t\t   text="{parts:[\'i18n>LAST_NAME\', \'i18n>COMPANY_NAME1\', \'i18n>COMPANY_NAME1\', \'category\'], formatter: \'cus.crm.myaccounts.util.formatter.AccountSpecificText\'}"/>\n       \t</form:label>\n       \t<form:fields>\n       \t\t<Text id="name1Input"\n\t\t          text="{name1}"/>\n       \t</form:fields>\n\t</form:FormElement>\n\n    <form:FormElement id="name2">\n       \t<form:label>\n       \t\t<Label id="name2Label"\n     \t\t\t   text="{parts:[\'i18n>FIRST_NAME\', \'i18n>COMPANY_NAME2\', \'i18n>COMPANY_NAME2\', \'category\'], formatter: \'cus.crm.myaccounts.util.formatter.AccountSpecificText\'}"/>\n       \t</form:label>\n       \t<form:fields>\n       \t\t<Text id="name2Input"\n   \t  \t\t\t  text="{name2}"/>\n       \t</form:fields>\n\t</form:FormElement>\n\n\t<!-- Extends the form -->\n\t<core:ExtensionPoint name="extDisplayFormCompany"/>\n\n</core:FragmentDefinition>',
		"cus/crm/myaccounts/view/overview/GeneralDataPerson.fragment.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:FragmentDefinition\n  xmlns="sap.m"\n  xmlns:core="sap.ui.core"\n  xmlns:form="sap.ui.layout.form">\n\n\t<form:FormElement id="title">\n\t\t<form:label>\n       \t\t<Label id="titleLabel"\n\t\t\t\t   text="{i18n>TITLE}"/>\n       \t</form:label>\n       \t<form:fields>\n       \t\t<Text id="titleInput"\n\t\t\t\t  text="{title}"/>\n    \t</form:fields>\n    </form:FormElement>\n\n    <form:FormElement id="academicTitle">\n       \t<form:label>\n       \t\t<Label id="academicTitleLabel"\n\t\t\t\t   text="{i18n>ACADEMIC_TITLE}"/>\n       \t</form:label>\n       \t<form:fields>\n       \t\t<Text id="academicTitleInput"\n\t\t\t      text="{academicTitle}"/>\n       \t</form:fields>\n\t</form:FormElement>\n\n    <form:FormElement id="name2">\n      \t<form:label>\n      \t\t<Label id="name2Label"\n     \t\t\t   text="{parts:[\'i18n>FIRST_NAME\', \'i18n>COMPANY_NAME2\', \'i18n>COMPANY_NAME2\', \'category\'], formatter: \'cus.crm.myaccounts.util.formatter.AccountSpecificText\'}"/>\n       \t</form:label>\n       \t<form:fields>\n       \t\t<Text id="name2Input"\n   \t  \t\t\t  text="{name2}"/>\n       \t</form:fields>\n\t</form:FormElement>\n\n    <form:FormElement id="lastName">\n       \t<form:label>\n       \t\t<Label id="lastNameLabel"\n\t\t\t\t   text="{parts:[\'i18n>LAST_NAME\', \'i18n>COMPANY_NAME1\', \'i18n>COMPANY_NAME1\', \'category\'], formatter: \'cus.crm.myaccounts.util.formatter.AccountSpecificText\'}"/>\n       \t</form:label>\n       \t<form:fields>\n       \t\t<Text id="lastNameInput"\n\t\t\t      text="{name1}"/>\n       \t</form:fields>\n\t</form:FormElement>\n\n    <form:FormElement id="birthDate">\n       \t<form:label>\n       \t\t<Label id="birthDateLabel"\n\t\t\t\t   text="{i18n>BIRTHDAY}"/>\n       \t</form:label>\n       \t<form:fields>\n       \t\t<Text id="birthDateInput"\n\t\t\t      text="{path:\'birthDate\', formatter:\'cus.crm.myaccounts.util.formatter.formatMediumDate\'}"/>\n       \t</form:fields>\n\t</form:FormElement>\n\n\t<!-- Extends the form -->\n\t<core:ExtensionPoint name="extDisplayFormPerson"/>\n\n</core:FragmentDefinition>',
		"cus/crm/myaccounts/view/overview/ItemsQuickoverview.fragment.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:FragmentDefinition\n\txmlns="sap.m"\n\txmlns:core="sap.ui.core"\n\txmlns:form="sap.ui.layout.form">\n\n\t<Popover\n\t    title="{i18n>PRODUCTS}"\n\t    class="sapUiPopupWithPadding"\n\t    placement="Right" >\n\t    <List\n\t\t\tgrowing="true" growingScrollToLoad="false" mode="None" growingThreshold="5" \n\t\t\titems="{ERP_BUPA_ODATA>Items}" >\n\t\t\t<StandardListItem\n\t\t\t\ttitle="{ERP_BUPA_ODATA>itemDescription}"\n\t\t\t\tdescription="{ERP_BUPA_ODATA>materialNumber}" />\n\t\t</List>\n\t</Popover>\n\n</core:FragmentDefinition>',
		"cus/crm/myaccounts/view/overview/Leads.controller.js": function() {
			jQuery.sap.require("cus.crm.myaccounts.util.formatter");
			cus.crm.myaccounts.NavigationHelper = {};
			sap.ui.controller("cus.crm.myaccounts.view.overview.Leads", {
				onInit: function() {
					this.resourceBundle = sap.ca.scfld.md.app.Application.getImpl().AppI18nModel.getResourceBundle();
				},
				getList: function() {
					return this.byId("list");
				},
				onSubViewLiveSearch: function(s) {
					var b = this.getList().getBinding("items");
					var f = [];
					if (s !== "") f.push(new sap.ui.model.Filter("description", sap.ui.model.FilterOperator.Contains, s));
					if (b) b.filter(f);
				},
				onInitPersonalization: function() {
					var t = this.getList();
					return {
						tablePersonalization: {
							table: t
						}
					};
				},
				onLeadDescriptionLinkClicked: function(e) {
					this._navToLead(e);
				},
				onEditLeadClicked: function(e) {
					var g = e.getSource().getBindingContext().getObject().Guid;
					var f = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService;
					var c = f && f("CrossApplicationNavigation");
					c.toExternal({
						target: {
							semanticObject: "Lead",
							action: "manageLead&/editFullScreen/Leads(guid'" + g + "')"
						}
					});
				},
				onEmployeeResponsibleLinkClicked: function(e) {
					this._showBusinessCard(e);
				},
				_navToLead: function(e) {
					var g = e.getSource().getBindingContext().getObject().Guid;
					var f = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService;
					var c = f && f("CrossApplicationNavigation");
					c.toExternal({
						target: {
							semanticObject: "Lead",
							action: "manageLead&/display/Leads(guid'" + g + "')"
						}
					});
				},
				_showBusinessCard: function(e) {
					var c = e.getSource().getBindingContext().sPath;
					var m = this.getView().getModel();
					cus.crm.myaccounts.util.Util.openQuickoverview(this.resourceBundle.getText("EMPLOYEE_TITLE"), m.getProperty(c +
							"/EmployeeResponsible/fullName"), m.getProperty(c + "/EmployeeResponsible/position"), cus.crm.myaccounts.util.formatter.pictureUrlFormatter(
							m.getProperty(c + "/EmployeeResponsible/Photo/__metadata/media_src")), e.getSource().getBindingContext(),
						"EmployeeResponsible", "WorkAddress", this.getView().getBindingContext(), "MainAddress", e.getSource());
				},
				onStoreCurrentStateSupported: function() {
					return true;
				},
				onStoreCurrentState: function(s) {
					s.contextPath = "";
					var b = sap.ui.getCore().getEventBus();
					s.onRefreshContextPath = function(c, e, d) {
						s.action = "refreshContextPath";
						s.contextPath = d.contextPath.replace("Leads", "LeadCollection");
					};
					b.subscribe("cus.crm.leads", "leadChanged", s.onRefreshContextPath, s);
					s.onExit = function() {
						var b = sap.ui.getCore().getEventBus();
						b.unsubscribe("cus.crm.leads", "leadChanged", s.onRefreshContextPath, s);
					};
				},
				onRestoreCurrentState: function(s) {
					if (s.action === "refreshContextPath") {
						var r = cus.crm.myaccounts.util.Util.getRefreshUIObject(this.getView().getModel(), "/" + s.contextPath,
							"EmployeeResponsible,EmployeeResponsible/Photo,EmployeeResponsible/WorkAddress");
						r.refresh();
					}
				}
			});
		},
		"cus/crm/myaccounts/view/overview/Leads.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core" xmlns:mvc="sap.ui.core.mvc" xmlns="sap.m" xmlns:layout="sap.ui.layout"\n\t\t\tcontrollerName="cus.crm.myaccounts.view.overview.Leads" xmlns:html="http://www.w3.org/1999/xhtml">\n\n\t<Table\n   \t\tid="list"\n\t\tmode="{device>/listMode}"\n\t\tgrowing="true"\n         \tgrowingThreshold="10"\n         \tgrowingScrollToLoad="false"\n         \titems="{path:\'Leads\',\n         \t\t\tparameters: {expand: \'EmployeeResponsible,EmployeeResponsible/Photo,EmployeeResponsible/WorkAddress\'},\n         \t\t\tsorter: [{path: \'validTo\', descending: true}]}">\n        <columns>\n          <Column id="descriptionCol" width="16rem" minScreenWidth="Small" demandPopin="true"><Label text="{i18n>DESCRIPTION}" /></Column>\n          <Column id="assignedToCol" width="16rem" minScreenWidth="Medium" demandPopin="true"><Label text="{i18n>ASSIGNED_TO}" /></Column>\n          <Column id="closingDateCol" width="8rem" minScreenWidth="Large" demandPopin="true"><Label text="{i18n>END_DATE}" /></Column>\n          <Column id="qualificationCol" width="8rem" minScreenWidth="Large" demandPopin="true"><Label text="{i18n>QUALIFICATION}" /></Column>\n          <Column id="statusCol" width="12rem" minScreenWidth="Large" demandPopin="true"><Label text="{i18n>STATUS}" /></Column>\n          <!-- <Column id="actions" width="3rem" minScreenWidth="Desktop" demandPopin="true"><Text text="{i18n>ACTIONS}" /></Column>  -->\n        </columns>\n        <items>\n        \t<ColumnListItem id="columnListItem">\n            \t<cells>\n            \t\n\t\t\t\t\t<VBox>\n\t\t\t\t\t\t<items>\n          \t\t\t\t\t\t<Link text="{description}" press="onLeadDescriptionLinkClicked"/>\n          \t\t\t\t\t\t<Label text="{objectId}" />\n          \t\t\t\t\t</items>\n          \t\t\t\t\t<layoutData>\n\t\t\t\t            <layout:GridData span="L12 M12 S12"/>\n\t\t\t\t        </layoutData>\n         \t\t\t\t</VBox>\t\n            \n            \t\t<layout:Grid class="gridMarginTop" defaultSpan="L3 M3 S6" hSpacing="0" vSpacing="0">\n            \t\t\t<layout:content>\n\t\t\t\t\t\t\t<core:Icon \n\t\t\t\t\t\t\t\tsrc="{path:\'EmployeeResponsible/Photo/__metadata/media_src\', formatter: \'cus.crm.myaccounts.util.formatter.pictureUrlFormatter\'}"\n\t\t\t\t\t\t\t\tvisible="{parts:[{path:\'EmployeeResponsible/employeeID\'}, {path:\'EmployeeResponsible/Photo/__metadata/media_src\'}], formatter:\'cus.crm.myaccounts.util.formatter.standardIconVisibilityFormatter\'}"\n            \t\t\t\t\tsize="2.5rem">\n\t\t\t\t\t\t     </core:Icon>\n\t\t\t\t\t\t     <Image \n\t\t\t\t\t\t\t\tsrc="{path:\'EmployeeResponsible/Photo/__metadata/media_src\', formatter:\'cus.crm.myaccounts.util.formatter.pictureUrlFormatter\'}"\n\t\t\t\t\t\t\t\tvisible="{path:\'EmployeeResponsible/Photo/__metadata/media_src\', formatter:\'cus.crm.myaccounts.util.formatter.logoVisibilityFormatter\'}" \n\t\t\t\t\t\t\t\theight="2.5rem" \n\t\t\t\t\t\t\t\twidth="2.5rem">\n\t\t\t\t\t\t\t</Image>\n\t\t\t\t\t\t\t<VBox>\n\t\t\t\t\t\t\t\t<items>\n            \t\t\t\t\t\t<Link text="{EmployeeResponsible/fullName}" press="onEmployeeResponsibleLinkClicked"/>\n            \t\t\t\t\t\t<Label text="{EmployeeResponsible/position}" />\n            \t\t\t\t\t</items>\n            \t\t\t\t\t<layoutData>\n\t\t\t\t\t\t            <layout:GridData span="L8 M8 S8"/>\n\t\t\t\t\t\t        </layoutData>\n           \t\t\t\t\t</VBox>\t\t\t\t\t\t\t  \n            \t\t\t</layout:content>\n            \t\t</layout:Grid>\n                    \n                    <Text text="{parts:[{path:\'validTo\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatMediumDate\' }"/>\n                   \n\t\t            <Text text="{qualificationLevel}"/>\n\t\t              \n\t\t            <ObjectStatus text="{statusText}" state="{path:\'status\', formatter:\'cus.crm.myaccounts.util.formatter.formatStatusText\'}"/>\n\t\t            <!-- \n\t\t            <layout:HorizontalLayout>\n\t\t            \t<core:Icon src="sap-icon://edit" size="1.3rem" press="onEditLeadClicked"/>\n\t\t\t        </layout:HorizontalLayout>\n\t\t\t        -->\n                \n            \t</cells>\n        \t</ColumnListItem>\n    \t</items>\n   \t</Table>\n\n</core:View>\n',
		"cus/crm/myaccounts/view/overview/MarketingAttributes.controller.js": function() {
			jQuery.sap.require("cus.crm.myaccounts.util.Constants");
			jQuery.sap.require("cus.crm.myaccounts.util.Util");
			jQuery.sap.require("sap.m.MessageBox");
			sap.ui.controller("cus.crm.myaccounts.view.overview.MarketingAttributes", {
				onInit: function() {
					this.aBatchOperations = [];
					var c = new sap.ui.model.json.JSONModel(cus.crm.myaccounts.util.Constants);
					this.getView().setModel(c, "constants");
				},
				onItemSelected: function() {
					jQuery.sap.log.debug("cus.crm.myaccounts.view.overview.MarketingAttributes - onItemSelected");
					this._bindMarketingAttributes();
				},
				_bindMarketingAttributes: function() {
					jQuery.sap.log.debug("cus.crm.myaccounts.view.overview.MarketingAttributes - _bindMarketingAttributes");
					var t = this;
					if (!this.getList().getModel("mktattr")) {
						this.getList().setModel(new sap.ui.model.json.JSONModel(), "mktattr");
					}
					this.getList().getModel("mktattr").setProperty("/MarketingAttributes", []);
					this.getList().setBusy(true);
					cus.crm.myaccounts.util.Util.readODataObjects(t.getView().getBindingContext(), "MarketingAttributes", [], function(r) {
						if (r) {
							var m = t.getList().getModel("mktattr").getProperty("/MarketingAttributes");
							for (var i = 0; i < r.length; i++) {
								var M = jQuery.extend({}, t.getView().getModel().getProperty("/" + r[i]));
								M.key = r[i];
								t._setAttributeValues(M);
								t._setUIFieldType(M);
								m.push(M);
							}
							t.getList().getModel("mktattr").setProperty("/MarketingAttributes", m);
							t.getList().setBusy(false);
						}
					});
				},
				onSubViewLiveSearch: function(s) {
					var b = this.getList().getBinding("items");
					var f = [];
					if (s !== "") {
						var S = [];
						S.push(new sap.ui.model.Filter("attribute", sap.ui.model.FilterOperator.Contains, s));
						S.push(new sap.ui.model.Filter("eTag", sap.ui.model.FilterOperator.EQ, ""));
						f.push(new sap.ui.model.Filter(S, false));
					}
					if (b) b.filter(f);
				},
				onInitPersonalization: function() {
					jQuery.sap.log.debug("cus.crm.myaccounts.view.overview.MarketingAttributes - onInitPersonalization");
					var t = this.getList();
					return {
						tablePersonalization: {
							table: t
						}
					};
				},
				_setAttributeValues: function(m, M) {
					if (!m.mktAttrValues) m.mktAttrValues = [{
						valueID: m.valueID,
						value: m.value
					}];
					if (M && M.length > 0) {
						var n = [];
						var N = {};
						var d = {};
						for (var i = 0; i < M.length; i++) {
							N = this.getList().getModel().getProperty("/" + M[i]);
							N.value = cus.crm.myaccounts.util.formatter.formatMktAttrDisplayField(N.valueID, N.value, m.attributeDatatype, m.decimalPlaces,
								m.currency);
							n.push(N);
							if (!d.valueID) {
								d = N;
							}
							if (N.isDefault) {
								d = N;
							}
						}
						m.mktAttrValues = n;
						if (d && d.valueID && !m.valueID) {
							m.valueID = d.valueID;
							m.value = d.value;
							if (m.attributeDatatype === cus.crm.myaccounts.util.Constants.dataTypeDATE) {
								m.dateValue = cus.crm.myaccounts.util.formatter.convertDateStringToUTC(m.value);
							}
						}
					}
				},
				_setUIFieldType: function(m) {
					if (m.mode === cus.crm.myaccounts.util.Constants.modeEdit && (m.hasChecktable || m.valueRestricted || (m.mktAttrValues && m.mktAttrValues
							.length > 1))) m.fieldType = cus.crm.myaccounts.util.Constants.fieldSelect;
					else if (m.attributeDatatype === cus.crm.myaccounts.util.Constants.dataTypeTIME) {
						if (!m.valueID || m.valueID.length < 9) m.fieldType = cus.crm.myaccounts.util.Constants.fieldTime;
						else m.fieldType = cus.crm.myaccounts.util.Constants.fieldInput;
					} else if (m.attributeDatatype === cus.crm.myaccounts.util.Constants.dataTypeDATE) {
						if (!m.value || m.valueID.length < 9) m.fieldType = cus.crm.myaccounts.util.Constants.fieldDate;
						else m.fieldType = cus.crm.myaccounts.util.Constants.fieldInput;
					} else if (m.attributeDatatype === cus.crm.myaccounts.util.Constants.dataTypeCURR) {
						m.fieldType = cus.crm.myaccounts.util.Constants.fieldCurrency;
					} else m.fieldType = cus.crm.myaccounts.util.Constants.fieldInput;
				},
				getList: function() {
					return this.byId("list");
				},
				_generateTemplateForMarketingAttribute: function(m) {
					var n = {};
					n.eTag = "";
					n.accountID = "";
					n.attributeSetID = "";
					n.attributeSet = "";
					n.attributeID = "";
					n.attribute = "";
					n.attributeDatatype = "";
					n.mktAttrValues = [{
						valueID: "",
						value: ""
					}];
					n.valueID = "";
					n.value = "";
					n.dateValue = null;
					n.fieldType = "";
					n.mode = "";
					n.errorExists = false;
					n.attributeLength = "";
					n.decimalPlaces = "";
					n.currency = "";
					if (m) {
						this._copyAttributesOfObject2ToObject1(n, m);
					}
					return n;
				},
				_copyAttributesOfObject2ToObject1: function(o, a) {
					if (!a) return;
					for (var k in o) {
						if (a.hasOwnProperty(k)) o[k] = a[k];
					}
				},
				onAddMarketingAttributeClicked: function() {
					jQuery.sap.log.debug("cus.crm.myaccounts.view.overview.MarketingAttributes - onAddMarketingAttributeClicked");
					this._savePendingData();
					var m = this.getList().getModel("mktattr");
					var M = m.getProperty("/MarketingAttributes");
					if (M.length > 0 && !M[0].value && !M[0].attribute && !M[0].attributeSet) return;
					var n = this._generateTemplateForMarketingAttribute();
					n.mode = cus.crm.myaccounts.util.Constants.modeEdit;
					M.unshift(n);
					m.setProperty("/MarketingAttributes", M);
				},
				onDeleteMarketingAttributeClicked: function(e) {
					jQuery.sap.log.debug("cus.crm.myaccounts.view.overview.MarketingAttributes - onDeleteMarketingAttributeClicked - ContextPath: " +
						e.getSource().getBindingContext("mktattr").sPath);
					var m = e.getSource().getBindingContext("mktattr");
					var M = m.getObject();
					var l = m.sPath.substring(21);
					if (!M.eTag) {
						this._removeLine(l);
					} else {
						var r = M.key;
						var b = this.getView().getModel().createBatchOperation(r, "DELETE");
						this._collectBatchOperation(b, this._onAfterSave, this._onAfterSaveWithError, l);
						M.mode = cus.crm.myaccounts.util.Constants.modeEdit;
					}
					this._savePendingData();
				},
				_removeLine: function(l) {
					var m = this.getList().getModel("mktattr");
					var M = m.getProperty("/MarketingAttributes");
					M.splice(l, 1);
					m.setProperty("/MarketingAttributes", M);
				},
				onSaveMarketingAttributeClicked: function(e) {
					jQuery.sap.log.debug("cus.crm.myaccounts.view.overview.MarketingAttributes - onSaveMarketingAttributeClicked - ContextPath: " +
						e.getSource().getBindingContext("mktattr").sPath);
					this._savePendingData();
				},
				_savePendingData: function() {
					var m = this.getList().getModel("mktattr");
					var M = m.getProperty("/MarketingAttributes");
					for (var i in M) {
						var o = M[i];
						if (o.mode === cus.crm.myaccounts.util.Constants.modeEdit) {
							this._removeCoherentErrorFlags(o);
							if (this._checkSaveNeeded(o)) {
								if (this._checkSavePossible(o)) {
									var b = this.getView().getBindingContext();
									var e = o.eTag ? true : false;
									var r, B;
									if (e) {
										r = o.key;
										B = b.getModel().createBatchOperation(r, "PUT", this._getStripedAttribute(o), {
											contextPath: "/MarketingAttributes/" + i
										});
									} else {
										r = b.sPath + "/MarketingAttributes";
										B = b.getModel().createBatchOperation(r, "POST", this._getStripedAttribute(o), {
											contextPath: "/MarketingAttributes/" + i
										});
									}
									this._collectBatchOperation(B, this._onAfterSave, this._onAfterSaveWithError, o);
								}
							} else {
								delete o.mode;
								o.errorExists = false;
								this._setUIFieldType(o);
							}
						}
					}
					this._sendBatchOperations();
				},
				_collectBatchOperation: function(b, c, a, d) {
					if (this.requestURIIncludedInQueue(b.requestUri)) return;
					var B = {
						operation: b,
						callBackSuccess: c,
						callBackError: a,
						callbackArguments: d
					};
					if (b.method === 'DELETE') {
						this.aBatchOperations.unshift(B);
					} else {
						this.aBatchOperations.push(B);
					}
				},
				requestURIIncludedInQueue: function(r) {
					for (var i in this.aBatchOperations)
						if (this.aBatchOperations[i].operation.requestUri === r) return true;
					return false;
				},
				_sendBatchOperations: function() {
					if (!this.aBatchOperations.length) {
						this.refreshUI();
						this._setBusy(false);
						return;
					}
					var b = [];
					var t = this;
					var c = true;
					var a = this.aBatchOperations[0].operation.method;
					var B = [];
					while (c && this.aBatchOperations.length) {
						if (a === this.aBatchOperations[0].operation.method) {
							b.push(this.aBatchOperations[0]);
							B.push(this.aBatchOperations[0].operation);
							this.aBatchOperations.splice(0, 1);
						} else {
							c = false;
						}
					}
					var d = cus.crm.myaccounts.util.Util.sendBatchChangeOperations;
					if (a === 'GET') d = cus.crm.myaccounts.util.Util.sendBatchReadOperations;
					d(this.getView().getModel(), B, function(_) {
						var r = _;
						if (a === 'GET') {
							r = [];
							for (var k in _) r.push(_[k]);
						}
						for (var i in b) {
							if (b[i].callBackSuccess) {
								var e = [];
								var R = null;
								if (r.length > i) R = r[i];
								e.push(b[i].operation);
								e.push(R);
								if (b[i].callbackArguments instanceof Array) {
									e = $.merge(e, b[i].callbackArguments);
								} else {
									e.push(b[i].callbackArguments);
								}
								b[i].callBackSuccess.apply(t, e);
							}
						}
						t._sendBatchOperations();
					}, function(e) {
						for (var i in b) {
							if (b[i].callBackError) {
								var f = [];
								f.push(b[i].operation);
								f.push(e);
								if (b[i].callbackArguments instanceof Array) {
									f = $.merge(f, b[i].callbackArguments);
								} else {
									f.push(b[i].callbackArguments);
								}
								b[i].callBackError.apply(t, f);
							}
						}
						t.refreshUI();
					});
				},
				_setBusy: function(b) {
					if (!this.oBusyDialog) this.oBusyDialog = new sap.m.BusyDialog();
					if (b) this.oBusyDialog.open();
					else this.oBusyDialog.close();
				},
				_getStripedAttribute: function(m) {
					var M = jQuery.extend({}, m);
					delete M.key;
					delete M.mode;
					delete M.mktAttrValues;
					delete M.fieldType;
					delete M.value;
					delete M.attribute;
					delete M.attributeSet;
					delete M.errorExists;
					return M;
				},
				_checkSavePossible: function(m) {
					return (m.attributeSetID && m.attributeID && m.valueID && !m.errorExists);
				},
				_checkSaveNeeded: function(m) {
					if (m.key) {
						var M = m.key.split("'");
						var o = M[3];
						var a = M[5];
						var b = M[7];
						return (m.attributeSetID !== o || m.attributeID !== a || m.valueID !== decodeURIComponent(b));
					} else {
						return true;
					}
				},
				_onAfterSave: function(b, r, c) {
					switch (b.method) {
						case "DELETE":
							var l = c;
							this._removeLine(l);
							return;
						case "POST":
							var m = c;
							delete m.mode;
							this._setUIFieldType(m);
							this._copyAttributesOfObject2ToObject1(m, r);
							m.key = "MarketingAttributeCollection(accountID='" + m.accountID + "',attributeSetID='" + m.attributeSetID + "',attributeID='" +
								m.attributeID + "',valueID='" + encodeURIComponent(m.valueID) + "')";
							if (m.mktAttrValues.length === 1) {
								m.mktAttrValues = [{
									valueID: m.valueID,
									value: m.value
								}];
							}
							break;
						case "PUT":
							var m = c;
							delete m.mode;
							this._setUIFieldType(m);
							m.key = /(Marketing).+valueID='/gi.exec(m.key)[0] + encodeURIComponent(m.valueID) + "')";
							this.rereadMarketingAttribute(m);
							break;
					}
				},
				_onAfterSaveWithError: function(b, e, m) {
					switch (b.method) {
						case "DELETE":
							break;
						case "POST":
							m.errorExists = true;
							break;
						case "PUT":
							m.errorExists = true;
							break;
					}
					if (this["_onAfterSaveHandleErrorCode_" + e.statusCode]) this["_onAfterSaveHandleErrorCode_" + e.statusCode](e);
					else {
						sap.m.MessageBox.alert(e.message.value);
					}
				},
				_onAfterSaveHandleErrorCode_400: function(e) {
					for (var i in e.innererror.errordetails) {
						if (e.innererror.errordetails[i].code === "CRM_BUPA_ODATA/026") {
							sap.m.MessageBox.alert(cus.crm.myaccounts.util.Util.geti18NText("MSG_CONFLICTING_DATA_WITH_REFRESH"));
							return;
						}
					}
					sap.m.MessageBox.alert(e.message.value);
				},
				onSuggestItem: function(e) {
					jQuery.sap.log.debug("cus.crm.myaccounts.view.overview.MarketingAttributes - onSuggestItem");
					var I = e.getSource();
					var n = e.getSource().getValue();
					if (!n) return;
					var o = I.usedSearchString ? I.usedSearchString : "";
					var c = e.getSource().getBindingContext("mktattr").sPath;
					var m = this.getView().getModel();
					var M = this.getList().getModel("mktattr");
					var a = M.getProperty(c + "/attributeSetID");
					var b = m.getProperty(this.getView().getBindingContext().sPath + "/category");
					var d = I.getId().indexOf("attributeSetInput") === -1 ? false : true;
					if (o.length && n.indexOf(o) === 0) return;
					I.removeAllSuggestionItems();
					var C = function(g, h) {
						I.removeAllSuggestionItems();
						I.usedSearchString = h.newSearchString;
						for (var i = 0; i < g.length; i++) {
							var j = g[i];
							var k = d ? j.attributeSet.toUpperCase() : j.attribute.toUpperCase();
							if (k === I.usedSearchString.toUpperCase()) {
								var l = M.getProperty(c);
								l.mktAttrValues = null;
								l.valueID = "";
								l.value = "";
								this._copyAttributesOfObject2ToObject1(l, j);
								this._readAttributeValuesForSelect(l);
							}
							var p;
							if (d) {
								p = new sap.ui.core.Item({
									text: j.attributeSet
								});
								p.addCustomData(new sap.ui.core.CustomData({
									key: "oMarketingAttributeSet",
									value: j
								}));
							} else {
								p = new sap.ui.core.Item({
									text: j.attribute
								});
								p.addCustomData(new sap.ui.core.CustomData({
									key: "oMarketingAttribute",
									value: j
								}));
							}
							p.addCustomData(new sap.ui.core.CustomData({
								key: "contextPath",
								value: c
							}));
							I.addSuggestionItem(p);
						}
					};
					var f = [];
					if (d) {
						if (b) f.push(new sap.ui.model.Filter("category", sap.ui.model.FilterOperator.EQ, b));
						f.push(new sap.ui.model.Filter("attributeSet", sap.ui.model.FilterOperator.StartsWith, encodeURIComponent(n)));
						this._readMarketingAttributeSet(f, C, {
							newSearchString: n
						});
					} else {
						if (a && this.byId("attributeSetCol").getVisible()) f.push(new sap.ui.model.Filter("attributeSetID", sap.ui.model.FilterOperator
							.EQ, a));
						else if (b) f.push(new sap.ui.model.Filter("category", sap.ui.model.FilterOperator.EQ, b));
						f.push(new sap.ui.model.Filter("attribute", sap.ui.model.FilterOperator.StartsWith, encodeURIComponent(n)));
						this._readMarketingAttributes(f, C, {
							newSearchString: n
						});
					}
				},
				onSuggestItemSelected: function(e) {
					jQuery.sap.log.debug("cus.crm.myaccounts.view.overview.MarketingAttributes - onSuggestItemSelected");
					var I = e.getParameter("selectedItem");
					var c = null;
					var C = null;
					var m = null;
					var a = null;
					for (var i in I.getCustomData()) {
						var o = I.getCustomData()[i];
						if (o.getKey() === "oMarketingAttribute") c = o.getValue();
						if (o.getKey() === "oMarketingAttributeSet") C = o.getValue();
						if (o.getKey() === "contextPath") a = o.getValue();
					}
					m = this.getList().getModel("mktattr").getProperty(a);
					if (C) {
						m.attributeID = "";
						m.attribute = "";
						m.attributeDatatype = "";
					}
					m.mktAttrValues = null;
					m.valueID = "";
					m.value = "";
					this._copyAttributesOfObject2ToObject1(m, c);
					this._copyAttributesOfObject2ToObject1(m, C);
					if (c) this._readAttributeValuesForSelect(m);
				},
				_readMarketingAttributes: function(f, c, a) {
					var t = this;
					t.getList().getModel().read("/CustomizingMarketingAttributeCollection", {
						filters: f,
						success: function(d) {
							var m = jQuery.parseJSON(JSON.stringify(d));
							if (c) c.apply(t, [m.results, a]);
						},
						error: function(e) {
							jQuery.sap.log.error("Read failed in MarketingAttributes->_readMarketingAttribute:" + e.response.body);
						}
					});
				},
				_readMarketingAttributeSet: function(f, c, a) {
					var t = this;
					t.getList().getModel().read("/CustomizingMarketingAttrSetCollection", {
						filters: f,
						success: function(d) {
							var m = jQuery.parseJSON(JSON.stringify(d));
							if (c) c.apply(t, [m.results, a]);
						},
						error: function(e) {
							jQuery.sap.log.error("Read failed in MarketingAttributes->_readMarketingAttributeSet:" + e.response.body);
						}
					});
				},
				onEditMarketingAttributeClicked: function(e) {
					jQuery.sap.log.debug("cus.crm.myaccounts.view.overview.MarketingAttributes - onEditMarketingAttributeClicked");
					this._savePendingData();
					var m = e.getSource().getBindingContext("mktattr");
					var M = m.getObject();
					M.mode = cus.crm.myaccounts.util.Constants.modeEdit;
					if (M.valueRestricted || M.hasChecktable) {
						this._readAttributeValuesForSelect(M);
					} else {
						this._setAttributeValues(M);
						this._setUIFieldType(M);
						this.refreshUI();
					}
				},
				_readAttributeValuesForSelect: function(m) {
					var c = new sap.ui.model.Context(this.getList().getModel(), "/CustomizingMarketingAttributeCollection(attributeSetID='" + m.attributeSetID +
						"',attributeID='" + m.attributeID + "')");
					var t = this;
					cus.crm.myaccounts.util.Util.readODataObjects(c, "MarketingAttributeValues", null, function(v) {
						t._setAttributeValues(m, v);
						t._setUIFieldType(m);
						t.refreshUI();
					});
				},
				onInputFieldChanged: function(e) {
					var m = e.getSource().getBindingContext("mktattr").getObject();
					m.errorExists = false;
					m.value = e.getSource().getValue();
					m.valueID = e.getSource().getValue();
					m.mktAttrValues = [{
						valueID: m.valueID,
						value: m.value
					}];
				},
				onSelectValueChanged: function(e) {
					var m = e.getSource().getBindingContext("mktattr").getObject();
					m.errorExists = false;
					m.value = e.getSource().getSelectedItem().getText();
					if (m.attributeDatatype === cus.crm.myaccounts.util.Constants.dataTypeDATE) {
						m.dateValue = cus.crm.myaccounts.util.formatter.convertDateStringToUTC(m.value);
					}
				},
				onDateInputFieldChanged: function(e) {
					var m = e.getSource().getBindingContext("mktattr").getObject();
					m.errorExists = false;
					m.dateValue = cus.crm.myaccounts.util.formatter.convertDateToUTC(m.dateValue);
					if (m.dateValue) {
						m.valueID = m.dateValue.toISOString().slice(0, 10).replace(/-/g, "");
						m.mktAttrValues = [{
							valueID: m.valueID,
							value: m.value
						}];
					}
				},
				onTimeInputFieldChanged: function(e) {
					var m = e.getSource().getBindingContext("mktattr").getObject();
					m.errorExists = false;
					var d = e.getSource().getDateValue();
					if (d) {
						m.valueID = d.toTimeString().slice(0, 8);
						m.mktAttrValues = [{
							valueID: m.valueID,
							value: m.value
						}];
					}
				},
				_removeCoherentErrorFlags: function(m) {
					var e = false;
					var M = this.getList().getModel("mktattr").getProperty("/MarketingAttributes");
					for (var i in M) {
						if (M[i].mode === cus.crm.myaccounts.util.Constants.modeEdit && M[i].attributeID === m.attributeID && M[i] !== m) {
							M[i].errorExists = false;
							e = true;
						}
					}
					if (e) {
						m.errorExists = false;
					}
				},
				rereadMarketingAttribute: function(m) {
					var t = this;
					if (m.hasChecktable || m.valueRestricted || (m.mktAttrValues && m.mktAttrValues.length > 1)) return;
					if (m.attributeDatatype === cus.crm.myaccounts.util.Constants.dataTypeNUM || m.attributeDatatype === cus.crm.myaccounts.util.Constants
						.dataTypeCURR) {
						var b = t.getView().getModel().createBatchOperation("/" + m.key, "GET");
						this._collectBatchOperation(b, function(b, r, m) {
							t._copyAttributesOfObject2ToObject1(m, r);
							m.key = /(Marketing).+valueID='/gi.exec(m.key)[0] + encodeURIComponent(r.valueID) + "')";
							if (m.mktAttrValues.length === 1) {
								m.mktAttrValues = [{
									valueID: m.valueID,
									value: m.value
								}];
							}
						}, function() {}, m);
					}
				},
				refreshUI: function() {
					var m = this.getList().getModel("mktattr");
					var M = m.getProperty("/MarketingAttributes");
					m.setProperty("/MarketingAttributes", M);
				},
				onMarketingAttributeValueHelpSelected: function(e) {
					jQuery.sap.log.debug("cus.crm.myaccounts.view.overview.MarketingAttributes - onMarketingAttributeValueHelpSelected");
					var m = this.getView().getModel();
					var b = this.getView().getBindingContext();
					var a = m.getProperty(b.sPath).category;
					var M = e.getSource().getBindingContext("mktattr").getObject();
					this.valueHelpMarketingAttribute = sap.ui.xmlfragment("cus.crm.myaccounts.view.maintain.ValueHelpMarketingAttribute", this);
					this.valueHelpMarketingAttribute.oMktAttribute = M;
					var f = [];
					if (M.attributeSetID && this.byId("attributeSetCol").getVisible()) {
						f.push(new sap.ui.model.Filter("attributeSetID", sap.ui.model.FilterOperator.EQ, M.attributeSetID));
					} else if (a) {
						f.push(new sap.ui.model.Filter("category", sap.ui.model.FilterOperator.EQ, a));
					}
					this.valueHelpMarketingAttribute.bindAggregation("items", {
						path: '/CustomizingMarketingAttributeCollection',
						template: this.valueHelpMarketingAttribute.getItems()[0].clone(),
						filters: f,
						sorter: new sap.ui.model.Sorter("attribute", false)
					});
					this.valueHelpMarketingAttribute.setModel(this.getList().getModel("i18n"), "i18n");
					this.valueHelpMarketingAttribute.setModel(this.getView().getModel());
					this.getView().getModel().attachRequestSent(function() {
						if (this._list) {
							this._list.setNoDataText(cus.crm.myaccounts.util.Util.geti18NText("LOADING_TEXT"));
						}
					}, this.valueHelpMarketingAttribute);
					this.getView().getModel().attachRequestCompleted(function() {
						if (this._list) {
							this._list.setNoDataText(cus.crm.myaccounts.util.Util.geti18NText("NO_DATA_TEXT"));
						}
					}, this.valueHelpMarketingAttribute);
					this.valueHelpMarketingAttribute.open();
				},
				onMarketingAttributeValueHelpSearch: function(e) {
					var s = e.getParameter("value");
					jQuery.sap.log.debug(
						"cus.crm.myaccounts.view.overview.MarketingAttributes - onMarketingAttributeValueHelpSearch - Search value: " + s);
					var f = new sap.ui.model.Filter("attribute", sap.ui.model.FilterOperator.Contains, s);
					e.getSource().getBinding("items").filter([f]);
				},
				onMarketingAttributeValueHelpClose: function(e) {
					jQuery.sap.log.debug("cus.crm.myaccounts.view.overview.MarketingAttributes - onMarketingAttributeValueHelpClose");
					var s = e.getParameter("selectedItem");
					if (s) {
						var S = s.getBindingContext().getObject();
						var m = this.valueHelpMarketingAttribute.oMktAttribute;
						m.mktAttrValues = null;
						m.valueID = "";
						m.value = "";
						this._copyAttributesOfObject2ToObject1(m, S);
						this._readAttributeValuesForSelect(m);
					}
				},
				onMarketingAttributeValueHelpCancel: function(e) {
					jQuery.sap.log.debug("cus.crm.myaccounts.view.overview.MarketingAttributes - onMarketingAttributeValueHelpCancel");
					if (e.getSource().getBinding("items").aFilters.length) {
						e.getSource().destroyItems();
					}
				},
				onMarketingAttributeSetValueHelpSelected: function(e) {
					jQuery.sap.log.debug("cus.crm.myaccounts.view.overview.MarketingAttributes - onMarketingAttributeSetValueHelpSelected");
					var m = this.getView().getModel();
					var b = this.getView().getBindingContext();
					var a = m.getProperty(b.sPath).category;
					this.valueHelpMarketingAttributeSet = sap.ui.xmlfragment("cus.crm.myaccounts.view.maintain.ValueHelpMarketingAttributeSet", this);
					this.valueHelpMarketingAttributeSet.mktAttrContextPath = e.getSource().getBindingContext("mktattr").sPath;
					this.valueHelpMarketingAttributeSet.oMktAttribute = e.getSource().getBindingContext("mktattr").getObject();
					var f = [];
					if (a) {
						f.push(new sap.ui.model.Filter("category", sap.ui.model.FilterOperator.EQ, a));
					}
					this.valueHelpMarketingAttributeSet.bindAggregation("items", {
						path: '/CustomizingMarketingAttrSetCollection',
						template: this.valueHelpMarketingAttributeSet.getItems()[0].clone(),
						filters: f,
						sorter: new sap.ui.model.Sorter("attributeSet", false)
					});
					this.valueHelpMarketingAttributeSet.setModel(this.getList().getModel("i18n"), "i18n");
					this.valueHelpMarketingAttributeSet.setModel(this.getView().getModel());
					this.getView().getModel().attachRequestSent(function() {
						if (this._list) {
							this._list.setNoDataText(cus.crm.myaccounts.util.Util.geti18NText("LOADING_TEXT"));
						}
					}, this.valueHelpMarketingAttributeSet);
					this.getView().getModel().attachRequestCompleted(function() {
						if (this._list) {
							this._list.setNoDataText(cus.crm.myaccounts.util.Util.geti18NText("NO_DATA_TEXT"));
						}
					}, this.valueHelpMarketingAttributeSet);
					this.valueHelpMarketingAttributeSet.open();
				},
				onMarketingAttributeSetValueHelpSearch: function(e) {
					var s = e.getParameter("value");
					jQuery.sap.log.debug(
						"cus.crm.myaccounts.view.overview.MarketingAttributes - onMarketingAttributeSetValueHelpSearch - Search value: " + s);
					var f = new sap.ui.model.Filter("attributeSet", sap.ui.model.FilterOperator.Contains, s);
					e.getSource().getBinding("items").filter([f]);
				},
				onMarketingAttributeSetValueHelpClose: function(e) {
					jQuery.sap.log.debug("cus.crm.myaccounts.view.overview.MarketingAttributes - onMarketingAttributeSetValueHelpClose");
					var s = e.getParameter("selectedItem");
					if (s) {
						var S = this._generateTemplateForMarketingAttribute(s.getBindingContext().getObject());
						var m = this.valueHelpMarketingAttributeSet.oMktAttribute;
						if (S.attributeSetID === m.attributeSetID) return;
						this._copyAttributesOfObject2ToObject1(m, S);
						m.mode = cus.crm.myaccounts.util.Constants.modeEdit;
						this.refreshUI();
					}
				},
				onMarketingAttributeSetValueHelpCancel: function(e) {
					jQuery.sap.log.debug("cus.crm.myaccounts.view.overview.MarketingAttributes - onMarketingAttributeSetValueHelpCancel");
					if (e.getSource().getBinding("items").aFilters.length) {
						e.getSource().destroyItems();
					}
				},
				getFooterButtons: function() {
					var t = this;
					return [{
						sIcon: "sap-icon://add",
						sTooltip: cus.crm.myaccounts.util.Util.geti18NText("ADD_MARKETING_ATTRIBUTE_TOOLTIP"),
						sId: "addButton",
						onBtnPressed: function() {
							t.onAddMarketingAttributeClicked();
						}
					}];
				},
				_unsavedDataExists: function() {
					var m = this.getList().getModel("mktattr");
					var M = m.getProperty("/MarketingAttributes");
					for (var i in M) {
						var o = M[i];
						if (this._checkSaveNeeded(o)) {
							return true;
						}
					}
					return false;
				},
				onBeforeClose: function(c) {
					jQuery.sap.log.debug("cus.crm.myaccounts.view.overview.MarketingAttributes - onBeforeClose");
					var t = this;
					if (this._unsavedDataExists()) {
						sap.m.MessageBox.confirm(cus.crm.myaccounts.util.Util.geti18NText("MSG_CONFIRM_CANCEL"), jQuery.proxy(function(a) {
							if (a === "OK") {
								t.getList().getModel("mktattr").setProperty("/MarketingAttributes", []);
								t.getView().setBindingContext(null);
								c.call();
							}
						}, this));
						return false;
					}
					return true;
				},
				onCleanUp: function() {
					jQuery.sap.log.debug("cus.crm.myaccounts.view.overview.MarketingAttributes - onCleanUp");
					this.aBatchOperations = [];
					var m = this.getList().getModel("mktattr");
					if (!m) return;
					var M = m.getProperty("/MarketingAttributes");
					for (var i in M) {
						var o = M[i];
						if (o.mode === cus.crm.myaccounts.util.Constants.modeEdit) {
							if (this._checkSaveNeeded(o)) {
								this.getList().getModel("mktattr").setProperty("/MarketingAttributes", []);
								this.getView().setBindingContext(null);
								return;
							} else {
								delete o.mode;
								o.errorExists = false;
								this._setUIFieldType(o);
							}
						}
					}
					this.refreshUI();
				}
			});
		},
		"cus/crm/myaccounts/view/overview/MarketingAttributes.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core" xmlns:mvc="sap.ui.core.mvc" xmlns="sap.m" xmlns:layout="sap.ui.layout"\n\t\t\tcontrollerName="cus.crm.myaccounts.view.overview.MarketingAttributes" xmlns:html="http://www.w3.org/1999/xhtml">\n\n\t<Table\n\t\tid="list"\n\t\tgrowing="true"\n\t\tgrowingThreshold="10"\n\t\tgrowingScrollToLoad="false"\n\t\titems="{path: \'mktattr>/MarketingAttributes\'}">\n\t\t<columns>\n\t\t\t<Column id="attributeSetCol" width="16rem" minScreenWidth="Small" demandPopin="true" visible="false"><Label text="{i18n>ATTRIBUTESET}"/></Column>\n\t\t\t<Column id="attributeCol" width="16rem" minScreenWidth="Small" demandPopin="true"><Label text="{i18n>ATTRIBUTE}" /></Column>\n\t\t\t<Column id="valueCol" width="16rem" minScreenWidth="Medium" demandPopin="true"><Label text="{i18n>VALUE}" /></Column>\n\t\t\t<Column id="actions" width="3rem" minScreenWidth="XLarge" demandPopin="true"><Text text="{i18n>ACTIONS}" /></Column>\n\t\t</columns>\n\t\t<items>\n\t\t\t<ColumnListItem id="columnListItem">\n\t\t\t\t<cells>\n\t\t\t\t\t<Input value="{mktattr>attributeSet}"\n\t\t\t\t\t\tid="attributeSetInput"\n\t\t\t\t\t\teditable="{parts:[{path:\'mktattr>eTag\'}],formatter:\'cus.crm.myaccounts.util.formatter.isInitial\'}"\n\t\t\t\t\t\tshowValueHelp="true"\n\t\t\t\t\t\tvalueHelpOnly="false"\n\t\t\t\t\t\tvalueHelpRequest="onMarketingAttributeSetValueHelpSelected"\n\t\t\t\t\t\tshowSuggestion="true"\n\t\t\t\t\t\tsuggest="onSuggestItem"\n\t\t\t\t\t\tsuggestionItemSelected="onSuggestItemSelected"\n\t\t\t\t\t\twidth="75%"/>\n\t\t\t\t\t<Input value="{mktattr>attribute}"\n\t\t\t\t\t\tid="attributeInput"\n\t\t\t\t\t\teditable="{parts:[{path:\'mktattr>eTag\'}],formatter:\'cus.crm.myaccounts.util.formatter.isInitial\'}"\n\t\t\t\t\t\tshowValueHelp="true"\n\t\t\t\t\t\tvalueHelpOnly="false"\n\t\t\t\t\t\tvalueHelpRequest="onMarketingAttributeValueHelpSelected"\n\t\t\t\t\t\tshowSuggestion="true"\n\t\t\t\t\t\tsuggest="onSuggestItem"\n\t\t\t\t\t\tsuggestionItemSelected="onSuggestItemSelected"\n\t\t\t\t\t\twidth="75%"/>\n\n\t\t\t\t\t<layout:VerticalLayout width="100%">\n\t\t\t\t\t\t<!-- <core:Icon src="sap-icon://alert" color="#cc1919" size="1.3rem" visible="{parts:[{path:\'mktattr>errorExists\'}],formatter:\'cus.crm.myaccounts.util.formatter.isNotInitial\'}"/>  -->\n\t\t\t\t\t\t<Input value="{mktattr>valueID}"\n\t\t\t\t\t\t\tvisible="false"/>\n\n\t\t\t\t\t\t<!-- Default Input Field -->\n\t\t\t\t\t\t<Input id="valueInput"\n\t\t\t\t\t\t\tvalue="{parts:[{path:\'mktattr>valueID\'}, {path:\'mktattr>value\'}, {path:\'mktattr>attributeDatatype\'}, {path:\'mktattr>decimalPlaces\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatMktAttrDisplayField\'}"\n\t\t\t\t\t\t\teditable="{parts:[{path:\'mktattr>mode\'}, \'constants>/modeEdit\'],formatter:\'cus.crm.myaccounts.util.formatter.isEqual\'}"\n\t\t\t\t\t\t\tvisible="{parts:[{path:\'mktattr>fieldType\'}, \'constants>/fieldInput\'],formatter:\'cus.crm.myaccounts.util.formatter.isEqual\'}"\n\t\t\t\t\t\t\tliveChange="onInputFieldChanged"\n\t\t\t\t\t\t\tmaxLength="30"\n\t\t\t\t\t\t\twidth="75%"/>\n\n\t\t\t\t\t\t<!-- Date Field -->\n\t\t\t\t\t\t<DatePicker value="{path:\'mktattr>dateValue\', type:\'sap.ui.model.type.Date\', formatOptions: { style: \'medium\'}}"\n\t\t\t\t\t\t\tid="valueDATEInput"\n\t\t\t\t\t\t\teditable="{parts:[{path:\'mktattr>mode\'}, \'constants>/modeEdit\'],formatter:\'cus.crm.myaccounts.util.formatter.isEqual\'}"\n\t\t\t\t\t\t\tvisible="{parts:[{path:\'mktattr>fieldType\'}, \'constants>/fieldDate\'],formatter:\'cus.crm.myaccounts.util.formatter.isEqual\'}"\n\t\t\t\t\t\t\tchange="onDateInputFieldChanged"\n\t\t\t\t\t\t\tdisplayFormat="medium"\n\t\t\t\t\t\t\twidth="75%"/>\n\n\t\t\t\t\t\t<!-- Currency Field -->\n\t\t\t\t\t\t<Input id="valueCURRInput"\n\t\t\t\t\t\t\tvalue="{parts:[ {path:\'mktattr>valueID\'}, {path:\'mktattr>decimalPlaces\'}, {path:\'mktattr>currency\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatMktAttrAmountInterval\'}"\n\t\t\t\t\t\t\teditable="{parts:[{path:\'mktattr>mode\'}, \'constants>/modeEdit\'],formatter:\'cus.crm.myaccounts.util.formatter.isEqual\'}"\n\t\t\t\t\t\t\tvisible="{parts:[{path:\'mktattr>fieldType\'}, \'constants>/fieldCurrency\'],formatter:\'cus.crm.myaccounts.util.formatter.isEqual\'}"\n\t\t\t\t\t\t\tchange="onInputFieldChanged"\n\t\t\t\t\t\t\twidth="75%"/>\n\n\t\t\t\t\t\t<!-- Time Field -->\n\t\t\t\t\t\t<DateTimeInput type="Time"\n\t\t\t\t\t\t\tvalue="{parts:[ {path:\'mktattr>value\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatMktAttrTime\'}"\n\t\t\t\t\t\t\tid="valueTIMEInput"\n\t\t\t\t\t\t\teditable="{parts:[{path:\'mktattr>mode\'}, \'constants>/modeEdit\'],formatter:\'cus.crm.myaccounts.util.formatter.isEqual\'}"\n\t\t\t\t\t\t\tvisible="{parts:[{path:\'mktattr>fieldType\'}, \'constants>/fieldTime\'],formatter:\'cus.crm.myaccounts.util.formatter.isEqual\'}"\n\t\t\t\t\t\t\tchange="onTimeInputFieldChanged"\n\t\t\t\t\t\t\twidth="75%"/>\n\n\t\t\t\t\t\t<!-- Select for edit mode -->\n\t\t\t\t\t\t<!-- Used for CHAR, NUM, CURR, DATE, TIME, CHEC -->\n\t\t\t\t\t\t<Select id="select"\n\t\t\t\t\t\t\titems="{path:\'mktattr>mktAttrValues\'}"\n\t\t\t\t\t\t\tselectedKey="{mktattr>valueID}"\n\t\t\t\t\t\t\tenabled="true"\n\t\t\t\t\t\t\tchange="onSelectValueChanged"\n\t\t\t\t\t\t\tvisible="{parts:[{path:\'mktattr>fieldType\'}, \'constants>/fieldSelect\'],formatter:\'cus.crm.myaccounts.util.formatter.isEqual\'}"\n\t\t\t\t\t\t\twidth="75%">\n\t\t\t\t\t\t\t<core:Item \tkey="{mktattr>valueID}" \n\t\t\t\t\t\t\t\t\t\ttext="{mktattr>value}"/>\n\t\t\t\t\t\t</Select>\n\t\t\t\t\t</layout:VerticalLayout>\n\n\t\t\t\t\t<layout:HorizontalLayout>\n\t\t\t\t\t\t<core:Icon src="sap-icon://edit" id="actionEdit" size="1.3rem" press="onEditMarketingAttributeClicked" visible="{parts:[{path:\'mktattr>mode\'}, \'constants>/modeEdit\'],formatter:\'cus.crm.myaccounts.util.formatter.isUnequal\'}"/>\n\t\t\t\t\t\t<core:Icon src="sap-icon://save" id="actionSave" size="1.3rem" press="onSaveMarketingAttributeClicked" visible="{parts:[{path:\'mktattr>mode\'}, \'constants>/modeEdit\'],formatter:\'cus.crm.myaccounts.util.formatter.isEqual\'}"/>\n\t\t\t\t\t\t<layout:HorizontalLayout class="cusMyAccountsPaddingLeft" />\n\t\t\t\t\t\t<core:Icon src="sap-icon://delete" id="actionDelete" size="1.3rem"  press="onDeleteMarketingAttributeClicked" visible="true"/>\n\t\t\t\t\t</layout:HorizontalLayout>\n\n\t\t\t\t</cells>\n\t\t\t</ColumnListItem>\n\t\t</items>\n\t</Table>\n</core:View>\n',
		"cus/crm/myaccounts/view/overview/Notes.controller.js": function() {
			jQuery.sap.require("sap.ca.ui.message.message");
			sap.ui.controller("cus.crm.myaccounts.view.overview.Notes", {
				onInit: function() {},
				getList: function() {
					return this.byId("Notes");
				},
				onItemSelected: function() {
					this.byId("noteInput").setValue("");
				},
				onSubViewLiveSearch: function(s) {
					var b = this.getList().getBinding("items");
					var f = [];
					if (s !== "") {
						var S = s.split(" ");
						for (var i in S) f.push(new sap.ui.model.Filter("content", sap.ui.model.FilterOperator.Contains, S[i]));
					}
					if (b) b.filter(f);
				},
				onAddNote: function(e) {
					var t, v, m, a = "",
						n, c;
					t = e.getParameter("value");
					t = jQuery.trim(t);
					if (t.length === 0) {
						return;
					}
					v = this.getView();
					m = this.getView().getModel();
					n = {
						"tdname": a,
						"tdid": "",
						"tdspras": "",
						"content": t,
						"createdAt": null,
						"creator": ""
					};
					c = v.getBindingContext();
					var N = jQuery.proxy(function(E) {
						var M = "";
						if (E.response) {
							M = jQuery.parseJSON(E.response.body).error.message.value;
						}
						sap.ca.ui.message.showMessageBox({
							type: sap.ca.ui.message.Type.ERROR,
							message: M
						});
					}, this);
					m.create("Notes", n, c, undefined, N);
					if (sap.ui.Device.system.phone || (sap.ui.Device.system.tablet && !sap.ui.Device.system.desktop)) {
						var l = this.getList();
						var b = l.getBinding("items");
						var r = null;
						r = jQuery.proxy(function() {
							l.focus();
							b.detachDataReceived(r);
						}, this);
						b.attachDataReceived(r);
					}
				}
			});
		},
		"cus/crm/myaccounts/view/overview/Notes.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core" xmlns:mvc="sap.ui.core.mvc" xmlns="sap.m"\n\t\t\tcontrollerName="cus.crm.myaccounts.view.overview.Notes" xmlns:html="http://www.w3.org/1999/xhtml">\n\n\t<FeedInput \n\t    id="noteInput"\n\t    post="onAddNote"\n\t    showIcon="false"\n\t    maxLength="1000"\n\t    placeholder="{i18n>NEW_NOTE}" />\n\t<List id="Notes"\n\t\tgrowing="true"\n\t\tgrowingScrollToLoad="false"\n\t\tgrowingThreshold="10" \n\t\titems="{Notes}" >\n\t\t<FeedListItem\n\t\t\ttext="{content}"\n\t\t\tsender="{creator}"\n\t\t\ttimestamp="{path:\'createdAt\', formatter:\'cus.crm.myaccounts.util.formatter.formatMediumDateTime\'}"\n\t\t\tsenderActive="false"\n\t\t\ticonActive="false"\n\t\t\ticonDensityAware="false"\n\t\t\tshowIcon="false" />\n\t</List>\n\n</core:View>',
		"cus/crm/myaccounts/view/overview/Opportunities.controller.js": function() {
			sap.ui.controller("cus.crm.myaccounts.view.overview.Opportunities", {
				onInit: function() {
					this.resourceBundle = sap.ca.scfld.md.app.Application.getImpl().AppI18nModel.getResourceBundle();
				},
				onOpportunityDescriptionLinkClicked: function(e) {
					this._navToOpportunity(e);
				},
				onEditOpportunityClicked: function(e) {
					var g = e.getSource().getBindingContext().getObject().Guid;
					var f = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService;
					var c = f && f("CrossApplicationNavigation");
					if (c) {
						c.toExternal({
							target: {
								semanticObject: "Opportunity",
								action: "manageOpportunity&/edit/Opportunities(guid'" + g + "')"
							}
						});
					}
				},
				onMainContactLinkClicked: function(e) {
					this._showBusinessCard(e);
				},
				_navToOpportunity: function(e) {
					var g = e.getSource().getBindingContext().getObject().Guid;
					var f = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService;
					var c = f && f("CrossApplicationNavigation");
					if (c) {
						c.toExternal({
							target: {
								semanticObject: "Opportunity",
								action: "manageOpportunity&/display/Opportunities(guid'" + g + "')"
							}
						});
					}
				},
				_showBusinessCard: function(e) {
					var c = e.getSource().getBindingContext().sPath;
					var m = this.getView().getModel();
					var C = m.getProperty(c + "/MainContact");
					var a = this.getView().getBindingContext().getObject();
					var t = this;
					if (C.accountID === a.accountID) {
						cus.crm.myaccounts.util.Util.openQuickoverview(this.resourceBundle.getText("CONTACT_TITLE"), m.getProperty(c +
								"/MainContact/fullName"), m.getProperty(c + "/MainContact/function"), cus.crm.myaccounts.util.formatter.pictureUrlFormatter(
								m.getProperty(c + "/MainContact/Photo/__metadata/media_src")), e.getSource().getBindingContext(), "MainContact",
							"WorkAddress", this.getView().getBindingContext(), "MainAddress", e.getSource(),
							function() {
								t._navToContact(m.getProperty(c + "/MainContact"));
							});
					} else {
						sap.m.MessageToast.show(cus.crm.myaccounts.util.Util.geti18NText("MSG_NOT_IN_MAIN_CONTACT"));
					}
				},
				_navToContact: function(c) {
					var a = c.contactID;
					var b = c.accountID;
					var f = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService;
					var C = f && f("CrossApplicationNavigation");
					if (C) {
						C.toExternal({
							target: {
								semanticObject: "ContactPerson",
								action: "MyContacts&/display/ContactCollection(contactID='" + a + "',accountID='" + b + "')"
							}
						});
					}
				},
				getList: function() {
					return this.byId("list");
				},
				onSubViewLiveSearch: function(s) {
					var b = this.getList().getBinding("items");
					var f = [];
					if (s !== "") f.push(new sap.ui.model.Filter("description", sap.ui.model.FilterOperator.Contains, s));
					if (b) b.filter(f);
				},
				onInitPersonalization: function() {
					var t = this.getList();
					return {
						tablePersonalization: {
							table: t
						}
					};
				},
				onStoreCurrentStateSupported: function() {
					return true;
				},
				onStoreCurrentState: function(s) {
					s.contextPath = "";
					var b = sap.ui.getCore().getEventBus();
					s.onRefreshContextPath = function(c, e, d) {
						if (s.action !== "refreshList") {
							s.action = "refreshContextPath";
							s.contextPath = d.contextPath.replace("Opportunities", "OpportunityCollection");
						}
					};
					s.onRefreshList = function() {
						s.action = "refreshList";
					};
					b.subscribe("cus.crm.opportunity", "opportunityChanged", s.onRefreshContextPath, s);
					b.subscribe("cus.crm.opportunity", "followUpOpportunityCreated", s.onRefreshList, s);
					b.subscribe("cus.crm.opportunity", "contactAdded", s.onRefreshContextPath, s);
					b.subscribe("cus.crm.opportunity", "contactDeleted", s.onRefreshContextPath, s);
					b.subscribe("cus.crm.mycontacts", "contactChanged", s.onRefreshList, s);
					b.subscribe("cus.crm.opportunity", "opportunityCreated", s.onRefreshList, s);
					s.onExit = function() {
						var b = sap.ui.getCore().getEventBus();
						b.unsubscribe("cus.crm.opportunity", "opportunityChanged", s.onRefreshContextPath, s);
						b.unsubscribe("cus.crm.opportunity", "followUpOpportunityCreated", s.onRefreshList, s);
						b.unsubscribe("cus.crm.opportunity", "contactAdded", s.onRefreshContextPath, s);
						b.unsubscribe("cus.crm.opportunity", "contactDeleted", s.onRefreshContextPath, s);
						b.unsubscribe("cus.crm.mycontacts", "contactChanged", s.onRefreshList, s);
						b.unsubscribe("cus.crm.opportunity", "opportunityCreated", s.onRefreshList, s);
					};
				},
				onRestoreCurrentState: function(s) {
					if (s.action === "refreshList") this.getView().getBindingContext().getModel().refresh();
					else if (s.action === "refreshContextPath") {
						var r = cus.crm.myaccounts.util.Util.getRefreshUIObject(this.getView().getModel(), "/" + s.contextPath,
							"MainContact,MainContact/Photo");
						r.refresh();
					}
				},
				getFooterButtons: function() {
					var t = this;
					return [{
						sIcon: "sap-icon://add",
						sTooltip: cus.crm.myaccounts.util.Util.geti18NText("ADD_OPPORTUNITY_TOOLTIP"),
						onBtnPressed: function() {
							t.onCreateOpportunity();
						}
					}];
				},
				onCreateOpportunity: function() {
					var d = this.getView().getModel();
					var t = this;
					var s = function(r) {
						var p;
						if (!t.processTypeModel) {
							p = r["CustomizingOpportunityTypeCollection"];
							t.processTypeModel = new sap.ui.model.json.JSONModel();
							t.processTypeModel.setProperty("/TransactionTypeSet", p);
						} else {
							p = t.processTypeModel.getProperty("/TransactionTypeSet");
						}
						if (p.length === 1) {
							var a = p[0].processTypeCode;
							t._navigateToCreationOfOpportunity(a);
						} else {
							t.oProcessTypeDialog = sap.ui.xmlfragment("cus.crm.myaccounts.view.overview.ProcessTypeDialog", t);
							t.oProcessTypeDialog.setModel(t.getView().getModel("i18n"), "i18n");
							t.oProcessTypeDialog.setModel(t.processTypeModel, "processTypes");
							t.oProcessTypeDialog.open();
						}
					};
					var h = function(e) {
						if (e.code === "/IWFND/CM_BEC/026") {
							e.message = cus.crm.myaccounts.util.Util.geti18NText("MSG_NO_OPPORTUNITY_TRANSACTION_TYPES");
							e.details = "";
							sap.ca.ui.message.showMessageBox(e);
						}
					};
					if (t.processTypeModel) s.call(t);
					else cus.crm.myaccounts.util.Util.sendBatchReadRequests(d, ["CustomizingOpportunityTypeCollection"], s, h);
				},
				selectProcess: function(e) {
					var p = "";
					var s = e.getParameter("selectedItem");
					if (s) {
						p = s.data("ProcessTypeCode");
					}
					this._navigateToCreationOfOpportunity(p);
				},
				_navigateToCreationOfOpportunity: function(p) {
					var f = sap.ushell.Container.getService;
					var c = f("CrossApplicationNavigation");
					var a = this.getView().getBindingContext().sPath.substring(1);
					c.toExternal({
						target: {
							semanticObject: "Opportunity",
							action: "manageOpportunity&/NewOpportunityFromAccount/" + p + "/" + a
						}
					});
				},
				searchProcess: function(e) {
					var i = e.getParameter("itemsBinding");
					var I;
					this.oProcessTypeDialog.setNoDataText(cus.crm.myaccounts.util.Util.geti18NText("LOADING_TEXT"));
					var s = e.getParameter("value");
					if (s !== undefined) {
						I = i.filter([new sap.ui.model.Filter("processTypeDescription", sap.ui.model.FilterOperator.Contains, s)]);
						if (I.getLength() === 0) {
							this.oProcessTypeDialog.setNoDataText(cus.crm.myaccounts.util.Util.geti18NText("NO_DATA_TEXT"));
						}
					}
				}
			});
		},
		"cus/crm/myaccounts/view/overview/Opportunities.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core" xmlns:mvc="sap.ui.core.mvc" xmlns="sap.m" xmlns:layout="sap.ui.layout"\n\t\t\tcontrollerName="cus.crm.myaccounts.view.overview.Opportunities" xmlns:html="http://www.w3.org/1999/xhtml">\n\n\t<Table\n   \t\tid="list"\n\t\tmode="{device>/listMode}"\n\t\tgrowing="true"\n         \tgrowingThreshold="10"\n         \tgrowingScrollToLoad="false"\n         \titems="{path:\'Opportunities\',\n         \t\t\tparameters: {expand: \'MainContact,MainContact/Photo\'}}"> \n        <columns>\n          <Column id="descriptionCol" width="16rem" minScreenWidth="Small" demandPopin="true"><Label text="{i18n>DESCRIPTION}" /></Column>\n          <Column id="mainContactCol" width="16rem" minScreenWidth="Medium" demandPopin="true"><Label text="{i18n>MAIN_CONTACT}" /></Column>\n          <Column id="volumeCol" width="8rem" minScreenWidth="Large" demandPopin="true"><Label text="{i18n>VOLUME}" /></Column>\n          <Column id="probabilityCol" width="8rem" minScreenWidth="Large" demandPopin="true"><Label text="{i18n>PROBABILITY}" /></Column>\n          <Column id="closingDate" width="12rem" minScreenWidth="XLarge" demandPopin="true"><Label text="{i18n>CLOSE_BY}" /></Column>\n          <Column id="statusCol" width="12rem" minScreenWidth="XXLarge" demandPopin="true"><Label text="{i18n>STATUS}" /></Column>\n          <!-- <Column id="actions" width="3rem" minScreenWidth="Desktop" demandPopin="true"><Text text="{i18n>ACTIONS}" /></Column> -->\n        </columns>\n        <items>\n        \t<ColumnListItem id="columnListItem">\n            \t<cells>\n            \t\n\t\t\t\t\t<VBox>\n\t\t\t\t\t\t<items>\n          \t\t\t\t\t\t<Link text="{description}" press="onOpportunityDescriptionLinkClicked"/>\n          \t\t\t\t\t\t<Label text="{objectId}" />\n          \t\t\t\t\t</items>\n          \t\t\t\t\t<layoutData>\n\t\t\t\t            <layout:GridData span="L12 M12 S12"/>\n\t\t\t\t        </layoutData>\n         \t\t\t\t</VBox>\n         \t\t\t\t\n         \t\t\t\t<layout:Grid class="gridMarginTop" defaultSpan="L3 M3 S6" hSpacing="0" vSpacing="0">\n            \t\t\t<layout:content>\n\t\t\t\t\t\t\t<core:Icon \n\t\t\t\t\t\t\t\tsrc="{path:\'MainContact/Photo/__metadata/media_src\', formatter: \'cus.crm.myaccounts.util.formatter.pictureUrlFormatter\'}"\n\t\t\t\t\t\t\t\tvisible="{parts:[{path:\'MainContact/contactID\'}, {path:\'MainContact/Photo/__metadata/media_src\'}], formatter:\'cus.crm.myaccounts.util.formatter.standardIconVisibilityFormatter\'}"\n            \t\t\t\t\tsize="2.5rem">\n\t\t\t\t\t\t     </core:Icon>\n\t\t\t\t\t\t     <Image \n\t\t\t\t\t\t\t\tsrc="{path:\'MainContact/Photo/__metadata/media_src\', formatter:\'cus.crm.myaccounts.util.formatter.pictureUrlFormatter\'}"\n\t\t\t\t\t\t\t\tvisible="{path:\'MainContact/Photo/__metadata/media_src\', formatter:\'cus.crm.myaccounts.util.formatter.logoVisibilityFormatter\'}" \n\t\t\t\t\t\t\t\theight="2.5rem" \n\t\t\t\t\t\t\t\twidth="2.5rem">\n\t\t\t\t\t\t\t</Image>\n\t\t\t\t\t\t\t<VBox>\n\t\t\t\t\t\t\t\t<items>\n            \t\t\t\t\t\t<Link text="{MainContact/fullName}" press="onMainContactLinkClicked"/>\n            \t\t\t\t\t\t<Label text="{MainContact/function}" />\n            \t\t\t\t\t</items>\n            \t\t\t\t\t<layoutData>\n\t\t\t\t\t\t            <layout:GridData span="L8 M8 S8"/>\n\t\t\t\t\t\t        </layoutData>\n           \t\t\t\t\t</VBox>\t\t\t\t\t\t\t  \n            \t\t\t</layout:content>\n            \t\t</layout:Grid>\n         \t\t\t\t\n         \t\t\t\t<Text text="{parts:[{path: \'expRevenue\'}, {path: \'currency\'}],  formatter:\'cus.crm.myaccounts.util.formatter.formatAmounts\'}"/>\n         \t\t\t\t\n         \t\t\t\t<Text text="{path: \'probability\', formatter: \'cus.crm.myaccounts.util.formatter.formatProbability\'}"/>\n         \t\t\t\t\n         \t\t\t\t<Text text="{parts:[{path:\'closingDate\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatMediumDate\' }"/>\n         \t\t\t\t\n         \t\t\t\t<ObjectStatus text="{statusText}" state="{path:\'status\', formatter:\'cus.crm.myaccounts.util.formatter.formatStatusText\'}"/>\n         \t\t\t\t<!--\n         \t\t\t\t<layout:HorizontalLayout>\n\t\t\t\t        \t<core:Icon src="sap-icon://edit" size="1.3rem" press="onEditOpportunityClicked"/>\n\t\t\t            </layout:HorizontalLayout>\n\t\t\t            -->\n\t\t              \n\t\t         </cells>\n        \t</ColumnListItem>\n    \t</items>\n   \t</Table>\n\n</core:View>',
		"cus/crm/myaccounts/view/overview/OverviewPage.controller.js": function() {
			jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");
			jQuery.sap.require("cus.crm.myaccounts.util.formatter");
			jQuery.sap.require("cus.crm.myaccounts.util.Util");
			jQuery.sap.require("sap.collaboration.components.fiori.sharing.attachment.Attachment");
			jQuery.sap.require("sap.ui.core.Item");
			jQuery.sap.require("sap.ca.ui.utils.TablePersonalizer");
			jQuery.sap.require("sap.m.TablePersoDialog");
			sap.ca.scfld.md.controller.BaseFullscreenController.extend("cus.crm.myaccounts.view.overview.OverviewPage", {
				configurationMode: false,
				onInit: function() {
					this.EHP2Backend = cus.crm.myaccounts.util.Util.getServiceSchemaVersion(this.getView().getModel(), "AccountCollection") < 1;
					this.liveChangeTimer = 0;
					this.oContext = null;
					this.oTabConfigurationModel = new sap.ui.model.json.JSONModel({
						"Tabs": [{
							"key": "general",
							"viewName": "cus.crm.myaccounts.view.overview.GeneralData",
							"name": cus.crm.myaccounts.util.Util.geti18NText("GENERAL_DATA"),
							"viewInstance": undefined,
							"searchString": undefined,
							"service": undefined,
							"hidden": undefined,
							"tablePersoController": undefined
						}, {
							"key": "marketingattributes",
							"viewName": "cus.crm.myaccounts.view.overview.MarketingAttributes",
							"name": cus.crm.myaccounts.util.Util.geti18NText("MARKETINGATTRIBUTES")
						}, {
							"key": "contacts",
							"viewName": "cus.crm.myaccounts.view.overview.Contacts",
							"name": cus.crm.myaccounts.util.Util.geti18NText("CONTACTS")
						}, {
							"key": "appointments",
							"viewName": "cus.crm.myaccounts.view.overview.Appointments",
							"name": cus.crm.myaccounts.util.Util.geti18NText("APPOINTMENTS")
						}, {
							"key": "tasks",
							"viewName": "cus.crm.myaccounts.view.overview.Tasks",
							"name": cus.crm.myaccounts.util.Util.geti18NText("TASKS")
						}, {
							"key": "attachments",
							"viewName": "cus.crm.myaccounts.view.overview.Attachments",
							"name": cus.crm.myaccounts.util.Util.geti18NText("ATTACHMENTS")
						}, {
							"key": "notes",
							"viewName": "cus.crm.myaccounts.view.overview.Notes",
							"name": cus.crm.myaccounts.util.Util.geti18NText("NOTES")
						}, {
							"key": "leads",
							"viewName": "cus.crm.myaccounts.view.overview.Leads",
							"name": cus.crm.myaccounts.util.Util.geti18NText("LEADS")
						}, {
							"key": "opportunities",
							"viewName": "cus.crm.myaccounts.view.overview.Opportunities",
							"name": cus.crm.myaccounts.util.Util.geti18NText("OPPORTUNITIES")
						}, {
							"key": "quotations",
							"viewName": "cus.crm.myaccounts.view.overview.Quotations",
							"name": cus.crm.myaccounts.util.Util.geti18NText("QUOTATIONS"),
							"service": "ERP_BUPA_ODATA"
						}, {
							"key": "salesorders",
							"viewName": "cus.crm.myaccounts.view.overview.SalesOrders",
							"name": cus.crm.myaccounts.util.Util.geti18NText("SALES_ORDERS"),
							"service": "ERP_BUPA_ODATA"
						}]
					});
					if (this.extHookAdaptAvailableSubViews) this.extHookAdaptAvailableSubViews(this.oTabConfigurationModel.getProperty("/Tabs"));
					this._restoreCurrentState();
					this._initModelsForExternalServices();
					this.personalizationSaveRunning = false;
					this.oPersonalizationContainer = null;
					this.oTabPersonalization = null;
					this.oTabPersonalizationController = null;
					this.oTabPersonalizationDialog = null;
					this._initTabPersonalization();
					var m = this.getView().getModel();
					m.mEventRegistry["requestFailed"] = [];
					m.attachRequestFailed(this._onRequestFailed);
					this.initializeMatchedRoute();
				},
				initializeMatchedRoute: function() {
					var c = this;
					var v = this.getView();
					var m = v.getModel();
					v.setModel(this.oTabConfigurationModel, "overviewConfig");
					this.oRouter.attachRouteMatched(function(e) {
						if (jQuery.device.is.phone && (e.getParameter("name") === "S2" || e.getParameter("name") === "mainPage")) this.byId("page").scrollTo(
							0, 0);
						if (e.getParameter("name") === "detail" || e.getParameter("name") === "subdetail") {
							var a = e.getParameter("arguments");
							if (c.EHP2Backend) {
								c.oRouter.navTo("s360", {
									contextPath: a.contextPath
								}, true);
								return;
							}
							var b = '/' + a.contextPath;
							var C = new sap.ui.model.Context(m, b);
							c.oContext = C;
							var s = a.selectedTab;
							this._fillTabSelect();
							if (this._isSelectionKeyHidden(s)) s = this._getFirstSelectionKey();
							if (!s) s = this._getFirstSelectionKey();
							this._setSelectedKey(s);
							if (C.getObject()) {
								this._readMissingObjects(s);
								var h = v.byId("headerArea");
								if (h.getBindingContext() && h.getBindingContext().getPath() !== C.getPath()) {
									h.setBindingContext(undefined);
									this._resetViews();
								}
								h.setBindingContext(C);
								c._displaySubView(s);
							} else {
								var h = v.byId("headerArea");
								h.setBindingContext(undefined);
								c._displaySubView(s);
								this._resetViews();
								m.createBindingContext(b, "", {
									expand: this._getExpandForBinding(s)
								}, function() {
									h.setBindingContext(C);
									c._displaySubView(s);
								}, true);
							}
						}
					}, this);
				},
				isInConfigurationMode: function() {
					return this.configurationMode;
				},
				toggleConfigurationMode: function() {
					this.configurationMode = !this.configurationMode;
					var b = this.byId("personalizationButton");
					b.setVisible(this.configurationMode);
					var s = this._getSubViewDefinition(this._getSelectedKey());
					if (s.viewInstance && s.viewInstance.getController().onInitPersonalization && this.oPersonalizationContainer) {
						b = this.byId("subViewPersonalizationButton");
						b.setVisible(this.configurationMode);
					}
					this.setHeaderFooterOptions(this._getHeaderFooterOptions());
				},
				_getSelectedKey: function() {
					var s = this.byId("tabSelect");
					return s.getSelectedKey();
				},
				_setSelectedKey: function(s) {
					this.byId("tabSelect").setSelectedKey(s);
				},
				_getFirstSelectionKey: function() {
					var s = this.byId("tabSelect");
					var i = s.getItems();
					if (i.length) return i[0].getKey();
					else return 'general';
				},
				_isSelectionKeyHidden: function(s) {
					if (this.oTabPersonalization && this.oTabPersonalization.aColumns) {
						var t = this.oTabPersonalization.aColumns;
						for (var i in t) {
							var a = this._getKeyTabFromPersonalizationColumn(t[i]);
							if (a === s && t[i].visible === false) {
								return true;
							}
						}
					}
					return false;
				},
				_refreshTabSelect: function() {
					var s = this._getSelectedKey();
					this._fillTabSelect();
					this._setSelectedKey(s);
					if (this._getSelectedKey() === "" || this._isSelectionKeyHidden(this._getSelectedKey())) this.navigateTo(this._getFirstSelectionKey());
				},
				_fillTabSelect: function() {
					var s = this.byId("tabSelect");
					s.removeAllItems();
					if (this.oTabPersonalization && this.oTabPersonalization.aColumns) {
						var t = this.oTabPersonalization.aColumns;
						for (var i in t) {
							if (t[i].visible) {
								var a = this._getKeyTabFromPersonalizationColumn(t[i]);
								var S = this._getSubViewDefinition(a);
								if (S && !S.hidden) s.addItem(new sap.ui.core.Item({
									text: S.name,
									key: S.key
								}));
							}
						}
					} else {
						var t = this.oTabConfigurationModel.getProperty("/Tabs");
						for (var i in t) {
							var S = t[i];
							if (!S.hidden) s.addItem(new sap.ui.core.Item({
								text: S.name,
								key: S.key
							}));
						}
					}
				},
				_readMissingObjects: function(t) {
					var m = this.getView().getModel();
					var c = this.oContext;
					var e = this._getExpandForBinding(t).split(",");
					var E = [];
					for (var i in e) {
						var o = m.getProperty(c.sPath + "/" + e[i]);
						if (!o) E.push(e[i]);
					}
					var a = E.indexOf('Logo');
					if (a >= 0) E.splice(a, 1);
					if ((!m.getProperty(c.sPath + "/AccountFactsheet") || !m.getProperty(c.sPath + "/AccountFactsheet/revenueCurrentYear") || !m.getProperty(
							c.sPath + "/AccountFactsheet/revenueLastYear")) && $.inArray("AccountFactsheet", E) === -1) {
						E.push("AccountFactsheet");
					}
					if (E.length > 0) cus.crm.myaccounts.util.Util.readExpandedODataObjects(c, E.toString(), null);
				},
				_getExpandForBinding: function(t) {
					var e = ["Logo", "MainAddress", "AccountFactsheet", "ERPCustomer"];
					var s = this._getSubView(t);
					if (s && s.getController().getExpandForBinding) {
						var E = s.getController().getExpandForBinding().split(",");
						for (var i in E) {
							if ($.inArray(E[i], e) === -1) e.push(E[i]);
						}
					}
					return e.toString();
				},
				_onRequestFailed: function(e) {
					var r = jQuery.parseJSON(e.getParameter("responseText"));
					var d = r.error.innererror.Error_Resolution.SAP_Note;
					sap.ca.ui.message.showMessageBox({
						type: sap.ca.ui.message.Type.ERROR,
						message: r.error.message.value,
						details: d
					});
				},
				_getSubView: function(t) {
					var v = this._getSubViewDefinition(t);
					if (!v.viewInstance) {
						v.viewInstance = sap.ui.view({
							type: sap.ui.core.mvc.ViewType.XML,
							viewName: v.viewName
						});
						v.viewInstance.getController().oRouter = this.oRouter;
						v.viewInstance.getController().oOverviewPage = this;
					}
					return v.viewInstance;
				},
				_getSubViewDefinition: function(t) {
					var T = this.oTabConfigurationModel.getProperty("/Tabs");
					var v;
					for (var i in T) {
						v = T[i];
						if (v.key === t) {
							return v;
						}
					}
				},
				_getSubViewDefinitionByViewName: function(v) {
					var t = this.oTabConfigurationModel.getProperty("/Tabs");
					var a;
					for (var i in t) {
						a = t[i];
						if (a.viewName === v) {
							return a;
						}
					}
				},
				_resetViews: function() {
					var t = this.oTabConfigurationModel.getProperty("/Tabs");
					var v;
					for (var i in t) {
						v = t[i];
						if (v.viewInstance) {
							v.viewInstance.setBindingContext(undefined);
							var c = v.viewInstance.getController();
							if (c.onReset) c.onReset();
							v.searchString = "";
							if (c.getList) {
								var l = c.getList();
								if (l) {
									var b = l.getBinding("items");
									if (b) {
										b.filter([]);
									}
								}
							}
						}
					}
				},
				_exitViews: function() {
					var t = this.oTabConfigurationModel.getProperty("/Tabs");
					var v;
					for (var i in t) {
						v = t[i];
						if (v.viewInstance && v.viewInstance.getController().onExit) v.viewInstance.getController().onExit();
					}
				},
				_displaySubView: function(t) {
					var s = this._getSubViewDefinition(t);
					if (!s) return;
					var S = s.viewInstance;
					if (!S) S = this._getSubView(t);
					var d = this.getView().byId("detailsViewContainer");
					d.removeAllContent();
					d.addContent(S);
					this._cleanUp(S);
					this._bindView(S);
					this.setHeaderFooterOptions(this._getHeaderFooterOptions());
					var o = this.byId("subViewSearchField");
					if (S.getController().onSubViewLiveSearch || S.getController().onSubViewSearch) {
						o.setVisible(true);
						if (s.searchString) o.setValue(s.searchString);
						else o.setValue("");
					} else {
						o.setVisible(false);
					}
					this._initPersonalizationForSubView(s);
				},
				_bindView: function(v) {
					var i = "";
					if (v.getBindingContext()) {
						i = v.getBindingContext().getPath();
					}
					var c = this.byId("headerArea").getBindingContext();
					if (c && i !== c.getPath()) {
						v.setBindingContext(c);
						var a = v.getController();
						if (a.onItemSelected) {
							a.onItemSelected();
						}
					}
				},
				onDetailsViewSelectionPressed: function(e) {
					jQuery.sap.log.debug("cus.crm.myaccounts.view.overview.OverviewPage - onDetailsViewSelectionPressed");
					var s = e.getParameters().selectedItem.getKey();
					e.getSource().close();
					this._checkDataLossAndNavigate(s);
				},
				_checkDataLossAndNavigate: function(s) {
					jQuery.sap.log.debug("cus.crm.myaccounts.view.overview.OverviewPage - _checkDataLossAndNavigate");
					var c = this.getView().byId("detailsViewContainer").getContent()[0];
					var t = this;
					this._checkDataLossForCurrentSubView(function() {
						t.navigateTo(s);
					}, function() {
						var C = t._getSubViewDefinitionByViewName(c.sViewName);
						var a = t.byId("tabSelect").mEventRegistry["change"];
						t.byId("tabSelect").mEventRegistry["change"] = null;
						t._setSelectedKey(C.key);
						window.setTimeout(function() {
							t.byId("tabSelect").mEventRegistry["change"] = a;
						}, 200);
					});
				},
				_checkDataLossForCurrentSubView: function(c, a) {
					var C = this.getView().byId("detailsViewContainer").getContent()[0];
					if (C && C.getController().onBeforeClose) {
						var v = C.getController().onBeforeClose(function() {
							c.call();
						});
						if (!v) {
							if (a) a.call();
							return;
						}
					}
					c.call();
				},
				navigateTo: function(s) {
					if (!this.oContext) return;
					var p = {};
					p.contextPath = this.oContext.getPath().replace("/", "");
					p.selectedTab = s;
					this.oRouter.navTo("subdetail", p, true);
				},
				onSubViewLiveSearch: function(e) {
					if (jQuery.device.is.phone) return;
					var s = this._getSubViewDefinition(this._getSelectedKey());
					if (!s.viewInstance.getController().onSubViewLiveSearch) return;
					var d = 300;
					var a = e.getParameter("newValue");
					s.searchString = a;
					window.clearTimeout(this.liveChangeTimer);
					this.liveChangeTimer = window.setTimeout(function() {
						s.viewInstance.getController().onSubViewLiveSearch(a);
					}, d);
				},
				onSubViewSearch: function(e) {
					var s = this._getSubViewDefinition(this._getSelectedKey());
					var S = s.viewInstance.getController();
					if ((jQuery.device.is.phone || jQuery.device.is.tablet) && S.getList) S.getList().focus();
					var a = e.getParameter("query");
					s.searchString = a;
					if (S.onSubViewSearch) S.onSubViewSearch(a);
					else if (jQuery.device.is.phone && S.onSubViewLiveSearch) S.onSubViewLiveSearch(a);
				},
				_getHeaderFooterOptions: function() {
					var t = this;
					var s = 'BUTTON_SHOW_PERSONALIZATION';
					if (this.configurationMode) s = 'BUTTON_HIDE_PERSONALIZATION';
					var h = {
						aAdditionalSettingButtons: [{
							sI18nBtnTxt: s,
							onBtnPressed: function() {
								t.toggleConfigurationMode();
							}
						}],
						sI18NFullscreenTitle: "DETAIL_TITLE",
						onBack: function() {
							t.onBackButtonPressed();
						},
						oJamOptions: {
							fGetShareSettings: function() {
								return {
									object: {
										id: document.URL.replace(/&/g, "%26"),
										display: t._getShareDisplay(),
										share: t._getShareText()
									},
									externalObject: {
										appContext: "CRM",
										odataServicePath: t._getOdataServicePath(),
										collection: "AccountCollection",
										key: "'" + t.oContext.getProperty("accountID") + "'",
										name: t._getDiscussName(),
										summary: t._getShareText()
									}
								};
							},
							fGetDiscussSettings: function() {
								return {
									businessObject: {
										appContext: "CRM",
										odataServicePath: t._getOdataServicePath(),
										collection: "AccountCollection",
										key: "'" + t.oContext.getProperty("accountID") + "'",
										name: t._getDiscussName(),
										ui_url: window.location.href
									}
								};
							}
						}
					};
					var S = this._getSubView(this._getSelectedKey());
					if (S.getController().getFooterButtons) {
						h.buttonList = S.getController().getFooterButtons();
						for (var i in h.buttonList) {
							h.buttonList[i].bDisabled = S.getBindingContext() === null;
						}
					}
					return h;
				},
				onBackButtonPressed: function() {
					this._checkDataLossForCurrentSubView(function() {
						window.history.back();
					});
				},
				_storeCurrentState: function() {
					cus.crm.myaccounts.view.overview.OverviewPage.storage = {};
					var s = cus.crm.myaccounts.view.overview.OverviewPage.storage;
					s.oDataModel = this.getView().getModel();
					s.tabPersonalization = this.oTabPersonalization ? this.oTabPersonalization : {};
					var a = this._getSubViewDefinition(this._getSelectedKey());
					if (a.viewInstance && a.viewInstance.getController().onStoreCurrentStateSupported && a.viewInstance.getController().onStoreCurrentStateSupported()) {
						s.currentSubViewDefinition = a;
						s.viewStorage = {};
						if (s.currentSubViewDefinition.viewInstance.getController().onStoreCurrentState) s.currentSubViewDefinition.viewInstance.getController()
							.onStoreCurrentState(s.viewStorage);
					}
					s.onExit = function() {
						if (s.viewStorage && s.viewStorage.onExit) s.viewStorage.onExit();
					};
				},
				_restoreCurrentState: function() {
					var s = cus.crm.myaccounts.view.overview.OverviewPage.storage;
					if (!s) return;
					if (s.oDataModel) this.getView().setModel(s.oDataModel);
					if (s.tabPersonalization) this.oTabPersonalization = s.tabPersonalization;
					if (s.currentSubViewDefinition) {
						s.currentSubViewDefinition.viewInstance.setModel(this.getView().getModel());
						if (s.currentSubViewDefinition.viewInstance.getController().onRestoreCurrentState) s.currentSubViewDefinition.viewInstance.getController()
							.onRestoreCurrentState(s.viewStorage);
						var t = this.oTabConfigurationModel.getProperty("/Tabs");
						for (var i in t) {
							if (t[i].viewName === s.currentSubViewDefinition.viewInstance.getControllerName()) {
								t[i] = s.currentSubViewDefinition;
							}
						}
					}
					s.onExit();
					cus.crm.myaccounts.view.overview.OverviewPage.storage = null;
				},
				_getShareText: function() {
					var a = this.getView().getModel().getProperty(this.oContext.sPath);
					var t = cus.crm.myaccounts.util.formatter.AccountNameFormatter(a.fullName, a.name1) + "\n";
					var m = this.getView().getModel().getProperty(this.oContext.sPath + "/MainAddress");
					if (m) t += m.address;
					return t;
				},
				_getShareDisplay: function() {
					var a = this.getView().getModel().getProperty(this.oContext.sPath);
					var t = cus.crm.myaccounts.util.formatter.AccountNameFormatter(a.fullName, a.name1);
					var m = this.getView().getModel().getProperty(this.oContext.sPath + "/MainAddress");
					var b = "";
					if (m) b = m.address;
					return new sap.m.ObjectListItem({
						title: t,
						description: b
					});
				},
				_getDiscussID: function() {
					return this._getOdataServicePath() + this.oContext.sPath;
				},
				_getDiscussType: function() {
					var u = document.createElement('a');
					u.href = this.getView().getModel().sServiceUrl;
					return u.pathname + "/$metadata#AccountCollection";
				},
				_getDiscussName: function() {
					var a = this.getView().getModel().getProperty(this.oContext.sPath);
					return cus.crm.myaccounts.util.formatter.AccountNameFormatter(a.fullName, a.name1);
				},
				_getOdataServicePath: function() {
					var u = document.createElement('a');
					u.href = this.getView().getModel().sServiceUrl;
					return u.pathname;
				},
				_initModelsForExternalServices: function() {
					var s = cus.crm.myaccounts.util.Util.getExternalServiceConfiguration();
					for (var i in s) {
						this._addInitializationStep();
						var S = s[i];
						var m = function(e, p) {
							p.oOVPageController.getView().setModel(p.oModel, p.oServiceConfig.name);
							p.oOVPageController._removeInitializationStep();
							if (p.oOVPageController._isInitializationFinished()) p.oOVPageController._buildTabPersonalization();
						};
						var M = function(e, p) {
							var t = p.oOVPageController.oTabConfigurationModel.getProperty("/Tabs");
							for (var z in t) {
								if (t[z].service === p.oServiceConfig.name) t[z].hidden = true;
							}
							p.oOVPageController._refreshTabSelect();
							p.oOVPageController._removeInitializationStep();
							if (p.oOVPageController._isInitializationFinished()) p.oOVPageController._buildTabPersonalization();
						};
						var o = sap.ui.model.odata.ODataModel.mServiceData[S.serviceUrl];
						var a = false,
							b = false;
						if (o) {
							a = true;
							if (o.oMetadata.oMetadata) b = false;
							else b = true;
						}
						var c = new sap.ui.model.odata.ODataModel(S.serviceUrl, {
							json: true,
							loadMetadataAsync: true,
							useBatch: S.useBatch
						});
						if (S.countSupported) c.setCountSupported(true);
						else c.setCountSupported(false);
						if (a) {
							if (b) M(null, {
								oModel: c,
								oServiceConfig: S,
								oOVPageController: this
							});
							else m(null, {
								oModel: c,
								oServiceConfig: S,
								oOVPageController: this
							});
						} else {
							c.attachMetadataLoaded({
								oModel: c,
								oServiceConfig: S,
								oOVPageController: this
							}, m, this);
							c.attachMetadataFailed({
								oModel: c,
								oServiceConfig: S,
								oOVPageController: this
							}, M, this);
						}
					}
				},
				onPersonalizationButtonPressed: function() {
					if (!this.oTabPersonalizationDialog) {
						this.oTabPersonalizationDialog = this.oTabPersonalizationController.getTablePersoDialog();
						this.oTabPersonalizationDialog._oDialog.setTitle(cus.crm.myaccounts.util.Util.geti18NText("VIEWS"));
						var t = this;
						this.oTabPersonalizationDialog.attachConfirm(function() {
							var p = t.oTabPersonalizationDialog.retrievePersonalizations();
							t.oTabPersonalization = p;
							t.oPersonalizationContainer.setItemValue("tabsPersonalization", p);
							t._savePersonalization();
							t._refreshTabSelect();
						});
					}
					this.oTabPersonalizationController.openDialog();
				},
				_initTabPersonalization: function() {
					if (!this.oTabPersonalization) {
						var t = this;
						sap.ushell.Container.getService("Personalization").getContainer("cus.crm.myaccounts", {
							validity: Infinity
						}).fail(function() {
							t._refreshTabSelect();
						}).done(function(c) {
							t.oPersonalizationContainer = c;
							if (t._isInitializationFinished()) t._buildTabPersonalization();
						});
					}
				},
				_buildTabPersonalization: function() {
					var t = this.oTabConfigurationModel.getProperty("/Tabs");
					var c = [];
					for (var i in t) {
						if (!t[i].hidden) {
							c.push(new sap.m.Column(t[i].key, {
								header: new sap.m.Label({
									text: t[i].name
								})
							}));
						}
					}
					var T = new sap.m.Table('tabsPersonalizationTable', {
						visible: false,
						columns: c
					});
					var p = sap.ushell.Container.getService("Personalization").getTransientPersonalizer();
					this.oTabPersonalizationController = new sap.m.TablePersoController({
						table: T,
						persoService: p
					});
					this.oTabPersonalization = this.oPersonalizationContainer.getItemValue("tabsPersonalization");
					this._refreshTabSelect();
					p.setValue(this.oTabPersonalization);
					this.oTabPersonalizationController.activate();
					this.byId("headerArea").addContent(T);
					this._initPersonalizationForSubView();
				},
				_initPersonalizationForSubView: function(s) {
					var p = this.byId("subViewPersonalizationButton");
					var S = s;
					if (!S) S = this._getSubViewDefinition(this._getSelectedKey());
					if (S.viewInstance && S.viewInstance.getController().onInitPersonalization && this.oPersonalizationContainer) {
						var a = S.key + "TablePersonalization";
						if (!S.tablePersoController) {
							var P = S.viewInstance.getController().onInitPersonalization();
							var o = sap.ushell.Container.getService("Personalization").getTransientPersonalizer();
							var t = new sap.m.TablePersoController({
								table: P.tablePersonalization.table,
								persoService: o
							});
							var T = this.oPersonalizationContainer.getItemValue(a);
							o.setValue(T);
							t.activate();
							S.tablePersoController = t;
						}
						var b = this;
						var f = function() {
							var c = S.tablePersoController.getTablePersoDialog();
							c.detachConfirm(f);
							var d = c.retrievePersonalizations();
							b.oPersonalizationContainer.setItemValue(a, d);
							b._savePersonalization();
						};
						var O = function() {
							S.tablePersoController.openDialog();
							var c = S.tablePersoController.getTablePersoDialog();
							c.attachConfirm(f);
						};
						p.setVisible(this.configurationMode);
						var e = p.mEventRegistry["press"];
						for (var i in e) p.detachPress(e[i].fFunction);
						p.attachPress(O);
					} else {
						p.setVisible(false);
					}
				},
				_savePersonalization: function() {
					if (this.personalizationSaveRunning) return;
					var t = this;
					this.personalizationSaveRunning = true;
					this.oPersonalizationContainer.save().fail(function() {
						t.personalizationSaveRunning = false;
					}).done(function() {
						t.personalizationSaveRunning = false;
					});
				},
				_getKeyTabFromPersonalizationColumn: function(c) {
					var k = c.id.split("empty_component-tabsPersonalizationTable-")[1];
					if (!k) k = c.id.split("cus.crm.myaccounts-tabsPersonalizationTable-")[1];
					return k;
				},
				_addInitializationStep: function() {
					if (this.remainingInitializationSteps === undefined) this.remainingInitializationSteps = 1;
					else this.remainingInitializationSteps++;
				},
				_removeInitializationStep: function() {
					this.remainingInitializationSteps--;
				},
				_isInitializationFinished: function() {
					return this.oPersonalizationContainer && this.remainingInitializationSteps == 0;
				},
				_cleanUp: function(s) {
					if (s.getController().onCleanUp) s.getController().onCleanUp();
				},
				onExit: function() {
					this._storeCurrentState();
					this._exitViews();
					this.getView().byId("detailsViewContainer").removeAllContent();
				}
			});
		},
		"cus/crm/myaccounts/view/overview/OverviewPage.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core" xmlns:mvc="sap.ui.core.mvc" xmlns="sap.m" xmlns:suite="sap.suite.ui.commons" xmlns:layout="sap.ui.layout"\n           controllerName="cus.crm.myaccounts.view.overview.OverviewPage"\n\t\t   xmlns:html="http://www.w3.org/1999/xhtml">\n\n\t<Page id="page" title="{i18n>FULLSCREEN_TITLE}" showNavButton="true" enableScrolling="true">\n\n\t\t<content>\n\n\t\t\t<!-- Header: -->\n\t\t\t<layout:Grid\n\t\t\t\tclass ="sapSuiteUtiHeaderGrid sapSuiteUti"\n\t\t\t\tdefaultSpan="L6 M6 S12"\n\t\t\t\tvSpacing="0"\n\t\t\t\thSpacing="0"\n\t\t\t\tid="headerArea">\n\t\t\t\t<layout:content>\n\n\t\t\t\t\t<ObjectHeader\n\t\t\t\t\t\tid="companyHeaderTitle"\n\t\t\t\t        title= "{parts:[{path: \'fullName\'},{path: \'name1\'}],\n\t\t\t\t                formatter: \'cus.crm.myaccounts.util.formatter.AccountNameFormatter\'}" \n\t\t\t\t        titleActive="false"\n\t\t\t\t        icon="{parts:[{path:\'Logo/__metadata/media_src\'},{path: \'category\'}], formatter:\'cus.crm.myaccounts.util.formatter.logoUrlFormatter\'}" \t\t\t\t     \n\t        \t\t\ticonDensityAware="false">\n\t\t\t\t        <attributes>\n\t\t\t\t          <ObjectAttribute text="{accountID}"/> \n\t\t\t\t        </attributes>\n\t\t      \t\t</ObjectHeader>\n\n\t\t\t\t\t<!-- Extends the header area by KPI tiles -->\n\t\t\t\t\t<core:ExtensionPoint name="extKpiBox">\n\t\t\t\t\t\t<layout:HorizontalLayout class="cusMyAccountsPaddingTop cusMyAccountsFloatRight">\n\t\t\t\t\t\t\t<suite:KpiTile\n\t\t\t\t\t\t\t\tid="revenueCurrentYear"\n\t\t\t\t\t\t\t\tvalue="{parts:[{path:\'AccountFactsheet/revenueCurrentYear/amount\'},{path:\'AccountFactsheet/revenueCurrentYear/currency\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatShortAmounts\'}"\n\t\t\t\t\t\t\t\tdescription="{i18n>REVENUE_CURRENT}"\n\t\t\t\t\t\t\t\tdoubleFontSize="false"\n\t\t\t\t\t\t\t\ttooltip="{i18n>REVENUE_CURRENT_TOOLTIP}">\n\t\t\t\t\t\t\t</suite:KpiTile>\n\t\t\t\t\t\t\t<suite:KpiTile\n\t\t\t\t\t\t\t\tid="revenueLastYear"\n\t\t\t\t\t\t\t\tvalue="{parts:[{path:\'AccountFactsheet/revenueLastYear/amount\'},{path:\'AccountFactsheet/revenueLastYear/currency\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatShortAmounts\'}"\n\t\t\t\t\t\t\t\tdescription="{i18n>REVENUE_LAST}"\n\t\t\t\t\t\t\t\tdoubleFontSize="false"\n\t\t\t\t\t\t\t\ttooltip="{i18n>REVENUE_LAST_TOOLTIP}">\n\t\t\t\t\t\t\t</suite:KpiTile>\n\t\t\t\t\t\t\t<!-- Extends the KPI tiles -->\n\t\t\t\t\t\t\t<core:ExtensionPoint name="extKpiTile"/>\n\t\t\t\t\t\t</layout:HorizontalLayout>\n\t\t\t\t\t</core:ExtensionPoint>\n\n\t\t\t\t</layout:content>\n\t\t\t</layout:Grid>\n\n\t\t\t<!-- Header for Details Views: -->\n\t\t\t<layout:Grid\n\t\t\t\tdefaultSpan="L6 M6 S12"\n\t\t\t\tvSpacing="0"\n\t\t\t\thSpacing="0">\n\t\t\t\t<layout:content>\n\t\t\t\t\t<layout:HorizontalLayout class="cusMyAccountsPaddingLeft">\n\t\t\t\t\t\t<core:Icon id="personalizationButton" src="sap-icon://action-settings" press="onPersonalizationButtonPressed" visible="{path:\'/\', formatter:\'.isInConfigurationMode\'}" size="1.2rem" class="cusMyAccountsPaddingTop"/>\n\t\t           \t\t<Select\n\t\t           \t\t\tid="tabSelect"\n\t\t\t\t\t\t\tchange="onDetailsViewSelectionPressed">\n\t\t\t        \t</Select>\n\t\t        \t</layout:HorizontalLayout>\n\t\t\t\t\t<layout:HorizontalLayout class="cusMyAccountsFloatRight">\n\t\t\t        \t<SearchField id="subViewSearchField" liveChange="onSubViewLiveSearch" search="onSubViewSearch" visible="false"/>\n\t\t\t\t\t\t<core:Icon id="subViewPersonalizationButton" src="sap-icon://action-settings" size="1.2rem" visible="false" class="cusMyAccountsPaddingLeft cusMyAccountsPaddingTop cusMyAccountsPaddingRight"/>\n\t\t\t\t\t</layout:HorizontalLayout>\n\t\t\t\t</layout:content>\n\t\t\t</layout:Grid>\n\t\t\t\n\t\t\t<!-- Details Views: -->\n\t\t \t<layout:Grid id="detailsViewContainer" defaultSpan="L12 M12 S12" vSpacing="0" hSpacing="0">\n\t      \t\t<layout:content/>\n\t      \t</layout:Grid>\n\n\t\t</content>\n\t\t<footer>\n\t\t\t<Bar id="footer"/>\n\t\t</footer>\n\t</Page>\n</core:View>',
		"cus/crm/myaccounts/view/overview/ProcessTypeDialog.fragment.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<SelectDialog\n        xmlns="sap.m"\n        xmlns:core="sap.ui.core"\n        \n        title="{i18n>SELECT_TRANSACTION_TYPE}"\n       \n        multiSelect=""\n        items="{processTypes>/TransactionTypeSet}"\n       \tsearch="searchProcess"\n        confirm="selectProcess"\n        cancel="cancelProcess">\n    <StandardListItem title="{processTypes>processTypeDescription}" description="{processTypes>processTypeCode}">\n        <customData>\n            <core:CustomData key="ProcessTypeCode" value="{processTypes>processTypeCode}"/>\n            <core:CustomData key="ProcessTypeDescription" value="{processTypes>processTypeDescription}" />\n            <core:CustomData key="PrivateFlag" value="{processTypes>privateFlag}" />\n        </customData>\n    </StandardListItem>\n</SelectDialog>',
		"cus/crm/myaccounts/view/overview/Quickoverview.controller.js": function() {
			jQuery.sap.require("cus.crm.myaccounts.util.Util");
			(function() {
				'use strict';
				sap.ui.controller("cus.crm.myaccounts.view.overview.Quickoverview", {
					onInit: function() {
						var l = new sap.ui.core.LocaleData(sap.ui.getCore().getConfiguration().getLocale());
						var i = new sap.ui.model.resource.ResourceModel({
							bundleName: "cus.crm.myaccounts.i18n.i18n",
							bundleLocale: l
						});
						this.getView().setModel(i, "i18n");
					},
					onPhoneTaped: function(e) {
						sap.m.URLHelper.triggerTel(e.getSource().getText());
					},
					onEmailTaped: function(e) {
						sap.m.URLHelper.triggerEmail(e.getSource().getText());
					},
					onMapIconPressed: function() {
						sap.m.URLHelper.redirect("http" + "://" + "maps.apple.com/?q=" + this.getView().getModel().getProperty(
							"/Company/Address/address").split("\n").join(" "), !sap.ui.Device.system.phone);
					}
				});
			}());
		},
		"cus/crm/myaccounts/view/overview/Quickoverview.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View\n     xmlns:core="sap.ui.core"\n\t xmlns:mvc="sap.ui.core.mvc"\n\t xmlns:form="sap.ui.layout.form"\n\t xmlns="sap.m"\n\t xmlns:layout="sap.ui.layout"\n\t controllerName="cus.crm.myaccounts.view.overview.Quickoverview"\n     xmlns:html="http://www.w3.org/1999/xhtml"\n     resourceBundleName="sap.ca.ui.i18n.i18n" resourceBundleAlias="ca_i18n">\n     \n\t<form:SimpleForm id="quickOverviewForm1" class="bcUpperContainer" minWidth="1024" maxContainerCols="2">\n\t\t<form:content>\n\t\t\t<Label text="{ca_i18n>Quickoverview.company.maincontactmobile}"/>\n\t\t\t<Link text="{/Person/Address/mobilePhone}" press="onPhoneTaped"/>\n\t\t\t<Label text="{ca_i18n>Quickoverview.company.maincontactphone}"/>\n\t\t\t<Link text="{/Person/Address/phone}" press="onPhoneTaped"/>\n\t\t\t<Label text="{ca_i18n>Quickoverview.company.maincontactemail}"/>\n\t\t\t<Link text="{/Person/Address/email}" press="onEmailTaped"/>\n\t\t\t<Label text=""/>\n\t\t\t<Text text=""/>\n\t\t</form:content>\n\t</form:SimpleForm>\n\t\n\t<form:SimpleForm id="quickOverviewForm2" class="bcLowerContainer" minWidth="1024" maxContainerCols="2">\n\t\t<form:content>\n\t\t\t<core:Title text="{ca_i18n>Quickoverview.employee.companytitle}"/>\n\t\t\t<Label text="{i18n>COMPANY_NAME}"/>\n\t\t\t<Text text="{/Company/name}"/>\n\t\t\t<Label text="{ca_i18n>Quickoverview.company.address}"/>\n\t\t\t<layout:HorizontalLayout>\n\t\t\t\t<Text text="{/Company/Address/address}"/>\n\t\t\t\t<layout:HorizontalLayout id="mapIcon" visible="false">\n\t\t\t\t\t<core:Icon src="sap-icon://map" press="onMapIconPressed" size="1.2rem" class="cusMyAccountsPaddingLeft" visible="{parts:[\'/Company/Address/address\'], formatter: \'cus.crm.myaccounts.util.formatter.isNotInitial\'}" />\n\t\t\t\t</layout:HorizontalLayout>\n\t\t\t</layout:HorizontalLayout>\n\t\t</form:content>\n\t</form:SimpleForm>\n\t\n\t<Label id="bindingLabel" visible="false"></Label>\n</core:View>',
		"cus/crm/myaccounts/view/overview/Quotations.controller.js": function() {
			sap.ui.controller("cus.crm.myaccounts.view.overview.Quotations", {
				onInit: function() {
					this.customizingModel = null;
				},
				onItemSelected: function() {
					this._readCustomizing();
					var a = this.getView().getBindingContext();
					var c = a.getProperty("ERPCustomer");
					if (c && c.customerNumber) {
						var m = this.getView().getModel("ERP_BUPA_ODATA");
						var C = new sap.ui.model.Context(m, "CustomerCollection('" + c.customerNumber + "')");
						this.getView().setBindingContext(C, "ERP_BUPA_ODATA");
					} else {
						this.getList()._hideBusyIndicator();
					}
				},
				onReset: function() {
					this.getView().setBindingContext(undefined, "ERP_BUPA_ODATA");
					this.getList().removeAllItems();
				},
				getList: function() {
					return this.byId("list");
				},
				onInitPersonalization: function() {
					var t = this.getList();
					return {
						tablePersonalization: {
							table: t
						}
					};
				},
				onQuotationLinkPressed: function(e) {
					clearTimeout(this.moseOverTimer);
					var q = e.getSource().getBindingContext("ERP_BUPA_ODATA").getObject().quotationID;
					this._navToQuotation(q);
				},
				_navToQuotation: function(q) {
					var f = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService;
					var c = f && f("CrossApplicationNavigation");
					c.toExternal({
						target: {
							semanticObject: "SalesQuotation",
							action: "displayMyQuotations&/display/" + q
						}
					});
				},
				onAmountLinkPressed: function(e) {
					var l = e.getSource();
					this._displayPopover(l);
				},
				_displayPopover: function(l) {
					if (this._oPopover) this._oPopover.destroy();
					this._oPopover = sap.ui.xmlfragment("cus.crm.myaccounts.view.overview.ItemsQuickoverview", this);
					this._oPopover.setBindingContext(l.getBindingContext("ERP_BUPA_ODATA"), "ERP_BUPA_ODATA");
					this.getView().addDependent(this._oPopover);
					jQuery.sap.delayedCall(0, this, function() {
						this._oPopover.openBy(l);
					});
				},
				_readCustomizing: function(c) {
					if (this.customizingModel) return;
					this.customizingModel = new sap.ui.model.json.JSONModel({
						ApplicationCustomizing: {}
					});
					this.getView().setModel(this.customizingModel, "Customizing");
					var t = this;
					var a = function(r) {
						var A = r["ApplicationCustomizing"];
						t.customizingModel.setProperty("/ApplicationCustomizing", A);
						if (c) c.call(t);
					};
					var m = this.getView().getModel("ERP_BUPA_ODATA");
					cus.crm.myaccounts.util.Util.sendBatchReadRequests(m, ["ApplicationCustomizing"], a, a);
				}
			});
		},
		"cus/crm/myaccounts/view/overview/Quotations.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core" xmlns:mvc="sap.ui.core.mvc" xmlns="sap.m"\n\t\t\tcontrollerName="cus.crm.myaccounts.view.overview.Quotations" xmlns:html="http://www.w3.org/1999/xhtml">\n\t<Table\n   \t\tid="list"\n\t\tmode="{device>/listMode}"\n\t\tgrowing="true"\n       \tgrowingThreshold="10"\n       \tgrowingScrollToLoad="false"\n       \titems="{ERP_BUPA_ODATA>Quotations}">\n        <columns>\n          <Column id="idCol" minScreenWidth="Small" demandPopin="true"><Label text="{i18n>ID}" /></Column>\n          <Column id="amountCol" minScreenWidth="Small" demandPopin="true"><Label text="{i18n>AMOUNT}" /></Column>\n          <Column id="expirationDateCol" minScreenWidth="Small" demandPopin="true"><Label text="{i18n>EXPIRATION_DATE}" /></Column>\n          <Column id="statusCol" minScreenWidth="Small" demandPopin="true"><Label text="{i18n>STATUS}" /></Column>\n        </columns>\n        <items>\n        \t<ColumnListItem id="columnListItem">\n        \t\t<cells>\n\t\t            <Link text="{ERP_BUPA_ODATA>quotationID}" press="onQuotationLinkPressed"/>\n\t\t            <Link text="{parts:[{path: \'ERP_BUPA_ODATA>netValue\'}, {path: \'ERP_BUPA_ODATA>currency\'}],  formatter:\'cus.crm.myaccounts.util.formatter.formatAmounts\'}"\n\t\t            \t  press= "onAmountLinkPressed"/>\n\t\t            <Text text="{parts:[{path:\'ERP_BUPA_ODATA>validTo\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatMediumDate\' }"/>\n\t\t            <ObjectStatus text="{ERP_BUPA_ODATA>status}" state="{parts:[{path:\'ERP_BUPA_ODATA>validTo\'},{path:\'ERP_BUPA_ODATA>status\'}, {path:\'Customizing>/ApplicationCustomizing/redThreshold\'}], formatter:\'cus.crm.myaccounts.util.formatter.formatExpiryState\'}"/>\n            \t</cells>\n        \t</ColumnListItem>\n    \t</items>\n   \t</Table>\n    \t\n</core:View>\n',
		"cus/crm/myaccounts/view/overview/SalesOrders.controller.js": function() {
			sap.ui.controller("cus.crm.myaccounts.view.overview.SalesOrders", {
				onItemSelected: function() {
					var a = this.getView().getBindingContext();
					var c = a.getProperty("ERPCustomer");
					if (c && c.customerNumber) {
						var m = this.getView().getModel("ERP_BUPA_ODATA");
						var C = new sap.ui.model.Context(m, "CustomerCollection('" + c.customerNumber + "')");
						this.getView().setBindingContext(C, "ERP_BUPA_ODATA");
					} else {
						this.getList().setBusy(false);
					}
				},
				onReset: function() {
					this.getView().setBindingContext(undefined, "ERP_BUPA_ODATA");
					this.getList().removeAllItems();
				},
				getList: function() {
					return this.byId("list");
				},
				onInitPersonalization: function() {
					var t = this.getList();
					return {
						tablePersonalization: {
							table: t
						}
					};
				},
				onSalesOrderLinkPressed: function(e) {
					var s = e.getSource().getBindingContext("ERP_BUPA_ODATA").getObject().salesOrderID;
					this._navToSalesOrder(s);
				},
				_navToSalesOrder: function(s) {
					var f = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService;
					var c = f && f("CrossApplicationNavigation");
					c.toExternal({
						target: {
							semanticObject: "SalesOrder",
							action: "track&/display/SalesOrders('" + s + "')"
						}
					});
				},
				onAmountLinkPressed: function(e) {
					var l = e.getSource();
					this._displayPopover(l);
				},
				_displayPopover: function(l) {
					if (this._oPopover) this._oPopover.destroy();
					this._oPopover = sap.ui.xmlfragment("cus.crm.myaccounts.view.overview.ItemsQuickoverview", this);
					this._oPopover.setBindingContext(l.getBindingContext("ERP_BUPA_ODATA"), "ERP_BUPA_ODATA");
					this.getView().addDependent(this._oPopover);
					jQuery.sap.delayedCall(0, this, function() {
						this._oPopover.openBy(l);
					});
				}
			});
		},
		"cus/crm/myaccounts/view/overview/SalesOrders.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core" xmlns:mvc="sap.ui.core.mvc" xmlns="sap.m" xmlns:layout="sap.ui.layout"\n\t\t\tcontrollerName="cus.crm.myaccounts.view.overview.SalesOrders" xmlns:html="http://www.w3.org/1999/xhtml">\n\t<Table\n   \t\tid="list"\n\t\tmode="{device>/listMode}"\n\t\tgrowing="true"\n        growingThreshold="10"\n        growingScrollToLoad="false"\n        items="{path:\'ERP_BUPA_ODATA>SalesOrders\',\n         \t\tsorter:[{path:\'postingDate\'}]}">\n        <columns>\n          <Column id="idCol" minScreenWidth="Small" demandPopin="true"><Label text="{i18n>ID}" /></Column>\n          <Column id="salesEmployee" minScreenWidth="Small" demandPopin="true"><Label text="{i18n>SALES_EMPLOYEE}" /></Column>\n          <Column id="amountCol" minScreenWidth="Small" demandPopin="true"><Label text="{i18n>AMOUNT}" /></Column>\n          <Column id="deliveryDateCol" minScreenWidth="Small" demandPopin="true"><Label text="{i18n>DELIVERY_DATE}" /></Column>\n          <Column id="statusCol" minScreenWidth="Small" demandPopin="true"><Label text="{i18n>STATUS}" /></Column>\n        </columns>\n        <items>\n        \t<ColumnListItem id="columnListItem">\n            \t<cells>\n\t\t            <Link text="{ERP_BUPA_ODATA>salesOrderID}" press="onSalesOrderLinkPressed"/>\n            \t\t<Text text="{ERP_BUPA_ODATA>salesEmployeeName}"/>\n\t\t            <Link text="{parts:[{path: \'ERP_BUPA_ODATA>netValue\'}, {path: \'ERP_BUPA_ODATA>currency\'}],  formatter:\'cus.crm.myaccounts.util.formatter.formatAmounts\'}"\n\t\t            \t  press= "onAmountLinkPressed"/>\n\t\t            <Text text="{parts:[{path:\'ERP_BUPA_ODATA>postingDate\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatMediumDate\' }"/>\n\t\t            <ObjectStatus text="{ERP_BUPA_ODATA>status}" state="{path:\'ERP_BUPA_ODATA>statusID\', formatter:\'cus.crm.myaccounts.util.formatter.formatSalesOrderStatusText\'}"/>\n            \t</cells>\n        \t</ColumnListItem>\n    \t</items>\n   \t</Table>\n    \t\n</core:View>',
		"cus/crm/myaccounts/view/overview/Tasks.controller.js": function() {
			jQuery.sap.require("cus.crm.myaccounts.util.Util");
			jQuery.sap.require("sap.m.MessageBox");
			jQuery.sap.require("sap.ca.ui.message.message");
			sap.ui.controller("cus.crm.myaccounts.view.overview.Tasks", {
				getList: function() {
					return this.byId("taskList");
				},
				onSubViewLiveSearch: function(s) {
					var b = this.getList().getBinding("items");
					var f = [];
					if (s !== "") f.push(new sap.ui.model.Filter("description", sap.ui.model.FilterOperator.Contains, s));
					if (b) b.filter(f);
				},
				onItemSelected: function() {
					this._adaptItems();
				},
				onListItemPressed: function(e) {
					this._navigateToTask(e.getSource().getBindingContext());
				},
				_adaptItems: function() {
					var l = this.byId("taskList");
					var u = null;
					u = jQuery.proxy(function() {
						var I = l.getItems();
						for (var i in I) {
							var o = I[i];
							o.getModeControl().setProperty("editable", false);
							if (o.isSelected()) this._greyOutItem(o);
						}
					}, this);
					l.attachUpdateFinished(u);
				},
				_navigateToTask: function(t) {
					if (sap.ushell && sap.ushell.Container) {
						var f = sap.ushell.Container.getService;
						if (f) {
							var c = f("CrossApplicationNavigation");
							if (c) {
								c.toExternal({
									target: {
										semanticObject: "Task",
										action: "manageTasks"
									},
									params: {
										fromAccount: "X"
									},
									appSpecificRoute: "&/taskOverview/Tasks(guid'" + t.getProperty("Guid") + "')"
								});
							}
						}
					}
				},
				_greyOutItem: function(i) {
					var b = sap.ui.core.theming.Parameters.get("sapUiExtraLightBG");
					i.$().css("background-color", b);
					var t = sap.ui.core.theming.Parameters.get("sapUiExtraLightText");
					i.$().find("span").css("color", t);
					i.$().find("span").css("opacity", "0.8");
				},
				onStoreCurrentStateSupported: function() {
					return true;
				},
				onStoreCurrentState: function(s) {
					s.contextPath = "";
					var b = sap.ui.getCore().getEventBus();
					s.onRefreshContextPath = function(c, e, d) {
						if (s.action !== "refreshList") {
							s.action = "refreshContextPath";
							s.contextPath = d.contextPath.replace("/Tasks", "TaskCollection");
						}
					};
					s.onRefreshList = function() {
						s.action = "refreshList";
					};
					b.subscribe("cus.crm.mytasks", "taskChanged", s.onRefreshContextPath, s);
					b.subscribe("cus.crm.mytasks", "followUpTaskCreated", s.onRefreshList, s);
					b.subscribe("cus.crm.mytasks", "taskCreated", s.onRefreshList, s);
					b.subscribe("cus.crm.mytasks", "taskDeleted", s.onRefreshList, s);
					s.onExit = function() {
						var b = sap.ui.getCore().getEventBus();
						b.unsubscribe("cus.crm.mytasks", "taskChanged", s.onRefreshContextPath, s);
						b.unsubscribe("cus.crm.mytasks", "followUpTaskCreated", s.onRefreshList, s);
						b.unsubscribe("cus.crm.mytasks", "taskCreated", s.onRefreshList, s);
						b.unsubscribe("cus.crm.mytasks", "taskDeleted", s.onRefreshList, s);
					};
				},
				onRestoreCurrentState: function(s) {
					if (s.action === "refreshList") {
						this.getList().getBinding("items").refresh();
					} else if (s.action === "refreshContextPath") {
						var r = cus.crm.myaccounts.util.Util.getRefreshUIObject(this.getView().getModel(), "/" + s.contextPath);
						r.refresh();
					}
				},
				getFooterButtons: function() {
					var t = this;
					return [{
						sIcon: "sap-icon://add",
						sTooltip: cus.crm.myaccounts.util.Util.geti18NText("ADD_TASK_TOOLTIP"),
						onBtnPressed: function() {
							t.onCreateTask();
						}
					}];
				},
				onCreateTask: function() {
					var d = this.getView().getModel();
					var t = this;
					var s = function(r) {
						var p;
						if (!t.processTypeModel) {
							p = r["CustomizingTaskTypeCollection"];
							t.processTypeModel = new sap.ui.model.json.JSONModel();
							t.processTypeModel.setProperty("/TransactionTypeSet", p);
						} else {
							p = t.processTypeModel.getProperty("/TransactionTypeSet");
						}
						if (p.length === 1) {
							var a = p[0].processTypeCode;
							t._navigateToCreationOfTask(a);
						} else {
							t.oProcessTypeDialog = sap.ui.xmlfragment("cus.crm.myaccounts.view.overview.ProcessTypeDialog", t);
							t.oProcessTypeDialog.setModel(t.getView().getModel("i18n"), "i18n");
							t.oProcessTypeDialog.setModel(t.processTypeModel, "processTypes");
							t.oProcessTypeDialog.open();
						}
					};
					if (!t.processTypeModel) cus.crm.myaccounts.util.Util.sendBatchReadRequests(d, ["CustomizingTaskTypeCollection"], s);
					else s.call(t);
				},
				selectProcess: function(e) {
					var s = e.getParameter("selectedItem");
					if (s) {
						this._navigateToCreationOfTask(s.data("ProcessTypeCode"));
					}
				},
				_navigateToCreationOfTask: function(p) {
					if (sap.ushell && sap.ushell.Container) {
						var f = sap.ushell.Container.getService;
						if (f) {
							var c = f("CrossApplicationNavigation");
							if (c) {
								var a = this.getView().getModel().getProperty(this.getView().getBindingContext().sPath).accountID;
								c.toExternal({
									target: {
										semanticObject: "Task",
										action: "manageTasks"
									},
									params: {
										createFromAccount: "X",
										accountID: a
									},
									appSpecificRoute: "&/newTask/" + p
								});
							}
						}
					}
				},
				searchProcess: function(e) {
					var i = e.getParameter("itemsBinding");
					var I;
					this.oProcessTypeDialog.setNoDataText(cus.crm.myaccounts.util.Util.geti18NText("LOADING_TEXT"));
					var s = e.getParameter("value");
					if (s !== undefined) {
						I = i.filter([new sap.ui.model.Filter("processTypeDescription", sap.ui.model.FilterOperator.Contains, s)]);
						if (I.getLength() === 0) {
							this.oProcessTypeDialog.setNoDataText(cus.crm.myaccounts.util.Util.geti18NText("NO_DATA_TEXT"));
						}
					}
				},
				onQuickCreationOfTask: function(e) {
					this._setBusy(true);
					var t = e.getSource().getValue();
					this._quickCreateTask(t);
				},
				_quickCreateTask: function(t) {
					var m = this.getView().getModel();
					var c = this.getView().getBindingContext();
					var a = c.getPath();
					var A = c.getObject();
					var T = {
						"description": t,
						"accountID": A ? A.accountID : "",
						"dueDate": new Date()
					};
					var b = this;
					cus.crm.myaccounts.util.Util.sendBatchChangeOperations(m, [m.createBatchOperation(a + "/Tasks", "POST", T)], function() {
						b._setBusy(false);
						sap.m.MessageToast.show(cus.crm.myaccounts.util.Util.geti18NText("MSG_TASK_CREATION_SUCCESS"));
					}, function(e) {
						b._setBusy(false);
						sap.m.MessageBox.alert(e.message.value);
					});
				},
				_setBusy: function(b) {
					var t = this;
					if (!this.oBusyDialog) this.oBusyDialog = new sap.m.BusyDialog();
					if (b) {
						this.liveChangeTimer = window.setTimeout(function() {
							t.oBusyDialog.open();
						}, 700);
						this.byId("taskInput").setEnabled(false);
					} else {
						window.clearTimeout(this.liveChangeTimer);
						this.oBusyDialog.close();
						this.byId("taskInput").setEnabled(true).setValue("");
					}
				},
				onCleanUp: function() {
					this.byId("taskInput").setValue("");
				}
			});
		},
		"cus/crm/myaccounts/view/overview/Tasks.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core" xmlns:mvc="sap.ui.core.mvc" xmlns="sap.m"\n\t\t\tcontrollerName="cus.crm.myaccounts.view.overview.Tasks" xmlns:html="http://www.w3.org/1999/xhtml">\n\n\t<FeedInput \n\t    id="taskInput"\n\t    post="onQuickCreationOfTask"\n\t    showIcon="false"\n\t    placeholder="{i18n>NEW_TASK_INPUT_PLACEHOLDER}" />\n\t<List id="taskList"\n\t\tgrowing="true" growingScrollToLoad="false" mode="MultiSelect"\n\t\tselect="markTaskCompleted" growingThreshold="10" \n\t\titems="{path:\'Tasks\', sorter: [{path: \'dueDate\', descending: true}]}" >\n\t\t<ObjectListItem id="task"\n\t\t\ttype="Active"\n\t\t\tselected="{completed}"\n\t\t\ttitle="{description}"\n\t\t\tpress="onListItemPressed">\n\t\t\t\t<secondStatus>\n\t\t\t\t\t<ObjectStatus\n\t\t\t\t\t\tstate="None"\n\t\t\t\t\t\ttext="{path:\'dueDate\', formatter:\'cus.crm.myaccounts.util.formatter.formatMediumDate\'}" />\n\t\t\t\t</secondStatus>\n\t\t\t\t<attributes>\n\t\t\t\t\t<ObjectAttribute text="{note}" />\n\t\t\t\t\t<ObjectAttribute text="{contactName}" />\n\t\t\t\t</attributes>\n\n\t\t</ObjectListItem>\n\t</List>\n</core:View>\n',
		"cus/crm/myaccounts/view/search/SearchResult.controller.js": function() {
			jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");
			jQuery.sap.require("cus.crm.myaccounts.util.Constants");
			jQuery.sap.require("cus.crm.myaccounts.util.formatter");
			jQuery.sap.require("cus.crm.myaccounts.util.Util");
			jQuery.sap.require("sap.ca.ui.utils.TablePersonalizer");
			jQuery.sap.require("sap.m.TablePersoDialog");
			jQuery.sap.require("sap.m.TablePersoController");
			sap.ca.scfld.md.controller.BaseFullscreenController.extend("cus.crm.myaccounts.view.search.SearchResult", {
				configurationMode: false,
				onInit: function() {
					if (cus.crm.myaccounts.view.overview && cus.crm.myaccounts.view.overview.OverviewPage.storage) {
						if (cus.crm.myaccounts.view.overview.OverviewPage.storage.onExit) {
							cus.crm.myaccounts.view.overview.OverviewPage.storage.onExit();
						}
						cus.crm.myaccounts.view.overview.OverviewPage.storage = null;
					}
					this.EHP2Backend = cus.crm.myaccounts.util.Util.getServiceSchemaVersion(this.getView().getModel(), "AccountCollection") < 1;
					this._initPersonalization();
					this.oRouter.attachRouteMatched(this._handleNavToWithFilter, this);
				},
				getList: function() {
					return this.byId("list");
				},
				_handleNavToWithFilter: function(e) {
					jQuery.sap.log.debug("cus.crm.myaccounts.view.search.SearchResult - handleNavTo");
					if (e.getParameter("name") === "mainPage" || e.getParameter("name") === "S2") {
						var f = e.getParameter("arguments").filterState;
						if (f) {
							this.selectedKey = f;
						} else {
							this.selectedKey = cus.crm.myaccounts.util.Constants.filterMyAccounts;
						}
						this._bindTable();
						this.setHeaderFooterOptions(this._getHeaderFooterOptions());
					}
				},
				_bindTable: function(r) {
					if (!this.personalizationLoadFinished || !this.selectedKey) return;
					var l = this.getList();
					var b = this._getParametersFromPersonalization();
					if (l && (!l.getBinding("items") || r)) {
						l.bindAggregation("items", {
							path: '/AccountCollection',
							filters: this._getFilters(),
							parameters: b,
							template: l.getItems()[0].clone()
						});
						l.getBinding("items").attachChange(this._onBindingChange, this);
					}
				},
				_getPossibleAccountFilters: function() {
					if (this.EHP2Backend) {
						return [cus.crm.myaccounts.util.Constants.filterMyAccounts, cus.crm.myaccounts.util.Constants.filterAllAccounts];
					}
					return [cus.crm.myaccounts.util.Constants.filterMyAccounts, cus.crm.myaccounts.util.Constants.filterMyIndividualAccounts, cus.crm
						.myaccounts.util.Constants.filterMyCorporateAccounts, cus.crm.myaccounts.util.Constants.filterMyAccountGroups, cus.crm.myaccounts
						.util.Constants.filterAllAccounts, cus.crm.myaccounts.util.Constants.filterAllIndividualAccounts, cus.crm.myaccounts.util.Constants
						.filterAllCorporateAccounts, cus.crm.myaccounts.util.Constants.filterAllAccountGroups
					];
				},
				_getAccountFilterItems: function() {
					var a = this._getPossibleAccountFilters();
					var A = [];
					var i;
					for (i = 0; i < a.length; i++) {
						A.push({
							text: cus.crm.myaccounts.util.Util.geti18NText(a[i]),
							key: a[i]
						});
					}
					return A;
				},
				_getFilters: function() {
					var f = [];
					var s = this.byId("mySearchField").getValue();
					if (s && s.length > 0) {
						f.push(new sap.ui.model.Filter("fullName", sap.ui.model.FilterOperator.Contains, s));
					}
					var i = this.selectedKey.indexOf("MY") >= 0;
					f.push(new sap.ui.model.Filter("isMyAccount", sap.ui.model.FilterOperator.EQ, i));
					if (this.selectedKey.indexOf("INDIVIDUAL") >= 0) {
						f.push(new sap.ui.model.Filter("category", sap.ui.model.FilterOperator.EQ, cus.crm.myaccounts.util.Constants.accountCategoryPerson));
					} else if (this.selectedKey.indexOf("CORPORATE") >= 0) {
						f.push(new sap.ui.model.Filter("category", sap.ui.model.FilterOperator.EQ, cus.crm.myaccounts.util.Constants.accountCategoryCompany));
					} else if (this.selectedKey.indexOf("GROUP") >= 0) {
						f.push(new sap.ui.model.Filter("category", sap.ui.model.FilterOperator.EQ, cus.crm.myaccounts.util.Constants.accountCategoryGroup));
					}
					return f;
				},
				_applyFilter: function() {
					var b = this.getList().getBinding("items");
					b.aApplicationFilters = [];
					b.filter(this._getFilters());
				},
				_setFilterInURL: function() {
					this.oRouter.navTo("mainPage", {
						"filterState": this.selectedKey
					}, true);
				},
				_onBindingChange: function() {
					var t = "";
					switch (this.selectedKey) {
						case cus.crm.myaccounts.util.Constants.filterMyAccounts:
							t = "MY_ACCOUNT_TITLE";
							break;
						case cus.crm.myaccounts.util.Constants.filterMyIndividualAccounts:
							t = "MY_INDIVIDUAL_ACCOUNT_TITLE";
							break;
						case cus.crm.myaccounts.util.Constants.filterMyCorporateAccounts:
							t = "MY_CORPORATE_ACCOUNT_TITLE";
							break;
						case cus.crm.myaccounts.util.Constants.filterMyAccountGroups:
							t = "MY_ACCOUNT_GROUP_TITLE";
							break;
						case cus.crm.myaccounts.util.Constants.filterAllAccounts:
							t = "ALL_ACCOUNTS_TITLE";
							break;
						case cus.crm.myaccounts.util.Constants.filterAllIndividualAccounts:
							t = "ALL_INDIVIDUAL_ACCOUNTS_TITLE";
							break;
						case cus.crm.myaccounts.util.Constants.filterAllCorporateAccounts:
							t = "ALL_CORPORATE_ACCOUNTS_TITLE";
							break;
						case cus.crm.myaccounts.util.Constants.filterAllAccountGroups:
							t = "ALL_ACCOUNT_GROUPS_TITLE";
							break;
					}
					var c = 0;
					var b = this.getList().getBinding("items");
					if (b) {
						c = b.getLength();
					}
					if (c > 0) {
						this._oControlStore.oTitle.setText(cus.crm.myaccounts.util.Util.geti18NText1(t, c));
					} else {
						this._oControlStore.oTitle.setText(cus.crm.myaccounts.util.Util.geti18NText1(t, "0"));
					}
				},
				onSearchPressed: function() {
					this._applyFilter();
				},
				onAccountLinkClicked: function(e) {
					this.oRouter.navTo("detail", {
						contextPath: e.getSource().getBindingContext().getPath().replace('/', "")
					}, false);
				},
				_addAccount: function(e) {
					if (!this.oCreateAccountActionSheet) {
						var t = this;
						var b = [new sap.m.Button({
							text: cus.crm.myaccounts.util.Util.geti18NText("INDIVIDUAL_ACCOUNT"),
							id: "createIndividualAccountButton",
							press: function() {
								t._navigateToCreateScreen(cus.crm.myaccounts.util.Constants.accountCategoryPerson);
							}
						}), new sap.m.Button({
							text: cus.crm.myaccounts.util.Util.geti18NText("CORPORATE_ACCOUNT"),
							id: "createCorporateAccountButton",
							press: function() {
								t._navigateToCreateScreen(cus.crm.myaccounts.util.Constants.accountCategoryCompany);
							}
						}), new sap.m.Button({
							text: cus.crm.myaccounts.util.Util.geti18NText("ACCOUNT_GROUP"),
							id: "createGroupAccountButton",
							press: function() {
								t._navigateToCreateScreen(cus.crm.myaccounts.util.Constants.accountCategoryGroup);
							}
						})];
						this.oCreateAccountActionSheet = new sap.m.ActionSheet("AddAccountActionSheet", {
							buttons: b,
							placement: sap.m.PlacementType.Top
						});
					}
					this.oCreateAccountActionSheet.openBy(e.getSource());
				},
				_navigateToCreateScreen: function(a) {
					this.oRouter.navTo("new", {
						"accountCategory": a
					}, false);
				},
				_getHeaderFooterOptions: function() {
					var t = this;
					var b = [];
					if (!this.EHP2Backend) {
						b.push({
							sIcon: "sap-icon://add",
							sTooltip: cus.crm.myaccounts.util.Util.geti18NText("ADD_ACCOUNT_TOOLTIP"),
							onBtnPressed: function(e) {
								t._addAccount(e);
							}
						});
					}
					var f = "";
					if (this._oControlStore && this._oControlStore.oTitle) {
						f = this._oControlStore.oTitle.getText();
					}
					var s = 'BUTTON_SHOW_PERSONALIZATION';
					if (this.configurationMode) {
						s = 'BUTTON_HIDE_PERSONALIZATION';
					}
					return {
						sFullscreenTitle: f,
						aAdditionalSettingButtons: [{
							sI18nBtnTxt: s,
							onBtnPressed: function() {
								t.toggleConfigurationMode();
							}
						}],
						buttonList: b,
						oFilterOptions: {
							aFilterItems: this._getAccountFilterItems(),
							sSelectedItemKey: this.selectedKey,
							onFilterSelected: function(a) {
								jQuery.sap.log.debug("cus.crm.myaccounts.view.search.SearchResult - onFilterSelected - " + a + " has been selected");
								t.selectedKey = a;
								t._applyFilter();
								t._setFilterInURL();
							}
						},
						oAddBookmarkSettings: {
							icon: "sap-icon://Fiori2/F0002"
						}
					};
				},
				_initPersonalization: function() {
					this.personalizationKey = "searchResultPersonalization";
					var p = sap.ushell.Container.getService("Personalization").getTransientPersonalizer();
					this.oTablePersoController = new sap.m.TablePersoController({
						table: this.getList(),
						persoService: p
					});
					var t = this;
					sap.ushell.Container.getService("Personalization").getContainer("cus.crm.myaccounts", {
						validity: Infinity
					}).fail(function() {
						t.personalizationLoadFinished = true;
						t._bindTable();
					}).done(function(c) {
						t.oPersonalizationContainer = c;
						var P = c.getItemValue(t.personalizationKey);
						p.setValue(P);
						t.oTablePersoController.activate();
						t.personalizationLoadFinished = true;
						t._bindTable();
					});
				},
				isInConfigurationMode: function() {
					return this.configurationMode;
				},
				_savePersonalization: function() {
					this._bindTable(true);
					if (this.personalizationSaveRunning) return;
					var t = this;
					this.personalizationSaveRunning = true;
					this.oPersonalizationContainer.save().fail(function() {
						t.personalizationSaveRunning = false;
					}).done(function() {
						t.personalizationSaveRunning = false;
					});
				},
				_getParametersFromPersonalization: function() {
					var p = this.oPersonalizationContainer.getItemValue(this.personalizationKey);
					var e = "";
					var s = "*";
					var a = function(d) {
						var n = d.split("/");
						if (s.indexOf(d) < 0) {
							if (s.length) s = s + ",";
							s = s + d;
						}
						if (e.indexOf(n[0]) < 0) {
							if (e.length) e = e + ",";
							e = e + n[0];
						}
					};
					if (p && p.aColumns) {
						for (var i in p.aColumns) {
							if (p.aColumns[i].visible) {
								var c = this._getColumnIDFromPersonalizationColumn(p.aColumns[i]);
								var o = this._getOdataAttributeFromColumn(c);
								for (var z in o) a(o[z], e, s);
							}
						}
					} else {
						var C = this.getList().getAggregation("columns");
						var v = this.getView().getId();
						for (var i in C) {
							if (C[i].getVisible()) {
								var c = C[i].getId().replace(v + "--", "");
								var o = this._getOdataAttributeFromColumn(c);
								for (var z in o) a(o[z], e, s);
							}
						}
					}
					if (!e.length) return null;
					return {
						expand: e,
						select: s
					};
				},
				_getColumnIDFromPersonalizationColumn: function(c) {
					var k = c.id.split("empty_component-list-")[1];
					if (!k) k = c.id.split("cus.crm.myaccounts-list-")[1];
					return k;
				},
				_getOdataAttributeFromColumn: function(c) {
					var C = this.getView().byId(c);
					if (!C) return;
					var o = [];
					var a = C.getCustomData();
					for (var i in a) {
						var k = a[i].getKey();
						if (k === "odataAttribute") o.push(a[i].getValue());
					}
					return o;
				},
				onPersonalizationButtonPressed: function(e) {
					this.oTablePersoController.openDialog();
					if (!this.oTabPersonalizationDialog) {
						this.oTabPersonalizationDialog = this.oTablePersoController.getTablePersoDialog();
						var t = this;
						this.oTabPersonalizationDialog.attachConfirm(function() {
							var p = t.oTabPersonalizationDialog.retrievePersonalizations();
							t.oPersonalizationContainer.setItemValue(t.personalizationKey, p);
							t._savePersonalization();
						});
					}
				},
				toggleConfigurationMode: function() {
					this.configurationMode = !this.configurationMode;
					var b = this.byId("personalizationButton");
					b.setVisible(this.configurationMode);
					this.setHeaderFooterOptions(this._getHeaderFooterOptions());
				},
				destroy: function() {
					this.getList().getBinding("items").detachChange(this._onBindingChange, this);
				},
				onExit: function() {
					if (this.oCreateAccountActionSheet) {
						this.oCreateAccountActionSheet.destroy();
						this.oCreateAccountActionSheet = null;
					}
				}
			});
		},
		"cus/crm/myaccounts/view/search/SearchResult.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core" xmlns="sap.m" xmlns:layout="sap.ui.layout"\n\tcontrollerName="cus.crm.myaccounts.view.search.SearchResult">\n\t<Page id="page">\n\t\t<subHeader>\n\t\t\t<Toolbar>\n\t\t\t\t\t<SearchField id="mySearchField" search="onSearchPressed" showRefreshButton="{device>/isNoTouch}" placeholder="{i18n>SEARCH_ACCOUNTS}"/>\n\t\t\t\t\t<Button id="personalizationButton"\n\t\t\t\t\t\t\ticon="sap-icon://action-settings"\n\t\t\t\t\t\t\tvisible="{path:\'/\', formatter:\'.isInConfigurationMode\'}"\n\t\t\t\t\t\t\tpress="onPersonalizationButtonPressed"\n\t\t\t\t\t\t\tsize="1.2rem"/>\n\t\t\t</Toolbar>\n\t\t</subHeader>\n\t\t<content>\n\t\t\t<Table\n\t\t\t\tid="list"\n\t\t\t\tgrowing="true"\n\t\t\t\tgrowingThreshold="20"\n\t\t\t\tgrowingScrollToLoad="false">\n\t\t\t\t<columns>\n\t\t\t\t\t<Column id="imageColumn" width="3rem" testID="marcin" minScreenWidth="Small" demandPopin="true"><Text text="{i18n>IMAGE}"/>\n\t\t\t\t\t\t<customData><core:CustomData key="odataAttribute" value="Logo"/></customData></Column>\n\t\t\t\t\t<Column id="accountColumn" width="14rem" minScreenWidth="Small" demandPopin="true"><Text text="{i18n>NAME}" />\n\t\t\t\t\t\t<customData><core:CustomData key="odataAttribute" value="MainAddress"/></customData></Column>\n\t\t\t\t\t<Column id="ratingColumn" width="9rem" minScreenWidth="Small" demandPopin="true" visible="{device>/isNoPhone}"><Text text="{i18n>RATING}" />\n\t\t\t\t\t\t<customData><core:CustomData key="odataAttribute" value="Classification"/></customData></Column>\n\t\t\t\t\t<Column id="contactColumn" width="9rem" minScreenWidth="Medium" demandPopin="true" visible="{device>/isNoPhone}"><Text text="{i18n>CONTACT_TITLE}" />\n\t\t\t\t\t\t<customData><core:CustomData key="odataAttribute" value="MainContact"/></customData></Column>\n\t\t\t\t\t<Column id="opportunityVolumeColumn" width="7rem" minScreenWidth="Large" demandPopin="true" visible="{device>/isNoPhone}"><Text text="{i18n>OPPORTUNITIES}" />\n\t\t\t\t\t\t<customData><core:CustomData key="odataAttribute" value="AccountFactsheet/opportunityVolume"/></customData></Column>\n\t\t\t\t\t<Column id="revenueCurrentYearColumn" width="7rem" minScreenWidth="XLarge" demandPopin="true" visible="{device>/isNoPhone}"><Text text="{i18n>REVENUE_CURRENT}" />\n\t\t\t\t\t\t<customData><core:CustomData key="odataAttribute" value="AccountFactsheet/revenueCurrentYear"/></customData></Column>\n\t\t\t\t\t<Column id="lastContactColumn" width="7rem" minScreenWidth="XXLarge" demandPopin="true" visible="{device>/isNoPhone}"><Text text="{i18n>LAST_APPOINTMENT}" />\n\t\t\t\t\t\t<customData><core:CustomData key="odataAttribute" value="AccountFactsheet/lastContact"/></customData></Column>\n\t\t\t\t\t<Column id="nextContactColumn" width="7rem" minScreenWidth="XXLarge" demandPopin="true"><Text text="{i18n>NEXT_APPOINTMENT}" />\n\t\t\t\t\t    <customData><core:CustomData key="odataAttribute" value="AccountFactsheet/nextContact"/></customData></Column>\n\t\t\t\t\t<!-- Extends the Column -->\n\t\t\t\t\t<core:ExtensionPoint name="extResultListColumn"/>\n\t\t\t\t</columns>\n\t\t\t\t<items>\n\t\t\t\t\t<ColumnListItem id="columnListItem"\n\t\t\t\t\t\t\t\t \tpress="onAccountLinkClicked"\n\t\t\t\t\t\t\t\t\ttype="Active">\n\t\t\t\t\t\t<cells>\n\t\t\t\t\t\t\t<layout:VerticalLayout>\n\t\t\t\t\t\t\t\t<core:Icon\n\t\t\t\t\t\t\t\t\tsrc="{parts:[{path:\'Logo/__metadata/media_src\'},{path: \'category\'}], formatter:\'cus.crm.myaccounts.util.formatter.logoUrlFormatter\'}"\n\t\t\t\t\t\t\t\t\tvisible="{parts:[{path:\'accountID\'}, {path:\'Logo/__metadata/media_src\'}], formatter:\'cus.crm.myaccounts.util.formatter.standardIconVisibilityFormatter\'}"\n\t\t\t\t\t\t\t\t\tsize="2.5rem">\n\t\t\t\t\t\t\t\t</core:Icon>\n\t\t\t\t\t\t\t\t<Image\n\t\t\t\t\t\t\t\t\tsrc="{parts:[{path:\'Logo/__metadata/media_src\'},{path: \'category\'}], formatter:\'cus.crm.myaccounts.util.formatter.logoUrlFormatter\'}"\n\t\t\t\t\t\t\t\t\tvisible="{path:\'Logo/__metadata/media_src\', formatter:\'cus.crm.myaccounts.util.formatter.logoVisibilityFormatter\'}"\n\t\t\t\t\t\t\t\t\theight="2.5rem"\n\t\t\t\t\t\t\t\t\twidth="2.5rem">\n\t\t\t\t\t\t\t\t</Image>\n\t\t\t\t\t\t\t</layout:VerticalLayout>\n\t\t\t\t\t\t\t<VBox>\n\t\t\t\t\t\t\t\t<items>\n\t\t\t\t\t\t\t\t\t<Text id="fullNameText" text="{parts:[{path: \'fullName\'},{path: \'name1\'}], formatter: \'cus.crm.myaccounts.util.formatter.AccountNameFormatter\'}"/>\n\t\t\t\t\t\t\t\t\t<Text id="addressText" text="{parts:[{path:\'MainAddress/city\'}, {path:\'MainAddress/country\'}],formatter:\'cus.crm.myaccounts.util.formatter.locationFormatter\'}" />\n\t\t\t\t\t\t\t\t</items>\n\t\t\t\t\t\t\t</VBox>\n\t\t\t\t\t\t\t<Text text="{Classification/ratingText}" visible="{device>/isNoPhone}"/>\n\t\t\t\t\t\t\t<Text text="{MainContact/fullName}" visible="{device>/isNoPhone}"/>\n\t\t\t\t\t\t\t<Text text="{parts:[{path:\'AccountFactsheet/opportunityVolume/amount\'},{path:\'AccountFactsheet/opportunityVolume/currency\'}],\n\t\t\t\t\t\t\t\t\t\t formatter:\'cus.crm.myaccounts.util.formatter.formatShortAmounts\'}"\n\t\t\t\t\t\t\t\t  visible="{device>/isNoPhone}"/>\n\t\t\t\t\t\t\t<Text text="{parts:[{path:\'AccountFactsheet/revenueCurrentYear/amount\'},{path:\'AccountFactsheet/revenueCurrentYear/currency\'}],\n\t\t\t\t\t\t\t\t\t\t formatter:\'cus.crm.myaccounts.util.formatter.formatShortAmounts\'}"\n\t\t\t\t\t\t\t\t  visible="{device>/isNoPhone}"/>\n\t\t\t\t\t\t\t<Text text="{parts:[{path:\'AccountFactsheet/lastContact/toDate\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatMediumDate\'}"\n\t\t\t\t\t\t\t\t  visible="{device>/isNoPhone}"/>\n\t\t\t\t\t\t\t<Text text="{parts:[{path:\'AccountFactsheet/nextContact/fromDate\'}],formatter:\'cus.crm.myaccounts.util.formatter.formatMediumDate\'}"/>\n\t\t\t\t\t\t\t<!-- Extends the Column -->\n\t\t\t\t\t\t\t<core:ExtensionPoint name="extResultListColumnContent"/>\n\t\t\t\t\t\t</cells>\n\t\t\t\t\t</ColumnListItem>\n\t\t\t\t</items>\n\t\t\t</Table>\n\n\t\t</content>\n\t</Page>\n</core:View>\n'
	}
});