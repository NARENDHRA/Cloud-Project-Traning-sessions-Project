jQuery.sap.require("sap.ui.comp.odata.MetadataAnalyser");
jQuery.sap.require("sap.ui.comp.providers.ValueHelpProvider");
sap.ui.base.Object.extend('ZPRS_DISPUTES.util.Util', {
	_oBundle: null,
	_oODataModel: null,
	_oMetadataAnalyser: null,
	constructor: function(b, o) {
		this._oBundle = b;
		this._oODataModel = o;
	},
	getValueHelpPathForProperty: function(e, p) {
		if (!this._oMetadataAnalyser) {
			this._oMetadataAnalyser = new sap.ui.comp.odata.MetadataAnalyser(this._oODataModel);
		}
		var n = this._oMetadataAnalyser.getNamespace();
		var a = this._oMetadataAnalyser.getValueListAnnotation(n + '.' + e + '/' + p);
		if (!a || !a.primaryValueListAnnotation || !a.primaryValueListAnnotation.valueListEntitySetName) {
			jQuery.sap.log.error('valueListEntitySetName could not be determined from Metadata Annotations');
			return '';
		}
		var P = '/' + a.primaryValueListAnnotation.valueListEntitySetName;
		return P;
	},
	showErrorMessageDialog: function(m, d, D) {
		if (!m) {
			return;
		}
		var e = {
			msg: d,
			icon: 'sap-icon://warning2'
		};
		this.showMessageDialog(m, {
			messageDetails: [e],
			type: "Error",
			fnDialogClose: D
		});
	},
	showMessageDialog: function(m, p) {
		var t, s, d;
		var M = {};
		if (p) {
			t = p.title;
			s = p.type;
			M = p.messageDetails;
			d = p.fnDialogClose;
		}
		var D = new sap.m.Dialog({
			horizontalScrolling: false,
			type: "Message"
		});
		if (m) {
			D.addContent(new sap.m.Text({
				text: m,
				design: sap.m.LabelDesign.Bold
			}));
		}
		D.addButton(new sap.m.Button({
			text: this._oBundle.getText("CreateOkBtn"),
			press: function(e) {
				D.close();
				if (d) {
					d();
				}
			}
		}));
		D.addStyleClass("sapUiSizeCompact");
		if (s) {
			D.setState(s);
		}
		if (t) {
			D.setTitle(t);
		} else {
			if (s) {
				var c = 0;
				if (M) {
					jQuery.each(M, function(i, v) {
						if (v) {
							c++;
						}
					});
					M.length = c;
					if (M.length > 0) {
						switch (s) {
							case "Error":
							case sap.ui.core.ValueState.Error:
								D.setTitle(this._oBundle.getText("ErrorWithNo", M.length));
								break;
							case "Success":
							case sap.ui.core.ValueState.Success:
								D.setTitle(this._oBundle.getText("SuccessWithNo", M.length));
								break;
							case "Warning":
							case sap.ui.core.ValueState.Warning:
								D.setTitle(this._oBundle.getText("WarningWithNo", M.length));
								break;
							default:
								D.setTitle(this._oBundle.getText("NoneWithNo", M.length));
								break;
						}
					}
				}
				if (!D.getTitle()) {
					switch (s) {
						case "Error":
						case sap.ui.core.ValueState.Error:
							D.setTitle(this._oBundle.getText("Error"));
							break;
						case "Success":
						case sap.ui.core.ValueState.Success:
							D.setTitle(this._oBundle.getText("Success"));
							break;
						case "Warning":
						case sap.ui.core.ValueState.Warning:
							D.setTitle(this._oBundle.getText("Warning"));
							break;
						default:
							D.setTitle(this._oBundle.getText("None"));
							break;
					}
				}
			} else {
				D.setTitle(this._oBundle.getText("None"));
			}
		}
		if (M && M.length > 0) {
			var C = new sap.m.List({
				showSeparators: sap.m.ListSeparators.None
			});
			jQuery.each(M, function(i, v) {
				if (!v) {
					return;
				}
				var l = null;
				if (v.msg && v.icon) {
					l = new sap.m.FeedListItem({
						text: v.msg,
						icon: v.icon
					});
				} else if (v.msg) {
					l = new sap.m.FeedListItem({
						text: v.msg
					});
				} else if (typeof v === 'string') {
					l = new sap.m.FeedListItem({
						text: v,
						showIcon: false
					});
				}
				if (l) {
					C.addItem(l);
				}
			});
			if (C.getItems().length > 0) {
				D.addContent(C);
			}
		}
		D.open();
	},
	addExcelDownload: function(t, T) {
		var e = this.getView().getModel().getServiceMetadata().dataServices.schema[0].entityContainer;
		var E = false;
		for (var i = 0; i < e.length; i++) {
			if (e[i].isDefaultEntityContainer) {
				if (e[i].extensions) {
					for (var j = 0; j < e[i].extensions.length; j++) {
						if (e[i].extensions[j].name == "supported-formats") {
							if (e[i].extensions[j].value.indexOf("xlsx") >= 0) {
								E = true;
							}
							break;
						}
					}
				}
				break;
			}
		}
		if (E) {
			var b = new sap.m.Button("TableToolbarExportBtn", {
				tooltip: this.getView().getModel('i18n').getResourceBundle().getText("TABLE_EXPORT_TEXT"),
				icon: "sap-icon://excel-attachment",
				press: jQuery.proxy(function(o) {
					if (t.getTotalSize() > 10000) {
						var c = !!this.getView().$().closest(".sapUiSizeCompact").length;
						jQuery.sap.require("sap.m.MessageBox");
						sap.m.MessageBox.confirm(this.getView().getModel('i18n').getResourceBundle().getText("DOWNLOAD_CONFIRMATION_TEXT", t.getTotalSize()), {
							actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
							styleClass: c ? "sapUiSizeCompact" : "",
							onClose: function(a) {
								if (a == sap.m.MessageBox.Action.YES) {
									var u = t.getBinding("rows").getDownloadUrl("xlsx");
									window.open(u);
								}
							}
						});
					} else {
						var u = t.getBinding("rows").getDownloadUrl("xlsx");
						window.open(u);
					}
				}, this)
			});
			T.addContent(b);
			b.setEnabled(false);
		}
	},
	activateExcelDownload: function(t, c) {
		var C = t.getContent();
		var b = jQuery.grep(C, function(a, i) {
			return a.getId() === "TableToolbarExportBtn";
		});
		if (b.length > 0) {
			if (c > 0) b[0].setEnabled(true);
			else b[0].setEnabled(false);
		}
	},
	provideSearchHelp: function(p) {
		var c, e, P, d, m, M;
		c = p.control;
		e = p.entity;
		P = p.property;
		d = p.dialogTitle;
		m = p.maxSuggestionWidth;
		if (c) {
			M = c.getModel();
		}
		if (!c || !e || !P || !M) {
			jQuery.sap.log.error("ProvideSearchHelpDialog: Missing input parameters to provide search help for control");
			return false;
		}
		if (!c.getBindingContext()) {
			jQuery.sap.log.warning(
				"ProvideSearchHelpDialog: Binding context for control is missing. Be sure that it will be set later in order to get the search help working."
			);
		}
		if (c.setFilterSuggests) {
			c.setFilterSuggests(false);
		}
		c.setShowSuggestion(true);
		c.setShowValueHelp(true);
		c.attachSuggest(sap.m.InputODataSuggestProvider.suggest);
		if (m) {
			c.setMaxSuggestionWidth(m);
		}
		if (!d) {
			var s = "/#{0}/{1}/@sap:label";
			var a = jQuery.sap.formatMessage(s, [e, P]);
			d = M.getProperty(a);
			if (!d) {
				d = P;
				jQuery.sap.log.error("ProvideSearchHelpDialog: No title for dialog given and could not determine title from metadata " + e + "/" + P);
			}
		}
		var o = new sap.ui.comp.odata.MetadataAnalyser(M);
		var A = o.getNamespace() + "." + e + "/" + P;
		var v = o.getValueListAnnotation(A);
		if (!v || !v.primaryValueListAnnotation || v.primaryValueListAnnotation.length === 0) {
			jQuery.sap.log.error("ProvideSearchHelpDialog: Could not determine annotations for" + e + "/" + P);
			return false;
		}
		var V = new sap.ui.comp.providers.ValueHelpProvider({
			annotation: v.primaryValueListAnnotation,
			additionalAnnotations: v.additionalAnnotations,
			control: c,
			model: M,
			preventInitialDataFetchInValueHelpDialog: true,
			supportMultiSelect: false,
			supportRanges: true,
			fieldName: P,
			title: d
		});
	}
});