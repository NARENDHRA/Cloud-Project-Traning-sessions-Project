jQuery.sap.declare("ZPRS_DISPUTES.util.VariantMgmt");
jQuery.sap.require("sap.ui.comp.variants.VariantManagement");
jQuery.sap.require("sap.ui.table.TablePersoController");
sap.ui.base.Object.extend("ZPRS_DISPUTES.util.VariantMgmt", {
	oTableToolbar: null,
	oController: null,
	sVariant: null,
	constructor: function(c, t, T, v) {
		this.oTableToolbar = t;
		this.oController = c;
		this.sVariant = v;
		if (!sap.ushell || !sap.ushell.Container || !sap.ushell.Container.getService("Personalization")) {
			return;
		}
		var p = sap.ushell.Container.getService("Personalization").getTransientPersonalizer();
		var o = new sap.ui.table.TablePersoController({
			table: T,
			autoSave: false,
			persoService: p
		});
		var d = this,
			V = '',
			s = '',
			n = false;
		V = new sap.ui.comp.variants.VariantManagement({
			save: function(e) {
				var k = e.getParameter("key"),
					f = e.getParameter("name");
				var g = '';
				if (!e.getParameter("overwrite")) {
					if (!d.oVariantSet.getVariantKeyByName(f)) {
						g = d.oVariantSet.addVariant(f);
						s = g.getVariantKey();
					} else {
						s = d.oVariantSet.getVariantKeyByName(f);
						g = d.oVariantSet.getVariant(s);
						sap.m.MessageToast.show(d.oController.getView().getModel('i18n').getResourceBundle().getText("VARIANT_OVERWRITTEN", f));
					}
				} else {
					g = d.oVariantSet.getVariant(k);
					s = k;
				}
				if (e.getParameter("def")) {
					d.oVariantSet.setCurrentVariantKey(s);
					V.setDefaultVariantKey(s);
				} else if (d.oVariantSet.getCurrentVariantKey() == s) {
					d.oVariantSet.setCurrentVariantKey('');
					V.setDefaultVariantKey('');
				}
				o.savePersonalizations();
				if (g) {
					g.setItemValue("table", p.getValue());
					d.oContainer.save().fail(function() {}).done(function() {
						var h = d.oVariantSet.getVariantKeys();
						var j = {
							variant: []
						};
						for (var i = 0; i < h.length; i++) {
							j.variant.push({
								text: d.oVariantSet.getVariant(h[i]).getVariantName(),
								key: h[i]
							});
						};
						j.variant.sort(function(a, b) {
							if (a.text > b.text) return 1;
							if (a.text < b.text) return -1;
							return 0;
						});
						var l = s;
						V.destroyItems();
						n = true;
						for (var i = 0; i < j.variant.length; i++) {
							V.addItem(new sap.ui.core.Item({
								text: j.variant[i].text,
								key: j.variant[i].key
							}));
						};
						V.setInitialSelectionKey(l);
						s = l;
						n = false;
					});
				}
			},
			manage: function(e) {
				var r = e.getParameter("renamed"),
					D = e.getParameter("deleted"),
					f = false;
				for (var i = 0; i < r.length; i++) {
					var g = d.oVariantSet.getVariant(r[i].key);
					var I = g.getItemValue("table");
					d.oVariantSet.delVariant(r[i].key);
					g = d.oVariantSet.addVariant(r[i].name);
					g.setItemValue("table", I);
				}
				for (var i = 0; i < D.length; i++) {
					d.oVariantSet.delVariant(D[i]);
					if (d.oVariantSet.getCurrentVariantKey() == d.oVariantSet.delVariant(D[i])) {
						f = true;
					}
				}
				d.oContainer.save().fail(function() {}).done(function() {
					if (r.length) {
						var h = d.oVariantSet.getVariantKeys();
						var j = {
							variant: []
						};
						for (var i = 0; i < h.length; i++) {
							j.variant.push({
								text: d.oVariantSet.getVariant(h[i]).getVariantName(),
								key: h[i]
							});
						};
						j.variant.sort(function(a, b) {
							if (a.text > b.text) return 1;
							if (a.text < b.text) return -1;
							return 0;
						});
						V.destroyItems();
						n = true;
						for (var i = 0; i < j.variant.length; i++) {
							V.addItem(new sap.ui.core.Item({
								text: j.variant[i].text,
								key: j.variant[i].key
							}));
						};
						n = false;
					}
					if (f) {
						V.setInitialSelectionKey('');
						d.oVariantSet.setCurrentVariantKey('');
					} else {
						V.setInitialSelectionKey(s);
					}
				});
			},
			select: function(e) {
				if (!n) {
					s = e.getParameter("key");
					var a = d.oVariantSet.getVariant(s);
					if (a) {
						p.setValue(a.getItemValue("table"));
						o.refresh();
					}
				}
			}
		});
		this.oTableToolbar.addContent(V);
		this.oTablePersoController = o;
		var B = new sap.m.Button({
			icon: "sap-icon://action-settings",
			press: function(e) {
				d.oTablePersoController.openDialog();
			}
		});
		this.oTableToolbar.addContent(B);
		sap.ushell.Container.getService("Personalization").getContainer("ZPRS_DISPUTES.VariantsALV" + this.sVariant, {
			validity: Infinity
		}).fail(function() {}).done(function(C) {
			d.oContainer = C;
			d.oVariantSetAdapter = new sap.ushell.services.Personalization.VariantSetAdapter(C);
			d.oVariantSet = d.oVariantSetAdapter.getVariantSet("Default");
			if (!d.oVariantSet) {
				d.oVariantSetAdapter.addVariantSet("Default");
				d.oVariantSet = d.oVariantSetAdapter.getVariantSet("Default");
			}
			var e = d.oVariantSet.getVariantKeys();
			var f = {
				variant: []
			};
			for (var i = 0; i < e.length; i++) {
				f.variant.push({
					text: d.oVariantSet.getVariant(e[i]).getVariantName(),
					key: e[i]
				});
			};
			f.variant.sort(function(a, b) {
				if (a.text > b.text) return 1;
				if (a.text < b.text) return -1;
				return 0;
			});
			d.oModel = new sap.ui.model.json.JSONModel(f);
			V.setModel(d.oModel);
			var I = new sap.ui.core.Item({
				text: "{text}",
				key: "{key}"
			});
			V.bindAggregation("items", "/variant", I);
			s = d.oVariantSet.getCurrentVariantKey();
			if (s) {
				var g = d.oVariantSet.getVariant(s);
				if (g) {
					V.setInitialSelectionKey(s);
					V.setDefaultVariantKey(s);
					p.setValue(g.getItemValue("table"));
					o.refresh();
				}
			}
		});
	}
});