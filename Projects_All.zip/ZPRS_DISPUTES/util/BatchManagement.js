(function() {
	var c = {
		constructor: function(m, C) {
			this._oModel = m;
			this._aBatch = [];
			this._oContext = C;
		},
		addBatchRequest: function(p, o, s, e, E) {
			var b = this._oModel.createBatchOperation(p, o, E);
			var B = {
				operation: b,
				method: o,
				onSuccess: jQuery.proxy(s, this._oContext),
				onError: jQuery.proxy(e, this._oContext)
			};
			this._aBatch.push(B);
			switch (o) {
				case 'GET':
					return this._oModel.addBatchReadOperations([b]);
				case 'POST':
				case 'PUT':
				case 'MERGE':
				case 'DELETE':
					return this._oModel.addBatchChangeOperations([b]);
				default:
					throw 'Unsupported operation: "' + o + '"';
			}
		},
		addBatchRequestObject: function(r) {
			this.addBatchRequest(r.sPath, r.sOperation, r.fnSuccess, r.fnError, r.oEntry);
		},
		submit: function(r, e, s) {
			var E = jQuery.noop;
			var f = jQuery.proxy(r, this._oContext) || E;
			var a = jQuery.proxy(e, this._oContext) || E;
			var b = jQuery.proxy(s, this._oContext) || E;
			var B = jQuery.proxy(function(o) {
				this._handleCompleteRequestFailed();
				var D = this.parseErrorMessage(o);
				a(D);
				f();
			}, this);
			var d = jQuery.proxy(function(D, R) {
				this._handleBatchResult(D, R, b, a);
				f();
			}, this);
			this._oModel.submitBatch(d, B);
		},
		parseResponse: function(d, s, e) {
			var r = null;
			var D = null;
			if (d.__changeResponses) {
				if (d.__changeResponses.length === 1) {
					r = d.__changeResponses[0];
				} else {
					throw "Bundling of multiple changes in one change request is not supported";
				}
			} else {
				D = (d.data && d.data.results) || d.data;
				r = d;
			}
			var C = r.statusCode || r.response.statusCode;
			if (200 <= C && C < 400) {
				if (s) {
					s(D, r, C);
				}
			} else if (400 <= C && C < 600) {
				if (e) {
					var m = c.parseErrorMessage(r);
					e(r, C, m);
				}
			}
		},
		parseErrorMessage: function(e) {
			var r = '';
			var s = '';
			var m = '';
			var R = null;
			if (e && e.response && e.response.body) {
				R = e.response;
			} else if (e && e.body) {
				R = e;
			} else if (typeof e === 'string' || e instanceof String) {
				m = c.getXmlError(e).join(" ");
				return m || e;
			} else {
				return '';
			}
			r = R.body;
			s = R.statusText;
			if (R.headers) {
				var C = c._getHeader(R.headers, 'Content-Type');
				var a = (C || '').split(';')[0];
				switch (a) {
					case 'text/plain':
						m = r;
						break;
					case 'application/json':
						m = c.getJsonError(r).join(" ");
						break;
					case 'application/xml':
						m = c.getXmlError(r).join(" ");
						break;
				}
			}
			return m || s || '';
		},
		getXmlError: function(r) {
			var x;
			try {
				x = jQuery.parseXML(r);
			} catch (e) {
				jQuery.sap.log.error("Could not parse response as XML", e);
			}
			if (!x) {
				return [];
			}
			var m = [];
			var E = jQuery(x).find("errordetail");
			jQuery.each(E, function(i, o) {
				o = jQuery(o);
				var C = o && o.find("code") && o.find("code").length > 0 && o.find("code")[0] && o.find("code")[0].innerHTML || null;
				if (C === "/IWBEP/CX_MGW_BUSI_EXCEPTION") {
					return;
				}
				var s = o && o.find("message") && o.find("message").length > 0 && o.find("message")[0] && o.find("message")[0].innerHTML || null;
				if (s) {
					m.push(s);
				}
			});
			if (m.length > 0) {
				return m;
			}
			var M = jQuery(x).find("message");
			jQuery.each(M, function(i, o) {
				var s = o && o.innerHTML;
				m.push(s);
			});
			return m;
		},
		getJsonError: function(r) {
			var j;
			try {
				j = jQuery.parseJSON(r);
			} catch (e) {
				jQuery.sap.log.error("Could not parse response as JSON", e);
			}
			var m = [];
			if (j && j.error && j.error.innererror && j.error.innererror.errordetails && j.error.innererror.errordetails.length > 0) {
				jQuery.each(j.error.innererror.errordetails, function(E, o) {
					if (o && o.code === "/IWBEP/CX_MGW_BUSI_EXCEPTION") {
						return;
					}
					var M = o.message || null;
					if (M) {
						m.push(M);
					}
				});
			}
			if (m.length > 0) {
				return m;
			}
			var M = j && j.error && j.error.message && j.error.message.value;
			if (M) {
				return [M];
			} else {
				return [];
			}
		},
		_getHeader: function(h, H) {
			var u = H.toUpperCase();
			for (var k in h) {
				if (!h.hasOwnProperty(k)) {
					continue;
				}
				if (k.toUpperCase() === u) {
					return h[k];
				}
			}
			return;
		},
		_handleBatchResult: function(d, r, s, e) {
			var R = d.__batchResponses;
			var u = [];
			var b = r.statusCode === 202;
			var a = R.length === this._aBatch.length;
			if (!b || !a) {
				var B = null;
				if (!b) {
					B = this.parseErrorMessage(r);
				}
				this._handleCompleteRequestFailed();
				e(B, R);
				return;
			}
			jQuery.each(R, jQuery.proxy(function(i, v) {
				var o = this._aBatch[i];
				var S = o.onSuccess;
				var f = function(r) {
					u.push(r);
				};
				var E = o.onError || f;
				this.parseResponse(v, S, E);
			}, this));
			if (u.length > 0) {
				var D = jQuery.map(u, jQuery.proxy(function(v) {
					return this.parseErrorMessage(v.response);
				}, this)).join("\n\n");
				e(D, u);
			} else {
				s(d, r);
			}
			this._aBatch = [];
		},
		_handleCompleteRequestFailed: function() {
			jQuery.each(this._aBatch, function(i, r) {
				if (r.onError) {
					r.onError();
				}
			});
		}
	};
	sap.ui.base.Object.extend('ZPRS_DISPUTES.util.BatchManagement', c);
})();