sap.ui.base.Object.extend('ZPRS_DISPUTES.util.Formatters', {
	_oBundle: null,
	constructor: function(o) {
		this._oBundle = o;
	},
	address: function(a) {
		if (!a) {
			return "";
		}
		var r = a.split("/").join("\n");
		return r;
	},
	stringToVisibility: function(s) {
		var r = false;
		if (s && s.length > 0) {
			r = true;
		}
		return r;
	},
	customerNameFromDescription: function(d) {
		var s = '/';
		var S = d && d.indexOf(s);
		if (!d || S === -1 || S === 0) {
			return d;
		}
		return d.substring(0, S);
	},
	otherActionsVisibility: function(h) {
		if (!h) {
			return false;
		} else {
			return h;
		}
	},
	link: function(l, c, C) {
		c = encodeURIComponent(c);
		C = encodeURIComponent(C);
		return jQuery.sap.formatMessage(l, c, C);
	},
	month: function(m) {
		return sap.ui.core.format.DateFormat.getDateInstance().aMonthsAbbrev[m - 1];
	},
	collectionGroupFilter: function(g, G) {
		if (!g) {
			return G;
		}
		var b = this.oApplicationFacade.getResourceBundle();
		return b.getText('CW_COLLECTION_GROUP_FILTER_TEXT', [g, G]);
	},
	stripLeadingZerosFromNumber: function(v) {
		var V = parseInt(v, 10);
		if (isNaN(V)) {
			return v;
		}
		return V;
	},
});