jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");
jQuery.sap.require('sap.ca.ui.model.format.AmountFormat');
jQuery.sap.require('sap.ca.ui.model.type.Date');
jQuery.sap.require("ZPRS_DISPUTES.util.VariantMgmt");
jQuery.sap.require("ZPRS_DISPUTES.util.Formatters");
jQuery.sap.require("ZPRS_DISPUTES.view.CustomerPopover");
jQuery.sap.require("ZPRS_DISPUTES.view.ChangeContentDialog");
jQuery.sap.require("sap.ca.ui.message.message");
jQuery.sap.require("ZPRS_DISPUTES.util.Formatters");
jQuery.sap.require("ZPRS_DISPUTES.util.Util");
sap.ca.scfld.md.controller.BaseFullscreenController.extend("ZPRS_DISPUTES.view.DisputeList", {
  oDataModel: null,
  oBundle: null,
  oJsonModel: null,
  oActionSheetPopover: null,
  oChangeContentDialog: null,
  oCustomerPopover: null,
  oCrossAppNavigator: null,
  oFilterBar: null,
  format: null,
  onInit: function() {
    sap.ca.scfld.md.controller.BaseFullscreenController.prototype.onInit.call(this);
    this.oActionSheetPopover = sap.ui.xmlfragment('ActionSheetPopover', 'ZPRS_DISPUTES.view.ActionSheetPopoverDisputeList',
      this);
    this.getView().addDependent(this.oActionSheetPopover);
    this.oDataModel = this.oApplicationFacade.getODataModel();
    sap.ca.scfld.md.controller.BaseFullscreenController.prototype.onInit.call(this);
    var f = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService;
    this.oCrossAppNavigator = f && f("CrossApplicationNavigation");
    this.oDataModel.attachMetadataFailed(function(E) {
      var r = null;
      try {
        r = E.getParameter("mParameters").responseText;
        r = jQuery.parseHTML(r)[1].getElementsByTagName("message")[0].innerText;
      } catch (e) {
        r = null;
      }
      if (r) {
        var S = {
          type: sap.ca.ui.message.Type.ERROR,
          message: r,
        };
        sap.ca.ui.message.showMessageBox(S);
      } else {}
    });
    this.oBundle = this.getView().getModel('i18n').getResourceBundle();
    this.oDataModel.attachRejectChange(function(e) {
      var S = {
        type: sap.ca.ui.message.Type.ERROR,
        message: this.oBundle.getText("DisputeListToastRejectChange"),
      };
      sap.ca.ui.message.showMessageBox(S);
    }, this);
    this.initJsonModel();
    this.oRouter.attachRoutePatternMatched(this.onRouteMatched, this);
    this.oUtil = new ZPRS_DISPUTES.util.Util(this.oBundle, this.oDataModel);
    this.format = new ZPRS_DISPUTES.util.Formatters(this.oBundle);
    var d = this.getView().byId("DisputeTableALV");
    var t = this.getView().byId('DisputeTableALVToolbar');
    jQuery.proxy(this.oUtil.addExcelDownload, this)(d, t);
    this.oVariantMgmnt = new ZPRS_DISPUTES.util.VariantMgmt(this, t, d, "D");
    var s = jQuery.proxy(function(e) {
      var d = this.byId("DisputeTableALV");
      d.clearSelection();
    }, this);
    this.oChangeContentDialog = new ZPRS_DISPUTES.view.ChangeContentDialog(this.getView(), s);
  },
  initJsonModel: function() {
    this.oJsonModel = new sap.ui.model.json.JSONModel();
    this.oJsonModel.setProperty('/DisputeListHeader', this.oBundle.getText('DisputeListHeaderInitial'));
    this.oJsonModel.setProperty('/DisputeListHeaderNoDataText', this.oBundle.getText('DisputeListNoDataTextNoDisputes'));
    this.getView().setModel(this.oJsonModel, 'json');
  },
  initBindings: function(f) {
    this.initBindingsALV(f);
  },
  initBindingsALV: function(f) {
    var a = f;
    var s = [new sap.ui.model.Sorter('ExternalKey', true), ];
    var d = this.byId("DisputeTableALV");
    d.bindRows({
      path: '/DisputeSet',
      filters: a,
      sorter: s,
      parameters: {
        useBatchRequests: true
      }
    });
    d.getBinding().attachDataRequested(this.onDataRequested, this);
    d.getBinding().attachDataReceived(jQuery.proxy(this.onDataReceived, this));
  },
  onDataRequested: function(e) {
    var d = this.byId("DisputeTableALV");
    d.setBusyIndicatorDelay(1000);
    d.setBusy(true);
  },
  onDataReceived: function() {
    var d = this.byId("DisputeTableALV");
    var c = d.getTotalSize();
    var h = this.oBundle.getText("DisputeListHeader", [c]);
    this.oJsonModel.setProperty('/DisputeListHeader', h);
    var t = this.getView().byId('DisputeTableALVToolbar');
    this.oUtil.activateExcelDownload(t, c);
    d.setBusy(false);
    d.setShowOverlay(false);
    d.setNoData(this.oBundle.getText('DisputeListNoDataTextNoDisputes'));
  },
  ensureFilterBarCreation: function() {
    var o = sap.ui.core.Component.getOwnerIdFor(this.getView());
    var c = sap.ui.component(o);
    var C = c.getComponentData();
    var f = this.byId('SelectionPanel');
    if (f.getContent().length !== 0) {
      return;
    }
    var p = C && C.startupParameters;
    var m = p && p.MyDisputes && p.MyDisputes.length && p.MyDisputes[0];
    switch (m) {
      case "Processor":
        this.oFilterBar = sap.ui.xmlfragment('ZPRS_DISPUTES.view.SelectionParametersProcessor', this);
        f.addContent(this.oFilterBar);
        break;
      case "Coordinator":
        this.oFilterBar = sap.ui.xmlfragment('ZPRS_DISPUTES.view.SelectionParametersCoordinator', this);
        f.addContent(this.oFilterBar);
        break;
      case "Responsible":
        this.oFilterBar = sap.ui.xmlfragment('ZPRS_DISPUTES.view.SelectionParametersResponsible', this);
        f.addContent(this.oFilterBar);
        break;
      default:
        this.oFilterBar = sap.ui.xmlfragment('ZPRS_DISPUTES.view.SelectionParametersDefault', this);
        f.addContent(this.oFilterBar);
        break;
    }
  },
  initFilterBarValuesAccordingToStartupParameters: function() {
    var o = sap.ui.core.Component.getOwnerIdFor(this.getView());
    var c = sap.ui.component(o);
    var C = c.getComponentData();
    var p = C && C.startupParameters;
    var m = p && p.MyDisputes && p.MyDisputes.length && p.MyDisputes[0];
    switch (m) {
      case "Processor":
        var f = this.oFilterBar.getControlByKey('Processor');
        f.setValue(this.currentUser());
        break;
      case "Coordinator":
        var f = this.oFilterBar.getControlByKey('Coordinator');
        f.setValue(this.currentUser());
        break;
      case "Responsible":
        var f = this.oFilterBar.getControlByKey('Responsible');
        f.setValue(this.currentUser());
        break;
    }
  },
  handleRouteWithParameters: function(e) {
    var h = window.location.hash;
    //if (!(h.indexOf("DisputeCase-manageDispute") > -1)) {
    if (!(h.indexOf("ZPRS_DISPUTES-manageDispute") > -1)) {
      return;
    }
    if (!e.getParameter('arguments') || !e.getParameter('arguments')['?query']) {
      return;
    }
    var E = e.getParameter('arguments')['?query'];
    var a = {};
    jQuery.each(E, function(i, v) {
      a[i] = decodeURIComponent(v);
    });
    var n = a.filterBar;
    var c = this.oFilterBar.getFilterDataAsString();
    if (n != c) {
      this.oFilterBar.setFilterDataAsString(n);
      var f = this.oFilterBar.getAllFilterItems(false);
      var j = JSON.parse(n);
      jQuery.each(f, function(i, v) {
        if (!v.setVisibleInAdvancedArea) {
          return;
        }
        if (j[v.getName()]) {
          v.setVisibleInAdvancedArea(true);
        }
      });
    }
    var F = this.oFilterBar.getFilters();
    this.prepareFiltersForOdata(F || []);
    this.initBindings(F);
  },
  onRouteMatched: function(e) {
    var r = e.getParameter("name");
    this.ensureFilterBarCreation();
    var d = this.byId("DisputeTableALV");
    d.clearSelection();
    if (r === "DisputeListWithParameters") {
      this.handleRouteWithParameters(e);
    } else if (r === "DisputeList") {
      this.initFilterBarValuesAccordingToStartupParameters();
      var f = this.oFilterBar.getFilters();
      if (f && f.length) {
        this.updateNavigationState();
      }
    }
  },
  updateNavigationState: function() {
    var f = this.oFilterBar && this.oFilterBar.getFilterDataAsString();
    var p = {
      query: {
        filterBar: f
      }
    };
    jQuery.each(p.query, function(i, v) {
      p.query[i] = encodeURIComponent(v);
    });
    this.oRouter.navTo('DisputeListWithParameters', p, true);
  },
  currentUser: function() {
    var u = '';
    if (sap.ushell && sap.ushell.Container) {
      var U = sap.ushell.Container.getService("UserInfo");
      u = U.getId() || u;
    }
    return u;
  },
  onStartSearch: function(e) {
    this.updateNavigationState();
  },
  prepareFiltersForOdata: function(f) {
    if (f.length == 0) {
      f.push(new sap.ui.model.Filter('SystemStatus', sap.ui.model.FilterOperator.LT, '007'));
    }
    var F = this.getFieldsByEntitySetName(this.getView().getModel(), 'DisputeSet');
    this.convertDatesToUtc(f, F);
    this.addDefaultFilter(f);
  },
  addDefaultFilter: function(f) {
    if (this.checkDefaultFilterRequired(f)) {
      f.push(new sap.ui.model.Filter('SystemStatus', sap.ui.model.FilterOperator.LT, '007'));
    }
  },
  checkDefaultFilterRequired: function(f) {
    var d = true;
    jQuery.each(f, jQuery.proxy(function(i, a) {
      if (a.aFilters && a.aFilters.length > 0) {
        d = this.checkDefaultFilterRequired(a.aFilters);
      } else {
        var p = a.sPath;
        if (p && (p === "SystemStatus" || p == "Status")) {
          d = false;
          return false;
        }
      }
    }, this));
    return d;
  },
  convertDatesToUtc: function(f, F) {
    jQuery.each(f, jQuery.proxy(function(i, a) {
      if (a.aFilters && a.aFilters.length > 0) {
        this.convertDatesToUtc(a.aFilters, F);
      } else {
        var p = a.sPath;
        if (jQuery.grep(F, function(b, i) {
            return b.name === p && b.type == "Edm.DateTime";
          }).length > 0) {
          if (a.oValue1) this.dateToUTC(a.oValue1);
          if (a.oValue2) this.dateToUTC(a.oValue2);
        }
      }
    }, this));
  },
  dateToUTC: function(d) {
    var y = d.getFullYear();
    var a = d.getDate();
    var m = d.getMonth();
    d.setTime(Date.UTC(y, m, a));
  },
  getFieldsByEntitySetName: function(m, s) {
    var a = new sap.ui.comp.odata.MetadataAnalyser(m);
    var f = a.getFieldsByEntitySetName(s);
    return f;
  },
  openCustomerPopover: function(c, s) {
    if (!c || !c.getProperty('Customer')) {
      return;
    }
    this.initActions();
    if (!this.oCustomerPopover) {
      this.oCustomerPopover = new ZPRS_DISPUTES.view.CustomerPopover(this.oView);
    }
    this.oCustomerPopover.openBy(c, s);
  },
  onCustomerLinkPressed: function(e) {
    var c = e.getSource();
    var C = c.getBindingContext();
    this.openCustomerPopover(C, c);
  },
  onActionsShow: function(e) {
    var b = sap.ui.core.Fragment.byId("ActionSheetPopover", "ZPRS_DISPUTES.bookmarkBtn");
    if (this.oActionSheetPopover.isOpen()) {
      this.oActionSheetPopover.close();
      return;
    }
    var t = this.oBundle.getText("SaveAsTileTitle");
    var c = {
      title: t,
      icon: "sap-icon://Fiori2/F0106",
    };
    b.setAppData(c);
    var s = e.getSource();
    this.oActionSheetPopover.openBy(s);
  },
  getIdFromColumn: function(c, t) {
    var T = this.byId(t);
    var C = T.getColumns();
    var v;
    var o = null;
    var s = null;
    var i;
    for (i = 0, v = -1; i < C.length; i++) {
      o = C[i];
      if (!o.getVisible()) {
        continue;
      }
      v++;
      if (v === c) {
        s = o.getId();
        break;
      }
    }
    return s;
  },
  onCellClick: function(e) {
    var c = e.getParameter('cellControl');
    var C = c.getBindingContext();
    var i = parseInt(e.getParameter('columnIndex'), 10);
    var s = this.getIdFromColumn(i, 'DisputeTableALV');
    var a = this.byId('CustomerNoALV').getId();
    if (s === a) {
      this.openCustomerPopover(C, c);
      return;
    }
    this.navigateToDetails(C);
  },
  onRowSelectionChange: function(e) {
    var v = this.getView();
    var c = v.byId("changeProcessorBtn");
    var d = this.byId("DisputeTableALV");
    var s = d.getSelectedIndices();
    if (s.length == 0) {
      c.setEnabled(false);
    } else if (s.length == 1) {
      c.setEnabled(true);
    } else if (s.length > 1) {
      c.setEnabled(true);
    }
  },
  onNavigateToDetails: function(e) {
    var d = this.byId("DisputeTableALV");
    var s = d.getSelectedIndices();
    if (s.length == 0) return;
    var b = d.getContextByIndex(s[0]);
    if (b) {
      this.navigateToDetails(b);
    }
  },
  navigateToDetails: function(b) {
    var c = b.getProperty("CaseGuid");
    if (c) {
      var p = {
        CaseGuid: c
      };
      this.oRouter.navTo('toDetails', p);
    }
  },
  onChangeContentProcessor: function(e) {
    this.changeContent("Processor");
  },
  changeContent: function(c) {
    var d = this.byId("DisputeTableALV");
    var s = d.getSelectedIndices();
    var D = jQuery.map(s, function(r) {
      var b = d.getContextByIndex(r);
      if (!b) {
        return;
      }
      var p = b.getPath();
      var o = b.getObject();
      var a = {
        "path": p,
        "data": o
      };
      return a;
    });
    this.oChangeContentDialog.open(D);
  },
  navBack: function() {
    window.history.back();
  },
  initActions: function() {
    if (this.oJsonModel.getProperty('/Actions')) {
      return;
    }
    var s = 'Customer';
    var p = this.oCrossAppNavigator.getSemanticObjectLinks(s);
    p.fail(jQuery.proxy(function() {
      this.oJsonModel.setProperty('/Actions', null);
      this.oJsonModel.setProperty('/ActionsAvailable', false);
      this.oJsonModel.setProperty('/HasActionFactSheet', false);
    }, this));
    p.done(jQuery.proxy(function(l) {
      var a = [];
      var h = false;
      if (l && l.length) {
        var u = sap.ushell.Container.getService('URLParsing');
        var c = this.oCrossAppNavigator.hrefForExternal();
        for (var i = 0; i < l.length; i++) {
          var I = l[i].intent;
          var t = l[i].text;
          var H = "#" + I;
          if (H.indexOf(c) === 0) {
            continue;
          }
          var S = u.parseShellHash(I);
          if (S.action === 'displayFactSheet' && !h) {
            h = true;
            continue;
          }
          a.push({
            text: t,
            linkPattern: '#' + I + '?Customer={0}&CompanyCode={1}'
          });
        }
      }
      var P = {
        'Win8.0': /Windows NT 6.2/i.test(navigator.userAgent.toLowerCase()),
        'Win8.1': /Windows NT 6.3/i.test(navigator.userAgent.toLowerCase()),
      };
      var b = sap.ui.Device.os.ios || P['Win8.0'] || P['Win8.1'];
      if (b) {
        var t = this.oBundle.getText('CustomerActionAppFinfact');
        var d = 'sapcustfactcustomer://showCustomer?CustomerNo={0}';
        a.push({
          text: t,
          linkPattern: d
        });
      }
      this.oJsonModel.setProperty('/Actions', a);
      this.oJsonModel.setProperty('/ActionsAvailable', a && a.length > 0);
      this.oJsonModel.setProperty('/HasActionFactSheet', h);
    }, this));
  },
  onExit: function() {}
});