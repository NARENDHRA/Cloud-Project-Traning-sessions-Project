jQuery.sap.require("sap.ui.model.SimpleType");
sap.ui.model.SimpleType.extend("ZPRS_DISPUTES.Util.InputMailRecipientValidationType", {
	formatValue: function(v) {
		return v;
	},
	parseValue: function(v) {
		return v;
	},
	validateValue: function(v) {
		this._validateMultipleRecipients(v);
	},
	_validateMultipleRecipients: function(r) {
		var R = r && r.split(";") || [];
		return jQuery.grep(R, jQuery.proxy(function(s) {
			if (!s || !s.trim()) {
				return false;
			} else if (this._isValidMail(s)) {
				return true;
			} else {
				throw new sap.ui.model.ValidateException();
			}
		}, this)).length;
	},
	_isValidMail: function(m) {
		var M = m && m.trim();
		if (!M) {
			return false;
		} else if (M.indexOf("@") < 0) {
			return false;
		} else if (M.indexOf(" ") >= 0) {
			return false;
		}
		return true;
	}
});
ZPRS_DISPUTES.Util.InputMailRecipientValidationType.extend(
	"ZPRS_DISPUTES.Util.InputMailRecipientMandatoryValidationType", {
		validateValue: function(v) {
			var c = this._validateMultipleRecipients(v);
			if (c <= 0) {
				throw new sap.ui.model.ValidateException();
			}
		}
	});
sap.ui.base.Object.extend("ZPRS_DISPUTES.view.CreateCorrespondenceDialog", {
	_sFragmentId: "",
	_oView: null,
	_oModel: null,
	_oLocalJson: null,
	_oUtil: null,
	_oBundle: null,
	_oDialog: null,
	_sBindingPath: "",
	_oUpdateCall: null,
	constructor: function(v) {
		this._sFragmentId = v.getId() + "-" + "CreateCorrespondenceDialog";
		this._oView = v;
		this._oModel = v.getModel();
		this._oBundle = v.getModel("i18n").getResourceBundle();
		this._oUtil = new ZPRS_DISPUTES.util.Util(this._oBundle, this._oModel);
		this._oDialog = null;
		this._initJsonModel();
	},
	open: function(b, s) {
		if (!this._oDialog) {
			this._oDialog = sap.ui.xmlfragment(this._sFragmentId, "ZPRS_DISPUTES.view.CreateCorrespondenceDialog", this);
			this._oView.addDependent(this._oDialog);
			this._oDialog.setModel(this._oLocalJson, "localJson");
		}
		this._sBindingPath = b;
		this._fnSuccess = s;
		var B = {
			path: this._sBindingPath,
			parameters: {
				expand: "GetNotes,GetLinkedObjects,GetAttachments"
			}
		};
		this._oDialog.bindElement(B);
		this._registerInputErrorHandlers();
		this._bindTemplateList();
		this._resetValues();
		this._oDialog.open();
	},
	_byId: function(i) {
		return sap.ui.core.Fragment.byId(this._sFragmentId, i);
	},
	_registerInputErrorHandlers: function() {
		this._byId("inputReceiver").attachValidationError(this._validationErrorHandler, this).attachValidationSuccess(this._validationSuccessHandler,
			this);
		this._byId("inputCopyReceiver").attachValidationError(this._validationErrorHandler, this).attachValidationSuccess(this._validationSuccessHandler,
			this);
	},
	_validationSuccessHandler: function(e) {
		var i = e.getSource();
		if (i.setValueState) {
			i.setValueState();
		}
	},
	_validationErrorHandler: function(e) {
		var i = e.getSource();
		if (i.setValueState) {
			i.setValueState(sap.ui.core.ValueState.Error);
		}
	},
	_onConfirmDialog: function() {
		var s = function() {
			this._oSaveBusyDialog.close();
			this._oDialog.close();
			sap.m.MessageToast.show(this._oBundle.getText("SendCorrespondenceSent"));
			if (this._fnSuccess) {
				this._fnSuccess();
			}
		};
		var e = function(r) {
			this._oSaveBusyDialog.close();
			if (r) {
				var m = ZPRS_DISPUTES.util.BatchManagement.prototype.parseErrorMessage(r);
				this._oUtil.showErrorMessageDialog(m);
			}
		};
		if (!this._oSaveBusyDialog) {
			this._oSaveBusyDialog = new sap.m.BusyDialog({
				text: this._oBundle.getText("SendCorrespondenceProgress")
			});
		}
		this._oSaveBusyDialog.open();
		this._sendCreateMailRequest(true, s, e);
	},
	_onCancelDialog: function() {
		this._oDialog.close();
	},
	_onTemplateSelectionChanged: function() {
		this._loadLanguages();
	},
	_onTemplateLanguageSelectionChanged: function() {
		this._updatePreview();
	},
	_onNoteSelectionChanged: function() {
		this._scheduleUpdatePreview();
	},
	_scheduleUpdatePreview: function() {
		if (this._oUpdateCall) {
			jQuery.sap.clearDelayedCall(this._oUpdateCall);
		}
		this._oUpdateCall = jQuery.sap.delayedCall(200, this, function() {
			this._updatePreview();
		});
	},
	_updatePreview: function() {
		var c = "<iframe style=\"width:95%;height:100%;overflow-x:hidden;overflow-y:scroll;position:absolute;\" />";
		var h = this._byId("HtmlPreview");
		h.setContent(c);
		h.setPreferDOM(true);
		var s = function(r) {
			var S = r.EmailSubject;
			var H = r.EmailBodyHtml;
			var o = this._byId("inputSubject");
			o.setText(S);
			var f = jQuery("[id='" + h.getId() + "']");
			f.contents().find("html").html(H);
		};
		var e = function(r) {
			var m = ZPRS_DISPUTES.util.BatchManagement.prototype.parseErrorMessage(r);
			this._oUtil.showErrorMessageDialog(m);
		};
		this._sendCreateMailRequest(false, s, e);
	},
	_sendCreateMailRequest: function(s, S, e) {
		var l = this._byId("NoteList");
		var a = l.getSelectedContexts();
		var c = jQuery.map(a, function(i) {
			var g = i.getProperty("NoteContent");
			return g;
		});
		c.push(this._byId("customNote").getValue());
		var n = c.join("\n\n");
		var E = jQuery.proxy(e, this);
		var b = this._oLocalJson.getProperty("/SelectedTemplate");
		var d = this._oLocalJson.getProperty("/SelectedTemplateLanguage");
		if (!b || !d) {
			E();
			return;
		}
		var C = this._oDialog.getBindingContext();
		var D = {
			CaseGuid: C.getProperty("CaseGuid"),
			LastChangeDateTime: C.getProperty("LastChangeDateTime"),
			EmailTemplate: b,
			EmailID: "",
			EmailTemplateLanguage: d,
			EmailSendIndicator: s,
			EmailRecipients: this._oLocalJson.getProperty("/MailReceiver"),
			EmailCcRecipients: this._oLocalJson.getProperty("/MailCopyReceiver"),
			FreeDefinedNote: n
		};
		var f = jQuery.proxy(function(r, D) {
			this._oModel.setRefreshAfterChange(false);
			var j = D && D.headers && D.headers["sap-message"];
			if (j) {
				var m;
				var J;
				try {
					J = jQuery.parseJSON(j);
					m = J && J.message || j;
				} catch (o) {
					jQuery.sap.log.error("Could not parse response as JSON", o);
					m = j;
				}
				if (J && J.severity === "error") {
					E(m);
					return;
				} else if (m) {
					this._oUtil.showErrorMessageDialog(m);
				}
			}
			if (S) {
				jQuery.proxy(S, this, r, D)();
			}
		}, this);
		var p = {
			success: f,
			error: E,
			async: true
		};
		this._oModel.setRefreshAfterChange(false);
		this._oModel.create("/CaseMailSet", D, p);
	},
	_onAddNote: function(e) {
		var i = e.getSource();
		var t = i.getBindingContext().getProperty("NoteContent");
		var c = this._byId("customNote");
		var C = c.getValue();
		if (C) {
			C += "\n\n";
		}
		C += t;
		c.setValue(C);
		this._scheduleUpdatePreview();
	},
	_initJsonModel: function() {
		this._oLocalJson = new sap.ui.model.json.JSONModel();
		this._oLocalJson.setProperty("/LanguagesAvailable", false);
	},
	_bindTemplateList: function() {
		var t = this._byId("inputTemplate");
		var T = new sap.ui.core.Item({
			key: {
				path: "ID"
			},
			text: {
				parts: ["NAME", "ID"],
				formatter: this._formatFirstString
			}
		});
		var f = new sap.ui.model.Filter({
			path: "CDS_VIEW",
			operator: sap.ui.model.FilterOperator.EQ,
			value1: "UDMO_V_CM_ATTR_VIEW"
		});
		var p = {
			path: "/VL_SH_SMTG_TMPL_ID",
			template: T,
			filters: [f],
			events: {
				dataRequested: jQuery.proxy(function() {
					this._oLocalJson.setProperty("/LanguagesAvailable", false);
				}, this),
				dataReceived: jQuery.proxy(function(e) {
					var c = e.getSource();
					var C = c.getContexts();
					var s = "UDMO_INFO_TO_CUSTOMER";
					var i = jQuery.grep(C, function(T) {
						return T.getProperty("ID") === s;
					}).length > 0;
					if (!i) {
						s = C && C[0] && C[0].getProperty("ID");
					}
					this._oLocalJson.setProperty("/SelectedTemplate", s);
					this._onTemplateSelectionChanged();
				}, this)
			}
		};
		t.bindAggregation("items", p);
	},
	_loadLanguages: function() {
		var s = this._oLocalJson.getProperty("/SelectedTemplate");
		if (!s) {
			return;
		}
		this._oLocalJson.setProperty("/LanguagesAvailable", false);
		this._oLocalJson.setProperty("/SelectedTemplateLanguage", null);
		var f = new sap.ui.model.Filter({
			path: "ID",
			operator: sap.ui.model.FilterOperator.EQ,
			value1: s
		});
		var p = {
			filters: [f],
			sorters: [new sap.ui.model.Sorter("SPTXT"), new sap.ui.model.Sorter("LANGU")],
			success: jQuery.proxy(function(d) {
				var l = d.results;
				var S;
				var c = sap.ui.getCore().getConfiguration().getLanguage();
				var C = c && c.toUpperCase();
				var i = jQuery.grep(l, function(I) {
					return I.LANGU === C;
				}).length > 0;
				if (i) {
					S = C;
				} else {
					S = l.length > 0 && l[0] && l[0].LANGU || null;
				}
				this._oLocalJson.setProperty("/Languages", l);
				this._oLocalJson.setProperty("/LanguagesAvailable", l.length > 0);
				this._oLocalJson.setProperty("/SelectedTemplateLanguage", S);
				this._onTemplateLanguageSelectionChanged();
			}, this)
		};
		this._oModel.read("/VL_SH_UDMO_TMPL_CONT", p);
	},
	_resetValues: function() {
		this._byId("customNote").setValue("");
		this._oLocalJson.setProperty("/MailCopyReceiver", "");
		var r = this._oDialog.getBindingContext() && this._oDialog.getBindingContext().getProperty("ContactPersonEmailAddress") || "";
		this._oLocalJson.setProperty("/MailReceiver", r);
	},
	_getCurrentUser: function() {
		var u;
		if (sap.ushell && sap.ushell.Container) {
			u = sap.ushell.Container.getService("UserInfo");
		}
		return u.getId();
	},
	_formatFirstString: function() {
		var r = "";
		jQuery.each(arguments, function(i, I) {
			var b = jQuery.type(I) === "string";
			if (b && I) {
				r = I;
				return false;
			}
		});
		return r;
	},
	_formatCanSendMail: function(s, S, m, M, a) {
		var c = s && S && m !== sap.ui.core.ValueState.Error && M !== sap.ui.core.ValueState.Error && a;
		return !!c;
	}
});