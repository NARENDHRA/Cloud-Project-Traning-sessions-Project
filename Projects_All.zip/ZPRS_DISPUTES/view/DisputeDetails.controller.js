jQuery.sap.require("sap.m.TablePersoController");
jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");
jQuery.sap.require("sap.ca.ui.model.format.AmountFormat");
jQuery.sap.require("sap.ca.ui.model.type.FileSize");
jQuery.sap.require("sap.ca.ui.model.type.Date");
jQuery.sap.require("sap.ca.ui.model.type.DateTime");
jQuery.sap.require("sap.ui.model.SimpleType");
jQuery.sap.require("sap.m.MessageBox");
jQuery.sap.require("sap.ui.comp.odata.MetadataAnalyser");
jQuery.sap.require("ZPRS_DISPUTES.util.Util");
jQuery.sap.require("ZPRS_DISPUTES.util.BatchManagement");
jQuery.sap.require("ZPRS_DISPUTES.view.CreateCorrespondenceDialog");
sap.ca.scfld.md.controller.BaseFullscreenController.extend("ZPRS_DISPUTES.view.DisputeDetails", {
	sPath: null,
	sCaseGuid: null,
	oBundle: null,
	oDataModel: null,
	oDispute: null,
	oUnchangedDispute: null,
	oLoadBusyDialog: null,
	oSaveBusyDialog: null,
	oFormErrors: null,
	aDisputeMetadata: [],
	aAttributeSet: [],
	aStatusListControls: [],
	oDeferredLinkedObjectsLoaded: null,
	oJsonModel: null,
	onInit: function() {
		sap.ca.scfld.md.controller.BaseFullscreenController.prototype.onInit.call(this);
		var f = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService;
		this.oCrossAppNavigator = f && f("CrossApplicationNavigation");
		this.initJsonModel();
		this.detectCodeline();
		sap.ui.model.SimpleType.extend('ZPRS_DISPUTES.Util.EmptyToNullType', {
			oDefaultNullValue: null,
			constructor: function(d) {
				this.oDefaultNullValue = d;
			},
			formatValue: function(v) {
				return v || '';
			},
			parseValue: function(v) {
				return v || this.oDefaultNullValue;
			},
			validateValue: function() {}
		});
		sap.ui.model.SimpleType.extend('ZPRS_DISPUTES.Util.InputValidationType', {
			oParameters: null,
			oBundle: null,
			constructor: function(b, p) {
				this.oBundle = b;
				this.oParameters = p || {};
			},
			formatValue: function(v) {
				return v;
			},
			parseValue: function(v) {
				return v;
			},
			validateValue: function(v) {
				var m;
				if (this.oParameters.IsMandatory && !v) {
					m = this.oBundle.getText("InputValidationMandatoryField");
					throw new sap.ui.model.ValidateException(m);
				} else if (this.oParameters.MaxLength && v && v.length > this.oParameters.MaxLength) {
					m = this.oBundle.getText("InputValidationMaxLength", [this.oParameters.MaxLength]);
					throw new sap.ui.model.ValidateException(m);
				}
			}
		});
		sap.ui.model.SimpleType.extend('ZPRS_DISPUTES.Util.CheckBoxForString', {
			formatValue: function(v) {
				return v;
			},
			parseValue: function(v) {
				if (v) {
					return "X";
				} else {
					return "";
				}
			},
			validateValue: function() {}
		});
		sap.ui.model.SimpleType.extend('ZPRS_DISPUTES.Util.UTCDate', {
			formatValue: function(v) {
				if (!v) {
					return v;
				}
				var y = v.getUTCFullYear();
				var m = v.getUTCMonth();
				var d = v.getUTCDate();
				return new Date(y, m, d);
			},
			parseValue: function(v) {
				if (!v) {
					return v;
				}
				var y = v.getFullYear();
				var m = v.getMonth();
				var d = v.getDate();
				var u = Date.UTC(y, m, d);
				return new Date(u);
			},
			validateValue: function() {}
		});
		this.oFormErrors = {};
		this.byId("customerFields").attachValidationError(function(e) {
			var i = e.getSource();
			var E = e.getParameter('exception');
			if (i.setValueState) {
				i.setValueState(sap.ui.core.ValueState.Error);
			}
			if (i.setValueStateText) {
				i.setValueStateText(E && E.message);
			}
			this.oFormErrors[i.getId()] = true;
			this.updateSaveButtonState();
		}, this);
		this.byId('customerFields').attachValidationSuccess(function(e) {
			var i = e.getSource();
			if (i.setValueState) {
				i.setValueState(sap.ui.core.ValueState.None);
			}
			if (i.setValueStateText) {
				i.setValueStateText();
			}
			delete this.oFormErrors[i.getId()];
			this.updateSaveButtonState();
		}, this);
		this.oDataModel = this.oApplicationFacade.getODataModel();
		this.oBundle = this.getView().getModel("i18n").getResourceBundle();
		this.oLoadBusyDialog = new sap.m.BusyDialog({
			text: this.oBundle.getText("DisputeDetailLoadingDispute")
		});
		this.oSaveBusyDialog = new sap.m.BusyDialog({
			text: this.oBundle.getText("DisputeDetailSavingDispute")
		});
		this.oUtil = new ZPRS_DISPUTES.util.Util(this.oBundle, this.oDataModel);
		this.oRouter.attachRoutePatternMatched(this.routePatternMatched, this);
		this.oDeferredLinkedObjectsLoaded = jQuery.Deferred();
		this.oDeferredLinkedObjectsLoaded.done(jQuery.proxy(this.checkNavigationTargets, this));
	},
	routePatternMatched: function(e) {
		if (e.getParameter("name") !== "toDetails") {
			return;
		}
		var a = e.getParameter("arguments");
		this.sCaseGuid = a.CaseGuid;
		this.CaseAlvGuid = a.CaseAlvGuid;
		this.oLoadBusyDialog.open();
		if (this.CaseAlvGuid) {
			this.sPath = "/DisputeSet('" + this.CaseAlvGuid + "')";
			this.initBindings();
		} else if (this.sCaseGuid) {
			this.loadDisputeByCaseGuid(this.sCaseGuid);
		} else {
			return;
		}
	},
	initJsonModel: function() {
		this.oJsonModel = new sap.ui.model.json.JSONModel();
		this.oJsonModel.setSizeLimit(Number.MAX_VALUE);
		var a = {
			CustomerFactSheet: false,
			AccountingDocumentApp: false
		};
		this.oJsonModel.setProperty('/AppsAvailable', a);
		this.oJsonModel.setProperty('/EditMode', true);
		this.getView().setModel(this.oJsonModel, 'json');
	},
	detectCodeline: function() {
		var i = false;
		if (ZPRS_DISPUTES.fin_lib.sap.fin.central.lib.environ.ApplicationContext.isSInnovation()) {
			i = true;
		}
		this.oJsonModel.setProperty("/HasDisputeMail", i);
	},
	checkNavigationTargets: function() {
		var i = [];
		var c = "#Customer-displayFactSheet";
		i.push(c);
		var a = "#AccountingDocument-manage";
		i.push(a);
		var p = this.oCrossAppNavigator.isIntentSupported(i);
		p.done(jQuery.proxy(function(t) {
			if (t && t[c]) {
				this.oJsonModel.setProperty('/AppsAvailable/CustomerFactSheet', t[c].supported !== false);
			}
			if (t && t[a]) {
				this.oJsonModel.setProperty('/AppsAvailable/AccountingDocumentApp', t[a].supported !== false);
			}
			this.oJsonModel.checkUpdate(true);
		}, this));
	},
	getDisputeEntityPathFromCaseGuid: function() {
		var d = jQuery.Deferred();
		var s = jQuery.proxy(function(D) {
			var o = D.results[0];
			var i = o.Identifier;
			var E = encodeURIComponent(sap.ui.model.odata.ODataUtils.formatValue(i, 'Edm.String'));
			var P = "/DisputeSet({0})";
			var a = jQuery.sap.formatMessage(P, [E]);
			d.resolveWith(this, [a]);
		}, this);
		var e = jQuery.proxy(function(E) {
			d.rejectWith(this, [E]);
		}, this);
		var f = [new sap.ui.model.Filter('CaseGuid', 'EQ', this.sCaseGuid)];
		var p = {
			filters: f,
			success: s,
			error: e
		};
		this.oDataModel.read("/DisputeSet", p);
		return d.promise();
	},
	loadDisputeByCaseGuid: function() {
		this.getDisputeEntityPathFromCaseGuid().done(function(p) {
			this.sPath = p;
			this.initBindings();
		}).fail(function(d) {
			this.oLoadBusyDialog.close();
			var D = ZPRS_DISPUTES.util.BatchManagement.prototype.parseErrorMessage(d) || null;
			var m = this.oBundle.getText('batch_failed');
			var f = jQuery.proxy(function() {
				this.navBack();
			}, this);
			this.oUtil.showErrorMessageDialog(m, D, f);
		});
	},
	initBindings: function() {
		var v = this.getView();
		var b = v.getBindingContext();
		var p = b && b.getProperty("CaseType");
		if (b && (b.getPath() !== this.sPath)) {
			v.unbindElement();
		}
		var B = jQuery.proxy(function(e) {
			var s = e.getSource();
			var b = s.getBoundContext();
			if (!b) {
				s.detachChange(B, this);
				return;
			}
			var c = b.getProperty("CaseType");
			this.oDispute = b.getObject();
			this.oUnchangedDispute = jQuery.extend(true, {}, this.oDispute);
			this.triggerRefreshStatusLists();
			if (this.byId("customerFields").getContent().length === 0 || (p && (p !== c))) {
				this.loadCustomerFields(c);
			} else {
				var E = ((this.oDispute.SystemStatus < 7) !== this.oJsonModel.getProperty("/EditMode"));
				var a = this.oDispute.SystemStatus < 7;
				this.oJsonModel.setProperty("/EditMode", a);
				if (E) {
					var w = this.byId("customerFields");
					w.destroyContent();
					this.aStatusListControls = [];
					this.renderCustomerFields(this.aAttributeSet, this.aDisputeMetadata, w);
				}
				this.oLoadBusyDialog.close();
				this.oSaveBusyDialog.close();
			}
		}, this);
		var o = {
			path: this.sPath,
			events: {
				change: B
			},
			parameters: {
				expand: "GetNotes,GetLinkedObjects,GetAttachments"
			}
		};
		v.bindElement(o);
		this.updateSaveButtonState();
		this.setFileUploaderPath();
	},
	setFileUploaderPath: function() {
		var v = this.getView();
		var f = v.byId("attachmentFileUploader");
		var F = this.oDataModel.sServiceUrl + this.sPath + "/GetAttachments";
		f.setUploadUrl(F);
	},
	onDisputeAttachmentPressed: function(e) {
		var s = e.getSource();
		var b = s.getBindingContext();
		var m = b.getObject().__metadata.media_src;
		window.open(m);
	},
	onDisputeAttachmentDeletePressed: function(e) {
		var s = e.getSource();
		var p = s.getBindingContext().getPath();
		if (this.hasPendingChanges()) {
			this.oUtil.showMessageDialog(this.oBundle.getText("AttachmentDeleteNotPossibleDialogText"), {
				title: this.oBundle.getText("AttachmentDeleteNotPossibleDialogTitle"),
				type: sap.ui.core.ValueState.Warning
			});
			return;
		}
		var h = jQuery.proxy(function(a) {
			if (a !== sap.m.MessageBox.Action.OK) {
				return;
			}
			this.oSaveBusyDialog.open();
			var S = jQuery.proxy(function() {
				this.oSaveBusyDialog.close();
				this.oLoadBusyDialog.open();
				this.loadDisputeByCaseGuid(this.sCaseGuid);
			}, this);
			var E = jQuery.proxy(function(r) {
				var m = ZPRS_DISPUTES.util.BatchManagement.prototype.parseErrorMessage(r);
				if (m) {
					this.oUtil.showErrorMessageDialog(m);
				}
				this.oSaveBusyDialog.close();
			}, this);
			var P = {
				success: S,
				error: E,
				async: true
			};
			this.oDataModel.remove(p, P);
		}, this);
		sap.m.MessageBox.confirm(this.oBundle.getText("AttachmentDeleteDialogText"), h);
	},
	onAttachmentFileUploaderChanged: function(e) {
		var v = this.getView();
		var f = v.byId("attachmentFileUploader");
		f.removeAllHeaderParameters();
		var F = e.getParameter("newValue");
		var t = this.oDataModel.getSecurityToken();
		var c = new sap.ui.unified.FileUploaderParameter({
			name: "x-csrf-token",
			value: t
		});
		var C = new sap.ui.unified.FileUploaderParameter({
			name: "slug",
			value: F
		});
		f.addHeaderParameter(c);
		f.addHeaderParameter(C);
		this.updateSaveButtonState();
		v.byId("BtnCleanAttachmentFileUploader").setEnabled(true);
	},
	cleanAttachmentFileUploader: function() {
		var v = this.getView();
		var f = v.byId("attachmentFileUploader");
		f.clear();
		v.byId("BtnCleanAttachmentFileUploader").setEnabled(false);
	},
	onAttachmentUploadComplete: function(p, e) {
		var x = e.getParameter("readyStateXHR");
		var s = e.getParameter("status");
		var r = e.getParameter("response");
		if (x === 4) {
			if (r && s === 201) {
				p.resolveWith(this, [r]);
			} else {
				var X = e.getParameter("responseRaw");
				p.rejectWith(this, [X]);
			}
		}
	},
	attachmentLoadingFinsihed: function(e) {
		var a = e.getParameter("actual");
		var t = this.byId("textAttachmentsHeader");
		var T = this.oBundle.getText("DisputeDetailLabelAttachmentsWithCount", [a]);
		t.setText(T);
	},
	linkedObjectsLoadingFinsihed: function(e) {
		var a = e.getParameter("actual");
		var t = this.byId("textLinkedObjectsHeader");
		var T = this.oBundle.getText("DisputeDetailLabelDisputedObjectsWithCount", [a]);
		t.setText(T);
		this.oDeferredLinkedObjectsLoaded.resolve();
	},
	prepareMetadataForCustomerFields: function() {
		var m = this.oDataModel.getServiceMetadata();
		var d = [];
		var s = null;
		var a = [];
		var M = new sap.ui.comp.odata.MetadataAnalyser(this.oDataModel);
		var S = M.getNamespace();
		var D = M.getFieldsByEntitySetName("DisputeSet");
		jQuery.each(D, function(i, v) {
			var b = true;
			if (v.nullable === 'false') {
				b = false;
			}
			d[v.name] = {
				type: v.type,
				nullable: b
			};
			if (v.maxLength) {
				var l = parseInt(v.maxLength, 10);
				if (l > 0) {
					d[v.name].maxLength = l;
				}
			}
			if (v.extensions) {
				jQuery.each(v.extensions, function(c, e) {
					switch (e.name) {
						case "label":
							d[v.name].text = e.value;
							break;
						case "unit":
							d[v.name].unitField = e.value;
							break;
						case "text":
							d[v.name].descr = e.value;
							break;
					}
				});
			}
		});
		jQuery.each(m.dataServices.schema, function(i, v) {
			if (v.namespace === S) {
				s = v;
				return false;
			}
		});
		if (!s) {
			return false;
		}
		if (s.annotations) {
			jQuery.each(s.annotations, function(i, v) {
				if (v.target.indexOf(".Dispute/") !== -1) {
					var p = v.target.substr(v.target.indexOf(".Dispute/") + 9);
					var A = {};
					if (!v.annotation[0].record) {
						return true;
					}
					jQuery.each(v.annotation[0].record.propertyValue, function(i, v) {
						if (v.property === "CollectionPath") {
							A.collectionPath = v.string;
						}
						if (v.property === "Parameters") {
							var r = v.collection.record;
							jQuery.each(r, function(i, R) {
								if (R.propertyValue[0].propertyPath === p) {
									A.key = R.propertyValue[1].string;
								}
							});
							jQuery.each(r, function(b, c) {
								if (b !== 0 && c.type === "com.sap.vocabularies.Common.v1.ValueListParameterInOut") {
									if (!A.inParams) {
										A.inParams = [];
									}
									A.inParams.push({
										"valueList": c.propertyValue[1].string,
										"dataProperty": c.propertyValue[0].propertyPath
									});
								}
								jQuery.each(s.entityType, function(i, e) {
									if (e.name === A.collectionPath) {
										var f = e.property[0];
										var E = f.extensions;
										jQuery.each(E, function(i, o) {
											if (o.name === "text") {
												A.descr = o.value;
											}
										});
									}
								});
							});
						}
					});
					A.propertyName = p;
					a.push(A);
				}
			});
		}
		jQuery.each(a, function(i, v) {
			if (d[v.propertyName]) {
				d[v.propertyName].annotation = v;
			} else {
				jQuery.sap.log.warning("ZPRS_DISPUTES.view.DisputeDetails: Property missing for Dispute entity", v.propertyName);
			}
		});
		return d;
	},
	renderCustomerFields: function(c, d, w) {
		var g = [];
		c = jQuery.extend(true, {}, c);
		var s = parseInt(this.oDispute.SystemStatus, 10);
		if (s >= 7) {
			this.oJsonModel.setProperty("/EditMode", false);
			jQuery.each(c, function(a, C) {
				C.DisplayOnly = true;
			});
		}
		jQuery.each(c, jQuery.proxy(function(a, v) {
			if (!g[v.GroupID]) {
				var S = new sap.ui.layout.form.SimpleForm({
					layout: sap.ui.layout.form.SimpleFormLayout.ResponsiveGridLayout,
					maxContainerCols: 2,
					emptySpanL: 2,
					width: "100%",
					title: v.GroupTitle,
					editable: true
				});
				S.addContent(new sap.ui.core.Title());
				w.addContent(S);
				g[v.GroupID] = {
					elem: S
				};
			}
			var S = g[v.GroupID].elem;
			if (a > 0) {
				var C = parseInt(v.RowNo, 10);
				var b = parseInt(c[a - 1].RowNo, 10);
				var e = parseInt(v.ColumnNo, 10);
				var f = parseInt(c[a - 1].ColumnNo, 10);
				if (((C - b) > 1) && e === f) {
					var n = C - b - 1;
					for (var i = 0; i < n; i++) {
						S.addContent(new sap.m.Label());
						S.addContent(new sap.m.Text());
					}
				}
				if (f === 1 && e === 2) {
					S.addContent(new sap.ui.core.Title());
				}
			}
			if (v.Hidden) {
				S.addContent(new sap.m.Label());
				S.addContent(new sap.m.Text());
				return;
			}
			var l = new sap.m.Label({
				text: v.Attribute
			});
			var I = null;
			var o = null;
			var B = null;
			if (v.DisplayOnly) {
				if (v.IsCheckbox) {
					I = new sap.m.CheckBox();
					I.setEnabled(false);
					B = {
						path: v.Attribute
					};
					I.bindProperty("selected", B);
				} else {
					I = new sap.m.Text();
					I.setTextAlign(sap.ui.core.TextAlign.End);
					switch (d[v.Attribute].type) {
						case "Edm.DateTime":
							B = {
								path: v.Attribute,
								type: "sap.ca.ui.model.type.DateTime",
								formatOptions: {
									style: 'medium'
								}
							};
							break;
						case "Edm.Date":
							B = {
								path: v.Attribute,
								type: "sap.ca.ui.model.type.Date",
								formatOptions: {
									style: 'medium'
								}
							};
							break;
						case "Edm.Decimal":
							if (d[v.Attribute].unitField) {
								B = {
									parts: [v.Attribute, d[v.Attribute].unitField],
									formatter: sap.ca.ui.model.format.AmountFormat.FormatAmountStandardWithCurrency
								};
							} else {
								B = {
									path: v.Attribute
								};
							}
							break;
						default:
							if (d[v.Attribute].descr) {
								B = {
									path: d[v.Attribute].descr
								};
							} else {
								B = {
									path: v.Attribute
								};
							}
					}
					I.bindProperty("text", B);
				}
			} else {
				if (v.IsCheckbox) {
					I = new sap.m.CheckBox();
					B = {
						path: v.Attribute,
						mode: sap.ui.model.BindingMode.TwoWay
					};
					if (d[v.Attribute].type !== "Edm.Boolean") {
						B.type = new ZPRS_DISPUTES.Util.CheckBoxForString();
					}
					I.bindProperty("selected", B);
				} else if (v.IsDropdown) {
					var h = null;
					if (v.Attribute === "Status") {
						h = new sap.ui.core.Item({
							text: "{StatusDescription}",
							key: "{Status}"
						});
						I = new sap.m.ComboBox({
							items: {
								path: "/GetValidStatusList",
								template: h,
								parameters: {
									custom: {
										CaseType: "'" + this.oDispute.CaseType + "'",
										CurrentStatus: "'" + this.oDispute.Status + "'"
									}
								},
								events: {
									dataReceived: function() {
										I.bindProperty('selectedKey', {
											path: v.Attribute,
											mode: sap.ui.model.BindingMode.TwoWay,
											type: new ZPRS_DISPUTES.Util.EmptyToNullType('0')
										});
									}
								}
							}
						});
						this.aStatusListControls.push(I);
					} else {
						if (d[v.Attribute].annotation) {
							var A = d[v.Attribute].annotation;
							h = new sap.ui.core.Item({
								text: "{" + A.descr + "}",
								key: "{" + A.key + "}"
							});
							var F = [];
							if (A.inParams) {
								jQuery.each(A.inParams, jQuery.proxy(function(a, p) {
									F.push(new sap.ui.model.Filter(p.valueList, sap.ui.model.FilterOperator.StartsWith, this.oDispute[p.dataProperty]));
								}, this));
							}
							var D = '';
							if (d[v.Attribute].type === "Edm.Decimal") {
								D = '0';
							}
							I = new sap.m.ComboBox({
								items: {
									path: "/" + A.collectionPath,
									template: h,
									filters: F,
									events: {
										dataReceived: function() {
											I.bindProperty('selectedKey', {
												path: v.Attribute,
												mode: sap.ui.model.BindingMode.TwoWay,
												type: new ZPRS_DISPUTES.Util.EmptyToNullType(D)
											});
										}
									}
								}
							});
						} else {
							if (d[v.Attribute].descr) {
								h = new sap.ui.core.Item({
									text: "{" + d[v.Attribute].descr + "}",
									key: "{" + v.Attribute + "}"
								});
							} else {
								h = new sap.ui.core.Item({
									text: "{" + v.Attribute + "}",
									key: "{" + v.Attribute + "}"
								});
							}
							I = new sap.m.ComboBox({
								items: [h]
							});
						}
					}
				} else {
					switch (d[v.Attribute].type) {
						case "Edm.DateTime":
							I = new sap.m.DatePicker();
							B = {
								path: v.Attribute,
								mode: sap.ui.model.BindingMode.TwoWay,
								type: 'ZPRS_DISPUTES.Util.UTCDate'
							};
							I.bindProperty("dateValue", B);
							break;
						case "Edm.Date":
							I = new sap.m.DatePicker();
							B = {
								path: v.Attribute,
								mode: sap.ui.model.BindingMode.TwoWay
							};
							I.bindProperty("value", B);
							break;
						case "Edm.Decimal":
							I = new sap.m.Input({
								width: "100%",
								showValueStateMessage: true,
								valueLiveUpdate: true
							});
							if (d[v.Attribute].maxLength) {
								I.setMaxLength(d[v.Attribute].maxLength);
							}
							var V = {
								IsMandatory: !d[v.Attribute].nullable
							};
							B = {
								path: v.Attribute,
								mode: sap.ui.model.BindingMode.TwoWay,
								type: new ZPRS_DISPUTES.Util.InputValidationType(this.oBundle, V)
							};
							I.bindProperty("value", B);
							break;
						default:
							I = new sap.m.Input({
								valueLiveUpdate: true
							});
							if (d[v.Attribute].maxLength) {
								I.setMaxLength(d[v.Attribute].maxLength);
							}
							B = {
								path: v.Attribute,
								mode: sap.ui.model.BindingMode.TwoWay
							};
							I.bindProperty("value", B);
							I.setModel(this.oDataModel);
							if (d[v.Attribute].annotation) {
								this.oUtil.provideSearchHelp({
									control: I,
									entity: "Dispute",
									property: v.Attribute
								});
							}
					}
				}
				var j = jQuery.proxy(function() {
					this.updateSaveButtonState();
				}, this);
				if (I.attachLiveChange) {
					I.attachLiveChange(j);
				} else if (I.attachSelectionChange) {
					I.attachSelectionChange(j);
				} else if (I.attachSelect) {
					I.attachSelect(j);
				} else if (I.attachChange) {
					I.attachChange(j);
				} else {
					jQuery.sap.log.warning("ZPRS_DISPUTES.view.DisputeDetails: Control not supported to enable update button", I);
				}
			}
			if (d[v.Attribute]) {
				if (d[v.Attribute].text) {
					l.setText(d[v.Attribute].text);
				} else {
					l.setText(v.Attribute);
				}
			}
			S.addContent(l);
			if (o) {
				S.addContent(o);
				o = null;
			} else {
				S.addContent(I);
			}
		}, this));
		this.oLoadBusyDialog.close();
	},
	loadCustomerFields: function(c) {
		this.aDisputeMetadata = this.prepareMetadataForCustomerFields();
		var w = this.byId("customerFields");
		w.destroyContent();
		this.aStatusListControls = [];
		var e = jQuery.proxy(function(E) {
			var m = ZPRS_DISPUTES.util.BatchManagement.prototype.parseErrorMessage(E);
			this.oUtil.showErrorMessageDialog(m);
		}, this);
		var s = jQuery.proxy(function(d) {
			if (d && d.__batchResponses && d.__batchResponses.length > 0 && d.__batchResponses[0].data && d.__batchResponses[0].data.results) {
				this.aAttributeSet = d.__batchResponses[0].data.results;
				this.renderCustomerFields(this.aAttributeSet, this.aDisputeMetadata, w);
			} else {
				jQuery.sap.log.warning("ZPRS_DISPUTES.view.DisputeDetails: Could not read attribute profile");
			}
		}, this);
		var p = "GetAttributeProperties?CaseType='" + c + "'";
		var b = [];
		b.push(this.oDataModel.createBatchOperation(p, "GET"));
		this.oDataModel.addBatchReadOperations(b);
		this.oDataModel.submitBatch(s, e);
	},
	onPhoneNoClick: function(e) {
		var s = e.getSource();
		var n = s.getText();
		sap.m.URLHelper.triggerTel(n);
	},
	discardAllChanges: function() {
		if (this.hasPendingChanges()) {
			if (!this.oDataLossDialog) {
				this.oDataLossDialog = sap.ui.xmlfragment('DataLossDialog', 'ZPRS_DISPUTES.util.DataLossDialog', this);
				this.getView().addDependent(this.oDataLossDialog);
			}
			this.oDataLossDialog.open();
		} else {
			this.navBack();
		}
	},
	saveDisputeDetails: function() {
		var d = jQuery.Deferred();
		var s = jQuery.Deferred();
		var r = (this.oUnchangedDispute.Status !== this.oDispute.Status);
		var S = jQuery.proxy(function() {
			s.resolveWith(this);
		}, this);
		var e = jQuery.proxy(function(E) {
			s.rejectWith(this, [E]);
		}, this);
		s.done(function() {
			this.getDisputeEntityPathFromCaseGuid().done(function(p) {
				this.sPath = p;
				if (r) {
					this.triggerRefreshStatusLists();
				}
				d.resolveWith(this);
			}).fail(function() {
				d.rejectWith(this);
			});
		});
		s.fail(function(E) {
			d.rejectWith(this, [E]);
		});
		if (this.oDataModel.hasPendingChanges()) {
			this.oDataModel.submitChanges(S, e);
		} else {
			d.resolveWith(this);
		}
		return d.promise();
	},
	triggerRefreshStatusLists: function() {
		jQuery.each(this.aStatusListControls, jQuery.proxy(function(i, s) {
			var b = s.getBindingInfo("items");
			var r = false;
			if (b) {
				if (b.parameters && b.parameters.custom && b.parameters.custom.CurrentStatus) {
					if (b.parameters.custom.CurrentStatus !== "'" + this.oDispute.Status + "'") {
						r = true;
						b.parameters.custom.CurrentStatus = "'" + this.oDispute.Status + "'";
					}
				}
				if (r) {
					s.bindItems(b);
				}
			}
		}, this));
	},
	saveNote: function() {
		var d = jQuery.Deferred();
		var s = jQuery.Deferred();
		var n = this.byId('NoteInput');
		var v = n.getValue();
		if (this.oDataModel.hasPendingChanges()) {
			d.rejectWith(this);
			return d;
		}
		var e = {
			NoteContent: v,
			CaseGuid: this.sCaseGuid
		};
		var S = jQuery.proxy(function(D, r) {
			s.resolveWith(this, [D, r]);
		}, this);
		var E = jQuery.proxy(function(D) {
			s.rejectWith(this, [D]);
		}, this);
		var p = {
			success: S,
			error: E,
			async: true
		};
		s.done(function(D, r) {
			if (r.statusCode === 201) {
				n.setValue('');
				this.getDisputeEntityPathFromCaseGuid().then(function(P) {
					this.sPath = P;
					d.resolveWith(this, [D]);
				}, function() {
					d.rejectWith(this);
				});
			} else {
				d.rejectWith(this, [D, r]);
			}
		});
		s.fail(function(D) {
			d.rejectWith(this, [D]);
		});
		if (v !== '') {
			this.oDataModel.create("/CaseNoteSet", e, p);
		} else {
			d.resolveWith(this);
		}
		return d.promise();
	},
	addAttachment: function() {
		var d = jQuery.Deferred();
		var s = jQuery.Deferred();
		var u = jQuery.proxy(this.onAttachmentUploadComplete, this, s);
		var f = this.byId("attachmentFileUploader");
		if (this.oDataModel.hasPendingChanges()) {
			d.rejectWith(this);
			return d.promise();
		}
		s.done(function(D) {
			if (f.clear) {
				f.clear();
			} else {
				f.setValue('');
			}
			this.byId("BtnCleanAttachmentFileUploader").setEnabled(false);
			this.getDisputeEntityPathFromCaseGuid().then(function(p) {
				this.sPath = p;
				d.resolveWith(this, [D]);
			}, function() {
				d.rejectWith(this);
			});
		});
		s.fail(function(D) {
			d.rejectWith(this, [D]);
		});
		s.always(function() {
			f.detachUploadComplete(u);
		});
		if (f.getValue() !== '') {
			f.attachUploadComplete(u);
			f.upload();
		} else {
			d.resolveWith(this);
		}
		return d.promise();
	},
	saveAllChanges: function() {
		var n = this.byId('NoteInput');
		if (!this.hasPendingChanges()) {
			sap.m.MessageToast.show(this.oBundle.getText("DisputeDetailDisputeCaseNotChanged"));
			return;
		}
		this.oSaveBusyDialog.open();
		this.oDataModel.setRefreshAfterChange(false);
		var p = this.saveDisputeDetails();
		var P = p.then(function() {
			return this.saveNote();
		});
		var o = P.then(function() {
			return this.addAttachment();
		});
		jQuery.when(p, P, o).always(jQuery.proxy(function() {
			this.oDataModel.setRefreshAfterChange(true);
			this.oSaveBusyDialog.close();
		}, this)).done(jQuery.proxy(function() {
			sap.m.MessageToast.show(this.oBundle.getText("DisputeDetailToastDisputeCaseSaved"));
			this.oLoadBusyDialog.open();
			this.initBindings();
		}, this)).fail(jQuery.proxy(function(d) {
			if ((d && d.response && d.response.statusCode === 412) || (d && d.response && d.response.statusCode === 400 && d.response.body &&
					d.response.body.indexOf("/IWBEP/CM_MGW_RT/020") > 0)) {
				var D = new sap.m.Dialog({
					horizontalScrolling: false,
					type: sap.m.DialogType.Message,
					content: [new sap.m.Text({
						text: this.oBundle.getText("DisputeDetailSavingPreconditionFailed")
					})],
					title: this.oBundle.getText("Error"),
					state: sap.ui.core.ValueState.Error
				});
				D.addStyleClass("sapUiSizeCompact");
				var c = new sap.m.Button({
					text: this.oBundle.getText("ok"),
					press: function(a) {
						D.close();
					}
				});
				var r = new sap.m.Button({
					text: this.oBundle.getText("DisputeDetailsBtnReloadEtag"),
					press: jQuery.proxy(function() {
						this.oLoadBusyDialog.open();
						this.clearInputs();
						this.loadDisputeByCaseGuid();
						D.close();
					}, this)
				});
				D.setEndButton(r);
				D.setBeginButton(c);
				D.open();
			} else {
				var s = ZPRS_DISPUTES.util.BatchManagement.prototype.parseErrorMessage(d);
				if (d && jQuery.type(d) === "string" && d.length > 0 && d.indexOf('SY/530') === 0) {
					var S = 'UDM_MSG/169';
					var e = 'error/IWBEP/CX_MGW_BUSI_EXCEPTION';
					var i = d.indexOf(S);
					var E = d.indexOf(e);
					if (i > 0 && E > 0 && i + S.length < E && E < d.length) {
						s = d.substring(i + S.length, E);
					}
				}
				var m = this.oBundle.getText('batch_failed');
				if (s) {
					this.oUtil.showErrorMessageDialog(m, s);
				} else {
					this.oUtil.showErrorMessageDialog(m);
				}
			}
		}, this));
	},
	hasPendingChanges: function() {
		var h = this.byId('NoteInput').getValue() !== '';
		var H = this.oDataModel.hasPendingChanges();
		var b = this.byId('attachmentFileUploader').getValue() !== '';
		return H || h || b;
	},
	resetPendingChanges: function() {
		this.oDataModel.resetChanges();
		this.byId('NoteInput').setValue('');
		this.byId('attachmentFileUploader').setValue('');
	},
	clearInputs: function() {
		this.byId('attachmentFileUploader').clear();
		this.byId('NoteInput').setValue();
	},
	updateSaveButtonState: function() {
		var b = this.byId("ButtonSaveDispute");
		var c = this.byId("ButtonCreateCorrespondence");
		var h = !jQuery.isEmptyObject(this.oFormErrors);
		var e = false;
		if (!h) {
			e = this.hasPendingChanges();
		}
		b.setEnabled(e);
		c.setEnabled(!e);
	},
	onPrintCorrespondence: function() {
		if (!this.oPrintCorrespondence) {
			this.oPrintCorrespondence = new ZPRS_DISPUTES.view.CreateCorrespondenceDialog(this.getView());
		}
		var s = jQuery.proxy(function() {
			this.oLoadBusyDialog.open();
			this.loadDisputeByCaseGuid(this.sCaseGuid);
		}, this);
		this.oPrintCorrespondence.open(this.sPath, s);
	},
	navBack: function() {
		this.resetPendingChanges();
		window.history.back();
	},
	closeDataLossDialog: function() {
		this.oDataLossDialog.close();
	},
	navigateToLinkedObject: function(e) {
		var s = e.getSource();
		var l = s.getBindingContext().getObject();
		var n = null;
		switch (l.ObjectType) {
			case "KNA1":
				n = {
					target: {
						semanticObject: "Customer",
						action: "displayFactSheet"
					},
					params: {
						Customer: l.ObjectKey
					}
				};
				break;
			case "BSEG":
				n = {
					target: {
						semanticObject: "AccountingDocument",
						action: "manage"
					},
					params: {
						AccountingDocument: l.InvoiceNumber,
						CompanyCode: l.CompanyCode,
						FiscalYear: l.FiscalYear
					}
				};
				break;
		}
		if (n) {
			this.oCrossAppNavigator.toExternal(n);
		}
	},
	formatCompanyCodeWithDescr: function(c, C) {
		if (!this.oBundle) {
			this.oBundle = this.getView().getModel('i18n').getResourceBundle();
		}
		if (c && C) {
			return this.oBundle.getText("DisputeDetailCompanyCodeWithDescr", [c, C]);
		}
	},
	formatAttachmentDetailsLabel: function(C, a, b) {
		var d = new sap.ca.ui.model.type.DateTime({
			style: "short"
		});
		b = d.formatValue(b, "string");
		return this.oBundle.getText("DisputeDetailLabelAttachmentDetail", [C, a, b]);
	},
	formatFileNameWithSize: function(f, s) {
		if (f && s) {
			var F = sap.ca.ui.model.format.FileSizeFormat.getInstance();
			s = F.format(s);
			return this.oBundle.getText("DisputeDetailLabelAttachmentNameSize", [f, s]);
		}
	},
	formatIsNavigationSupported: function(o, a) {
		switch (o) {
			case "BSEG":
				if (!a.AccountingDocumentApp) {
					return "Inactive";
				}
				return "Navigation";
			case "KNA1":
				if (!a.CustomerFactSheet) {
					return "Inactive";
				}
				return "Navigation";
			default:
				return "Inactive";
		}
	}
});