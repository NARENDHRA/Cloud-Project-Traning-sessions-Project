jQuery.sap.declare("ZPRS_DISPUTES.view.CustomerPopover");
jQuery.sap.require("ZPRS_DISPUTES.util.Formatters");
ZPRS_DISPUTES.view.CustomerPopover = function(m) {
	this._oMotherView = m;
	this._oPopover = null;
	this._oHeader = null;
	this.format = m.getController().format;
};
ZPRS_DISPUTES.view.CustomerPopover.prototype.openBy = function(c, C) {
	if (!this._oPopover) {
		this._oPopover = sap.ui.xmlfragment('CustomerPopover', 'ZPRS_DISPUTES.view.CustomerPopover', this);
		this._oMotherView.addDependent(this._oPopover);
		this._oHeader = sap.ui.core.Fragment.byId('CustomerPopover', 'CustomerPopoverHeader');
	}
	var s = jQuery.proxy(function(d, r, E) {
		if (E && E.length > 0) {
			return;
		}
		if (d.HasLogo) {
			this._oHeader.setIcon(d.__metadata.media_src);
		}
	}, this);
	var e = function(E) {};
	var m = this._oMotherView.getModel();
	var p = c.sPath + "/GetCustomerImage";
	var P = {
		success: s,
		error: e
	};
	m.read(p, P);
	this._oPopover.setBindingContext(c);
	this._oPopover.openBy(C);
};
ZPRS_DISPUTES.view.CustomerPopover.prototype.onCallCustomer = function(e) {
	var p = this._oPopover.getBindingContext().getProperty("ContactPersonPhoneNumber");
	if (p && p != "") {
		sap.m.URLHelper.triggerTel(p);
	}
};
ZPRS_DISPUTES.view.CustomerPopover.prototype.onTitlePress = function(e) {
	var f = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService;
	var c = f && f("CrossApplicationNavigation");
	var a = this._oPopover.getBindingContext().getProperty("Customer");
	c.toExternal({
		target: {
			semanticObject: "Customer",
			action: "displayFactSheet"
		},
		params: {
			Customer: a
		}
	});
};