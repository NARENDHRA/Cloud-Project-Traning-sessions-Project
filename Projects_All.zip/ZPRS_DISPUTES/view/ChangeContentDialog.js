jQuery.sap.declare("ZPRS_DISPUTES.view.ChangeContentDialog");
jQuery.sap.require("ZPRS_DISPUTES.util.BatchManagement");
ZPRS_DISPUTES.view.ChangeContentDialog = function(v, s, e) {
	this._sFragmentId = v.getId() + '-' + 'ChangeContentDialog';
	this._oView = v;
	this._oBundle = v.getModel('i18n').getResourceBundle();
	this._oODataModel = v.getModel();
	this._oDialog = null;
	this._aDisputes = null;
	this._fnSuccess = s;
	this._fnError = e;
	this._oUtil = new ZPRS_DISPUTES.util.Util(this._oBundle, this._oODataModel);
};
ZPRS_DISPUTES.view.ChangeContentDialog.prototype.open = function(d) {
	var m;
	if (!this._oDialog) {
		this._oDialog = sap.ui.xmlfragment(this._sFragmentId, 'ZPRS_DISPUTES.view.ChangeContentDialog', this);
		this._oView.addDependent(this._oDialog);
		m = this._oDialog.getModel();
		this._oDialog.attachAfterClose(jQuery.proxy(function(e) {
			var b = this._oDialog.getBindingContext();
			if (b) {
				m.deleteCreatedEntry(b);
			}
		}, this));
		var p = this._byId("processor");
		this._oDialog.setBindingContext(m.createEntry("DisputeSet"));
		this._oUtil.provideSearchHelp({
			control: p,
			entity: "Dispute",
			property: "Processor"
		});
	} else {
		m = this._oDialog.getModel();
		this._oDialog.setBindingContext(m.createEntry("DisputeSet"));
	}
	this._aDisputes = d;
	this._oDialog.open();
};
ZPRS_DISPUTES.view.ChangeContentDialog.prototype._byId = function(i) {
	return sap.ui.core.Fragment.byId(this._sFragmentId, i);
};
ZPRS_DISPUTES.view.ChangeContentDialog.prototype._onChangeContent = function() {
	var d = this._oView.getModel();
	var h = {
		'X-Requested-With': 'XMLHttpRequest'
	};
	d.setHeaders(h);
	var b = new sap.m.BusyDialog({
		text: this._oBundle.getText("Loadingtext")
	});
	b.open();
	var B = new ZPRS_DISPUTES.util.BatchManagement(d, this);
	var s = function() {
		if (this._fnSuccess) {
			this._fnSuccess(this);
		}
		this._oDialog.close();
		b.close();
	};
	var e = function(E) {
		this._oUtil.showMessageDialog(E, {
			title: this._oBundle.getText("Error"),
			type: sap.ui.core.ValueState.Error
		});
		if (this._fnError) {
			this._fnError();
		}
		b.close();
	};
	var p = this._byId("processor");
	jQuery.each(this._aDisputes, jQuery.proxy(function(i, D) {
		var o = D.data;
		var P = D.path;
		o.Processor = p.getValue() || "";
		var a = {
			sPath: P,
			oEntry: o,
			sOperation: 'PUT'
		};
		B.addBatchRequestObject(a);
	}, this));
	B.submit(null, e, s);
};
ZPRS_DISPUTES.view.ChangeContentDialog.prototype._onCancelChangeContent = function() {
	this._byId("processor").setValue("");
	this._oDialog.close();
};