jQuery.sap.declare("ZPRS_DISPUTES.Component");
jQuery.sap.require("sap.ca.scfld.md.ComponentBase");
(function() {
  var p = jQuery.sap.getModulePath("ZPRS_DISPUTES");
  var P = p.toLowerCase().indexOf("/zprs_disputes");
  var n = "";
  if (P !== -1) {
    if (jQuery.sap.isDeclared("sap.fin.central.lib.library")) {
      return;
    }
    n = p.substring(0, P);
    n += "/fin_lib/sap/fin/central/lib/";
    jQuery.sap.registerModulePath("sap.fin.central.lib", n);
  }
  jQuery.sap.require("ZPRS_DISPUTES.fin_lib.sap.fin.central.lib.library");
}());
sap.ca.scfld.md.ComponentBase.extend("ZPRS_DISPUTES.Component", {
  metadata: sap.ca.scfld.md.ComponentBase.createMetaData("FS", {
    "name": "Fullscreen Sample",
    "version": "2.1.4",
    "library": "ZPRS_DISPUTES",
    "includes": ["css/app.css"],
    "dependencies": {
      "libs": ["sap.m", "sap.me", "sap.ui.comp", "sap.ui.table"],
      "components": []
    },
    "config": {
      "fullWidth": true,
      "resourceBundle": "i18n/i18n.properties",
      "titleResource": "Title",
      "icon": "sap-icon://Fiori2/F0106",
      "favIcon": "./resources/sap/ca/ui/themes/base/img/favicon/F0106_Process_Collection_Worklist.ico",
      "homeScreenIconPhone": "./resources/sap/ca/ui/themes/base/img/launchicon/F0106_Process_Collection_Worklist/57_iPhone_Desktop_Launch.png",
      "homeScreenIconPhone@2": "./resources/sap/ca/ui/themes/base/img/launchicon/F0106_Process_Collection_Worklist/114_iPhone-Retina_Web_Clip.png",
      "homeScreenIconTablet": "./resources/sap/ca/ui/themes/base/img/launchicon/F0106_Process_Collection_Worklist/72_iPad_Desktop_Launch.png",
      "homeScreenIconTablet@2": "./resources/sap/ca/ui/themes/base/img/launchicon/F0106_Process_Collection_Worklist/144_iPad_Retina_Web_Clip.png"
    },
    viewPath: "ZPRS_DISPUTES.view",
    fullScreenPageRoutes: {
      "DisputeList": {
        "pattern": "",
        "view": "DisputeList",
        "viewId": "ZPRS_DISPUTES.DisputeList"
      },
      "DisputeListWithParameters": {
        "pattern": "p/:?query:",
        "view": "DisputeList",
        "viewId": "ZPRS_DISPUTES.DisputeList",
      },
      "toDetails": {
        "pattern": "DisputeDetails/:CaseAlvGuid:/:CaseGuid:",
        "view": "DisputeDetails",
        "viewId": "ZPRS_DISPUTES.DisputeDetails"
      }
    },
  }),
  createContent: function() {
    var v = {
      component: this
    };
    return sap.ui.view({
      viewName: "ZPRS_DISPUTES.Main",
      type: sap.ui.core.mvc.ViewType.XML,
      viewData: v
    });
  },
  init: function() {
    var c = null;
    if (this.getComponentData() && this.getComponentData().startupParameters && this.getComponentData().startupParameters.CaseGuid && this
      .getComponentData().startupParameters.CaseGuid.length > 0 && this.getComponentData().startupParameters.CaseGuid[0]) {
      c = this.getComponentData().startupParameters.CaseGuid[0];
    }
    if (c) {
      var r = this.getRouter();
      var h = sap.ui.core.routing.HashChanger.getInstance();
      var H = r.getURL("toDetails", {
        CaseGuid: c
      });
      h.replaceHash(H);
    }
  },
});