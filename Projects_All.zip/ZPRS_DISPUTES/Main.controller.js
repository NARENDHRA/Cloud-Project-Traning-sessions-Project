sap.ui.controller("ZPRS_DISPUTES.Main", {
	onInit: function() {
		jQuery.sap.require("sap.ca.scfld.md.Startup");
		sap.ca.scfld.md.Startup.init('ZPRS_DISPUTES', this);
	}
});