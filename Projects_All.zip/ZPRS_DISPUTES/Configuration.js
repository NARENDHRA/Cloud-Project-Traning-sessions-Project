jQuery.sap.declare("ZPRS_DISPUTES.Configuration");
jQuery.sap.require("sap.ca.scfld.md.ConfigurationBase");
jQuery.sap.require("sap.ca.scfld.md.app.Application");
sap.ca.scfld.md.ConfigurationBase.extend("ZPRS_DISPUTES.Configuration", {
  oServiceParams: {
    serviceList: [{
      name: "ZPRS_MANAGE_DISPUTES_SRV",
      masterCollection: "DisputeSet",
      serviceUrl: "/sap/opu/odata/sap/ZPRS_MANAGE_DISPUTES_SRV/",
      metadataParams: "sap-documentation=heading,quickinfo",
      isDefault: true,
      mockedDataSource: "/ZPRS_DISPUTES/model/metadata.xml",
      noBusyIndicator: true,
      loadMetadataAsync: false,
      fRequestFailed: function(e) {
        var r = e.getParameter("responseText");
        var R = jQuery.parseJSON(r);
        var s = function(m, d) {
          var S = {
            type: sap.ca.ui.message.Type.ERROR,
            message: m,
            details: d
          };
          sap.ca.ui.message.showMessageBox(S);
        };
        if (R && R.error && R.error.innererror && R.error.innererror.errordetails && R.error.innererror.errordetails[0] && R.error.innererror
          .errordetails[0].message) {
          s(R.error.innererror.errordetails[0].message, e.getParameter("responseText"));
          return;
        }
        if (R && R.error && R.error.message && R.error.message.value) {
          s(R.error.message.value);
          return;
        }
        s(e.getParameter("message"), e.getParameter("responseText"));
      }
    }]
  },
  getServiceParams: function() {
    return this.oServiceParams;
  },
  getAppConfig: function() {
    return this.oAppConfig;
  },
  getServiceList: function() {
    return this.oServiceParams.serviceList;
  },
  getMasterKeyAttributes: function() {
    return ["Id"];
  }
});