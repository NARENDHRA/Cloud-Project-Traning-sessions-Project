/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("cus.crm.lead.util.Util");

cus.crm.lead.util.Util ={
refreshHeaderETag : function(sPath,oController){
	 
	 var oModel = oController.oModel;
	 
	 if(oModel.getContext("/" + sPath)){
	        oModel.deleteCreatedEntry(oModel.getContext("/" + sPath));	 
	 }
	 	 oModel.createBindingContext("/"+ sPath,null,function(oContext){
			 
			 //dispatch the latest object to S3 view as well
			 var oData = oContext.getObject();
			 var oControllersModel = oController.getView().getModel("controllers");
			 var oS3Controller = oControllersModel.getProperty("/s3Controller");
			 
			 if(oS3Controller){
				 oS3Controller.bindS3Header(oData);
			 }
			 
		 },true);
	 },
	 
	 show412ErrorDialog : function(oController,fnOKCallback){
			sap.ca.ui.message.showMessageBox({
				type : sap.ca.ui.message.Type.ERROR,
				message : sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText('MSG_CONFLICTING_DATA')
			},fnOKCallback);
		}
	 
};