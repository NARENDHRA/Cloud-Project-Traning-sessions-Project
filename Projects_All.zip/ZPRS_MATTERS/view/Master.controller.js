jQuery.sap.require("sap.m.MessageBox");
jQuery.sap.require("Matters_NRF.formatters.formatter");
sap.ui.core.mvc.Controller.extend("Matters_NRF.view.Master", {
	onInit: function() {
		this.oInitialLoadFinishedDeferred = jQuery.Deferred();

		var oEventBus = this.getEventBus();
		oEventBus.subscribe("Detail", "TabChanged", this.onDetailTabChanged, this);

		var oList = this.getView().byId("list");
		oList.attachEvent("updateFinished", function() {
			this.oInitialLoadFinishedDeferred.resolve();
			oEventBus.publish("Master", "InitialLoadFinished");
		}, this);

		//On phone devices, there is nothing to select from the list. There is no need to attach events.
		if (sap.ui.Device.system.phone) {
			return;
		}

		this.getRouter().attachRoutePatternMatched(this.onRouteMatched, this);

		oEventBus.subscribe("Detail", "Changed", this.onDetailChanged, this);
		oEventBus.subscribe("Detail", "NotFound", this.onNotFound, this);
	},

	onRouteMatched: function(oEvent) {
		var sName = oEvent.getParameter("name");

		if (sName !== "main") {
			return;
		}

		//Load the detail view in desktop
		this.loadDetailView();

		//Wait for the list to be loaded once
		this.waitForInitialListLoading(function() {

			//On the empty hash select the first item
			this.selectFirstItem();

		});

	},

	onDetailChanged: function(sChanel, sEvent, oData) {
		var sEntityPath = oData.sEntityPath;
		//Wait for the list to be loaded once
		this.waitForInitialListLoading(function() {
			var oList = this.getView().byId("list");

			var oSelectedItem = oList.getSelectedItem();
			// The correct item is already selected
			if (oSelectedItem && oSelectedItem.getBindingContext().getPath() === sEntityPath) {
				return;
			}

			var aItems = oList.getItems();

			for (var i = 0; i < aItems.length; i++) {
				if (aItems[i].getBindingContext().getPath() === sEntityPath) {
					oList.setSelectedItem(aItems[i], true);
					break;
				}
			}
		});
	},

	onDetailTabChanged: function(sChanel, sEvent, oData) {
		this.sTab = oData.sTabKey;
	},

	loadDetailView: function() {
		this.getRouter().myNavToWithoutHash({
			currentView: this.getView(),
			targetViewName: "Matters_NRF.view.Detail",
			targetViewType: "XML"
		});
	},

	waitForInitialListLoading: function(fnToExecute) {
		jQuery.when(this.oInitialLoadFinishedDeferred).then(jQuery.proxy(fnToExecute, this));
	},

	onNotFound: function() {
		this.getView().byId("list").removeSelections();
	},

	selectFirstItem: function() {
		var oList = this.getView().byId("list");
		var aItems = oList.getItems();
		if (aItems.length) {
			oList.setSelectedItem(aItems[0], true);
			//Load the detail view in desktop
			this.loadDetailView();
			oList.fireSelect({
				"listItem": aItems[0]
			});
		} else {
			this.getRouter().myNavToWithoutHash({
				currentView: this.getView(),
				targetViewName: "Matters_NRF.view.NotFound",
				targetViewType: "XML"
			});
		}
	},

/*	myColor: function(sValue) {
		var bValue = "Success";
		switch (sValue) {
			case "OPEN":
				bValue = "Success";
				break;
			case "CLOSED":
				bValue = "Error";
				break;
			default:
		}
		return bValue;
	},*/

	onSearch: function() {
		this.oInitialLoadFinishedDeferred = jQuery.Deferred();
		// Add search filter
		var filters = [];
		var searchString = this.getView().byId("searchField").getValue();
		if (searchString && searchString.length > 0) {
			filters = [new sap.ui.model.Filter("Post1", sap.ui.model.FilterOperator.Contains, searchString)];
		}
		// Update list binding
		this.getView().byId("list").getBinding("items").filter(filters);

		//On phone devices, there is nothing to select from the list
		if (sap.ui.Device.system.phone) {
			return;
		}

		//Wait for the list to be reloaded
		this.waitForInitialListLoading(function() {
			//On the empty hash select the first item
			this.selectFirstItem();
		});
	},
	onSearch2: function(searchString) {
		this.oInitialLoadFinishedDeferred = jQuery.Deferred();
		// Add search filter
		var filters = [];
		//var searchString = this.getView().byId("searchField").getValue();
		if (searchString && searchString.length > 0) {
			filters = [new sap.ui.model.Filter("Post1", sap.ui.model.FilterOperator.Contains, searchString)];
		}
		// Update list binding
		this.getView().byId("list").getBinding("items").filter(filters);

		//On phone devices, there is nothing to select from the list
		if (sap.ui.Device.system.phone) {
			return;
		}

		//Wait for the list to be reloaded
		this.waitForInitialListLoading(function() {
			//On the empty hash select the first item
			this.selectFirstItem();
		});
	},
	onSelect: function(oEvent) {
		var that = this;
		var oListItem = oEvent.getParameter("listItem");
		var oView = this.getView();
		var oMainModel = oView.getModel();
		if ($("#__xmlview1--edit-img").length > 0 ||
			$("#__xmlview2--edit-img").length > 0 ||
			$("#__xmlview3--edit-img").length > 0 ||
			$("#__xmlview4--edit-img").length > 0 ||
			$("#__xmlview5--edit-img").length > 0 ||
			$("#__xmlview6--edit-img").length > 0 ||
			$("#__xmlview7--edit-img").length > 0 ||
			$("#__xmlview8--edit-img").length > 0 ||
			$("#__xmlview9--edit-img").length > 0 ||
			$("#__xmlview10--edit-img").length > 0 ||
			$("#__xmlview11--edit-img").length > 0 ||
			$("#__xmlview12--edit-img").length > 0 ||
			$("#__xmlview13--edit-img").length > 0 ||
			$("#__xmlview14--edit-img").length > 0 ||
			$("#__xmlview15--edit-img").length > 0 ||
			$("#__xmlview16--edit-img").length > 0 ||
			$("#__xmlview17--edit-img").length > 0 ||
			$("#__xmlview18--edit-img").length > 0 ||
			$("#__xmlview19--edit-img").length > 0 ||
			$("#__xmlview20--edit-img").length > 0 ||
			$("#__xmlview21--edit-img").length > 0 ||
			$("#__xmlview22--edit-img").length > 0 ||
			$("#__xmlview23--edit-img").length > 0 ||
			$("#__xmlview24--edit-img").length > 0 ||
			$("#__xmlview25--edit-img").length > 0 ||
			$("#__xmlview26--edit-img").length > 0 ||
			$("#__xmlview27--edit-img").length > 0 ||
			$("#__xmlview28--edit-img").length > 0 ||
			$("#__xmlview29--edit-img").length > 0 ||
			$("#__xmlview30--edit-img").length > 0
		) { // Display Mode
			// Get the list item either from the listItem parameter or from the event's
			// source itself (will depend on the device-dependent mode)
			this.showDetail(oEvent.getParameter("listItem") || oEvent.getSource());
		} else { // Edit Mode, hence show popup
			if ($("#__xmlview1--save-img").length > 0 ||
				$("#__xmlview2--save-img").length > 0 ||
				$("#__xmlview3--save-img").length > 0 ||
				$("#__xmlview4--save-img").length > 0 ||
				$("#__xmlview5--save-img").length > 0 ||
				$("#__xmlview6--save-img").length > 0 ||
				$("#__xmlview7--save-img").length > 0 ||
				$("#__xmlview8--save-img").length > 0 ||
				$("#__xmlview9--save-img").length > 0 ||
				$("#__xmlview10--save-img").length > 0 ||
				$("#__xmlview11--save-img").length > 0 ||
				$("#__xmlview12--save-img").length > 0 ||
				$("#__xmlview13--save-img").length > 0 ||
				$("#__xmlview14--save-img").length > 0 ||
				$("#__xmlview15--save-img").length > 0 ||
				$("#__xmlview16--save-img").length > 0 ||
				$("#__xmlview17--save-img").length > 0 ||
				$("#__xmlview18--save-img").length > 0 ||
				$("#__xmlview19--save-img").length > 0 ||
				$("#__xmlview20--save-img").length > 0 ||
				$("#__xmlview21--save-img").length > 0 ||
				$("#__xmlview22--save-img").length > 0 ||
				$("#__xmlview23--save-img").length > 0 ||
				$("#__xmlview24--save-img").length > 0 ||
				$("#__xmlview25--save-img").length > 0 ||
				$("#__xmlview26--save-img").length > 0 ||
				$("#__xmlview27--save-img").length > 0 ||
				$("#__xmlview28--save-img").length > 0 ||
				$("#__xmlview29--save-img").length > 0 ||
				$("#__xmlview30--save-img").length > 0
			) {
				sap.m.MessageBox.confirm("Any unsaved changes will be lost. Do you want to continue?", {
					title: "Confirmation",
					onClose: function(oAction) {
						if (oAction === "OK") {
							oMainModel.refresh(true);
							// Get the list item either from the listItem parameter or from the event's
							// source itself (will depend on the device-dependent mode)
							that.showDetail(oListItem || oEvent.getSource());
						}
					}
				});
			}
		}
	},

	showDetail: function(oItem) {
		// If we're on a phone device, include nav in history
		// var bReplace = jQuery.device.is.phone ? false : true;
		var bReplace = sap.ui.Device.system.phone ? false : true;
		this.getRouter().navTo("detail", {
			from: "master",
			entity: oItem.getBindingContext().getPath().substr(1),
			tab: this.sTab
		}, bReplace);
	},

	getEventBus: function() {
		return sap.ui.getCore().getEventBus();
	},

	getRouter: function() {
		return sap.ui.core.UIComponent.getRouterFor(this);
	},

	onExit: function(oEvent) {
		var oEventBus = this.getEventBus();
		oEventBus.unsubscribe("Detail", "TabChanged", this.onDetailTabChanged, this);
		oEventBus.unsubscribe("Detail", "Changed", this.onDetailChanged, this);
		oEventBus.unsubscribe("Detail", "NotFound", this.onNotFound, this);
	}
});
/*sap.ui.core.mvc.Controller.extend("Matters_NRF.view.Master", {

	onInit: function() {
		this.oInitialLoadFinishedDeferred = jQuery.Deferred();

		var oEventBus = this.getEventBus();
		oEventBus.subscribe("Detail", "TabChanged", this.onDetailTabChanged, this);

		var oList = this.getView().byId("list");
		oList.attachEvent("updateFinished", function() {
			this.oInitialLoadFinishedDeferred.resolve();
			oEventBus.publish("Master", "InitialLoadFinished");
		}, this);

		//On phone devices, there is nothing to select from the list. There is no need to attach events.
		if (sap.ui.Device.system.phone) {
			return;
		}

		this.getRouter().attachRoutePatternMatched(this.onRouteMatched, this);

		oEventBus.subscribe("Detail", "Changed", this.onDetailChanged, this);
		oEventBus.subscribe("Detail", "NotFound", this.onNotFound, this);
	},

	onRouteMatched: function(oEvent) {
		var sName = oEvent.getParameter("name");

		if (sName !== "main") {
			return;
		}

		//Load the detail view in desktop
		this.loadDetailView();

		//Wait for the list to be loaded once
		this.waitForInitialListLoading(function() {

			//On the empty hash select the first item
			this.selectFirstItem();

		});

	},

	onDetailChanged: function(sChanel, sEvent, oData) {
		var sEntityPath = oData.sEntityPath;
		//Wait for the list to be loaded once
		this.waitForInitialListLoading(function() {
			var oList = this.getView().byId("list");

			var oSelectedItem = oList.getSelectedItem();
			// The correct item is already selected
			if (oSelectedItem && oSelectedItem.getBindingContext().getPath() === sEntityPath) {
				return;
			}

			var aItems = oList.getItems();

			for (var i = 0; i < aItems.length; i++) {
				if (aItems[i].getBindingContext().getPath() === sEntityPath) {
					oList.setSelectedItem(aItems[i], true);
					break;
				}
			}
		});
	},

	onDetailTabChanged: function(sChanel, sEvent, oData) {
		this.sTab = oData.sTabKey;
	},

	loadDetailView: function() {
		this.getRouter().myNavToWithoutHash({
			currentView: this.getView(),
			targetViewName: "Matters_NRF.view.Detail",
			targetViewType: "XML"
		});
	},

	waitForInitialListLoading: function(fnToExecute) {
		jQuery.when(this.oInitialLoadFinishedDeferred).then(jQuery.proxy(fnToExecute, this));
	},

	onNotFound: function() {
		this.getView().byId("list").removeSelections();
	},

	selectFirstItem: function() {
		var oList = this.getView().byId("list");
		var aItems = oList.getItems();
		if (aItems.length) {
			oList.setSelectedItem(aItems[0], true);
			//Load the detail view in desktop
			this.loadDetailView();
			oList.fireSelect({
				"listItem": aItems[0]
			});
		} else {
			this.getRouter().myNavToWithoutHash({
				currentView: this.getView(),
				targetViewName: "Matters_NRF.view.NotFound",
				targetViewType: "XML"
			});
		}
	},

	onSearch: function() {
		this.oInitialLoadFinishedDeferred = jQuery.Deferred();
		// Add search filter
		var filters = [];
		var searchString = this.getView().byId("searchField").getValue();
		if (searchString && searchString.length > 0) {
			filters = [new sap.ui.model.Filter("Kunnrname", sap.ui.model.FilterOperator.Contains, searchString)];
		}
		// Update list binding
		this.getView().byId("list").getBinding("items").filter(filters);

		//On phone devices, there is nothing to select from the list
		if (sap.ui.Device.system.phone) {
			return;
		}

		//Wait for the list to be reloaded
		this.waitForInitialListLoading(function() {
			//On the empty hash select the first item
			this.selectFirstItem();
		});
	},

	onSelect: function(oEvent) {
		// Get the list item either from the listItem parameter or from the event's
		// source itself (will depend on the device-dependent mode)
		this.showDetail(oEvent.getParameter("listItem") || oEvent.getSource());
	},

	showDetail: function(oItem) {
		// If we're on a phone device, include nav in history
		var bReplace = jQuery.device.is.phone ? false : true;
		this.getRouter().navTo("detail", {
			from: "master",
			entity: oItem.getBindingContext().getPath().substr(1),
			tab: this.sTab
		}, bReplace);
	},

	getEventBus: function() {
		return sap.ui.getCore().getEventBus();
	},

	getRouter: function() {
		return sap.ui.core.UIComponent.getRouterFor(this);
	},

	onExit: function(oEvent) {
		var oEventBus = this.getEventBus();
		oEventBus.unsubscribe("Detail", "TabChanged", this.onDetailTabChanged, this);
		oEventBus.unsubscribe("Detail", "Changed", this.onDetailChanged, this);
		oEventBus.unsubscribe("Detail", "NotFound", this.onNotFound, this);
	}
});*/