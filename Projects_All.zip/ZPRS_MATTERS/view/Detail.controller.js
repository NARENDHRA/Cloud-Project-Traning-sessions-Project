jQuery.sap.require("sap.m.MessageBox");
jQuery.sap.require("Matters_NRF.formatters.formatter");
jQuery.sap.require("sap.ui.core.format.DateFormat");
sap.ui.core.mvc.Controller.extend("Matters_NRF.view.Detail", {

	_oCheckNoLock: null,
	_oEtagDtl: null,
	_osPath: null,
	_oClientBPBP: null,

	_sFltr: null,
	_sEntityPath: null,

	_oTblPrtnrNmbrRowBPBP: null,
	_oTblPrtnrNmbrRowBFBP: null,

	_aDelTableBP: [],
	_aDelTableBF: [],

	onInit: function() {
		this.oInitialLoadFinishedDeferred = jQuery.Deferred();

		if (sap.ui.Device.system.phone) {
			//Do not wait for the master when in mobile phone resolution
			this.oInitialLoadFinishedDeferred.resolve();
		} else {
			this.getView().setBusy(true);
			var oEventBus = this.getEventBus();
			oEventBus.subscribe("Component", "MetadataFailed", this.onMetadataFailed, this);
			oEventBus.subscribe("Master", "InitialLoadFinished", this.onMasterLoaded, this);
		}

		this.getRouter().attachRouteMatched(this.onRouteMatched, this);

	},

	onMasterLoaded: function(sChannel, sEvent) {
		this.getView().setBusy(false);
		this.oInitialLoadFinishedDeferred.resolve();
	},

	onMetadataFailed: function() {
		this.getView().setBusy(false);
		this.oInitialLoadFinishedDeferred.resolve();
		this.showEmptyView();
	},

	onRouteMatched: function(oEvent) {
		var oParameters = oEvent.getParameters();

		jQuery.when(this.oInitialLoadFinishedDeferred).then(jQuery.proxy(function() {
			var oView = this.getView();

			// When navigating in the Detail page, update the binding context 
			if (oParameters.name !== "detail") {
				return;
			}
			//this.loadMToast();
			var sEntityPath = "/" + oParameters.arguments.entity;
			this._sEntityPath = sEntityPath;
			this.bindView(sEntityPath);
			this.bindDispTable(sEntityPath);
			this._osPath = sEntityPath;
			var oMainModel = oView.getModel();
			var oEtagPath = this._osPath + "/MatterToMDetail";
			var that = this;
			oMainModel.read(oEtagPath, null, null, null, function(data, request) {
				that._oEtagDtl = request.data.Etag;
			}, function(oError) {});

			var oalChngTbl = oView.byId("FormDisplay354ALH");
			oalChngTbl.setVisible(false);

			var oIconTabBar = oView.byId("idIconTabBar");
			oIconTabBar.getItems().forEach(function(oItem) {
				oItem.bindElement(oItem.getKey());
			});

			// Specify the tab being focused
			var sTabKey = oParameters.arguments.tab;
			this.getEventBus().publish("Detail", "TabChanged", {
				sTabKey: sTabKey
			});

			if (oIconTabBar.getSelectedKey() !== sTabKey) {
				oIconTabBar.setSelectedKey(sTabKey);
			}
		}, this));

	},

	onRouteMatchedSuccess: function() {

		var oView = this.getView();
		var oMainModel = oView.getModel();
		//var oIconTabBar = oView.byId("idIconTabBar");

		// Specify the tab being focused
		/*			var sTabKey = "MatterToMPhase";
			this.getEventBus().publish("Detail", "TabChanged", {
				sTabKey: sTabKey
			});

			if (oIconTabBar.getSelectedKey() !== sTabKey) {
				oIconTabBar.setSelectedKey(sTabKey);
			}*/
		oMainModel.refresh(true);
		//oIconTabBar.setSelectedKey("MatterToMDetail");
		this.bindView(this._sEntityPath);
		this.bindDispTable(this._sEntityPath);
		sap.m.MessageToast.show("Data has been refreshed.");
	},

	_setValueState: function() {
		var oView = this.getView();
		var oState = "None";
		var inputs = ["ChgMIMC", "ChgBDET", "ChgBDBC", "ChgODBL", "ChgODDBF", "ChgODFBF", "ChgODTD", "ChgODTK", "ChgODCD"];
		for (var s = 0; s < inputs.length; s++) {
			var value = inputs[s];
			var field = oView.byId(value);
			value = field.getValue().length;
			if (value !== 0) {
				oState = "None";
			} else {
				oState = "Error";
			}
			field.setValueState(oState);
		}
	},
	loadMToast: function() {
		var oView = this.getView();
		oView.setBusy(true);
		sap.m.MessageToast.show("Loading Administration...", {
			duration: 1000,
			width: "18em"
		});
		setTimeout(function() {
			sap.m.MessageToast.show("Loading Matter Phase...", {
				duration: 1000,
				width: "18em"
			});
		}, 500);
		setTimeout(function() {
			sap.m.MessageToast.show("Loading Business Partners...", {
				duration: 1000,
				width: "18em"
			});
		}, 1000);
		setTimeout(function() {
			sap.m.MessageToast.show("Loading Matter Info...", {
				duration: 1000,
				width: "18em"
			});
		}, 1500);
		setTimeout(function() {
			sap.m.MessageToast.show("Loading Billing Data...", {
				duration: 1000,
				width: "18em"
			});
		}, 2000);
		setTimeout(function() {
			sap.m.MessageToast.show("Loading Billing Financial...", {
				duration: 1000,
				width: "18em"
			});
		}, 2500);
		setTimeout(function() {
			sap.m.MessageToast.show("Loading Output Data...", {
				duration: 1000,
				width: "18em"
			});
		}, 3000);
		setTimeout(function() {
			sap.m.MessageToast.show("Loading Allocation...", {
				duration: 1000,
				width: "18em"
			});
		}, 3500);
		setTimeout(function() {
			sap.m.MessageToast.show("Loading Billing Instructions...", {
				duration: 1000,
				width: "18em"
			});
		}, 4000);
	},
	bindView: function(sEntityPath) {
		var that = this;
		var oView = this.getView();
		oView.bindElement(sEntityPath);
		oView.setBusy(true);
		setTimeout(function() {
			that._setValueState();
			oView.setBusy(false);
		}, 5000);
		//Check if the data is already on the client
		if (!oView.getModel().getData(sEntityPath)) {

			// Check that the entity specified was found.
			oView.getElementBinding().attachEventOnce("dataReceived", jQuery.proxy(function() {
				var oData = oView.getModel().getData(sEntityPath);
				if (!oData) {
					//this.fireDetailChanged(sEntityPath);
					this.showEmptyView();
					this.fireDetailNotFound();
				} else {
					this.fireDetailChanged(sEntityPath);
				}
			}, this));

		} else {
			this.fireDetailChanged(sEntityPath);
		}
	},

	bindDispTable: function(sEntityPath) {
		var oView = this.getView();
		var oMainModel = oView.getModel();
		this.bindTableWO(oView, oMainModel, sEntityPath);
		// this.bindTableMP(oView, oMainModel, sEntityPath); 
		this.bindTableBP(oView, oMainModel, sEntityPath);
		this.bindTableBF(oView, oMainModel, sEntityPath);
		this.bindTableAL(oView, oMainModel, sEntityPath);
	},

	bindTableWO: function(oView, oMainModel, sEntityPath) {

		var ompChngTbl = oView.byId("FormDisplay354WO");
		var oPath = sEntityPath + "/MatterToMOffice";
		oMainModel.read(oPath, null, null, null, function(data, request) {
			var aTableData = [];
			for (var k = 0; k < data.results.length; k++) {
				var oRow = {
					OfficeCode: data.results[k].OfficeCode,
					OfficeName: data.results[k].OfficeName,
					CompCode: data.results[k].CompCode,
					Country: data.results[k].Country
				};
				aTableData.push(oRow);
			}
			//Create a model and bind the table rows to this model
			var oModel = new sap.ui.model.json.JSONModel();
			oModel.setData({
				modelData: aTableData
			});
			ompChngTbl.setModel(oModel);
			ompChngTbl.bindRows("/modelData");
		}, function(oError) {});

	},

	bindTableMP: function(oView, oMainModel, sEntityPath) {

		var ompChngTbl = oView.byId("FormDisplay354MP");
		var oPath = sEntityPath + "/MatterToMPhase";
		oMainModel.read(oPath, null, null, null, function(data, request) {
			var aTableData = [];
			for (var k = 0; k < data.results.length; k++) {
				var oRow = {
					Posid: data.results[k].Posid,
					Post1: data.results[k].Post1,
					Status: data.results[k].Status
				};
				aTableData.push(oRow);
			}
			//Create a model and bind the table rows to this model
			var oModel = new sap.ui.model.json.JSONModel();
			oModel.setData({
				modelData: aTableData
			});
			ompChngTbl.setModel(oModel);
			ompChngTbl.bindRows("/modelData");
		}, function(oError) {});

	},

	bindTableBP: function(oView, oMainModel, sEntityPath) {
		var obpChngTbl = oView.byId("FormChange354BP");
		var obpDispTbl = oView.byId("FormDisplay354BP");
		var oPath = sEntityPath + "/MatterToMBP";
		var that = this;
		oMainModel.read(oPath, null, null, null, function(data, request) {
			var oZzlinkE, aTableData = [];
			for (var k = 0; k < data.results.length; k++) {
				if (data.results[k].Zzlink.length === 0) {
					oZzlinkE = false;
				} else {
					oZzlinkE = true;
				}
				if (data.results[k].Parvw !== "BP" && data.results[k].Parvw !== "SH") {
					var oRow = {
						Parvw: data.results[k].Parvw,
						Parvwdesc: data.results[k].Parvwdesc,
						ParnrOld: data.results[k].ParnrOld,
						ParnrNew: data.results[k].ParnrNew,
						Zzlink: data.results[k].Zzlink,
						ZzlinkE: oZzlinkE,
						Name1: data.results[k].Name1,
						Addrln: data.results[k].Addrln,
						Update: "N"
					};
					aTableData.push(oRow);
					if (data.results[k].Parvw === "PY") {
						that._oClientBPBP = data.results[k].ParnrOld;
					}
				}
			}
			//Create a model and bind the table rows to this model
			var oModel = new sap.ui.model.json.JSONModel();
			oModel.setData({
				modelData: aTableData
			});
			obpChngTbl.setModel(oModel);
			obpChngTbl.bindRows("/modelData");
			obpDispTbl.setModel(oModel);
			obpDispTbl.bindRows("/modelData");
		}, function(oError) {});
	},

	bindTableBF: function(oView, oMainModel, sEntityPath) {

		var obfChngTbl = oView.byId("FormChange354BF1");
		var obfDispTbl = oView.byId("FormDisplay354BF1");
		var oPath1 = sEntityPath + "/MatterToMMPY";
		oMainModel.read(oPath1, null, null, null, function(data, request) {
			var aTableData1 = [];
			for (var k = 0; k < data.results.length; k++) {
				var oRow = {
					Payer_old: data.results[k].Payer_old,
					Payer_new: data.results[k].Payer_new,
					Name1: data.results[k].Name1,
					Perc: data.results[k].Perc,
					Update: "N"
				};
				aTableData1.push(oRow);
			}
			//Create a model and bind the table rows to this model
			var oModel1 = new sap.ui.model.json.JSONModel();
			oModel1.setData({
				modelData: aTableData1
			});
			obfChngTbl.setModel(oModel1);
			obfChngTbl.bindRows("/modelData");
			obfDispTbl.setModel(oModel1);
			obfDispTbl.bindRows("/modelData");
		}, function(oError) {});

	},

	bindTableAL: function(oView, oMainModel, sEntityPath) {
		this.sEntityPath = sEntityPath;
		var oalChngTbl = oView.byId("FormDisplay354AL");
		var oPath = sEntityPath + "/MatterToMAllocation";
		var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
			style: "medium"
		});
		var dateStr;
		var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;
		oMainModel.read(oPath, null, null, null, function(data, request) {
			var aTableData = [];
			for (var k = 0; k < data.results.length; k++) {
				/*				var begda = data.results[k].Begda;
								var month = begda.getMonth() + 1;
								begda = begda.getFullYear() + "-" + month + "-" + begda.getDate();
								var endda = data.results[k].Endda;
								month = endda.getMonth() + 1;
								endda = endda.getFullYear() + "-" + month + "-" + endda.getDate();*/
				var begda = data.results[k].Begda;
				if (begda) {
					dateStr = dateFormat.format(new Date(begda.getTime() + TZOffsetMs));
					begda = dateStr;
				}
				var endda = data.results[k].Endda;
				if (endda) {
					dateStr = dateFormat.format(new Date(endda.getTime() + TZOffsetMs));
					endda = dateStr;
				}
				var oRow = {
					Cname: data.results[k].Cname,
					Vtext: data.results[k].Vtext,
					Pernr: data.results[k].Pernr,
					PernrOffice: data.results[k].PernrOffice,
					Zzpercnt: data.results[k].Zzpercnt,
					Begda: begda,
					Endda: endda
				};
				aTableData.push(oRow);
			}
			//Create a model and bind the table rows to this model
			var oModel = new sap.ui.model.json.JSONModel();
			oModel.setData({
				modelData: aTableData
			});
			oalChngTbl.setModel(oModel);
			oalChngTbl.bindRows("/modelData");
		}, function(oError) {});

	},

	//handleCreatePress: function(oView, oMainModel, sEntityPath) {
	getHistory: function() {
		var oView = this.getView();
		var oMainModel = oView.getModel();
		var sEntityPath = this.sEntityPath;
		var oalChngTbl = oView.byId("FormDisplay354ALH");
		var oPath = sEntityPath + "/MatterToMAllocHist";
		oMainModel.read(oPath, null, null, null, function(data, request) {
			var aTableData = [];
			if (data.results.length > 0) {
				oalChngTbl.setVisible(true);
			} else {
				oalChngTbl.setVisible(false);
			}
			for (var k = 0; k < data.results.length; k++) {
				var begda = data.results[k].Begda;
				var month = begda.getMonth() + 1;
				begda = begda.getFullYear() + "-" + month + "-" + begda.getDate();
				var endda = data.results[k].Endda;
				month = endda.getMonth() + 1;
				endda = endda.getFullYear() + "-" + month + "-" + endda.getDate();
				var oRow = {
					Cname: data.results[k].Cname,
					Vtext: data.results[k].Vtext,
					Pernr: data.results[k].Pernr,
					PernrOffice: data.results[k].PernrOffice,
					Zzpercnt: data.results[k].Zzpercnt,
					Begda: begda,
					Endda: endda
				};
				aTableData.push(oRow);
			}
			//Create a model and bind the table rows to this model
			var oModel = new sap.ui.model.json.JSONModel();
			oModel.setData({
				modelData: aTableData
			});
			oalChngTbl.setModel(oModel);
			oalChngTbl.bindRows("/modelData");
		}, function(oError) {});

	},
	onRefresh: function() {
		var oView = this.getView();
		var oMainModel = oView.getModel();
		this.clearFilters(oView.byId("FormDisplay354AL"));
		this.bindTableAL(oView, oMainModel, this.sEntityPath);
	},
	onRefreshHistory: function() {
		var oView = this.getView();
		this.clearFilters(oView.byId("FormDisplay354ALH"));
		this.getHistory();
	},
	clearFilters: function(oTable) {
		var aTTColumns = oTable.getColumns();
		for (var int = 0; int < aTTColumns.length; int++) {
			var oCurrentRow = aTTColumns[int];
			oCurrentRow.setFilterValue("");
		}
	},
	formatDate: function(date) {
		return date;
	},
	showEmptyView: function() {
		this.getRouter().myNavToWithoutHash({
			currentView: this.getView(),
			targetViewName: "Matters_NRF.view.NotFound",
			targetViewType: "XML"
		});
	},

	fireDetailChanged: function(sEntityPath) {
		this.getEventBus().publish("Detail", "Changed", {
			sEntityPath: sEntityPath
		});
	},

	fireDetailNotFound: function() {
		this.getEventBus().publish("Detail", "NotFound");
	},

	onNavBack: function() {
		// This is only relevant when running on phone devices
		this.getRouter().myNavBack("main");
	},

	onDetailSelect: function(oEvent) {
		sap.ui.core.UIComponent.getRouterFor(this).navTo("detail", {
			entity: oEvent.getSource().getBindingContext().getPath().slice(1),
			tab: oEvent.getParameter("selectedKey")
		}, true);
	},

	openActionSheet: function() {
		if (!this._oActionSheet) {
			this._oActionSheet = new sap.m.ActionSheet({
				buttons: new sap.ushell.ui.footerbar.AddBookmarkButton()
			});
			this._oActionSheet.setShowCancelButton(true);
			this._oActionSheet.setPlacement(sap.m.PlacementType.Top);
		}

		this._oActionSheet.openBy(this.getView().byId("actionButton"));
	},

	getEventBus: function() {
		return sap.ui.getCore().getEventBus();
	},

	getRouter: function() {
		return sap.ui.core.UIComponent.getRouterFor(this);
	},

	onExit: function() {
		var oEventBus = this.getEventBus();
		oEventBus.unsubscribe("Master", "InitialLoadFinished", this.onMasterLoaded, this);
		oEventBus.unsubscribe("Component", "MetadataFailed", this.onMetadataFailed, this);
		if (this._oActionSheet) {
			this._oActionSheet.destroy();
			this._oActionSheet = null;
		}
	},

	handleEditPress: function() {
		this._toggleButtonsAndView(true);

		/*						var saveData = {
									Pspid: "30000100"
								};


var oModel = this.getView().getModel(); // Call ODATA.
		var saveParam = "/PlaceLockSet('30000100')";
		oModel.update(saveParam, saveData, null, function(oSuccess) {

		}, function(oError) {
			
		});*/
	},

	handleCancelPress: function() {
		this._toggleButtonsAndView(false);
	},

	_toggleButtonsAndView: function(bEdit) {
		var oView = this.getView();

		var aChange = ["edit", "FormDisplay354BP", "FormDisplay354MI", "FormDisplay354BD",
			"FormDisplay354BF", "FormDisplay354BF1", "FormDisplay354OD", "FormDisplay354BI"
		];
		var aDisplay = ["save", "cancel", "FormChange354BP", "FormChange354MI", "FormChange354BD",
			"FormChange354BF", "FormChange354BF1", "FormChange354OD",
			"FormChange354BI"
		];

		for (var i = 0; i < aChange.length; i++) {
			oView.byId(aChange[i]).setVisible(!bEdit);
		}
		for (var j = 0; j < aDisplay.length; j++) {
			oView.byId(aDisplay[j]).setVisible(bEdit);
		}
	},

	_formFragments: {},
	_getFormFragment: function(sFragmentName) {
		var oFormFragment = this._formFragments[sFragmentName];
		if (oFormFragment) {
			return oFormFragment;
		}
		oFormFragment = sap.ui.xmlfragment("Matters_NRF.fragments." + sFragmentName, this);
		this._formFragments[sFragmentName] = oFormFragment;
		return this._formFragments[sFragmentName];
	},

	_showFormFragment: function(sFragmentName) {
		var oPage = this.getView().byId("detailPage");
		oPage.insertContent(this._getFormFragment(sFragmentName));
	},

	handleSavePress: function() {
		var that = this;
		var oView = this.getView();
		var bDate = false;
		var oBDEnabled = oView.byId("ChgBDET").getEnabled();
		if (oBDEnabled) {
			var oBDState = oView.byId("ChgBDET").getValueState();
			if (oBDState !== "None") {
				sap.m.MessageToast.show("Billing Data Tab: Entry Type must not be empty.");
				bDate = false;
			} else {
				bDate = true;
			}
		} else {
			bDate = true;
		}

		if (bDate) {
			// Matter Info Tab
			var oMatterCatState = oView.byId("ChgMIMC").getValueState();
			if (oMatterCatState === "None") {

				// Output Data Tab
				var oBLState = oView.byId("ChgODBL").getValueState();
				if (oBLState === "None") {
					var oDBFState = oView.byId("ChgODDBF").getValueState();
					if (oDBFState === "None") {
						var oFBFState = oView.byId("ChgODFBF").getValueState();
						if (oFBFState === "None") {
							var oTDState = oView.byId("ChgODTD").getValueState();
							if (oTDState === "None") {
								var oTKState = oView.byId("ChgODTK").getValueState();
								if (oTKState === "None") {
									var oCDState = oView.byId("ChgODCD").getValueState();
									if (oCDState === "None") {

										// Billing Data Tab
										//var oETState = oView.byId("ChgBDET").getValueState();
										//if (oETState === "None") {
										var oBCState = oView.byId("ChgBDBC").getValueState();
										if (oBCState === "None") {

											// Billing Data Tab
											// Date format 2014-09-12T00:00:00
											var oTime = "T00:00:00";

											var oMCA = oView.byId("ChgBDMCA").getValue();
											/*
																						var oET = oView.byId("ChgBDET").getPlaceholder();
																						var oTS = oView.byId("ChgBDTS").getPlaceholder();
																						var oTJ = oView.byId("ChgBDTJ").getPlaceholder();
																						var oBT = oView.byId("ChgBDBT").getPlaceholder();
																						var oBF = oView.byId("ChgBDBF").getPlaceholder();
																						var oBM = oView.byId("ChgBDBM").getPlaceholder();
																						var oBC = oView.byId("ChgBDBC").getPlaceholder();
																						var oECS = oView.byId("ChgBDECS").getPlaceholder();
																						var oFFACS = oView.byId("ChgBDFFACS").getPlaceholder();
											*/
											var oETDesc = oView.byId("ChgBDET").getValue();
											var oTSDesc = oView.byId("ChgBDTS").getValue();
											var oTJDesc = oView.byId("ChgBDTJ").getValue();
											var oBTDesc = oView.byId("ChgBDBT").getValue();
											var oBFDesc = oView.byId("ChgBDBF").getValue();
											var oBMDesc = oView.byId("ChgBDBM").getValue();
											var oBCDesc = oView.byId("ChgBDBC").getValue();
											var oECSDesc = oView.byId("ChgBDECS").getValue();
											var oFFACSDesc = oView.byId("ChgBDFFACS").getValue();

											if (oETDesc.length === 1 && oETDesc === " ") {
												oETDesc = "";
											}
											if (oTSDesc.length === 1 && oTSDesc === " ") {
												oTSDesc = "";
											}
											if (oTJDesc.length === 1 && oTJDesc === " ") {
												oTJDesc = "";
											}
											if (oBTDesc.length === 1 && oBTDesc === " ") {
												oBTDesc = "";
											}
											if (oBFDesc.length === 1 && oBFDesc === " ") {
												oBFDesc = "";
											}
											if (oBMDesc.length === 1 && oBMDesc === " ") {
												oBMDesc = "";
											}
											if (oBCDesc.length === 1 && oBCDesc === " ") {
												oBCDesc = "";
											}
											if (oECSDesc.length === 1 && oECSDesc === " ") {
												oECSDesc = "";
											}
											if (oFFACSDesc.length === 1 && oFFACSDesc === " ") {
												oFFACSDesc = "";
											}
											/*
																						if (oETDesc.length === 0) {
																							oET = "";
																						}
																						if (oTSDesc.length === 0) {
																							oTS = "";
																						}
																						if (oTJDesc.length === 0) {
																							oTJ = "";
																						}
																						if (oBTDesc.length === 0) {
																							oBT = "";
																						}
																						if (oBFDesc.length === 0) {
																							oBF = "";
																						}
																						if (oBMDesc.length === 0) {
																							oBM = "";
																						}
																						if (oBCDesc.length === 0) {
																							oBC = "";
																						}
																						if (oECSDesc.length === 0) {
																							oECS = "";
																						}
																						if (oFFACSDesc.length === 0) {
																							oFFACS = "";
																						}
											*/
											//var oTCS = oView.byId("ChgBDTCS").getPlaceholder();
											var oTCSDesc = oView.byId("ChgBDTCS").getValue();
											if (oTCSDesc.length === 1 && oTCSDesc === " ") {
												oTCSDesc = "";
											}
											/*if (oTCSDesc.length === 0) {
												oTCS = "";
											}*/
											var oTCSVF = oView.byId("ChgBDTCSVF").getValue();
											if (oTCSVF) {
												oTCSVF = oTCSVF + oTime;
											} else {
												oTCSVF = null;
											}

											//var oACS = oView.byId("ChgBDACS").getPlaceholder();
											var oACSDesc = oView.byId("ChgBDACS").getValue();
											if (oACSDesc.length === 1 && oACSDesc === " ") {
												oACSDesc = "";
											}
											/*if (oACSDesc.length === 0) {
												oACS = "";
											}*/
											var oACSVF = oView.byId("ChgBDACSVF").getValue();
											if (oACSVF) {
												oACSVF = oACSVF + oTime;
											} else {
												oACSVF = null;
											}

											var bTCSSuccess = false,
												bACSSuccess = false;
											if (oTCSDesc.length === 0) {
												oTCSVF = null;
												bTCSSuccess = true;
											} else {
												if (oTCSVF !== null) {
													bTCSSuccess = true;
												} else { // Error message for the user to add date as TCS field has value.
													bTCSSuccess = false;
													sap.m.MessageBox.show("Billing Data Tab: Please provide Task Code Set Valid From", sap.m.MessageBox.Icon.ERROR);
												}
											}
											if (oACSDesc.length === 0) {
												oACSVF = null;
												bACSSuccess = true;
											} else {
												if (oACSVF !== null) {
													bACSSuccess = true;
												} else { // Error message for the user to add date as ACS field has value.
													bACSSuccess = false;
													sap.m.MessageBox.show("Billing Data Tab: Please provide Activity Code Set Valid From", sap.m.MessageBox.Icon.ERROR);
												}
											}
											if (bTCSSuccess && bACSSuccess) {

												// Billing Financial Tab
												//var oDB = oView.byId("ChgBFDB").getPlaceholder();
												var oDBDesc = oView.byId("ChgBFDB").getValue();
												if (oDBDesc.length === 1 && oDBDesc === " ") {
													oDBDesc = "";
												}
												/*if (oDBDesc.length === 0) {
													oDB = "";
												}*/
												var oAC = oView.byId("ChgBFAC").getState();
												if (oAC) {
													oAC = " ";
												} else {
													oAC = "N";
												}
												// Child Body
												var saveChildDataBF = [];

												var oTableBF = oView.byId("FormChange354BF1");
												var oTModelBF = oTableBF.getModel();
												var modelDataBF = oTModelBF.getData();

												for (var k = 0; k < modelDataBF.modelData.length; k++) {
													var value2 = modelDataBF.modelData[k];
													saveChildDataBF.push(value2);
												}

												var aPerc = [];
												for (var m = 0; m < saveChildDataBF.length; m++) {
													var value4 = saveChildDataBF[m].Perc;
													aPerc.push(parseInt(value4));
												}
												var total = 0;
												$.each(aPerc, function() {
													total += this;
												});

												if (total !== 0 && total !== 100) { // Don't make an ODATA call.
													var oMsg = "Billing Financial Tab: Percentage in Billing Financial section needs to be 0 or 100.";
													sap.m.MessageBox.show(oMsg, sap.m.MessageBox.Icon.ERROR);
												} else { // Make an ODATA call.
													for (var l = 0; l < this._aDelTableBF.length; l++) {
														var value3 = this._aDelTableBF[l];
														value3.Update = "D";
														saveChildDataBF.push(value3);
													}
													this._aDelTableBF.length = 0;

													//var oShell = sap.ui.getCore().byId("mattersShell");
													oView.setBusy(true);

													// Business Partners Tab

													// Child Body
													var saveChildDataBP = [];

													var oTableBP = oView.byId("FormChange354BP");
													var oTModelBP = oTableBP.getModel();
													var modelDataBP = oTModelBP.getData();

													for (var i = 0; i < modelDataBP.modelData.length; i++) {
														var value = modelDataBP.modelData[i];
														delete value.ZzlinkE;
														saveChildDataBP.push(value);
													}

													for (var j = 0; j < this._aDelTableBP.length; j++) {
														var value1 = this._aDelTableBP[j];
														value1.Update = "D";
														delete value1.ZzlinkE;
														saveChildDataBP.push(value1);
													}
													this._aDelTableBP.length = 0;

													// Matter Info Tab
													var oMatterType = oView.byId("ChgMIMT").getSelectedKey();
/*													
													var oMatterCat = oView.byId("ChgMIMC").getPlaceholder();
													var oMR = oView.byId("ChgMIMR").getPlaceholder();
													var oGB = oView.byId("ChgMIGB").getPlaceholder();
													var oLPG = oView.byId("ChgMILPG").getPlaceholder();
													var oAOL = oView.byId("ChgMIAOL").getPlaceholder();
													var oMPG = oView.byId("ChgMIMPG").getPlaceholder();
*/
													var oMatterCatDesc = oView.byId("ChgMIMC").getValue();
													var oMRDesc = oView.byId("ChgMIMR").getValue();
													var oGBDesc = oView.byId("ChgMIGB").getValue();
													var oLPGDesc = oView.byId("ChgMILPG").getValue();
													var oAOLSDesc = oView.byId("ChgMIAOL").getValue();
													var oMPGDesc = oView.byId("ChgMIMPG").getValue();

													if (oMatterCatDesc.length === 1 && oMatterCatDesc === " ") {
														oMatterCatDesc = "";
													}
													if (oMRDesc.length === 1 && oMRDesc === " ") {
														oMRDesc = "";
													}
													if (oGBDesc.length === 1 && oGBDesc === " ") {
														oGBDesc = "";
													}
													if (oLPGDesc.length === 1 && oLPGDesc === " ") {
														oLPGDesc = "";
													}
													if (oAOLSDesc.length === 1 && oAOLSDesc === " ") {
														oAOLSDesc = "";
													}
													if (oMPGDesc.length === 1 && oMPGDesc === " ") {
														oMPGDesc = "";
													}
/*
													if (oMatterCatDesc.length === 0) {
														oMatterCat = "";
													}
													if (oMRDesc.length === 0) {
														oMR = "";
													}
													if (oGBDesc.length === 0) {
														oGB = "";
													}
													if (oLPGDesc.length === 0) {
														oLPG = "";
													}
													if (oAOLSDesc.length === 0) {
														oAOL = "";
													}
													if (oMPGDesc.length === 0) {
														oMPG = "";
													}
*/
													var oMIPC = oView.byId("ChgMIPC").getValue();
													if (!oMIPC) {
														oMIPC = null;
													}
													var oMIPCD = oView.byId("ChgMIPCD").getValue();
													if (oMIPCD) {
														oMIPCD = oMIPCD + oTime;
													} else {
														oMIPCD = null;
													}

													var oAM = oView.byId("ChgMIAM").getState();
													if (oAM) {
														oAM = "N";
													} else {
														oAM = " ";
													}
													var oPA = oView.byId("ChgMIPA").getState();
													if (oPA) {
														oPA = "X";
													} else {
														oPA = " ";
													}
													var oP = oView.byId("ChgMIP").getState();
													if (oP) {
														oP = "X";
													} else {
														oP = " ";
													}

													// Output Data Tab
													var oCCNbr = oView.byId("ChgODCCNbr").getValue();
													var oCCN = oView.byId("ChgODCCN").getValue();
													var oS1 = oView.byId("ChgODS1").getValue();
													var oS2 = oView.byId("ChgODS2").getValue();
													var oS3 = oView.byId("ChgODS3").getValue();
													var oS4 = oView.byId("ChgODS4").getValue();
													var oS5 = oView.byId("ChgODS5").getValue();
/*
													var oBL = oView.byId("ChgODBL").getPlaceholder();
													var oIV = oView.byId("ChgODIV").getPlaceholder();
													var oDBF = oView.byId("ChgODDBF").getPlaceholder();
													var oFBF = oView.byId("ChgODFBF").getPlaceholder();
													var oTD = oView.byId("ChgODTD").getPlaceholder();
													var oTK = oView.byId("ChgODTK").getPlaceholder();
													var oCD = oView.byId("ChgODCD").getPlaceholder();
*/
													var oBLDesc = oView.byId("ChgODBL").getValue();
													var oIVDesc = oView.byId("ChgODIV").getValue();
													var oDBFDesc = oView.byId("ChgODDBF").getValue();
													var oFBFDesc = oView.byId("ChgODFBF").getValue();
													var oTDDesc = oView.byId("ChgODTD").getValue();
													var oTKDesc = oView.byId("ChgODTK").getValue();
													var oCDDesc = oView.byId("ChgODCD").getValue();

													if (oBLDesc.length === 1 && oBLDesc === " ") {
														oBLDesc = "";
													}
													if (oIVDesc.length === 1 && oIVDesc === " ") {
														oIVDesc = "";
													}
													if (oDBFDesc.length === 1 && oDBFDesc === " ") {
														oDBFDesc = "";
													}
													if (oFBFDesc.length === 1 && oFBFDesc === " ") {
														oFBFDesc = "";
													}
													if (oTDDesc.length === 1 && oTDDesc === " ") {
														oTDDesc = "";
													}
													if (oTKDesc.length === 1 && oTKDesc === " ") {
														oTKDesc = "";
													}
													if (oCDDesc.length === 1 && oCDDesc === " ") {
														oCDDesc = "";
													}
/*
													if (oBLDesc.length === 0) {
														oBL = "";
													}
													if (oIVDesc.length === 0) {
														oIV = "";
													}
													if (oDBFDesc.length === 0) {
														oDBF = "";
													}
													if (oFBFDesc.length === 0) {
														oFBF = "";
													}
													if (oTDDesc.length === 0) {
														oTD = "";
													}
													if (oTKDesc.length === 0) {
														oTK = "";
													}
													if (oCDDesc.length === 0) {
														oCD = "";
													}
*/
													var oPN = oView.byId("ChgODPN").getState();
													var oRP = oView.byId("ChgODRP").getState();
													var oWO = oView.byId("ChgODWO").getState();

													if (oPN) {
														oPN = "X";
													} else {
														oPN = " ";
													}
													if (oRP) {
														oRP = "X";
													} else {
														oRP = " ";
													}
													if (oWO) {
														oWO = "X";
													} else {
														oWO = " ";
													}

													// Billing Instructions Tab
													var oBI = oView.byId("FormChange354BI").getValue();

													//var oViewBindingPath = oView.getBindingContext().getPath();
													//var oPspid = oViewBindingPath.match(/'(\w*)'/)[1];

													/*if (oMIPC) {
														oMIPC = oMIPC.replace(",", ".");
													}
													if (oMCA) {
														oMCA = oMCA.replace(",", ".");
													}*/
													var oPspid = oView.byId("detailHeader").getNumber();
													var saveHeaderData = {
														Pspid: oPspid,
														CheckNoLock: that._oCheckNoLock,
														Etag: that._oEtagDtl,

														Zzmattertype: oMatterType,
														
														Zzmattercat: oMatterCatDesc,
														Zzmatrptgrp: oMRDesc,
														Zzgrpbill: oGBDesc,
														
														Zzcompletion: oMIPC,
														Zzcompldate: oMIPCD,
														
														Zzpracticegroup: oLPGDesc,
														Zzaol: oAOLSDesc,
														Zzmprgrp: oMPGDesc,
														
														Zzmonlau: oAM,
														Zziob: oPA,
														Zzpriconf: oP,
														
														Zzenttype: oETDesc,
														Zztax: oTSDesc,
														Txjcd: oTJDesc,
														Zzbillteam: oBTDesc,
														Zzbillfreq: oBFDesc,
														Zzbillmthd: oBMDesc,
														Zzmcurr: oBCDesc,
														
														Zzexpcodeset: oECSDesc,
														Zzfftcset: oFFACSDesc,
														
														Zztaskcodeset: oTCSDesc,
														ZztcsetValidfrom: oTCSVF,
														Zzactcodeset: oACSDesc,
														ZzacsetValidfrom: oACSVF,
														
														Zzcap: oMCA,
														
														Zzmansp: oDBDesc,
														Zzcolco: oAC,

														Zzbspras: oBLDesc,
														Zzintver: oIVDesc,
														Zzdrftformat: oDBFDesc,
														Zzfnalformat: oFBFDesc,
														Zztmdtl: oTDDesc,
														Zztksumry: oTKDesc,
														Zzcstdtsumry: oCDDesc,
														
														Zzclcasenbr: oCCNbr,
														Zzclcasename: oCCN,
														Zzipsort1: oS1,
														Zzipsort2: oS2,
														Zzipsort3: oS3,
														Zzipsort4: oS4,
														Zzipsort5: oS5,
														Zzmatpageno: oPN,
														Zzmatremit: oRP,
														Zzsumwo: oWO,

														Zzbillinst: oBI
													};
													saveHeaderData.MatterDet_MatterBp = saveChildDataBP; //Add BP child to request
													saveHeaderData.MatterDet_MatterMPY = saveChildDataBF; //Add BF child to request
													var oModel = oView.getModel(); // Call ODATA.
													var saveParam = "/MatterDetailSet";
													var batchChanges = []; //create an array of batch changes and save  
													batchChanges.push(oModel.createBatchOperation(saveParam, "POST", saveHeaderData));
													oModel.addBatchChangeOperations(batchChanges);

													oModel.setHeaders({
														"If-Match": "value1"
													});
													oModel.submitBatch(function(oSuccess) {
														that._oCheckNoLock = " ";
														oView.setBusy(false);
														var aBtchResp = oSuccess.__batchResponses[0];
														if (aBtchResp.__changeResponses) { // Success
															var oSuccessMsg = oSuccess.__batchResponses[0].__changeResponses[0].data.Errormessage;
															oSuccessMsg = "Matter has been updated successfully.";
															sap.m.MessageBox.show(oSuccessMsg, {
																icon: sap.m.MessageBox.Icon.SUCCESS,
																title: "SUCCESS",
																onClose: function() { // On successful update, switch to display mode and refresh the data.
																	oView.setBusy(true);
																	that._toggleButtonsAndView(false);
																	setTimeout(function() {
																		that.onRouteMatchedSuccess();
																		oView.setBusy(false);
																	}, 3000);
																}
															});
														} else {
															var oJSONErr = JSON.parse(oSuccess.__batchResponses[0].response.body).error;
															if (oJSONErr) {
																var oJSONErrTitle = oJSONErr.message.value;
																var oJSONErrDetails = oJSONErr.innererror.errordetails;
																var oJSONErrBody = "";
																for (var p = 0; p < oJSONErrDetails.length; p++) {
																	var valueP = oJSONErrDetails[p];
																	if (valueP.message) {
																		oJSONErrBody = oJSONErrBody + (p + 1) + " : ";
																		oJSONErrBody = oJSONErrBody + valueP.message;
																		oJSONErrBody = oJSONErrBody + "\n";
																	}
																}
																if (oJSONErrBody) {
																	if (oJSONErrDetails[0].message === "Precondition failed") {
																		sap.m.MessageBox.confirm(
																			"Data has been changed by another user. Do you want to overwrite the other user's changes with your own?", {
																				title: "Confirmation",
																				onClose: function(oAction) {
																					if (oAction === "OK") {
																						that._oCheckNoLock = "X";
																						that.handleSavePress();
																					}
																				}
																			});
																	} else {
																		sap.m.MessageBox.show(oJSONErrTitle, {
																			icon: sap.m.MessageBox.Icon.ERROR,
																			title: "ERROR",
																			actions: sap.m.MessageBox.Action.OK,
																			styleClass: "errorMsgBox",
																			details: oJSONErrBody
																		});
																	}
																} else {
																	sap.m.MessageBox.show(oJSONErrTitle, {
																		icon: sap.m.MessageBox.Icon.ERROR,
																		title: "ERROR",
																		actions: sap.m.MessageBox.Action.OK
																	});
																}
															}
														}
													}, function(oError) {});

												}
											}
										} else {
											sap.m.MessageToast.show("Billing Data Tab: Billing Currency must not be empty.");
										}
										//} else {
										//	sap.m.MessageToast.show("Billing Data Tab: Entry Type must not be empty.");
										//}

									} else {
										sap.m.MessageToast.show("Output Data Tab: Cost Detail and Summary must not be empty.");
									}
								} else {
									sap.m.MessageToast.show("Output Data Tab: TK Summarization must not be empty.");
								}
							} else {
								sap.m.MessageToast.show("Output Data Tab: Time Detail must not be empty.");
							}
						} else {
							sap.m.MessageToast.show("Output Data Tab: Final Bill Format must not be empty.");
						}
					} else {
						sap.m.MessageToast.show("Output Data Tab: Draft Bill Format must not be empty.");
					}
				} else {
					sap.m.MessageToast.show("Output Data Tab: Billing Language must not be empty.");
				}

			} else {
				sap.m.MessageToast.show("Matter Info Tab: Matter Category must not be empty.");
			}
		}
	},
	/*
		myBoolean: function(sBool) {
			var bValue = false;
			if (sBool === "true") {
				bValue = true;
			}
			return bValue;
		},
		myBooleanV: function(sBool) {
			var bValue = false;
			if (sBool === "X") {
				bValue = true;
			}
			return bValue;
		},
		myBoolean1: function(sBool) {
			var bValue = false;
			if (sBool !== "SP") {
				bValue = true;
			}
			return bValue;
		},
		myDate: function(sBool) {
			if (sBool) {
				var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					//pattern: "yyyy-MM-dd"
					style: "medium"
				});
				var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;
				var dateStr = dateFormat.format(new Date(sBool.getTime() + TZOffsetMs));
				return dateStr;
			}
		},
		myDate1: function(sBool) {
			if (sBool) {
				var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "yyyy-MM-dd"
						//style: "medium"
				});
				var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;
				var dateStr = dateFormat.format(new Date(sBool.getTime() + TZOffsetMs));
				return dateStr;
			}
		},
		myColor: function(sValue) {
			var bValue = "Success";
			switch (sValue) {
				case "OPEN":
					bValue = "Success";
					break;
				case "CLOSED":
					bValue = "Error";
					break;
				default:
			}
			return bValue;
		},
	*/
	handleAddRowChgBP: function(oEvent) {
		var oTable = this.getView().byId("FormChange354BP");
		var oModel = oTable.getModel();
		var modelData = oModel.getData();
		var aTable = [];
		for (var i = 0; i < modelData.modelData.length; i++) {
			var value = modelData.modelData[i];
			aTable.push(value);
		}
		var oRow = {
			Parvw: "Z1",
			ParnrOld: "",
			ParnrNew: "",
			Name1: "",
			Addrln: "",
			IsEditable: "true",
			Update: "I"
		};
		aTable.push(oRow);
		oModel.setData({
			modelData: aTable
		});
		sap.m.MessageToast.show("Rows added: " + 1);
	},

	handleDelRowChgBP: function(oEvent) {
		var oTable = this.getView().byId("FormChange354BP");
		var m = oTable.getModel();
		var data = m.getData();
		var aSelIndices = oTable.getSelectedIndices();
		/*var index = aSelIndices.indexOf(0);
		if (index > -1) {
			aSelIndices.splice(index, 1);
		}*/
		aSelIndices = aSelIndices.reverse();
		var count = aSelIndices.length;
		var countRow = 0;
		var bFlag = [];
		for (var i = 0; i < count; i++) {
			var value = aSelIndices[i];
			var data1 = data.modelData[value];
			switch (data1.Parvw) {
				case "SP":
					bFlag.push(false);
					sap.m.MessageToast.show("Sold-to party cannot be deleted");
					break;
					/*case "BP":
						bFlag.push(false);
						sap.m.MessageToast.show("Bill-to party cannot be deleted");
						break;*/
				case "PY":
					bFlag.push(false);
					sap.m.MessageToast.show("Payer cannot be deleted");
					break;
					/*case "SH":
						bFlag.push(false);
						sap.m.MessageToast.show("Ship-to party cannot be deleted");
						break;*/
				default:
					bFlag.push(true);
					countRow = countRow + 1;
					this._aDelTableBP.push(data1);
					data.modelData.splice(value, 1);
			}
		}
		oTable.clearSelection();
		for (var a = 0; a < bFlag.length; a++) {
			var value123 = bFlag[a];
			if (value123) {
				m.setData(data);
				sap.m.MessageToast.show("Rows deleted: " + countRow);
			}
		}
		/*if (index > -1) {
			sap.m.MessageToast.show("CLIENT cannot be deleted");
		} else {
			sap.m.MessageToast.show("Rows deleted: " + count);
		}*/
	},

	handleAddRowChgBF: function(oEvent) {
		var oTable = this.getView().byId("FormChange354BF1");
		var oModel = oTable.getModel();
		var modelData = oModel.getData();
		var aTable = [];
		for (var i = 0; i < modelData.modelData.length; i++) {
			var value = modelData.modelData[i];
			aTable.push(value);
		}
		var oRow = {
			Payer_old: "",
			Payer_new: "",
			Name1: "",
			Perc: "",
			Update: "I"
		};
		aTable.push(oRow);
		oModel.setData({
			modelData: aTable
		});
		sap.m.MessageToast.show("Rows added: " + 1);
	},

	handleDelRowChgBF: function(oEvent) {
		var oTable = this.getView().byId("FormChange354BF1");
		var m = oTable.getModel();
		var data = m.getData();
		var aSelIndices = oTable.getSelectedIndices();
		aSelIndices = aSelIndices.reverse();
		var count = aSelIndices.length;
		for (var i = 0; i < count; i++) {
			var value = aSelIndices[i];
			this._aDelTableBF.push(data.modelData[value]);
			data.modelData.splice(value, 1);
		}
		m.setData(data);
		oTable.clearSelection();
		sap.m.MessageToast.show("Rows deleted: " + count);
	},

	handleSelectPartnerTypeBP: function(oEvent) {
		var oSelKey = oEvent.oSource.getSelectedKey();
		if (oSelKey === "SP") {
			sap.m.MessageToast.show("CLIENT can be selected only once.");
			oEvent.oSource.setSelectedKey("PY");
		}
		var oTable = this.getView().byId("FormChange354BP");
		var oModel = oTable.getModel();
		var modelData = oModel.getData();
		var aTable = [];

		for (var i = 0; i < modelData.modelData.length; i++) {
			var value = modelData.modelData[i];
			aTable.push(value);
		}

		if (aTable[this._oTblPrtnrNmbrRowBPBP].Update !== "I") {
			aTable[this._oTblPrtnrNmbrRowBPBP].Update = "U";
		}
		oModel.setData({
			modelData: aTable
		});
	},

	handleLiveChg: function(oEvent) {
		var oValue = oEvent.getParameter("value");
		var oState = "None";
		if (!oValue) {
			oState = "Error";
		}
		oEvent.oSource.setValueState(oState);
	},

	handleValueHelpChgBPBP: function(oEvent) {
		var sFieldName, sFrgmntName;
		sFieldName = "Kunnr";
		sFrgmntName = "ChgBPBP";
		this.handleValueHelpSingleTable(oEvent, sFieldName, sFrgmntName);
	},
	handleValueHelpSingleTable: function(oEvent, sFieldName, sFrgmntName) {
		var oView = this.getView();
		var oId = oEvent.getParameter("id");
		var oIndex = oId.indexOf("w");
		oIndex = oIndex + 1;
		var oSelRow = oId.substr(oIndex);
		var oTable = oView.byId("FormChange354BP");
		var oModel = oTable.getModel();
		var modelData = oModel.getData();
		var value = modelData.modelData[oSelRow];
		var oFltr = value.Parvw;
		this._sFltr = oFltr.toString();
		var oPspid = oView.byId("detailHeader").getNumber();
		var sInputValue = oEvent.getSource().getValue();
		this.inputId = sFrgmntName;

		// create a filter for the binding
		var oFilter, aFilter = [];
		oFilter = new sap.ui.model.Filter(sFieldName, sap.ui.model.FilterOperator.Contains, sInputValue);
		aFilter.push(oFilter);
		oFilter = new sap.ui.model.Filter("Parvw", sap.ui.model.FilterOperator.EQ, this._sFltr);
		aFilter.push(oFilter);
		oFilter = new sap.ui.model.Filter("Pspid", sap.ui.model.FilterOperator.EQ, oPspid);
		aFilter.push(oFilter);
		oFilter = new sap.ui.model.Filter("Client", sap.ui.model.FilterOperator.EQ, this._oClientBPBP);
		aFilter.push(oFilter);

		// create value help dialog
		this._valueHelpDialog = sap.ui.xmlfragment("Matters_NRF.fragments.change.dialogSearch." + sFrgmntName, this);
		this.getView().addDependent(this._valueHelpDialog);
		this._valueHelpDialog.getBinding("items").filter(aFilter);

		// open value help dialog filtered by the input value
		this._valueHelpDialog.open(sInputValue);
	},
	handleValueHelpSearchChgBPBP: function(evt) {
		var oView = this.getView();
		var sValue = evt.getParameter("value");
		var oPspid = oView.byId("detailHeader").getNumber();

		// create a filter for the binding
		var oFilter, aFilter = [];

		oFilter = new sap.ui.model.Filter("Kunnr", sap.ui.model.FilterOperator.Contains, sValue);
		aFilter.push(oFilter);
		oFilter = new sap.ui.model.Filter("Parvw", sap.ui.model.FilterOperator.EQ, this._sFltr);
		aFilter.push(oFilter);
		oFilter = new sap.ui.model.Filter("Pspid", sap.ui.model.FilterOperator.EQ, oPspid);
		aFilter.push(oFilter);
		evt.getSource().getBinding("items").filter(aFilter);
	},

	handleSelectMatterTypeMI: function(oEvent) {
		var oSelKey = oEvent.oSource.getSelectedKey();
		this.oDesc = oSelKey;
	},
	handleValueHelpChgMIMT: function(oEvent) {
		//var oSelKey = oEvent.oSource.getSelectedKey();
		/*var sFieldName, sFrgmntName;
			sFieldName = "Description";
			sFrgmntName = "ChgMIMT";
			this.handleValueHelpSingle(oEvent, sFieldName, sFrgmntName);*/

		/*var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.getView().byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
				this.oDesc = oSelectedItem.getDescription();
				productInput.setPlaceholder(this.oDesc);
			}
			evt.getSource().getBinding("items").filter([]);*/
	},
	handleValueHelpSearchChgMIMT: function(evt) {
		var sFieldName1 = "Description";
		this._handleValueHelpSearch(evt, sFieldName1);
	},

	handleValueHelpChgMIMC: function(oEvent) {
		var sFieldName1, sFieldName2, sFrgmntName;
		sFieldName1 = "Mattertype";
		sFieldName2 = "Catdescription";
		sFrgmntName = "ChgMIMC";
		this.handleValueHelp(oEvent, sFieldName1, sFieldName2, sFrgmntName);
	},
	handleValueHelpSearchChgMIMC: function(evt) {
		/*var sFieldName1 = "Catdescription";
			this._handleValueHelpSearch(evt, sFieldName1);*/
		var sFieldName1, sFieldName2;
		sFieldName1 = "Mattertype";
		sFieldName2 = "Catdescription";
		this._handleValueHelpSearchDouble(evt, sFieldName1, sFieldName2);
	},

	handleValueHelpChgMIGB: function(oEvent) {
		var sFieldName, sFrgmntName;
		sFieldName = "Post1";
		sFrgmntName = "ChgMIGB";
		this.handleValueHelpSingleMIGB(oEvent, sFieldName, sFrgmntName);
	},
	handleValueHelpSearchChgMIGB: function(evt) {
		var sFieldName1 = "Post1";
		this._handleValueHelpSearchMIGB(evt, sFieldName1);
	},

	handleValueHelpChgMIMR: function(oEvent) {
		var sFieldName, sFrgmntName;
		sFieldName = "Post1";
		sFrgmntName = "ChgMIMR";
		this.handleValueHelpSingle(oEvent, sFieldName, sFrgmntName);
	},
	handleValueHelpSearchChgMIMR: function(evt) {
		var sFieldName1 = "Post1";
		this._handleValueHelpSearch(evt, sFieldName1);
	},

	handleValueHelpChgMILPG: function(oEvent) {
		var sFieldName, sFrgmntName;
		sFieldName = "Desc40";
		sFrgmntName = "ChgMILPG";
		this.handleValueHelpSingle(oEvent, sFieldName, sFrgmntName);
	},
	handleValueHelpSearchChgMILPG: function(evt) {
		var sFieldName1 = "Desc40";
		this._handleValueHelpSearch(evt, sFieldName1);
	},

	handleValueHelpChgMIAOL: function(oEvent) {
		var sFieldName, sFrgmntName;
		sFieldName = "Desc80";
		sFrgmntName = "ChgMIAOL";
		this.handleValueHelpSingle(oEvent, sFieldName, sFrgmntName);
	},
	handleValueHelpSearchChgMIAOL: function(evt) {
		var sFieldName1 = "Desc80";
		this._handleValueHelpSearch(evt, sFieldName1);
	},

	handleValueHelpChgMIMPG: function(oEvent) {
		var sFieldName, sFrgmntName;
		sFieldName = "Zzmprgrp";
		sFrgmntName = "ChgMIMPG";
		this.handleValueHelpSingle(oEvent, sFieldName, sFrgmntName);
	},
	handleValueHelpSearchChgMIMPG: function(evt) {
		var sFieldName1 = "Zzmprgrp";
		this._handleValueHelpSearch(evt, sFieldName1);
	},

	handleValueHelpChgBDET: function(oEvent) {
		var sFieldName, sFrgmntName;
		sFieldName = "Vtext";
		sFrgmntName = "ChgBDET";
		this.handleValueHelpSingle(oEvent, sFieldName, sFrgmntName);
	},
	handleValueHelpSearchChgBDET: function(evt) {
		var sFieldName1 = "Vtext";
		this._handleValueHelpSearch(evt, sFieldName1);
	},

	handleValueHelpChgBDECS: function(oEvent) {
		var sFieldName, sFrgmntName;
		sFieldName = "Zzsetname";
		sFrgmntName = "ChgBDECS";
		this.handleValueHelpSingle(oEvent, sFieldName, sFrgmntName);
	},
	handleValueHelpSearchChgBDECS: function(evt) {
		var sFieldName1 = "Zzsetname";
		this._handleValueHelpSearch(evt, sFieldName1);
	},

	handleValueHelpChgBDTCS: function(oEvent) {
		var sFieldName, sFrgmntName;
		sFieldName = "ZztaskcodesDesc";
		sFrgmntName = "ChgBDTCS";
		this.handleValueHelpSingle(oEvent, sFieldName, sFrgmntName);
	},
	handleValueHelpSearchChgBDTCS: function(evt) {
		var sFieldName1 = "ZztaskcodesDesc";
		this._handleValueHelpSearch(evt, sFieldName1);
	},

	handleValueHelpChgBDACS: function(oEvent) {
		var sFieldName, sFrgmntName;
		sFieldName = "Zzactcodedesc";
		sFrgmntName = "ChgBDACS";
		this.handleValueHelpSingle(oEvent, sFieldName, sFrgmntName);
	},
	handleValueHelpSearchChgBDACS: function(evt) {
		var sFieldName1 = "Zzactcodedesc";
		this._handleValueHelpSearch(evt, sFieldName1);
	},

	handleValueHelpChgBDFFACS: function(oEvent) {
		var sFieldName, sFrgmntName;
		sFieldName = "Zzfftaskcodedesc";
		sFrgmntName = "ChgBDFFACS";
		this.handleValueHelpSingle(oEvent, sFieldName, sFrgmntName);
	},
	handleValueHelpSearchChgBDFFAC: function(evt) {
		var sFieldName1 = "Zzfftaskcodedesc";
		this._handleValueHelpSearch(evt, sFieldName1);
	},

	handleValueHelpChgBDBT: function(oEvent) {
		var sFieldName, sFrgmntName;
		sFieldName = "Zzdesc";
		sFrgmntName = "ChgBDBT";
		this.handleValueHelpSingle(oEvent, sFieldName, sFrgmntName);
	},
	handleValueHelpSearchChgBDBT: function(evt) {
		var sFieldName1 = "Zzdesc";
		this._handleValueHelpSearch(evt, sFieldName1);
	},

	handleValueHelpChgBDBF: function(oEvent) {
		var sFieldName, sFrgmntName;
		sFieldName = "Zzdesc";
		sFrgmntName = "ChgBDBF";
		this.handleValueHelpSingle(oEvent, sFieldName, sFrgmntName);
	},
	handleValueHelpSearchChgBDBF: function(evt) {
		var sFieldName1 = "Zzdesc";
		this._handleValueHelpSearch(evt, sFieldName1);
	},

	handleValueHelpChgBDBM: function(oEvent) {
		var sFieldName, sFrgmntName;
		sFieldName = "Zzdesc";
		sFrgmntName = "ChgBDBM";
		this.handleValueHelpSingle(oEvent, sFieldName, sFrgmntName);
	},
	handleValueHelpSearchChgBDBM: function(evt) {
		var sFieldName1 = "Zzdesc";
		this._handleValueHelpSearch(evt, sFieldName1);
	},

	handleValueHelpChgBDBC: function(oEvent) {
		var sFieldName, sFrgmntName;
		sFieldName = "Ltext";
		sFrgmntName = "ChgBDBC";
		this.handleValueHelpSingle(oEvent, sFieldName, sFrgmntName);
	},
	handleValueHelpSearchChgBDBC: function(evt) {
		var sFieldName1 = "Ltext";
		this._handleValueHelpSearch(evt, sFieldName1);
	},

	handleValueHelpChgBDTS: function(oEvent) {
		/*			var sFieldName, sFrgmntName;
			sFieldName = "Text1";
			sFrgmntName = "ChgBDTS";
			this.handleValueHelpSingle(oEvent, sFieldName, sFrgmntName);*/

		var sFieldName1, sFieldName2, sFrgmntName;
		sFieldName1 = "Pspid";
		sFieldName2 = "Vtext";
		sFrgmntName = "ChgBDTS";
		//this.handleValueHelpSingle(oEvent, sFieldName, sFrgmntName);

		var sInputValue = oEvent.getSource().getValue();
		this.inputId = sFrgmntName;
		// create value help dialog
		//if (!this._valueHelpDialog) {
		this._valueHelpDialog = sap.ui.xmlfragment("Matters_NRF.fragments.change.dialogSearch." + sFrgmntName, this);
		this.getView().addDependent(this._valueHelpDialog);
		//}
		// create a filter for the binding
		var aFilter = [];
		var oFilter;

		var oPspid = this.getView().byId("detailHeader").getNumber();

		oFilter = new sap.ui.model.Filter(sFieldName1, sap.ui.model.FilterOperator.EQ, oPspid);
		aFilter.push(oFilter);
		oFilter = new sap.ui.model.Filter(sFieldName2, sap.ui.model.FilterOperator.Contains, sInputValue);
		aFilter.push(oFilter);
		this._valueHelpDialog.getBinding("items").filter(aFilter);

		// open value help dialog filtered by the input value
		this._valueHelpDialog.open(sInputValue);
	},
	handleValueHelpSearchChgBDTS: function(evt) {
		/*			var sFieldName1 = "Text1";
			this._handleValueHelpSearch(evt, sFieldName1);*/

		var sFieldName1 = "Pspid";
		var sFieldName2 = "Vtext";

		//this._handleValueHelpSearch(evt, sFieldName1);

		var sValue = evt.getParameter("value");
		var oFilter;
		var aFilter = [];
		var oPspid = this.getView().byId("detailHeader").getNumber();
		oFilter = new sap.ui.model.Filter(sFieldName1, sap.ui.model.FilterOperator.EQ, oPspid);
		aFilter.push(oFilter);
		oFilter = new sap.ui.model.Filter(sFieldName2, sap.ui.model.FilterOperator.Contains, sValue);
		aFilter.push(oFilter);
		evt.getSource().getBinding("items").filter(aFilter);
	},

	handleValueHelpChgBDTJ: function(oEvent) {
		var sFieldName1, sFieldName2, sFrgmntName;
		sFieldName1 = "Pspid";
		sFieldName2 = "Text1";
		sFrgmntName = "ChgBDTJ";
		//this.handleValueHelpSingle(oEvent, sFieldName, sFrgmntName);

		var sInputValue = oEvent.getSource().getValue();
		this.inputId = sFrgmntName;
		// create value help dialog
		//if (!this._valueHelpDialog) {
		this._valueHelpDialog = sap.ui.xmlfragment("Matters_NRF.fragments.change.dialogSearch." + sFrgmntName, this);
		this.getView().addDependent(this._valueHelpDialog);
		//}
		// create a filter for the binding
		var aFilter = [];
		var oFilter;

		var oPspid = this.getView().byId("detailHeader").getNumber();

		oFilter = new sap.ui.model.Filter(sFieldName1, sap.ui.model.FilterOperator.EQ, oPspid);
		aFilter.push(oFilter);
		oFilter = new sap.ui.model.Filter(sFieldName2, sap.ui.model.FilterOperator.Contains, sInputValue);
		aFilter.push(oFilter);
		this._valueHelpDialog.getBinding("items").filter(aFilter);

		// open value help dialog filtered by the input value
		this._valueHelpDialog.open(sInputValue);
	},
	handleValueHelpSearchChgBDTJ: function(evt) {
		var sFieldName1 = "Pspid";
		var sFieldName2 = "Text1";

		//this._handleValueHelpSearch(evt, sFieldName1);

		var sValue = evt.getParameter("value");
		var oFilter;
		var aFilter = [];
		var oPspid = this.getView().byId("detailHeader").getNumber();
		oFilter = new sap.ui.model.Filter(sFieldName1, sap.ui.model.FilterOperator.EQ, oPspid);
		aFilter.push(oFilter);
		oFilter = new sap.ui.model.Filter(sFieldName2, sap.ui.model.FilterOperator.Contains, sValue);
		aFilter.push(oFilter);
		evt.getSource().getBinding("items").filter(aFilter);
	},

	handleValueHelpChgBFDB: function(oEvent) {
		var sFieldName, sFrgmntName;
		sFieldName = "Text1";
		sFrgmntName = "ChgBFDB";
		this.handleValueHelpSingle(oEvent, sFieldName, sFrgmntName);
	},
	handleValueHelpSearchChgBFDB: function(evt) {
		var sFieldName1 = "Text1";
		this._handleValueHelpSearch(evt, sFieldName1);
	},

	handleValueHelpChgBFBP: function(oEvent) {
		var sFieldName, sFrgmntName;
		sFieldName = "Kunnr";
		sFrgmntName = "ChgBFBP";
		//this.handleValueHelpSingle(oEvent, sFieldName, sFrgmntName);
		this.handleValueHelpSingleTableBFBP(oEvent, sFieldName, sFrgmntName);
	},
	handleValueHelpSingleTableBFBP: function(oEvent, sFieldName, sFrgmntName) {
		var oView = this.getView();
		var oPspid = oView.byId("detailHeader").getNumber();
		var sInputValue = oEvent.getSource().getValue();
		this.inputId = sFrgmntName;

		// create a filter for the binding
		var oFilter, aFilter = [];
		oFilter = new sap.ui.model.Filter(sFieldName, sap.ui.model.FilterOperator.Contains, sInputValue);
		aFilter.push(oFilter);
		oFilter = new sap.ui.model.Filter("Parvw", sap.ui.model.FilterOperator.EQ, "PY");
		aFilter.push(oFilter);
		oFilter = new sap.ui.model.Filter("Pspid", sap.ui.model.FilterOperator.EQ, oPspid);
		aFilter.push(oFilter);
		// create value help dialog
		this._valueHelpDialog = sap.ui.xmlfragment("Matters_NRF.fragments.change.dialogSearch." + sFrgmntName, this);
		this.getView().addDependent(this._valueHelpDialog);
		this._valueHelpDialog.getBinding("items").filter(aFilter);

		// open value help dialog filtered by the input value
		this._valueHelpDialog.open(sInputValue);
	},
	handleValueHelpSearchChgBFBP: function(evt) {
		/*	var sFieldName1 = "Kunnr";
			this._handleValueHelpSearch(evt, sFieldName1);*/

		var oView = this.getView();
		var sValue = evt.getParameter("value");
		var oPspid = oView.byId("detailHeader").getNumber();

		// create a filter for the binding
		var oFilter, aFilter = [];

		oFilter = new sap.ui.model.Filter("Kunnr", sap.ui.model.FilterOperator.Contains, sValue);
		aFilter.push(oFilter);
		oFilter = new sap.ui.model.Filter("Parvw", sap.ui.model.FilterOperator.EQ, "PY");
		aFilter.push(oFilter);
		oFilter = new sap.ui.model.Filter("Pspid", sap.ui.model.FilterOperator.EQ, oPspid);
		aFilter.push(oFilter);
		evt.getSource().getBinding("items").filter(aFilter);
	},

	handleValueHelpChgODBL: function(oEvent) {
		var sFieldName, sFrgmntName;
		sFieldName = "Sptxt";
		sFrgmntName = "ChgODBL";
		this.handleValueHelpSingle(oEvent, sFieldName, sFrgmntName);
	},
	handleValueHelpSearchChgODBL: function(evt) {
		var sFieldName1 = "Sptxt";
		this._handleValueHelpSearch(evt, sFieldName1);
	},

	handleValueHelpChgODIV: function(oEvent) {
		var sFieldName, sFrgmntName;
		sFieldName = "NationTex";
		sFrgmntName = "ChgODIV";
		this.handleValueHelpSingle(oEvent, sFieldName, sFrgmntName);
	},
	handleValueHelpSearchChgODIV: function(evt) {
		var sFieldName1 = "NationTex";
		this._handleValueHelpSearch(evt, sFieldName1);
	},

	handleValueHelpChgODDBF: function(oEvent) {
		var sFieldName, sFrgmntName;
		sFieldName = "Vtext";
		sFrgmntName = "ChgODDBF";
		this.handleValueHelpSingle(oEvent, sFieldName, sFrgmntName);
	},
	handleValueHelpSearchChgODDBF: function(evt) {
		var sFieldName1 = "Vtext";
		this._handleValueHelpSearch(evt, sFieldName1);
	},

	handleValueHelpChgODFBF: function(oEvent) {
		var sFieldName, sFrgmntName;
		sFieldName = "Vtext";
		sFrgmntName = "ChgODFBF";
		this.handleValueHelpSingle(oEvent, sFieldName, sFrgmntName);
	},
	handleValueHelpSearchChgODFBF: function(evt) {
		var sFieldName1 = "Vtext";
		this._handleValueHelpSearch(evt, sFieldName1);
	},

	handleValueHelpChgODTD: function(oEvent) {
		var sFieldName1, sFieldName2, sFrgmntName;
		sFieldName1 = "Zzfnalformat";
		sFieldName2 = "Desc80";
		sFrgmntName = "ChgODTD";
		this.handleValueHelpF(oEvent, sFieldName1, sFieldName2, sFrgmntName);
	},
	handleValueHelpSearchChgODTD: function(evt) {
		/*			var sFieldName1 = "Desc80";
			this._handleValueHelpSearch(evt, sFieldName1);*/

		var sFieldName1, sFieldName2;
		sFieldName1 = "Zzfnalformat";
		sFieldName2 = "Desc80";
		this._handleValueHelpSearchDoubleF(evt, sFieldName1, sFieldName2);
	},

	handleValueHelpChgODTK: function(oEvent) {
		var sFieldName1, sFieldName2, sFrgmntName;
		sFieldName1 = "Zzfnalformat";
		sFieldName2 = "Desc80";
		sFrgmntName = "ChgODTK";
		this.handleValueHelpF(oEvent, sFieldName1, sFieldName2, sFrgmntName);
	},
	handleValueHelpSearchChgODTK: function(evt) {
		/*			var sFieldName1 = "Desc80";
			this._handleValueHelpSearch(evt, sFieldName1);*/

		var sFieldName1, sFieldName2;
		sFieldName1 = "Zzfnalformat";
		sFieldName2 = "Desc80";
		this._handleValueHelpSearchDoubleF(evt, sFieldName1, sFieldName2);
	},

	handleValueHelpChgODCD: function(oEvent) {
		var sFieldName1, sFieldName2, sFrgmntName;
		sFieldName1 = "Zzfnalformat";
		sFieldName2 = "Desc80";
		sFrgmntName = "ChgODCD";
		this.handleValueHelpF(oEvent, sFieldName1, sFieldName2, sFrgmntName);
	},
	handleValueHelpSearchChgODCD: function(evt) {
		/*			var sFieldName1 = "Desc80";
			this._handleValueHelpSearch(evt, sFieldName1);*/

		var sFieldName1, sFieldName2;
		sFieldName1 = "Zzfnalformat";
		sFieldName2 = "Desc80";
		this._handleValueHelpSearchDoubleF(evt, sFieldName1, sFieldName2);
	},

	handleValueHelpF: function(oEvent, sFieldName1, sFieldName2, sFrgmntName) {
		var sInputValue = oEvent.getSource().getValue();
		this.inputId = sFrgmntName;
		// create value help dialog
		//if (!this._valueHelpDialog) {
		this._valueHelpDialog = sap.ui.xmlfragment("Matters_NRF.fragments.change.dialogSearch." + sFrgmntName, this);
		this.getView().addDependent(this._valueHelpDialog);
		//}
		// create a filter for the binding
		var aFilter = [];
		var oFilter;

		this.oDesc1 = this.getView().byId("ChgODFBF").getValue();

		oFilter = new sap.ui.model.Filter(sFieldName1, sap.ui.model.FilterOperator.EQ, this.oDesc1);
		aFilter.push(oFilter);
		oFilter = new sap.ui.model.Filter(sFieldName2, sap.ui.model.FilterOperator.Contains, sInputValue);
		aFilter.push(oFilter);
		this._valueHelpDialog.getBinding("items").filter(aFilter);

		// open value help dialog filtered by the input value
		this._valueHelpDialog.open(sInputValue);
	},
	_handleValueHelpSearchDoubleF: function(evt, sFieldName1, sFieldName2) {
		var sValue = evt.getParameter("value");
		var oFilter;
		var aFilter = [];

		oFilter = new sap.ui.model.Filter(sFieldName1, sap.ui.model.FilterOperator.EQ, this.oDesc1);
		aFilter.push(oFilter);
		oFilter = new sap.ui.model.Filter(sFieldName2, sap.ui.model.FilterOperator.Contains, sValue);
		aFilter.push(oFilter);
		evt.getSource().getBinding("items").filter(aFilter);
	},

	_handleValueHelpSearch: function(evt, sFieldName1) {
		var sValue = evt.getParameter("value");
		if (sFieldName1 === "Postu") {
			/*if (sValue) {
				sValue = sValue.toUpperCase();
			}*/
		}
		var oFilter = new sap.ui.model.Filter(sFieldName1, sap.ui.model.FilterOperator.Contains, sValue);
		evt.getSource().getBinding("items").filter([oFilter]);
	},

	_handleValueHelpSearchMIGB: function(evt, sFieldName1) {
		var sValue = evt.getParameter("value");
		if (sFieldName1 === "Postu") {
			/*if (sValue) {
				sValue = sValue.toUpperCase();
			}*/
		}
		var aFilter = [];
		var oView = this.getView();
		var oPspid = oView.byId("detailHeader").getNumber();

		var oFilter = new sap.ui.model.Filter(sFieldName1, sap.ui.model.FilterOperator.Contains, sValue);
		aFilter.push(oFilter);

		oFilter = new sap.ui.model.Filter("Pspid", sap.ui.model.FilterOperator.EQ, oPspid);
		aFilter.push(oFilter);

		evt.getSource().getBinding("items").filter(aFilter);
	},

	_handleValueHelpSearchDouble: function(evt, sFieldName1, sFieldName2) {
		var sValue = evt.getParameter("value");
		var oFilter;
		var aFilter = [];

		oFilter = new sap.ui.model.Filter(sFieldName1, sap.ui.model.FilterOperator.EQ, this.oDesc);
		aFilter.push(oFilter);
		oFilter = new sap.ui.model.Filter(sFieldName2, sap.ui.model.FilterOperator.Contains, sValue);
		aFilter.push(oFilter);
		evt.getSource().getBinding("items").filter(aFilter);
	},

	_handleValueHelpClose: function(evt) {
		var oSelectedItem = evt.getParameter("selectedItem");
		if (oSelectedItem) {
			var productInput = this.getView().byId(this.inputId);
			this.oDesc = oSelectedItem.getDescription();

			if (this.inputId === "ChgBDTS") {
				if (this.oDesc.length > 1) {
					this.oDesc = this.oDesc.charAt(0);
				}
			}
			if (this.oDesc !== "N/A") {
				/*productInput.setPlaceholder(this.oDesc);
				productInput.setValue(oSelectedItem.getTitle().trim());*/
				productInput.setValue(this.oDesc);
				productInput.setDescription(oSelectedItem.getTitle().trim());
				productInput.setFieldWidth("40%");
			}
			productInput.setValueState("None");
		}
		evt.getSource().getBinding("items").filter([]);
	},

	_handleValueHelpClose1: function(evt) {
		var oSelectedItem = evt.getParameter("selectedItem");
		if (oSelectedItem) {
			var productInput = this.getView().byId(this.inputId);
			this.oDesc = oSelectedItem.getDescription();

			if (this.inputId === "ChgBDTS") {
				if (this.oDesc.length > 1) {
					this.oDesc = this.oDesc.charAt(0);
				}
			}
			if (this.oDesc !== "N/A") {
				productInput.setPlaceholder(this.oDesc);
				productInput.setValue(oSelectedItem.getTitle().trim());
			}
			productInput.setValueState("None");
		}
		evt.getSource().getBinding("items").filter([]);
	},

	handleCellClickChgBPBP: function(oEvent) {
		this._oTblPrtnrNmbrRowBPBP = oEvent.getParameter("rowIndex");
	},

	_handleValueHelpCloseBPBP: function(evt) {
		var oSelectedItem = evt.getParameter("selectedItem");
		if (oSelectedItem) {
			var oPrtnrNmbr = oSelectedItem.getTitle();
			var oPrtnrName = oSelectedItem.getDescription();
			var oTable = this.getView().byId("FormChange354BP");
			var oModel = oTable.getModel();
			var modelData = oModel.getData();
			var aTable = [];

			for (var i = 0; i < modelData.modelData.length; i++) {
				var value = modelData.modelData[i];
				aTable.push(value);
			}
			aTable[this._oTblPrtnrNmbrRowBPBP].ParnrNew = oPrtnrNmbr;
			aTable[this._oTblPrtnrNmbrRowBPBP].Name1 = oPrtnrName;
			//aTable[this._oTblPrtnrNmbrRowBPBP].Addrln = oPrtnrName;
			if (aTable[this._oTblPrtnrNmbrRowBPBP].Update !== "I") {
				aTable[this._oTblPrtnrNmbrRowBPBP].Update = "U";
			}
			oModel.setData({
				modelData: aTable
			});
		}
	},

	handleCellClickChgBFBP: function(oEvent) {
		this._oTblPrtnrNmbrRowBFBP = oEvent.getParameter("rowIndex");
	},

	_handleValueHelpCloseBFBP: function(evt) {
		var oSelectedItem = evt.getParameter("selectedItem");
		if (oSelectedItem) {
			var oPrtnrNmbr = oSelectedItem.getTitle();
			var oPrtnrName = oSelectedItem.getDescription();
			var oTable = this.getView().byId("FormChange354BF1");
			var oModel = oTable.getModel();
			var modelData = oModel.getData();
			var aTable = [];

			for (var i = 0; i < modelData.modelData.length; i++) {
				var value = modelData.modelData[i];
				aTable.push(value);
			}

			aTable[this._oTblPrtnrNmbrRowBFBP].Payer_new = oPrtnrNmbr;
			aTable[this._oTblPrtnrNmbrRowBFBP].Name1 = oPrtnrName;
			if (aTable[this._oTblPrtnrNmbrRowBFBP].Update !== "I") {
				aTable[this._oTblPrtnrNmbrRowBFBP].Update = "U";
			}
			oModel.setData({
				modelData: aTable
			});
		}
	},
	handleValueChgBFBP: function() {
		var oTable = this.getView().byId("FormChange354BF1");
		var oModel = oTable.getModel();
		var modelData = oModel.getData();
		var aTable = [];
		for (var i = 0; i < modelData.modelData.length; i++) {
			var value = modelData.modelData[i];
			aTable.push(value);
		}
		if (aTable[this._oTblPrtnrNmbrRowBFBP].Update !== "I") {
			aTable[this._oTblPrtnrNmbrRowBFBP].Update = "U";
		}
		oModel.setData({
			modelData: aTable
		});
	},
	handleValueHelpSingle: function(oEvent, sFieldName, sFrgmntName) {
		var sInputValue = oEvent.getSource().getValue();
		this.inputId = sFrgmntName;
		if (sFrgmntName === "ChgMIMR" || sFrgmntName === "ChgMIGB") {
			/*if (sInputValue) {
				sInputValue = sInputValue.toUpperCase();
			}*/
		}
		// create a filter for the binding
		var oFilter, aFilter = [];
		oFilter = new sap.ui.model.Filter(sFieldName, sap.ui.model.FilterOperator.Contains, sInputValue);
		aFilter.push(oFilter);

		// create value help dialog
		this._valueHelpDialog = sap.ui.xmlfragment("Matters_NRF.fragments.change.dialogSearch." + sFrgmntName, this);
		this.getView().addDependent(this._valueHelpDialog);
		this._valueHelpDialog.getBinding("items").filter(aFilter);

		// open value help dialog filtered by the input value
		this._valueHelpDialog.open(sInputValue);
	},

	handleValueHelpSingleMIGB: function(oEvent, sFieldName, sFrgmntName) {
		var sInputValue = oEvent.getSource().getValue();
		this.inputId = sFrgmntName;
		/*if (sInputValue) {
			sInputValue = sInputValue.toUpperCase();
		}*/
		// create a filter for the binding
		var oView = this.getView();
		var oPspid = oView.byId("detailHeader").getNumber();

		var oFilter, aFilter = [];
		oFilter = new sap.ui.model.Filter(sFieldName, sap.ui.model.FilterOperator.Contains, sInputValue);
		aFilter.push(oFilter);
		oFilter = new sap.ui.model.Filter("Pspid", sap.ui.model.FilterOperator.EQ, oPspid);
		aFilter.push(oFilter);

		// create value help dialog
		this._valueHelpDialog = sap.ui.xmlfragment("Matters_NRF.fragments.change.dialogSearch." + sFrgmntName, this);
		this.getView().addDependent(this._valueHelpDialog);
		this._valueHelpDialog.getBinding("items").filter(aFilter);

		// open value help dialog filtered by the input value
		this._valueHelpDialog.open(sInputValue);
	},

	handleValueHelp: function(oEvent, sFieldName1, sFieldName2, sFrgmntName) {
			var sInputValue = oEvent.getSource().getValue();
			this.inputId = sFrgmntName;
			// create value help dialog
			//if (!this._valueHelpDialog) {
			this._valueHelpDialog = sap.ui.xmlfragment("Matters_NRF.fragments.change.dialogSearch." + sFrgmntName, this);
			this.getView().addDependent(this._valueHelpDialog);
			//}
			// create a filter for the binding
			var aFilter = [];
			var oFilter;

			//if (this.oDesc === undefined) {
			if (sFrgmntName === "ChgMIMC") {
				this.oDesc = this.getView().byId("ChgMIMT").getSelectedKey();
			} else {
				this.oDesc = this.getView().byId(sFrgmntName).getValue();
			}

			//}
			oFilter = new sap.ui.model.Filter(sFieldName1, sap.ui.model.FilterOperator.EQ, this.oDesc);
			aFilter.push(oFilter);
			oFilter = new sap.ui.model.Filter(sFieldName2, sap.ui.model.FilterOperator.Contains, sInputValue);
			aFilter.push(oFilter);
			this._valueHelpDialog.getBinding("items").filter(aFilter);

			// open value help dialog filtered by the input value
			this._valueHelpDialog.open(sInputValue);
		}
		/*
			handleSuggestChgMIMCSel: function(oEvent) {
				var oInputId = "ChgMIMC";
				this.handleSuggestSel(oEvent, oInputId);
			},
			handleSuggestChgMILPGSel: function(oEvent) {
				var oInputId = "ChgMILPG";
				this.handleSuggestSel(oEvent, oInputId);
			},
			handleSuggestChgMIAOLSel: function(oEvent) {
				var oInputId = "ChgMIAOL";
				this.handleSuggestSel(oEvent, oInputId);
			},
			handleSuggestChgMIMPGSel: function(oEvent) {
				var oInputId = "ChgMIMPG";
				this.handleSuggestSel(oEvent, oInputId);
			},

			handleSuggestChgBDETSel: function(oEvent) {
				var oInputId = "ChgBDET";
				this.handleSuggestSel(oEvent, oInputId);
			},
			handleSuggestChgBDECSSel: function(oEvent) {
				var oInputId = "ChgBDECS";
				this.handleSuggestSel(oEvent, oInputId);
			},
			handleSuggestChgBDFFACSSel: function(oEvent) {
				var oInputId = "ChgBDFFACS";
				this.handleSuggestSel(oEvent, oInputId);
			},
			handleSuggestChgBDBTSel: function(oEvent) {
				var oInputId = "ChgBDBT";
				this.handleSuggestSel(oEvent, oInputId);
			},
			handleSuggestChgBDBFSel: function(oEvent) {
				var oInputId = "ChgBDBF";
				this.handleSuggestSel(oEvent, oInputId);
			},
			handleSuggestChgBDBMSel: function(oEvent) {
				var oInputId = "ChgBDBM";
				this.handleSuggestSel(oEvent, oInputId);
			},
			handleSuggestChgBDBCSel: function(oEvent) {
				var oInputId = "ChgBDBC";
				this.handleSuggestSel(oEvent, oInputId);
			},
			handleSuggestChgBDTSSel: function(oEvent) {
				var oInputId = "ChgBDTS";
				this.handleSuggestSel(oEvent, oInputId);
			},
			handleSuggestChgBDTJSel: function(oEvent) {
				var oInputId = "ChgBDTJ";
				this.handleSuggestSel(oEvent, oInputId);
			},
			handleSuggestChgMIGBSel: function(oEvent) {
				var oInputId = "ChgMIGB";
				this.handleSuggestSel(oEvent, oInputId);
			},
			handleSuggestChgBDTCSSel: function(oEvent) {
				var oInputId = "ChgBDTCS";
				this.handleSuggestSel(oEvent, oInputId);
			},
			handleSuggestChgBDACSSel: function(oEvent) {
				var oInputId = "ChgBDACS";
				this.handleSuggestSel(oEvent, oInputId);
			},

			handleSuggestChgBFDBSel: function(oEvent) {
				var oInputId = "ChgBFDB";
				this.handleSuggestSel(oEvent, oInputId);
			},

			handleSuggestChgODBLSel: function(oEvent) {
				var oInputId = "ChgODBL";
				this.handleSuggestSel(oEvent, oInputId);
			},
			handleSuggestChgODIVSel: function(oEvent) {
				var oInputId = "ChgODIV";
				this.handleSuggestSel(oEvent, oInputId);
			},
			handleSuggestChgODDBFSel: function(oEvent) {
				var oInputId = "ChgODDBF";
				this.handleSuggestSel(oEvent, oInputId);
			},
			handleSuggestChgODFBFSel: function(oEvent) {
				var oInputId = "ChgODFBF";
				this.handleSuggestSel(oEvent, oInputId);
			},
			handleSuggestChgODTDSel: function(oEvent) {
				var oInputId = "ChgODTD";
				this.handleSuggestSel(oEvent, oInputId);
			},
			handleSuggestChgODTKSel: function(oEvent) {
				var oInputId = "ChgODTK";
				this.handleSuggestSel(oEvent, oInputId);
			},
			handleSuggestChgODCDSel: function(oEvent) {
				var oInputId = "ChgODCD";
				this.handleSuggestSel(oEvent, oInputId);
			},

			handleSuggestSel: function(oEvent, oInputId) {
				var oSelKey = oEvent.getParameter("selectedItem").getKey();
				this.getView().byId(oInputId).setPlaceholder(oSelKey);
			}*/

});
/*sap.ui.core.mvc.Controller.extend("Matters_NRF.view.Detail", {

	onInit: function() {
		this.oInitialLoadFinishedDeferred = jQuery.Deferred();

		if (sap.ui.Device.system.phone) {
			//Do not wait for the master when in mobile phone resolution
			this.oInitialLoadFinishedDeferred.resolve();
		} else {
			this.getView().setBusy(true);
			var oEventBus = this.getEventBus();
			oEventBus.subscribe("Component", "MetadataFailed", this.onMetadataFailed, this);
			oEventBus.subscribe("Master", "InitialLoadFinished", this.onMasterLoaded, this);
		}

		this.getRouter().attachRouteMatched(this.onRouteMatched, this);
	},

	onMasterLoaded: function(sChannel, sEvent) {
		this.getView().setBusy(false);
		this.oInitialLoadFinishedDeferred.resolve();
	},

	onMetadataFailed: function() {
		this.getView().setBusy(false);
		this.oInitialLoadFinishedDeferred.resolve();
		this.showEmptyView();
	},

	onRouteMatched: function(oEvent) {
		var oParameters = oEvent.getParameters();

		jQuery.when(this.oInitialLoadFinishedDeferred).then(jQuery.proxy(function() {
			var oView = this.getView();

			// When navigating in the Detail page, update the binding context 
			if (oParameters.name !== "detail") {
				return;
			}

			var sEntityPath = "/" + oParameters.arguments.entity;
			this.bindView(sEntityPath);

			var oIconTabBar = oView.byId("idIconTabBar");
			oIconTabBar.getItems().forEach(function(oItem) {
				if (oItem.getKey() !== "selfInfo") {
					oItem.bindElement(oItem.getKey());
				}
			});

			// Specify the tab being focused
			var sTabKey = oParameters.arguments.tab;
			this.getEventBus().publish("Detail", "TabChanged", {
				sTabKey: sTabKey
			});

			if (oIconTabBar.getSelectedKey() !== sTabKey) {
				oIconTabBar.setSelectedKey(sTabKey);
			}
		}, this));

	},

	bindView: function(sEntityPath) {
		var oView = this.getView();
		oView.bindElement(sEntityPath);

		//Check if the data is already on the client
		if (!oView.getModel().getData(sEntityPath)) {

			// Check that the entity specified was found.
			oView.getElementBinding().attachEventOnce("dataReceived", jQuery.proxy(function() {
				var oData = oView.getModel().getData(sEntityPath);
				if (!oData) {
					this.showEmptyView();
					this.fireDetailNotFound();
				} else {
					this.fireDetailChanged(sEntityPath);
				}
			}, this));

		} else {
			this.fireDetailChanged(sEntityPath);
		}

	},

	showEmptyView: function() {
		this.getRouter().myNavToWithoutHash({
			currentView: this.getView(),
			targetViewName: "Matters_NRF.view.NotFound",
			targetViewType: "XML"
		});
	},

	fireDetailChanged: function(sEntityPath) {
		this.getEventBus().publish("Detail", "Changed", {
			sEntityPath: sEntityPath
		});
	},

	fireDetailNotFound: function() {
		this.getEventBus().publish("Detail", "NotFound");
	},

	onNavBack: function() {
		// This is only relevant when running on phone devices
		this.getRouter().myNavBack("main");
	},

	onDetailSelect: function(oEvent) {
		sap.ui.core.UIComponent.getRouterFor(this).navTo("detail", {
			entity: oEvent.getSource().getBindingContext().getPath().slice(1),
			tab: oEvent.getParameter("selectedKey")
		}, true);
	},

	openActionSheet: function() {

		if (!this._oActionSheet) {
			this._oActionSheet = new sap.m.ActionSheet({
				buttons: new sap.ushell.ui.footerbar.AddBookmarkButton()
			});
			this._oActionSheet.setShowCancelButton(true);
			this._oActionSheet.setPlacement(sap.m.PlacementType.Top);
		}

		this._oActionSheet.openBy(this.getView().byId("actionButton"));
	},

	getEventBus: function() {
		return sap.ui.getCore().getEventBus();
	},

	getRouter: function() {
		return sap.ui.core.UIComponent.getRouterFor(this);
	},

	onExit: function(oEvent) {
		var oEventBus = this.getEventBus();
		oEventBus.unsubscribe("Master", "InitialLoadFinished", this.onMasterLoaded, this);
		oEventBus.unsubscribe("Component", "MetadataFailed", this.onMetadataFailed, this);
		if (this._oActionSheet) {
			this._oActionSheet.destroy();
			this._oActionSheet = null;
		}
	}
});*/