jQuery.sap.declare("Matters_NRF.formatters.formatter");
jQuery.sap.require("sap.ui.core.format.DateFormat");

Matters_NRF.formatters.formatter = {

	myBoolean: function(sBool) {
		var bValue = false;
		if (sBool === "true") {
			bValue = true;
		}
		return bValue;
	},
	myBooleanV: function(sBool) {
		var bValue = false;
		if (sBool === "X") {
			bValue = true;
		}
		return bValue;
	},
	myBoolean1: function(sBool) {
		var bValue = false;
		if (sBool !== "SP" && sBool !== "PY") {
			bValue = true;
		}
		return bValue;
	},
	myDate: function(sBool) {
		if (sBool) {
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				style: "medium"
			});
			var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;
			var dateStr = dateFormat.format(new Date(sBool.getTime() + TZOffsetMs));
			return dateStr;
		}
	},
	myDate1: function(sBool) {
		if (sBool) {
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyy-MM-dd"
			});
			var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;
			var dateStr = dateFormat.format(new Date(sBool.getTime() + TZOffsetMs));
			return dateStr;
		}
	},
	myColor: function(sValue) {
		var bValue = "Success";
		switch (sValue) {
			case "OPEN":
				bValue = "Success";
				break;
			case "PEND":
				bValue = "Warning";
				break;
			case "DCLN":
				bValue = "Error";
				break;
			case "SCLS":
				bValue = "Success";
				break;
			case "HCLS":
				bValue = "Success";
				break;
			default:
		}
		return bValue;
	},
	
	myDecimal: function(sValue) {
		if (sValue) {
			sValue = sValue.replace(",", ".");
			return sValue;	
		}
		
	}

};