jQuery.sap.require("sap.ca.ui.model.format.DateFormat");
sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device"
], function(JSONModel, Device) {
	"use strict";

	return {

		/**
		 * Rounds the number unit value to 2 digits
		 * @public
		 * @param {string} sValue the number string to be rounded
		 * @returns {string} sValue with 2 digits rounded
		 */
		// numberUnit : function (sValue) {
		// 	if (!sValue) {
		// 		return "";
		// 	}
		// 	return parseFloat(sValue).toFixed(2);
		// }

		convertDate: function(sBool) {
			if (sBool) {
				var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					style: "medium"
				});
				
				// var sJsonDate = "/Date(1402166783294)/";
				var sNumber = sBool.replace(/[^0-9]+/g, '');
				var iNumber = sNumber * 1; //trick seventeen  
				var oDate = new Date(iNumber);
				var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;
				var dateStr = dateFormat.format(new Date(oDate.getTime() + TZOffsetMs));
				return dateStr;
			
			}
		},
		SeTStatusIcon: function(isError) {
			if (isError === "S")
				return "sap-icon://message-success";
			else if (isError === "E")
				return "sap-icon://message-error";

			else if (isError === "" || isError === null || isError === undefined)
				return "";

		},
		SeTStatusIconColor: function(isError) {

			if (isError === "S")
				return "Green";
			else if (isError === "E")
				return "Red";

		},
		SeTIconToolTip: function(isError) {
			if (isError === "S")
				return "Checkout Successfull";
			else if (isError === "E")
				return "Error";

			else if (isError === "" || isError === null || isError === undefined)
				return "";

		},
		toggleButtonColor: function(sComments) {
			if (sComments === null || sComments === undefined || sComments === "" || sComments === " ")
				return sap.m.ButtonType.Default;
			else return sap.m.ButtonType.Emphasized;
		}
		
		// convertCheckoutBy: function(sCheckoutby) {
		// 	if(sCheckoutby === "") return "";
		// 	else if(sCheckoutby !== "" || sCheckoutby !== "") return "X";
		// }

	};

});