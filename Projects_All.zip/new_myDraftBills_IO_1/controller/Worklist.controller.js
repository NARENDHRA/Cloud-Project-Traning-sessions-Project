sap.ui.define([
	"checkoutin/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"checkoutin/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function(BaseController, JSONModel, formatter, Filter, FilterOperator) {
	"use strict";

	return BaseController.extend("checkoutin.controller.Worklist", {

		formatter: formatter,
		onInit: function() {

			var oTable = this.byId("table");
			oTable.setBusyIndicatorDelay(1000);
			// oTable.addEventDelegate({
			// 	onAfterRendering: function(evt) {

			// 	}
			// }, this);

			// var oModel = new sap.ui.model.json.JSONModel();
			// oModel.attachRequestSent(null, function(evt){
			// 	evt.getSource().setEnableBusyIndicator(true);
			// }, this);
			this.updateRecords();
			// oModel.loadData("/sap/opu/odata/sap/ZPRS_DB_WF02_SRV/DBListSet");
			// oModel.attachRequestCompleted(oModel.getData(), this.setTableLimit);

			// oTable.setModel(oModel).bindRows("/d/results");
			// oTable.setBusy(false);

			var oView = this.getView();
			var oIconTabBar = oView.byId("idIconTabBar");
			oIconTabBar.setSelectedKey("AllDraftBill");
			this.sKey = "AllDraftBill";

			this.getView().byId("idCheckInButton").setVisible(false);
			this.getView().byId("idCheckOutButton").setVisible(false);
			this.getView().byId("idRefreshButton").setVisible(true);
			this.getView().byId("idAddComment").setVisible(false);
			this.getView().byId("idCheckOutBy").setVisible(false);
			this.getView().byId("idCheckOutAt").setVisible(false);
			this.getView().byId("idCheckInBy").setVisible(false);
			this.getView().byId("idCheckInAt").setVisible(false);
			this.getView().byId("idStatus").setVisible(false);
			this.getView().byId("table").setSelectionMode("None");

			var oViewModel,
				iOriginalBusyDelay;

			this._oTable = oTable;
			this._oTableSearchState = [];

			// Model used to manipulate control states
			oViewModel = new JSONModel({
				worklistTableTitle: this.getResourceBundle().getText("worklistTableTitle"),
				saveAsTileTitle: this.getResourceBundle().getText("worklistViewTitle"),
				shareOnJamTitle: this.getResourceBundle().getText("worklistViewTitle"),
				tableNoDataText: this.getResourceBundle().getText("tableNoDataText"),
				tableBusyDelay: 0,
				AllDraftBills: 0,
				CheckedOut: 0,
				ToBeCheckedout: 0,
				countAll: 0,
				Comments: "",
				NewComments: "",
				addCmtEnable: false,
				saveButton: false
			});
			this.setModel(oViewModel, "worklistView");

			/// comment Model 
			var comModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_BILL_EDIT_SRV/");
			this.setModel(comModel, "comModel");

			//////////////////////////// Filters
			// Create an object of filters
			this._mFilters = {
				"AllDraftBills": [],
				"CheckedOut": [new sap.ui.model.Filter("Checkoutby", "NE", " ")],
				"ToBeCheckedout": [new sap.ui.model.Filter("Checkoutby", "EQ", " ")],
				"DRAFTBILL": []
			};
			this.aFilter = [];
			this.currentFilters = [];
			this.aSearchFilter = []; // Filter for Search Field Value
			this.aSearchFilter1 = []; // Filter for ui table filteration and it has OR conditions
			///////////////////////////  Filters

			this.oCountModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_DB_WF02_SRV/");
			this.onUpdateFinished();
			/// For icontab count 
			var that = this;
			var oBinding = this.getView().byId("table").getBinding("rows");
			oBinding.attachChange(function() {
				if (that.sKey === "AllDraftBill") {
					that.getView().byId("idAllDraftsIconTab").setCount(oBinding.getLength());
				} else if (that.sKey === "CheckOut") {
					that.getView().byId("idCheckOutIconTab").setCount(oBinding.getLength());
				} else if (that.sKey === "ToBeCheckOut") {
					that.getView().byId("idTobeCheckedOutIconTab").setCount(oBinding.getLength());
				}
			}.bind(this));

		},

		updateRecords: function() {
			var oTable = this.byId("table");
			var oModel = new sap.ui.model.json.JSONModel();
			oModel.loadData("/sap/opu/odata/sap/ZPRS_DB_WF02_SRV/DBListSet");
			oModel.attachRequestCompleted(oModel.getData(), this.setTableLimit);

			oTable.setModel(oModel).bindRows("/d/results");

		},

		setTableLimit: function(evt) {
			if (evt.getSource().getData() &&
				evt.getSource().getData().d &&
				evt.getSource().getData().d.results &&
				evt.getSource().getData().d.results.length > 0) {
				evt.getSource().setSizeLimit(evt.getSource().getData().d.results.length);
			}
			// evt.getSource().setEnableBusyIndicator(false);
		},

		onQuickFilter: function(oEvent) {
			this.sKey = oEvent.getParameter("selectedKey");
			if (!this.sKey) {
				this.sKey = this.getView().byId("idIconTabBar").getSelectedKey();
			}
			var tbl = this.getView().byId("table");
			this.messageRest(tbl);
			this.setFilterTab(this.sKey);
		},

		setFilterTab: function(sKey) {
			var that = this;
			var oViewModel = this.getModel("worklistView");
			var tbl = this.getView().byId("table");
			var oBinding = tbl.getBinding('rows');
			var allFilter = [];
			switch (sKey) {
				case "AllDraftBill":
					tbl.setSelectionMode("None");
					oViewModel.setProperty('/addCmtEnable', false);
					allFilter = this.aFilter;
					if (this.aSearchFilter1 && this.aSearchFilter1.length > 0)
						allFilter = allFilter.concat(this.aSearchFilter1);
					if (this.currentFilters.length > 0) {
						$.each(this.currentFilters, function(i, o) {
							if (o.sPath && o.sPath !== "Tab")
								allFilter = allFilter.concat(o);
						});
					}
					// oBinding.filter(this.aFilter);
					oBinding.filter(allFilter);
					this.getView().byId("idCheckOutButton").setVisible(false);
					this.getView().byId("idRefreshButton").setVisible(true);
					this.getView().byId("idCheckInButton").setVisible(false);
					this.getView().byId("idAddComment").setVisible(false);
					this.getView().byId("idSaveButton").setVisible(false);

					this.getView().byId("idStatus").setVisible(false);
					this.getView().byId("idCheckOutBy").setVisible(false);
					this.getView().byId("idCheckOutAt").setVisible(false);
					this.getView().byId("idCheckInBy").setVisible(false);
					this.getView().byId("idCheckInAt").setVisible(false);

					break;
				case "CheckOut":
					oViewModel.setProperty('/addCmtEnable', true);
					// allFilter = this._mFilters.CheckedOut;
					// allFilter = [new sap.ui.model.Filter("Checkoutby", "NE", "")];
					allFilter = [new sap.ui.model.Filter("Tab", "EQ", "O")];
					// allFilter = allFilter.concat([new sap.ui.model.Filter("Pspid", "Contains", "90000102")]);
					allFilter = allFilter.concat(this.aFilter);
					if (this.aSearchFilter1 && this.aSearchFilter1.length > 0)
						allFilter = allFilter.concat(this.aSearchFilter1);
					// if (this.currentFilters.length > 0)
					// 	allFilter = allFilter.concat(this.currentFilters);
					if (this.currentFilters.length > 0) {
						$.each(this.currentFilters, function(i, o) {
							if (o.sPath && o.sPath !== "Tab")
								allFilter = allFilter.concat(o);
						});
					}
					oBinding.filter(allFilter);

					tbl.setSelectionMode("MultiToggle");
					this.getView().byId("idCheckInButton").setVisible(true);
					this.getView().byId("idRefreshButton").setVisible(true);
					this.getView().byId("idCheckOutButton").setVisible(false);
					this.getView().byId("idSaveButton").setVisible(true);

					this.getView().byId("idStatus").setVisible(true);
					this.getView().byId("idCheckOutBy").setVisible(true);
					this.getView().byId("idCheckOutAt").setVisible(true);
					this.getView().byId("idCheckInBy").setVisible(false);
					this.getView().byId("idCheckInAt").setVisible(false);
					this.getView().byId("idAddComment").setVisible(true);
					break;
				case "ToBeCheckOut":
					oViewModel.setProperty('/addCmtEnable', true);
					// allFilter = this._mFilters.ToBeCheckedout;
					// allFilter = [new sap.ui.model.Filter("Checkoutby", "EQ", "")];
					allFilter = [new sap.ui.model.Filter("Tab", "EQ", "I")];
					allFilter = allFilter.concat(this.aFilter);
					if (this.aSearchFilter1 && this.aSearchFilter1.length > 0)
						allFilter = allFilter.concat(this.aSearchFilter1);
					// if (this.currentFilters.length > 0)
					// 	allFilter = allFilter.concat(this.currentFilters);
					if (this.currentFilters.length > 0) {
						$.each(this.currentFilters, function(i, o) {
							if (o.sPath && o.sPath !== "Tab")
								allFilter = allFilter.concat(o);
						});
					}

					oBinding.filter(allFilter);
					tbl.setSelectionMode("MultiToggle");
					this.getView().byId("idCheckOutButton").setVisible(true);
					this.getView().byId("idRefreshButton").setVisible(true);
					this.getView().byId("idCheckInButton").setVisible(false);
					this.getView().byId("idSaveButton").setVisible(true);

					this.getView().byId("idStatus").setVisible(true);
					this.getView().byId("idCheckOutBy").setVisible(false);
					this.getView().byId("idCheckOutAt").setVisible(false);
					this.getView().byId("idCheckInBy").setVisible(true);
					this.getView().byId("idCheckInAt").setVisible(true);
					this.getView().byId("idAddComment").setVisible(true);
					break;
			}

			oViewModel.setProperty("/NewComments", "");

			// this.onUpdateFinished();

		},

		// checkout and checkin  functionaltiy

		onCheckInOut: function(evt) {
			var oTable = this.getView().byId("table");
			var oSelectedRows = oTable.getSelectedIndices();

			if (oSelectedRows.length === 0) {
				var sMsg;
				sMsg = "Select atleast one Draft Bill!!!";
				sap.m.MessageToast.show(sMsg);
				return;
			}

			this.getView().byId("table").setBusy(true);
			var cInOut = "";
			if (evt.getSource().getText() === this.getResourceBundle().getText("Check-In")) {
				cInOut = "CIN";
			}
			if (evt.getSource().getText() === this.getResourceBundle().getText("Check-Out")) {
				cInOut = "COUT";
			}
			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPRS_DB_WF02_SRV");
			var batchChanges = [];
			$.each(oTable.getSelectedIndices(), function(i, o) {
				var oRow = oTable.getRows("rowIndices")[o];
				var OData = oRow.getBindingContext().getObject();
				var oSelectedBillDraft = {
					Vbeln: OData.Vbeln,
					Action: cInOut,
					Newcomments: OData.Newcomments
				};
				batchChanges.push(oModel.createBatchOperation("/DBListSet", "POST", oSelectedBillDraft));
			});
			oModel.addBatchChangeOperations(batchChanges);
			//submit changes and refresh the table and display message&nbsp;\&nbsp;
			oModel.setUseBatch(true);
			var that = this;
			oModel.submitBatch(function(data) {
					var errorData = {};
					errorData.results = [];
					var receivedData = data.__batchResponses[0].__changeResponses;

					$.each(oTable.getSelectedIndices(), function(inx, o) {
						var oRow = oTable.getRows("rowIndices")[o];
						var sobj = oRow.getBindingContext().getObject();
						var a = receivedData.filter(function(obj) {
							return obj.data.Vbeln === sobj.Vbeln;
						});
						if (a.length === 1) {
							var ctx = oRow.getBindingContext();
							var isErrorPath = ctx.getPath() + "/Iserror";
							var MessagePath = ctx.getPath() + "/Message";
							var model = ctx.getModel();
							that.setCellProperty(oRow.getCells(), "status", {
								Message: a[0].data.Message,
								Iserror: a[0].data.Iserror
							});

						}
					});

					oTable.setBusy(false);
					// this.onUpdateFinished();
				},
				function(oErr) {
					oTable.setBusy(false);
				});
		},
		setCellProperty: function(cells, fieldName, resp) {
			$.each(cells, function(i, cell) {
				if (cell.data().fieldName && cell.data().fieldName === "status") {
					var iSource = formatter.SeTStatusIcon(resp.Iserror);
					var color = formatter.SeTStatusIconColor(resp.Iserror);
					cell.setSrc(iSource);
					cell.setColor(color);
					cell.setTooltip(resp.Message);
				}
			});
		},

		onUpdateFinished: function(evt) {
			// update the worklist's object counter after the table update

			var oViewModel = this.getModel("worklistView"),
				that = this;
			var oModel = this.oCountModel;

			var sKeyArray = ["CheckedOut", "ToBeCheckedout", "AllDraftBills"];
			var c1Filter = this._mFilters[sKeyArray[0]].length > 0 ? this._mFilters[sKeyArray[0]] : [];
			var c2Filter = this._mFilters[sKeyArray[1]].length > 0 ? this._mFilters[sKeyArray[1]] : [];
			var c3Filter = this._mFilters[sKeyArray[2]].length > 0 ? this._mFilters[sKeyArray[2]] : [];
			if ((this.aSearchFilter && this.aSearchFilter.length > 0) || (this.aFilter && this.aFilter.length > 0)) {
				if (this.aFilter.length > 0) {
					c1Filter = c1Filter.concat(this.aFilter);
					c2Filter = c2Filter.concat(this.aFilter);
					c3Filter = c3Filter.concat(this.aFilter);
				}
				if (this.aSearchFilter && this.aSearchFilter.length > 0) {
					c1Filter = c1Filter.concat(this.aSearchFilter);
					c2Filter = c2Filter.concat(this.aSearchFilter);
					c3Filter = c3Filter.concat(this.aSearchFilter);
				}
				c1Filter = [new Filter(c1Filter, true)];
				c2Filter = [new Filter(c2Filter, true)];
				c3Filter = [new Filter(c3Filter, true)];
			} else {
				c1Filter = this._mFilters[sKeyArray[0]];
				c2Filter = this._mFilters[sKeyArray[1]];
				c3Filter = this._mFilters[sKeyArray[2]];
			}

			// Poplating Table Filter
			if (this.currentFilters.length !== 0) {
				c1Filter = c1Filter.concat(this.currentFilters);
				c2Filter = c2Filter.concat(this.currentFilters);
				c3Filter = c3Filter.concat(this.currentFilters);
			}
			oModel.read("/DBListSet/$count", {
				success: function(oData, response) {
					oViewModel.setProperty("/" + sKeyArray[0], response.body);
					for (var i = 1; i < that._mFilters[sKeyArray[0]].length; i++) {
						that._mFilters[sKeyArray[0]].pop(i);
						that._mFilters[sKeyArray[1]].pop(i);
					}
				},
				filters: c1Filter
			});

			oModel.read("/DBListSet/$count", {
				success: function(oData, response) {
					oViewModel.setProperty("/" + sKeyArray[1], response.body);
					//	oTbl.setBusy(false);
					for (var i = 1; i < that._mFilters[sKeyArray[0]].length; i++) {
						that._mFilters[sKeyArray[0]].pop(i);
						that._mFilters[sKeyArray[1]].pop(i);
					}
				},
				filters: c2Filter
			});
			oModel.read("/DBListSet/$count", {
				success: function(oData, response) {
					oViewModel.setProperty("/" + sKeyArray[2], response.body);
					//	oTbl.setBusy(false);
					for (var i = 1; i < that._mFilters[sKeyArray[0]].length; i++) {
						that._mFilters[sKeyArray[0]].pop(i);
						that._mFilters[sKeyArray[1]].pop(i);
					}
				},
				filters: c3Filter
			});

		},

		onPress: function(oEvent) {
			var index = oEvent.getParameter("rowIndex");
			if (oEvent.getParameters("selectAll").selectAll && oEvent.getParameters("selectAll").selectAll === true) {
				for (var i = 0; i < oEvent.getSource().getRows().length; i++) {
					if (oEvent.getSource().getRows()[i].getCells()[16] && oEvent.getSource().getRows()[i].getCells()[16].getContent() &&
						oEvent.getSource().getRows()[i].getCells()[16].getContent()[1]) {
						oEvent.getSource().getRows()[i].getCells()[16].getContent()[1].setEnabled(true);
					}
				}
			} else if (!oEvent.getParameters("selectAll").selectAll && index === -1) {
				for (i = 0; i < oEvent.getSource().getRows().length; i++) {
					if (oEvent.getSource().getRows()[i].getCells()[16] && oEvent.getSource().getRows()[i].getCells()[16].getContent() &&
						oEvent.getSource().getRows()[i].getCells()[16].getContent()[1]) {
						oEvent.getSource().getRows()[i].getCells()[16].getContent()[1].setEnabled(false);
					}
				}
			} else if (index !== -1) {
				if (oEvent.getSource().getRows()[index].getCells()[16] && oEvent.getSource().getRows()[index].getCells()[16].getContent() &&
					oEvent.getSource().getRows()[index].getCells()[16].getContent()[1]) {
					if (oEvent.getSource().getRows()[index].getCells()[16].getContent()[1].getEnabled() === false) {
						oEvent.getSource().getRows()[index].getCells()[16].getContent()[1].setEnabled(true);
					} else {
						oEvent.getSource().getRows()[index].getCells()[16].getContent()[1].setEnabled(false);
					}
				}
			}
		},

		onNavBack: function() {
			history.go(-1);
		},

		onSearch: function(oEvent) {
			var oTableSearchState = [];
			var sQuery = oEvent.getParameter("query");
			this.aSearchFilter = [];
			// if (this.aFilter.length > 0) {
			// 	oTableSearchState = oTableSearchState.concat(this.aFilter);
			// }
			if (sQuery && sQuery.length > 0) {
				this.aSearchFilter = [new Filter("Pspid1", FilterOperator.Contains, sQuery)]; // filter for backend call and it contains pspid1 filter parameter
				var aORFilter = new sap.ui.model.Filter(
					[
						new sap.ui.model.Filter("Vbeln", sap.ui.model.FilterOperator.Contains, sQuery),
						new sap.ui.model.Filter("Pspid", sap.ui.model.FilterOperator.Contains, sQuery),
						new sap.ui.model.Filter("Bname", sap.ui.model.FilterOperator.Contains, sQuery)
					],
					false);
				this.aSearchFilter1 = []; // Filter for ui table filteration and it has OR conditions
				this.aSearchFilter1.push(aORFilter);
				if (oTableSearchState.length > 0) {
					oTableSearchState = oTableSearchState.concat(this.aSearchFilter1);
				} else {
					oTableSearchState = this.aSearchFilter1;
				}
				if(this.currentFilters.length === 0){
				if (this.sKey === "CheckOut") {
					oTableSearchState = oTableSearchState.concat([new sap.ui.model.Filter("Tab", "EQ", "O")]);
				}
				if (this.sKey === "ToBeCheckOut") {
					oTableSearchState = oTableSearchState.concat([new sap.ui.model.Filter("Tab", "EQ", "I")]);
				}
				if (this.sKey === "AllDraftBill") {
					oTableSearchState = oTableSearchState.concat(this._mFilters.AllDraftBills);
				}
				} else oTableSearchState = oTableSearchState.concat(this.currentFilters);
				this._applySearch(oTableSearchState);
			}
			if (oEvent.getParameters().clearButtonPressed) {
				// if (this.aFilter.length === 0) {
				if (this.currentFilters !== 0)
					oTableSearchState = oTableSearchState.concat(this.currentFilters);
				else {
					if (this.sKey === "CheckOut") {
						oTableSearchState = oTableSearchState.concat([new sap.ui.model.Filter("Tab", "EQ", "O")]);
					}
					if (this.sKey === "ToBeCheckOut") {
						oTableSearchState = oTableSearchState.concat([new sap.ui.model.Filter("Tab", "EQ", "I")]);
					}
					if (this.sKey === "AllDraftBill") {
						oTableSearchState = oTableSearchState.concat(this._mFilters.AllDraftBills);
					}
				}

				this._applySearch(oTableSearchState);
				this.aSearchFilter1 = [];
			}
		},

		_applySearch: function(oTableSearchState) {
			var oViewModel = this.getModel("worklistView");
			var tbl = this.getView().byId("table");
			tbl.getBinding("rows").filter(oTableSearchState);
			// changes the noDataText of the list in case there are no filter results
			if (oTableSearchState && oTableSearchState.length !== 0) {
				oViewModel.setProperty("/tableNoDataText", this.getResourceBundle().getText("worklistNoDataWithSearchText"));
			}
			// this.onUpdateFinished();
		},
		messageRest: function(tbl) {
			var that = this;
			$.each(tbl.getSelectedIndices(), function(i, o) {
				var oRow = tbl.getRows("rowIndices")[o];
				that.setCellProperty(oRow.getCells(), "status", {
					Message: "",
					Iserror: ""
				});

			});
			tbl.clearSelection();
		},
		onRefreshButtonpress: function(oEvt) {

			this.restControl();
			this.updateRecords();
			// Reset table data
			var clearFilter = [];
			var tbl = this.getView().byId("table");
			var oBinding = tbl.getBinding('rows');
			this.setFilterTab(this.sKey);

			// tbl.unbindRows();
			// this.reModel();
			// 	tbl.getModel().bindRows("/d/results");
			this.onUpdateFinished();

		},
		restControl: function() {
			this.aFilter = []; // Clear all Filters when refreshed
			this.aSearchFilter = [];
			this.aSearchFilter1 = []; // Clear table Filter
			var tbl = this.getView().byId("table");
			this.messageRest(tbl);
			this.byId("searchField").setValue("");
			// draft bill Status 
			this.byId("idDraftBillStatus").setFilterValue(null);

			// Draft bill 
			this.byId("idDraftBill").setFilterValue(null);

			// matter 
			this.byId("idMatter").setFilterValue(null);

			//Client Name
			this.byId("idClientName").setFilterValue(null);

			//Billing Office
			this.byId("idBillingOffice").setFilterValue(null);

			//Billing Partner
			this.byId("idBillingPartner").setFilterValue(null);

			// Group bill id
			this.byId("idGroupBillId").setFilterValue(null);
			// for icontab Count 
			this.byId("idAllDraftsIconTab").setCount(0);
			this.byId("idCheckOutIconTab").setCount(0);
			this.byId("idTobeCheckedOutIconTab").setCount(0);

			this.currentFilters = [];
			// this.reModel();
		},
		/// ON comment filed QickView 

		showQickView: function(oEvt) {
			var src = oEvt.getSource();
			var caller = src.data().caller;
			var fragPath = "checkoutin.fragments.Comment";
			var worklistModel = this.getView().getModel("worklistView");
			var worklistData = worklistModel.getData();
			worklistData.caller = caller;
			if (caller !== "multi") {
				var obj = src.getBindingContext().getObject();
				worklistData.NewComments = obj.Newcomments;
			} else {
				worklistData.NewComments = "";
			}
			worklistModel.setData(worklistData);
			worklistModel.refresh();
			if (!this.oQuick) {
				this.oQuick = sap.ui.xmlfragment(fragPath, this);
				this.getView().addDependent(this.oQuick);
			}
			this.oQuick.setBindingContext(src.getBindingContext());
			this.oQuick.openBy(oEvt.getSource());
		},
		//displayComment of quick view 

		disPlayComment: function(oEvt) {
			var src = oEvt.getSource();

			var fragPath = "checkoutin.fragments.DisplayComment";
			var worklistModel = this.getView().getModel("worklistView");
			var worklistData = worklistModel.getData();
			var obj = src.getBindingContext().getObject();
			worklistData.Comments = obj.Comments;

			worklistModel.setData(worklistData);
			worklistModel.refresh();
			if (!this.displayCmt) {
				this.displayCmt = sap.ui.xmlfragment(fragPath, this);
				this.getView().addDependent(this.displayCmt);
			}
			var comList = sap.ui.getCore().byId("commentsList");
			var binding = comList.getBinding("items");
			var filters = [];
			filters.push(new Filter("Area", FilterOperator.EQ, "W1"));
			filters.push(new Filter("Vbeln", FilterOperator.EQ, obj.Vbeln));
			binding.filter(filters);
			this.displayCmt.openBy(oEvt.getSource());
		},
		handlCommentClose: function(oEvt) {
			this.displayCmt.close();
		},
		handleCommentAdd: function(oEvent) {
			var tbl = this.getView().byId('table');
			var src = oEvent.getSource();
			var worklistModel = this.getView().getModel("worklistView");
			var worklistData = worklistModel.getData();
			if (worklistData.caller === "multi") {
				$.each(tbl.getSelectedContexts(), function(i, o) {
					var OData = o.getObject();
					OData.Newcomments = worklistData.NewComments;
				});
			} else {
				var obj = src.getBindingContext().getObject();
				obj.Newcomments = worklistData.NewComments;
			}
			this.oQuick.close();

		},

		// Switch to My WorkList Appilcation
		switchApp: function(oEvent) {
			var oCrossAppNav = sap.ushell.Container.getService("CrossApplicationNavigation");
			oCrossAppNav.toExternal({
				target: {
					semanticObject: "ZPRS_MYWORKLIST",
					action: "display"
				}
			});
		},
		// navigation to handle press link on draft bill Status.
		handleAuditTrailReport: function(oEvent) {
			var oSelItem = oEvent.getSource();
			var oContext = oSelItem.getBindingContext();
			var oObj = oContext.getObject();
			var oHref = "#ZPRS_DB_WF05-display&/" + oObj.Vbeln;
			oEvent.oSource.setHref(oHref);

		},
		// navigation to bill edit application 
		onPressBill: function(oEvent) {
			var oSelItem = oEvent.getSource();
			var oContext = oSelItem.getBindingContext();
			var oObj = oContext.getObject(),
				billerUrl;

			billerUrl = "/sap/bc/ui5_ui5/sap/ZPRS_BILL_EDIT/index.html#/main/" + oObj.Vbeln;
			sap.m.URLHelper.redirect(billerUrl, true);

		},

		applyMenuFilter: function(evt) {
			// if (this.aSearchFilter1 && this.aSearchFilter1.length === 1) {
			// 	this.byId("idSearchFieldFilterColumn").setFiltered(true);
			// 	this.byId("idSearchFieldFilterColumn").setFilterOperator(this.aSearchFilter[0].sOperator);
			// 	this.byId("idSearchFieldFilterColumn").setFilterProperty(this.aSearchFilter[0].sPath);
			// 	this.byId("idSearchFieldFilterColumn").setFilterValue(this.aSearchFilter[0].oValue1);
			// } else {
			// 	this.byId("idSearchFieldFilterColumn").setFiltered(false);
			// 	this.byId("idSearchFieldFilterColumn").setFilterValue(null);
			// }
			// if(this.aSearchFilter1 && this.aSearchFilter1.length === 1){
			// 	$.each(this.aSearchFilter1[0].aFilters, function(i, o) {
			// 		o[i].
			// 	});
			// }

			var oTableIconTabFilter = [];
			if (this.sKey === "CheckOut") {
				// oTableIconTabFilter = [new sap.ui.model.Filter("Checkoutby", "GT", "000000000000")];
				oTableIconTabFilter = [new sap.ui.model.Filter("Tab", "EQ", "O")];
			} else if (this.sKey === "ToBeCheckOut") {
				// oTableIconTabFilter = [new sap.ui.model.Filter("Checkoutby", "EQ", "")];
				oTableIconTabFilter = [new sap.ui.model.Filter("Tab", "EQ", "I")];
			}
			// else if (this.sKey === "AllDraftBill") {
			// 	oTableIconTabFilter = this._mFilters.AllDraftBills;
			// }

			// if (oTableIconTabFilter.length === 1) {
			// 	this.byId("idCheckOutBy").setFiltered(true);
			// 	this.byId("idCheckOutBy").setFilterOperator(oTableIconTabFilter[0].sOperator);
			// 	this.byId("idCheckOutBy").setFilterProperty(oTableIconTabFilter[0].sPath);
			// 	var sValue = " ";
			// 	this.byId("idCheckOutBy").setFilterValue(sValue);
			// } else {
			// 	this.byId("idCheckOutBy").setFiltered(false);
			// 	this.byId("idCheckOutBy").setFilterValue(null);
			// }

			var sValue;
			if (oTableIconTabFilter.length === 1) {
				this.byId("idCheckoutbyFilterColumn").setFiltered(true);
				this.byId("idCheckoutbyFilterColumn").setFilterOperator(oTableIconTabFilter[0].sOperator);
				this.byId("idCheckoutbyFilterColumn").setFilterProperty(oTableIconTabFilter[0].sPath);
				// if(this.sKey === "ToBeCheckOut")
				// 	sValue = "";
				// else if(this.sKey === "CheckOut")
				sValue = oTableIconTabFilter[0].oValue1;
				this.byId("idCheckoutbyFilterColumn").setFilterValue(sValue);
			} else {
				this.byId("idCheckoutbyFilterColumn").setFiltered(false);
				this.byId("idCheckoutbyFilterColumn").setFilterValue(null);
			}

			this.currentFilters = [];
			var currentFilters1 = [];
			if (evt.getSource().getBinding() && evt.getSource().getBinding().aFilters && evt.getSource().getBinding().aFilters.length !== 0) {
				currentFilters1 = evt.getSource().getBinding().aFilters;
			}
			var ParFilter = new Filter(evt.getParameters().column.mProperties.filterProperty,
				sap.ui.model.FilterOperator.Contains,
				evt.getParameters().value);
			var that = this;
			// currentFilters1 = currentFilters1.concat(ParFilter);
			$.each(currentFilters1, function(i, o) {
				if (!o.aFilters) {
					if (o.sPath !== ParFilter.sPath)
						if (o.sPath !== oTableIconTabFilter[0].sPath)
							that.currentFilters.push(o);
				}
			});
			if (ParFilter.length !== 0)
				this.currentFilters.push(ParFilter);
			if (oTableIconTabFilter.length === 1)
				this.currentFilters.push(oTableIconTabFilter[0]);
			// this.onUpdateFinished();
			// this.setFilterTab(this.sKey);
			// this.byId("table").detachFilter(this.applyMenuFilter);
			// evt.getSource().getBinding().aFilters = [];
			// evt.getParameters().column = undefined;
			// evt.getParameters().value = undefined;
		}
	});
});