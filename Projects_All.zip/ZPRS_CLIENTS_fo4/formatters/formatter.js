jQuery.sap.declare("MyClients.formatters.formatter");
jQuery.sap.require("sap.ui.core.format.DateFormat");

MyClients.formatters.formatter = {
    
	myBoolean: function(sBool) {
		var bValue = false;
		if (sBool === "X") {
			bValue = true;
		}
		return bValue;
	},

	myBooleanAC: function(sBool) {
		var bValue = true;
		if (sBool === "N") {
			bValue = false;
		}
		return bValue;
	},

	myBoolean1: function(sBool) {
		var bValue = false;
		if (sBool !== "SP") {
			bValue = true;
		}
		return bValue;
	},

	myDate: function(sBool) {
		if (sBool) {
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				style: "medium"
			});
			var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;
			var dateStr = dateFormat.format(new Date(sBool.getTime() + TZOffsetMs));
			return dateStr;
		}
	},

	myDate1: function(sBool) {
		if (sBool) {
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyy-MM-dd"
			});
			var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;
			var dateStr = dateFormat.format(new Date(sBool.getTime() + TZOffsetMs));
			return dateStr;
		}
	},
    
	myVisibleGD: function(sBool) {
		var bValue = true;
		if (sBool === "S") {
			bValue = false;
		}
		return bValue;
	},

	myVisiblePhEm: function(sBool) {
		var bValue = true;
		if (sBool === "") {
			bValue = false;
		}
		return bValue;
	}
	
};