jQuery.sap.require("sap.m.MessageBox");
jQuery.sap.require("MyClients.formatters.formatter");
jQuery.sap.require("sap.ui.core.format.DateFormat");
sap.ui.core.mvc.Controller.extend("MyClients.view.Detail", {

  _aDelTableBC: [],
  _aDelTableWD: [],
  _aDelTablePD: [],
  _aDelTableCPD: [],
  _aGlobalBP: [],

  _oKunnr: null,
  _oVkorg: null,
  _oGlblFlag: null,

  _oTblPrtnrNmbrRowBC: null,
  _oTblPrtnrNmbrRowBPBP: null,
  _oTblPrtnrNmbrRowWDTY: null,
  _oTblPrtnrNmbrRowWDCD: null,
  _oTblPrtnrNmbrWDCDWT: null,
  _oTblPrtnrNmbrRowCPCG: null,
  _oTblPrtnrNmbrRowCPCS: null,
  _oTblPrtnrNmbrCPCS: null,
  _oTblPrtnrNmbrCPCS1: null,
  _oTblPrtnrNmbrRowCPCGD: null,
  _oTblPrtnrNmbrRowCPCSD: null,

  _sFltr: null,
  _sEntityPath: null,

  onInit: function() {
    this.oInitialLoadFinishedDeferred = jQuery.Deferred();

    if (sap.ui.Device.system.phone) {
      //Do not wait for the master when in mobile phone resolution
      this.oInitialLoadFinishedDeferred.resolve();
    } else {
      this.getView().setBusy(true);
      var oEventBus = this.getEventBus();
      oEventBus.subscribe("Component", "MetadataFailed", this.onMetadataFailed, this);
      oEventBus.subscribe("Master", "InitialLoadFinished", this.onMasterLoaded, this);
    }

    this.getRouter().attachRouteMatched(this.onRouteMatched, this);
  },

  onMasterLoaded: function(sChannel, sEvent) {
    this.getView().setBusy(false);
    this.oInitialLoadFinishedDeferred.resolve();
  },

  onMetadataFailed: function() {
    this.getView().setBusy(false);
    this.oInitialLoadFinishedDeferred.resolve();
    this.showEmptyView();
  },

  handlePhonePress: function(oEvent) {
    sap.m.URLHelper.triggerTel(oEvent.oSource.getText());
  },

  handleEmailPress: function(oEvent) {
    sap.m.URLHelper.triggerEmail(oEvent.oSource.getText());
  },
  	handlepress: function() {

			var saveHeaderData = {
				"Vbeln": "0070015023",
				"Comments": "Testing"
			};
			

	var saveHeaderData1 = {
				"Vbeln": "0070015024",
				"Comments": "Testing1"
			};
			// var that = this;
			var oView = this.getView();
			var oModel = oView.getModel("oF41");
			var saveParam = "/CheckoutSet";
			var batchChanges = [];
			batchChanges.push(oModel.createBatchOperation(saveParam, "POST", saveHeaderData));
				batchChanges.push(oModel.createBatchOperation(saveParam, "POST", saveHeaderData1));
			oModel.addBatchChangeOperations(batchChanges);
		
					oModel.setHeaders({
				"If-Match": "value1"
			});
			oModel.submitBatch(function(oSuccess) {
				var a = 10;
			}, function(oError) {
				var a = 10;
			});

		},

  onRouteMatched: function(oEvent) {
    var oParameters = oEvent.getParameters();

    jQuery.when(this.oInitialLoadFinishedDeferred).then(jQuery.proxy(function() {
      var oView = this.getView();

      // When navigating in the Detail page, update the binding context 
      if (oParameters.name !== "detail") {
        return;
      }

      //var oShell = sap.ui.getCore().byId("clientsShell");
      oView.setBusy(true);
      var sEntityPath = "/" + oParameters.arguments.entity;
      this._sEntityPath = sEntityPath;
      this.bind();
      var oCPTab = oView.byId("CP");
      var oCSTab = oView.byId("CS");
      var oAddBtn = oView.byId("FormChange354CPDAddBtn");
      var oDelBtn = oView.byId("FormChange354CPDDelBtn");
      oCPTab.setVisible(false);
      oCSTab.setVisible(false);
      oAddBtn.setEnabled(false);
      oDelBtn.setEnabled(false);
      //this._oKunnr = oView.byId("detailHeader").getNumber();
      this._oKunnr = oView.byId("detailHeader").getText();

      var oIconTabBar = oView.byId("idIconTabBar");
      oIconTabBar.getItems().forEach(function(oItem) {
        if (oItem.getKey() !== "selfInfo") {
          oItem.bindElement(oItem.getKey());
        }
      });

      // Specify the tab being focused
      var sTabKey = oParameters.arguments.tab;
      this.getEventBus().publish("Detail", "TabChanged", {
        sTabKey: sTabKey
      });

      if (oIconTabBar.getSelectedKey() !== sTabKey) {
        oIconTabBar.setSelectedKey(sTabKey);
      }
    }, this));

  },

  refreshModel: function() {
    var oView = this.getView();
    var oMainModel = oView.getModel();
    oMainModel.refresh(true);
  },
  onRouteMatchedSuccess: function() {
    this.refreshModel();
    var oView = this.getView();
    var oIconTabBar = oView.byId("idIconTabBar");
    oIconTabBar.setSelectedKey("MYCLIENTSToClientGData");
    this.bind();
  },

  bind: function() {
    this.bindView(this._sEntityPath);
    this.bindDispTable(this._sEntityPath);
  },

  _setValueStateGD: function(oView) {
    var inputs = ["ChgGDGU", "ChgGDDN"];
    this._setValueState(oView, inputs);
  },

  _setValueStateCD: function(oView) {
    var inputs = ["ChgCDAS", "ChgCDDP", "ChgCDPT"];
    this._setValueState(oView, inputs);
  },

  _setValueState: function(oView, inputs) {
    var oState = "None";
    for (var s = 0; s < inputs.length; s++) {
      var value = inputs[s];
      var field = oView.byId(value);
      value = field.getValue().length;
      if (value !== 0) {
        oState = "None";
      } else {
        oState = "Error";
      }
      field.setValueState(oState);
    }
    oView.setBusy(false);
  },

  bindView: function(sEntityPath) {
    var that = this;
    var oView = this.getView();
    oView.setBusy(true);
    oView.bindElement(sEntityPath);

    var oUdmbp = oView.byId("ChgGDUD");
    var oCSTab = oView.byId("CS");

    setTimeout(function() {
      oUdmbp = oUdmbp.getText();
      if (oUdmbp === "X") {
        oCSTab.setVisible(true);
      } else {
        oCSTab.setVisible(false);
      }
    }, 2000);
    setTimeout(function() {
      that._setValueStateGD(oView);
    }, 3000);
    //Check if the data is already on the client
    if (!oView.getModel().getData(sEntityPath)) {

      // Check that the entity specified was found.
      oView.getElementBinding().attachEventOnce("dataReceived", jQuery.proxy(function() {
        var oData = oView.getModel().getData(sEntityPath);
        if (!oData) {
          this.showEmptyView();
          this.fireDetailNotFound();
        } else {
          this.fireDetailChanged(sEntityPath);
        }
      }, this));

    } else {
      this.fireDetailChanged(sEntityPath);
    }
  },

  bindDispTable: function(sEntityPath) {
    var oView = this.getView();
    var oMainModel = oView.getModel();
    this.bindTableBC(oView, oMainModel, sEntityPath);
    this.bindSelectLE(oView, oMainModel, sEntityPath);
    this.bindCheckbox(oView, oMainModel, sEntityPath);
  },

  bindTableBC: function(oView, oMainModel, sEntityPath) {

    var ompDispTbl = oView.byId("FormDisplay354BC");
    var ompChngTbl = oView.byId("FormChange354BC");

    var oPath = sEntityPath + "/MYCLIENTSToClientBCon";
    oMainModel.read(oPath, null, null, null, function(data, request) {
      var aTableData = [];
      if (data.results[0].Kunnr !== "X") {
        for (var k = 0; k < data.results.length; k++) {
          var oRow = {
            Kunnr: data.results[k].Kunnr,
            Parnr: data.results[k].Parnr,
            Namev: data.results[k].Namev,
            Name1: data.results[k].Name1,
            Phone: data.results[k].Phone,
            Fax: data.results[k].Fax,
            Email: data.results[k].Email,
            Department: data.results[k].Department,
            Msgfn: ""
          };
          aTableData.push(oRow);
        }
      }
      //Create a model and bind the table rows to this model
      var oModel = new sap.ui.model.json.JSONModel();
      oModel.setData({
        modelData: aTableData
      });
      ompDispTbl.setModel(oModel);
      ompDispTbl.bindRows("/modelData");
      ompChngTbl.setModel(oModel);
      ompChngTbl.bindRows("/modelData");
    }, function(oError) {});

  },

  bindSelectLE: function(oView, oMainModel, sEntityPath) {
    var oSelectLE = oView.byId("ChgLELE");
    var oPath = sEntityPath + "/MYCLIENTSToClientLEntity";
    oSelectLE.bindAggregation("items", oPath, new sap.ui.core.Item({
      text: "{Vkorgt}",
      key: "{Vkorg}-{Udmbp}"
    }), true);

    var that = this;
    setTimeout(function() {
      oSelectLE.setSelectedIndex(0);
      oView.setBusy(false);
      that.refreshTable();
    }, 2000);
  },

  bindCheckbox: function(oView, oMainModel, sEntityPath) {
    var oPath = sEntityPath + "/MYCLIENTSToClientStatus";
    var ompDispTbl = oView.byId("FormDisplay354ST");
    ompDispTbl.bindElement(oPath);
    var ompChngTbl = oView.byId("FormChange354ST");
    ompChngTbl.bindElement(oPath);
  },

  refreshTable: function(oEvent) {
    var oView = this.getView();
    //this.bindTableBPRefresh(oView);
    //this.bindTableWtaxRefresh(oView);
    this.bindTableCdataRefresh(oView);
    //this.bindTableCPdataRefresh(oView);
    //this.bindTableCProfRefresh(oView);
    //this.bindTableCDProfRefresh(oView);
    this.bindTableRefresh(oView);
    var oIconTabBar = oView.byId("idIconTabBarLE");
    oIconTabBar.setSelectedKey("ClientLEntityToClientBP");
  },

  bindTableBPRefresh: function(oView) {
    var ompDispTbl = oView.byId("FormDisplay354PD");
    var ompChngTbl = oView.byId("FormChange354PD");
    var aTableData = [];
    var oModel = new sap.ui.model.json.JSONModel();
    oModel.setData({
      modelData: aTableData
    });
    ompDispTbl.setModel(oModel);
    ompDispTbl.bindRows("/modelData");
    ompChngTbl.setModel(oModel);
    ompChngTbl.bindRows("/modelData");
  },

  bindTableWtaxRefresh: function(oView) {
    var ompDispTbl = oView.byId("FormDisplay354WD");
    var ompChngTbl = oView.byId("FormChange354WD");
    var aTableData = [];
    var oModel = new sap.ui.model.json.JSONModel();
    oModel.setData({
      modelData: aTableData
    });
    ompDispTbl.setModel(oModel);
    ompDispTbl.bindRows("/modelData");
    ompChngTbl.setModel(oModel);
    ompChngTbl.bindRows("/modelData");
  },

  bindTableCdataRefresh: function(oView) {
    var ompDispTbl = oView.byId("FormDisplay354CD");
    if (ompDispTbl) {
      ompDispTbl.unbindElement();
    }
    var ompChngTbl = oView.byId("FormChange354CD");
    if (ompChngTbl) {
      ompChngTbl.unbindElement();
    }

    // Reset field values
    var aReset = ["ChgCDAS", "ChgCDDP", "ChgCDDB", "ChgCDDR", "ChgCDLD", "ChgCDPT", "ChgCDDL",
      "ChgCDPG", "ChgCDTG", "ChgCDPM", "ChgCDCU", "ChgCDTN"
    ];
    for (var i = 0; i < aReset.length; i++) {
      oView.byId(aReset[i]).setValue("");
    }
  },

  bindTableCPdataRefresh: function(oView) {
    var ompDispTbl = oView.byId("FormDisplay354ST");
    if (ompDispTbl) {
      ompDispTbl.unbindElement();
    }
    var ompChngTbl = oView.byId("FormChange354ST");
    if (ompChngTbl) {
      ompChngTbl.unbindElement();
    }

    // Reset field values
    var aReset = ["ChgCPCB", "ChgCPNR"];
    for (var i = 0; i < aReset.length; i++) {
      oView.byId(aReset[i]).setSelected(false);
    }
  },

  bindTableCProfRefresh: function(oView) {
    var ompDispTbl = oView.byId("FormDisplay354CP");
    var ompChngTbl = oView.byId("FormChange354CP");
    var aTableData = [];
    var oModel = new sap.ui.model.json.JSONModel();
    oModel.setData({
      modelData: aTableData
    });
    ompDispTbl.setModel(oModel);
    ompDispTbl.bindRows("/modelData");
    ompChngTbl.setModel(oModel);
    ompChngTbl.bindRows("/modelData");
  },

  bindTableCDProfRefresh: function(oView) {
    var ompDispTbl = oView.byId("FormDisplay354CPD");
    var ompChngTbl = oView.byId("FormChange354CPD");
    var aTableData = [];
    var oModel = new sap.ui.model.json.JSONModel();
    oModel.setData({
      modelData: aTableData
    });
    ompDispTbl.setModel(oModel);
    ompDispTbl.bindRows("/modelData");
    ompChngTbl.setModel(oModel);
    ompChngTbl.bindRows("/modelData");

    var aReset = ["FormDisplay354CPD", "FormChange354CPD"];
    for (var i = 0; i < aReset.length; i++) {
      var oTable = oView.byId(aReset[i]);
      oTable.setModel(oModel);
      oTable.bindRows("/modelData");
    }
  },

  bindTableRefresh: function(oView) {
    var aTableData = [];
    var oModel = new sap.ui.model.json.JSONModel();
    oModel.setData({
      modelData: aTableData
    });
    var aReset = ["FormDisplay354PD", "FormChange354PD", "FormDisplay354WD", "FormChange354WD",
      "FormDisplay354CP", "FormChange354CP", "FormDisplay354CPD", "FormChange354CPD"
    ];
    for (var i = 0; i < aReset.length; i++) {
      var oTable = oView.byId(aReset[i]);
      oTable.setModel(oModel);
      oTable.bindRows("/modelData");
    }
  },

  handleSelectLE: function(oEvent) {
    var oVkorg = oEvent.getSource().getSelectedKey();
    var oView = this.getView();
    oView.setBusy(true);
    var oUdmbp = oVkorg.substr(5, 1);
    oVkorg = oVkorg.substr(0, 4);
    this._oVkorg = oVkorg;
    var oCPTab = oView.byId("CP");
    sap.m.MessageToast.show("Loading Partner Details...", {
      duration: 1000,
      width: "18em"
    });
    setTimeout(function() {
      sap.m.MessageToast.show("Loading Withholding tax data...", {
        duration: 1000,
        width: "18em"
      });
    }, 1000);
    setTimeout(function() {
      sap.m.MessageToast.show("Loading Correspondence data...", {
        duration: 1000,
        width: "18em"
      });
    }, 2000);
    if (oUdmbp === "X") { // Display Collections Profile
      oCPTab.setVisible(true);
      setTimeout(function() {
        sap.m.MessageToast.show("Loading Collection Profile...", {
          duration: 1000,
          width: "18em"
        });
      }, 3000);
    } else { // Hide Collections Profile
      oCPTab.setVisible(false);
    }

    this.refreshTable();

    var oUrl = "/ClientLEntitySet(Kunnr='" + this._oKunnr + "',Vkorg='" + this._oVkorg + "')/";
    var oUrlBP = oUrl + "ClientLEntityToClientBP";
    var oUrlWtax = oUrl + "ClientLEntityToClientWtax";
    var oUrlCdata = oUrl + "ClientLEntityToClientCdata";

    var oMainModel = oView.getModel();
    this.bindTableBP(oView, oMainModel, oUrlBP);
    this.bindTableWtax(oView, oMainModel, oUrlWtax);
    this.bindTableCdata(oView, oMainModel, oUrlCdata);
    if (oUdmbp === "X") {
      var oUrlCProf = oUrl + "ClientLEntityToCollProf";
      var oUrlCDProf = oUrl + "ClientLEntityToTempAssn";
      this.bindTableCProf(oView, oMainModel, oUrlCProf);
      this.bindTableCDProf(oView, oMainModel, oUrlCDProf);
      var oUrlStat = this._sEntityPath + "/MYCLIENTSToClientStatus";
      this.bindStatus(oView, oMainModel, oUrlStat);
    }
    setTimeout(function() {
      oView.setBusy(false);
    }, 4000);
  },

  bindTableBP: function(oView, oMainModel, sEntityPath) {
    var ompDispTbl = oView.byId("FormDisplay354PD");
    var ompChngTbl = oView.byId("FormChange354PD");
    var oPath = sEntityPath;
    var that = this;
    oMainModel.read(oPath, null, null, null, function(data, request) {
      var aTableData = [];
      for (var k = 0; k < data.results.length; k++) {
        var oAddress = data.results[k].Line1 + ", " +
          data.results[k].Line2 + ", " +
          data.results[k].Line3 + ", " +
          data.results[k].Line4;
        if (data.results[k].Parvw !== "BP" && data.results[k].Parvw !== "SH") {
          var oRow = {
            Kunnr: data.results[k].Kunnr,
            Vkorg: data.results[k].Vkorg,
            Parvw: data.results[k].Parvw,
            Vtext: data.results[k].Vtext,
            Kunn2: data.results[k].Kunn2,
            Name1: data.results[k].Name1,
            Address: oAddress,
            Msgfn: ""
          };
          aTableData.push(oRow);
        } else {
          var oRow1 = {
            Kunnr: data.results[k].Kunnr,
            Vkorg: data.results[k].Vkorg,
            Parvw: data.results[k].Parvw,
            Vtext: data.results[k].Vtext,
            Kunn2: data.results[k].Kunn2,
            Name1: data.results[k].Name1,
            Msgfn: ""
          };
          that._aGlobalBP.push(oRow1);
        }
      }
      //Create a model and bind the table rows to this model
      var oModel = new sap.ui.model.json.JSONModel();
      oModel.setData({
        modelData: aTableData
      });
      ompDispTbl.setModel(oModel);
      ompDispTbl.bindRows("/modelData");
      ompChngTbl.setModel(oModel);
      ompChngTbl.bindRows("/modelData");
    }, function(oError) {});

  },

  bindTableWtax: function(oView, oMainModel, sEntityPath) {
    var dateFormat;
    var ompDispTbl = oView.byId("FormDisplay354WD");
    dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
      style: "medium"
    });
    this.bindTableWtax1(oView, oMainModel, sEntityPath, ompDispTbl, dateFormat);
    var ompChngTbl = oView.byId("FormChange354WD");
    dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
      pattern: "yyyy-MM-dd"
    });
    this.bindTableWtax1(oView, oMainModel, sEntityPath, ompChngTbl, dateFormat);
  },

  bindTableWtax1: function(oView, oMainModel, sEntityPath, oTable, dateFormat) {
    var oPath = sEntityPath;
    var dateStr;
    var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;
    oMainModel.read(oPath, null, null, null, function(data, request) {
      var aTableData = [];
      if (data.results[0].Kunnr !== "X") {
        for (var k = 0; k < data.results.length; k++) {
          var oSwitch = data.results[k].Agent;
          if (oSwitch === "X") {
            oSwitch = true;
          } else {
            oSwitch = false;
          }

          var oFrmDt = data.results[k].Agtdf;
          if (oFrmDt) {
            dateStr = dateFormat.format(new Date(oFrmDt.getTime() + TZOffsetMs));
            oFrmDt = dateStr;
          }
          var oToDt = data.results[k].Agtdt;
          if (oToDt) {
            dateStr = dateFormat.format(new Date(oToDt.getTime() + TZOffsetMs));
            oToDt = dateStr;
          }
          var oRow = {
            Kunnr: data.results[k].Kunnr,
            Vkorg: data.results[k].Vkorg,
            Witht: data.results[k].Witht,
            Withcd: data.results[k].Withcd,
            Text40: data.results[k].Text40,
            Agent: oSwitch,
            Agtdf: oFrmDt,
            Agtdt: oToDt,
            Msgfn: ""
          };
          aTableData.push(oRow);
        }
      }
      //Create a model and bind the table rows to this model
      var oModel = new sap.ui.model.json.JSONModel();
      oModel.setData({
        modelData: aTableData
      });
      oTable.setModel(oModel);
      oTable.bindRows("/modelData");
    }, function(oError) {});
  },

  bindTableCdata: function(oView, oMainModel, sEntityPath) {
    var ompDispTbl = oView.byId("FormDisplay354CD");
    ompDispTbl.bindElement(sEntityPath);
    var ompChngTbl = oView.byId("FormChange354CD");
    ompChngTbl.bindElement(sEntityPath);
    var that = this;
    oView.setBusy(true);
    setTimeout(function() {
      that._setValueStateCD(oView);
    }, 6000);
  },

  bindTableCProf: function(oView, oMainModel, sEntityPath) {
    var ompDispTbl = oView.byId("FormDisplay354CP");
    var ompChngTbl = oView.byId("FormChange354CP");
    var oPath = sEntityPath;
    var oAddBtn = oView.byId("FormChange354CPDAddBtn");
    var oDelBtn = oView.byId("FormChange354CPDDelBtn");
    var bFlag = false;
    oMainModel.read(oPath, null, null, null, function(data, request) {
      var aTableData = [];
      if (data.results[0].Partner !== "X") {
        for (var k = 0; k < data.results.length; k++) {
          var oRow = {
            Partner: data.results[k].Partner,
            CollSegment: data.results[k].CollSegment,
            CollSegmentTxt: data.results[k].CollSegmentTxt,
            CollGroup: data.results[k].CollGroup,
            CollGroupText: data.results[k].CollGroupText,
            CollSpecialist: data.results[k].CollSpecialist,
            Fullname: data.results[k].Fullname,
            Msgfn: ""
          };
          aTableData.push(oRow);
        }
        bFlag = true;
      } else {
        bFlag = false;
      }
      oAddBtn.setEnabled(bFlag);
      oDelBtn.setEnabled(bFlag);
      //Create a model and bind the table rows to this model
      var oModel = new sap.ui.model.json.JSONModel();
      oModel.setData({
        modelData: aTableData
      });
      ompDispTbl.setModel(oModel);
      ompDispTbl.bindRows("/modelData");
      ompChngTbl.setModel(oModel);
      ompChngTbl.bindRows("/modelData");
    }, function(oError) {});
  },

  bindTableCDProf: function(oView, oMainModel, sEntityPath) {
    var dateFormat;
    var ompDispTbl = oView.byId("FormDisplay354CPD");
    dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
      style: "medium"
    });
    this.bindTableCDProf1(oView, oMainModel, sEntityPath, ompDispTbl, dateFormat);
    var ompChngTbl = oView.byId("FormChange354CPD");
    dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
      pattern: "yyyy-MM-dd"
    });
    this.bindTableCDProf1(oView, oMainModel, sEntityPath, ompChngTbl, dateFormat);
  },

  bindTableCDProf1: function(oView, oMainModel, sEntityPath, oTable, dateFormat) {
    var oPath = sEntityPath;
    var dateStr;
    var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;
    oMainModel.read(oPath, null, null, null, function(data, request) {
      var aTableData = [];
      if (data.results[0].Partner !== "X") {
        for (var k = 0; k < data.results.length; k++) {
          var oFrmDt = data.results[k].ValidFrom;
          if (oFrmDt) {
            dateStr = dateFormat.format(new Date(oFrmDt.getTime() + TZOffsetMs));
            oFrmDt = dateStr;
          }
          var oToDt = data.results[k].ValidUntil;
          if (oToDt) {
            dateStr = dateFormat.format(new Date(oToDt.getTime() + TZOffsetMs));
            oToDt = dateStr;
          }
          var ValidFromE, ValidUntilE, CollGroupE, CollSpecialistE;
          switch (data.results[k].ChangeID) {
            case "E":
              ValidFromE = true;
              ValidUntilE = true;
              CollGroupE = true;
              CollSpecialistE = true;
              break;
            case "P":
              ValidFromE = false;
              ValidUntilE = true;
              CollGroupE = false;
              CollSpecialistE = false;
              break;
            case "D":
              ValidFromE = false;
              ValidUntilE = false;
              CollGroupE = false;
              CollSpecialistE = false;
              break;
            default:
              ValidFromE = false;
              ValidUntilE = false;
              CollGroupE = false;
              CollSpecialistE = false;
          }
          var oRow = {
            ValidFrom: oFrmDt,
            ValidUntil: oToDt,
            Partner: data.results[k].Partner,
            Bukrs: data.results[k].Bukrs,
            CollGroup: data.results[k].CollGroup,
            CollGroupText: data.results[k].CollGroupText,
            CollSpecialist: data.results[k].CollSpecialist,
            Fullname: data.results[k].Fullname,
            ChangeID: data.results[k].ChangeID,
            ValidFromE: ValidFromE,
            ValidUntilE: ValidUntilE,
            CollGroupE: CollGroupE,
            CollSpecialistE: CollSpecialistE,
            Msgfn: ""
          };
          aTableData.push(oRow);
        }
      }
      //Create a model and bind the table rows to this model
      var oModel = new sap.ui.model.json.JSONModel();
      oModel.setData({
        modelData: aTableData
      });
      oTable.setModel(oModel);
      oTable.bindRows("/modelData");
    }, function(oError) {});
  },

  bindStatus: function(oView, oMainModel, sEntityPath) {
    /*var ompDispTbl = oView.byId("FormDisplay354CD");
    ompDispTbl.bindElement(sEntityPath);
    var ompChngTbl = oView.byId("FormChange354CD");
    ompChngTbl.bindElement(sEntityPath);
    var that = this;
    oView.setBusy(true);
    setTimeout(function() {
      that._setValueStateCD(oView);
    }, 6000);*/
  },

  handleCellClickChgBPBP: function(oEvent) {
    this._oTblPrtnrNmbrRowBPBP = oEvent.getParameter("rowIndex");
  },

  handleSelectPartnerTypeBP: function(oEvent) {
    var oSelKey = oEvent.oSource.getSelectedKey();
    if (oSelKey === "SP") {
      oEvent.oSource.setSelectedKey("PY");
      sap.m.MessageToast.show("CLIENT Partner Type can be selected only once.");
    }
    var oTable = this.getView().byId("FormChange354PD");
    var oModel = oTable.getModel();
    var modelData = oModel.getData();
    var aTable = [];

    for (var i = 0; i < modelData.modelData.length; i++) {
      var value = modelData.modelData[i];
      aTable.push(value);
    }

    if (aTable[this._oTblPrtnrNmbrRowBPBP].Msgfn !== "009") {
      aTable[this._oTblPrtnrNmbrRowBPBP].Msgfn = "004";
    }
    oModel.setData({
      modelData: aTable
    });
  },

  handleValueHelpChgBPBP: function(oEvent) {
    var sFieldName, sFrgmntName;
    sFieldName = "Kunnr";
    sFrgmntName = "ChgBPBP";
    this.handleValueHelpSingleTable(oEvent, sFieldName, sFrgmntName);
  },

  handleValueHelpSingleTable: function(oEvent, sFieldName, sFrgmntName) {
    var oView = this.getView();
    var oId = oEvent.getParameter("id");
    var oIndex = oId.indexOf("w");
    oIndex = oIndex + 1;
    var oSelRow = oId.substr(oIndex);
    var oTable = oView.byId("FormChange354PD");
    var oModel = oTable.getModel();
    var modelData = oModel.getData();
    var value = modelData.modelData[oSelRow];
    var oFltr = value.Parvw;
    this._sFltr = oFltr.toString();
    var sInputValue = oEvent.getSource().getValue();
    this.inputId = sFrgmntName;

    // create a filter for the binding
    var oFilter, aFilter = [];
    oFilter = new sap.ui.model.Filter(sFieldName, sap.ui.model.FilterOperator.Contains, sInputValue);
    aFilter.push(oFilter);
    oFilter = new sap.ui.model.Filter("Parvw", sap.ui.model.FilterOperator.EQ, this._sFltr);
    aFilter.push(oFilter);

    // create value help dialog
    this._valueHelpDialog = sap.ui.xmlfragment("MyClients.fragments.change.dialogSearch." + sFrgmntName, this);
    this.getView().addDependent(this._valueHelpDialog);
    this._valueHelpDialog.getBinding("items").filter(aFilter);

    // open value help dialog filtered by the input value
    this._valueHelpDialog.open(sInputValue);
  },
  handleValueHelpSearchChgBPBP: function(evt) {
    var sValue = evt.getParameter("value");
    // create a filter for the binding
    var oFilter, aFilter = [];

    oFilter = new sap.ui.model.Filter("Kunnr", sap.ui.model.FilterOperator.Contains, sValue);
    aFilter.push(oFilter);
    oFilter = new sap.ui.model.Filter("Parvw", sap.ui.model.FilterOperator.EQ, this._sFltr);
    aFilter.push(oFilter);
    evt.getSource().getBinding("items").filter(aFilter);
  },

  _handleValueHelpCloseBPBP: function(evt) {
    var oSelectedItem = evt.getParameter("selectedItem");
    if (oSelectedItem) {
      var oPrtnrNmbr = oSelectedItem.getTitle();
      var oPrtnrName = oSelectedItem.getDescription();
      var oTable = this.getView().byId("FormChange354PD");
      var oModel = oTable.getModel();
      var modelData = oModel.getData();
      var aTable = [];

      for (var i = 0; i < modelData.modelData.length; i++) {
        var value = modelData.modelData[i];
        aTable.push(value);
      }
      aTable[this._oTblPrtnrNmbrRowBPBP].Kunn2 = oPrtnrNmbr;
      aTable[this._oTblPrtnrNmbrRowBPBP].Name1 = oPrtnrName;
      if (aTable[this._oTblPrtnrNmbrRowBPBP].Msgfn !== "009") {
        aTable[this._oTblPrtnrNmbrRowBPBP].Msgfn = "004";
      }
      oModel.setData({
        modelData: aTable
      });
    }
  },

  handleCellClickChgBC: function(oEvent) {
    this._oTblPrtnrNmbrRowBC = oEvent.getParameter("rowIndex");
    this.updateTableBC();
  },
  updateTableBC: function() {
    var oTable = this.getView().byId("FormChange354BC");
    var oModel = oTable.getModel();
    var modelData = oModel.getData();
    var aTable = [];

    for (var i = 0; i < modelData.modelData.length; i++) {
      var value = modelData.modelData[i];
      aTable.push(value);
    }

    if (aTable[this._oTblPrtnrNmbrRowBC].Msgfn !== "009") {
      aTable[this._oTblPrtnrNmbrRowBC].Msgfn = "004";
    }
    oModel.setData({
      modelData: aTable
    });
  },

  handleCellClickChgWD: function(oEvent) {
    this._oTblPrtnrNmbrRowWDCD = this._oTblPrtnrNmbrRowWDTY = oEvent.getParameter("rowIndex");
    //this._oTblPrtnrNmbrRowWDCD = oEvent.getParameter("rowIndex");
  },
  handleValueHelpChgWDTY: function(oEvent) {
    /*    var sFieldName, sFrgmntName;
    sFieldName = "Witht";
    sFrgmntName = "ChgWDTY";
    this.handleValueHelpSingleTableWDTY(oEvent, sFieldName, sFrgmntName);*/
    var sFieldName1, sFieldName2, sFrgmntName;
    sFieldName1 = "Bukrs";
    sFieldName2 = "Witht";
    sFrgmntName = "ChgWDTY";
    this.handleValueHelpSingleTableWDTY(oEvent, sFieldName1, sFieldName2, sFrgmntName);
  },
  handleValueHelpSingleTableWDTY: function(oEvent, sFieldName1, sFieldName2, sFrgmntName) {
    var sInputValue = oEvent.getSource().getValue();
    this.inputId = sFrgmntName;

    // create a filter for the binding
    var oFilter, aFilter = [];
    oFilter = new sap.ui.model.Filter(sFieldName1, sap.ui.model.FilterOperator.EQ, this._oVkorg);
    aFilter.push(oFilter);
    oFilter = new sap.ui.model.Filter(sFieldName2, sap.ui.model.FilterOperator.Contains, sInputValue);
    aFilter.push(oFilter);

    // create value help dialog
    this._valueHelpDialog = sap.ui.xmlfragment("MyClients.fragments.change.dialogSearch." + sFrgmntName, this);
    this.getView().addDependent(this._valueHelpDialog);
    this._valueHelpDialog.getBinding("items").filter(aFilter);

    // open value help dialog filtered by the input value
    this._valueHelpDialog.open(sInputValue);
  },
  handleValueHelpSearchChgWDTY: function(evt) {
    var sValue = evt.getParameter("value");

    // create a filter for the binding
    var oFilter, aFilter = [];

    oFilter = new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.EQ, this._oVkorg);
    aFilter.push(oFilter);
    oFilter = new sap.ui.model.Filter("Witht", sap.ui.model.FilterOperator.Contains, sValue);
    aFilter.push(oFilter);
    evt.getSource().getBinding("items").filter(aFilter);
  },

  _handleValueHelpCloseWDTY: function(evt) {
    var oSelectedItem = evt.getParameter("selectedItem");
    if (oSelectedItem) {
      var oPrtnrNmbr = oSelectedItem.getTitle();
      var oPrtnrName = oSelectedItem.getDescription();
      var oTable = this.getView().byId("FormChange354WD");
      var oModel = oTable.getModel();
      var modelData = oModel.getData();
      var aTable = [];

      for (var i = 0; i < modelData.modelData.length; i++) {
        var value = modelData.modelData[i];
        aTable.push(value);
      }
      aTable[this._oTblPrtnrNmbrRowWDTY].Witht = oPrtnrNmbr;
      aTable[this._oTblPrtnrNmbrRowWDTY].Text40 = oPrtnrName;
      if (aTable[this._oTblPrtnrNmbrRowWDTY].Msgfn !== "009") {
        aTable[this._oTblPrtnrNmbrRowWDTY].Msgfn = "004";
      }
      oModel.setData({
        modelData: aTable
      });
    }
  },

  handleValueHelpChgWDCD: function(oEvent) {
    /*    var sFieldName, sFrgmntName;
    sFieldName = "WtWithcd";
    sFrgmntName = "ChgWDCD";
    this.handleValueHelpSingleTableWDCD(oEvent, sFieldName, sFrgmntName);*/
    var sFieldName1, sFieldName2, sFrgmntName;
    sFieldName1 = "Bukrs";
    sFieldName2 = "WtWithcd";
    sFrgmntName = "ChgWDCD";
    this.handleValueHelpSingleTableWDCD(oEvent, sFieldName1, sFieldName2, sFrgmntName);
  },
  handleValueHelpSingleTableWDCD: function(oEvent, sFieldName1, sFieldName2, sFrgmntName) {
    var sInputValue = oEvent.getSource().getValue();
    this.inputId = sFrgmntName;

    // Read Witht value
    var oTable = this.getView().byId("FormChange354WD");
    var oModel = oTable.getModel();
    var modelData = oModel.getData();
    if (this._oTblPrtnrNmbrRowWDCD !== null) {
      this._oTblPrtnrNmbrWDCDWT = modelData.modelData[this._oTblPrtnrNmbrRowWDCD].Witht;
    } else {
      this._oTblPrtnrNmbrWDCDWT = "";
    }

    // create a filter for the binding
    var oFilter, aFilter = [];
    oFilter = new sap.ui.model.Filter("Witht", sap.ui.model.FilterOperator.EQ, this._oTblPrtnrNmbrWDCDWT);
    aFilter.push(oFilter);
    oFilter = new sap.ui.model.Filter(sFieldName1, sap.ui.model.FilterOperator.EQ, this._oVkorg);
    aFilter.push(oFilter);
    oFilter = new sap.ui.model.Filter(sFieldName2, sap.ui.model.FilterOperator.Contains, sInputValue);
    aFilter.push(oFilter);

    // create value help dialog
    this._valueHelpDialog = sap.ui.xmlfragment("MyClients.fragments.change.dialogSearch." + sFrgmntName, this);
    this.getView().addDependent(this._valueHelpDialog);
    this._valueHelpDialog.getBinding("items").filter(aFilter);

    // open value help dialog filtered by the input value
    this._valueHelpDialog.open(sInputValue);
  },
  handleValueHelpSearchChgWDCD: function(evt) {
    var sValue = evt.getParameter("value");

    // create a filter for the binding
    var oFilter, aFilter = [];
    oFilter = new sap.ui.model.Filter("Witht", sap.ui.model.FilterOperator.EQ, this._oTblPrtnrNmbrWDCDWT);
    aFilter.push(oFilter);
    oFilter = new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.EQ, this._oVkorg);
    aFilter.push(oFilter);
    oFilter = new sap.ui.model.Filter("WtWithcd", sap.ui.model.FilterOperator.Contains, sValue);
    aFilter.push(oFilter);
    evt.getSource().getBinding("items").filter(aFilter);
  },

  _handleValueHelpCloseWDCD: function(evt) {
    var oSelectedItem = evt.getParameter("selectedItem");
    if (oSelectedItem) {
      var oPrtnrNmbr = oSelectedItem.getTitle();
      var oTable = this.getView().byId("FormChange354WD");
      var oModel = oTable.getModel();
      var modelData = oModel.getData();
      var aTable = [];

      for (var i = 0; i < modelData.modelData.length; i++) {
        var value = modelData.modelData[i];
        aTable.push(value);
      }
      aTable[this._oTblPrtnrNmbrRowWDCD].Withcd = oPrtnrNmbr;
      if (aTable[this._oTblPrtnrNmbrRowWDCD].Msgfn !== "009") {
        aTable[this._oTblPrtnrNmbrRowWDCD].Msgfn = "004";
      }
      oModel.setData({
        modelData: aTable
      });
    }
  },

  handleChgWDCD: function(oEvent) {

    var oTable = this.getView().byId("FormChange354WD");
    var oModel = oTable.getModel();
    var modelData = oModel.getData();
    var aTable = [];

    for (var i = 0; i < modelData.modelData.length; i++) {
      var value = modelData.modelData[i];
      aTable.push(value);
    }

    if (aTable[this._oTblPrtnrNmbrRowWDTY].Msgfn !== "009") {
      aTable[this._oTblPrtnrNmbrRowWDTY].Msgfn = "004";
    }
    oModel.setData({
      modelData: aTable
    });

  },

  handleCellClickChgCP: function(oEvent) {
    this._oTblPrtnrNmbrRowCPCS = this._oTblPrtnrNmbrRowCPCG = oEvent.getParameter("rowIndex");
  },

  handleValueHelpChgCPCG: function(oEvent) {
    /*    var sFieldName, sFrgmntName;
        sFieldName = "CollGroup";
        sFrgmntName = "ChgCPCG";
        this.handleValueHelpSingleTableCPCG(oEvent, sFieldName, sFrgmntName);*/
    var sFieldName1, sFieldName2, sFrgmntName;
    sFieldName1 = "CollSegment";
    sFieldName2 = "CollGroup";
    sFrgmntName = "ChgCPCG";
    this.handleValueHelpSingleTableCPCG(oEvent, sFieldName1, sFieldName2, sFrgmntName);
  },
  handleValueHelpSingleTableCPCG: function(oEvent, sFieldName1, sFieldName2, sFrgmntName) {
    var sInputValue = oEvent.getSource().getValue();
    this.inputId = sFrgmntName;

    // create a filter for the binding
    /*    var oFilter, aFilter = [];
        oFilter = new sap.ui.model.Filter(sFieldName, sap.ui.model.FilterOperator.Contains, sInputValue);
        aFilter.push(oFilter);*/

    var oTable = this.getView().byId("FormChange354CP");
    var oModel = oTable.getModel();
    var modelData = oModel.getData();
    if (this._oTblPrtnrNmbrRowCPCS !== null) {
      this._oTblPrtnrNmbrCPCS1 = modelData.modelData[0].CollSegment;
    } else {
      this._oTblPrtnrNmbrCPCS1 = "";
    }

    // create a filter for the binding
    var oFilter, aFilter = [];
    oFilter = new sap.ui.model.Filter(sFieldName1, sap.ui.model.FilterOperator.EQ, this._oTblPrtnrNmbrCPCS1);
    aFilter.push(oFilter);
    oFilter = new sap.ui.model.Filter(sFieldName2, sap.ui.model.FilterOperator.Contains, sInputValue);
    aFilter.push(oFilter);

    // create value help dialog
    this._valueHelpDialog = sap.ui.xmlfragment("MyClients.fragments.change.dialogSearch." + sFrgmntName, this);
    this.getView().addDependent(this._valueHelpDialog);
    this._valueHelpDialog.getBinding("items").filter(aFilter);

    // open value help dialog filtered by the input value
    this._valueHelpDialog.open(sInputValue);
  },
  handleValueHelpSearchChgCPCG: function(evt) {
    var sValue = evt.getParameter("value");

    // create a filter for the binding
    /*    var oFilter, aFilter = [];
        oFilter = new sap.ui.model.Filter("CollGroup", sap.ui.model.FilterOperator.Contains, sValue);
        aFilter.push(oFilter);
        evt.getSource().getBinding("items").filter(aFilter);*/
    var oFilter, aFilter = [];
    oFilter = new sap.ui.model.Filter("CollSegment", sap.ui.model.FilterOperator.EQ, this._oTblPrtnrNmbrCPCS1);
    aFilter.push(oFilter);
    oFilter = new sap.ui.model.Filter("CollGroup", sap.ui.model.FilterOperator.Contains, sValue);
    aFilter.push(oFilter);
    evt.getSource().getBinding("items").filter(aFilter);
  },

  _handleValueHelpCloseCPCG: function(evt) {
    var oSelectedItem = evt.getParameter("selectedItem");
    if (oSelectedItem) {
      var oPrtnrNmbr = oSelectedItem.getTitle();
      var oPrtnrName = oSelectedItem.getDescription();
      var oTable = this.getView().byId("FormChange354CP");
      var oModel = oTable.getModel();
      var modelData = oModel.getData();
      var aTable = [];

      for (var i = 0; i < modelData.modelData.length; i++) {
        var value = modelData.modelData[i];
        aTable.push(value);
      }
      aTable[this._oTblPrtnrNmbrRowCPCG].CollGroup = oPrtnrNmbr;
      aTable[this._oTblPrtnrNmbrRowCPCG].CollGroupText = oPrtnrName;
      if (aTable[this._oTblPrtnrNmbrRowCPCG].Msgfn !== "I") {
        aTable[this._oTblPrtnrNmbrRowCPCG].Msgfn = "U";
      }
      oModel.setData({
        modelData: aTable
      });
    }
  },

  handleValueHelpChgCPCS: function(oEvent) {
    var sFieldName1, sFieldName2, sFrgmntName;
    sFieldName1 = "CollGroup";
    sFieldName2 = "CollSpecialist";
    sFrgmntName = "ChgCPCS";
    this.handleValueHelpSingleTableCPCS(oEvent, sFieldName1, sFieldName2, sFrgmntName);
  },
  handleValueHelpSingleTableCPCS: function(oEvent, sFieldName1, sFieldName2, sFrgmntName) {
    var sInputValue = oEvent.getSource().getValue();
    this.inputId = sFrgmntName;

    var oTable = this.getView().byId("FormChange354CP");
    var oModel = oTable.getModel();
    var modelData = oModel.getData();
    if (this._oTblPrtnrNmbrRowCPCS !== null) {
      this._oTblPrtnrNmbrCPCS = modelData.modelData[this._oTblPrtnrNmbrRowCPCS].CollGroup;
    } else {
      this._oTblPrtnrNmbrCPCS = "";
    }

    // create a filter for the binding
    var oFilter, aFilter = [];
    oFilter = new sap.ui.model.Filter("CollGroup", sap.ui.model.FilterOperator.EQ, this._oTblPrtnrNmbrCPCS);
    aFilter.push(oFilter);
    oFilter = new sap.ui.model.Filter(sFieldName2, sap.ui.model.FilterOperator.Contains, sInputValue);
    aFilter.push(oFilter);

    // create value help dialog
    this._valueHelpDialog = sap.ui.xmlfragment("MyClients.fragments.change.dialogSearch." + sFrgmntName, this);
    this.getView().addDependent(this._valueHelpDialog);
    this._valueHelpDialog.getBinding("items").filter(aFilter);

    // open value help dialog filtered by the input value
    this._valueHelpDialog.open(sInputValue);
  },
  handleValueHelpSearchChgCPCS: function(evt) {
    var sValue = evt.getParameter("value");

    // create a filter for the binding
    var oFilter, aFilter = [];
    oFilter = new sap.ui.model.Filter("CollGroup", sap.ui.model.FilterOperator.EQ, this._oTblPrtnrNmbrCPCS);
    aFilter.push(oFilter);
    oFilter = new sap.ui.model.Filter("CollSpecialist", sap.ui.model.FilterOperator.Contains, sValue);
    aFilter.push(oFilter);
    evt.getSource().getBinding("items").filter(aFilter);
  },

  _handleValueHelpCloseCPCS: function(evt) {
    var oSelectedItem = evt.getParameter("selectedItem");
    if (oSelectedItem) {
      var oPrtnrNmbr = oSelectedItem.getTitle();
      var oPrtnrName = oSelectedItem.getDescription();
      var oTable = this.getView().byId("FormChange354CP");
      var oModel = oTable.getModel();
      var modelData = oModel.getData();
      var aTable = [];

      for (var i = 0; i < modelData.modelData.length; i++) {
        var value = modelData.modelData[i];
        aTable.push(value);
      }
      aTable[this._oTblPrtnrNmbrRowCPCS].CollSpecialist = oPrtnrNmbr;
      aTable[this._oTblPrtnrNmbrRowCPCS].Fullname = oPrtnrName;
      if (aTable[this._oTblPrtnrNmbrRowCPCS].Msgfn !== "I") {
        aTable[this._oTblPrtnrNmbrRowCPCS].Msgfn = "U";
      }
      oModel.setData({
        modelData: aTable
      });
    }
  },

  handleCellClickChgCPD: function(oEvent) {
    this._oTblPrtnrNmbrRowCPCSD = this._oTblPrtnrNmbrRowCPCGD = oEvent.getParameter("rowIndex");
  },

  handleValueHelpChgCPCGD: function(oEvent) {
    /*    var sFieldName, sFrgmntName;
        sFieldName = "CollGroup";
        sFrgmntName = "ChgCPCGD";
        this.handleValueHelpSingleTableCPCGD(oEvent, sFieldName, sFrgmntName);*/
    var sFieldName1, sFieldName2, sFrgmntName;
    sFieldName1 = "CollSegment";
    sFieldName2 = "CollGroup";
    sFrgmntName = "ChgCPCGD";
    this.handleValueHelpSingleTableCPCGD(oEvent, sFieldName1, sFieldName2, sFrgmntName);
  },
  handleValueHelpSingleTableCPCGD: function(oEvent, sFieldName1, sFieldName2, sFrgmntName) {
    var sInputValue = oEvent.getSource().getValue();
    this.inputId = sFrgmntName;

    // create a filter for the binding
    /*    var oFilter, aFilter = [];
        oFilter = new sap.ui.model.Filter(sFieldName, sap.ui.model.FilterOperator.Contains, sInputValue);
        aFilter.push(oFilter);*/

    var oTable = this.getView().byId("FormChange354CP");
    var oModel = oTable.getModel();
    var modelData = oModel.getData();
    this._oTblPrtnrNmbrCPCS1 = modelData.modelData[0].CollSegment;
    // create a filter for the binding
    var oFilter, aFilter = [];
    oFilter = new sap.ui.model.Filter(sFieldName1, sap.ui.model.FilterOperator.EQ, this._oTblPrtnrNmbrCPCS1);
    aFilter.push(oFilter);
    oFilter = new sap.ui.model.Filter(sFieldName2, sap.ui.model.FilterOperator.Contains, sInputValue);
    aFilter.push(oFilter);

    // create value help dialog
    this._valueHelpDialog = sap.ui.xmlfragment("MyClients.fragments.change.dialogSearch." + sFrgmntName, this);
    this.getView().addDependent(this._valueHelpDialog);
    this._valueHelpDialog.getBinding("items").filter(aFilter);

    // open value help dialog filtered by the input value
    this._valueHelpDialog.open(sInputValue);
  },
  handleValueHelpSearchChgCPCGD: function(evt) {
    var sValue = evt.getParameter("value");

    // create a filter for the binding
    /*    var oFilter, aFilter = [];
        oFilter = new sap.ui.model.Filter("CollGroup", sap.ui.model.FilterOperator.Contains, sValue);
        aFilter.push(oFilter);
        evt.getSource().getBinding("items").filter(aFilter);*/
    var oFilter, aFilter = [];
    oFilter = new sap.ui.model.Filter("CollSegment", sap.ui.model.FilterOperator.EQ, this._oTblPrtnrNmbrCPCS1);
    aFilter.push(oFilter);
    oFilter = new sap.ui.model.Filter("CollGroup", sap.ui.model.FilterOperator.Contains, sValue);
    aFilter.push(oFilter);
    evt.getSource().getBinding("items").filter(aFilter);
  },

  _handleValueHelpCloseCPCGD: function(evt) {
    var oSelectedItem = evt.getParameter("selectedItem");
    if (oSelectedItem) {
      var oPrtnrNmbr = oSelectedItem.getTitle();
      var oPrtnrName = oSelectedItem.getDescription();
      var oTable = this.getView().byId("FormChange354CPD");
      var oModel = oTable.getModel();
      var modelData = oModel.getData();
      var aTable = [];

      for (var i = 0; i < modelData.modelData.length; i++) {
        var value = modelData.modelData[i];
        aTable.push(value);
      }
      aTable[this._oTblPrtnrNmbrRowCPCGD].CollGroup = oPrtnrNmbr;
      aTable[this._oTblPrtnrNmbrRowCPCGD].CollGroupText = oPrtnrName;
      if (aTable[this._oTblPrtnrNmbrRowCPCGD].Msgfn !== "I") {
        aTable[this._oTblPrtnrNmbrRowCPCGD].Msgfn = "U";
      }
      oModel.setData({
        modelData: aTable
      });

      if (aTable[this._oTblPrtnrNmbrRowCPCGD].ValidFrom.length === 0 || aTable[this._oTblPrtnrNmbrRowCPCGD].ValidUntil.length === 0) {
        sap.m.MessageToast.show("Date entry needs to be filled");
        this._oGlblFlag = true;
      } else {
        this._oGlblFlag = false;
      }
    }
  },

  handleValueHelpChgCPCSD: function(oEvent) {
    var sFieldName1, sFieldName2, sFrgmntName;
    sFieldName1 = "CollGroup";
    sFieldName2 = "CollSpecialist";
    sFrgmntName = "ChgCPCSD";
    this.handleValueHelpSingleTableCPCSD(oEvent, sFieldName1, sFieldName2, sFrgmntName);
  },
  handleValueHelpSingleTableCPCSD: function(oEvent, sFieldName1, sFieldName2, sFrgmntName) {
    var sInputValue = oEvent.getSource().getValue();
    this.inputId = sFrgmntName;

    var oTable = this.getView().byId("FormChange354CPD");
    var oModel = oTable.getModel();
    var modelData = oModel.getData();
    if (this._oTblPrtnrNmbrRowCPCSD !== null) {
      this._oTblPrtnrNmbrCPCSD = modelData.modelData[this._oTblPrtnrNmbrRowCPCSD].CollGroup;
    } else {
      this._oTblPrtnrNmbrCPCSD = "";
    }

    // create a filter for the binding
    var oFilter, aFilter = [];
    oFilter = new sap.ui.model.Filter("CollGroup", sap.ui.model.FilterOperator.EQ, this._oTblPrtnrNmbrCPCSD);
    aFilter.push(oFilter);
    oFilter = new sap.ui.model.Filter(sFieldName2, sap.ui.model.FilterOperator.Contains, sInputValue);
    aFilter.push(oFilter);

    // create value help dialog
    this._valueHelpDialog = sap.ui.xmlfragment("MyClients.fragments.change.dialogSearch." + sFrgmntName, this);
    this.getView().addDependent(this._valueHelpDialog);
    this._valueHelpDialog.getBinding("items").filter(aFilter);

    // open value help dialog filtered by the input value
    this._valueHelpDialog.open(sInputValue);
  },
  handleValueHelpSearchChgCPCSD: function(evt) {
    var sValue = evt.getParameter("value");

    // create a filter for the binding
    var oFilter, aFilter = [];
    oFilter = new sap.ui.model.Filter("CollGroup", sap.ui.model.FilterOperator.EQ, this._oTblPrtnrNmbrCPCSD);
    aFilter.push(oFilter);
    oFilter = new sap.ui.model.Filter("CollSpecialist", sap.ui.model.FilterOperator.Contains, sValue);
    aFilter.push(oFilter);
    evt.getSource().getBinding("items").filter(aFilter);
  },

  _handleValueHelpCloseCPCSD: function(evt) {
    var oSelectedItem = evt.getParameter("selectedItem");
    if (oSelectedItem) {
      var oPrtnrNmbr = oSelectedItem.getTitle();
      var oPrtnrName = oSelectedItem.getDescription();
      var oTable = this.getView().byId("FormChange354CPD");
      var oModel = oTable.getModel();
      var modelData = oModel.getData();
      var aTable = [];
      for (var i = 0; i < modelData.modelData.length; i++) {
        var value = modelData.modelData[i];
        aTable.push(value);
      }
      aTable[this._oTblPrtnrNmbrRowCPCSD].CollSpecialist = oPrtnrNmbr;
      aTable[this._oTblPrtnrNmbrRowCPCSD].Fullname = oPrtnrName;
      if (aTable[this._oTblPrtnrNmbrRowCPCSD].Msgfn !== "I") {
        aTable[this._oTblPrtnrNmbrRowCPCSD].Msgfn = "U";
      }
      oModel.setData({
        modelData: aTable
      });
    }
  },

  handleChgCP: function(oEvent) {
    var oTable = this.getView().byId("FormChange354CPD");
    var oModel = oTable.getModel();
    var modelData = oModel.getData();
    var data = modelData.modelData;
    var aTable = [];

    var bFlag = false;
    var bFlagEF = false;
    var bFlagET = false;
    var oSelDate = oEvent.oSource.mProperties.dateValue;
    var today = new Date();
    today = new Date(today.getTime() - (24 * 60 * 60 * 1000));
    var oColId = oEvent.getParameter("id");
    var oCol1 = oColId.indexOf("col1");
    var oCol2 = oColId.indexOf("col2");
    var oVFrom = data[this._oTblPrtnrNmbrRowCPCGD].ValidFrom;
    for (var j = 0; j < data.length; j++) {
      switch (data[j].ChangeID) {
        case "P": // Validate Valid To
          if (oSelDate === null || oSelDate < today) {
            sap.m.MessageToast.show("VALID TO should be greater than or equal to current date.");
            bFlag = true;
          } else {
            bFlag = false;
          }
          break;
        case "E": // Validate all the fields
          if (oCol1 > 0) { // User pressed From Date
            // Validation 1: From Date should be >= current date
            if (oSelDate === null || oSelDate < today) {
              sap.m.MessageToast.show("VALID FROM should be greater than or equal to current date.");
              bFlagEF = true;
            } else { // From date is >= current date
              // bFlagEF = false;
              // Validation 2: From Date should be >= To date of the previous record
              var oVToPrevRow = data[this._oTblPrtnrNmbrRowCPCGD + 1].ValidUntil;
              oVToPrevRow = new Date(oVToPrevRow);
              oVToPrevRow = new Date(oVToPrevRow.getTime() + (24 * 60 * 60 * 1000));
              if (oSelDate < oVToPrevRow) {
                sap.m.MessageToast.show("Time Intervals overlap.");
                bFlagEF = true;
              } else {
                bFlagEF = false;
              }
            }
          } else { // User pressed To Date
            if (oCol2 > 0) { // User pressed To Date
              // Validation 1: To Date should be >= From date
              if (oSelDate === null) { // Blank Valid To Date
                sap.m.MessageToast.show("VALID TO should be greater than or equal to VALID FROM date.");
                bFlagET = true;
              } else { // Valid Date is available
                oVFrom = new Date(oVFrom);
                oVFrom = new Date(oVFrom.getTime() + (24 * 60 * 60 * 1000));
                if (oVFrom > oSelDate) { // Valid From Date > Valid To Date
                  bFlagET = true;
                  sap.m.MessageToast.show("VALID TO should be greater than or equal to VALID FROM date.");
                } else {
                  bFlagET = false;
                }
              }
            } else { // User pressed To Date

            }
          }
          break;
        default:
      }
      if (bFlag || bFlagEF || bFlagET) {
        this._oGlblFlag = true;
        break;
      } else {
        this._oGlblFlag = false;
      }
    }
    for (var i = 0; i < data.length; i++) {
      var value = data[i];
      aTable.push(value);
    }
    if (bFlag) {
      aTable[this._oTblPrtnrNmbrRowCPCGD].ValidUntil = "";
    } else { // Execute the below code when all the date validations are successful
      if (bFlagEF) {
        aTable[this._oTblPrtnrNmbrRowCPCGD].ValidFrom = "";
      } else { // Execute the below code when all the date validations are successful
        if (bFlagET) {
          aTable[this._oTblPrtnrNmbrRowCPCGD].ValidUntil = "";
        } else {
          if (aTable[this._oTblPrtnrNmbrRowCPCGD].Msgfn !== "I") {
            aTable[this._oTblPrtnrNmbrRowCPCGD].Msgfn = "U";
          }
        }
      }
    }

    oModel.setData({
      modelData: aTable
    });
  },

  showEmptyView: function() {
    this.getRouter().myNavToWithoutHash({
      currentView: this.getView(),
      targetViewName: "MyClients.view.NotFound",
      targetViewType: "XML"
    });
  },

  fireDetailChanged: function(sEntityPath) {
    this.getEventBus().publish("Detail", "Changed", {
      sEntityPath: sEntityPath
    });
  },

  fireDetailNotFound: function() {
    this.getEventBus().publish("Detail", "NotFound");
  },

  onNavBack: function() {
    // This is only relevant when running on phone devices
    this.getRouter().myNavBack("main");
  },

  onDetailSelect: function(oEvent) {
    sap.ui.core.UIComponent.getRouterFor(this).navTo("detail", {
      entity: oEvent.getSource().getBindingContext().getPath().slice(1),
      tab: oEvent.getParameter("selectedKey")
    }, true);
  },

  openActionSheet: function() {

    if (!this._oActionSheet) {
      this._oActionSheet = new sap.m.ActionSheet({
        buttons: new sap.ushell.ui.footerbar.AddBookmarkButton()
      });
      this._oActionSheet.setShowCancelButton(true);
      this._oActionSheet.setPlacement(sap.m.PlacementType.Top);
    }

    this._oActionSheet.openBy(this.getView().byId("actionButton"));
  },

  getEventBus: function() {
    return sap.ui.getCore().getEventBus();
  },

  getRouter: function() {
    return sap.ui.core.UIComponent.getRouterFor(this);
  },

  onExit: function(oEvent) {
    var oEventBus = this.getEventBus();
    oEventBus.unsubscribe("Master", "InitialLoadFinished", this.onMasterLoaded, this);
    oEventBus.unsubscribe("Component", "MetadataFailed", this.onMetadataFailed, this);
    if (this._oActionSheet) {
      this._oActionSheet.destroy();
      this._oActionSheet = null;
    }
  },
  /*
    myBoolean: function(sBool) {
      var bValue = false;
      if (sBool === "X") {
        bValue = true;
      }
      return bValue;
    },

    myBooleanAC: function(sBool) {
      var bValue = true;
      if (sBool === "N") {
        bValue = false;
      }
      return bValue;
    },

    myBoolean1: function(sBool) {
      var bValue = false;
      if (sBool !== "SP") {
        bValue = true;
      }
      return bValue;
    },

    myDate: function(sBool) {
      if (sBool) {
        var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
          //pattern: "yyyy-MM-dd"
          style: "medium"
        });
        var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;
        var dateStr = dateFormat.format(new Date(sBool.getTime() + TZOffsetMs));
        return dateStr;
      }
    },

    myDate1: function(sBool) {
      if (sBool) {
        var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
          pattern: "yyyy-MM-dd"
            //style:"medium"
        });
        var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;
        var dateStr = dateFormat.format(new Date(sBool.getTime() + TZOffsetMs));
        return dateStr;
      }
    },

    myVisibleGD: function(sBool) {
      var bValue = true;
      if (sBool === "S") {
        bValue = false;
      }
      return bValue;
    },

    myVisiblePhEm: function(sBool) {
      var bValue = true;
      if (sBool === "") {
        bValue = false;
      }
      return bValue;
    },
  */

  handleEditPress: function() {
    this._toggleButtonsAndView(true);
  },

  handleCancelPress: function() {
    this._toggleButtonsAndView(false);
  },

  _toggleButtonsAndView: function(bEdit) {
    var oView = this.getView();
    var aChange = ["edit", "FormDisplay354GD", "FormDisplay354BC", "FormDisplay354PD", "FormDisplay354WD", "FormDisplay354CD",
      "FormDisplay354CP", "FormDisplay354CPD", "FormDisplay354ST"
    ];
    var aDisplay = ["save", "cancel", "FormChange354GD", "FormChange354BC", "FormChange354WD", "FormChange354CD", "FormChange354PD",
      "FormChange354CP", "FormChange354CPD", "FormChange354ST"
    ];
    for (var i = 0; i < aChange.length; i++) {
      oView.byId(aChange[i]).setVisible(!bEdit);
    }
    for (var j = 0; j < aDisplay.length; j++) {
      oView.byId(aDisplay[j]).setVisible(bEdit);
    }
  },

  _formFragments: {},
  _getFormFragment: function(sFragmentName) {
    var oFormFragment = this._formFragments[sFragmentName];
    if (oFormFragment) {
      return oFormFragment;
    }
    oFormFragment = sap.ui.xmlfragment("MyClients.fragments." + sFragmentName, this);
    this._formFragments[sFragmentName] = oFormFragment;
    return this._formFragments[sFragmentName];
  },

  _showFormFragment: function(sFragmentName) {
    var oPage = this.getView().byId("detailPage");
    oPage.insertContent(this._getFormFragment(sFragmentName));
  },

  handleSavePress: function() {
    if (this._oGlblFlag) {
      sap.m.MessageToast.show("Collection Profile Tab: Please fill mandatory fields.");
    } else {
      var that = this;
      var oView = that.getView();
      var bDate = false;
      var oODEnabled = oView.byId("ChgGDOD").getEnabled();
      if (oODEnabled) {
        var oODState = oView.byId("ChgGDOD").getValue();
        if (oODState.length === 0) {
          sap.m.MessageToast.show("General Data Tab: Open Date must not be empty.");
          bDate = false;
        } else {
          bDate = true;
        }
      } else {
        bDate = true;
      }
      if (bDate) {

        // General Data Tab
        var oGUState = oView.byId("ChgGDGU").getValueState();
        if (oGUState === "None") {
          var oDNState = oView.byId("ChgGDDN").getValueState();
          if (oDNState === "None") {

            // Correspondence Data Tab
            var oASState = oView.byId("ChgCDAS").getValueState();
            if (oASState === "None") {
              var oDPState = oView.byId("ChgCDDP").getValueState();
              if (oDPState === "None") {
                var oPTState = oView.byId("ChgCDPT").getValueState();
                if (oPTState === "None") {

                  // Date format 2014-09-12T00:00:00
                  var oTime = "T00:00:00";

                  // Child data arrays
                  var saveChildDataBC = [],
                    saveChildDataPD = [],
                    saveChildDataWD = [],
                    saveChildDataCP = [],
                    saveChildDataCPD = [];

                  // Billing Contact Tab
                  var oTableBC = oView.byId("FormChange354BC");
                  var oTModelBC = oTableBC.getModel();
                  var modelDataBC = oTModelBC.getData();

                  //if (modelDataBC) {
                  var bFlag = false;
                  for (var i = 0; i < modelDataBC.modelData.length; i++) {
                    var value = modelDataBC.modelData[i];
                    if (value.Name1 === "") {
                      bFlag = true;
                      break;
                    } else {
                      bFlag = false;
                    }
                    if (value.Namev === "") {
                      bFlag = true;
                      break;
                    } else {
                      bFlag = false;
                    }
                  }
                  if (bFlag === false) {
                    for (var i1 = 0; i1 < modelDataBC.modelData.length; i1++) {
                      var value11 = modelDataBC.modelData[i1];
                      saveChildDataBC.push(value11);
                    }

                    for (var j = 0; j < that._aDelTableBC.length; j++) {
                      var value1 = that._aDelTableBC[j];
                      value1.Msgfn = "003";
                      saveChildDataBC.push(value1);
                    }
                    that._aDelTableBC.length = 0;
                    // General Data Tab

                    var oGDL = oView.byId("ChgGDL").getPlaceholder();
                    var oGDECS = oView.byId("ChgGDECS").getPlaceholder();
                    var oGDTJ = oView.byId("ChgGDTJ").getPlaceholder();
                    var oGDLDesc = oView.byId("ChgGDL").getValue();
                    var oGDECSDesc = oView.byId("ChgGDECS").getValue();
                    var oGDTJDesc = oView.byId("ChgGDTJ").getValue();

                    var oGDOD = oView.byId("ChgGDOD").getValue();
                    if (oGDOD) {
                      oGDOD = oGDOD + oTime;
                    } else {
                      oGDOD = null;
                    }

                    var oGDAUDesc = oView.byId("ChgGDAU").getText();
                    var oGDCGDesc = oView.byId("ChgGDCG").getValue();
                    var oGDGUDesc = oView.byId("ChgGDGU").getValue();
                    var oGDDNDesc = oView.byId("ChgGDDN").getValue();
                    var oGDT1Desc = oView.byId("ChgGDT1").getValue();
                    var oGDT2Desc = oView.byId("ChgGDT2").getValue();
                    var oGDT3Desc = oView.byId("ChgGDT3").getValue();
                    var oGDT4Desc = oView.byId("ChgGDT4").getValue();
                    var oGDT5Desc = oView.byId("ChgGDT5").getValue();
                    var oGDVADesc = oView.byId("ChgGDVA").getValue();

                    if (oGDLDesc.length === 1 && oGDLDesc === " ") {
                      oGDLDesc = "";
                    }
                    if (oGDECSDesc.length === 1 && oGDECSDesc === " ") {
                      oGDECSDesc = "";
                    }
                    if (oGDTJDesc.length === 1 && oGDTJDesc === " ") {
                      oGDTJDesc = "";
                    }

                    if (oGDLDesc.length === 0) {
                      oGDL = "";
                    }
                    if (oGDECSDesc.length === 0) {
                      oGDECS = "";
                    }
                    if (oGDTJDesc.length === 0) {
                      oGDTJ = "";
                    }

                    var oGDAC = oView.byId("ChgGDAC").getState();
                    var oGDP = oView.byId("ChgGDP").getState();

                    if (oGDAC) {
                      oGDAC = " ";
                    } else {
                      oGDAC = "N";
                    }
                    if (oGDP) {
                      oGDP = "X";
                    } else {
                      oGDP = " ";
                    }

                    // Correspondence data Tab

                    var oCDDLDesc = oView.byId("ChgCDDL").getValue();
                    var oCDCUDesc = oView.byId("ChgCDCU").getValue();
                    var oCDTNDesc = oView.byId("ChgCDTN").getValue();

                    var oCDAS = oView.byId("ChgCDAS").getPlaceholder();
                    //var oCDDA = oView.byId("ChgCDDA").getPlaceholder();
                    var oCDDP = oView.byId("ChgCDDP").getPlaceholder();
                    var oCDDB = oView.byId("ChgCDDB").getPlaceholder();
                    var oCDDR = oView.byId("ChgCDDR").getPlaceholder();
                    var oCDPT = oView.byId("ChgCDPT").getPlaceholder();
                    var oCDPG = oView.byId("ChgCDPG").getPlaceholder();
                    var oCDTG = oView.byId("ChgCDTG").getPlaceholder();
                    var oCDPM = oView.byId("ChgCDPM").getPlaceholder();

                    var oCDASDesc = oView.byId("ChgCDAS").getValue();
                    //var oCDDADesc = oView.byId("ChgCDDA").getValue();
                    var oCDDPDesc = oView.byId("ChgCDDP").getValue();
                    var oCDDBDesc = oView.byId("ChgCDDB").getValue();
                    var oCDDRDesc = oView.byId("ChgCDDR").getValue();
                    var oCDPTDesc = oView.byId("ChgCDPT").getValue();
                    var oCDPGDesc = oView.byId("ChgCDPG").getValue();
                    var oCDTGDesc = oView.byId("ChgCDTG").getValue();
                    var oCDPMDesc = oView.byId("ChgCDPM").getValue();

                    if (oCDASDesc.length === 1 && oCDASDesc === " ") {
                      oCDASDesc = "";
                    }
                    /*if (oCDDADesc.length === 1 && oCDDADesc === " ") {
                      oCDDADesc = "";
                    }*/
                    if (oCDDPDesc.length === 1 && oCDDPDesc === " ") {
                      oCDDPDesc = "";
                    }
                    if (oCDDBDesc.length === 1 && oCDDBDesc === " ") {
                      oCDDBDesc = "";
                    }
                    if (oCDDRDesc.length === 1 && oCDDRDesc === " ") {
                      oCDDRDesc = "";
                    }
                    if (oCDPTDesc.length === 1 && oCDPTDesc === " ") {
                      oCDPTDesc = "";
                    }
                    if (oCDPGDesc.length === 1 && oCDPGDesc === " ") {
                      oCDPGDesc = "";
                    }
                    if (oCDTGDesc.length === 1 && oCDTGDesc === " ") {
                      oCDTGDesc = "";
                    }
                    if (oCDPMDesc.length === 1 && oCDPMDesc === " ") {
                      oCDPMDesc = "";
                    }

                    if (oCDASDesc.length === 0) {
                      oCDASDesc = "";
                    }
                    /*if (oCDDADesc.length === 0) {
                      oCDDADesc = "";
                    }*/
                    if (oCDDPDesc.length === 0) {
                      oCDDPDesc = "";
                    }
                    if (oCDDBDesc.length === 0) {
                      oCDDBDesc = "";
                    }
                    if (oCDDRDesc.length === 0) {
                      oCDDRDesc = "";
                    }
                    if (oCDPTDesc.length === 0) {
                      oCDPT = "";
                    }
                    if (oCDPGDesc.length === 0) {
                      oCDPG = "";
                    }
                    if (oCDTGDesc.length === 0) {
                      oCDTG = "";
                    }
                    if (oCDPMDesc.length === 0) {
                      oCDPM = "";
                    }

                    var oCDLD = oView.byId("ChgCDLD").getValue();
                    if (oCDLD) {
                      oCDLD = oCDLD + oTime;
                    } else {
                      oCDLD = null;
                    }

                    var oCDCI = oView.byId("ChgCDCI").getState();
                    var oCDLDT = oView.byId("ChgCDLDT").getState();

                    if (oCDCI) {
                      oCDCI = "X";
                    } else {
                      oCDCI = " ";
                    }
                    if (oCDLDT) {
                      oCDLDT = "X";
                    } else {
                      oCDLDT = " ";
                    }

                    // Withholding tax data Tab
                    var oTableWD = oView.byId("FormChange354WD");
                    var oTModelWD = oTableWD.getModel();
                    var modelDataWD = oTModelWD.getData();
                    if (modelDataWD) {
                      for (var i12 = 0; i12 < modelDataWD.modelData.length; i12++) {
                        var value1123 = modelDataWD.modelData[i12];
                        saveChildDataWD.push(value1123);
                      }

                      for (var j1 = 0; j1 < that._aDelTableWD.length; j1++) {
                        var value111 = that._aDelTableWD[j1];
                        value111.Msgfn = "003";
                        saveChildDataWD.push(value111);
                      }
                      that._aDelTableWD.length = 0;

                      // Change field

                      for (var m = 0; m < saveChildDataWD.length; m++) {
                        if (saveChildDataWD[m].Agent) {
                          saveChildDataWD[m].Agent = "X";
                        } else {
                          saveChildDataWD[m].Agent = " ";
                        }
                        if (saveChildDataWD[m].Agtdf) {
                          var n = saveChildDataWD[m].Agtdf.indexOf(oTime);
                          if (n < 0) {
                            saveChildDataWD[m].Agtdf = saveChildDataWD[m].Agtdf + oTime;
                          }
                        } else {
                          saveChildDataWD[m].Agtdf = null;
                        }
                        if (saveChildDataWD[m].Agtdt) {
                          var n1 = saveChildDataWD[m].Agtdt.indexOf(oTime);
                          if (n1 < 0) {
                            saveChildDataWD[m].Agtdt = saveChildDataWD[m].Agtdt + oTime;
                          }
                        } else {
                          saveChildDataWD[m].Agtdt = null;
                        }
                      }
                    }

                    // Partner Details Tab
                    var oTablePD = oView.byId("FormChange354PD");
                    var oTModelPD = oTablePD.getModel();
                    var modelDataPD = oTModelPD.getData();
                    if (modelDataPD) {
                      for (var k = 0; k < modelDataPD.modelData.length; k++) {
                        var value2 = modelDataPD.modelData[k];
                        saveChildDataPD.push(value2);
                      }

                      for (var l = 0; l < that._aDelTablePD.length; l++) {
                        var value3 = that._aDelTablePD[l];
                        value3.Msgfn = "003";
                        saveChildDataPD.push(value3);
                      }
                      that._aDelTablePD.length = 0;

                      // Remove Address field
                      var saveChildDataPDFinal = [];
                      for (var m1 = 0; m1 < saveChildDataPD.length; m1++) {
                        var valueM1 = saveChildDataPD[m1];
                        var oRow1 = {
                          Kunnr: valueM1.Kunnr,
                          Vkorg: valueM1.Vkorg,
                          Parvw: valueM1.Parvw,
                          Vtext: valueM1.Vtext,
                          Kunn2: valueM1.Kunn2,
                          Name1: valueM1.Name1,
                          Msgfn: valueM1.Msgfn
                        };
                        saveChildDataPDFinal.push(oRow1);
                      }
                      saveChildDataPD = saveChildDataPDFinal;
                    }
                    for (var iPD = 0; iPD < that._aGlobalBP.length; iPD++) {
                      var valuePD = that._aGlobalBP[iPD];
                      saveChildDataPD.push(valuePD);
                    }
                    // Collection Profile Tab
                    var oTableCP = oView.byId("FormChange354CP");
                    var oTModelCP = oTableCP.getModel();
                    var modelDataCP = oTModelCP.getData();
                    if (modelDataCP) {
                      for (var i123 = 0; i123 < modelDataCP.modelData.length; i123++) {
                        var value11234 = modelDataCP.modelData[i123];
                        saveChildDataCP.push(value11234);
                      }
                    }

                    // Temporary Assignments Tab
                    var oTableCPD = oView.byId("FormChange354CPD");
                    var oTModelCPD = oTableCPD.getModel();
                    var modelDataCPD = oTModelCPD.getData();

                    //if (modelDataCPD) {
                    var bFlagCPD = false;
                    for (var iCPD = 0; iCPD < modelDataCPD.modelData.length; iCPD++) {
                      var valueCPD = modelDataCPD.modelData[iCPD];
                      if (valueCPD.CollGroup === "") {
                        bFlagCPD = true;
                        break;
                      } else {
                        bFlagCPD = false;
                      }
                    }
                    if (bFlagCPD === false) {

                      for (var i1234 = 0; i1234 < modelDataCPD.modelData.length; i1234++) {
                        var value112345 = modelDataCPD.modelData[i1234];
                        saveChildDataCPD.push(value112345);
                      }

                      for (var j12 = 0; j12 < that._aDelTableCPD.length; j12++) {
                        var value1111 = that._aDelTableCPD[j12];
                        value1111.Msgfn = "D";
                        saveChildDataCPD.push(value1111);
                      }
                      that._aDelTableCPD.length = 0;

                      // Change field

                      for (var m11 = 0; m11 < saveChildDataCPD.length; m11++) {
                        if (saveChildDataCPD[m11].ValidFrom) {
                          var n11 = saveChildDataCPD[m11].ValidFrom.indexOf(oTime);
                          if (n11 < 0) {
                            saveChildDataCPD[m11].ValidFrom = saveChildDataCPD[m11].ValidFrom + oTime;
                          }
                        } else {
                          saveChildDataCPD[m11].ValidFrom = null;
                        }
                        if (saveChildDataCPD[m11].ValidUntil) {
                          var n111 = saveChildDataCPD[m11].ValidUntil.indexOf(oTime);
                          if (n111 < 0) {
                            saveChildDataCPD[m11].ValidUntil = saveChildDataCPD[m11].ValidUntil + oTime;
                          }
                        } else {
                          saveChildDataCPD[m11].ValidUntil = null;
                        }
                      }
                      //}
                      // Remove Enable fields
                      var saveChildDataCPDFinal = [];
                      for (var iCPD1 = 0; iCPD1 < saveChildDataCPD.length; iCPD1++) {
                        var valueCPD1 = saveChildDataCPD[iCPD1];
                        var oRowCPD = {
                          Partner: valueCPD1.Partner,
                          Bukrs: valueCPD1.Bukrs,
                          ChangeID: valueCPD1.ChangeID,
                          CollGroup: valueCPD1.CollGroup,
                          CollGroupText: valueCPD1.CollGroupText,
                          CollSpecialist: valueCPD1.CollSpecialist,
                          Fullname: valueCPD1.Fullname,
                          Msgfn: valueCPD1.Msgfn,
                          ValidFrom: valueCPD1.ValidFrom,
                          ValidUntil: valueCPD1.ValidUntil
                        };
                        saveChildDataCPDFinal.push(oRowCPD);
                      }
                      saveChildDataCPD = saveChildDataCPDFinal;

                      var saveHeaderData = {
                        Kunnr: that._oKunnr,
                        Vkorg: that._oVkorg,

                        Langu: oGDL,
                        Zzexpcodeset: oGDECS,
                        Txjcd: oGDTJ,
                        Zzopendate: oGDOD,

                        Zzclntgrp: oGDCGDesc,
                        Zzglobalultimate: oGDGUDesc,
                        Zzdunsnumber: oGDDNDesc,
                        Stceg: oGDVADesc,
                        Auth: oGDAUDesc,

                        Zzcolco: oGDAC,
                        Zzpriconf: oGDP,

                        Stcd1: oGDT1Desc,
                        Stcd2: oGDT2Desc,
                        Stcd3: oGDT3Desc,
                        Stcd4: oGDT4Desc,
                        Stcd5: oGDT5Desc,

                        Xausz: oCDAS,
                        //Maber: oCDDA,
                        Mahna: oCDDP,
                        Mansp: oCDDB,
                        Knrma: oCDDR,
                        Zterm: oCDPT,
                        Fdgrv: oCDPG,
                        Togru: oCDTG,
                        Zwels: oCDPM,

                        Madat: oCDLD,

                        Mahns: oCDDLDesc,
                        Zsabe: oCDCUDesc,
                        Tlfns: oCDTNDesc,

                        Zamim: oCDCI,
                        Zamir: oCDLDT
                      };

                      saveHeaderData.ClientsToClientBCon = saveChildDataBC; //Add BC child to request
                      saveHeaderData.ClientsToClientBP = saveChildDataPD; //Add PD child to request
                      saveHeaderData.ClientsToClientWtax = saveChildDataWD; //Add WD child to request
                      saveHeaderData.ClientsToCollProf = saveChildDataCP; //Add CP child to request
                      saveHeaderData.ClientsToTempAssn = saveChildDataCPD; //Add CPD child to request

                      var oModel = oView.getModel();
                      var saveParam = "/ClientsSet";
                      var batchChanges = [];
                      batchChanges.push(oModel.createBatchOperation(saveParam, "POST", saveHeaderData));
                      oModel.addBatchChangeOperations(batchChanges);
                      oModel.setHeaders({
                        "If-Match": "value1"
                      });
                      //var oShell = sap.ui.getCore().byId("clientsShell");
                      oView.setBusy(true);
                      oModel.submitBatch(function(oSuccess) {
                        that.handleSuccess(oSuccess, oView);
                      }, function(oError) {
                        that.handleError(oError, oView);
                      });
                    } else {
                      sap.m.MessageToast.show("Collection Profile Tab: Collection Group must not be empty.");
                    }
                  } else {
                    sap.m.MessageToast.show("Billing Contact Tab: Name/First Name must not be empty.");
                  }
                  //}

                } else {
                  sap.m.MessageToast.show("Correspondence Data Tab: Payt Terms must not be empty.");
                }
              } else {
                sap.m.MessageToast.show("Correspondence Data Tab: Dunning Procedure must not be empty.");
              }
            } else {
              sap.m.MessageToast.show("Correspondence Data Tab: Acct Statement must not be empty.");
            }
          } else {
            sap.m.MessageToast.show("General Data Tab: DUNS No. must not be empty.");
          }
        } else {
          sap.m.MessageToast.show("General Data Tab: Global Ultimate must not be empty.");
        }
      }
    }
  },

  handleSuccess: function(oSuccess, oView) {
    var that = this;

    oView.setBusy(false);
    var aBtchResp = oSuccess.__batchResponses[0];
    if (aBtchResp.__changeResponses) { // Success
      var oSuccessMsg = oSuccess.__batchResponses[0].__changeResponses[0].data.Errormessage;
      oSuccessMsg = "Client has been updated successfully.";
      sap.m.MessageBox.show(oSuccessMsg, {
        icon: sap.m.MessageBox.Icon.SUCCESS,
        title: "SUCCESS",
        onClose: function() { // On successful update, switch to display mode and refresh the data.
          oView.setBusy(true);
          that._toggleButtonsAndView(false);
          that.onRouteMatchedSuccess();
          setTimeout(function() {
            oView.setBusy(false);
            sap.m.MessageToast.show("Data has been refreshed.");
          }, 3000);
        }
      });
    } else {
      var oJSONErr = JSON.parse(oSuccess.__batchResponses[0].response.body).error;
      if (oJSONErr) {
        var oJSONErrTitle = oJSONErr.message.value;
        var oJSONErrDetails = oJSONErr.innererror.errordetails;
        var oJSONErrBody = "";
        for (var p = 0; p < oJSONErrDetails.length; p++) {
          var valueP = oJSONErrDetails[p];
          if (valueP.message) {
            oJSONErrBody = oJSONErrBody + (p + 1) + " : ";
            oJSONErrBody = oJSONErrBody + valueP.message;
            oJSONErrBody = oJSONErrBody + "\n";
          }
        }
        if (oJSONErrBody) {
          sap.m.MessageBox.show(oJSONErrTitle, {
            icon: sap.m.MessageBox.Icon.ERROR,
            title: "ERROR",
            actions: sap.m.MessageBox.Action.OK,
            styleClass: "errorMsgBox",
            details: oJSONErrBody
          });
        } else {
          sap.m.MessageBox.show(oJSONErrTitle, {
            icon: sap.m.MessageBox.Icon.ERROR,
            title: "ERROR",
            actions: sap.m.MessageBox.Action.OK
          });
        }
      }
    }
  },

  handleError: function(oError, oView) {
    oView.setBusy(false);
    var oJSONErr = JSON.parse(oError.response.body).error.message.value;
    sap.m.MessageBox.show(oJSONErr, {
      icon: sap.m.MessageBox.Icon.ERROR,
      title: "ERROR",
      actions: sap.m.MessageBox.Action.OK
    });
  },

  handleValueHelpChgCDAS: function(oEvent) {
    var sFieldName, sFrgmntName;
    sFieldName = "Text1";
    sFrgmntName = "ChgCDAS";
    this.handleValueHelpSingle(oEvent, sFieldName, sFrgmntName);
  },

  handleValueHelpChgCDDA: function(oEvent) {
    /*    var sFieldName, sFrgmntName;
    sFieldName = "Text1";
    sFrgmntName = "ChgCDDA";
    this.handleValueHelpSingle(oEvent, sFieldName, sFrgmntName);*/
    var sFieldName1, sFieldName2, sFrgmntName;
    sFieldName1 = "Bukrs";
    sFieldName2 = "Text1";
    sFrgmntName = "ChgCDDA";
    this.handleValueHelp(oEvent, sFieldName1, sFieldName2, sFrgmntName);
  },

  handleValueHelpChgCDDB: function(oEvent) {
    var sFieldName, sFrgmntName;
    sFieldName = "Text1";
    sFrgmntName = "ChgCDDB";
    this.handleValueHelpSingle(oEvent, sFieldName, sFrgmntName);
  },

  handleValueHelpChgCDDP: function(oEvent) {
    var sFieldName, sFrgmntName;
    sFieldName = "Textm";
    sFrgmntName = "ChgCDDP";
    this.handleValueHelpSingle(oEvent, sFieldName, sFrgmntName);
  },

  handleValueHelpChgCDDR: function(oEvent) {
    var sFieldName, sFrgmntName;
    sFieldName = "Kunnr";
    sFrgmntName = "ChgCDDR";
    this.handleValueHelpSingle(oEvent, sFieldName, sFrgmntName);
  },

  handleValueHelpChgCDPG: function(oEvent) {
    var sFieldName, sFrgmntName;
    sFieldName = "Textl";
    sFrgmntName = "ChgCDPG";
    this.handleValueHelpSingle(oEvent, sFieldName, sFrgmntName);
  },

  handleValueHelpChgCDPT: function(oEvent) {
    var sFieldName, sFrgmntName;
    sFieldName = "Text1";
    sFrgmntName = "ChgCDPT";
    this.handleValueHelpSingle(oEvent, sFieldName, sFrgmntName);
  },

  handleValueHelpChgCDTG: function(oEvent) {
    /*    var sFieldName, sFrgmntName;
    sFieldName = "Togru";
    sFrgmntName = "ChgCDTG";
    this.handleValueHelpSingle(oEvent, sFieldName, sFrgmntName);*/
    var sFieldName1, sFieldName2, sFrgmntName;
    sFieldName1 = "Bukrs";
    sFieldName2 = "Togru";
    sFrgmntName = "ChgCDTG";
    this.handleValueHelp(oEvent, sFieldName1, sFieldName2, sFrgmntName);
  },

  handleValueHelpChgCDPM: function(oEvent) {
    /*    var sFieldName, sFrgmntName;
    sFieldName = "Text1";
    sFrgmntName = "ChgCDPM";
    this.handleValueHelpSingle(oEvent, sFieldName, sFrgmntName);*/
    var sFieldName1, sFieldName2, sFrgmntName;
    sFieldName1 = "Bukrs";
    sFieldName2 = "Text1";
    sFrgmntName = "ChgCDPM";
    this.handleValueHelp(oEvent, sFieldName1, sFieldName2, sFrgmntName);
  },

  handleValueHelpChgGDL: function(oEvent) {
    var sFieldName, sFrgmntName;
    sFieldName = "Sptxt";
    sFrgmntName = "ChgGDL";
    this.handleValueHelpSingle(oEvent, sFieldName, sFrgmntName);
  },

  handleValueHelpChgGDECS: function(oEvent) {
    var sFieldName, sFrgmntName;
    sFieldName = "Zzsetname";
    sFrgmntName = "ChgGDECS";
    this.handleValueHelpSingle(oEvent, sFieldName, sFrgmntName);
  },

  handleValueHelpChgGDTJ: function(oEvent) {
    var sFieldName1, sFieldName2, sFrgmntName;
    sFieldName1 = "Land1";
    sFieldName2 = "Text1";
    sFrgmntName = "ChgGDTJ";
    this.handleValueHelpDouble(oEvent, sFieldName1, sFieldName2, sFrgmntName);
  },

  handleValueHelpSingle: function(oEvent, sFieldName, sFrgmntName) {
    var sInputValue = oEvent.getSource().getValue();
    this.inputId = sFrgmntName;

    // create a filter for the binding
    var oFilter, aFilter = [];
    oFilter = new sap.ui.model.Filter(sFieldName, sap.ui.model.FilterOperator.Contains, sInputValue);
    aFilter.push(oFilter);

    // create value help dialog
    this._valueHelpDialog = sap.ui.xmlfragment("MyClients.fragments.change.dialogSearch." + sFrgmntName, this);
    this.getView().addDependent(this._valueHelpDialog);
    this._valueHelpDialog.getBinding("items").filter(aFilter);

    // open value help dialog filtered by the input value
    this._valueHelpDialog.open(sInputValue);
  },

  handleValueHelp: function(oEvent, sFieldName1, sFieldName2, sFrgmntName) {
    var sInputValue = oEvent.getSource().getValue();
    this.inputId = sFrgmntName;

    // create a filter for the binding
    var oFilter, aFilter = [];
    oFilter = new sap.ui.model.Filter(sFieldName1, sap.ui.model.FilterOperator.EQ, this._oVkorg);
    aFilter.push(oFilter);
    oFilter = new sap.ui.model.Filter(sFieldName2, sap.ui.model.FilterOperator.Contains, sInputValue);
    aFilter.push(oFilter);

    // create value help dialog
    this._valueHelpDialog = sap.ui.xmlfragment("MyClients.fragments.change.dialogSearch." + sFrgmntName, this);
    this.getView().addDependent(this._valueHelpDialog);
    this._valueHelpDialog.getBinding("items").filter(aFilter);

    // open value help dialog filtered by the input value
    this._valueHelpDialog.open(sInputValue);
  },

  handleValueHelpDouble: function(oEvent, sFieldName1, sFieldName2, sFrgmntName) {
    var sInputValue = oEvent.getSource().getValue();
    this.inputId = sFrgmntName;
    var oLand1 = this.getView().byId("ChgGDTJ").getName();

    // create a filter for the binding
    var oFilter, aFilter = [];
    oFilter = new sap.ui.model.Filter(sFieldName1, sap.ui.model.FilterOperator.EQ, oLand1);
    aFilter.push(oFilter);
    oFilter = new sap.ui.model.Filter(sFieldName2, sap.ui.model.FilterOperator.Contains, sInputValue);
    aFilter.push(oFilter);

    // create value help dialog
    this._valueHelpDialog = sap.ui.xmlfragment("MyClients.fragments.change.dialogSearch." + sFrgmntName, this);
    this.getView().addDependent(this._valueHelpDialog);
    this._valueHelpDialog.getBinding("items").filter(aFilter);

    // open value help dialog filtered by the input value
    this._valueHelpDialog.open(sInputValue);
  },

  handleValueHelpSearchChgCDAS: function(evt) {
    var sFieldName1 = "Text1";
    this._handleValueHelpSearch(evt, sFieldName1);
  },

  handleValueHelpSearchChgCDDA: function(evt) {
    /*    var sFieldName1 = "Text1";
    this._handleValueHelpSearch(evt, sFieldName1);*/
    var sFieldName1, sFieldName2;
    sFieldName1 = "Bukrs";
    sFieldName2 = "Text1";
    this._handleValueHelpSearchDouble(evt, sFieldName1, sFieldName2);
  },

  handleValueHelpSearchChgCDDB: function(evt) {
    var sFieldName1 = "Text1";
    this._handleValueHelpSearch(evt, sFieldName1);
  },

  handleValueHelpSearchChgCDDP: function(evt) {
    var sFieldName1 = "Textm";
    this._handleValueHelpSearch(evt, sFieldName1);
  },

  handleValueHelpSearchChgCDDR: function(evt) {
    var sFieldName1 = "Kunnr";
    this._handleValueHelpSearch(evt, sFieldName1);
  },

  handleValueHelpSearchChgCDPG: function(evt) {
    var sFieldName1 = "Textl";
    this._handleValueHelpSearch(evt, sFieldName1);
  },

  handleValueHelpSearchChgCDPT: function(evt) {
    var sFieldName1 = "Text1";
    this._handleValueHelpSearch(evt, sFieldName1);
  },

  handleValueHelpSearchChgCDTG: function(evt) {
    /*    var sFieldName1 = "Togru";
    this._handleValueHelpSearch(evt, sFieldName1);*/
    var sFieldName1, sFieldName2;
    sFieldName1 = "Bukrs";
    sFieldName2 = "Togru";
    this._handleValueHelpSearchDouble(evt, sFieldName1, sFieldName2);
  },

  handleValueHelpSearchChgCDPM: function(evt) {
    /*    var sFieldName1 = "Text1";
    this._handleValueHelpSearch(evt, sFieldName1);*/
    var sFieldName1, sFieldName2;
    sFieldName1 = "Bukrs";
    sFieldName2 = "Text1";
    this._handleValueHelpSearchDouble(evt, sFieldName1, sFieldName2);
  },

  handleValueHelpSearchChgGDL: function(evt) {
    var sFieldName1 = "Sptxt";
    this._handleValueHelpSearch(evt, sFieldName1);
  },

  handleValueHelpSearchChgGDECS: function(evt) {
    var sFieldName1 = "Zzsetname";
    this._handleValueHelpSearch(evt, sFieldName1);
  },

  handleValueHelpSearchChgGDTJ: function(evt) {
    var sFieldName1, sFieldName2;
    sFieldName1 = "Land1";
    sFieldName2 = "Text1";
    this._handleValueHelpSearchDouble1(evt, sFieldName1, sFieldName2);
  },

  _handleValueHelpSearch: function(evt, sFieldName1) {
    var sValue = evt.getParameter("value");
    var oFilter = new sap.ui.model.Filter(sFieldName1, sap.ui.model.FilterOperator.Contains, sValue);
    evt.getSource().getBinding("items").filter([oFilter]);
  },

  _handleValueHelpSearchDouble: function(evt, sFieldName1, sFieldName2) {
    var sValue = evt.getParameter("value");
    var oFilter;
    var aFilter = [];

    oFilter = new sap.ui.model.Filter(sFieldName1, sap.ui.model.FilterOperator.EQ, this._oVkorg);
    aFilter.push(oFilter);
    oFilter = new sap.ui.model.Filter(sFieldName2, sap.ui.model.FilterOperator.Contains, sValue);
    aFilter.push(oFilter);
    evt.getSource().getBinding("items").filter(aFilter);
  },

  _handleValueHelpSearchDouble1: function(evt, sFieldName1, sFieldName2) {
    var sValue = evt.getParameter("value");
    var oLand1 = this.getView().byId("ChgGDTJ").getName();
    var oFilter;
    var aFilter = [];

    oFilter = new sap.ui.model.Filter(sFieldName1, sap.ui.model.FilterOperator.EQ, oLand1);
    aFilter.push(oFilter);
    oFilter = new sap.ui.model.Filter(sFieldName2, sap.ui.model.FilterOperator.Contains, sValue);
    aFilter.push(oFilter);
    evt.getSource().getBinding("items").filter(aFilter);
  },

  _handleValueHelpClose: function(evt) {
    var oSelectedItem = evt.getParameter("selectedItem");
    if (oSelectedItem) {
      var productInput = this.getView().byId(this.inputId);
      productInput.setValue(oSelectedItem.getTitle());
      productInput.setPlaceholder(oSelectedItem.getDescription());
      productInput.setValueState("None");
    }
    evt.getSource().getBinding("items").filter([]);
  },

  _handleValueHelpCloseKunnr: function(evt) {
    var oSelectedItem = evt.getParameter("selectedItem");
    if (oSelectedItem) {
      var productInput = this.getView().byId(this.inputId);
      productInput.setValue(oSelectedItem.getTitle());
      productInput.setPlaceholder(oSelectedItem.getTitle());
      productInput.setValueState("None");
    }
    evt.getSource().getBinding("items").filter([]);
  },
  /*
    handleSuggestChgCDASSel: function(oEvent) {
      var oInputId = "ChgCDAS";
      this.handleSuggestSel(oEvent, oInputId);
    },

    handleSuggestChgCDDASel: function(oEvent) {
      var oInputId = "ChgCDDA";
      this.handleSuggestSel(oEvent, oInputId);
    },

    handleSuggestChgCDDBSel: function(oEvent) {
      var oInputId = "ChgCDDB";
      this.handleSuggestSel(oEvent, oInputId);
    },

    handleSuggestChgCDDPSel: function(oEvent) {
      var oInputId = "ChgCDDP";
      this.handleSuggestSel(oEvent, oInputId);
    },

    handleSuggestChgCDDRSel: function(oEvent) {
      var oInputId = "ChgCDDR";
      this.handleSuggestSel(oEvent, oInputId);
    },

    handleSuggestChgCDPGSel: function(oEvent) {
      var oInputId = "ChgCDPG";
      this.handleSuggestSel(oEvent, oInputId);
    },

    handleSuggestChgCDPTSel: function(oEvent) {
      var oInputId = "ChgCDPT";
      this.handleSuggestSel(oEvent, oInputId);
    },

    handleSuggestChgCDTGSel: function(oEvent) {
      var oInputId = "ChgCDTG";
      this.handleSuggestSel(oEvent, oInputId);
    },

    handleSuggestChgCDPMSel: function(oEvent) {
      var oInputId = "ChgCDPM";
      this.handleSuggestSel(oEvent, oInputId);
    },

    handleSuggestChgGDLSel: function(oEvent) {
      var oInputId = "ChgGDL";
      this.handleSuggestSel(oEvent, oInputId);
    },

    handleSuggestChgGDECSSel: function(oEvent) {
      var oInputId = "ChgGDECS";
      this.handleSuggestSel(oEvent, oInputId);
    },

    handleSuggestSel: function(oEvent, oInputId) {
      var oSelKey = oEvent.getParameter("selectedItem").getKey();
      this.getView().byId(oInputId).setPlaceholder(oSelKey);
    },*/

  handleAddRowChgBC: function(oEvent) {
    var oTable = this.getView().byId("FormChange354BC");
    var oModel = oTable.getModel();
    var modelData = oModel.getData();
    var aTable = [];
    if (modelData) {
      for (var i = 0; i < modelData.modelData.length; i++) {
        var value = modelData.modelData[i];
        aTable.push(value);
      }
    }
    var oRow = {
      Kunnr: this._oKunnr,
      Parnr: "",
      Namev: "",
      Name1: "",
      Phone: "",
      Fax: "",
      Email: "",
      Department: "",
      Msgfn: "009"
    };
    aTable.push(oRow);
    oModel.setData({
      modelData: aTable
    });
    sap.m.MessageToast.show("Row added: " + 1);
  },

  handleDelRowChgBC: function(oEvent) {
    var oTable = this.getView().byId("FormChange354BC");
    var m = oTable.getModel();
    var data = m.getData();
    var aSelIndices = oTable.getSelectedIndices();
    aSelIndices = aSelIndices.reverse();
    var count = aSelIndices.length;
    for (var i = 0; i < count; i++) {
      var value = aSelIndices[i];
      this._aDelTableBC.push(data.modelData[value]);
      data.modelData.splice(value, 1);
    }
    m.setData(data);
    oTable.clearSelection();
    sap.m.MessageToast.show("Rows deleted: " + count);
  },

  handleAddRowChgWD: function(oEvent) {
    var oTable = this.getView().byId("FormChange354WD");
    var oModel = oTable.getModel();
    var modelData = oModel.getData();
    var aTable = [];
    if (modelData) {
      for (var i = 0; i < modelData.modelData.length; i++) {
        var value = modelData.modelData[i];
        aTable.push(value);
      }
    }
    var oRow = {
      Kunnr: this._oKunnr,
      Vkorg: this._oVkorg,
      Witht: "",
      Withcd: "",
      Text40: "",
      Agent: false,
      Agtdf: "",
      Agtdt: "",
      Msgfn: "009"
    };
    aTable.push(oRow);
    oModel.setData({
      modelData: aTable
    });
    sap.m.MessageToast.show("Row added: " + 1);
  },

  handleDelRowChgWD: function(oEvent) {
    var oTable = this.getView().byId("FormChange354WD");
    var m = oTable.getModel();
    var data = m.getData();
    var aSelIndices = oTable.getSelectedIndices();
    aSelIndices = aSelIndices.reverse();
    var count = aSelIndices.length;
    for (var i = 0; i < count; i++) {
      var value = aSelIndices[i];
      this._aDelTableWD.push(data.modelData[value]);
      data.modelData.splice(value, 1);
    }
    m.setData(data);
    oTable.clearSelection();
    sap.m.MessageToast.show("Rows deleted: " + count);
  },

  handleAddRowChgPD: function(oEvent) {
    var oTable = this.getView().byId("FormChange354PD");
    var oModel = oTable.getModel();
    var modelData = oModel.getData();
    var aTable = [];
    if (modelData) {
      for (var i = 0; i < modelData.modelData.length; i++) {
        var value = modelData.modelData[i];
        aTable.push(value);
      }
    }
    var oRow = {
      Kunnr: this._oKunnr,
      Vkorg: this._oVkorg,
      Parvw: "PY",
      Kunn2: "",
      Name1: "",
      Address: "",
      Msgfn: "009"
    };
    aTable.push(oRow);
    oModel.setData({
      modelData: aTable
    });
    sap.m.MessageToast.show("Row added: " + 1);
  },

  handleDelRowChgPD: function(oEvent) {
    var oTable = this.getView().byId("FormChange354PD");
    var m = oTable.getModel();
    var data = m.getData();
    var aSelIndices = oTable.getSelectedIndices();
    /*var index = aSelIndices.indexOf(0);
    if (index > -1) {
      aSelIndices.splice(index, 1);
    }*/
    aSelIndices = aSelIndices.reverse();
    var count = aSelIndices.length;
    var countRow = 0;
    var bFlag = [];
    for (var i = 0; i < count; i++) {
      var value = aSelIndices[i];
      var data1 = data.modelData[value];
      switch (data1.Parvw) {
        case "SP":
          bFlag.push(false);
          sap.m.MessageToast.show("Sold-to party cannot be deleted");
          break;
          /*case "BP":
            bFlag.push(false);
            sap.m.MessageToast.show("Bill-to party cannot be deleted");
            break;*/
        case "PY":
          bFlag.push(false);
          sap.m.MessageToast.show("Payer cannot be deleted");
          break;
          /*  case "SH":
              bFlag.push(false);
              sap.m.MessageToast.show("Ship-to party cannot be deleted");
              break;*/
        default:
          bFlag.push(true);
          countRow = countRow + 1;
          this._aDelTablePD.push(data1);
          data.modelData.splice(value, 1);
      }
    }
    oTable.clearSelection();
    for (var a = 0; a < bFlag.length; a++) {
      var value123 = bFlag[a];
      if (value123) {
        m.setData(data);
        sap.m.MessageToast.show("Rows deleted: " + countRow);
      }
    }

    /*    if (index > -1) {
      sap.m.MessageToast.show("CLIENT Partner Type cannot be removed");
    } else {
      sap.m.MessageToast.show("Rows deleted: " + count);
    }*/
  },

  handleAddRowChgCPD: function(oEvent) {
    var oTable = this.getView().byId("FormChange354CPD");
    var oModel = oTable.getModel();
    var modelData = oModel.getData();
    var aTable = [];
    if (modelData) {
      for (var i = 0; i < modelData.modelData.length; i++) {
        var value = modelData.modelData[i];
        aTable.push(value);
      }
    }
    var oFromDt = "";
    var oToDt = "";
    if (modelData.modelData.length === 0) {
      var today = new Date();
      today = new Date(today.getTime() + (24 * 60 * 60 * 1000));
      oFromDt = MyClients.formatters.formatter.myDate1(today);
    } else {
      if (modelData.modelData[0].ValidUntil) {
        var tomorrow = new Date(modelData.modelData[0].ValidUntil);
        tomorrow = new Date(tomorrow.getTime() + (24 * 60 * 60 * 1000));
        oFromDt = MyClients.formatters.formatter.myDate1(tomorrow);
      }
    }
    var oRow = {
      Partner: this._oKunnr,
      Bukrs: this._oVkorg,
      ValidFrom: oFromDt,
      ValidUntil: oToDt,
      CollGroup: "",
      CollGroupText: "",
      CollSpecialist: "",
      Fullname: "",
      ValidFromE: true,
      ValidUntilE: true,
      CollGroupE: true,
      CollSpecialistE: true,
      ChangeID: "E",
      Msgfn: "I"
    };
    //aTable.push(oRow);
    aTable.splice(0, 0, oRow);
    oModel.setData({
      modelData: aTable
    });
    sap.m.MessageToast.show("Row added: " + 1);
  },

  handleDelRowChgCPD: function(oEvent) {
    var oTable = this.getView().byId("FormChange354CPD");
    var m = oTable.getModel();
    var data = m.getData();
    var aSelIndices = oTable.getSelectedIndices();
    aSelIndices = aSelIndices.reverse();
    var count = aSelIndices.length;
    var countRow = 0;
    var bFlag = [];
    for (var i = 0; i < count; i++) {
      var value = aSelIndices[i];
      var data1 = data.modelData[value];
      switch (data1.ChangeID) {
        case "P":
          bFlag.push(false);
          sap.m.MessageToast.show("Date entry cannot be deleted");
          break;
        case "D":
          bFlag.push(false);
          sap.m.MessageToast.show("Date entry cannot be deleted");
          break;
        default:
          if (data1.ValidFrom.length > 0 && data1.ValidUntil.length > 0 && data1.CollGroup.length > 0) { //Eligible to delete record
            // Delete record only if all the fields are filled
            bFlag.push(true);
            countRow = countRow + 1;
            this._aDelTableCPD.push(data1);
            data.modelData.splice(value, 1);
            this._oGlblFlag = false;
          } else {
            this._oGlblFlag = true;
            if (data1.ValidFrom.length === 0 || data1.ValidUntil.length === 0) {
              sap.m.MessageToast.show("Date entry needs to be filled");
            } else {
              sap.m.MessageToast.show("Collection Group needs to be filled");
            }
          }
      }
    }
    /*    for (var i = 0; i < count; i++) {
          var value = aSelIndices[i];
          this._aDelTableCPD.push(data.modelData[value]);
          data.modelData.splice(value, 1);
        }
        m.setData(data);
        oTable.clearSelection();
        sap.m.MessageToast.show("Rows deleted: " + count);
    */
    oTable.clearSelection();
    for (var a = 0; a < bFlag.length; a++) {
      var value123 = bFlag[a];
      if (value123) {
        m.setData(data);
        sap.m.MessageToast.show("Rows deleted: " + countRow);
      }
    }
  },

  handleLiveChg: function(oEvent) {
    var oValue = oEvent.getParameter("value");
    var oState = "None";
    if (!oValue) {
      oState = "Error";
    }
    oEvent.oSource.setValueState(oState);
  }
});