sap.ui.define([
	"AzureAPI/DTRV_Demo/test/unit/controller/View1.controller"
], function () {
	"use strict";
});