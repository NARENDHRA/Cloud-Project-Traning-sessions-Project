sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History"
], function (Controller, History) {
	"use strict";

	return Controller.extend("AzureAPI.DTRV_Demo.controller.DTRVdashboard", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf AzureAPI.DTRV_Demo.view.DTRVdashboard
		 */
		onInit: function () {
			this.setLegendModel();
			var that = this;
			that.initLoc(that);
			that.initialize();
		},
		initialize: function () {
			var oViewModel = new sap.ui.model.json.JSONModel();
			var data = {
				prospectFilterEnable: true,
				soldToFilterEnable: true,
				shipToFilterEnable: true,
				allAccountsFilterEnable: false,
				mifFilterEnable: true,
				uccFilterEnable: true,
				hppFilterEnable: true
			};
			oViewModel.setData(data);
			this.getView().setModel(oViewModel, "viewModel");

			// Get List of accounts
			// this.getAccounts();

			this.createMap();
		},

		setLegendModel: function () {
			var Data = {
				"Legend": [{

					"text": "HP",
					"color": "rgb(100,149,237)" // Sky Blue Color
				}, {

					"text": "Customers",
					"color": "rgb(248, 196, 113)" //"rgb(204,204,0)"	//	Dark Yellow Color
				}, {

					"text": "UCC",
					"color": "rgb(178,34,34)" // Fire Brick Red Color
				}, {
					"text": "Prop", // Black Color
					"color": "rgb(86, 101, 115)" //"rgb(0,0,0)"
				}, {
					"text": "Open-Opp",
					"color": "rgb(30, 132, 73)" // Green Yellow Color
				}]
			};

			var oModel = new sap.ui.model.json.JSONModel();
			oModel.setData(Data);
			this.getView().byId("GeoMap").setModel(oModel, "legend");
		},
		initLoc: function (that) {
			// Try HTML5 geolocation.
			if (navigator.geolocation) {
				navigator.geolocation.getCurrentPosition(function (position) {
						var pos = {
							lat: position.coords.latitude,
							lng: position.coords.longitude
						};
						// console.log("Found current location - Suji");
						console.log(pos);
						that.myPosition = pos;
						// if (window.localStorage.getItem("filter") || window.localStorage.getItem("range")) {
						// 	that.getView().byId("idSlider").setValue(Number(window.localStorage.getItem("range")));
						// 	if (window.localStorage.getItem("filter") !== null) {
						// 		that.resetFilterStatus();
						// 		that.setFilter(window.localStorage.getItem("filter"));
						// 		that.handleSpots(Number(window.localStorage.getItem("range")), window.localStorage.getItem("filter"));
						// 	} else
						// 		that.handleSpots(Number(window.localStorage.getItem("range")), null);
						// 	window.localStorage.removeItem("filter");
						// 	window.localStorage.removeItem("range");
						// } else
						// 	that.handleSpots(10, null);
						that.setMyLocation();
					}

					,
					function () {
						console.log("Error occured while finding current location")
						that.initLocAlt(that);
					});
			} else {
				// Browser doesn't support Geolocation
				console.log("Browser does not support finding current location")
				that.initLocAlt(that);
			}
		},
		initLocAlt: function (that) {
			jQuery.ajax({
				type: 'POST',
				url: "https://www.googleapis.com/geolocation/v1/geolocate?key=AIzaSyDaVXuAKP1CvNOKBBdXMu7IbyKDcQg0vfk",
				cache: false,
				dataType: "application/json",
				async: true,
				error: function (response) {
					// that.initialize();
					// that.wait(5000);
					var data = JSON.parse(response.responseText);
					that.myPosition = data.location;
					if (window.localStorage.getItem("filter") || window.localStorage.getItem("range")) {
						that.getView().byId("idSlider").setValue(Number(window.localStorage.getItem("range")));
						if (window.localStorage.getItem("filter") !== null) {
							that.resetFilterStatus();
							that.setFilter(window.localStorage.getItem("filter"));
							that.handleSpots(Number(window.localStorage.getItem("range")), window.localStorage.getItem("filter"));
						} else
							that.handleSpots(Number(window.localStorage.getItem("range")), null);
						window.localStorage.removeItem("filter");
						window.localStorage.removeItem("range");
					} else
						that.handleSpots(10, null);
					that.setMyLocation();
					// that.getView().byId("GeoMap").setZoomlevel(7);
				}

			});
		},
		setMyLocation: function () {
			var oGeoMap = this.getView().byId("GeoMap");
			var position = this.myPosition.lng + ";" + this.myPosition.lat + ";0";
			oGeoMap.setCenterPosition(position);
			oGeoMap.addVo(new sap.ui.vbm.Spots({
				items: [
					new sap.ui.vbm.Spot({
						position: position,
						type: "Default",
						tooltip: "You are here!",
						labelPos: position,
						labelType: "Success",
						labelText: "You are here!"
					})
				]
			}));
		},
		createMap: function () {
			var oGeoMap = this.getView().byId("GeoMap");
			var oMapConfig = {
				"MapProvider": [{
					"name": "GMAP",
					"Source": [{
						"id": "s1",
						"url": "https://mt.google.com/vt/x={X}&y={Y}&z={LOD}"
					}]
				}],
				"MapLayerStacks": [{
					"name": "DEFAULT",
					"MapLayer": {
						"name": "layer1",
						"refMapProvider": "GMAP",
						"opacity": "1",
						"colBkgnd": "RGB(255,255,255)"
					}
				}]
			};
			oGeoMap.setMapConfiguration(oMapConfig);
			oGeoMap.setRefMapLayerStack("DEFAULT");
		},
		onNavBack: function () {
			// debugger;
			// pervious view navigation to from current view 
			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("FunctionalTower", true);
			}
		}

	});

});