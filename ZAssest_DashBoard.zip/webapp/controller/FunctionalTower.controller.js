sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History"
], function (Controller, History) {
	"use strict";

	return Controller.extend("AzureAPI.DTRV_Demo.controller.FunctionalTower", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf AzureAPI.DTRV_Demo.view.FunctionalTower
		 */
		onInit: function () {
			// local property added to Local Json Modle .Added by Rajesh
			var oJsonModel = new sap.ui.model.json.JSONModel({
				digitalAsset: true,
				digitalAssetDetails: false,
				ENGDatadigitalDetails: false
			});
			this.getView().setModel(oJsonModel, "localModel");
			var oModelList = new sap.ui.model.json.JSONModel({
				results: [{
					"text": "Digital Twin"
				}, {
					"text": "3D Scaning"
				}, {
					"text": "Point Cloud"
				}, {
					"text": "Plant Virtualization"
				}, {
					"text": "Extended Reality"
				}, {
					"text": "4D/5D Construction/Turnaround"
				}],
				resultsE: [{
					"text": "Computer Vision for Engineering"
				}, {
					"text": "Document Analysis"
				}, {
					"text": "Digital Plant Refresh"
				}, {
					"text": "Engineering OCR"
				}]
			});
			this.getView().setModel(oModelList, "ListModel");
		},
		onNavBacklogin: function () {
			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("RouteView1", true);
			}
		},
		Next: function () {
			var oModel = this.getView().getModel("localModel");
			oModel.setProperty("/digitalAssetDetails", false);
			oModel.setProperty("/ENGDatadigitalDetails", false);
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("DTRVdashboard");
			// var oHistory = History.getInstance();
			// var sPreviousHash = oHistory.getPreviousHash();

			// if (sPreviousHash !== undefined && sPreviousHash !== ""  ) {
			// 	window.history.go(-1);
			// } else {
			// 	var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			// 	oRouter.navTo("RouteView1", true);
			// }

		},
		onFunctionalTowerSelect: function () {

			// var _this = this;

			// 	if (!this._oPopover) {
			// 	_this._oPopover = sap.ui.xmlfragment("AzureAPI.DTRV_Demo.controller.Platforms", _this);
			// 	_this.getView().addDependent(_this._oPopover);
			// 	// this._oPopover.bindElement("/ProductCollection/0");
			// }

			// _this._oPopover.open();
		},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf AzureAPI.DTRV_Demo.view.FunctionalTower
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf AzureAPI.DTRV_Demo.view.FunctionalTower
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf AzureAPI.DTRV_Demo.view.FunctionalTower
		 */
		//	onExit: function() {
		//
		//	}
		// Navback Button action added by rajesh 
		onLogout: function (evt) {
			// var src = evt.getSource();
			// history.go(-1);
			var oModel = this.getView().getModel("localModel");
			oModel.setProperty("/digitalAssetDetails", false);
			oModel.setProperty("/ENGDatadigitalDetails", false);
			var orouter = sap.ui.core.UIComponent.getRouterFor(this);
			orouter.navTo("RouteView1");
		},
		// View details action link view added by rajesh 
		onViewDetailstPress: function (evt) {
			var oModel = this.getView().getModel("localModel");
			var oAction = evt.getSource().getParent().getParent().getProperty("footer");
			var oModelList = new sap.ui.model.json.JSONModel({
				results: [{
					"text": "Digital Twin"
				}, {
					"text": "3D Scaning"
				}, {
					"text": "Point Cloud"
				}, {
					"text": "Plant Virtualization"
				}, {
					"text": "Extended Reality"
				}, {
					"text": "4D/5D Construction/Turnaround"
				}],
				resultsE: [{
					"text": "Computer Vision for Engineering"
				}, {
					"text": "Document Analysis"
				}, {
					"text": "Digital Plant Refresh"
				}, {
					"text": "Engineering OCR"
				}]
			});
			this.getView().setModel(oModelList, "ListModel");
			if (oAction === "Digital Asset Management") {
				oModel.setProperty("/digitalAssetDetails", true);
				oModel.setProperty("/ENGDatadigitalDetails", false);
			} else {
				oModel.setProperty("/ENGDatadigitalDetails", true);
				oModel.setProperty("/digitalAssetDetails", false);
			}
		}

	});

});