sap.ui.define([
	"mockSer/ZmockServer_SmartFilterBar/test/unit/controller/View1.controller"
], function () {
	"use strict";
});