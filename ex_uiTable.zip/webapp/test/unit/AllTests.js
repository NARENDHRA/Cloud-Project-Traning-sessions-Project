sap.ui.define([
	"excel/ex_uiTable/test/unit/controller/MainView.controller"
], function () {
	"use strict";
});