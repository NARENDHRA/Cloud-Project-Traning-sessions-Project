sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("excel.ex_uiTable.controller.MainView", {
		onInit: function () {
			var oModel = this.getOwnerComponent().getModel();
			this._oreadCall(oModel);
		},
		_oreadCall: function (oModel) {
			var ojsonModel = new sap.ui.model.json.JSONModel();
			var that = this;
			oModel.read("/ProductSet", {
				success: function (odata) {
					ojsonModel.setData(odata.results);
					that.getView().setModel(ojsonModel, "MattOffModel");
				},
				error: function () {}
			});
		},
		onExportExcelTrigger: function (evt) {
			var oModel = this.getOwnerComponent().getModel();
			var sUrl = oModel.sServiceUrl + "/ProductSet?$format=xlsx&$select=ProductID,TypeCode,Category,SupplierID";
			if (this.sFilterURL) {
				sUrl = sUrl + this.sFilterURL;
			}
			var encodeUrl = encodeURI(sUrl);
			sap.m.URLHelper.redirect(encodeUrl, false);
		},
		onChangetrigger: function (evt) {
			var oFileUpId = this.byId("fileUpload"),
				domRef = oFileUpId.getFocusDomRef(),
				file = domRef.files[0];
			oFileUpId.clear();
			this._importxlxsfile(file);
		},
		_importxlxsfile: function (file) {
			if (file && window.FileReader) {
				var reader = new FileReader();
				var that = this;
				reader.onload = function (evt) {
					var data = evt.target.result;
					//var xlsx = XLSX.read(data, {type: 'binary'});
					var CHUNK_SIZE = 0x8000; // arbitrary number here, not too small, not too big
					var index = 0;
					var array = new Uint8Array(data);
					var length = array.length;
					var arr = '';
					var slice1;
					while (index < length) {
						slice1 = array.subarray(index, Math.min(index + CHUNK_SIZE, length)); // `Math.min` is not really necessary here I think
						arr += String.fromCharCode.apply(null, slice1);
						index += CHUNK_SIZE;
					}
					try {
						var xlsx = XLSX.read(btoa(arr), {
							type: 'base64'
						});
					} catch (err) {
						sap.m.MessageBox.show(err.message, {
							title: "Error",
							styleClass: "sapUiSizeCompact messageBox",
							icon: sap.m.MessageBox.Icon.ERROR,
							actions: [sap.m.MessageBox.Action.OK]
						});
						that.getView().byId("fileUpload").setValue("");
						return false;
					}

					var result = xlsx.Strings;
					result = {};
					var sheet = xlsx.SheetNames[0];
					// xlsx.Sheets[xlsx.SheetNames[0]]['!ref'] = "A1:F10";
					xlsx.SheetNames.forEach(function (sheetName) {
						var rObjArr = XLSX.utils
							.sheet_to_row_object_array(xlsx.Sheets[sheetName]);
						if (rObjArr.length > 0) {
							result[sheetName] = rObjArr;
						}
					});
					var sheetData = result[sheet];
					if (sheetData === undefined) {
						sap.m.MessageBox.show("Invalid Excel\nUse Excel template to upload", {
							title: "Error",
							styleClass: "sapUiSizeCompact messageBox",
							icon: sap.m.MessageBox.Icon.ERROR,
							actions: [sap.m.MessageBox.Action.OK]
						});
						that.getView().byId("fileUpload").setValue("");
						return false;
					}
					that._creatobjPy(sheetData);

				};
				reader.readAsArrayBuffer(file);
			}
		},
		_creatobjPy: function (Data) {
			var oTable = this.getView().byId();
			var excelData = [];
			//Excel Header set
			for (var k = 0; k < Data.length; k++) {
				var data = Data[k];
				var oProductID = data["Product ID"] ? data["Product ID"].trim() : "";
				var oTypeCode = data["Product Type Code"] ? data["Product Type Code"].trim() : "";
				var oCategory = data["Product Category"] ? data["Product Category"].trim() : "";
				var oSupplierID = data["Business Partner ID"] ? data["Business Partner ID"].trim() : "";
				var obj = {
					"ProductID": oProductID,
					"TypeCode": oTypeCode,
					"Category": oCategory,
					"SupplierID": oSupplierID
				};
				excelData.push(obj);
			}
			var model = this.getView().getModel("MattOffModel"),
				results = excelData;

			// results.push(objArray);
			model.setProperty("/", results);
		},
		onPressCanclefn: function (evt) {
			this.getView().setBusy(true);
			var oModel = this.getOwnerComponent().getModel();
			this._oreadCall(oModel);
			this.getView().setBusy(false);
		}
	});
});